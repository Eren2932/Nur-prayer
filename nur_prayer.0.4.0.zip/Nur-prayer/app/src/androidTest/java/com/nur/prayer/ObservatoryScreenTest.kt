package com.nur.prayer

import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.qibla.Heading
import com.nur.prayer.ui.qibla.HeadingSource
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Run in the existing API 26 / 34 CI matrix. Authored here, not claimed as locally executed. */
@RunWith(AndroidJUnit4::class)
class ObservatoryScreenTest {
    @get:Rule val compose = createComposeRule()
    private val moment = ZonedDateTime.parse("2026-09-07T21:00:00+03:00[Europe/Moscow]")
    private fun fixture(): PrayerData {
        val city = City.MOSCOW
        val settings = AppSettings()
        val params = settings.paramsFor(city.country)
        val place = Place(city.name, city.subtitle, city.country, city.coordinates, city.zone, false)
        return PrayerData(place, PrayerEngine.days(moment.toLocalDate(), 3, city.coordinates, city.zone, params),
            PrayerEngine.window(moment, city.coordinates, city.zone, params), qiblaBearing(city.coordinates),
            distanceToKaabaKm(city.coordinates), HijriCalendar.format(moment.toLocalDate()), settings,
            settings.profileFor(city.country), params)
    }

    @Test fun countdownUsesSharedClockWithoutLosingLayout() {
        val data = fixture()
        val clock = mutableStateOf(moment)
        compose.setContent { NurTheme { HomeScreen(data, clock, paletteFor(Prayer.ISHA), {}) } }
        val next = moment.plusSeconds(1)
        compose.runOnIdle { clock.value = next }
        compose.onNodeWithContentDescription("До ${PrayerLabels.title(data.window.next)}: ${Format.countdown(data.window.remaining(next))}")
            .assertIsDisplayed()
        compose.onNodeWithText("ПУТЬ ВРЕМЕНИ").assertIsDisplayed()
    }
    @Test fun unavailableSensorCannotShowDirectionFound() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading()) } }
        compose.onNodeWithText("Компас недоступен").assertIsDisplayed()
        compose.onNodeWithText("НАПРАВЛЕНИЕ НАЙДЕНО").assertDoesNotExist()
        compose.onNodeWithContentDescription("Кааба — направление кыблы").assertIsDisplayed()
    }
    @Test fun magneticInterferenceCannotReportLockEvenAtTargetAzimuth() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 110f, source = HeadingSource.FUSED)) } }
        compose.onNodeWithText("Проверьте калибровку и помехи").assertIsDisplayed()
        compose.onNodeWithText("НАПРАВЛЕНИЕ НАЙДЕНО").assertDoesNotExist()
    }
    @Test fun alignedCalibratedFlatSensorShowsLock() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 45f, source = HeadingSource.FUSED)) } }
        compose.onNodeWithText("НАПРАВЛЕНИЕ НАЙДЕНО").assertIsDisplayed()
        compose.onNodeWithText("Направление на Каабу").assertIsDisplayed()
    }
}
