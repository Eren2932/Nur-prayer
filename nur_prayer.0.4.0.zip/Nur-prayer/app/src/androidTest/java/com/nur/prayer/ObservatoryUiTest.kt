package com.nur.prayer

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.ui.schedule.CalendarMonthModel
import com.nur.prayer.ui.schedule.MonthCalendar
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import java.time.LocalDate
import java.time.YearMonth
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ObservatoryUiTest {
    @get:Rule val compose = createComposeRule()

    private fun calendar(today: LocalDate, initial: YearMonth = YearMonth.from(today)) {
        compose.setContent {
            NurTheme {
                var month by remember { mutableStateOf(initial) }
                var selected by remember { mutableStateOf(today) }
                Column(Modifier.width(320.dp)) {
                    MonthCalendar(month, selected, today, 0, paletteFor(Prayer.ISHA),
                        onMonth = { target ->
                            month = target
                            selected = CalendarMonthModel.moveSelection(selected, target)
                        }, onSelect = { selected = it }, onToday = { month = YearMonth.from(today); selected = today })
                }
            }
        }
    }

    @Test fun fullMonthHasSelectableLastDayOnCompactViewport() {
        calendar(LocalDate.of(2026, 9, 7))
        compose.onNodeWithTag("calendar-day-2026-09-30").assertIsDisplayed().performClick().assertIsSelected()
    }
    @Test fun changingMonthAndReturningTodayWorks() {
        calendar(LocalDate.of(2026, 9, 7))
        compose.onNodeWithContentDescription("Следующий месяц").performClick()
        compose.onNodeWithText("октябрь 2026").assertIsDisplayed()
        compose.onNodeWithTag("calendar-today").performClick()
        compose.onNodeWithTag("calendar-day-2026-09-07").assertIsSelected()
    }
    @Test fun leapDayCanBeSelected() {
        calendar(LocalDate.of(2028, 2, 1))
        compose.onNodeWithTag("calendar-day-2028-02-29").performClick().assertIsSelected()
    }
    @Test fun adjacentMonthPaddingDoesNotDispatchSelection() {
        calendar(LocalDate.of(2026, 9, 7))
        compose.onNodeWithTag("calendar-day-2026-08-31").assertIsNotEnabled()
        compose.onNodeWithTag("calendar-day-2026-09-07").assertIsSelected()
    }
    @Test fun navigationHasAnExplicitUpperBound() {
        calendar(LocalDate.of(2026, 9, 7), YearMonth.of(2027, 9))
        compose.onNodeWithContentDescription("Следующий месяц").assertIsNotEnabled()
    }
}
