package com.nur.prayer.ui.components

import android.os.SystemClock
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.translate
import com.nur.prayer.ui.theme.PhasePalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.math.sin
import kotlin.math.PI

/** One 20 Hz draw-only clock, 38 stars, 8 motes, two cached ribbons. No blur, bitmaps or runtime shaders.
 * Lifecycle / battery / accessibility policy stops the coroutine, not just its visible output.
 */
@Composable
fun NightSky(palette: PhasePalette, modifier: Modifier = Modifier, motionEnabled: Boolean = true) {
    val allowed = motionEnabled && rememberAmbientMotionAllowed()
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(allowed) {
        if (allowed) {
            var last = SystemClock.elapsedRealtime()
            while (isActive) {
                delay(50L)
                val next = SystemClock.elapsedRealtime()
                phase.floatValue = (phase.floatValue + (next - last).coerceAtMost(150L) / 1000f) % (200f * PI.toFloat())
                last = next
            }
        }
    }
    Box(modifier.fillMaxSize().drawWithCache {
        val w = size.width
        val h = size.height
        if (w < 1f || h < 1f) {
            onDrawBehind { }
        } else {
            val sky = Brush.verticalGradient(listOf(palette.zenith, palette.mid, palette.horizon))
            val horizon = Brush.radialGradient(
                listOf(palette.glow.copy(alpha = 0.22f), Color.Transparent),
                center = Offset(w * 0.8f, h * 0.46f), radius = size.maxDimension * 0.7f)
            val veil = Brush.verticalGradient(listOf(Color.Transparent, palette.zenith.copy(alpha = 0.8f)))
            val stars = List(38) { i -> Offset(w * ((i * 73 + 19) % 997) / 997f,
                h * (0.02f + ((i * 137 + 41) % 991) / 991f * 0.72f)) }
            val ribbons = List(2) { i -> Path().apply {
                val y = h * (0.22f + i * 0.13f)
                moveTo(-w * 0.2f, y)
                cubicTo(w * 0.2f, y - h * 0.2f, w * 0.7f, y + h * 0.2f, w * 1.2f, y - h * 0.16f)
                lineTo(w * 1.2f, y - h * 0.12f)
                cubicTo(w * 0.7f, y + h * 0.28f, w * 0.2f, y - h * 0.16f, -w * 0.2f, y + h * 0.06f)
                close()
            } }
            val ribbonBrushes = listOf(palette.ribbonA, palette.ribbonB).map { color ->
                Brush.verticalGradient(listOf(Color.Transparent,
                    color.copy(alpha = 0.13f * palette.auroraIntensity), Color.Transparent), 0f, h * 0.75f)
            }
            onDrawBehind {
                val t = phase.floatValue // read only in drawing: does not recompose screens
                drawRect(sky)
                drawRect(horizon)
                ribbons.forEachIndexed { i, path ->
                    translate(top = sin(t * 0.12f + i * 2f) * h * 0.026f,
                        left = sin(t * 0.07f + i) * w * 0.035f) { drawPath(path, ribbonBrushes[i]) }
                }
                stars.forEachIndexed { i, point ->
                    val alpha = (0.28f + 0.26f * (sin(t * 0.45f + i * 1.7f) + 1f)) * palette.starIntensity
                    drawCircle(palette.accentSoft.copy(alpha = alpha), (if (i % 7 == 0) 1.1f else 0.65f) * density, point)
                }
                repeat(8) { i ->
                    val x = w * (0.08f + i * 0.12f) + sin(t * 0.18f + i * 2f) * w * 0.025f
                    val y = h * (0.25f + i * 0.065f) + sin(t * 0.11f + i) * h * 0.05f
                    drawCircle(palette.accentSoft.copy(alpha = 0.10f), 4f * density, Offset(x, y))
                    drawCircle(palette.accentSoft.copy(alpha = 0.45f), 1.1f * density, Offset(x, y))
                }
                drawRect(veil)
            }
        }
    })
}
