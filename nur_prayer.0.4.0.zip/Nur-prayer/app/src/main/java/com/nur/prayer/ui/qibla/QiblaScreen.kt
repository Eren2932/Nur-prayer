package com.nur.prayer.ui.qibla

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.InkSoft
import com.nur.prayer.ui.theme.solidTone
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.KaabaIcon
import androidx.compose.foundation.clickable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.nur.prayer.ui.components.AtlasPanel
import com.nur.prayer.ui.theme.Amber
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin


/**
 * The colour of an instrument that has not found anything yet.
 *
 * Green on this screen means exactly one thing — *you are pointing at the Kaaba* — and it may
 * therefore never appear before that is true.
 */
private val DialSteel = Color(0xFFC6CEE4)

/** North is a fact about the dial, not a status, so it gets brightness rather than colour. */
private val NorthLabel = Color(0xFFE6EBFA)

@Composable
fun QiblaScreen(
    data: PrayerData,
    palette: PhasePalette,
    modifier: Modifier = Modifier,
    /** Preview / instrumentation seam; production always uses the real lifecycle-aware sensors. */
    headingOverride: Heading? = null
) {
    val ui = uiScale()
    val dockInset = LocalDockInset.current
    var showDetails by rememberSaveable { mutableStateOf(false) }
    val heading = headingOverride ?: rememberHeading(data.place.coordinates.latitude, data.place.coordinates.longitude)
    val qibla = data.qibla.toFloat()
    val delta = angleDelta(heading.azimuth, qibla)
    val aligned = QiblaGuidance.aligned(delta, heading.available, heading.trustworthy, heading.heldFlat)
    val haptic = LocalHapticFeedback.current

    // Fires once per entry into the aligned state, not on every frame inside it.
    LaunchedEffect(aligned) {
        if (aligned) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    // Two separate colours, because they answer two separate questions.
    //
    // `markColor` — "am I on the Kaaba?" Steel until the answer is yes, then mint. Nothing else is
    // allowed to turn it green. The old code used `palette.accent` here, and at night that accent
    // *is* mint: the compass looked solved the moment it opened, so the one signal that matters
    // carried no information.
    // `deviceColor` — "can the sensors be trusted?" It reports interference and tilt, and it stays
    // steel while everything is fine, so a healthy compass is visually silent.
    val markColor by animateColorAsState(
        targetValue = if (aligned) Mint else DialSteel,
        animationSpec = tween(280),
        label = "qiblaMark"
    )
    val deviceColor by animateColorAsState(
        targetValue = when {
            aligned -> Mint
            heading.interference -> Crimson
            !heading.heldFlat -> Amber
            else -> DialSteel
        },
        animationSpec = tween(400),
        label = "qiblaDevice"
    )
    // Width of the lock-on bloom: 0 while searching, 1 when locked.
    val lock by animateFloatAsState(
        targetValue = if (aligned) 1f else 0f,
        animationSpec = tween(320),
        label = "qiblaLock"
    )
    var rotationTarget by remember { mutableFloatStateOf(-heading.azimuth) }
    LaunchedEffect(heading.azimuth) {
        rotationTarget = nearestDialRotation(rotationTarget, heading.azimuth)
    }
    val dialRotation = animateFloatAsState(
        targetValue = rotationTarget,
        animationSpec = tween(90),
        label = "dial"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = ui.s(20f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("ОДНО НАПРАВЛЕНИЕ", color = palette.accentSoft, fontSize = ui.t(10f), letterSpacing = ui.t(2f),
            modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
        AutoSizeText(
            text = "Путь к Каабе",
            color = TextPrimary,
            fontSize = ui.t(30f),
            fontWeight = FontWeight.SemiBold
        )
        AutoSizeText(
            text = "${data.place.label} · ${data.kaabaDistanceKm.roundToInt()} км до Каабы",
            color = TextTertiary,
            fontSize = ui.t(12f),
            maxLines = 2,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(ui.s(12f)))

        // The dial never grows past what the viewport can host, whatever the font scale is.
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val dialSize = min(maxWidth, maxOf(280.dp, (ui.heightDp * 0.44f).dp))
            Box(
                modifier = Modifier
                    .width(dialSize)
                    .aspectRatio(1f)
                    .align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                // Opaque instrument body: a fixed bezel separates information from the backdrop.
                Canvas(Modifier.fillMaxSize()) {
                    if (size.minDimension < 8f) return@Canvas
                    val r = size.minDimension * 0.49f
                    drawCircle(Brush.radialGradient(listOf(InkSoft, SurfaceInset), center, r), r)
                    drawCircle(SurfaceEdge, radius = r, style = Stroke(1.dp.toPx()))
                    drawCircle(markColor.copy(alpha = 0.18f), radius = r * 0.95f, style = Stroke(3.dp.toPx()))
                    drawCircle(markColor.copy(alpha = 0.10f), radius = r * 0.60f, style = Stroke(1.dp.toPx()))
                }
                // The world rotates, the phone stays still.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { rotationZ = dialRotation.value }
                ) {
                    CompassFace(qibla, markColor, lock)

                    CardinalLabel("С", 0f, NorthLabel, ui.t(13f), dialRotation, dialSize * 0.18f)
                    CardinalLabel("В", 90f, TextSecondary, ui.t(12f), dialRotation, dialSize * 0.18f)
                    CardinalLabel("Ю", 180f, TextSecondary, ui.t(12f), dialRotation, dialSize * 0.18f)
                    CardinalLabel("З", 270f, TextSecondary, ui.t(12f), dialRotation, dialSize * 0.18f)
                    for (degree in listOf(30, 60, 120, 150, 210, 240, 300, 330)) {
                        CardinalLabel(degree.toString(), degree.toFloat(), TextTertiary, ui.t(9f), dialRotation, dialSize * 0.18f)
                    }

                    // Kaaba marker: rides the dial, stays upright.
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { rotationZ = qibla }
                    ) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .size(ui.s(44f))
                                .graphicsLayer { rotationZ = -dialRotation.value - qibla }
                                .clip(CircleShape)
                                // The badge stays neutral while searching; only a trusted lock turns its edge mint.
                                .background(
                                    if (aligned) solidTone(Mint, 0.2f) else InkSoft
                                )
                                .border(
                                    1.dp,
                                    markColor.copy(alpha = 0.22f + 0.53f * lock),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            KaabaIcon(markColor, Modifier.size(ui.s(31f)).semantics { contentDescription = "Кааба — направление кыблы" })
                        }
                    }
                }

                // Fixed device pointer, drawn on top of the rotating dial.
                Canvas(modifier = Modifier.fillMaxSize()) {
                    if (size.minDimension < 8f) return@Canvas
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val radius = size.minDimension / 2f * 0.86f
                    // Mask the ray below the readout to keep numerals crisp.
                    drawCircle(SurfaceInset, radius = radius * 0.58f, center = center)
                    // Separate radial zones: badge ends first, then the fixed pointer, then labels.
                    val tip = size.minDimension / 2f - ui.s(44f).toPx() - 3.dp.toPx()
                    val base = tip - 7.dp.toPx()
                    val path = Path().apply {
                        moveTo(center.x, center.y - tip)
                        lineTo(center.x - radius * 0.045f, center.y - base)
                        lineTo(center.x + radius * 0.045f, center.y - base)
                        close()
                    }
                    drawPath(path, color = deviceColor)
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .widthIn(max = dialSize * 0.56f)
                        .padding(top = ui.s(18f))
                ) {
                    AutoSizeText(if (aligned) "НАПРАВЛЕНИЕ НАЙДЕНО" else "ОСТАЛОСЬ ПОВЕРНУТЬ", color = TextTertiary, fontSize = ui.t(9f), minFontSize = ui.t(7f),
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    AutoSizeText(
                        text = if (heading.available && heading.trustworthy && heading.heldFlat) "${abs(delta).roundToInt()}°" else "—",
                        color = TextPrimary,
                        fontSize = ui.t(46f),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Light
                    )
                    AutoSizeText(
                        text = QiblaGuidance.instruction(delta, heading.available, heading.trustworthy, heading.heldFlat),
                        color = if (aligned) Mint else TextSecondary,
                        fontSize = ui.t(11f),
                        maxLines = 3,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(ui.s(6f)))
                    if (heading.available) BubbleLevel(tiltDegrees = heading.tiltDegrees, size = ui.s(28f), accent = deviceColor)
                }
            }
        }

        Spacer(Modifier.height(ui.s(10f)))

        // Honest status line: what the sensors are actually doing right now.
        StatusStrip(heading = heading, accent = palette.accent, ui = ui)

        Spacer(Modifier.height(ui.s(10f)))

        AtlasPanel(modifier = Modifier.fillMaxWidth(), contentPadding = ui.s(16f)) {
            Column {
                InfoRow("Азимут кыблы · истинный север", QiblaGuidance.degrees(qibla), ui)
                Row(Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = { showDetails = !showDetails })
                    .padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Точность и датчики", color = TextPrimary, fontSize = ui.t(14f), modifier = Modifier.weight(1f))
                    Text(if (showDetails) "−" else "+", color = palette.accentSoft, fontSize = ui.t(22f))
                }
                if (showDetails) {
                InfoRow("Курс устройства", if (heading.available) QiblaGuidance.degrees(heading.azimuth) else "—", ui)
                InfoRow("Магнитный курс", if (heading.available) QiblaGuidance.degrees(heading.magneticAzimuth) else "—", ui)
                InfoRow(
                    "Магнитная поправка (WMM)",
                    (if (heading.declination >= 0) "+" else "") + "${heading.declination.roundToInt()}°",
                    ui
                )
                InfoRow("Наклон телефона", if (heading.available) "${heading.tiltDegrees.roundToInt()}°" else "—", ui)
                InfoRow(
                    "Поле",
                    if (heading.fieldStrength > 0f) "${heading.fieldStrength.roundToInt()} мкТл" else "—",
                    ui
                )
                InfoRow(
                    "Датчики",
                    when (heading.source) {
                        HeadingSource.FUSED -> "гиро + магнит + акселерометр"
                        HeadingSource.GEOMAGNETIC -> "магнит + акселерометр"
                        HeadingSource.RAW -> "магнит + акселерометр (сырые)"
                        HeadingSource.NONE -> "недоступны"
                    },
                    ui
                )

                }
                val hint = when {
                    !heading.available ->
                        "На этом устройстве нет магнитометра — компас недоступен. Азимут кыблы рассчитан для выбранного местоположения: " +
                            "выставьте его по любому другому компасу или по карте."
                    heading.interference ->
                        "Поле ${heading.fieldStrength.roundToInt()} мкТл вместо обычных 25–65: рядом магнит, металл или " +
                            "динамик. Отойдите от техники и стола с металлом."
                    heading.accuracy < 2 ->
                        "Магнитометр не откалиброван. Проведите телефоном «восьмёркой» в воздухе 3–4 секунды."
                    !heading.heldFlat ->
                        "Держите телефон горизонтально, экраном вверх — пузырёк должен встать в центр. " +
                            "Сейчас читаем направление «от задней камеры», это менее точно."
                    else ->
                        "Поправка на магнитное склонение применена. Зелёный указатель означает доворот не более 2,5°, " +
                            "но это не гарантия точности датчика. Держитесь подальше от металла и магнитных чехлов."
                }
                Spacer(Modifier.height(ui.s(8f)))
                Text(
                    text = hint,
                    color = TextTertiary,
                    fontSize = ui.t(11.5f),
                    lineHeight = ui.t(16f)
                )
            }
        }

        Spacer(Modifier.height(dockInset))
    }
}

/** Scalar tilt indicator, not a directional pitch/roll level. */
@Composable
private fun BubbleLevel(tiltDegrees: Float, size: androidx.compose.ui.unit.Dp, accent: Color) {
    val normalized = (tiltDegrees / 45f).coerceIn(0f, 1f)
    Canvas(modifier = Modifier.size(size)) {
        if (this.size.minDimension < 4f) return@Canvas
        val r = this.size.minDimension / 2f
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        drawCircle(
            color = Color.White.copy(alpha = 0.10f),
            radius = r,
            center = center,
            style = Stroke(width = 1.2f * density)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.16f),
            radius = r * 0.30f,
            center = center,
            style = Stroke(width = 1f * density)
        )
        drawCircle(
            color = accent.copy(alpha = 0.85f),
            radius = r * 0.22f,
            center = Offset(center.x, center.y + normalized * r * 0.72f)
        )
    }
}

/**
 * One line of sensor state.
 *
 * It used to be a row of capsules: tinted fill, hairline border, a dot each. Three problems, and
 * only one of them is taste. A capsule is the shape this app uses for things you can *press* — the
 * method picker, the day chips in the schedule — so a read-only readout wearing it invited taps that
 * do nothing. Two of them side by side also carried more visual weight than the number they were
 * describing, and the tinted-glass pill is the single most recognisable stock component going, which
 * is exactly the "assembled from a template" look we are trying not to have.
 *
 * So: one dot, one line, tertiary type. The dot takes the colour of the *worst* thing currently
 * true, because that is the only part a glance needs; the words stay quiet and are read only when
 * the dot says something is off. Nothing is hidden — the same facts are still in the table below
 * and in "О расчётах".
 */
private data class SensorNote(val label: String, val tone: Color, val severity: Int)

@Composable
private fun StatusStrip(
    heading: Heading,
    accent: Color,
    ui: com.nur.prayer.ui.theme.UiScale
) {
    val notes = buildList {
        if (!heading.available) add(SensorNote("датчики недоступны", TextSecondary, 4))
        if (heading.available) add(
            when (heading.accuracy) {
                3 -> SensorNote("калибровка высокая", Mint, 0)
                2 -> SensorNote("калибровка средняя", accent, 1)
                1 -> SensorNote("калибровка низкая", Amber, 2)
                0 -> SensorNote("не калиброван", Crimson, 3)
                else -> SensorNote("проверяем калибровку", TextTertiary, 1)
            }
        )
        if (heading.interference) add(SensorNote("помеха магнита", Crimson, 3))
        if (!heading.heldFlat && heading.available) {
            add(SensorNote("наклон ${heading.tiltDegrees.roundToInt()}°", Amber, 2))
        }
        if (heading.trustworthy && heading.heldFlat) add(SensorNote("готов", Mint, 0))
    }
    val worst = notes.maxByOrNull { it.severity } ?: return
    val quiet = worst.severity == 0
    // The tilt note carries a live number, so the string changes several times a second. Keying the
    // auto-size search on the *length* keeps it from re-measuring (and blinking) on every degree.
    val line = notes.joinToString(" · ") { it.label }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(ui.s(5f))
                .clip(CircleShape)
                .background(worst.tone.copy(alpha = if (quiet) 0.55f else 0.9f))
        )
        Spacer(Modifier.width(ui.s(7f)))
        AutoSizeText(
            text = line,
            color = if (quiet) TextTertiary else worst.tone.copy(alpha = 0.85f),
            fontSize = ui.t(10.5f),
            minFontSize = ui.t(8.5f),
            maxLines = 1,
            textAlign = TextAlign.Center,
            resizeKey = line.length
        )
    }
}

@Composable
private fun CardinalLabel(
    text: String,
    angle: Float,
    color: Color,
    fontSize: androidx.compose.ui.unit.TextUnit,
    dialRotation: State<Float>,
    inset: androidx.compose.ui.unit.Dp
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { rotationZ = angle }
            .padding(inset)
    ) {
        Text(
            text = text,
            color = color,
            fontSize = fontSize,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .graphicsLayer { rotationZ = -angle - dialRotation.value }
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String, ui: com.nur.prayer.ui.theme.UiScale) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(5f)),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AutoSizeText(
            text = label,
            color = TextTertiary,
            fontSize = ui.t(11.5f),
            maxLines = 2,
            modifier = Modifier.weight(1f, fill = true)
        )
        Spacer(Modifier.width(ui.s(10f)))
        AutoSizeText(
            text = value,
            color = TextPrimary,
            fontSize = ui.t(12.5f),
            fontFamily = FontFamily.Monospace
        )
    }
}

/** Stable child: heading updates rotate the layer, not the cached paths and trigonometry. */
@Composable
private fun CompassFace(qibla: Float, markColor: Color, lock: Float) {
    Box(Modifier.fillMaxSize().drawWithCache {
        val radius = size.minDimension * 0.43f
        val c = Offset(size.width / 2f, size.height / 2f)
        if (radius < 4f) {
            onDrawBehind { }
        } else {
            val majorTicks = Path()
            val minorTicks = Path()
            for (i in 0 until 72) {
                val a = Math.toRadians(i * 5.0 - 90.0)
                val major = i % 6 == 0
                val inner = radius * (if (major) 0.90f else 0.955f)
                val path = if (major) majorTicks else minorTicks
                path.moveTo(c.x + radius * cos(a).toFloat(), c.y + radius * sin(a).toFloat())
                path.lineTo(c.x + inner * cos(a).toFloat(), c.y + inner * sin(a).toFloat())
            }
            val petals = Path().apply {
                repeat(8) { i ->
                    val a = Math.toRadians(i * 45.0 - 90.0)
                    val side = Math.toRadians(9.0)
                    moveTo(c.x + radius * 0.58f * cos(a).toFloat(), c.y + radius * 0.58f * sin(a).toFloat())
                    lineTo(c.x + radius * 0.69f * cos(a - side).toFloat(), c.y + radius * 0.69f * sin(a - side).toFloat())
                    lineTo(c.x + radius * 0.84f * cos(a).toFloat(), c.y + radius * 0.84f * sin(a).toFloat())
                    lineTo(c.x + radius * 0.69f * cos(a + side).toFloat(), c.y + radius * 0.69f * sin(a + side).toFloat())
                    close()
                }
            }
            val qa = Math.toRadians(qibla - 90.0)
            val half = Math.toRadians(QiblaGuidance.ALIGN_TOLERANCE.toDouble())
            val cone = Path().apply {
                moveTo(c.x, c.y)
                lineTo(c.x + radius * cos(qa - half).toFloat(), c.y + radius * sin(qa - half).toFloat())
                lineTo(c.x + radius * cos(qa + half).toFloat(), c.y + radius * sin(qa + half).toFloat())
                close()
            }
            val tip = Offset(c.x + radius * 0.94f * cos(qa).toFloat(), c.y + radius * 0.94f * sin(qa).toFloat())
            val ray = Brush.linearGradient(listOf(markColor.copy(alpha = 0.12f), markColor), c, tip)
            val majorStyle = Stroke(1.8f * density, cap = StrokeCap.Round)
            val minorStyle = Stroke(0.8f * density, cap = StrokeCap.Round)
            val rim = Stroke(density)
            onDrawBehind {
                drawCircle(SurfaceEdge, radius, c, style = rim)
                drawCircle(SurfaceEdge, radius * 0.56f, c, style = rim)
                drawPath(petals, markColor.copy(alpha = 0.055f))
                drawPath(petals, markColor.copy(alpha = 0.22f), style = rim)
                drawPath(majorTicks, TextSecondary, style = majorStyle)
                drawPath(minorTicks, SurfaceEdge, style = minorStyle)
                drawPath(cone, markColor.copy(alpha = 0.05f + 0.13f * lock))
                drawLine(ray, c, tip, strokeWidth = (2f + lock) * density, cap = StrokeCap.Round)
            }
        }
    })
}
