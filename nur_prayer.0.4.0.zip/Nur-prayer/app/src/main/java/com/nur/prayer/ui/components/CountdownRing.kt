package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.CountdownMath
import com.nur.prayer.ui.theme.SurfaceEdge
import java.time.ZonedDateTime
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Compatibility name; now a shallow luminous horizon, not a second compass.
 * Interval progress and readout share the same clock. No independent animation loop.
 */
@Composable
fun CountdownRing(
    startMillis: Long, endMillis: Long, now: State<ZonedDateTime>, accent: Color,
    accentSoft: Color, modifier: Modifier = Modifier, stroke: Dp = 3.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            if (size.minDimension < 24f) return@Canvas
            val progress = CountdownMath.progress(startMillis, endMillis, now.value.toInstant().toEpochMilli())
            val rx = size.width * 0.44f
            val ry = size.height * 0.28f
            val c = Offset(size.width * 0.5f, size.height * 0.99f)
            val origin = Offset(c.x - rx, c.y - ry)
            val bounds = Size(rx * 2f, ry * 2f)
            val line = stroke.toPx()
            drawArc(SurfaceEdge, 205f, 130f, false, origin, bounds, style = Stroke(line, cap = StrokeCap.Round))
            if (progress > 0f) drawArc(accent, 205f, 130f * progress, false, origin, bounds,
                style = Stroke(line, cap = StrokeCap.Round))
            val a = (205.0 + 130.0 * progress) * PI / 180.0
            val sun = Offset(c.x + rx * cos(a).toFloat(), c.y + ry * sin(a).toFloat())
            drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.28f), Color.Transparent), sun, 22.dp.toPx()),
                22.dp.toPx(), sun)
            drawCircle(accentSoft, 5.dp.toPx(), sun)
            drawCircle(accentSoft.copy(alpha = 0.3f), 9.dp.toPx(), sun, style = Stroke(1.dp.toPx()))
        }
        content()
    }
}
