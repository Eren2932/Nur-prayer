package com.nur.prayer.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerWindow
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AtlasPanel
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.CountdownRing
import com.nur.prayer.ui.components.LocalBackdropPaused
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.solidTone
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime

/** Observatory: editorial countdown above a luminous interval horizon and daily agenda. */
@Composable
fun HomeScreen(
    data: PrayerData, now: State<ZonedDateTime>, palette: PhasePalette,
    onOpenCity: () -> Unit, modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val scroll = rememberScrollState()
    val backdropPaused = LocalBackdropPaused.current
    val scrolling = scroll.isScrollInProgress
    DisposableEffect(scrolling) {
        backdropPaused.value = scrolling
        onDispose { backdropPaused.value = false }
    }
    Column(modifier.fillMaxWidth().verticalScroll(scroll).padding(horizontal = ui.s(22f))) {
        Spacer(Modifier.height(ui.s(12f)))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable(role = Role.Button, onClickLabel = "Выбрать город", onClick = onOpenCity)
                .heightIn(min = 48.dp).padding(vertical = ui.s(4f))) {
                Text("Н У Р   /   نور", color = palette.accentSoft, fontSize = ui.t(9f), letterSpacing = ui.t(2f))
                AutoSizeText(data.place.label + "  ›", color = TextPrimary, fontSize = ui.t(21f),
                    minFontSize = ui.t(15f), fontWeight = FontWeight.Medium, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.width(ui.s(12f)))
            Column(Modifier.weight(0.75f), horizontalAlignment = Alignment.End) {
                AutoSizeText(data.hijri, color = TextSecondary, fontSize = ui.t(11.5f),
                    minFontSize = ui.t(9f), textAlign = TextAlign.End, maxLines = 2, modifier = Modifier.fillMaxWidth())
                Text(Format.dayMonth(data.today.date), color = TextTertiary, fontSize = ui.t(11f))
            }
        }
        Spacer(Modifier.height(ui.s(24f)))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(6.dp).background(palette.accent, androidx.compose.foundation.shape.CircleShape))
            Spacer(Modifier.width(8.dp))
            Text(palette.name.uppercase(), color = palette.accentSoft, fontSize = ui.t(10f), letterSpacing = ui.t(2f))
            Spacer(Modifier.weight(1f))
            Text("Время для главного", color = TextSecondary, fontSize = ui.t(11f))
        }
        Spacer(Modifier.height(ui.s(12f)))
        AtlasPanel(Modifier.fillMaxWidth(), corner = 32.dp, contentPadding = 0.dp, accent = palette.accent) {
            CountdownRing(
                startMillis = data.window.currentStart.toInstant().toEpochMilli(),
                endMillis = data.window.nextStart.toInstant().toEpochMilli(),
                now = now, accent = palette.accent, accentSoft = palette.accentSoft,
                modifier = Modifier.fillMaxWidth().height(if (ui.compact) 260.dp else 290.dp)
            ) {
                Column(Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(horizontal = ui.s(22f), vertical = ui.s(24f))) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("СЛЕДУЮЩЕЕ ВРЕМЯ", color = TextSecondary, fontSize = ui.t(9f), letterSpacing = ui.t(1.5f))
                            AutoSizeText(PrayerLabels.title(data.window.next), color = palette.accentSoft,
                                fontSize = ui.t(30f), minFontSize = ui.t(22f), fontWeight = FontWeight.Medium)
                        }
                        Text(PrayerLabels.arabic(data.window.next), color = palette.accentSoft.copy(alpha = 0.7f),
                            fontSize = ui.t(28f), modifier = Modifier.clearAndSetSemantics { })
                    }
                    Spacer(Modifier.height(ui.s(14f)))
                    CountdownReadout(data.window, now)
                    Text("осталось до начала · ${Format.time(data.window.nextStart)}", color = TextSecondary,
                        fontSize = ui.t(12f), modifier = Modifier.align(Alignment.CenterHorizontally))
                }
                Row(Modifier.fillMaxWidth().align(Alignment.BottomCenter).padding(horizontal = 24.dp, vertical = 14.dp)) {
                    Text(Format.time(data.window.currentStart), color = TextSecondary, fontSize = ui.t(10f))
                    Spacer(Modifier.weight(1f))
                    Text("ПУТЬ ВРЕМЕНИ", color = palette.accentSoft, fontSize = ui.t(8f), letterSpacing = ui.t(1.2f))
                    Spacer(Modifier.weight(1f))
                    Text(Format.time(data.window.nextStart), color = TextSecondary, fontSize = ui.t(10f))
                }
            }
        }
        Spacer(Modifier.height(ui.s(24f)))
        Row(Modifier.fillMaxWidth().padding(top = ui.s(2f), bottom = ui.s(12f)), verticalAlignment = Alignment.CenterVertically) {
            Text("СЕГОДНЯ", color = TextPrimary, fontSize = ui.t(11f), letterSpacing = ui.t(2f))
            Spacer(Modifier.weight(1f))
            Text("Сейчас · ${PrayerLabels.title(data.window.current)}", color = palette.accentSoft, fontSize = ui.t(11f))
        }
        AtlasPanel(Modifier.fillMaxWidth(), contentPadding = 0.dp, corner = ui.s(26f)) {
            Column {
                Prayer.entries.forEachIndexed { index, prayer ->
                    if (index > 0) Box(Modifier.fillMaxWidth().padding(horizontal = ui.s(16f)).height(1.dp).background(SurfaceEdge))
                    PrayerRow(prayer, data.today.times[prayer]?.let { Format.time(it) } ?: "—",
                        prayer == data.window.next, prayer == data.window.current,
                        data.settings.notifications[prayer] == true, palette.accent)
                }
            }
        }
        data.today.note?.let {
            Spacer(Modifier.height(ui.s(14f)))
            AtlasPanel(Modifier.fillMaxWidth(), contentPadding = ui.s(14f)) {
                Text(it, color = TextSecondary, fontSize = ui.t(12f), lineHeight = ui.t(18f))
            }
        }
        Spacer(Modifier.height(LocalDockInset.current))
    }
}

@Composable
private fun CountdownReadout(window: PrayerWindow, now: State<ZonedDateTime>) {
    val ui = uiScale()
    val text = Format.countdown(window.remaining(now.value))
    // Fixed geometry and monospaced numerals: no per-digit transitions, no size animation.
    AutoSizeText(text, color = TextPrimary, fontSize = ui.t(52f), minFontSize = ui.t(28f),
        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Light, textAlign = TextAlign.Center,
        resizeKey = text.length, modifier = Modifier.fillMaxWidth().clearAndSetSemantics {
            contentDescription = "До ${PrayerLabels.title(window.next)}: $text"
            // Not a live region: TalkBack must not interrupt the user every second.
        })
}

@Composable
private fun PrayerRow(prayer: Prayer, time: String, next: Boolean, current: Boolean, notify: Boolean, accent: Color) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().background(if (next) solidTone(accent, 0.18f) else Color.Transparent)
        .padding(horizontal = ui.s(16f), vertical = ui.s(13f)), verticalAlignment = Alignment.CenterVertically) {
        Text(if (next) "→" else (prayer.ordinal + 1).toString().padStart(2, '0'),
            color = if (next) accent else TextTertiary, fontSize = ui.t(11f),
            fontFamily = FontFamily.Monospace, modifier = Modifier.width(ui.s(30f)))
        Column(Modifier.weight(1f)) {
            Text(PrayerLabels.title(prayer), color = if (next) accent else TextPrimary,
                fontSize = ui.t(15f), fontWeight = if (next) FontWeight.SemiBold else FontWeight.Normal)
            Text(if (current) "Текущий период" else PrayerLabels.hint(prayer), color = TextTertiary, fontSize = ui.t(10f))
        }
        if (!ui.compact) Text(PrayerLabels.arabic(prayer), color = TextTertiary, fontSize = ui.t(13f),
            modifier = Modifier.padding(horizontal = ui.s(10f)).clearAndSetSemantics { })
        Column(horizontalAlignment = Alignment.End) {
            Text(time, color = if (next) accent else TextPrimary, fontSize = ui.t(19f), fontFamily = FontFamily.Monospace)
            if (prayer.isPrayer) Text(if (notify) "с уведомлением" else "без уведомления", color = TextTertiary, fontSize = ui.t(8f))
        }
    }
}
