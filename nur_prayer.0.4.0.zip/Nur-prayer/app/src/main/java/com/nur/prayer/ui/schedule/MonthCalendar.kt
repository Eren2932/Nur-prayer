package com.nur.prayer.ui.schedule

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.AtlasPanel
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate
import java.time.YearMonth

/** Calendar dates remain selectable while times load. No astronomical work inside composition. */
@Composable
fun MonthCalendar(
    month: YearMonth, selected: LocalDate, today: LocalDate, hijriOffset: Int,
    palette: PhasePalette, onMonth: (YearMonth) -> Unit, onSelect: (LocalDate) -> Unit,
    onToday: () -> Unit, modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val cells = remember(month) { CalendarMonthModel.cells(month) }
    val base = YearMonth.from(today)
    val min = base.minusMonths(12)
    val max = base.plusMonths(12)
    AtlasPanel(modifier.fillMaxWidth(), corner = 28.dp, contentPadding = ui.s(12f)) {
        Column {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { onMonth(month.minusMonths(1)) }, enabled = month > min,
                    modifier = Modifier.semantics { contentDescription = "Предыдущий месяц" }) {
                    Text("‹", fontSize = ui.t(26f), color = if (month > min) palette.accent else TextTertiary)
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    AutoSizeText(Format.monthYear(month.atDay(1)), color = TextPrimary, fontSize = ui.t(21f),
                        minFontSize = ui.t(14f), fontWeight = FontWeight.Medium, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().testTag("calendar-month"))
                    Text("ГРИГОРИАНСКИЙ / ХИДЖРА", color = TextTertiary, fontSize = ui.t(8f), letterSpacing = ui.t(1f))
                }
                TextButton(onClick = { onMonth(month.plusMonths(1)) }, enabled = month < max,
                    modifier = Modifier.semantics { contentDescription = "Следующий месяц" }) {
                    Text("›", fontSize = ui.t(26f), color = if (month < max) palette.accent else TextTertiary)
                }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс").forEachIndexed { i, label ->
                    Text(label, color = if (i == 4) palette.accentSoft else TextTertiary, fontSize = ui.t(10f),
                        textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                }
            }
            cells.chunked(7).forEach { week ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    week.forEach { date ->
                        val inMonth = YearMonth.from(date) == month
                        val active = date == selected
                        val isToday = date == today
                        val hijri = remember(date, hijriOffset) { HijriCalendar.dayOfMonth(date, hijriOffset) }
                        val label = remember(date, hijriOffset, isToday) {
                            "${Format.fullDate(date)}, ${HijriCalendar.format(date, hijriOffset)}" + if (isToday) ", сегодня" else ""
                        }
                        val shape = RoundedCornerShape(16.dp)
                        Column(Modifier.weight(1f).height(58.dp).clip(shape)
                            .background(if (active) palette.accent else Color.Transparent)
                            .border(1.dp, if (isToday && !active) palette.accent else Color.Transparent, shape)
                            .selectable(selected = active, enabled = inMonth, role = Role.Button, onClick = { onSelect(date) })
                            .semantics(mergeDescendants = true) { contentDescription = label }
                            .testTag("calendar-day-$date").padding(vertical = 5.dp),
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text(date.dayOfMonth.toString(), fontSize = ui.t(16f),
                                fontWeight = if (active || isToday) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (active) Ink else if (inMonth) TextPrimary else TextTertiary.copy(alpha = 0.45f))
                            Text(hijri.toString(), fontSize = ui.t(9f),
                                color = if (active) Ink.copy(alpha = 0.8f) else if (inMonth) TextSecondary else TextTertiary.copy(alpha = 0.4f))
                            if (date.dayOfWeek.value == 5 && inMonth) {
                                Box(Modifier.size(3.dp).background(if (active) Ink else palette.accent, CircleShape))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(3.dp))
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("• Пятница", color = palette.accentSoft, fontSize = ui.t(10f), modifier = Modifier.weight(1f))
                TextButton(onClick = onToday, modifier = Modifier.testTag("calendar-today")) {
                    Text("Сегодня", color = palette.accentSoft, fontSize = ui.t(12f))
                }
            }
        }
    }
}
