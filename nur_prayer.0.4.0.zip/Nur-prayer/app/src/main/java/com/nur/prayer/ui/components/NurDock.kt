package com.nur.prayer.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.solidTone
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.NavigationMotion
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

enum class DockIcon { PRAYER, CALENDAR, QIBLA, SETTINGS }
@Immutable
data class DockItem(val key: String, val label: String, val icon: DockIcon)

/** Floating observatory dock with a single draw-only sliding selection surface. */
@Composable
fun NurDock(items: List<DockItem>, selected: String, onSelect: (String) -> Unit, accent: Color, modifier: Modifier = Modifier) {
    if (items.isEmpty()) return
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val index = items.indexOfFirst { it.key == selected }.coerceAtLeast(0)
    val position = animateFloatAsState(index.toFloat(), tween(NavigationMotion.DOCK_MILLIS), label = "atlasIndex")
    Box(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).height(72.dp)
        .clip(RoundedCornerShape(26.dp)).background(SurfaceInset)
        .border(1.dp, SurfaceEdge.copy(alpha = 0.7f), RoundedCornerShape(26.dp)).selectableGroup()) {
        Canvas(Modifier.fillMaxSize()) {
            val slot = size.width / items.size
            val x = slot * (position.value + 0.5f)
            drawRoundRect(solidTone(accent, 0.18f), Offset(x - slot * 0.40f, 6.dp.toPx()),
                androidx.compose.ui.geometry.Size(slot * 0.80f, size.height - 12.dp.toPx()),
                androidx.compose.ui.geometry.CornerRadius(20.dp.toPx()))
        }
        Row(Modifier.fillMaxSize()) {
            items.forEach { item ->
                val active = item.key == selected
                val tint = if (active) accent else TextTertiary
                Column(Modifier.weight(1f).fillMaxHeight().selectable(selected = active, role = Role.Tab, onClick = {
                    if (!active) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSelect(item.key)
                    }
                }).padding(horizontal = 3.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center) {
                    Canvas(Modifier.size(22.dp)) { drawDockIcon(item.icon, tint, active) }
                    Spacer(Modifier.height(5.dp))
                    AutoSizeText(item.label, color = tint, fontSize = ui.t(10.5f), minFontSize = ui.t(8f),
                        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

private fun DrawScope.drawDockIcon(icon: DockIcon, color: Color, active: Boolean) {
    val s = size.minDimension
    val w = if (active) s * 0.10f else s * 0.085f
    val stroke = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(x * s, y * s)

    when (icon) {
        // A mihrab arch: the niche a prayer is directed at.
        DockIcon.PRAYER -> {
            val path = Path().apply {
                moveTo(0.16f * s, 0.92f * s)
                lineTo(0.16f * s, 0.46f * s)
                cubicTo(
                    0.16f * s, 0.14f * s,
                    0.84f * s, 0.14f * s,
                    0.84f * s, 0.46f * s
                )
                lineTo(0.84f * s, 0.92f * s)
            }
            drawPath(path, color = color, style = stroke)
            drawLine(
                color = color.copy(alpha = 0.75f),
                start = p(0.06f, 0.92f),
                end = p(0.94f, 0.92f),
                strokeWidth = w,
                cap = StrokeCap.Round
            )
            if (active) {
                drawCircle(color = color, radius = s * 0.075f, center = p(0.5f, 0.52f))
            }
        }
        // Calendar: plate, hangers, and a filled "today" cell.
        DockIcon.CALENDAR -> {
            drawRoundRect(
                color = color,
                topLeft = p(0.12f, 0.22f),
                size = androidx.compose.ui.geometry.Size(s * 0.76f, s * 0.68f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(s * 0.14f, s * 0.14f),
                style = stroke
            )
            drawLine(color, p(0.30f, 0.10f), p(0.30f, 0.28f), strokeWidth = w, cap = StrokeCap.Round)
            drawLine(color, p(0.70f, 0.10f), p(0.70f, 0.28f), strokeWidth = w, cap = StrokeCap.Round)
            drawLine(
                color.copy(alpha = 0.6f), p(0.12f, 0.44f), p(0.88f, 0.44f),
                strokeWidth = w * 0.8f
            )
            if (active) {
                drawRoundRect(
                    color = color,
                    topLeft = p(0.30f, 0.56f),
                    size = androidx.compose.ui.geometry.Size(s * 0.18f, s * 0.16f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(s * 0.05f, s * 0.05f)
                )
            }
        }
        // Compass rose with a needle pointing north-east.
        DockIcon.QIBLA -> {
            drawCircle(color = color, radius = s * 0.40f, center = p(0.5f, 0.5f), style = stroke)
            val needle = Path().apply {
                moveTo(0.70f * s, 0.30f * s)
                lineTo(0.44f * s, 0.44f * s)
                lineTo(0.30f * s, 0.70f * s)
                lineTo(0.56f * s, 0.56f * s)
                close()
            }
            if (active) drawPath(needle, color = color) else drawPath(needle, color = color, style = stroke)
        }
        // Faders: settings that are actually tuned, not a gear cliche.
        DockIcon.SETTINGS -> {
            val rows = floatArrayOf(0.28f, 0.5f, 0.72f)
            val knobs = floatArrayOf(0.68f, 0.36f, 0.58f)
            rows.forEachIndexed { i, y ->
                drawLine(
                    color = color.copy(alpha = 0.55f),
                    start = p(0.12f, y), end = p(0.88f, y),
                    strokeWidth = w * 0.85f, cap = StrokeCap.Round
                )
                val cx = knobs[i]
                if (active) {
                    drawCircle(color = color, radius = s * 0.105f, center = p(cx, y))
                } else {
                    drawCircle(color = color, radius = s * 0.10f, center = p(cx, y), style = Stroke(width = w * 0.9f))
                }
            }
        }
    }
}
