package com.nur.prayer.ui.theme

import androidx.compose.ui.graphics.Color
import com.nur.prayer.core.astro.Prayer

val Ink = Color(0xFF090E20)
val InkSoft = Color(0xFF141D34)
val Gold = Color(0xFFECC88D)
val GoldSoft = Color(0xFFFFE9C3)
val Mint = Color(0xFF7DE0CF)
val Violet = Color(0xFFC0ACFF)
val Azure = Color(0xFF8BCBFF)
val Amber = Color(0xFFF2A65A)
val Rose = Color(0xFFF07C8C)
val Crimson = Color(0xFFF08A93)

val TextPrimary = Color(0xFFF4F1EA)
val TextSecondary = Color(0xFFBEC8DE)
val TextTertiary = Color(0xFF98A7C3)

/**
 * The sky of the app. It is a real atmospheric stack, not two glowing circles:
 * zenith -> mid air -> horizon haze, an aurora built from two ribbon colours, and a star budget.
 * Every prayer phase re-paints all of it.
 */
@androidx.compose.runtime.Immutable
data class PhasePalette(
    /** Top of the sky, the darkest band. */
    val zenith: Color,
    /** Middle air. */
    val mid: Color,
    /** Horizon haze at the very bottom. */
    val horizon: Color,
    /** Wide, shallow atmospheric glow sitting on the horizon. */
    val glow: Color,
    val ribbonA: Color,
    val ribbonB: Color,
    val accent: Color,
    val accentSoft: Color,
    /** 0 = daylight, no stars; 1 = deep night. */
    val starIntensity: Float,
    /** How strong the aurora ribbons are, 0..1. */
    val auroraIntensity: Float,
    val name: String
)

fun paletteFor(prayer: Prayer): PhasePalette = when (prayer) {
    // Pre-dawn: deep indigo with the first violet lift on the horizon.
    Prayer.SAHAR, Prayer.FAJR -> PhasePalette(
        zenith = Color(0xFF04050F),
        mid = Color(0xFF0B0F2A),
        horizon = Color(0xFF241A45),
        glow = Color(0xFF7A5CE0),
        ribbonA = Color(0xFF6C5CE7),
        ribbonB = Color(0xFF3B7BD8),
        accent = Violet,
        accentSoft = Color(0xFFC9C1FF),
        starIntensity = 0.85f,
        auroraIntensity = 0.85f,
        name = "Рассвет"
    )
    // Sunrise: warm amber flooding the horizon, stars gone.
    Prayer.SUNRISE -> PhasePalette(
        zenith = Color(0xFF091634),
        mid = Color(0xFF1B2B52),
        horizon = Color(0xFF6B3A3C),
        glow = Color(0xFFF2A65A),
        ribbonA = Color(0xFFF2A65A),
        ribbonB = Color(0xFFEE7B93),
        accent = Amber,
        accentSoft = Color(0xFFFFD8A8),
        starIntensity = 0.18f,
        auroraIntensity = 0.35f,
        name = "Восход"
    )
    // Noon: clean high-altitude blue.
    Prayer.DHUHR -> PhasePalette(
        zenith = Color(0xFF061A3A),
        mid = Color(0xFF0E2E58),
        horizon = Color(0xFF1E5C86),
        glow = Color(0xFF6FC6FF),
        ribbonA = Color(0xFF8BCBFF),
        ribbonB = Color(0xFF7DE0CF),
        accent = Azure,
        accentSoft = Color(0xFFB6DCFF),
        starIntensity = 0f,
        auroraIntensity = 0.28f,
        name = "Полдень"
    )
    // Afternoon: the light turns golden and the air gets dusty.
    Prayer.ASR -> PhasePalette(
        zenith = Color(0xFF091830),
        mid = Color(0xFF16294A),
        horizon = Color(0xFF4A4363),
        glow = Color(0xFFECC88D),
        ribbonA = Color(0xFF7FB2F0),
        ribbonB = Color(0xFFECC88D),
        accent = Gold,
        accentSoft = GoldSoft,
        starIntensity = 0.05f,
        auroraIntensity = 0.32f,
        name = "Предвечерье"
    )
    // Sunset: crimson horizon under a night that is already arriving at the zenith.
    Prayer.MAGHRIB -> PhasePalette(
        zenith = Color(0xFF0A0A1E),
        mid = Color(0xFF251434),
        horizon = Color(0xFF6E2338),
        glow = Color(0xFFFF8A5C),
        ribbonA = Color(0xFFF08A93),
        ribbonB = Color(0xFFF2A65A),
        accent = Crimson,
        accentSoft = Color(0xFFFFC0A8),
        starIntensity = 0.55f,
        auroraIntensity = 0.7f,
        name = "Закат"
    )
    // Night: near-black with a cold teal aurora and a full star field.
    Prayer.ISHA -> PhasePalette(
        zenith = Color(0xFF02030A),
        mid = Color(0xFF070C1C),
        horizon = Color(0xFF10203A),
        glow = Color(0xFF2E6E7E),
        ribbonA = Color(0xFF3D4CB8),
        ribbonB = Color(0xFF1D8F8F),
        accent = Mint,
        accentSoft = Color(0xFFB9FFEA),
        starIntensity = 1f,
        auroraIntensity = 1f,
        name = "Ночь"
    )
}

// Observatory surfaces stay opaque for legibility; atmosphere lives in the spaces between them.
val SurfaceRaised = Color(0xFF202C46)
val SurfaceInset = Color(0xFF0C1429)
val SurfaceEdge = Color(0xFF364460)
val SystemBar = Ink
fun solidTone(accent: Color, amount: Float = 0.16f): Color =
    androidx.compose.ui.graphics.lerp(InkSoft, accent.copy(alpha = 1f), amount.coerceIn(0f, 1f))
