package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.nur.prayer.ui.theme.Gold

/** Hand-drawn local vector: black kiswah, gold belt, door and visible roof; no emoji / font dependency. */
@Composable
fun KaabaIcon(edge: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        if (s < 4f) return@Canvas
        fun polygon(vararg points: Float): Path = Path().apply {
            moveTo(points[0] * s, points[1] * s)
            for (i in 2 until points.size step 2) lineTo(points[i] * s, points[i + 1] * s)
            close()
        }
        val roof = polygon(0.12f, 0.24f, 0.62f, 0.08f, 0.90f, 0.23f, 0.40f, 0.41f)
        val left = polygon(0.12f, 0.24f, 0.40f, 0.41f, 0.40f, 0.94f, 0.12f, 0.74f)
        val front = polygon(0.40f, 0.41f, 0.90f, 0.23f, 0.90f, 0.76f, 0.40f, 0.94f)
        drawPath(roof, Color(0xFF46506A))
        drawPath(left, Color(0xFF111727))
        drawPath(front, Color(0xFF222B40))
        listOf(roof, left, front).forEach { drawPath(it, edge.copy(alpha = 0.7f), style = Stroke(s * 0.025f)) }
        drawPath(polygon(0.12f, 0.36f, 0.40f, 0.53f, 0.40f, 0.62f, 0.12f, 0.45f), Gold.copy(alpha = 0.75f))
        drawPath(polygon(0.40f, 0.53f, 0.90f, 0.35f, 0.90f, 0.44f, 0.40f, 0.62f), Gold)
        drawPath(polygon(0.72f, 0.59f, 0.82f, 0.55f, 0.82f, 0.79f, 0.72f, 0.83f), Gold)
    }
}
