package com.nur.prayer.ui.schedule

import androidx.compose.runtime.saveable.rememberSaveable
import com.nur.prayer.ui.theme.SurfaceEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.AtlasPanel
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.UiScale
import com.nur.prayer.ui.theme.uiScale
import java.time.Duration
import java.time.ZonedDateTime

import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.material3.TextButton
import androidx.compose.ui.platform.testTag
import com.nur.prayer.core.astro.PrayerEngine
import java.time.LocalDate
import java.time.YearMonth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Full month navigation; only the selected day and its following dawn need solar computation. */
@Composable
fun ScheduleScreen(data: PrayerData, now: State<ZonedDateTime>, palette: PhasePalette, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val today = data.today
    val hijriOffset = data.settings.hijriOffset
    var monthText by rememberSaveable(today.date.toEpochDay(), data.place.label) {
        mutableStateOf(YearMonth.from(today.date).toString())
    }
    var selectedEpoch by rememberSaveable(today.date.toEpochDay(), data.place.label) {
        mutableStateOf(today.date.toEpochDay())
    }
    val month = YearMonth.parse(monthText)
    val selectedDate = LocalDate.ofEpochDay(selectedEpoch)
    // State is keyed by the complete calculation identity: stale times cannot flash under a new city/date.
    var loaded by remember(selectedDate, data.place, data.params) { mutableStateOf<List<PrayerDay>?>(null) }
    var failed by remember(selectedDate, data.place, data.params) { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    LaunchedEffect(selectedDate, data.place, data.params, retry) {
        failed = false
        try {
            loaded = withContext(Dispatchers.Default) {
                PrayerEngine.days(selectedDate, 2, data.place.coordinates, data.place.zone, data.params)
            }
        } catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { failed = true }
    }
    val selected = loaded?.firstOrNull()
    val isToday = selectedDate == today.date
    val haptic = LocalHapticFeedback.current
    Column(modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(20f))) {
        Spacer(Modifier.height(16.dp))
        Text("РИТМ ДНЕЙ", color = palette.accentSoft, fontSize = ui.t(10f), letterSpacing = ui.t(2f))
        Row(Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Календарь", color = TextPrimary, fontSize = ui.t(30f), fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f))
            AutoSizeText(data.place.label, color = TextSecondary, fontSize = ui.t(12f), maxLines = 2,
                modifier = Modifier.weight(0.6f), textAlign = TextAlign.End)
        }
        MonthCalendar(month, selectedDate, today.date, hijriOffset, palette,
            onMonth = { target ->
                monthText = target.toString()
                selectedEpoch = CalendarMonthModel.moveSelection(selectedDate, target).toEpochDay()
            }, onSelect = { date ->
                if (date != selectedDate) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    selectedEpoch = date.toEpochDay()
                }
            }, onToday = {
                monthText = YearMonth.from(today.date).toString()
                selectedEpoch = today.date.toEpochDay()
            })
        Text("Малая цифра — день хиджры. Даты по Умм аль-Кура; местное наблюдение луны может отличаться.",
            color = TextTertiary, fontSize = ui.t(10f), lineHeight = ui.t(15f),
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 12.dp))
        AtlasPanel(Modifier.fillMaxWidth().testTag("calendar-detail"), contentPadding = ui.s(18f), corner = 28.dp,
            accent = palette.accent) {
            Column {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        AutoSizeText(Format.fullDate(selectedDate).replaceFirstChar { it.uppercase() },
                            color = TextPrimary, fontSize = ui.t(18f), minFontSize = ui.t(13f), fontWeight = FontWeight.Medium)
                        Text(HijriCalendar.format(selectedDate, hijriOffset), color = palette.accentSoft,
                            fontSize = ui.t(12f), modifier = Modifier.padding(top = 4.dp))
                    }
                    if (isToday) DayNote("сегодня", palette.accent, ui)
                }
                Spacer(Modifier.height(16.dp))
                when {
                    failed -> {
                        Text("Не удалось рассчитать этот день. Текущие настройки сохранены.", color = TextSecondary)
                        TextButton(onClick = { retry++ }) { Text("Повторить", color = palette.accentSoft) }
                    }
                    selected == null -> Text("Рассчитываем время…", color = TextSecondary,
                        modifier = Modifier.heightIn(min = 120.dp))
                    else -> {
                        DayTimeline(selected, if (isToday) now else null, palette.accent, ui)
                        Spacer(Modifier.height(14.dp))
                        // Seven named events in chronological rows, not a 3×3 grid with two empty slots.
                        Prayer.entries.forEach { prayer ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(5.dp).background(
                                    if (isToday && prayer == data.window.next) palette.accent else TextTertiary,
                                    CircleShape))
                                Spacer(Modifier.width(12.dp))
                                Text(PrayerLabels.title(prayer), color = TextSecondary, fontSize = ui.t(14f),
                                    modifier = Modifier.weight(1f))
                                Text(selected.times[prayer]?.let { Format.time(it) } ?: "—", color =
                                    if (isToday && prayer == data.window.next) palette.accentSoft else TextPrimary,
                                    fontSize = ui.t(21f), fontFamily = FontFamily.Monospace)
                            }
                        }
                        HairLine(ui)
                        val dayLength = daylight(selected)
                        SummaryRow("Световой день", Format.hoursMinutes(dayLength), ui)
                        if (!isToday) {
                            SummaryRow("Разница с сегодня", Format.signedMinutes(dayLength.toMinutes() - daylight(today).toMinutes()), ui)
                            SummaryRow("Фаджр сдвинулся", Format.signedMinutes(minuteShift(today, selected, Prayer.FAJR)), ui)
                            SummaryRow("Магриб сдвинулся", Format.signedMinutes(minuteShift(today, selected, Prayer.MAGHRIB)), ui)
                        }
                        SummaryRow("От Иша до Фаджра", Format.hoursMinutes(nightLength(loaded.orEmpty(), 0)), ui)
                        selected.note?.let {
                            Text(it, color = palette.accentSoft, fontSize = ui.t(11f), lineHeight = ui.t(16f),
                                modifier = Modifier.padding(top = 10.dp))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(LocalDockInset.current))
    }
}

/**
 * The day on an hour scale: 00:00 on the left, 24:00 on the right, night dark, daylight lit, six
 * markers where the prayers fall, and a live "now" needle on today. This is the compact, horizontal
 * reading of a day that a vertical list can never give.
 */
@Composable
private fun DayTimeline(
    day: PrayerDay,
    now: State<ZonedDateTime>?,
    accent: Color,
    ui: UiScale
) {
    val fajr = fraction(day, Prayer.FAJR)
    val sunrise = fraction(day, Prayer.SUNRISE)
    val maghrib = fraction(day, Prayer.MAGHRIB)
    val markers = Prayer.entries.mapNotNull { prayer ->
        day.times[prayer]?.let { prayer to fraction(day, prayer) }
    }

    Column {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(ui.s(34f))
        ) {
            if (size.width < 8f || size.height < 4f) return@Canvas
            val h = size.height
            val barTop = h * 0.30f
            val barHeight = h * 0.36f
            val corner = barHeight / 2f

            // Night bed.
            drawRoundRect(
                color = Color.White.copy(alpha = 0.06f),
                topLeft = Offset(0f, barTop),
                size = androidx.compose.ui.geometry.Size(size.width, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(corner, corner)
            )
            // Twilight (fajr -> sunrise) and daylight (sunrise -> maghrib).
            fun band(from: Float, to: Float, brush: Brush) {
                if (to <= from) return
                drawRoundRect(
                    brush = brush,
                    topLeft = Offset(size.width * from, barTop),
                    size = androidx.compose.ui.geometry.Size(size.width * (to - from), barHeight),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(corner, corner)
                )
            }
            band(
                fajr, sunrise,
                Brush.horizontalGradient(
                    listOf(accent.copy(alpha = 0.18f), accent.copy(alpha = 0.34f))
                )
            )
            band(
                sunrise, maghrib,
                Brush.horizontalGradient(
                    listOf(
                        accent.copy(alpha = 0.45f),
                        accent.copy(alpha = 0.75f),
                        accent.copy(alpha = 0.45f)
                    )
                )
            )

            // Hour grid every three hours.
            for (i in 1 until 8) {
                val x = size.width * (i / 8f)
                drawLine(
                    color = Color.White.copy(alpha = 0.09f),
                    start = Offset(x, barTop),
                    end = Offset(x, barTop + barHeight),
                    strokeWidth = 1f * density
                )
            }

            // Prayer markers.
            markers.forEach { (_, f) ->
                val x = size.width * f
                drawLine(
                    color = Color.White.copy(alpha = 0.85f),
                    start = Offset(x, barTop - h * 0.16f),
                    end = Offset(x, barTop + barHeight + h * 0.16f),
                    strokeWidth = 1.6f * density,
                    cap = StrokeCap.Round
                )
            }

            // Now.
            // The state is read *here*, inside the draw scope. Compose then re-runs this lambda and
            // nothing else — no recomposition, no relayout.
            val moment = now?.value
            if (moment != null) {
                val secondOfDay = moment.hour * 3600 + moment.minute * 60 + moment.second
                val nowFraction = (secondOfDay / 86400f).coerceIn(0f, 1f)
                val x = size.width * nowFraction
                drawLine(
                    color = accent,
                    start = Offset(x, 0f),
                    end = Offset(x, h),
                    strokeWidth = 2.2f * density,
                    cap = StrokeCap.Round
                )
                drawCircle(color = accent, radius = 3f * density, center = Offset(x, h * 0.06f))
            }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            listOf("00", "06", "12", "18", "24").forEachIndexed { index, label ->
                Text(
                    text = label,
                    color = TextTertiary,
                    fontSize = ui.t(8.5f),
                    textAlign = when (index) {
                        0 -> TextAlign.Start
                        4 -> TextAlign.End
                        else -> TextAlign.Center
                    },
                    modifier = Modifier.weight(if (index == 0 || index == 4) 0.5f else 1f)
                )
            }
        }
    }
}

@Composable
private fun DayNote(text: String, color: Color, ui: UiScale) {
    AutoSizeText(
        text = text,
        color = color.copy(alpha = 0.92f),
        fontSize = ui.t(11f),
        minFontSize = ui.t(9f),
        fontWeight = FontWeight.Medium,
        letterSpacing = ui.t(0.4f),
        resizeKey = text.length
    )
}

@Composable
private fun SummaryRow(label: String, value: String, ui: UiScale) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(4f)),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AutoSizeText(
            text = label,
            color = TextTertiary,
            fontSize = ui.t(11.5f),
            minFontSize = ui.t(9f),
            maxLines = 2,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(ui.s(10f)))
        AutoSizeText(
            text = value,
            color = TextPrimary,
            fontSize = ui.t(12.5f),
            minFontSize = ui.t(10f),
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun HairLine(ui: UiScale) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(8f))
            .height(1.dp)
            .background(SurfaceEdge)
    )
}

/* ------------------------------------------------------------------------------------------------
 * Small calculations
 * ---------------------------------------------------------------------------------------------- */

/** Where a prayer falls inside its own local day, 0..1. */
private fun fraction(day: PrayerDay, prayer: Prayer): Float {
    val time = day.times[prayer] ?: return 0f
    val local = time.toLocalTime()
    val seconds = local.hour * 3600 + local.minute * 60 + local.second
    // A prayer pushed past midnight (short northern nights) belongs to the far right edge.
    val rolled = if (time.toLocalDate().isAfter(day.date)) 86400 else seconds
    return (rolled / 86400f).coerceIn(0f, 1f)
}

private fun daylight(day: PrayerDay): Duration {
    val sunrise = day.times[Prayer.SUNRISE]
    val maghrib = day.times[Prayer.MAGHRIB]
    if (sunrise == null || maghrib == null) return Duration.ZERO
    return Duration.between(sunrise, maghrib)
}

/** How many minutes a prayer moved between two days. */
private fun minuteShift(from: PrayerDay, to: PrayerDay, prayer: Prayer): Long {
    val a = from.times[prayer] ?: return 0
    val b = to.times[prayer] ?: return 0
    val aMinutes = a.toLocalTime().toSecondOfDay() / 60L
    val bMinutes = b.toLocalTime().toSecondOfDay() / 60L
    return bMinutes - aMinutes
}

/** Isha of the selected day to Fajr of the following one — the real night, across midnight. */
private fun nightLength(days: List<PrayerDay>, index: Int): Duration {
    val current = days.getOrNull(index) ?: return Duration.ZERO
    val isha = current.times[Prayer.ISHA] ?: return Duration.ZERO
    val nextFajr = days.getOrNull(index + 1)?.times?.get(Prayer.FAJR)
        ?: return Duration.ZERO
    val length = Duration.between(isha, nextFajr)
    return if (length.isNegative) Duration.ZERO else length
}
