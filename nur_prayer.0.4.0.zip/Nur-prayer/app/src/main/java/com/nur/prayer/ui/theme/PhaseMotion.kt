package com.nur.prayer.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color

/** Only a phase change animates this value; there is no per-second root recomposition. */
@Composable
fun animatedPhasePalette(target: PhasePalette): PhasePalette {
    val stars by animateFloatAsState(target.starIntensity, tween(1600), label = "skyStars")
    val aurora by animateFloatAsState(target.auroraIntensity, tween(1600), label = "skyAurora")
    return target.copy(
        zenith = phaseTone(target.zenith, "skyZenith"), mid = phaseTone(target.mid, "skyMid"),
        horizon = phaseTone(target.horizon, "skyHorizon"), glow = phaseTone(target.glow, "skyGlow"),
        ribbonA = phaseTone(target.ribbonA, "skyRibbonA"), ribbonB = phaseTone(target.ribbonB, "skyRibbonB"),
        accent = phaseTone(target.accent, "skyAccent"), accentSoft = phaseTone(target.accentSoft, "skyAccentSoft"),
        starIntensity = stars, auroraIntensity = aurora)
}

@Composable
private fun phaseTone(color: Color, label: String): Color =
    animateColorAsState(color, tween(1600), label = label).value
