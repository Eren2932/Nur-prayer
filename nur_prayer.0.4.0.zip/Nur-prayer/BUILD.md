# Сборка и проверка Нур 0.4.0

Нужны JDK 17, Gradle 8.9, Android SDK Platform 34 / Build Tools 34.0.0 и Python 3.10+.
Версии Kotlin 2.0.20, AGP 8.5.2 и Compose BOM 2024.09.00 сохранены. Новых зависимостей нет.
В архиве, как и в 0.3.3, **нет полного Gradle Wrapper**. Используйте установленный `gradle`,
а не `./gradlew`. В настроенной среде можно выполнить `gradle wrapper --gradle-version 8.9`.
Для первого скачивания зависимостей необходим доступ к Google Maven, Maven Central и Gradle.

## Проверки без Android

Из корня распакованного проекта:

````bash
python3 tools/check_compose_actions.py
python3 tools/test_compose_actions.py
python3 tools/kt_sanity.py
python3 tools/kt_symbols.py
python3 tools/source_audit.py
python3 tools/test_source_archive.py
python3 tools/test_kt_symbols.py
python3 tools/verify_cities.py
python3 tools/verify_uz_table.py
python3 tools/test_build_regressions.py
````

Эти десять команд выполнены при подготовке архива. Они НЕ компилируют Kotlin.
Логи: `docs/qa-0.4.0/`. Изменение source_audit с запрета любой анимации на проверку
ограниченной живой атмосферы — намеренная смена требования; protected-baseline не изменён.

## Сборка и настоящие тесты

````bash
gradle --no-daemon :app:compileDebugKotlin :app:compileReleaseKotlin :app:compileDebugUnitTestKotlin :app:compileDebugAndroidTestKotlin --stacktrace
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleRelease :app:assembleDebugAndroidTest --stacktrace
# С подключённым эмулятором или Android-устройством:
gradle :app:connectedDebugAndroidTest
````

В исходниках 134 JVM-теста (добавлено 8 для модели месяца) и 19 UI-тестов
(добавлено 9 для календаря, таймера и безопасных состояний компаса).
Эти тесты **не запускались в the Computer**. Компиляция APK для тестов не равна запуску тестов.

Существующий `.github/workflows/build.yml` сначала компилирует приложение и оба вида тестов,
затем выполняет JVM-тесты, lint, собирает APK и запускает instrumentation на API 26 / 34.
Сам workflow не менялся. Успешность нового run в GitHub пока неизвестна.

## Посмотреть интерфейс до установки

Выберите debug variant в Android Studio и откройте
`app/src/debug/java/com/nur/prayer/preview/ObservatoryPreviews.kt`.
Preview вызывает настоящие компоненты с фиксированной датой и тестовым показанием датчика.
Рендер Preview здесь не выполнялся; для интерактивных сценариев запускайте приложение.

## Установка и подпись

Debug: `app/build/outputs/apk/debug/app-debug.apk`.
Release: `app/build/outputs/apk/release/app-release.apk`.
Release в проекте подписывается debug-ключом, как и раньше, исключительно для тестовой установки.
Для публикации нужен собственный постоянный release-ключ. Не удаляйте установленное приложение
ради конфликта подписей без резервной копии: удаление уничтожит его локальные настройки.

Перед релизом пройдите `docs/DEVICE-CHECK-0.4.0.md`. Ни отсутствие ошибок в Python,
ни сохранность расчётного ядра не гарантируют отсутствие визуальных регрессий.
