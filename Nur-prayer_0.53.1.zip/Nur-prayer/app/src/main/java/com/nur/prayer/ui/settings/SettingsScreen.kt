package com.nur.prayer.ui.settings

import com.nur.prayer.ui.wallpaper.WallpaperCatalog
import com.nur.prayer.ui.wallpaper.WallpaperRow
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.RegionalProfiles
import com.nur.prayer.data.HomeLayout
import com.nur.prayer.data.PlaceProfiles
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.core.astro.TimeSource
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.i18n.trDynamic
import com.nur.prayer.icon.AppIconSwitcher
import com.nur.prayer.icon.title
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.NavigationMotion
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.MenuIcon
import com.nur.prayer.ui.components.MenuGlass
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.ScreenHeader
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale

/** Index and editors are transparent: NurRoot owns the continuous settings wallpaper. */
@Composable
fun SettingsScreen(
    data: PrayerData,
    palette: PhasePalette,
    actions: AppActions,
    exactAlarmsAllowed: Boolean,
    locating: Boolean = false,
    locationStatus: String? = null,
    notificationsAllowed: Boolean = true,
    modifier: Modifier = Modifier,
    locationButtonLabel: String = "",
    onBack: (() -> Unit)? = null,
    onOpenWallpapers: () -> Unit = {}
) {
    val ui = uiScale()
    val dockInset = LocalDockInset.current
    val settings = data.settings
    val accent = EditorStyle.Paper
    val effectiveMethod = data.params.method
    // The launcher alias lives in PackageManager, not in DataStore: read once, then follow the taps.
    val context = LocalContext.current
    var appIcon by remember { mutableStateOf(AppIconSwitcher.selected(context)) }

    // Survives rotation and process death, so coming back to the app does not silently collapse the
    // editor the user was working in.
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    val pages = rememberSaveableStateHolder()
    BackHandler(enabled = open != null) { open = settingsParent(open) }

    val methodTitle = trDynamic(effectiveMethod.title)
    val specs = buildList {
        add(SettingsTile("language", tr("Язык"), L10n.language.nativeName, MenuIcon.GLOBE) {
            LanguagePicker()
        })
        run {
            // 0.18.6: the automatic profile follows the region where it has its own muftiate (Казань → ДУМ РТ).
            val placeDefault = PlaceProfiles.forPlace(data.place.country, data.place.region)
            val byRegion = placeDefault != RegionalProfiles.forCountry(data.place.country)
            add(SettingsTile(
                id = "method",
                title = tr("Метод расчёта"),
                value = when (effectiveMethod) {
                    CalculationMethod.SPIRITUAL_BOARD_TATARSTAN -> tr("ДУМ РТ")
                    CalculationMethod.RUSSIA_DUM -> tr("ДУМ РФ")
                    else -> methodTitle
                },
                icon = MenuIcon.SETTINGS
            ) {
                EditorRule()
                EditorChoice(
                    title = tr("Автоматически"),
                    subtitle = "${if (byRegion) data.place.region else trDynamic(data.place.country)} → ${trDynamic(placeDefault.method.title)}",
                    selected = settings.methodIsAutomatic,
                    onClick = { actions.setMethod(null) }
                )
                /*
                 * Only the methods that mean something here, plus whatever the user has already
                 * chosen by hand — a selected row must never disappear from the list it lives in.
                 */
                val methods = remember(data.place.country, data.place.region, effectiveMethod, settings.methodIsAutomatic) {
                    val offered = PlaceProfiles.methodsFor(data.place.country, data.place.region)
                    if (settings.methodIsAutomatic || effectiveMethod in offered) offered else offered + effectiveMethod
                }
                methods.forEach { method ->
                    EditorRule()
                    EditorChoice(
                        title = trDynamic(method.title),
                        subtitle = subtitleFor(method),
                        selected = !settings.methodIsAutomatic && effectiveMethod == method,
                        onClick = { actions.setMethod(method) }
                    )
                }
            })
        }
        add(SettingsTile(
            id = "madhab",
            title = tr("Мазхаб · время Асра"),
            value = if (settings.madhab == Madhab.HANAFI) tr("Ханафитский") else tr("Шафиитский"),
            icon = MenuIcon.MOON
        ) {
            EditorSegments(
                options = listOf(tr("Ханафитский"), tr("Шафиитский")),
                selectedIndex = if (settings.madhab == Madhab.HANAFI) 0 else 1,
                onSelect = { index -> actions.setMadhab(if (index == 0) Madhab.HANAFI else Madhab.STANDARD) }
            )
            Spacer(Modifier.height(ui.s(10f)))
            EditorNote(tr("Ханафитский Аср позже: тень — две высоты предмета, а не одна"))
        })
        run {
            val on = Prayer.entries.count { it.isPrayer && settings.notifications[it] == true }
            val total = Prayer.entries.count { it.isPrayer }
            val base = if (settings.preAlertMinutes > 0) tr("{0} из {1} · за {2} мин", on, total, settings.preAlertMinutes)
                else tr("{0} из {1}", on, total)
            add(SettingsTile(
                id = "notify",
                title = tr("Уведомления"),
                value = when {
                    !notificationsAllowed -> tr("Выключены в Android")
                    !exactAlarmsAllowed -> tr("{0} · нет точных будильников", base)
                    else -> base
                },
                icon = MenuIcon.BELL
            ) {
                if (!notificationsAllowed) {
                    WarningBlock(
                        text = tr("Уведомления запрещены в Android — разрешите их в системе"),
                        actionText = tr("Открыть настройки уведомлений"),
                        onClick = actions.openNotificationSettings
                    )
                    Spacer(Modifier.height(ui.s(12f)))
                }
                if (!exactAlarmsAllowed) {
                    WarningBlock(
                        text = tr("Без точных будильников уведомление может опоздать на пару минут"),
                        actionText = tr("Разрешить точные будильники"),
                        onClick = { actions.openExactAlarmSettings() }
                    )
                    Spacer(Modifier.height(ui.s(12f)))
                }
                Prayer.entries.filter { it.isPrayer }.forEach { prayer ->
                    EditorRule()
                    EditorToggle(
                        title = PrayerLabels.title(prayer),
                        checked = settings.notifications[prayer] == true,
                        onChange = { actions.setNotification(prayer, it) }
                    )
                }
                EditorRule()
                EditorStepper(
                    label = tr("Напомнить заранее"),
                    value = tr("{0} мин", settings.preAlertMinutes),
                    minusEnabled = settings.preAlertMinutes > 0, plusEnabled = settings.preAlertMinutes < 60,
                    onMinus = { actions.setPreAlert(settings.preAlertMinutes - 5) },
                    onPlus = { actions.setPreAlert(settings.preAlertMinutes + 5) }
                )
                Spacer(Modifier.height(ui.s(10f)))
                NurButton(text = tr("Отключить экономию батареи для Nur"), accent = accent, onClick = { actions.openBatterySettings() })
            })
        }
        add(SettingsTile(
            id = "azan",
            title = tr("Звук азана"),
            value = trDynamic(settings.azanSound.title),
            icon = MenuIcon.SOUND
        ) {
            AzanEditor(settings.azanSound, actions.setAzanSound)
        })
        add(SettingsTile(
            id = "highlat",
            title = tr("Высокие широты"),
            value = ruleTitle(settings.highLatitudeRule),
            icon = MenuIcon.SUN
        ) {
            HighLatitudeRule.entries.forEach { rule ->
                EditorRule()
                EditorChoice(
                    title = ruleTitle(rule),
                    subtitle = ruleSubtitle(rule),
                    selected = settings.highLatitudeRule == rule,
                    onClick = { actions.setHighLatitudeRule(rule) }
                )
            }
        })
        add(SettingsTile(
            id = "rounding",
            title = tr("Округление секунд"),
            value = trDynamic(settings.rounding.title),
            icon = MenuIcon.CLOCK
        ) {
            EditorSegments(
                options = listOf(tr("Ближайшая"), tr("Вверх"), tr("Вниз")),
                selectedIndex = RoundingMode.entries.indexOf(settings.rounding),
                onSelect = { index -> actions.setRounding(RoundingMode.entries[index]) }
            )
            Spacer(Modifier.height(ui.s(10f)))
            EditorNote(trDynamic(settings.rounding.explanation))
        })
        run {
            val edited = Prayer.entries.filter { (settings.offsets[it] ?: 0) != 0 }
            add(SettingsTile(
                id = "offsets",
                title = tr("Ручная коррекция"),
                value = when {
                    edited.isEmpty() && settings.hijriOffset == 0 -> tr("без правок")
                    edited.isEmpty() -> tr("хиджра {0} дн.", signed(settings.hijriOffset))
                    else -> edited.joinToString(", ") { "${PrayerLabels.title(it)} ${signed(settings.offsets[it] ?: 0)}" }
                },
                icon = MenuIcon.SLIDERS
            ) {
                Prayer.entries.forEach { prayer ->
                    EditorRule()
                    val value = settings.offsets[prayer] ?: 0
                    EditorStepper(
                        label = PrayerLabels.title(prayer),
                        value = tr("{0} мин", signed(value)),
                        minusEnabled = value > -60, plusEnabled = value < 60,
                        onMinus = { actions.setOffset(prayer, value - 1) },
                        onPlus = { actions.setOffset(prayer, value + 1) }
                    )
                }
                EditorRule()
                EditorStepper(
                    label = tr("Сдвиг даты по хиджре"),
                    value = tr("{0} дн.", signed(settings.hijriOffset)),
                    minusEnabled = settings.hijriOffset > -2, plusEnabled = settings.hijriOffset < 2,
                    onMinus = { actions.setHijriOffset(settings.hijriOffset - 1) },
                    onPlus = { actions.setHijriOffset(settings.hijriOffset + 1) }
                )
            })
        }
        val wallpaper = WallpaperCatalog.resolve(settings.wallpaperId, settings.skyBackdrop)
        add(SettingsTile(
            id = "display",
            title = tr("Оформление"),
            value = "${wallpaper.title()} · ${appIcon.title()}",
            icon = MenuIcon.SPARKLE
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = ui.s(EditorStyle.SIDE))) {
                EditorLabel(tr("Главный экран"))
                Spacer(Modifier.height(ui.s(6f)))
                EditorSegments(listOf(tr("Таймер"), tr("Крупный намаз")), settings.homeLayout.ordinal) {
                    actions.setHomeLayout(HomeLayout.entries[it])
                }
                Spacer(Modifier.height(ui.s(3f)))
                EditorNote(if (settings.homeLayout == HomeLayout.CARDS) tr("Таймер и ближайшие намазы")
                    else tr("Название следующего намаза крупно и шкала дня"))
            }
            Spacer(Modifier.height(ui.s(24f)))
            WallpaperRow(wallpaper, settings.recentWallpapers, palette,
                onPick = { actions.setWallpaper(it.id) }, onOpenAll = onOpenWallpapers)
            Spacer(Modifier.height(ui.s(28f)))
            AppIconPicker(appIcon) { icon ->
                AppIconSwitcher.select(context, icon)
                appIcon = icon
            }
        })
        add(SettingsTile(
            id = "about",
            title = tr("О расчёте"),
            value = "${trDynamic(effectiveMethod.angleSummary)} · ${data.place.zone.id}",
            icon = MenuIcon.INFO
        ) {
            EditorFact(tr("Страна профиля"), data.place.country)
            EditorFact(tr("Метод"), methodTitle)
            EditorFact(tr("Углы метода"), trDynamic(effectiveMethod.angleSummary))
            EditorFact(tr("Сверка"), trDynamic(data.profile.calibration.label))
            EditorFact(tr("Координаты"), format(data.place.coordinates.latitude) + ", " + format(data.place.coordinates.longitude))
            EditorFact(tr("Часовой пояс"), data.place.zone.id)
            EditorFact(tr("Пояс определён"), zoneSourceLabel(data.place.zoneSource))
            data.place.accuracyMeters?.let { EditorFact(tr("Точность точки"), tr("±{0} м", it.toInt())) }
            if (data.place.fromDeviceLocation) {
                settings.locationAddress?.let { EditorFact(tr("Адрес точки"), it) }
                settings.locationPostalCode?.let { EditorFact(tr("Почтовый индекс"), it) }
            }
            EditorFact(tr("Азимут кыблы"), "${Math.round(data.qibla)}°")
            EditorFact(tr("Сухур сегодня"), sourceLabel(data.today.saharSource))
            EditorFact(tr("Фаджр сегодня"), sourceLabel(data.today.fajrSource))
            EditorFact(tr("Иша сегодня"), sourceLabel(data.today.ishaSource))
            EditorRule()
            EditorNote(trDynamic(data.profile.note))
            data.place.zoneExplanation.takeIf { it.isNotEmpty() }?.let {
                EditorRule()
                EditorNote(trDynamic(it))
            }
            data.today.note?.let {
                EditorRule()
                EditorNote(trDynamic(it))
            }
        })
    }

    AnimatedContent(targetState = open ?: "index", transitionSpec = {
        val opening = settingsDepth(targetState) > settingsDepth(initialState)
        val move = tween<IntOffset>(NavigationMotion.EDITOR_ENTER_MILLIS, easing = FastOutSlowInEasing)
        val fadeInSpec = tween<Float>(NavigationMotion.TAB_ENTER_MILLIS, delayMillis = 40, easing = LinearOutSlowInEasing)
        val fadeOutSpec = tween<Float>(NavigationMotion.EXIT_MILLIS / 2 + 30, easing = FastOutLinearInEasing)
        val enter = slideInHorizontally(move) { w -> if (opening) w / 6 else -w / 12 } + fadeIn(fadeInSpec)
        val exit = slideOutHorizontally(move) { w -> if (opening) -w / 12 else w / 6 } + fadeOut(fadeOutSpec)
        (enter togetherWith exit).apply { targetContentZIndex = if (opening) 1f else -1f }.using(null)
    }, label = "settingsEditor", modifier = modifier.fillMaxSize()) { page ->
        pages.SaveableStateProvider(page) {
            val spec = specs.firstOrNull { it.id == page }
            // A tablet or a landscape phone keeps a phone-like column in the middle instead of stretched cards.
            val side = ui.s(EditorStyle.SIDE)
            val listInset = if (spec == null) ui.s(24f) else 0.dp
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxHeight()
                        .widthIn(max = MenuGlass.MaxWidth)
                        .fillMaxWidth()
                        .testTag("settings-$page"),
                    contentPadding = PaddingValues(
                        start = listInset, end = listInset, top = ui.s(if (page == "index") 18f else 28f), bottom = dockInset
                    ),
                    verticalArrangement = Arrangement.spacedBy(ui.s(if (spec == null) 0f else 28f))
                ) {
                    if (spec != null) {
                        item(key = "heading") {
                            ScreenHeader(
                                title = spec.title,
                                onBack = null,
                                modifier = Modifier.padding(horizontal = side)
                            )
                        }
                        item(key = "editor-${spec.id}") {
                            val choices = spec.id == "method" || spec.id == "highlat" || spec.id == "language"
                            Column(Modifier.fillMaxWidth().padding(horizontal = if (spec.id == "display") 0.dp else side)
                                .then(if (choices) Modifier.selectableGroup() else Modifier), content = spec.content)
                        }
                    } else if (page == PRECISION_PAGE) {
                        item(key = "heading") { IndexTitle(tr("Точность и коррекция"), large = false) }
                        precisionEditors.forEach { id ->
                            val tile = specs.first { it.id == id }
                            item(key = id, contentType = "link") { IndexLink(tile.icon, tile.title, tile.value, id) { open = id } }
                        }
                    } else {
                        settingsIndex(specs, data, notificationsAllowed, exactAlarmsAllowed, locationStatus,
                            actions.openCityPicker, onOpen = { open = it })
                    }
                }
            }
        }
    }
}

internal const val APP_VERSION = "0.53.1"
internal fun settingsVersionLabel() = tr("Нур {0}", APP_VERSION)

internal class SettingsTile(
    val id: String,
    val title: String,
    val value: String,
    val icon: MenuIcon,
    val content: @Composable ColumnScope.() -> Unit
)

/* ------------------------------------------------------------------------------------------------
 * Local pieces
 * ---------------------------------------------------------------------------------------------- */

/** A signed number states a direction, so the plus sign is never dropped. */
private fun signed(value: Int): String = if (value > 0) "+$value" else "$value"

private fun format(value: Double): String = String.format(java.util.Locale.US, "%.4f", value)

@Composable
private fun WarningBlock(text: String, actionText: String, onClick: () -> Unit) {
    val ui = uiScale()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(ui.s(14f)))
            .background(Crimson.copy(alpha = 0.10f))
            .padding(ui.s(13f))
    ) {
        Text(text = text, color = TextSecondary, fontSize = ui.t(12f), lineHeight = ui.t(16.5f))
        Spacer(Modifier.height(ui.s(11f)))
        NurButton(text = actionText, accent = Crimson, onClick = onClick, primary = true)
    }
}

private fun subtitleFor(method: CalculationMethod): String {
    val hint = when (method) {
        CalculationMethod.RUSSIA_DUM -> tr("Россия и Беларусь")
        CalculationMethod.SPIRITUAL_BOARD_TATARSTAN -> tr("Татарстан, календарь ДУМ РТ")
        CalculationMethod.UZBEKISTAN_BOARD -> tr("Узбекистан, сверено с namozvaqti.uz")
        CalculationMethod.UMM_AL_QURA -> tr("Саудовская Аравия")
        CalculationMethod.TURKEY -> tr("С поправками Diyanet")
        CalculationMethod.TEHRAN -> tr("Иран, Магриб по углу")
        else -> null
    }
    val angles = trDynamic(method.angleSummary)
    return if (hint == null) angles else "$hint · $angles"
}

private fun ruleTitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> tr("Автоматически")
    HighLatitudeRule.FIXED_INTERVAL -> tr("Фиксированный интервал (ДУМ РФ)")
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> tr("Середина ночи")
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> tr("Одна седьмая ночи")
    HighLatitudeRule.TWILIGHT_ANGLE -> tr("Пропорция по углу сумерек")
}

private fun ruleSubtitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> tr("Выше 48° широты — фиксированный интервал, иначе середина ночи")
    HighLatitudeRule.FIXED_INTERVAL -> tr("Восход − 120 мин и закат + 90 мин, как печатает ДУМ РТ")
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> tr("Фаджр и Иша не переходят середину ночи")
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> tr("Классическая доля ночи 1/7")
    HighLatitudeRule.TWILIGHT_ANGLE -> tr("Доля ночи пропорциональна углу метода")
}

/** Which piece of evidence decided the time zone. */
private fun zoneSourceLabel(source: com.nur.prayer.location.ZoneSource): String = when (source) {
    com.nur.prayer.location.ZoneSource.DEVICE -> tr("по часам телефона")
    com.nur.prayer.location.ZoneSource.NEIGHBOURHOOD -> tr("по городам рядом")
    com.nur.prayer.location.ZoneSource.LONGITUDE -> tr("по долготе (приближённо)")
}

/** Exhaustive on purpose: a new [TimeSource] must fail to compile here, not fall behind silently. */
private fun sourceLabel(source: TimeSource): String = when (source) {
    TimeSource.ANGLE -> tr("по углу солнца")
    TimeSource.PRINTED_TABLE -> tr("из печатной таблицы муфтията")
    TimeSource.METHOD_INTERVAL -> tr("интервал метода")
    TimeSource.FIXED_INTERVAL -> tr("фикс. интервал (короткая ночь)")
    TimeSource.NIGHT_FRACTION -> tr("доля ночи (короткая ночь)")
    TimeSource.MIDNIGHT_BOUND -> tr("ограничено серединой ночи")
    TimeSource.CONGREGATION -> tr("как в мечети: восход − 90 мин")
    TimeSource.DAWN_BOUND -> tr("поднято до рассвета")
}
