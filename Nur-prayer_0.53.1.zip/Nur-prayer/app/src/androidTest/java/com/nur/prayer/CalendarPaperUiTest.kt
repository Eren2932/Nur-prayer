package com.nur.prayer

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.activity.result.ActivityResultRegistry
import androidx.activity.result.ActivityResultRegistryOwner
import androidx.activity.result.contract.ActivityResultContract
import androidx.core.app.ActivityOptionsCompat
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.getUnclippedBoundsInRoot
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.click
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeLeft
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.schedule.CalendarImageShare
import com.nur.prayer.ui.schedule.MonthTimes
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.schedule.calendarPage
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.time.YearMonth
import java.time.ZonedDateTime

@RunWith(AndroidJUnit4::class)
class CalendarPaperUiTest {
    @get:Rule val compose = createComposeRule()
    private val moment = ZonedDateTime.parse("2026-11-28T13:00:00+03:00[Europe/Moscow]")
    private fun fixture(): PrayerData {
        val c = City.MOSCOW
        val settings = AppSettings()
        val params = settings.paramsFor(c.country)
        val place = Place(c.name, c.subtitle, c.country, c.coordinates, c.zone, false)
        return PrayerData(place, PrayerEngine.days(moment.toLocalDate(), 3, c.coordinates, c.zone, params),
            PrayerEngine.window(moment, c.coordinates, c.zone, params), qiblaBearing(c.coordinates),
            distanceToKaabaKm(c.coordinates), HijriCalendar.format(moment.toLocalDate()), settings,
            settings.profileFor(c.country), params)
    }
    private fun awaitTag(tag: String) = compose.waitUntil(10_000) {
        compose.onAllNodesWithTag(tag).fetchSemanticsNodes().isNotEmpty()
    }

    @Test fun allDaysFitAndSwipingDoesNotToggleFocusOrOpenShare() {
        val data = fixture()
        var shellHidden = false
        val chooserIntents = java.util.concurrent.CopyOnWriteArrayList<Intent>()
        val testOwner = object : ActivityResultRegistryOwner {
            override val activityResultRegistry = object : ActivityResultRegistry() {
                override fun <I,O> onLaunch(requestCode: Int, contract: ActivityResultContract<I,O>, input: I, options: ActivityOptionsCompat?) {
                    chooserIntents.add(input as Intent)
                    dispatchResult(requestCode, Activity.RESULT_CANCELED, null)
                }
            }
        }
        compose.setContent {
            NurTheme {
                CompositionLocalProvider(LocalDensity provides Density(LocalDensity.current.density, 2f), LocalActivityResultRegistryOwner provides testOwner) {
                    Box(Modifier.width(320.dp).height(520.dp)) {
                        ScheduleScreen(data, remember { mutableStateOf(moment) }, paletteFor(Prayer.ASR),
                            onModalChange = { shellHidden = it })
                    }
                }
            }
        }
        compose.onNodeWithTag("calendar-tab-2").performClick()
        awaitTag("table-row-2026-11-30")
        compose.onNodeWithTag("table-row-2026-11-01").assertIsDisplayed()
        compose.onNodeWithTag("table-row-2026-11-30").assertIsDisplayed()
        val viewport = compose.onNodeWithTag("calendar-pager").getUnclippedBoundsInRoot()
        compose.onNodeWithTag("month-table").performTouchInput { click() }
        compose.onNodeWithTag("calendar-tabs").assertDoesNotExist()
        compose.onNodeWithTag("calendar-share").assertDoesNotExist()
        assertEquals(viewport, compose.onNodeWithTag("calendar-pager").getUnclippedBoundsInRoot())
        compose.runOnIdle { assertTrue(shellHidden) }
        compose.onNodeWithTag("calendar-pager").performTouchInput { swipeLeft() }
        awaitTag("table-row-2026-12-31")
        compose.onNodeWithTag("calendar-tabs").assertDoesNotExist()
        compose.onNodeWithTag("month-table").performTouchInput { click() }
        compose.onNodeWithTag("calendar-share").assertIsEnabled().performClick()
        compose.waitUntil(10_000) { chooserIntents.size == 1 }
        assertEquals(Intent.ACTION_CHOOSER, chooserIntents.single().action)
        compose.onNodeWithTag("calendar-export").assertDoesNotExist()
        // Canceling the system chooser leaves both the month and the current page intact.
        compose.onNodeWithTag("table-row-2026-12-31").assertIsDisplayed()
        compose.onNodeWithContentDescription("Выбрать период").performClick()
        compose.onNodeWithTag("period-prev").performClick()
        compose.onNodeWithTag("period-month-2").performScrollTo().performClick().assertIsSelected()
        compose.onNodeWithTag("period-done").performClick()
        awaitTag("table-row-2025-02-28")
        compose.onNodeWithTag("calendar-share").assertIsEnabled().performClick()
        compose.waitUntil(10_000) { chooserIntents.size == 2 }
        assertNotEquals(stream(chooserIntents[0]), stream(chooserIntents[1]))
    }

    @Suppress("DEPRECATION")
    private fun stream(chooser: Intent): Uri {
        val send = requireNotNull(chooser.getParcelableExtra<Intent>(Intent.EXTRA_INTENT))
        assertEquals(Intent.ACTION_SEND, send.action)
        assertEquals("image/png", send.type)
        val uri = requireNotNull(send.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))
        assertEquals(uri, send.clipData?.getItemAt(0)?.uri)
        assertTrue((send.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0)
        return uri
    }

    @Test fun freshFilesRemainReadableThroughChooserUris() {
        val data = fixture()
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        fun prepare(month: YearMonth): CalendarImageShare.Export {
            val days = PrayerEngine.days(month.atDay(1), month.lengthOfMonth(), data.place.coordinates, data.place.zone, data.params)
            val p = calendarPage(MonthTimes(month, days, Prayer.entries), 0, data.place.label, data.params.method, moment.toLocalDate())
            return runBlocking { CalendarImageShare.prepare(ctx, p) }
        }
        val month = YearMonth.from(moment)
        val a = prepare(month)
        val bytes = a.file.readBytes()
        val b = prepare(month.plusMonths(1))
        try {
            assertNotEquals(a.file, b.file)
            assertTrue(bytes.contentEquals(a.file.readBytes()))
            assertTrue(!bytes.contentEquals(b.file.readBytes()))
            val decoded = BitmapFactory.decodeFile(b.file.absolutePath)
            try {
                assertEquals(1440, decoded.width)
                assertEquals(2560, decoded.height)
                val uri = stream(CalendarImageShare.chooser(ctx,b))
                val shared = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                assertTrue(shared.contentEquals(b.file.readBytes()))
            } finally { decoded.recycle() }
        } finally { a.file.delete(); b.file.delete() }
    }
}
