package com.nur.prayer.ui.wallpaper

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import com.nur.prayer.ui.components.SkyBackdrop
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette
import kotlin.math.hypot
import kotlin.math.max

/**
 * 0.22.0: the backdrop of the whole app is a wallpaper.
 *
 * The sky and black are drawn by [SkyBackdrop] exactly as before; a picture is drawn by [WallpaperLayer]
 * with its computed scrim. A change of wallpaper is not a cut: the new one is decoded first (never an
 * empty frame), then grows out of the button that set it as a circle with a soft light ring on its
 * edge, over the old one — a drop of paint, not a slide.
 *
 * [dim] (read only while drawing, so a moving calendar never recomposes this) darkens a picture
 * under pages that put lists of text on the backdrop: the scrim contract covers the home layout only.
 */
@Composable
fun WallpaperBackdrop(
    wallpaper: Wallpaper,
    palette: PhasePalette,
    motionEnabled: Boolean,
    dim: () -> Float,
    modifier: Modifier = Modifier
) {
    Box(modifier.fillMaxSize().onSizeChanged { WallpaperScreen.size.value = it }) {
        RevealingWallpaper(wallpaper, palette, motionEnabled)
        Box(
            Modifier
                .fillMaxSize()
                .drawBehind {
                    if (!wallpaper.isImage) return@drawBehind
                    val a = dim().coerceIn(0f, 1f) * PAGE_DIM
                    if (a > 0.001f) drawRect(Color.Black.copy(alpha = a))
                }
        )
    }
}

/**
 * [WallpaperLayer] that changes by a growing circle from [WallpaperScreen.revealOrigin] (root px —
 * the box is expected to start at the root's top-left, give or take [originShift]).
 */
@Composable
internal fun RevealingWallpaper(
    wallpaper: Wallpaper,
    palette: PhasePalette,
    motionEnabled: Boolean,
    modifier: Modifier = Modifier,
    sharp: Boolean = true,
    originShift: Offset = Offset.Zero
) {
    val context = LocalContext.current.applicationContext
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var shown by remember { mutableStateOf(wallpaper) }
    var under by remember { mutableStateOf<Wallpaper?>(null) }
    var origin by remember { mutableStateOf(Offset.Unspecified) }
    val reveal = remember { Animatable(1f) }

    LaunchedEffect(wallpaper) {
        if (wallpaper == shown) return@LaunchedEffect
        val s = boxSize
        if (wallpaper.isImage && s.width > 0 && s.height > 0) {
            // Decode first: the circle must never open onto an empty frame.
            val div = if (sharp) 1 else SOFT_DIVISOR
            WallpaperImages.load(context, wallpaper, s.width / div, s.height / div)
            if (sharp) WallpaperImages.scrim(context, wallpaper, s.width, s.height)
        }
        val o = WallpaperScreen.revealOrigin
        origin = if (o.isSpecified) o - originShift else Offset.Unspecified
        under = shown
        shown = wallpaper
        reveal.snapTo(0f)
        reveal.animateTo(1f, tween(REVEAL_MILLIS, easing = RevealEasing))
        under = null
    }

    Box(modifier.fillMaxSize().onSizeChanged { boxSize = it }) {
        under?.let { WallpaperLayer(it, palette, motionEnabled = false, sharp = sharp) }
        WallpaperLayer(
            shown, palette, motionEnabled && under == null,
            Modifier.drawWithContent {
                val p = reveal.value
                if (p >= 1f || under == null) {
                    drawContent()
                    return@drawWithContent
                }
                val c = if (origin.isSpecified) origin else Offset(size.width / 2f, size.height * 0.92f)
                val far = max(
                    max(hypot(c.x, c.y), hypot(size.width - c.x, c.y)),
                    max(hypot(c.x, size.height - c.y), hypot(size.width - c.x, size.height - c.y))
                )
                val r = far * p
                val circle = Path().apply { addOval(Rect(c, r)) }
                clipPath(circle) { this@drawWithContent.drawContent() }
                // The wet edge of the paint: a light ring that fades as the circle grows.
                drawCircle(Color.White.copy(alpha = 0.28f * (1f - p)), r, c, style = Stroke(width = 10f + 26f * (1f - p)))
            },
            sharp = sharp
        )
    }
}

/**
 * One wallpaper filling its box. [sharp] = false draws the picture from a small copy, stretched:
 * a soft, free blur (the gallery puts it behind its own content on every Android version).
 */
@Composable
internal fun WallpaperLayer(
    wallpaper: Wallpaper,
    palette: PhasePalette,
    motionEnabled: Boolean,
    modifier: Modifier = Modifier,
    sharp: Boolean = true
) {
    if (!wallpaper.isImage) {
        SkyBackdrop(palette, modifier, sky = wallpaper.kind == Wallpaper.Kind.SKY, motionEnabled = motionEnabled && sharp)
        return
    }
    BoxWithConstraints(modifier.fillMaxSize()) {
        val w = constraints.maxWidth
        val h = constraints.maxHeight
        val div = if (sharp) 1 else SOFT_DIVISOR
        val bitmap by rememberWallpaperBitmap(wallpaper, w / div, h / div)
        val scrim by rememberWallpaperScrim(wallpaper, w, h)
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Ink)
            val b = bitmap ?: return@Canvas
            drawWallpaper(b, wallpaper, if (sharp) FilterQuality.High else FilterQuality.Low)
            if (sharp) scrim?.let { drawScrim(it) }
        }
    }
}

/** Black over a picture under a page of text (calendar, Today, Qibla): enough for 4.5:1 on any picture. */
private const val PAGE_DIM = 0.62f
private const val REVEAL_MILLIS = 760
private const val SOFT_DIVISOR = 10

/** Starts fast like a dropped blob, then slows down as it reaches the corners. */
private val RevealEasing = CubicBezierEasing(0.2f, 0.9f, 0.3f, 1f)
