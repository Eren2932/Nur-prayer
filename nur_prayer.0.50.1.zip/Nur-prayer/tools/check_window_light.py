#!/usr/bin/env python3
"""Bound the sRGB contrast of the real draw constants. Not an Android rendering test."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

U = Path(__file__).resolve().parents[1] / 'app/src/main/java/com/nur/prayer/ui'

def rgba(h):
    a, r, g, b = bytes.fromhex(h)
    return (r, g, b), a / 255

def over(fg, bg):
    rgb, a = fg
    return tuple(a*x+(1-a)*y for x,y in zip(rgb,bg))

def lum(rgb):
    def linear(c):
        v = c/255
        return v / 12.92 if v <= .04045 else ((v+.055)/1.055)**2.4
    return sum(linear(c)*w for c,w in zip(rgb,(.2126,.7152,.0722)))

def ratio(a,b):
    l,h=sorted((lum(a),lum(b)))
    return (h+.05)/(l+.05)

def take(text, pattern):
    return re.search(pattern,text).group(1)

def named(text,name):
    return rgba(take(text, rf'val {name} = Color\(0x(\w{{8}})\)'))

if __name__=='__main__':
    shell=(U/'shell/NavCapsule.kt').read_text().split('internal object TimerInk {')[1]; surface=named(shell,'Surface')
    white=(255,255,255); black=(0,0,0)
    # The white-pixel upper bound covers saturated photos and tiny specular highlights
    # even before tone analysis returns. Read the actual foreground and scrim constants.
    policy=(U/'wallpaper/WallpaperTonePolicy.kt').read_text()
    lo,hi=(float(take(policy,rf'const val SETTINGS_DIM_{k} = ([.0-9]+)f')) for k in ('MIN','MAX'))
    assert 0 < lo <= hi < 1
    bg=tuple(round(v) for v in over((black,lo),white))
    muted=named((U/'settings/EditorControls.kt').read_text(),'Muted')[0]
    for fg in (muted,white):
        c=ratio(fg,bg);print(f'editor {fg} on white highlight: >= {c:.2f}:1');assert c>=4.5
    # Componentwise monotonic sRGB: white provides the highest possible luminance of the timer body.
    for name in ('Time','Label','Icon'):
        c=ratio(over(surface,white),named(shell,name)[0]);print(f'timer {name}: >= {c:.2f}:1');assert c>=4.5
    wash=(U/'wallpaper/DeedsWindowWash.kt').read_text()
    # No upper shadow. Dark status glyphs sit on the flat neutral photo exposure;
    # check even the darkest source at the instant the status tone is switched.
    header,header_alpha=named(wash,'PhotoHeader')
    root=(U/'NurRoot.kt').read_text()
    threshold=float(take(root,r'calendar.progress \* \(1f - deepLayer.value\) >= (\.\d+)f'))
    c=ratio(black,over((header,header_alpha*threshold),black));print(f'dark status glyphs on photo: >= {c:.2f}:1');assert c>=4.5
    frost=(U/'shell/Frost.kt').read_text();pig=frost.split('internal object CardPigment {')[1].split('}')[0]
    opacity,alpha=[float(take(frost,rf'CardPigment.Deed{key}, alpha = (\.\d+)f')) for key in ('Photo','Plain')]
    def floor(key, a): return over((named(pig,key)[0],a),black)
    body, fallback=floor('DeedPhoto',opacity),floor('DeedPlain',alpha)
    menu=[floor('SectionPhoto',opacity),floor('SectionPlain',alpha)]
    # The new material must be a small lift, not a second blur or a cream opaque fill.
    for story, section in zip((body,fallback),menu):
        assert all(5 <= b-a <= 11 for a,b in zip(story,section))
    matte=(U/'today/DeedMaterial.kt').read_text();assert '.border(' not in matte
    c=ratio(over((header,header_alpha),black),named(matte,'Ink')[0]);print(f'photo header text: >= {c:.2f}:1');assert c>=4.5
    for name in ('Ink','Quiet'):
        c=min(ratio(bg,named(matte,name)[0]) for bg in (body,fallback,*menu));print(f'deed/menu {name}: >= {c:.2f}:1');assert c>=4.5
    # Guard both the lightness floor and the original amount of wallpaper in the glass.
    assert abs(1-float(opacity)-.23*.82) < .0001 and abs(1-float(alpha)-.12)<.0001
    assert max(abs(a-b) for a,b in zip(body,fallback)) < 2
    assert all(189 <= v <= 200 for bg in (body, fallback) for v in bg)
    c=min(ratio(bg,named(matte,'Utility')[0]) for bg in (body,fallback));assert c>=3
    # New decorative gradients retain their bright tips. Require a distinct dark body tone,
    # not a fictitious contrast guarantee for every pixel of an amber highlight.
    draw=U.parents[4]/'res/drawable'
    android='{http://schemas.android.com/apk/res/android}'
    for icon in ('allah','star','sun','moon','bars','clock'):
        vec=ET.parse(draw / f'deed_{icon}.xml').getroot(); paths=vec.findall('path')
        assert paths and all(p.find('.//gradient') is not None for p in paths)
        if icon=='bars':assert len(paths)==3
        colors=[tuple(bytes.fromhex(i.attrib[android+'color'][1:])) for i in vec.iter('item')]
        c=min(max(ratio(bg,rgb) for rgb in colors) for bg in (body,fallback))
        print(f'{icon}: darkest pigment >= {c:.2f}:1; {len(set(colors))} tones');assert c>=3
