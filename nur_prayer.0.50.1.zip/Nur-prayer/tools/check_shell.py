#!/usr/bin/env python3
"""0.27.0 «Капсула»: a mirror of ShellMath.kt, checked in CI without a JVM.
0.33.0 «Минарет»: the glass is the mock's light cream; the checks that spoke of the old dark glass
(tint over a white wallpaper, 10-18 % hairline) are replaced by the ones that matter for cream and dark ink:
contrast of every text and icon colour, the roof's curve, the section glyphs and the speaker of the cards.
0.36.0 «Бумага»: the roof is gone, the glass is flat paper white (#FAFAFA), "now" is lavender and the capsule wears
the tone of where the user is (ShellTones). The checks follow: paper colours and their contrast, the white glyph on
every section disc, the capsule's ink on its pastel disc.

0.39.0 «Капля»: the panel is a compact slab (no times, no cards): the checks of the cards, the speakers and the lavender
«now» are gone; in their place the matte glass (its tone and the ink's contrast on it, lightest and darkest), the drop's
curves and the panel's grid.

The Kotlin numbers are read from the source, so the mirror cannot silently drift from it.
"""
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SHELL = ROOT / 'app/src/main/java/com/nur/prayer/ui/shell'
SRC = (SHELL / 'ShellState.kt').read_text()
FROST = (SHELL / 'Frost.kt').read_text()
CAPS = (SHELL / 'NavCapsule.kt').read_text()
TIMES = (SHELL / 'PanelTimes.kt').read_text()
PANEL = (SHELL / 'PanelLayout.kt').read_text()
GLYPHS = (SHELL / 'ShellGlyphs.kt').read_text()
DATA = (SHELL / 'ShellIconData.kt').read_text()
TONES = (SHELL / 'ShellTones.kt').read_text()
SECTION = (ROOT / 'app/src/main/java/com/nur/prayer/ui/home/HomeSection.kt').read_text()


def num(pattern, what, text=SRC, name='ShellState.kt'):
    m = re.search(pattern, text)
    if not m: sys.exit('check_shell: %s not found in %s' % (what, name))
    return float(m.group(1))


CARDS = (SHELL / 'SectionCards.kt').read_text()
errors = []
# --- colours: the mock's paper white, near-black ink, lavender "now" --------------------------------------------------------------
def colors_of(text, obj):
    m = re.search(r'(?:internal )?object %s \{(.*?)\n\}' % obj, text, re.S)
    if not m: sys.exit('check_shell: object %s not found' % obj)
    out = {}
    for name, v in re.findall(r'val (\w+) = Color\(0x([0-9A-Fa-f]{8})\)', m.group(1)):
        v = int(v, 16)
        out[name] = (((v >> 24) & 255) / 255.0, (v >> 16) & 255, (v >> 8) & 255, v & 255)
    # 0.36.0: aliases (val Label = Ink) are the same colour under another name.
    for name, ref in re.findall(r'val (\w+) = ([A-Z]\w*)\s*$', m.group(1), re.M):
        if ref in out: out[name] = out[ref]
    return out


C = colors_of(FROST, 'ShellColors')


def over(fg, bg):
    """Colour fg (alpha, r, g, b) laid over the opaque bg (alpha, r, g, b)."""
    a = fg[0]
    return (1.0,) + tuple(a * fg[i] + (1 - a) * bg[i] for i in (1, 2, 3))


def luma(c):
    def lin(v):
        v /= 255.0
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126 * lin(c[1]) + 0.7152 * lin(c[2]) + 0.0722 * lin(c[3])


def contrast(fg, bg):
    fg = over(fg, bg)
    a, b = luma(fg), luma(bg)
    return (max(a, b) + 0.05) / (min(a, b) + 0.05)


def need(name):
    if name not in C: sys.exit('check_shell: ShellColors.%s not found' % name)
    return C[name]


glass = need('Glass')
if glass[0] != 1.0: errors.append('ShellColors.Glass must be opaque: it is the flat paper of the island and of the panel over a white page')
if luma(glass) < 0.55: errors.append('ShellColors.Glass is not light (luminance %.2f)' % luma(glass))
# The paper is white, not cream: no channel may lean warm by more than a few levels.
if max(glass[1:]) - min(glass[1:]) > 6: errors.append('ShellColors.Glass must be neutral white, not cream')
# (foreground, background, minimum contrast): text 4.5, big text and the ink of icons 3
PAIRS = [
    ('Ink', 'Glass', 7.0), ('Secondary', 'Glass', 4.5), ('Icon', 'Glass', 4.5),
    ('PanelInk', 'Glass', 7.0), ('GearInk', 'Glass', 7.0),
]
for fg, bg, floor in PAIRS:
    r = contrast(need(fg), need(bg))
    if r < floor: errors.append('%s on %s: contrast %.2f, needs %.1f' % (fg, bg, r, floor))
# The bar's veil. 0.38.0: on home the round buttons are really transparent (black at 3-15 %, the picture shows through);
# inside a section the page under the bar may be white paper, so there the buttons keep 0.37.0's firmer veil
# (BarGlassPage, black at 30-60 %), and the white ink must keep 3:1 on it even over a white page, the worst case.
veil, page_veil, ring, ink = need('BarGlass'), need('BarGlassPage'), need('BarRing'), need('BarInk')
if not (0.03 <= veil[0] <= 0.15 and veil[1:] == (0, 0, 0)): errors.append('ShellColors.BarGlass must be black at 3-15 %')
if not (0.3 <= page_veil[0] <= 0.6 and page_veil[1:] == (0, 0, 0)): errors.append('ShellColors.BarGlassPage must be black at 30-60 %')
for page in ((1.0, 255, 255, 255), (1.0, 243, 234, 211)):
    r = contrast(ink, over(page_veil, page))
    if r < 3.0: errors.append('BarInk on BarGlassPage over page %s: contrast %.2f, needs 3.0' % (page[1:], r))
    r = contrast(ring, over(page_veil, page))
    if r < 3.0: errors.append('BarRing on BarGlassPage over page %s: contrast %.2f, needs 3.0' % (page[1:], r))
# The pill «Учёба» (0.38.0): dark ink on light grey, readable also at the glint's brightest.
pill_fill, pill_ink, glint = need('PillFill'), need('PillInk'), need('PillGlint')
if contrast(pill_ink, pill_fill) < 7.0: errors.append('PillInk on PillFill: contrast %.2f, needs 7.0' % contrast(pill_ink, pill_fill))
PILL = (SHELL / 'PillShimmer.kt').read_text()
peak = num(r'const val PEAK_ALPHA = ([0-9.]+)f', 'PEAK_ALPHA', PILL, 'PillShimmer.kt')
lit = over((peak, glint[1], glint[2], glint[3]), pill_fill)
if contrast(pill_ink, lit) < 7.0: errors.append('PillInk at the glint\'s peak: contrast %.2f, needs 7.0' % contrast(pill_ink, lit))
# The glint is rarer than in the owner's clip (a pass of 0.4 s every 1.6 s) and its strip is not slower.
cycle = num(r'const val CYCLE_MS = (\d+)', 'CYCLE_MS', PILL, 'PillShimmer.kt')
sweep = num(r'const val SWEEP_MS = (\d+)', 'SWEEP_MS', PILL, 'PillShimmer.kt')
if not (3200 <= cycle <= 4800): errors.append('PillShimmer.CYCLE_MS %d: the passes must be 2-3 times rarer than the clip\'s 1600 ms' % cycle)
if not (400 <= sweep <= 533): errors.append('PillShimmer.SWEEP_MS %d: the strip must keep the clip\'s speed (400-533 ms a pass)' % sweep)
# The bar's geometry (0.38.0, measured on the reference): 35.5 dp high, a 95 dp pill, one gap, the middle one centred.
LAYOUT = (SHELL / 'BarLayout.kt').read_text()
button = num(r'const val BUTTON = ([0-9.]+)f', 'BarLayout.BUTTON', LAYOUT, 'BarLayout.kt')
gap = num(r'const val GAP = ([0-9.]+)f', 'BarLayout.GAP', LAYOUT, 'BarLayout.kt')
pill_w = num(r'const val PILL_WIDTH = ([0-9.]+)f', 'BarLayout.PILL_WIDTH', LAYOUT, 'BarLayout.kt')
if abs(button - 35.5) > 0.3 or abs(pill_w - 95) > 0.5 or abs(gap - 33) > 0.7:
    errors.append('BarLayout: %.1f / %.1f / %.1f dp is not the reference\'s 35.5 / 95 / 33' % (button, pill_w, gap))
if 'fun middleStart' not in LAYOUT or '(width - BUTTON) / 2f' not in LAYOUT:
    errors.append('BarLayout.middleStart must centre the middle button')
# The panel's grid no longer holds «Учёба» (it is the bar's pill) nor the Quran.
grid = re.search(r'val GRID: List<HomeSection> = listOf\(([^)]*)\)', SECTION)
if not grid or [x.strip() for x in grid.group(1).split(',')] != ['DHIKR', 'QIBLA', 'TODAY', 'SCHEDULE']:
    errors.append('HomeSection.GRID must be DHIKR, QIBLA, TODAY, SCHEDULE')

# --- tones: white glyph on every disc, the capsule's ink on its pastel -------------------------------------------
def hexc(h):
    v = int(h, 16)
    return (1.0, (v >> 16) & 255, (v >> 8) & 255, v & 255)
def mix(a, b, t):
    return (1.0,) + tuple(a[i] + (b[i] - a[i]) * t for i in (1, 2, 3))
PASTEL = num(r'const val PASTEL = ([0-9.]+)f', 'ShellTones.PASTEL', TONES, 'ShellTones.kt')
INK_SHADE = num(r'const val INK_SHADE = ([0-9.]+)f', 'ShellTones.INK_SHADE', TONES, 'ShellTones.kt')
pw = re.search(r'PASTEL_WHITE = Color\(0xFF([0-9A-Fa-f]{6})\)', TONES)
if not pw: sys.exit('check_shell: ShellTones.PASTEL_WHITE not found')
PW = hexc(pw.group(1))
WHITE, BLACK = (1.0, 255, 255, 255), (1.0, 0, 0, 0)
tones = re.findall(r'val (\w+) = of\(Color\(0xFF([0-9A-Fa-f]{6})\)(?:, container = Color\(0xFF([0-9A-Fa-f]{6})\))?\)', TONES)
if len(tones) < 9: errors.append('ShellTones: expected seven sections and two azkar tones, got %d' % len(tones))
for name, well, cont in tones:
    w = hexc(well)
    c = hexc(cont) if cont else mix(w, PW, PASTEL)
    ink = mix(w, BLACK, INK_SHADE)
    if name not in ('MORNING',) and contrast(WHITE, w) < 2.5:
        errors.append('ShellTones.%s: the white glyph on the disc, contrast %.2f, needs 2.5' % (name, contrast(WHITE, w)))
    if contrast(ink, c) < 4.5: errors.append('ShellTones.%s: capsule ink on its pastel, contrast %.2f, needs 4.5' % (name, contrast(ink, c)))
    if luma(c) < 0.35: errors.append('ShellTones.%s: the capsule disc must be pastel (luminance %.2f)' % (name, luma(c)))

# --- the glass is flat: no per-frame work while the shape morphs ----------------------------------------------------
if 'shadow(' in FROST or 'clipPath' in FROST or 'elevation' in FROST.replace('elevation shadow', ''):
    errors.append('Frost.kt: no elevation shadow and no path clip: they rebuild every frame while the shape morphs')
if 'CompositingStrategy.ModulateAlpha' not in CAPS: errors.append('NavCapsule.kt: layers fade per draw call, not in an offscreen buffer')
if 'object SheetGlass' not in FROST: errors.append('Frost.kt: the prayer sheet keeps its dark glass (SheetGlass)')

# --- the glyphs --------------------------------------------------------------------------------------------------
paths = re.findall(r'GlyphLayer\(1\.0f, false, "([^"]*)"\)', DATA)
names = re.findall(r'    val (\w+) = ShellIconArt\(', DATA)
if names != ['QURAN', 'DHIKR', 'QIBLA', 'TODO', 'MONTH'] or len(paths) != 5:
    errors.append('ShellIconData: expected QURAN, DHIKR, QIBLA, TODO, MONTH (the sixth, study, is the letter ع), got %s' % names)
if 'ShellGlyph.AIN' not in SECTION: errors.append('HomeSection.COURSE must wear ShellGlyph.AIN (the letter ع)')
if 'ShellGlyph.CAP' in SECTION + CAPS + GLYPHS or 'STUDY' in GLYPHS + DATA:
    errors.append('the graduation cap is gone: «Учёба» is the letter ع')
if 'ArabicFont.paintTypeface()' not in GLYPHS or 'private const val AIN_TEXT = "\u0639"' not in GLYPHS:
    errors.append('ShellGlyphs.kt: ع is set in the mushaf face (ArabicFont) from U+0639')
# One glyph, one box: the letter is exactly as tall as its box and its weight is a share of it.
w = num(r'object AinFit \{\s*const val WEIGHT = ([0-9.]+)f', 'AinFit.WEIGHT', GLYPHS, 'ShellGlyphs.kt')
if not (0.03 <= w <= 0.08): errors.append('AinFit.WEIGHT %.3f: the letter must carry about the weight of the drawn glyphs' % w)

# --- the panel (0.39.0 «Капля») ----------------------------------------------------------------------------------
if re.search(r'PRAYERS: List<Prayer> = listOf\(([^)]*)\)', TIMES) is None:
    errors.append('PanelTimes.PRAYERS not found (home prints the six times in this order)')
else:
    got = re.findall(r'Prayer\.(\w+)', re.search(r'PRAYERS: List<Prayer> = listOf\(([^)]*)\)', TIMES).group(1))
    if got != ['FAJR', 'SUNRISE', 'DHUHR', 'ASR', 'MAGHRIB', 'ISHA']: errors.append('home prints the six times in this order, got %s' % got)
if 'fun callOn(' not in TIMES: errors.append('PanelTimes.callOn: one rule for "this card has a call" (sunrise never has)')
if re.search(r'PanelTimes|TimeCard|onOpenPrayer|SPEAKER', CAPS):
    errors.append('0.39.0: the panel holds the sections and the settings only: no times, no cards, no speakers')
if 'ShellGlyph.GEAR' not in CARDS or 'R.drawable.sections_gear' not in GLYPHS:
    errors.append('the full-width settings action must use the filled vector')
if 'DiscGlyph(section.glyph, Color.White, well)' not in CARDS or 'tone.well' not in CARDS:
    errors.append('keep the original optical fit, glyph and colour of each section')
def pl(name):
    return num(r'const val %s = ([0-9.]+)f' % name, name, PANEL, 'PanelLayout.kt')
if min(pl('ROW'), pl('HIT'), pl('SETTINGS')) < 48 or pl('GAP') < 8:
    errors.append('targets must be >= 48 dp, gutters >= 8 dp')
if 'PanelLayout.columns(maxWidth.value' not in CARDS or '.verticalScroll(' not in CARDS:
    errors.append('use available width; overflow must scroll without shrinking the targets')
if 'CloseMark(ink, Modifier.size(BAR_BUTTON))' not in CAPS or 'BackHandler(enabled = shell.open)' not in CAPS:
    errors.append('the ring must toggle in place and system Back must close the menu')
if errors:
    print('\n'.join('check_shell: ' + e for e in errors)); sys.exit(1)
print('check_shell: ok (fixed toggle, responsive section cards, %d colour pairs, %d tones)' % (len(PAIRS), len(tones)))
