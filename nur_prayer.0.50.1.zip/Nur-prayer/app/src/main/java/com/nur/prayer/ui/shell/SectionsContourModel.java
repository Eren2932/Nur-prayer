package com.nur.prayer.ui.shell;

/** Pure reference model. Angles increase clockwise from three o'clock, as in Nur-contour-only.mp4. */
final class SectionsContourModel {
    static final int STEP = 40, CYCLE = 7600, PERIOD = 6080, PHASES = PERIOD / STEP, ANGLES = 96;
    static final int FIRST = 320, LAST = 6920; // first/last nontransparent sample of the 50-fps reference at 25 Hz
    static final double EXTRA_DP = 2.95 * 35.5 / 103.0; // 2.95 px inward in the original 103 px disc
    private static final double[] KNOTS = {0, .22, .53, .78, 1};
    private static final int[] SILVER = {0xff85909a, 0xffa4b2be, 0xffdbe9f3, 0xfffbfdff, 0xffffffff};
    // The cool white crest is retained on paper. A graphite outer edge belongs to the static border underneath.
    private static final int[] PAPER = {0xff3f4c54, 0xff64737e, 0xffb5c8d4, 0xffedf5fb, 0xffffffff};
    private SectionsContourModel() {}

    static int slot(long elapsedMs, float scale) {
        if (!(scale > 0f) || !Float.isFinite(scale)) return -1;
        int t = (int) ((long) (elapsedMs / (double) scale) % CYCLE);
        return t < FIRST || t >= LAST + STEP ? -1 : t / STEP;
    }
    // Return a delay, never a count of vsync callbacks. Late draws skip obsolete samples.
    static long sleepMs(long elapsedMs, float scale) {
        if (!(scale > 0f) || !Float.isFinite(scale)) return Long.MAX_VALUE;
        long logical = (long) (elapsedMs / (double) scale);
        int t = (int) (logical % CYCLE);
        int next = t < FIRST ? FIRST : t >= LAST + STEP ? CYCLE + FIRST : (t / STEP + 1) * STEP;
        return Math.max(STEP, (long) Math.ceil((logical - t + next) * (double) scale - elapsedMs));
    }
    static int phase(int slot) { return (slot + 4) % PHASES; } // reference starts the spatial field at +160 ms
    static int opacity(int slot) {
        if (slot < 0) return 0;
        int t = slot * STEP;
        return (int) Math.round(255 * smooth((t-280)/280.0) * smooth((6950-t)/500.0));
    }
    private static double smooth(double v) {
        double x = Math.min(1, Math.max(0, v)); return x*x*(3-2*x);
    }
    static double extraDp(int value) { return EXTRA_DP * smooth((value/255.0 - .11)/.71); }
    static int color(int value, boolean paper) {
        int[] c = paper ? PAPER : SILVER;
        double v = value/255.0; int i = 0;
        while (i+2 < KNOTS.length && v > KNOTS[i+1]) i++;
        double f = (v-KNOTS[i])/(KNOTS[i+1]-KNOTS[i]);
        int out = 0xff000000;
        for (int shift=0; shift<=16; shift+=8) {
            int a=(c[i] >> shift) & 255, b=(c[i+1] >> shift) & 255;
            out |= (int) Math.round(a+(b-a)*f) << shift;
        }
        return out;
    }
    // The only persistent table is 14,592 bytes. First accessed on Dispatchers.Default, once per process.
    private static class Holder { static final byte[] DATA = bake(); }
    static byte[] profile() { return Holder.DATA; }
    private static double delta(double d) { return d - 360*Math.floor((d+180)/360); }
    private static double gaussian(double d, double w) { double x=d/w; return Math.exp(-.5*x*x); }
    private static byte[] bake() {
        byte[] data = new byte[PHASES*ANGLES];
        double[] widths={32,36,26}, shifts={-14,16,-11}, phases={0,2.17,4.06};
        double[] center=new double[3], amp=new double[3], width=new double[3];
        for (int k=0;k<PHASES;k++) {
            double a=2*Math.PI*k/PHASES;
            center[0]=-95+63*Math.sin(a-.82)+14*Math.sin(2*a+.15);
            center[1]=139+58*Math.sin(a+.45)-13*Math.sin(2*a-.88);
            center[2]=9+51*Math.sin(a+1.37)+9*Math.sin(2*a+.60);
            for (int j=0;j<3;j++) {
                amp[j]=.08+.92*smooth(.5+.5*Math.cos(a-phases[j]));
                width[j]=widths[j]*(1+.14*Math.sin(a+1.54*j));
            }
            for (int i=0;i<ANGLES;i++) {
                double remaining=1;
                for (int j=0;j<3;j++) {
                    double d=delta(360.0*i/ANGLES-center[j]);
                    remaining *= 1-amp[j]*(.72*gaussian(d,width[j])+.28*gaussian(delta(d-shifts[j]),1.46*width[j]));
                }
                data[k*ANGLES+i]=(byte)Math.round(255*(1-remaining));
            }
        }
        return data;
    }
}
