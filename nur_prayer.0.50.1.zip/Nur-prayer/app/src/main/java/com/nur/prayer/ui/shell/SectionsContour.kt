package com.nur.prayer.ui.shell

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.SweepGradient
import android.os.SystemClock
import com.nur.prayer.ui.shell.SectionsContourModel as Contour
import kotlin.ByteArray
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin

/** Decorative sibling of the dots. Removing it cancels the timer and releases the per-size geometry. */
@Composable
internal fun SectionsContour(paper: Boolean, scale: Float, stroke: Dp, modifier: Modifier) {
    val table = remember { mutableStateOf<ByteArray?>(null) }
    val slot = remember(scale) { mutableIntStateOf(-1) }
    LaunchedEffect(scale) {
        table.value = withContext(Dispatchers.Default) { Contour.profile() }
        val start = SystemClock.uptimeMillis()
        while (true) {
            val elapsed = SystemClock.uptimeMillis() - start
            slot.intValue = Contour.slot(elapsed, scale)
            delay(Contour.sleepMs(elapsed, scale))
        }
    }
    // No offscreen bitmap or alpha layer. Only this small display list is invalidated at a sample boundary.
    Spacer(modifier.graphicsLayer { }.drawWithCache {
        val cache = table.value?.let {
            ContourFrames(it, size.width/2f, size.height/2f, ceil(stroke.toPx()),
                1.dp.toPx(), paper)
        }
        onDrawBehind {
            val s = slot.intValue
            if (s >= 0) cache?.draw(drawContext.canvas.nativeCanvas, s)
        }
    })
}

internal class ContourFrames(
    private val table: ByteArray, private val cx: Float, private val cy: Float,
    private val baseWidth: Float, density: Float, paper: Boolean
) {
    private class Frame(val ring: Path, val gradient: SweepGradient)
    private val n = Contour.ANGLES
    private val frames = arrayOfNulls<Frame>(Contour.PHASES)
    private val colors = IntArray(256) { Contour.color(it, paper) }
    private val outer = minOf(cx,cy)
    // On near-white paper leave a sub-dp graphite edge INSIDE the original radius. The crest itself stays white.
    private val brightOuter = outer - if (paper) minOf(baseWidth*.55f, .65f*density) else 0f
    private val inner = FloatArray(256) { (outer-baseWidth-density*Contour.extraDp(it).toFloat()).coerceAtLeast(0f) }
    private val xs = FloatArray(n) { cos(2.0*PI*it/n).toFloat() }
    private val ys = FloatArray(n) { sin(2.0*PI*it/n).toFloat() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun draw(canvas: Canvas, slot: Int) {
        val phase = Contour.phase(slot)
        val f = frames[phase] ?: build(phase).also { frames[phase] = it }
        paint.shader = f.gradient
        paint.alpha = Contour.opacity(slot)
        canvas.drawPath(f.ring, paint)
    }
    private fun build(phase: Int): Frame {
        val path = Path().apply {
            fillType = Path.FillType.EVEN_ODD
            addCircle(cx, cy, brightOuter, Path.Direction.CW)
        }
        val stops = IntArray(n+1)
        for (i in 0 until n) {
            val v = table[phase*n+i].toInt() and 255
            stops[i] = colors[v]
            val x = cx+inner[v]*xs[i]; val y = cy+inner[v]*ys[i]
            if (i == 0) path.moveTo(x,y) else path.lineTo(x,y)
        }
        path.close()
        stops[n] = stops[0] // continuous at three o'clock
        return Frame(path, SweepGradient(cx, cy, stops, null))
    }
}
