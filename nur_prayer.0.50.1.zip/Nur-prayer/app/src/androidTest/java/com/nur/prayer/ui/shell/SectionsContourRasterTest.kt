package com.nur.prayer.ui.shell

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.nur.prayer.ui.shell.SectionsContourModel as Contour
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.roundToInt

/** Exercise the production Android path/gradient, not a screenshot approximation. */
class SectionsContourRasterTest {
    @Test fun paintedBandStaysInsideDiscAndNeverTouchesTheDots() {
        for (paper in listOf(false, true)) for (density in listOf(1f, 2.75f, 4f)) {
            val diameter = (35.5f*density).roundToInt(); val center = diameter/2f + 3f
            val stroke = ceil(1.2f*density)
            val renderer = ContourFrames(Contour.profile(), diameter/2f, diameter/2f, stroke, density, paper)
            val bmp = Bitmap.createBitmap(diameter+6, diameter+6, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp).apply { translate(3f, 3f) }
            try {
                for (s in listOf(20, 49, 88, 127)) {
                    bmp.eraseColor(Color.TRANSPARENT); renderer.draw(canvas, s)
                    var painted = 0
                    for (y in 0 until bmp.height) for (x in 0 until bmp.width) {
                        val d = hypot((x+.5f-center).toDouble(), (y+.5f-center).toDouble())
                        val alpha = Color.alpha(bmp.getPixel(x,y))
                        if (d > diameter/2f+1 || d < diameter/2f-stroke-1.02f*density-1) assertEquals(0, alpha)
                        if (alpha > 180) painted++
                    }
                    assertTrue(painted > diameter)
                }
            } finally { bmp.recycle() }
        }
    }
}
