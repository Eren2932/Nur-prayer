package com.nur.prayer.ui.shell;

/** Also runnable on a plain JDK; no Android runtime is needed for timing, palette or profile checks. */
public final class SectionsContourContract {
    private static void check(boolean ok) { if (!ok) throw new AssertionError(); }
    public static void main(String[] ignored) {
        byte[] data = SectionsContourModel.profile();
        check(data == SectionsContourModel.profile() && data.length == 152*96);
        // Same wall-time sample at common timestamps regardless of how many screen refreshes preceded it.
        for (int hz : new int[]{60,90,120,144}) {
            for (int second=0; second<=120; second++) {
                long at=Math.round((long)second*hz*1000.0/hz);
                int pos=(second*1000)%7600;
                int expected=pos<320 || pos>=6960 ? -1 : pos/40;
                check(SectionsContourModel.slot(at,1f)==expected);
                if (expected>=0) check(SectionsContourModel.phase(expected)==((pos/40+4)%152));
            }
        }
        for (float scale : new float[]{.5f,1f,2f,10f}) {
            long next=0;
            for (int wake=0;wake<500;wake++) {
                // Intentionally miss callbacks. No catch-up loop or permanently shifted phase.
                long now=next+(wake%23==0 ? 137 : 0);
                long delay=SectionsContourModel.sleepMs(now,scale);
                check(delay>=40 && delay<2*7600*scale);
                long t=(long)(now/(double)scale)%7600;
                check(SectionsContourModel.slot(now,scale)==(t<320 || t>=6960 ? -1 : (int)t/40));
                next=now+delay;
            }
        }
        check(SectionsContourModel.slot(2430,0)==-1);
        check(SectionsContourModel.sleepMs(0,0)==Long.MAX_VALUE);
        check(SectionsContourModel.sleepMs(6960,1f)==960);
        check(SectionsContourModel.opacity(-1)==0 && SectionsContourModel.opacity(14)==255);
        check(SectionsContourModel.color(0,false)==0xff85909a && SectionsContourModel.color(255,false)==-1);
        check(SectionsContourModel.color(255,true)==-1);
        check(SectionsContourModel.extraDp(0)==0 && Math.abs(SectionsContourModel.extraDp(255)-1.01675)<.002);
        int[] landmarks={0,38,76,114};
        for(int phase:landmarks) {
            int lo=255, hi=0;
            for(int i=0;i<96;i++) { int v=data[phase*96+i]&255; lo=Math.min(lo,v); hi=Math.max(hi,v); }
            check(lo<36 && hi>180);
        }
        System.out.println("Sections contour: phase, pause, dropped frames, display rates, motion scales, palette and width OK");
    }
}
