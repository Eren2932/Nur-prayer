package com.nur.prayer.ui.wallpaper

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Same window, progress and crop as the soft copy. Never tint a padded page or the cards.
 * Use the real bar edge only as a colour stop, not a rectangle boundary. Gradients are cached;
 * swipes and transitions only change the draw alpha, not layout. */
@Composable
internal fun Modifier.deedsWindowWash(
    photo: Boolean, amount: () -> Float, bars: WindowInsets = WindowInsets.statusBars
): Modifier = drawWithCache {
    val top = bars.getTop(this).toFloat()
    val h = size.height.coerceAtLeast(1f)
    val barEnd = (top / h).coerceIn(.001f, .24f)
    val clearOfIcons = (barEnd + 52.dp.toPx() / h).coerceAtMost(.45f)
    val softShoulder = barEnd + (clearOfIcons - barEnd) * .28f
    val middle = Color(0xAAD1CBCD)
    val brush = if (!photo) Brush.verticalGradient(listOf(Color(0x73000000), Color.Transparent, Color(0x45000000)))
    else Brush.verticalGradient(
        0f to (if (top > 0f) Color(0xCC36383A) else middle),
        barEnd to (if (top > 0f) Color(0xC036383A) else middle),
        softShoulder to (if (top > 0f) Color(0xBE56575A) else middle),
        clearOfIcons to middle, .5f to Color.Transparent,
        .75f to Color(0x4A252327), 1f to Color(0x8C2A282C)
    )
    onDrawWithContent {
        drawContent()
        val k = amount().coerceIn(0f, 1f)
        if (k > .001f) drawRect(brush, alpha = k)
    }
}
