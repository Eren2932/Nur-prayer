package com.nur.prayer.ui.today

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.shell.GlassStyle
import com.nur.prayer.ui.shell.frostGlass
import com.nur.prayer.ui.shell.rememberFrost
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.uiScale

internal object DeedTone {
    val Ink = Color(0xFF17191B)
    val Quiet = Color(0xFF29292D)
    val Green = Color(0xFF318657)
    val GreenInk = Color(0xFF103C26)
    val Badge = Color(0xFFA3C9AE)
    val Track = Color(0x260E1012)
}

@Composable
internal fun Modifier.deedMatte(shape: Shape, raised: Boolean = false): Modifier = this
    .then(if (raised) Modifier.shadow(3.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = .24f), spotColor = Color.Black.copy(alpha = .27f)) else Modifier)
    .frostGlass(rememberFrost(), shape, halo = false, style = GlassStyle.DEED)

@Composable
internal fun DeedCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().deedMatte(RoundedCornerShape(uiScale().s(24f))), content = content)
}

@Composable
internal fun DeedHeading(title: String) {
    val ui = uiScale()
    Text(title, Modifier.padding(top = LocalIslandInset.current).padding(start = ui.s(26f), end = ui.s(23f), bottom = ui.s(12f), top = ui.s(12f)),
        fontSize = ui.t(28f), lineHeight = ui.t(34f), fontWeight = FontWeight.Bold, color = Color.White)
}
