package com.nur.prayer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.ui.wallpaper.deedsWindowWash
import kotlin.math.abs
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class WindowWashTest {
    @get:Rule val compose = createComposeRule()

    @Test fun photoWashCoversPixelsOnBothSidesOfStatusInsetAndLeavesNoResidueOnHome() {
        val k = mutableFloatStateOf(1f)
        val barPx = 36
        compose.setContent {
            Box(Modifier.size(160.dp, 320.dp).deedsWindowWash(true, { k.floatValue }, WindowInsets(0, barPx, 0, 0))
                .background(Color.White))
        }
        val pixels = compose.onRoot().captureToImage().toPixelMap()
        val x = minOf(10, pixels.width / 2)
        val upper = pixels[x, barPx - 1]; val lower = pixels[x, barPx + 1]
        assertTrue(upper.red < .55f && lower.red < .55f)
        assertTrue(abs(upper.red - lower.red) < .035f)
        compose.runOnIdle { k.floatValue = 0f }
        val home = compose.onRoot().captureToImage().toPixelMap()
        assertTrue(home[x, 1].red > .99f && home[x, barPx + 1].red > .99f)
    }
}
