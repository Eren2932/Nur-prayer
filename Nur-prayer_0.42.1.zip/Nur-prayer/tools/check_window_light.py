#!/usr/bin/env python3
"""Bound the sRGB contrast of the real draw constants. Not an Android rendering test."""
from pathlib import Path
import re

U = Path(__file__).resolve().parents[1] / 'app/src/main/java/com/nur/prayer/ui'

def rgba(h):
    a, r, g, b = bytes.fromhex(h)
    return (r, g, b), a / 255

def over(fg, bg):
    rgb, a = fg
    return tuple(a*x+(1-a)*y for x,y in zip(rgb,bg))

def lum(rgb):
    def linear(c):
        v = c/255
        return v / 12.92 if v <= .04045 else ((v+.055)/1.055)**2.4
    return sum(linear(c)*w for c,w in zip(rgb,(.2126,.7152,.0722)))

def ratio(a,b):
    l,h=sorted((lum(a),lum(b)))
    return (h+.05)/(l+.05)

def take(text, pattern):
    return re.search(pattern,text).group(1)

def named(text,name):
    return rgba(take(text, rf'val {name} = Color\(0x(\w{{8}})\)'))

if __name__=='__main__':
    shell=(U/'shell/NavCapsule.kt').read_text().split('internal object TimerInk {')[1]; surface=named(shell,'Surface')
    white=(255,255,255); black=(0,0,0)
    # Componentwise monotonic sRGB: white provides the highest possible luminance of the timer body.
    for name in ('Time','Label','Icon'):
        c=ratio(over(surface,white),named(shell,name)[0]);print(f'timer {name}: >= {c:.2f}:1');assert c>=4.5
    wash=(U/'wallpaper/DeedsWindowWash.kt').read_text()
    stops=re.findall(r'(?:0f|barEnd) to \(if \(top > 0f\) Color\(0x([A-Fa-f0-9]{8})\)',wash)
    assert len(stops)==2
    c=min(ratio(white,over(rgba(v),white)) for v in stops);print(f'status glyphs on fully washed photo: >= {c:.2f}:1');assert c>=4.5
    frost=(U/'shell/Frost.kt').read_text().split('} else if (style == GlassStyle.DEED) {')[1].split('} else if (style == GlassStyle.MATTE)')[0]
    rgb,opacity=re.search(r'drawRect\(Color\(0x(\w{8})\), alpha = (\.\d+)f\)',frost).groups();body=over((rgba(rgb)[0],float(opacity)),black)
    plain,alpha=re.search(r'drawRect\(Color\(0x(\w{8})\), alpha = (\.\d+)f\)',frost.split('} else {')[1]).groups();fallback=over((rgba(plain)[0],float(alpha)),black)
    matte=(U/'today/DeedMaterial.kt').read_text();assert '.border(' not in matte
    for name in ('Ink','Quiet'):
        c=min(ratio(bg,named(matte,name)[0]) for bg in (body,fallback));print(f'deed {name}: >= {c:.2f}:1');assert c>=4.5
