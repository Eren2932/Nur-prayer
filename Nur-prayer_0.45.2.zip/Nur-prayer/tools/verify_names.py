#!/usr/bin/env python3
"""Check name-to-bookmark identity, editorial fields and the shipped Quran verses offline.
Mechanical validation is not theological review.
"""
import csv
import unicodedata
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1] / 'app/src/main/assets'

def read(p):
    with p.open(encoding='utf-8') as f:
        return list(csv.DictReader(f, delimiter='\t', quoting=csv.QUOTE_NONE))

def norm(s):
    return ''.join(c for c in s if unicodedata.category(c) != 'Mn' and c != 'ـ').translate(str.maketrans('أإآٱ','اااا'))

def verify():
    rows = read(ROOT/'names/ru.tsv'); assert len(rows) == 99
    assert [int(r['id']) for r in rows] == list(range(1,100))
    assert tuple(rows[0]) == ('id','ar','reading','gloss','headline','senses','note','verse')
    for key in ('ar','reading','gloss','headline','senses','note'):
        assert all(r[key].strip() for r in rows)
    assert len({norm(r['ar']) for r in rows}) == len({r['reading'] for r in rows}) == 99
    assert len({r['note'] for r in rows}) == 99 and all(len(r['note']) >= 100 and r['gloss'] != r['senses'] for r in rows)
    for row in rows:
        title = row['headline']; note = row['note']; parts = note.split(r'\n\n')
        assert title == title.strip() and not any(c in title for c in ('\\','|','¶')), row['id']
        assert all(part.strip() and '\\' not in part and '¶' not in part for part in parts), row['id']
    # The Arabic sequence, not an alphabetical dictionary. Two explicit spelling variants.
    ref = Path(__file__).with_name('names_ref').joinpath('tirmidhi-3507.txt').read_text().splitlines()
    spellings = {'الحى':'الحي', 'الرءوف':'الرؤوف'}
    # Keep both the vowel evidence and a separate identity check against the older bare keys.
    vocalized = Path(__file__).with_name('names_ref').joinpath('tirmidhi-3507-vocalized.txt').read_text().splitlines()
    display_forms = {'الْحَىُّ':'الْحَيُّ', 'الرَّءُوفُ':'الرَّؤُوفُ'}
    assert [r['ar'] for r in rows] == [display_forms.get(s,s) for s in vocalized]
    assert all(any(unicodedata.category(c) == 'Mn' for c in s) for s in vocalized)
    assert [''.join(c for c in r['ar'] if unicodedata.category(c) != 'Mn') for r in rows] == [spellings.get(s,s) for s in ref]
    forms = {78:'المتعال', 83:'لرءوف'}
    count=0
    for r in rows:
        if r['verse'] == '-': continue
        s,a = map(int,r['verse'].split(':')); v=next(x for x in read(ROOT/f'quran/{s:03d}.tsv') if int(x['ayah']) == a)
        name=norm(r['ar']); bare=name.removeprefix('ال'); ar=norm(v['arabic']); tokens=ar.split()
        choices={name,bare,bare+'ا',forms.get(int(r['id']),name)};choices |= {'و'+t for t in choices}
        assert any((' '+t+' ') in (' '+' '.join(tokens)+' ') for t in choices), (r['reading'],r['verse'],ar)
        assert v['ru'].strip();count+=1
    assert count == 68
    print(f'99 names / 99 ordered Arabic headwords (Tirmidhi 3507); {count} verse links checked against the actual Arabic and Russian assets.')

if __name__=='__main__': verify()
