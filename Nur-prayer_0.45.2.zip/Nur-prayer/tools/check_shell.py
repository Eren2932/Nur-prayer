#!/usr/bin/env python3
"""0.27.0 «Капсула»: a mirror of ShellMath.kt, checked in CI without a JVM.
0.33.0 «Минарет»: the glass is the mock's light cream; the checks that spoke of the old dark glass
(tint over a white wallpaper, 10-18 % hairline) are replaced by the ones that matter for cream and dark ink:
contrast of every text and icon colour, the roof's curve, the section glyphs and the speaker of the cards.
0.36.0 «Бумага»: the roof is gone, the glass is flat paper white (#FAFAFA), "now" is lavender and the capsule wears
the tone of where the user is (ShellTones). The checks follow: paper colours and their contrast, the white glyph on
every section disc, the capsule's ink on its pastel disc.

0.39.0 «Капля»: the panel is a compact slab (no times, no cards): the checks of the cards, the speakers and the lavender
«now» are gone; in their place the matte glass (its tone and the ink's contrast on it, lightest and darkest), the drop's
curves and the panel's grid.

The Kotlin numbers are read from the source, so the mirror cannot silently drift from it.
"""
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SHELL = ROOT / 'app/src/main/java/com/nur/prayer/ui/shell'
SRC = (SHELL / 'ShellState.kt').read_text()
FROST = (SHELL / 'Frost.kt').read_text()
CAPS = (SHELL / 'NavCapsule.kt').read_text()
TIMES = (SHELL / 'PanelTimes.kt').read_text()
PANEL = (SHELL / 'PanelLayout.kt').read_text()
GLYPHS = (SHELL / 'ShellGlyphs.kt').read_text()
DATA = (SHELL / 'ShellIconData.kt').read_text()
TONES = (SHELL / 'ShellTones.kt').read_text()
SECTION = (ROOT / 'app/src/main/java/com/nur/prayer/ui/home/HomeSection.kt').read_text()


def num(pattern, what, text=SRC, name='ShellState.kt'):
    m = re.search(pattern, text)
    if not m: sys.exit('check_shell: %s not found in %s' % (what, name))
    return float(m.group(1))


CAP_END = num(r'capsuleAlpha\(p: Float\): Float = \(1f - p / ([0-9.]+)f\)', 'capsuleAlpha')
PAN_START = num(r'panelAlpha\(p: Float\): Float = \(\(p - ([0-9.]+)f\)', 'panelAlpha start')
PAN_SPAN = num(r'panelAlpha\(p: Float\): Float = \(\(p - [0-9.]+f\) / ([0-9.]+)f\)', 'panelAlpha span')
OVER = num(r'coerceIn\(0f, ([0-9.]+)f\)', 'clampProgress')
DAMP = num(r'OPEN_DAMPING = ([0-9.]+)f', 'OPEN_DAMPING')

clamp = lambda v: min(max(v, 0.0), 1.0)
cap = lambda p: clamp(1 - p / CAP_END)
pan = lambda p: clamp((p - PAN_START) / PAN_SPAN)

errors = []

# --- the morph -------------------------------------------------------------------------------------------------
# Never two layers of text at once: the capsule is (almost) gone before the panel shows.
worst = max(cap(i / 1000) + pan(i / 1000) for i in range(0, int(OVER * 1000) + 1))
if worst > 1.0001: errors.append('capsule and panel text overlap: %.3f' % worst)
if not (0.2 <= CAP_END <= 0.4): errors.append('capsule text must leave in the first third, got %.2f' % CAP_END)
if not (PAN_START + PAN_SPAN <= 0.9): errors.append('panel text must be fully in before the spring settles')
if not (1.0 < OVER <= 1.05): errors.append('overshoot bound must be small, got %.2f' % OVER)
if not (0.7 <= DAMP < 1.0): errors.append('open spring: a hint of bounce, not a wobble (damping %.2f)' % DAMP)
if re.search(r'\bROOF_|roofHeightPx|MinaretRoof|HeaderOrnament', SRC + CAPS + FROST):
    errors.append('0.36.0: the roof is gone; nothing may still speak of it')
FILL_DONE = num(r'const val FILL_DONE_AT = ([0-9.]+)f', 'FILL_DONE_AT')
# 0.37.0: the veil of the bar's glass must be paper by the time the panel's text has any weight.
if not (FILL_DONE <= PAN_START + 0.1 and FILL_DONE >= 0.2): errors.append('the veil must be paper where the panel text begins, got FILL_DONE_AT %.2f' % FILL_DONE)
if re.search(r'CAPSULE_SHARE|capsuleWidth|CAPSULE_MIN_WIDTH|CAPSULE_MAX_WIDTH', SRC + CAPS + FROST):
    errors.append('0.37.0: the capsule is a bar of buttons; nothing may still size it as a pill by the screen width')


# --- colours: the mock's paper white, near-black ink, lavender "now" --------------------------------------------------------------
def colors_of(text, obj):
    m = re.search(r'(?:internal )?object %s \{(.*?)\n\}' % obj, text, re.S)
    if not m: sys.exit('check_shell: object %s not found' % obj)
    out = {}
    for name, v in re.findall(r'val (\w+) = Color\(0x([0-9A-Fa-f]{8})\)', m.group(1)):
        v = int(v, 16)
        out[name] = (((v >> 24) & 255) / 255.0, (v >> 16) & 255, (v >> 8) & 255, v & 255)
    # 0.36.0: aliases (val Label = Ink) are the same colour under another name.
    for name, ref in re.findall(r'val (\w+) = ([A-Z]\w*)\s*$', m.group(1), re.M):
        if ref in out: out[name] = out[ref]
    return out


C = colors_of(FROST, 'ShellColors')


def over(fg, bg):
    """Colour fg (alpha, r, g, b) laid over the opaque bg (alpha, r, g, b)."""
    a = fg[0]
    return (1.0,) + tuple(a * fg[i] + (1 - a) * bg[i] for i in (1, 2, 3))


def luma(c):
    def lin(v):
        v /= 255.0
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126 * lin(c[1]) + 0.7152 * lin(c[2]) + 0.0722 * lin(c[3])


def contrast(fg, bg):
    fg = over(fg, bg)
    a, b = luma(fg), luma(bg)
    return (max(a, b) + 0.05) / (min(a, b) + 0.05)


def need(name):
    if name not in C: sys.exit('check_shell: ShellColors.%s not found' % name)
    return C[name]


glass = need('Glass')
if glass[0] != 1.0: errors.append('ShellColors.Glass must be opaque: it is the flat paper of the island and of the panel over a white page')
if luma(glass) < 0.55: errors.append('ShellColors.Glass is not light (luminance %.2f)' % luma(glass))
# The paper is white, not cream: no channel may lean warm by more than a few levels.
if max(glass[1:]) - min(glass[1:]) > 6: errors.append('ShellColors.Glass must be neutral white, not cream')
# (foreground, background, minimum contrast): text 4.5, big text and the ink of icons 3
PAIRS = [
    ('Ink', 'Glass', 7.0), ('Secondary', 'Glass', 4.5), ('Icon', 'Glass', 4.5),
    ('PanelInk', 'Glass', 7.0), ('GearInk', 'Glass', 7.0),
]
for fg, bg, floor in PAIRS:
    r = contrast(need(fg), need(bg))
    if r < floor: errors.append('%s on %s: contrast %.2f, needs %.1f' % (fg, bg, r, floor))
# 0.39.0 the matte glass of the panel: the owner's mock is (185, 183, 186) over a near-black picture; on the lightest
# picture (white, dimmed by PICTURE_DIM) it must still carry the labels and the settings icon at 7:1.
MATTE = re.search(r'internal object MatteGlass \{(.*?)\n\}', FROST, re.S)
if not MATTE: sys.exit('check_shell: object MatteGlass not found')
MATTE = MATTE.group(1)
tint = re.search(r'val Tint = Color\(0x([0-9A-Fa-f]{8})\)', MATTE)
if not tint: sys.exit('check_shell: MatteGlass.Tint not found')
tv = int(tint.group(1), 16)
TINT = (1.0, (tv >> 16) & 255, (tv >> 8) & 255, tv & 255)
T_ALPHA = num(r'const val TINT_ALPHA = ([0-9.]+)f', 'MatteGlass.TINT_ALPHA', MATTE, 'Frost.kt')
T_PLAIN = num(r'const val TINT_PLAIN_ALPHA = ([0-9.]+)f', 'MatteGlass.TINT_PLAIN_ALPHA', MATTE, 'Frost.kt')
DIM = num(r'const val PICTURE_DIM = ([0-9.]+)f', 'PICTURE_DIM')
def matte(picture_level, alpha=T_ALPHA):
    base = (1.0,) + (picture_level * (1 - DIM),) * 3
    return over((alpha, TINT[1], TINT[2], TINT[3]), base)
dark_matte, light_matte = matte(0.0), matte(255.0)
mock = (185, 183, 186)
if any(abs(dark_matte[i + 1] - mock[i]) > 3 for i in range(3)):
    errors.append('the matte over black is %s, the mock\'s slab is %s' % (tuple(round(v) for v in dark_matte[1:]), mock))
for who in ('PanelInk', 'GearInk'):
    for label, bg in (('lightest', light_matte), ('darkest', dark_matte), ('no picture, lightest page', matte(255.0, T_PLAIN))):
        r = contrast(need(who), bg)
        if r < 7.0: errors.append('%s on the matte glass (%s): contrast %.2f, needs 7.0' % (who, label, r))
if not (0.6 <= T_ALPHA <= 0.85 and T_ALPHA <= T_PLAIN <= 0.9): errors.append('matte tints out of range: %.3f / %.3f' % (T_ALPHA, T_PLAIN))
# The bar's veil. 0.38.0: on home the round buttons are really transparent (black at 3-15 %, the picture shows through);
# inside a section the page under the bar may be white paper, so there the buttons keep 0.37.0's firmer veil
# (BarGlassPage, black at 30-60 %), and the white ink must keep 3:1 on it even over a white page, the worst case.
veil, page_veil, ring, ink = need('BarGlass'), need('BarGlassPage'), need('BarRing'), need('BarInk')
if not (0.03 <= veil[0] <= 0.15 and veil[1:] == (0, 0, 0)): errors.append('ShellColors.BarGlass must be black at 3-15 %')
if not (0.3 <= page_veil[0] <= 0.6 and page_veil[1:] == (0, 0, 0)): errors.append('ShellColors.BarGlassPage must be black at 30-60 %')
for page in ((1.0, 255, 255, 255), (1.0, 243, 234, 211)):
    r = contrast(ink, over(page_veil, page))
    if r < 3.0: errors.append('BarInk on BarGlassPage over page %s: contrast %.2f, needs 3.0' % (page[1:], r))
    r = contrast(ring, over(page_veil, page))
    if r < 3.0: errors.append('BarRing on BarGlassPage over page %s: contrast %.2f, needs 3.0' % (page[1:], r))
# The pill «Учёба» (0.38.0): dark ink on light grey, readable also at the glint's brightest.
pill_fill, pill_ink, glint = need('PillFill'), need('PillInk'), need('PillGlint')
if contrast(pill_ink, pill_fill) < 7.0: errors.append('PillInk on PillFill: contrast %.2f, needs 7.0' % contrast(pill_ink, pill_fill))
PILL = (SHELL / 'PillShimmer.kt').read_text()
peak = num(r'const val PEAK_ALPHA = ([0-9.]+)f', 'PEAK_ALPHA', PILL, 'PillShimmer.kt')
lit = over((peak, glint[1], glint[2], glint[3]), pill_fill)
if contrast(pill_ink, lit) < 7.0: errors.append('PillInk at the glint\'s peak: contrast %.2f, needs 7.0' % contrast(pill_ink, lit))
# The glint is rarer than in the owner's clip (a pass of 0.4 s every 1.6 s) and its strip is not slower.
cycle = num(r'const val CYCLE_MS = (\d+)', 'CYCLE_MS', PILL, 'PillShimmer.kt')
sweep = num(r'const val SWEEP_MS = (\d+)', 'SWEEP_MS', PILL, 'PillShimmer.kt')
if not (3200 <= cycle <= 4800): errors.append('PillShimmer.CYCLE_MS %d: the passes must be 2-3 times rarer than the clip\'s 1600 ms' % cycle)
if not (400 <= sweep <= 533): errors.append('PillShimmer.SWEEP_MS %d: the strip must keep the clip\'s speed (400-533 ms a pass)' % sweep)
# The bar's geometry (0.38.0, measured on the reference): 35.5 dp high, a 95 dp pill, one gap, the middle one centred.
LAYOUT = (SHELL / 'BarLayout.kt').read_text()
button = num(r'const val BUTTON = ([0-9.]+)f', 'BarLayout.BUTTON', LAYOUT, 'BarLayout.kt')
gap = num(r'const val GAP = ([0-9.]+)f', 'BarLayout.GAP', LAYOUT, 'BarLayout.kt')
pill_w = num(r'const val PILL_WIDTH = ([0-9.]+)f', 'BarLayout.PILL_WIDTH', LAYOUT, 'BarLayout.kt')
if abs(button - 35.5) > 0.3 or abs(pill_w - 95) > 0.5 or abs(gap - 33) > 0.7:
    errors.append('BarLayout: %.1f / %.1f / %.1f dp is not the reference\'s 35.5 / 95 / 33' % (button, pill_w, gap))
if 'fun middleStart' not in LAYOUT or '(width - BUTTON) / 2f' not in LAYOUT:
    errors.append('BarLayout.middleStart must centre the middle button')
# The panel's grid no longer holds «Учёба» (it is the bar's pill) nor the Quran.
grid = re.search(r'val GRID: List<HomeSection> = listOf\(([^)]*)\)', SECTION)
if not grid or [x.strip() for x in grid.group(1).split(',')] != ['DHIKR', 'QIBLA', 'TODAY', 'SCHEDULE']:
    errors.append('HomeSection.GRID must be DHIKR, QIBLA, TODAY, SCHEDULE')

# --- tones: white glyph on every disc, the capsule's ink on its pastel -------------------------------------------
def hexc(h):
    v = int(h, 16)
    return (1.0, (v >> 16) & 255, (v >> 8) & 255, v & 255)
def mix(a, b, t):
    return (1.0,) + tuple(a[i] + (b[i] - a[i]) * t for i in (1, 2, 3))
PASTEL = num(r'const val PASTEL = ([0-9.]+)f', 'ShellTones.PASTEL', TONES, 'ShellTones.kt')
INK_SHADE = num(r'const val INK_SHADE = ([0-9.]+)f', 'ShellTones.INK_SHADE', TONES, 'ShellTones.kt')
pw = re.search(r'PASTEL_WHITE = Color\(0xFF([0-9A-Fa-f]{6})\)', TONES)
if not pw: sys.exit('check_shell: ShellTones.PASTEL_WHITE not found')
PW = hexc(pw.group(1))
WHITE, BLACK = (1.0, 255, 255, 255), (1.0, 0, 0, 0)
tones = re.findall(r'val (\w+) = of\(Color\(0xFF([0-9A-Fa-f]{6})\)(?:, container = Color\(0xFF([0-9A-Fa-f]{6})\))?\)', TONES)
if len(tones) < 9: errors.append('ShellTones: expected seven sections and two azkar tones, got %d' % len(tones))
for name, well, cont in tones:
    w = hexc(well)
    c = hexc(cont) if cont else mix(w, PW, PASTEL)
    ink = mix(w, BLACK, INK_SHADE)
    if name not in ('MORNING',) and contrast(WHITE, w) < 2.5:
        errors.append('ShellTones.%s: the white glyph on the disc, contrast %.2f, needs 2.5' % (name, contrast(WHITE, w)))
    if contrast(ink, c) < 4.5: errors.append('ShellTones.%s: capsule ink on its pastel, contrast %.2f, needs 4.5' % (name, contrast(ink, c)))
    if luma(c) < 0.35: errors.append('ShellTones.%s: the capsule disc must be pastel (luminance %.2f)' % (name, luma(c)))

# --- the glass is flat: no per-frame work while the shape morphs ----------------------------------------------------
if 'shadow(' in FROST or 'clipPath' in FROST or 'elevation' in FROST.replace('elevation shadow', ''):
    errors.append('Frost.kt: no elevation shadow and no path clip: they rebuild every frame while the shape morphs')
if re.search(r'if \((panelComposed|capsuleComposed)\) (CapsuleContent|PanelContent)', CAPS):
    errors.append('NavCapsule.kt: both faces of the capsule stay composed; opening must not compose the panel')
if 'CompositingStrategy.ModulateAlpha' not in CAPS: errors.append('NavCapsule.kt: layers fade per draw call, not in an offscreen buffer')
if 'object SheetGlass' not in FROST: errors.append('Frost.kt: the prayer sheet keeps its dark glass (SheetGlass)')

# --- the glyphs --------------------------------------------------------------------------------------------------
paths = re.findall(r'GlyphLayer\(1\.0f, false, "([^"]*)"\)', DATA)
names = re.findall(r'    val (\w+) = ShellIconArt\(', DATA)
if names != ['QURAN', 'DHIKR', 'QIBLA', 'TODO', 'MONTH'] or len(paths) != 5:
    errors.append('ShellIconData: expected QURAN, DHIKR, QIBLA, TODO, MONTH (the sixth, study, is the letter ع), got %s' % names)
if 'ShellGlyph.AIN' not in SECTION: errors.append('HomeSection.COURSE must wear ShellGlyph.AIN (the letter ع)')
if 'ShellGlyph.CAP' in SECTION + CAPS + GLYPHS or 'STUDY' in GLYPHS + DATA:
    errors.append('the graduation cap is gone: «Учёба» is the letter ع')
if 'ArabicFont.paintTypeface()' not in GLYPHS or 'private const val AIN_TEXT = "\u0639"' not in GLYPHS:
    errors.append('ShellGlyphs.kt: ع is set in the mushaf face (ArabicFont) from U+0639')
# One glyph, one box: the letter is exactly as tall as its box and its weight is a share of it.
w = num(r'object AinFit \{\s*const val WEIGHT = ([0-9.]+)f', 'AinFit.WEIGHT', GLYPHS, 'ShellGlyphs.kt')
if not (0.03 <= w <= 0.08): errors.append('AinFit.WEIGHT %.3f: the letter must carry about the weight of the drawn glyphs' % w)

# --- the panel (0.39.0 «Капля») ----------------------------------------------------------------------------------
if re.search(r'PRAYERS: List<Prayer> = listOf\(([^)]*)\)', TIMES) is None:
    errors.append('PanelTimes.PRAYERS not found (home prints the six times in this order)')
else:
    got = re.findall(r'Prayer\.(\w+)', re.search(r'PRAYERS: List<Prayer> = listOf\(([^)]*)\)', TIMES).group(1))
    if got != ['FAJR', 'SUNRISE', 'DHUHR', 'ASR', 'MAGHRIB', 'ISHA']: errors.append('home prints the six times in this order, got %s' % got)
if 'fun callOn(' not in TIMES: errors.append('PanelTimes.callOn: one rule for "this card has a call" (sunrise never has)')
if re.search(r'PanelTimes|TimeCard|onOpenPrayer|SPEAKER', CAPS):
    errors.append('0.39.0: the panel holds the sections and the settings only: no times, no cards, no speakers')
if 'ShellGlyph.GEAR' not in CAPS or 'GEAR' not in GLYPHS: errors.append('the settings icon is our own gear (ShellGlyph.GEAR)')
if 'TUNE' in GLYPHS + CAPS: errors.append('the mock\'s sliders are gone: the settings icon is the gear')
# The drop: the width is whole before the height is half done; cells whole before the spring settles.
REACH = num(r'const val REACH_DONE_AT = ([0-9.]+)f', 'REACH_DONE_AT')
RISE = num(r'const val RISE_START_AT = ([0-9.]+)f', 'RISE_START_AT')
C_START = num(r'const val CELL_START = ([0-9.]+)f', 'CELL_START')
C_STAG = num(r'const val CELL_STAGGER = ([0-9.]+)f', 'CELL_STAGGER')
C_SPAN = num(r'const val CELL_SPAN = ([0-9.]+)f', 'CELL_SPAN')
GEAR_RANK = num(r'const val GEAR_RANK = (\d+)', 'PanelLayout.GEAR_RANK', PANEL, 'PanelLayout.kt')
if not (0.4 <= REACH <= 0.8 and 0.1 <= RISE <= 0.4 and RISE < REACH): errors.append('the drop: width done at %.2f, height starts at %.2f' % (REACH, RISE))
if C_START + GEAR_RANK * C_STAG + C_SPAN > 0.85: errors.append('the last cell must be whole before the spring settles')
if C_START < RISE: errors.append('cells must not show before the glass has begun to rise')
# The panel's grid, measured on the mock (393 dp).
def pl(name):
    return num(r'const val %s = ([0-9.]+)f' % name, 'PanelLayout.' + name, PANEL, 'PanelLayout.kt')
SIDE, MAXW, H, CORNER, REFW = pl('SIDE'), pl('MAX_WIDTH'), pl('HEIGHT'), pl('CORNER'), pl('REFERENCE_WIDTH')
if abs((393 - 2 * SIDE) - REFW) > 0.6: errors.append('the slab at 393 dp is %.1f, the mock\'s is %.1f' % (393 - 2 * SIDE, REFW))
if not (88 <= H <= 94): errors.append('the slab is %.1f dp high, the mock\'s is 90.8' % H)
if not (CORNER < H / 2): errors.append('the corner must be a slab\'s, not a pill\'s')
if not (35 <= pl('DISC') <= 40): errors.append('the disc is %.1f dp, the mock\'s is 37.5' % pl('DISC'))
if abs(pl('LABEL_BASELINE') - pl('DISC_TOP') - pl('DISC') - 19.1) > 0.3: errors.append('the label must stand 19.1 dp under the disc')
grid_end = REFW - pl('GRID_START') - 4 * pl('CELL')
if abs(grid_end - 62.4) > 0.2: errors.append('the grid end is %.1f dp, expected 62.4' % grid_end)
for screen in (320, 360, 393, 430, 600, 840):
    w = max(min(screen - 2 * SIDE, MAXW), 0)
    cell = (w - pl('GRID_START') - grid_end) / 4
    cells_end = pl('GRID_START') + 4 * cell
    gear_left = w - pl('GEAR_FROM_END') - pl('GEAR_HIT') / 2
    if cell < 48: errors.append('%d dp: a cell is %.1f dp, a label does not fit' % (screen, cell))
    if gear_left < cells_end: errors.append('%d dp: the settings overlap the cells' % screen)

if errors:
    print('\n'.join('check_shell: ' + e for e in errors)); sys.exit(1)
print('check_shell: ok (overlap %.3f, capsule out by %.2f, panel in by %.2f, %d colour pairs, %d tones)' % (worst, CAP_END, PAN_START + PAN_SPAN, len(PAIRS), len(tones)))
