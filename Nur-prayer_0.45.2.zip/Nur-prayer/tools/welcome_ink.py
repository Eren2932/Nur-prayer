"""Offline authoring/QA for the welcome lettering. Pillow + numpy; neither is an app dependency.
Build: python tools/welcome_ink.py build ; visual invariants: python tools/welcome_ink.py check
The alpha-only silver tile is NOT a frame or a mask of the letters. It wraps on BOTH axes.
"""
from pathlib import Path
import sys
import re
import numpy as np
from PIL import Image
ROOT = Path(__file__).resolve().parents[1]
D = ROOT/'app/src/main/res/drawable-nodpi'
W,H = 405,196
RGB = np.array([114,127,147])
# The offline movie and checks consume the shipped renderer’s timings, offsets and strength.
source=(ROOT/'app/src/main/java/com/nur/prayer/ui/welcome/WelcomeGreeting.kt').read_text()
def constant(name):
    return int(re.search(r'const val '+name+r' = ([0-9_]+)[Lf]?\b',source)[1].replace('_',''))
T1,T2=[constant(key)/1.e9 for key in ('PRIMARY_NS','SECONDARY_NS')]
OX,OY,OPACITY=[constant(key) for key in ('SECONDARY_X','SECONDARY_Y','SECONDARY_ALPHA')]

def author_tile():
    y,x = np.indices((H,W)); u=(x+.5)/W; v=(y+.5)/H; k=2*np.pi
    # Curved local folds, not a vertical scan or a left-to-right index of glyphs.
    bend=.24*np.sin(k*(u+v)-.58)-.22*np.cos(k*(2*u-v)+.7)+.087*np.sin(k*(u-2*v))
    fold=np.cos(k*(3*u+v+bend)-.45)
    a=np.clip((fold-.22)/.78,0,1); a=a*a*(3-2*a)
    depth=.70+.22*(.5+.5*np.cos(k*(2*u-v)+.65))
    rgba=np.empty((H,W,4),np.uint8); rgba[:,:,:3]=RGB; rgba[:,:,3]=np.rint(255*a*depth)
    return rgba

def load():
    tile=np.array(Image.open(D/'welcome_silver.webp').convert('RGBA'))
    alpha=np.array(Image.open(D/'welcome_letters.webp').convert('RGBA'))[:,:,3]
    return alpha,tile[:,:,3].astype(np.float32)/255

def sample(tile,dx,dy):
    # BitmapShader(REPEAT, REPEAT) + bilinear interpolation of translated texel centres.
    ix,iy=int(np.floor(dx)),int(np.floor(dy)); fx,fy=dx-ix,dy-iy
    def move(x,y): return np.roll(tile,(y,x),(0,1))
    return (1-fy)*((1-fx)*move(ix,iy)+fx*move(ix+1,iy))+fy*((1-fx)*move(ix,iy+1)+fx*move(ix+1,iy+1))

def shade(tile,t):
    a=(t%T1)/T1; b=(t%T2)/T2
    primary=sample(tile,W*a,H*a)
    secondary=sample(tile,OX-W*b,OY+H*b)*(OPACITY/255)
    return 1-(1-primary)*(1-secondary)

def rgb(tile,t): return np.rint(255-shade(tile,t)[:,:,None]*(255-RGB)).astype(np.uint8)

if __name__=='__main__':
    expected=author_tile(); path=D/'welcome_silver.webp'
    if sys.argv[1:]==['build']: Image.fromarray(expected).save(path,lossless=True,method=6)
    elif sys.argv[1:]!=['check']: sys.exit('Usage: welcome_ink.py build|check')
    alpha,tile=load(); assert np.array_equal(np.rint(tile*255).astype(np.uint8),expected[:,:,3])
    white=np.array(Image.open(ROOT/'art/welcome/lettering_white.webp').convert('RGBA')); assert np.array_equal(white[:,:,3],alpha)
    actual=np.array(Image.open(D/'welcome_letters.webp').convert('RGBA')); assert (actual[:,:,:3][alpha>0]==255).all()
    actual_tile=np.array(Image.open(path).convert('RGBA')); assert (actual_tile[:,:,:3][expected[:,:,3]>0]==RGB).all()
    y,x=np.indices(alpha.shape); opaque=alpha==255
    top=opaque&(y<90); bottom=opaque&(y>=117); extrema=[np.ones_like(tile),np.zeros_like(tile)]
    rows=[]; groups=[]
    for t in np.arange(0,96,.25):
        s=shade(tile,t); np.minimum(extrema[0],s,out=extrema[0]); np.maximum(extrema[1],s,out=extrema[1]);
        for mask in (top,bottom):
            rows.append([(s[mask]>.31).mean(),(s[mask]<.055).mean()]); islands=sum((s[region]>.37).mean()>.07 for zone in range(4) if (region:=mask&(x>=zone*92)&(x<(zone+1)*92)).any()); groups.append(islands)
    rows=np.array(rows); print('Both rows: min/max toned, near-white:',rows.min(0),rows.max(0),'quadrants with silver:',min(groups),max(groups)); print('worst pixel: least / most tone attained',extrema[0][opaque].max(),extrema[1][opaque].min())
    assert min(groups)>=2 and rows.min(0)[0]>.11 and rows.min(0)[1]>.055
    assert np.all(extrema[0][opaque]<.025) and np.all(extrema[1][opaque]>.55)
    assert np.array_equal(rgb(tile,0),rgb(tile,96)) and np.abs(shade(tile,96-1.e-5)-shade(tile,0)).max()<.0001
    print('PASS: independent 24/32 s wraps, no blank rows/no permanent dark ink, silhouette preserved.')
