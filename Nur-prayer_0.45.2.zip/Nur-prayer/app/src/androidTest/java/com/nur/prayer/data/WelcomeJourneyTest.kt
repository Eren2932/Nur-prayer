package com.nur.prayer.data

import android.content.Context
import androidx.compose.ui.test.ExperimentalTestApi
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performImeAction
import androidx.compose.ui.test.performTextInput
import androidx.datastore.preferences.core.emptyPreferences
import androidx.lifecycle.ViewModelProvider
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.Graph
import com.nur.prayer.MainActivity
import com.nur.prayer.ui.AppEntry
import com.nur.prayer.ui.AppViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeFalse
import com.nur.prayer.location.LocationRequestStep
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Uses the real activity, catalog, settings transaction and schedule. No location hardware needed. */
@OptIn(ExperimentalTestApi::class)
@RunWith(AndroidJUnit4::class)
class WelcomeJourneyTest {
    @get:Rule val compose = createEmptyComposeRule()
    private val context: Context get() = ApplicationProvider.getApplicationContext()

    private fun withEmptyPlace(test: () -> Unit) {
        val store = context.dataStore
        val previous = runBlocking { store.data.first() }
        try {
            runBlocking { store.updateData { emptyPreferences() } }
            test()
        } finally { runBlocking { store.updateData { previous } } }
    }

    private fun waitForTag(tag: String) {
        compose.waitUntil(15_000) {
            compose.onAllNodesWithTag(tag).fetchSemanticsNodes().isNotEmpty() &&
                compose.onAllNodesWithTag("nur-launch").fetchSemanticsNodes().isEmpty()
        }
    }

    private fun model(scenario: ActivityScenario<MainActivity>): AppViewModel {
        lateinit var result: AppViewModel
        scenario.onActivity { result = ViewModelProvider(it)[AppViewModel::class.java] }
        return result
    }

    @Test fun manualChoiceSurvivesANewActivityWithoutWelcomeOrGps() = withEmptyPlace {
        // Choosing the default, Moscow, would not detect an accidental fallback after restart.
        val city = Graph.cities(context).search("ташкент").first { it.name == "Ташкент" }
        ActivityScenario.launch(MainActivity::class.java).use { activity ->
            val vm = model(activity)
            waitForTag("welcome-manual")
            assertEquals(AppEntry.Welcome, vm.entry.value)
            compose.onNodeWithContentDescription("Ассаламу алейкум").assertIsDisplayed()
            compose.onNodeWithTag("welcome-manual").performClick()
            compose.onNodeWithText("Назад").performClick()
            compose.onNodeWithTag("welcome-manual").performClick()
            compose.onNodeWithContentDescription("Поиск города").performTextInput("ташкент")
            compose.onNodeWithContentDescription("Поиск города").performImeAction()
            val tag = "city-row-${city.id}"
            waitForTag(tag)
            activity.recreate()
            waitForTag(tag)
            compose.onNodeWithTag(tag).performClick()
            compose.waitUntil(15_000) { vm.entry.value is AppEntry.Home }
            compose.onNodeWithTag("welcome-detect").assertDoesNotExist()
            assertFalse((vm.entry.value as AppEntry.Home).schedule.place.fromDeviceLocation)
        }
        ActivityScenario.launch(MainActivity::class.java).use { activity ->
            val vm = model(activity)
            compose.waitUntil(15_000) { vm.entry.value is AppEntry.Home }
            val saved = (vm.entry.value as AppEntry.Home).schedule
            assertEquals(city.id, saved.settings.cityId)
            assertEquals(city.timeZoneId, saved.place.zone.id)
            compose.onNodeWithTag("welcome-manual").assertDoesNotExist()
        }
    }

    @Test fun missingPermissionNeverCompletesOnboardingOrLocksManualChoice() = withEmptyPlace {
        ActivityScenario.launch(MainActivity::class.java).use { activity ->
            val vm = model(activity)
            waitForTag("welcome-detect")
            // Exercise the provider's denied result, not the Android permission dialog.
            // Never revoke permissions under instrumentation: that kills its target process.
            assumeFalse(vm.hasLocationPermission())
            activity.onActivity { vm.useDeviceLocation(forceFresh = true) }
            compose.waitUntil(15_000) { !vm.locating.value && vm.locationStep.value == LocationRequestStep.REQUEST_PERMISSION }
            assertEquals(AppEntry.Welcome, vm.entry.value)
            assertFalse(runBlocking { Graph.settings(context).settings.first() }.placeChosen)
            compose.onNodeWithTag("welcome-manual").assertIsDisplayed().performClick()
            compose.onNodeWithContentDescription("Поиск города").assertIsDisplayed()
        }
        ActivityScenario.launch(MainActivity::class.java).use { activity ->
            waitForTag("welcome-detect")
            assertEquals(AppEntry.Welcome, model(activity).entry.value)
            compose.onNodeWithTag("welcome-manual").assertIsDisplayed()
        }
    }

    @Test fun savedFixOpensHomeWithoutWaitingForAnAddress() = withEmptyPlace {
        ActivityScenario.launch(MainActivity::class.java).use { activity ->
            val vm = model(activity)
            waitForTag("welcome-detect")
            runBlocking { Graph.settings(context).setDeviceLocation(55.73, 37.58, City.MOSCOW.id, 850.0, System.currentTimeMillis()) }
            compose.waitUntil(15_000) { vm.entry.value is AppEntry.Home }
            val place = (vm.entry.value as AppEntry.Home).schedule.place
            assertTrue(place.fromDeviceLocation)
            assertEquals(55.73, place.coordinates.latitude, 0.000001)
            assertEquals(37.58, place.coordinates.longitude, 0.000001)
            compose.onNodeWithTag("welcome-manual").assertDoesNotExist()
        }
    }
}
