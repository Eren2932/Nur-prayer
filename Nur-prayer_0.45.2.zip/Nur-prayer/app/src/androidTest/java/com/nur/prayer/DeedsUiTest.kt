package com.nur.prayer

import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.test.getUnclippedBoundsInRoot
import com.nur.prayer.ui.theme.LocalUiScale
import com.nur.prayer.ui.theme.UiScale
import androidx.compose.runtime.remember
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.today.TodayActions
import com.nur.prayer.ui.today.TodayScreen
import com.nur.prayer.ui.today.TodayState
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DeedsUiTest {
    @get:Rule val compose = createComposeRule()

    @Test fun everyCardHasItsOwnDestination() {
        val opened = mutableListOf<String>()
        compose.setContent {
            NurTheme {
                TodayScreen(TodayState(AzkarSet.EVENING, 12, 16, 1, 3, 0L, false), remember { Reveal(true) },
                    TodayActions({}, {}, { opened += "names" }, { opened += "vird" }, { opened += it.name },
                        { opened += "salawat" }, { opened += "story" }))
            }
        }
        compose.onAllNodesWithText("Сейчас").assertCountEquals(1)
        compose.onNodeWithText("Коран").assertDoesNotExist()
        for (title in listOf("99 имён Аллаха", "Вирд дня", "Утренние азкары", "Вечерние азкары", "Зикр", "История дня")) {
            compose.onNodeWithText(title).performScrollTo().performClick()
        }
        compose.runOnIdle { assertEquals(listOf("names", "vird", "MORNING", "EVENING", "salawat", "story"), opened) }
    }

    @Test fun referenceGridKeepsMatchedTilesAndOriginalGutters() {
        compose.setContent {
            NurTheme {
                CompositionLocalProvider(LocalUiScale provides UiScale.of(393, 851, 1f),
                    LocalDensity provides Density(LocalDensity.current.density, 1f)) {
                    TodayScreen(TodayState(AzkarSet.MORNING, 17, 17, 0, 3, 0L, false), remember { Reveal(true) },
                        TodayActions({}, {}, {}, {}, {}, {}, {}))
                }
            }
        }
        fun bounds(label: String) = compose.onNodeWithText(label).getUnclippedBoundsInRoot()
        val names = bounds("99 имён Аллаха"); val star = bounds("Вирд дня")
        val sun = bounds("Утренние азкары"); val moon = bounds("Вечерние азкары")
        val salawat = bounds("Зикр"); val story = bounds("История дня")
        for (tile in listOf(names, star, sun, moon)) {
            assertEquals(137f, (tile.bottom - tile.top).value, 1f)
            assertEquals((names.right - names.left).value, (tile.right - tile.left).value, 1f)
        }
        assertEquals(12f, (star.left - names.right).value, 1f)
        assertEquals(11f, (sun.top - names.bottom).value, 1f)
        assertEquals(17f, (salawat.top - sun.bottom).value, 1f)
        assertEquals(16f, (story.top - salawat.bottom).value, 1f)
    }
}
