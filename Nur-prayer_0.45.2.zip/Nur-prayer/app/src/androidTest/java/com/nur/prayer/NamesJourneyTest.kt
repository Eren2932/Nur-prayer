package com.nur.prayer

import android.content.Context
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.unit.dp
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasSetTextAction
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performScrollToKey
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeLeft
import androidx.compose.ui.test.swipeRight
import androidx.compose.ui.test.swipeUp
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.ui.names.NamesCatalog
import com.nur.prayer.ui.names.NamesReader
import com.nur.prayer.ui.names.NamesScreen
import com.nur.prayer.ui.shell.rememberPrayerIslandTarget
import com.nur.prayer.ui.shell.PrayerIslandHost
import com.nur.prayer.ui.theme.NurTheme
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class NamesJourneyTest {
    @get:Rule val compose = createComposeRule()
    @Test fun firstVisitFilteredReaderAndResume() {
        val context=InstrumentationRegistry.getInstrumentation().targetContext
        val prefs=context.getSharedPreferences("nur_names_reading",Context.MODE_PRIVATE)
        prefs.edit().clear().commit()
        compose.setContent { NurTheme { NamesScreen(true) } }
        compose.onNodeWithText("Открыть имена").performScrollTo().performClick()
        compose.waitUntil(5000) { compose.onAllNodes(hasSetTextAction()).fetchSemanticsNodes().isNotEmpty() }
        compose.onNode(hasSetTextAction()).performTextInput("98")
        val name = context.assets.open(NamesCatalog.ASSET).bufferedReader().use { NamesCatalog.parse(it.readLines())[97].reading }
        compose.onNodeWithText(name).performScrollTo().performClick()
        compose.onNodeWithText("Следующее").assertDoesNotExist()
        compose.onNodeWithText("Предыдущее").assertDoesNotExist()
        val pager = compose.onNodeWithTag("names-pager")
        pager.performTouchInput { swipeLeft() }
        compose.waitUntil(5000) { prefs.getInt("bookmark_id",0)==99 }
        pager.performTouchInput { swipeRight() }
        compose.waitUntil(5000) { prefs.getInt("bookmark_id",0)==98 }
        pager.performTouchInput { swipeLeft() }
        compose.waitUntil(5000) { prefs.getInt("bookmark_id",0)==99 }
        compose.onNodeWithText("К списку").performClick()
        compose.onNode(hasSetTextAction()).assertIsDisplayed()
        compose.onNodeWithText("Продолжить · 99").performScrollTo().performClick()
        val count = 99
        compose.onNodeWithText("$count / $count").assertIsDisplayed()
        prefs.edit().clear().apply()
    }
    @Test fun verticalDragReadsLongPageWithoutTurningIt() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val rows = context.assets.open(NamesCatalog.ASSET).bufferedReader().use { NamesCatalog.parse(it.readLines()) }
        val id = 34 // includes the long verse 2:255; constrain height for tablet runs as well
        var saved = 0
        compose.setContent {
            NurTheme {
                Box(Modifier.height(320.dp)) { NamesReader(rows, id, onList = {}, onRead = { saved = it }) }
            }
        }
        val leaf = compose.onNodeWithTag("name-leaf-$id")
        val axis = leaf.fetchSemanticsNode().config[SemanticsProperties.VerticalScrollAxisRange]
        compose.runOnIdle { assertEquals(0f, axis.value(), 0f) }
        leaf.performTouchInput { swipeUp() }
        compose.runOnIdle { assertTrue(axis.value() > 0f); assertEquals(id, saved) }
    }
    @Test fun allRowShapesUseTheSameHeightAndIntroDoesNotReturn() {
        val prefs = InstrumentationRegistry.getInstrumentation().targetContext
            .getSharedPreferences("nur_names_reading", Context.MODE_PRIVATE)
        prefs.edit().clear().commit()
        val mounted = mutableStateOf(true)
        compose.setContent { NurTheme { if (mounted.value) NamesScreen(true) } }
        compose.onNodeWithText("Открыть имена").assertExists()
        compose.runOnIdle { mounted.value = false }
        compose.waitForIdle()
        compose.runOnIdle { mounted.value = true }
        compose.waitUntil(5000) { compose.onAllNodes(hasSetTextAction()).fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("О разделе").assertDoesNotExist()
        compose.onNodeWithText("Открыть имена").assertDoesNotExist()
        fun rowHeight(id: Int): Int {
            compose.onNodeWithTag("names-index").performScrollToKey(id)
            return compose.onNodeWithTag("name-row-$id").fetchSemanticsNode().size.height
        }
        val height = rowHeight(6)
        for (id in listOf(1, 34, 85, 99)) assertEquals(height, rowHeight(id))
        prefs.edit().clear().apply()
    }
    @Test fun islandDoesNotFlashOnEntryOrWhenChangingSections() {
        val at=ZonedDateTime.parse("2026-11-25T12:00:00+03:00"); val now=mutableStateOf(at.minusMinutes(4)); val route=mutableStateOf("today")
        val days=listOf(PrayerDay(at.toLocalDate(),mapOf(Prayer.DHUHR to at)))
        compose.mainClock.autoAdvance=false
        compose.setContent { NurTheme { PrayerIslandHost(rememberPrayerIslandTarget(route.value,days,now),now,{},Modifier) } }
        compose.mainClock.advanceTimeBy(1200); compose.onNodeWithText("Зухр").assertDoesNotExist()
        compose.mainClock.advanceTimeBy(1200); compose.onNodeWithText("Зухр").assertIsDisplayed()
        compose.runOnIdle { route.value="names" }; compose.mainClock.advanceTimeBy(300)
        compose.onNodeWithText("Зухр").assertDoesNotExist()
        compose.mainClock.advanceTimeBy(2100); compose.onNodeWithText("Зухр").assertIsDisplayed()
        compose.runOnIdle { now.value=at }; compose.mainClock.advanceTimeBy(200)
        compose.onNodeWithText("Зухр").assertDoesNotExist()
    }
}
