package com.nur.prayer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.getBoundsInRoot
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeLeft
import androidx.compose.ui.test.swipeUp
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.daily.Azkar
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.ROUTE_QURAN
import com.nur.prayer.ui.components.ExitDock
import com.nur.prayer.ui.daily.AzkarReader
import com.nur.prayer.ui.shell.ShellLayer
import com.nur.prayer.ui.shell.ShellState
import com.nur.prayer.ui.theme.NurTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AzkarReaderUiTest {
    @get:Rule val compose = createComposeRule()

    private fun exercise(set: AzkarSet) {
        val rows = Azkar.of(set, null).take(2)
        val counts = mutableStateOf(emptyMap<String, Long>())
        compose.setContent { NurTheme {
            Box(Modifier.height(410.dp)) {
                var translit by remember { mutableStateOf(true) }
                AzkarReader(rows, set, counts.value, translit,
                    onRepeat = { z -> counts.value = counts.value + (z.id to ((counts.value[z.id] ?: 0L) + 1)) },
                    onTranslit = { translit = it }, onReset = { counts.value = emptyMap() })
            }
        } }
        val prev = compose.onNodeWithContentDescription(tr("Предыдущее"))
        val next = compose.onNodeWithContentDescription(tr("Следующее"))
        val first = compose.onNodeWithTag("azkar-leaf-${rows[0].id}")
        val second = compose.onNodeWithTag("azkar-leaf-${rows[1].id}")
        val counter = compose.onNodeWithTag("azkar-repeat-${rows[0].id}")
        val footer = next.getBoundsInRoot()
        val frame = first.getBoundsInRoot()
        prev.assertIsNotEnabled()
        first.performTouchInput { swipeLeft() }
        first.performTouchInput { swipeUp() }
        assertTrue(first.fetchSemanticsNode().config[SemanticsProperties.VerticalScrollAxisRange].value() > 0f)
        assertEquals(footer, next.getBoundsInRoot())
        next.performClick()
        second.assertIsDisplayed()
        assertEquals(frame, second.getBoundsInRoot())
        next.assertIsNotEnabled()
        compose.runOnIdle { assertTrue(counts.value.isEmpty()) }
        prev.performClick()
        counter.performScrollTo().performClick()
        counter.assertIsNotEnabled()
        prev.assertIsNotEnabled()
        compose.runOnIdle { assertEquals(1L, counts.value.getValue(rows[0].id)) }
        assertEquals(footer, next.getBoundsInRoot())
    }

    @Test fun morningButtonsOnlyAndPinnedFooter() = exercise(AzkarSet.MORNING)
    @Test fun eveningButtonsOnlyAndPinnedFooter() = exercise(AzkarSet.EVENING)

    @Test fun quranCornersAreTheOnlyLaunchersAndTheDotsOpenARealMenu() {
        val events = mutableListOf<String>()
        compose.setContent { NurTheme {
            val shell = remember { ShellState() }
            Box(Modifier.fillMaxSize()) {
                ExitDock(onClose = { events += "back" }, bottom = 0.dp, onMenu = shell::show,
                    modifier = Modifier.align(Alignment.BottomCenter))
                ShellLayer(shell, ROUTE_QURAN, onOpenSection = { s, _ -> events += s.name }, onHome = { events += "home" })
            }
        } }
        compose.onNodeWithText(tr("Учёба")).assertDoesNotExist()
        compose.onNodeWithContentDescription(tr("На главную")).assertDoesNotExist()
        compose.onAllNodesWithContentDescription(tr("Разделы")).assertCountEquals(1)
        compose.onNodeWithContentDescription(tr("Разделы")).performClick()
        compose.onNodeWithContentDescription(tr("Настройки")).assertIsDisplayed().performClick()
        compose.onNodeWithContentDescription(tr("Назад")).performClick()
        compose.runOnIdle { assertEquals(listOf("SETTINGS", "back"), events) }
    }
}
