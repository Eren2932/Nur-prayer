package com.nur.prayer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PixelMap
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.StateRestorationTester
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.ui.welcome.GreetingLettering
import com.nur.prayer.ui.welcome.GreetingPlayback
import kotlin.math.abs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class WelcomeInkRenderTest {
    @get:Rule val compose = createComposeRule()
    private fun picture() = compose.onNodeWithContentDescription("Ассаламу алейкум").captureToImage().toPixelMap()
    private fun different(a: PixelMap, b: PixelMap): Int {
        var n = 0
        for (y in 0 until a.height) for (x in 0 until a.width) {
            if (abs(a[x,y].red - b[x,y].red) > .025f) n++
        }
        return n
    }

    @Test fun silverOnBothWordsAndNoColourOutsideLetters() {
        val time = mutableLongStateOf(0L)
        compose.setContent {
            // Magenta makes any accidental rectangle painted outside the strokes conspicuous.
            Box(Modifier.background(Color.Magenta)) { GreetingLettering(180.dp) { time.longValue } }
        }
        val still = picture()
        compose.runOnIdle { time.longValue = 3_000_000_000L }
        val moved = picture()
        assertTrue(different(still, moved) > 40)
        for (frame in listOf(still, moved)) {
            for (row in 0..1) {
                var groups = 0
                for (q in 0..3) {
                    var toned = 0
                    for (y in (if (row == 0) 0 else frame.height * 3 / 5) until
                        (if (row == 0) frame.height * 45 / 100 else frame.height)) {
                        for (x in q * frame.width / 4 until (q+1) * frame.width / 4) {
                            val c = frame[x,y]
                            if (c.red < .82f && c.green > .46f) toned++
                        }
                    }
                    if (toned > 4) groups++
                }
                assertTrue(groups >= 2)
            }
            val corner = frame[frame.width-1,frame.height-1]
            assertTrue(corner.red > .95f && corner.blue > .95f && corner.green < .03f)
        }
    }

    @Test fun pausedFrameSurvivesAndMovesAgainWithoutAWhiteFlash() {
        compose.mainClock.autoAdvance = false
        val speed = mutableFloatStateOf(1f)
        val restore = StateRestorationTester(compose)
        restore.setContent { Box(Modifier.background(Color.Black)) { GreetingPlayback(180.dp, speed.floatValue) } }
        compose.mainClock.advanceTimeBy(2400)
        val moving = picture()
        compose.runOnIdle { speed.floatValue = 0f }
        compose.mainClock.advanceTimeBy(48)
        val paused = picture()
        // Allow a last vsync before the pause takes effect, but not a switch to white.
        assertTrue(different(moving, paused) < paused.width * paused.height / 100)
        compose.mainClock.advanceTimeBy(8000)
        assertEquals(0, different(paused, picture()))
        // The playback is paused, but the test host needs frames to actually remove/recreate content.
        compose.mainClock.autoAdvance = true
        restore.emulateSavedInstanceStateRestore()
        assertEquals(0, different(paused, picture()))
        compose.mainClock.autoAdvance = false
        compose.runOnIdle { speed.floatValue = 1f }
        compose.mainClock.advanceTimeBy(32)
        assertTrue(different(paused, picture()) < paused.width * paused.height / 100)
        compose.mainClock.advanceTimeBy(1600)
        assertTrue(different(paused, picture()) > 40)
    }
}
