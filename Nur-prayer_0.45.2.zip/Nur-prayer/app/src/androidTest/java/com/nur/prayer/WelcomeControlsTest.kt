package com.nur.prayer

import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.location.LocationRequestStep
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.welcome.WelcomeFlow
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class WelcomeControlsTest {
    @get:Rule val compose = createComposeRule()

    @Test fun busyHidesManualAndDenialRestoresIt() {
        val busy = mutableStateOf(false)
        val denied = mutableStateOf(false)
        var taps = 0
        compose.setContent {
            NurTheme {
                WelcomeFlow(busy.value, if (denied.value) "Доступ не выдан" else null,
                    if (denied.value) LocationRequestStep.OPEN_APP_SETTINGS else LocationRequestStep.LOCATE,
                    search = { emptyList() }, onLocate = { taps++; busy.value = true }, onPick = {})
            }
        }
        compose.runOnIdle { assertEquals(0, taps) }
        compose.onNodeWithTag("welcome-detect").performClick()
        compose.onNodeWithTag("welcome-manual").assertDoesNotExist()
        compose.onNodeWithContentDescription("Определяем…").assertIsDisplayed()
        compose.runOnIdle { denied.value = true; busy.value = false }
        compose.onNodeWithText("Настройки").assertIsDisplayed()
        compose.onNodeWithTag("welcome-manual").assertIsDisplayed().performClick()
        compose.onNodeWithContentDescription("Поиск города").assertIsDisplayed()
        compose.runOnIdle { assertEquals(1, taps) }
    }
}
