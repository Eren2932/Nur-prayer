package com.nur.prayer

import com.nur.prayer.ui.names.NamesCatalog
import com.nur.prayer.ui.shell.PrayerIslandPolicy
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NamesAndIslandTest {
    private val noon = ZonedDateTime.parse("2026-11-25T12:00:00+03:00")
    private fun day(vararg times: Pair<Prayer,ZonedDateTime>) = PrayerDay(noon.toLocalDate(), times.toMap())
    private fun names() = javaClass.getResourceAsStream("/names/ru.tsv")!!.bufferedReader().use { NamesCatalog.parse(it.readLines()) }

    @Test fun fiveMinutesIsInclusiveButStartIsNot() {
        val times = PrayerIslandPolicy.schedule(listOf(day(Prayer.DHUHR to noon)))
        assertNull(PrayerIslandPolicy.imminent(times,noon.minusMinutes(5).minusNanos(1)))
        assertEquals(Prayer.DHUHR,PrayerIslandPolicy.imminent(times,noon.minusMinutes(5))?.prayer)
        assertEquals(Prayer.DHUHR,PrayerIslandPolicy.imminent(times,noon.minusNanos(1))?.prayer)
        assertNull(PrayerIslandPolicy.imminent(times,noon)); assertNull(PrayerIslandPolicy.imminent(times,noon.plusSeconds(1)))
    }
    @Test fun markersNeverMaskOrImpersonatePrayer() {
        val times=PrayerIslandPolicy.schedule(listOf(day(Prayer.SAHAR to noon.minusMinutes(2), Prayer.SUNRISE to noon, Prayer.FAJR to noon)))
        assertEquals(listOf(Prayer.FAJR),times.map { it.prayer })
        assertEquals(Prayer.FAJR,PrayerIslandPolicy.imminent(times,noon.minusMinutes(4))?.prayer)
        assertNull(PrayerIslandPolicy.imminent(emptyList(), noon))
    }
    @Test fun tomorrowIsVisibleAcrossMidnightEvenFromAnotherZone() {
        val start=noon.plusDays(1).withHour(0).withMinute(2)
        val times=PrayerIslandPolicy.schedule(listOf(PrayerDay(start.toLocalDate(), mapOf(Prayer.FAJR to start)),day(Prayer.ISHA to noon)))
        assertEquals(start,PrayerIslandPolicy.imminent(times,start.minusMinutes(4).withZoneSameInstant(java.time.ZoneOffset.UTC))?.start)
    }
    @Test fun searchByNumberMeaningReadingAndArabic() {
        val rows=names(); assertEquals(99,rows.size); assertEquals(99,NamesCatalog.search(rows," ").size)
        for (q in listOf("02", "ар рахман", "الرَّحْمَٰنِ", "милостивый")) {
            assertTrue(q,NamesCatalog.search(rows,q).any { it.id==2 })
        }
        assertTrue(NamesCatalog.search(rows,"100").isEmpty()); assertEquals(99,NamesCatalog.search(rows,"99").single().id)
    }
    @Test fun alternateMeaningsAndExistingBookmarksSurviveTheNewSchema() {
        val rows = names()
        for ((word, id) in listOf("сохранности" to 6, "без платы" to 17, "сотоварища" to 67, "085" to 85)) {
            assertTrue(word, NamesCatalog.search(rows, word).any { it.id == id })
        }
        assertEquals("Ас-Салям", rows[5].reading)
        assertEquals("Аль-Азым", rows[33].reading)
        assertEquals("Ас-Сабур", rows[98].reading)
    }
    @Test fun readerUsesEditedHeadlineAndUnescapesParagraphs() {
        val rows = names()
        val aziz = rows[8]
        assertEquals("Могущественный, Непобедимый", aziz.headline)
        assertEquals(2, aziz.note.split("\n\n").size)
        assertTrue(NamesCatalog.search(rows, "творящий без образца").any { it.id == 95 })
    }
    @Test fun arabicQueriesFindTheSamePageWithOrWithoutVowels() {
        val rows = names()
        val queries = listOf(8 to "المهيمن", 9 to "العزيز", 63 to "الحي", 83 to "الرؤوف", 85 to "ذو الجلال والإكرام")
        for ((id, bare) in queries) {
            val row = rows[id - 1]
            assertTrue(row.arabic != bare)
            assertEquals(NamesCatalog.fold(bare), NamesCatalog.fold(row.arabic))
            assertTrue(NamesCatalog.search(rows, bare).contains(row))
            assertTrue(NamesCatalog.search(rows, row.arabic).contains(row))
        }
    }
    @Test fun catalogKeepsDistinctSimilarNamesAndExactReferences() {
        val rows=names(); assertEquals(99,rows.map { it.arabic }.distinct().size)
        assertEquals(112 to 1,rows.first().verse); assertEquals(68,rows.count { it.verse!=null }); assertNull(rows.last().verse)
        assertTrue(rows[48].arabic!=rows[65].arabic)
    }
}
