package com.nur.prayer

import com.nur.prayer.ui.welcome.SILVER_LOOP_NS
import com.nur.prayer.ui.welcome.silverTimeAt
import org.junit.Assert.assertEquals
import org.junit.Test

class WelcomeSilverClockTest {
    @Test fun differentCadencesAndDroppedFramesMeetAtTheSameActiveTime() {
        val duration = 12_000_000_000L
        val anchor = 93_000_000_000L
        for (hz in listOf(24, 30, 60, 90, 120)) {
            val frames = 12 * hz
            var time = anchor
            for (i in 1..frames) {
                if (i % 7 == 3 && i < frames) continue
                time = silverTimeAt(anchor, duration*i/frames, 1f)
            }
            assertEquals(9_000_000_000L, time)
        }
    }

    @Test fun resumedEpochRetainsSavedFrameAndIgnoresTimeSpentStopped() {
        val held = silverTimeAt(0L, 11_000_000_000L, 2f)
        assertEquals(held, silverTimeAt(held, 33_000_000_000L, 0f))
        assertEquals(held, silverTimeAt(held, 0L, 1f))
        assertEquals(7_500_000_000L, silverTimeAt(held, 2_000_000_000L, 1f))
        assertEquals(0L, silverTimeAt(SILVER_LOOP_NS-1L, 1L, 1f))
    }
}
