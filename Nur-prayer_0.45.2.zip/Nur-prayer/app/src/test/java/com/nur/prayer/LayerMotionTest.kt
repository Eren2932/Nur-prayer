package com.nur.prayer

import com.nur.prayer.ui.LayerMotion
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.41.0: the one motion rule of the «Дела» layer. */
class LayerMotionTest {
    @Test fun incomingPageStartsAThirdOfTheWidthAway() {
        assertEquals(340, LayerMotion.enterOffset(1000))
        assertEquals(367, LayerMotion.enterOffset(1080)) // 367.2
    }

    @Test fun pageUnderneathDriftsAFifth() {
        assertEquals(200, LayerMotion.underOffset(1000))
        assertEquals(216, LayerMotion.underOffset(1080))
    }

    @Test fun theNewPageTravelsFartherThanTheOneUnderIt() {
        // Parallax: the page on top is the near one.
        assertTrue(LayerMotion.ENTER_SHIFT > LayerMotion.UNDER_SHIFT)
    }

    @Test fun theOldPageShrinksButStaysReadable() {
        assertTrue(LayerMotion.UNDER_SCALE in 0.9f..0.99f)
    }

    @Test fun fadesNeverOutlastTheSlide() {
        assertTrue(LayerMotion.FADE_IN_MILLIS <= LayerMotion.MILLIS)
        assertTrue(LayerMotion.FADE_OUT_MILLIS <= LayerMotion.MILLIS)
    }

    @Test fun bothDirectionsBuildATransition() {
        // Building a transition touches every spec once: a wrong type would fail here, not on a device.
        LayerMotion.forward()
        LayerMotion.backward()
    }
}
