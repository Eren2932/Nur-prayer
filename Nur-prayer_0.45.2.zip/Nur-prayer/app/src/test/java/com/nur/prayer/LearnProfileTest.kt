package com.nur.prayer

import com.nur.prayer.learn.Arabic
import com.nur.prayer.learn.Course
import com.nur.prayer.learn.Exercise
import com.nur.prayer.learn.ExerciseFactory
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.learn.LearnGoal
import com.nur.prayer.learn.LearnLevel
import com.nur.prayer.learn.LearnProfile
import com.nur.prayer.learn.LearnProgress
import com.nur.prayer.learn.LessonPlan
import com.nur.prayer.learn.LessonSession
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** 0.35.0: goals, the learner profile and the alphabet in its own order. */
class LearnProfileTest {
    private fun asset(name: String): String =
        listOf(File("src/main/assets/$name"), File("app/src/main/assets/$name")).first { it.exists() }.readText()

    private val base by lazy { LearnContent.parse(asset(LearnContent.WORDS_ASSET), asset(LearnContent.QURAN_ASSET)) }

    @Test fun profileRoundTripsAndIsLenient() {
        val p = LearnProfile(LearnGoal.LANGUAGE, LearnLevel.LETTERS, 20)
        assertEquals(p, LearnProfile.decode(p.encode()))
        assertNull(LearnProfile.decode(null))
        assertNull(LearnProfile.decode("garbage"))
        assertNull("no level means not chosen yet", LearnProfile.decode("v1;goal=quran"))
        assertEquals(LearnProfile(LearnGoal.QURAN, LearnLevel.ZERO, LearnProfile.DEFAULT_MINUTES),
            LearnProfile.decode("v1;goal=quran;level=zero;daily=9999;extra=1"))
    }

    @Test fun alphabetGoesInOrderWithEveryLetterOnce() {
        val joined = Arabic.LESSON_GROUPS.joinToString("")
        assertEquals("28 letters in alphabet order", Arabic.LETTERS.joinToString("") { it.char }, joined)
        val alphabet = base.course.stages.first()
        assertEquals("alphabet", alphabet.id)
        assertTrue("starts with how writing works", alphabet.lessons.first().plan is LessonPlan.Orientation)
        val taught = alphabet.lessons.map { it.plan }.filterIsInstance<LessonPlan.Letters>().flatMap { it.fresh }
        assertEquals(Arabic.LETTERS, taught)
        val vowels = alphabet.lessons.map { it.plan }.filterIsInstance<LessonPlan.Letters>().mapNotNull { it.newVowel }
        assertEquals("fatha, kasra, damma all met inside the alphabet", Arabic.VOWELS, vowels)
    }

    @Test fun everyGoalBuildsValidLessonsAndRunsToTheEnd() {
        for (goal in LearnGoal.values()) {
            val c = base.forGoal(goal)
            val ids = c.course.lessons.map { it.id }
            assertEquals("$goal: lesson ids unique", ids.size, ids.toSet().size)
            for (lesson in c.course.lessons) for (seed in 1..6) {
                val list = ExerciseFactory(c.lexicon, c.quran, seed).build(lesson.plan, c.course, LearnProgress(), 0)
                assertTrue("$goal ${lesson.id} empty", list.isNotEmpty())
                list.filterIsInstance<Exercise.Choice>().forEach { ch ->
                    assertTrue("$goal ${lesson.id}: options", ch.options.size >= 2 && ch.answer in ch.options.indices)
                    assertEquals("$goal ${lesson.id}: distinct", ch.options.size, ch.options.distinct().size)
                }
            }
            for (i in 1 until c.course.stages.size) {
                val cp = c.course.lesson(Course.checkpointId(i))!!
                assertTrue("$goal checkpoint $i", ExerciseFactory(c.lexicon, c.quran, 5).build(cp.plan, c.course, LearnProgress(), 0).size >= 6)
            }
            var p = LearnProgress()
            var steps = 0
            while (true) {
                val next = c.course.next(p) ?: break
                var s = LessonSession(ExerciseFactory(c.lexicon, c.quran, steps).build(next.plan, c.course, p, 100L + steps))
                while (!s.finished) s = if (s.current!!.isIntro) s.skip() else s.answer(true)
                p = p.complete(next.id, s.accuracy, s.firstTryCorrect, 100L + steps)
                steps++
                assertTrue("$goal never loops", steps <= c.course.lessons.size)
            }
        }
    }

    @Test fun levelSuggestsAStageToTestInto() {
        val c = base.course
        assertEquals(0, c.suggestedStart(null))
        assertEquals(0, c.suggestedStart(LearnProfile(LearnGoal.QURAN, LearnLevel.ZERO)))
        assertEquals(c.stageIndexById("forms"), c.suggestedStart(LearnProfile(LearnGoal.QURAN, LearnLevel.LETTERS)))
        assertEquals(c.stageIndexById("reading"), c.suggestedStart(LearnProfile(LearnGoal.QURAN, LearnLevel.READER)))
        assertEquals(c.stageIndexById("reading") + 1, c.suggestedStart(LearnProfile(LearnGoal.QURAN, LearnLevel.ADVANCED)))
    }

    @Test fun changingTheGoalKeepsSharedLessons() {
        val quran = base.forGoal(LearnGoal.QURAN).course.lessons.map { it.id }.toSet()
        val language = base.forGoal(LearnGoal.LANGUAGE).course.lessons.map { it.id }.toSet()
        assertTrue("the reading foundation is shared", quran.filter { it.startsWith("abc-") || it.startsWith("vowels-") }.all { it in language })
    }
}
