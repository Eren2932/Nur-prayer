package com.nur.prayer

import com.nur.prayer.ui.wallpaper.FrostBlur
import com.nur.prayer.ui.wallpaper.WallpaperImages
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt

/** 0.41.0: the soft copy under «Дела» is about 3 dp of blur, much milder than the frost of the glass. */
class SoftBlurTest {
    /**
     * Standard deviation (px of the blurred bitmap) of the blur, read from the response to an edge: the derivative of a
     * step is the blur's own profile, and a step keeps its 8-bit rounding error small (an impulse would not).
     */
    private fun sigma(radius: Int): Double {
        val n = 201
        val pixels = IntArray(n) { if (it < n / 2) 0xFF000000.toInt() else 0xFFFFFFFF.toInt() }
        repeat(3) { FrostBlur.blur(pixels, n, 1, radius) }
        var sum = 0.0
        var mean = 0.0
        val d = DoubleArray(n - 1) { ((pixels[it + 1] and 0xFF) - (pixels[it] and 0xFF)).toDouble() }
        d.forEachIndexed { i, v -> sum += v; mean += v * i }
        mean /= sum
        var m2 = 0.0
        d.forEachIndexed { i, v -> m2 += v * (i - mean) * (i - mean) }
        return sqrt(m2 / sum)
    }

    @Test fun softBlurIsAboutThreeDpOnAnXxhdpiScreen() {
        val screenPx = sigma(WallpaperImages.SOFT_BLUR_RADIUS) * WallpaperImages.SOFT_BLUR_DIVISOR
        val dp = screenPx / 2.142 // the reference: 842 px = 393 dp
        assertTrue("soft blur was $dp dp", dp in 2.0..5.0)
    }

    @Test fun softIsMilderThanTheFrostOfTheGlass() {
        // The glass: radius 3 at a tenth of the screen.
        val frostDp = sigma(3) * 10 / 2.142
        val softDp = sigma(WallpaperImages.SOFT_BLUR_RADIUS) * WallpaperImages.SOFT_BLUR_DIVISOR / 2.142
        assertTrue(softDp * 3 < frostDp)
    }
}
