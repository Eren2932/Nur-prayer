package com.nur.prayer

import androidx.compose.ui.graphics.Color
import com.nur.prayer.ui.shell.APPS_DOT
import com.nur.prayer.ui.shell.APPS_X
import com.nur.prayer.ui.shell.APPS_Y
import com.nur.prayer.ui.shell.BarLayout
import com.nur.prayer.ui.shell.PillShimmer
import com.nur.prayer.ui.shell.ShellColors
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin

/** 0.38.0: the bar after the new reference: where the three things stand, the four dots and the glint on the pill. */
class ShellBarTest {
    private val widths = listOf(320f, 360f, 375f, 393f, 411f, 432f, 600f, 840f)

    @Test fun theMiddleButtonIsAtTheCentreOfEveryScreen() {
        for (w in widths) {
            val centre = BarLayout.middleStart(w) + BarLayout.BUTTON / 2f
            assertEquals("width $w", w / 2f, centre, 1e-4f)
        }
    }

    @Test fun bothGapsAreTheSameAndTheNeighboursDoNotTouchTheMiddleOne() {
        for (w in widths) {
            val leftEnd = BarLayout.leftStart(w) + BarLayout.BUTTON
            val gapLeft = BarLayout.middleStart(w) - leftEnd
            val gapRight = BarLayout.pillStart(w) - (BarLayout.middleStart(w) + BarLayout.BUTTON)
            assertEquals("width $w", BarLayout.GAP, gapLeft, 1e-4f)
            assertEquals("width $w", BarLayout.GAP, gapRight, 1e-4f)
        }
    }

    @Test fun onTheReferencesPhoneTheNumbersAreTheMeasuredOnes() {
        // 577 px at 1.4667 px per dp.
        val w = 577f / 1.4667f
        val px = 1.4667f
        // The reference's edges, px: left ring ends 191.5, middle ring 240.9 .. 292.5, pill 339.4 .. 478.8.
        assertEquals((292.5f - 240.9f) / px, BarLayout.BUTTON, 0.5f)
        assertEquals((478.8f - 339.4f) / px, BarLayout.PILL_WIDTH, 0.5f)
        // The two gaps of the reference, 33.7 dp and 32.0 dp: the bar's single gap is their mean within half a dp.
        assertEquals(((240.9f - 191.5f) / px + (339.4f - 292.5f) / px) / 2f, BarLayout.GAP, 0.5f)
        // The reference's middle button was 14.9 dp left of the centre; here it is on it.
        assertEquals(w / 2f, BarLayout.middleStart(w) + BarLayout.BUTTON / 2f, 1e-3f)
    }

    @Test fun thePillAndTheQuranButtonStayOnTheScreenAndTheWordHasRoomFromAnyPhoneUp() {
        for (w in widths) {
            assertTrue("width $w", BarLayout.leftStart(w) >= BarLayout.MARGIN)
            // The pill may be as wide as its room says without leaving the screen's margin.
            assertTrue("width $w", BarLayout.pillStart(w) + BarLayout.pillRoom(w) <= w - BarLayout.MARGIN + 1e-3f)
        }
        // From 360 dp up the pill has its 95 dp whole.
        for (w in widths.filter { it >= 360f }) assertTrue("width $w", BarLayout.pillRoom(w) >= BarLayout.PILL_WIDTH)
    }

    @Test fun theFourDotsAreTheMeasuredGrid() {
        assertEquals(2, APPS_X.size)
        assertEquals(2, APPS_Y.size)
        assertEquals(4.1f, APPS_DOT, 1e-6f)
        assertEquals(8.45f, APPS_X[1] - APPS_X[0], 1e-4f)
        assertEquals(7.53f, APPS_Y[1] - APPS_Y[0], 1e-4f)
        // Centred in the 24-unit box, and the dots stay inside it.
        assertEquals(12f, (APPS_X[0] + APPS_X[1]) / 2f, 1e-4f)
        assertEquals(12f, (APPS_Y[0] + APPS_Y[1]) / 2f, 1e-4f)
        assertTrue(APPS_X[0] - APPS_DOT / 2f >= 0f && APPS_Y[0] - APPS_DOT / 2f >= 0f)
        // The dots do not touch.
        assertTrue(APPS_X[1] - APPS_X[0] > APPS_DOT && APPS_Y[1] - APPS_Y[0] > APPS_DOT)
    }

    @Test fun theGlintIsRarerThanInTheReferenceAndItsStripIsNotSlower() {
        // Measured on the owner's clip: a pass of ~0.40 s every 1.6 s.
        val clipSweep = 400
        val clipCycle = 1600
        assertTrue(PillShimmer.CYCLE_MS >= 2 * clipCycle)
        assertTrue(PillShimmer.CYCLE_MS <= 3 * clipCycle)
        // A pass is not faster than the clip's and not much slower: the strip is not slow, the passes are rare.
        assertTrue(PillShimmer.SWEEP_MS >= clipSweep && PillShimmer.SWEEP_MS <= clipSweep * 4 / 3)
        assertEquals(PillShimmer.CYCLE_MS - PillShimmer.SWEEP_MS, PillShimmer.PAUSE_MS)
        // The pause is a calm few seconds, and the first pass does not coincide with the bar's entrance.
        assertTrue(PillShimmer.PAUSE_MS in 3000..5000)
        assertTrue(PillShimmer.FIRST_MS in 1000..2500)
    }

    @Test fun theBandEntersAndLeavesTheWholePillOutside() {
        val width = 95f
        val band = width * PillShimmer.BAND
        // At the start the band's right edge is at the pill's left edge; at the end its left edge is at the pill's right.
        assertEquals(0f, PillShimmer.bandLeft(0f, width, band) + band, 1e-4f)
        assertEquals(width, PillShimmer.bandLeft(1f, width, band), 1e-4f)
        var last = PillShimmer.bandLeft(0f, width, band)
        for (i in 1..20) {
            val x = PillShimmer.bandLeft(i / 20f, width, band)
            assertTrue(x > last)
            last = x
        }
    }

    @Test fun theBandProfileIsSoftOnBothSidesAndPeaksInTheMiddle() {
        val p = PillShimmer.PROFILE
        assertEquals(0f, p.first(), 0f)
        assertEquals(0f, p.last(), 0f)
        assertEquals(1f, p.max(), 0f)
        assertEquals(p.size / 2, p.indexOfFirst { it == 1f })
        for (i in p.indices) assertEquals(p[i], p[p.size - 1 - i], 1e-6f)
        // A raised cosine at equal steps.
        for (i in p.indices) {
            val x = i / (p.size - 1).toDouble()
            assertEquals(sin(PI * x).pow(2).toFloat(), p[i], 1e-6f)
        }
    }

    @Test fun theEaseStartsAtZeroEndsAtOneAndNeverGoesBackwards() {
        assertEquals(0f, PillShimmer.EASING.transform(0f), 1e-4f)
        assertEquals(1f, PillShimmer.EASING.transform(1f), 1e-4f)
        var last = 0f
        for (i in 1..40) {
            val y = PillShimmer.EASING.transform(i / 40f)
            assertTrue(y >= last - 1e-5f)
            last = y
        }
    }

    @Test fun theGlintTintIsWhiteAndItsPeakIsTheDeclaredOne() {
        assertEquals(0f, PillShimmer.tint(0f).alpha, 1e-6f)
        // An sRGB Color keeps its alpha in 8 bits: 0.75 comes back as 191/255 = 0.7490.
        assertEquals(PillShimmer.PEAK_ALPHA, PillShimmer.tint(1f).alpha, 1f / 255f)
        assertEquals(1f, PillShimmer.tint(1f).red, 1e-6f)
    }

    @Test fun theVeilsAreFaintOnHomeAndFirmerInASection() {
        // Home: "really transparent, just a faint shade inside": 3..15 % black. A section keeps 0.37's 30..60 %.
        assertTrue(ShellColors.BarGlass.alpha in 0.03f..0.15f)
        assertEquals(0f, ShellColors.BarGlass.red, 0f)
        assertTrue(ShellColors.BarGlassPage.alpha in 0.30f..0.60f)
    }

    private fun lin(c: Float): Double = if (c <= 0.03928f) c / 12.92 else ((c + 0.055) / 1.055).pow(2.4)
    private fun lum(c: Color): Double = 0.2126 * lin(c.red) + 0.7152 * lin(c.green) + 0.0722 * lin(c.blue)
    private fun contrast(a: Color, b: Color): Double {
        val x = lum(a)
        val y = lum(b)
        return (maxOf(x, y) + 0.05) / (minOf(x, y) + 0.05)
    }

    @Test fun theWordOnThePillIsReadableEvenAtTheGlintsPeak() {
        assertTrue(contrast(ShellColors.PillInk, ShellColors.PillFill) >= 7.0)
        // At the peak the white lies over the grey at PEAK_ALPHA.
        val a = PillShimmer.PEAK_ALPHA
        val f = ShellColors.PillFill
        val peak = Color(f.red + (1f - f.red) * a, f.green + (1f - f.green) * a, f.blue + (1f - f.blue) * a)
        assertTrue(contrast(ShellColors.PillInk, peak) >= 7.0)
    }
}
