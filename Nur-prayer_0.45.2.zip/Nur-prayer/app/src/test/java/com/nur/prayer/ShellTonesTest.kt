package com.nur.prayer

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.ui.home.HomeSection
import com.nur.prayer.ui.shell.ShellTones
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.36.0 «Бумага»: the capsule's hue follows the place and the task; the arithmetic that makes it is pinned here. */
class ShellTonesTest {
    private fun lum(c: Color) = 0.2126f * c.red + 0.7152f * c.green + 0.0722f * c.blue

    @Test fun theEveningCapsuleIsTheMocksMint() {
        val t = ShellTones.EVENING
        assertEquals(0xFFADD2BF.toInt(), t.container.toArgb())
        // The glyph is nearly black in the hue, the button sits between the glyph and the disc.
        assertTrue(lum(t.ink) < 0.1f)
        assertTrue(lum(t.dots) > lum(t.ink) && lum(t.dots) < lum(t.container))
        assertTrue(lum(t.core) > lum(t.container))
    }

    @Test fun everyToneIsPaleOnTheOutsideAndDarkInTheGlyph() {
        val tones = HomeSection.entries.map { ShellTones.of(it) } + AzkarSet.entries.map { ShellTones.ofAzkar(it) }
        for (t in tones) {
            assertTrue("disc is lighter than the saturated well", lum(t.container) > lum(t.well))
            assertTrue("glyph reads on the disc", lum(t.container) - lum(t.ink) > 0.5f)
            assertTrue(lum(t.dots) < lum(t.container))
        }
    }

    @Test fun sectionsAndTasksHaveTheirOwnHue() {
        assertNotEquals(ShellTones.of(HomeSection.QURAN).well, ShellTones.of(HomeSection.DHIKR).well)
        assertNotEquals(ShellTones.of(HomeSection.QIBLA).well, ShellTones.of(HomeSection.TODAY).well)
        assertNotEquals(ShellTones.ofAzkar(AzkarSet.MORNING).container, ShellTones.ofAzkar(AzkarSet.EVENING).container)
    }

    @Test fun mixIsAStraightBlend() {
        val a = Color(0xFF000000)
        val b = Color(0xFFFFFFFF)
        assertEquals(a, ShellTones.mix(a, b, 0f))
        assertEquals(b, ShellTones.mix(a, b, 1f))
        // A Compose sRGB Color keeps 8 bits per channel: 0.5 comes back as 128/255, so the tolerance is one level.
        assertEquals(0.5f, ShellTones.mix(a, b, 0.5f).red, 1f / 255f)
    }
}
