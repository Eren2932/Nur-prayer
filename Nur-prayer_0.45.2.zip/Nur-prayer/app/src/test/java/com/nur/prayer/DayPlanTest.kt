package com.nur.prayer

import com.nur.prayer.daily.Azkar
import com.nur.prayer.daily.AzkarPages
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.DayItem
import com.nur.prayer.daily.DayPlan
import com.nur.prayer.daily.DayTask
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.daily.Vird
import com.nur.prayer.quran.KhatmPlan
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The «Дела» page: what counts as a task of the day, the summary on top, and the azkar reader. */
class DayPlanTest {
    private val d0 = 20_000L
    private val fullMask = (0 until 4).fold(0) { m, i -> StoryMath.withSeen(m, i) }

    private fun entry(task: DayTask, counted: Boolean, complete: Boolean, fraction: Float) = DayItem(task, counted, complete, fraction)

    @Test fun azkarFollowTheirCount() {
        assertEquals(DayItem(DayTask.AZKAR, true, false, 0f), DayPlan.azkar(0, 17))
        assertEquals(5 / 17f, DayPlan.azkar(5, 17).fraction, 1e-6f)
        assertTrue(DayPlan.azkar(17, 17).complete)
        // An empty list is no task: it must not read as «all done».
        assertFalse(DayPlan.azkar(0, 0).counted)
        assertFalse(DayPlan.azkar(0, 0).complete)
    }

    @Test fun quranWithoutKhatmIsNotATask() {
        val q = DayPlan.quran(null, d0)
        assertFalse(q.counted)
        assertFalse(q.complete)
    }

    @Test fun quranWithKhatmIsTodaysShare() {
        val fresh = KhatmPlan.start(d0, 30)
        val before = DayPlan.quran(fresh, d0)
        assertTrue(before.counted)
        assertFalse(before.complete)
        assertEquals(0f, before.fraction, 1e-6f)
        val atNorm = fresh.movedTo(fresh.expectedPage(d0), d0)
        val after = DayPlan.quran(atNorm, d0)
        assertTrue(after.complete)
        assertEquals(1f, after.fraction, 1e-6f)
    }

    @Test fun virdIsDoneOnlyWhenEveryDhikrIsSaid() {
        val vird = Vird.DEFAULT
        val one = mapOf(Dhikr.AFTER_PRAYER to Dhikr.preset(Dhikr.AFTER_PRAYER).target.toLong())
        val partial = DayPlan.dhikr(vird, one)
        assertTrue(partial.counted)
        assertFalse(partial.complete)
        assertEquals(1f / vird.size, partial.fraction, 1e-5f)
        val all = vird.associateWith { Dhikr.preset(it).target.toLong() }
        val full = DayPlan.dhikr(vird, all)
        assertTrue(full.complete)
        assertEquals(1f, full.fraction, 0f)
        // More than the target never pushes the ring past its end.
        val over = vird.associateWith { Dhikr.preset(it).target.toLong() * 3 }
        assertEquals(1f, DayPlan.dhikr(vird, over).fraction, 0f)
    }

    @Test fun emptyVirdIsNotATask() {
        val d = DayPlan.dhikr(emptyList(), mapOf(Dhikr.SALAWAT to 500L))
        assertFalse(d.counted)
        assertFalse(d.complete)
    }

    @Test fun storyIsDoneWhenEverySlideIsSeen() {
        assertEquals(0f, DayPlan.story(0, 4).fraction, 0f)
        val two = StoryMath.withSeen(StoryMath.withSeen(0, 0), 2)
        assertEquals(0.5f, DayPlan.story(two, 4).fraction, 1e-6f)
        assertFalse(DayPlan.story(two, 4).complete)
        assertTrue(DayPlan.story(fullMask, 4).complete)
    }

    @Test fun summaryCountsOnlyTasksWithAGoal() {
        val items = listOf(
            entry(DayTask.AZKAR, true, true, 1f),
            entry(DayTask.READING, false, false, 0f),
            entry(DayTask.VIRD, true, false, 0.5f),
            entry(DayTask.STORY, true, true, 1f)
        )
        assertEquals(2, DayPlan.doneCount(items))
        assertEquals(3, DayPlan.total(items))
        assertFalse(DayPlan.allDone(items))
        // The Quran has no goal, so it does not hold «next» either: the vird is.
        assertEquals(DayTask.VIRD, DayPlan.next(items))
    }

    @Test fun theDayIsDoneWhenEveryGoalIsReachedWhateverTheQuranSays() {
        val items = listOf(
            entry(DayTask.AZKAR, true, true, 1f),
            entry(DayTask.READING, false, false, 0f),
            entry(DayTask.VIRD, true, true, 1f),
            entry(DayTask.STORY, true, true, 1f)
        )
        assertTrue(DayPlan.allDone(items))
        assertNull(DayPlan.next(items))
        assertEquals(1f, DayPlan.fraction(items), 0f)
    }

    @Test fun nothingWithAGoalIsNeverDone() {
        val items = listOf(entry(DayTask.READING, false, false, 0f))
        assertFalse(DayPlan.allDone(items))
        assertNull(DayPlan.next(items))
        assertEquals(0f, DayPlan.fraction(items), 0f)
        assertFalse(DayPlan.allDone(emptyList()))
    }

    @Test fun nextFollowsThePagesOrder() {
        val items = listOf(
            entry(DayTask.AZKAR, true, false, 0.2f),
            entry(DayTask.READING, true, false, 0f),
            entry(DayTask.VIRD, true, false, 0f),
            entry(DayTask.STORY, true, false, 0f)
        )
        assertEquals(DayTask.AZKAR, DayPlan.next(items))
        assertEquals(DayTask.READING, DayPlan.next(listOf(items[0].copy(complete = true)) + items.drop(1)))
    }

    @Test fun fractionIsTheAverageOfTheGoalsAndIsSmooth() {
        val items = listOf(
            entry(DayTask.AZKAR, true, false, 0.5f),
            entry(DayTask.READING, false, false, 0.9f),   // no goal: ignored whatever it holds
            entry(DayTask.VIRD, true, true, 0.7f),     // complete counts as a whole
            entry(DayTask.STORY, true, false, 0f)
        )
        assertEquals((0.5f + 1f + 0f) / 3f, DayPlan.fraction(items), 1e-6f)
    }

    @Test fun buildKeepsThePagesOrder() {
        val items = DayPlan.build(3, 17, null, d0, Vird.DEFAULT, emptyMap(), 0, 4)
        assertEquals(listOf(DayTask.AZKAR, DayTask.READING, DayTask.VIRD, DayTask.STORY), items.map { it.task })
        assertEquals(3, DayPlan.total(items))
        assertEquals(0, DayPlan.doneCount(items))
    }

    private val list = Azkar.of(AzkarSet.MORNING, null).take(4)

    @Test fun theFirstUnfinishedOpensAndACompletedSetCanBeReread() {
        assertEquals(0, AzkarPages.opening(list, emptyMap()))
        assertEquals(1, AzkarPages.opening(list, mapOf(list.first().id to list.first().count.toLong())))
        assertEquals(0, AzkarPages.opening(list, list.associate { it.id to it.count.toLong() }))
    }

    @Test fun arrowsOnlyOfferAdjacentPagesAndNeverWrap() {
        for (n in 0..20) {
            for (p in 0 until n) {
                assertEquals((p - 1).takeIf { it >= 0 }, AzkarPages.neighbour(p, -1, n))
                assertEquals((p + 1).takeIf { it < n }, AzkarPages.neighbour(p, 1, n))
                assertNull(AzkarPages.neighbour(p, 2, n))
            }
        }
        assertNull(AzkarPages.neighbour(0, 1, 0))
    }

    @Test fun theRailShowsPositionNotCompletedRepetitions() {
        assertEquals(0f, AzkarPages.fraction(0f, 0), 0f)
        assertEquals(5f / 17, AzkarPages.fraction(4f, 17), 0f)
        assertEquals(5.5f / 17, AzkarPages.fraction(4.5f, 17), 0f)
        assertEquals(1f, AzkarPages.fraction(16f, 17), 0f)
    }
}
