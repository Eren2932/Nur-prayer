package com.nur.prayer

import com.nur.prayer.ui.NurNavigator
import com.nur.prayer.ui.ROUTE_AZKAR
import com.nur.prayer.ui.ROUTE_AZKAR_EVENING
import com.nur.prayer.ui.ROUTE_NAMES
import com.nur.prayer.ui.ROUTE_DHIKR
import com.nur.prayer.ui.ROUTE_TODAY
import com.nur.prayer.ui.ROUTE_VIRD
import com.nur.prayer.ui.ringWanted
import com.nur.prayer.ui.layerDepth
import com.nur.prayer.ui.shell.ShellRoutes
import com.nur.prayer.ui.today.SalawatGoal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DeedsTest {
    @Test fun goalUsesPersonalTotalsAndDoesNotOverflow() {
        val target = SalawatGoal.TARGET
        assertEquals(0, SalawatGoal.percent(Long.MIN_VALUE))
        assertEquals(0f, SalawatGoal.fraction(0), 0f)
        assertEquals(25, SalawatGoal.percent(126_529_699))
        assertEquals(.2530594f, SalawatGoal.fraction(126_529_699), 1e-6f)
        assertEquals(99, SalawatGoal.percent(target - 1))
        assertTrue(SalawatGoal.fraction(target - 1) < 1f)
        assertEquals(100, SalawatGoal.percent(target))
        assertEquals(100, SalawatGoal.percent(Long.MAX_VALUE))
        assertEquals(1f, SalawatGoal.fraction(Long.MAX_VALUE), 0f)
    }

    @Test fun readingGetsAnUninterruptedViewportAndSystemBackReturnsToDeeds() {
        for (page in listOf(ROUTE_NAMES, ROUTE_VIRD, ROUTE_AZKAR, ROUTE_AZKAR_EVENING, ROUTE_DHIKR)) {
            val nav = NurNavigator()
            nav.go(ROUTE_TODAY); nav.go(page)
            val state = nav.snapshot()
            val restored = NurNavigator(state.first(), state.drop(1))
            assertEquals(page, restored.current)
            val azkar = page == ROUTE_AZKAR || page == ROUTE_AZKAR_EVENING
            assertEquals(!azkar, ShellRoutes.islandOn(page))
            assertEquals(!azkar, ringWanted(page))
            assertFalse(ShellRoutes.capsuleOn(page))
            assertTrue(restored.back()); assertEquals(ROUTE_TODAY, restored.current)
        }
    }

    @Test fun openingADhikrFromVirdIsAForwardStep() {
        assertTrue(layerDepth(ROUTE_VIRD) > layerDepth(ROUTE_TODAY))
        assertTrue(layerDepth(ROUTE_DHIKR) > layerDepth(ROUTE_VIRD))
        val nav = NurNavigator()
        nav.go(ROUTE_TODAY); nav.go(ROUTE_VIRD); nav.go(ROUTE_DHIKR)
        assertTrue(nav.back()); assertEquals(ROUTE_VIRD, nav.current)
        assertTrue(nav.back()); assertEquals(ROUTE_TODAY, nav.current)
    }
}
