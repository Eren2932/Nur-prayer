package com.nur.prayer

import com.nur.prayer.ui.shell.PanelLayout
import com.nur.prayer.ui.shell.ShellMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.39.0: the geometry of the open panel, pinned to the numbers measured on the owner's mock (393 dp wide). */
class PanelLayoutTest {
    @Test fun theSlabHasTheMocksWidthOnItsScreenAndNeverGrowsPastTheCap() {
        assertEquals(344f, PanelLayout.width(393f), 1e-3f)
        assertEquals(PanelLayout.MAX_WIDTH, PanelLayout.width(1000f), 0f)
        assertEquals(0f, PanelLayout.width(40f), 0f)
        // At the mock's screen it is the mock's 344.4 within half a dp.
        assertEquals(PanelLayout.REFERENCE_WIDTH, PanelLayout.width(393f), 0.5f)
    }

    @Test fun theGridStandsWhereTheMockPutsItsDiscs() {
        val w = PanelLayout.REFERENCE_WIDTH
        assertEquals(62.4f, PanelLayout.gridEnd, 1e-3f)
        assertEquals(PanelLayout.CELL, PanelLayout.cellWidth(w), 1e-3f)
        // Measured centres, dp from the slab's left edge: 43.3, 110.9, 179.5, 247.7.
        val measured = listOf(43.3f, 110.9f, 179.5f, 247.7f)
        measured.forEachIndexed { i, centre ->
            assertEquals(centre, PanelLayout.cellCenter(w, i), 1f)
        }
        assertEquals(43.3f, PanelLayout.cellCenter(w, 0), 1e-3f)
        // The settings icon: 314.9 measured.
        assertEquals(314.9f, PanelLayout.gearCenter(w), 0.5f)
    }

    @Test fun theLabelSitsWhereTheMockHasIt() {
        assertEquals(19.1f, PanelLayout.LABEL_UNDER_DISC, 1e-3f)
        assertTrue(PanelLayout.DISC_TOP + PanelLayout.DISC < PanelLayout.LABEL_BASELINE)
        assertTrue(PanelLayout.LABEL_BASELINE < PanelLayout.HEIGHT)
    }

    @Test fun theCornerIsASlabsNotAPills() {
        assertTrue(PanelLayout.CORNER < PanelLayout.HEIGHT / 2f)
    }

    @Test fun theCellsStayAClearOfTheSettingsOnEveryWidth() {
        for (screen in listOf(320f, 360f, 393f, 411f, 600f, 840f)) {
            val w = PanelLayout.width(screen)
            val cellsEnd = PanelLayout.GRID_START + PanelLayout.CELLS * PanelLayout.cellWidth(w)
            val gearLeft = PanelLayout.gearCenter(w) - PanelLayout.GEAR_HIT / 2f
            assertTrue("settings clear of the cells at $screen dp", gearLeft >= cellsEnd)
            // A cell is wide enough for «Кыбла» at 14 sp bold (about 40 dp).
            assertTrue("cell wide enough at $screen dp", PanelLayout.cellWidth(w) >= 48f)
            // The icon's touch box is inside the slab.
            assertTrue(PanelLayout.gearCenter(w) + PanelLayout.GEAR_HIT / 2f <= w)
        }
    }

    @Test fun theSettingsIconOpensAfterTheSections() {
        assertTrue(PanelLayout.GEAR_RANK > ShellMath.cellRank(0, PanelLayout.CELLS))
        val lastDone = ShellMath.CELL_START + PanelLayout.GEAR_RANK * ShellMath.CELL_STAGGER + ShellMath.CELL_SPAN
        assertTrue(lastDone < 1f)
    }
}
