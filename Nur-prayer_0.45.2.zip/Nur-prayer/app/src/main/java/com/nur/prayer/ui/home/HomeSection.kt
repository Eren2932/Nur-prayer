package com.nur.prayer.ui.home

import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.shell.ShellGlyph

/*
 * 0.27.0 «Капсула»: the sections of the panel the capsule opens into, in the order of its grid
 * (three across, read like a page). Settings are not in the grid: the avatar on home opens them.
 */
enum class HomeSection(val glyph: ShellGlyph) {
    QURAN(ShellGlyph.BOOK),
    DHIKR(ShellGlyph.TASBIH),
    QIBLA(ShellGlyph.KAABA),
    TODAY(ShellGlyph.CHECKLIST),
    COURSE(ShellGlyph.AIN),
    SCHEDULE(ShellGlyph.CALENDAR),
    SETTINGS(ShellGlyph.DOTS);

    fun label(): String = when (this) {
        QURAN -> tr("Коран")
        DHIKR -> tr("Зикр")
        QIBLA -> tr("Кыбла")
        TODAY -> tr("Дела")
        COURSE -> tr("Учёба")
        SCHEDULE -> tr("Месяц")
        SETTINGS -> tr("Настройки")
    }

    companion object {
        /**
         * The panel grid: one row of four. 0.37.0: the Quran left the panel for the bar's own button (the panel does not
         * repeat what the bar has); the azkar were never a section, they live in «Дела». 0.38.0: «Учёба» left it too,
         * it is the pill of the bar now (the section itself, [COURSE], is the same: the pill opens it).
         */
        val GRID: List<HomeSection> = listOf(DHIKR, QIBLA, TODAY, SCHEDULE)
    }
}
