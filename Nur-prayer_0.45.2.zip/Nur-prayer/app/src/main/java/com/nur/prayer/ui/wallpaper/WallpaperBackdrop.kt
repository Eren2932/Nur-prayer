package com.nur.prayer.ui.wallpaper

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import com.nur.prayer.ui.components.SkyBackdrop
import com.nur.prayer.ui.shell.rememberFrost
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette
import kotlin.math.hypot
import kotlin.math.max

/**
 * 0.22.0: the backdrop of the whole app is a wallpaper.
 *
 * The sky and black are drawn by [SkyBackdrop] exactly as before; a picture is drawn by [WallpaperLayer]
 * with its computed scrim. A change of wallpaper is not a cut: the new one is decoded first (never an
 * empty frame), then grows out of the button that set it as a circle with a soft light ring on its
 * edge, over the old one — a drop of paint, not a slide.
 *
 * [dim] (read only while drawing, so a moving calendar never recomposes this) darkens a picture
 * under pages that put lists of text on the backdrop: the scrim contract covers the home layout only.
 *
 * 0.27.1: the same number also *blurs* it. Under a page the sharp wallpaper gives way to the frosted
 * copy of itself (the one the capsule's glass already carries), so a page reads as a calm, dark
 * window onto the picture instead of a darkened poster, and the glass of the capsule, the panel and
 * the island sits on exactly the same picture. No blur is computed per frame: it is a second draw of
 * a ~40 × 90 px bitmap, cross-faded by [dim].
 *
 * 0.34.0: the blur and the black are two numbers now ([blur], [dim]; [blur] defaults to [dim], so nothing changes
 * for the calendar and Qibla), and [shade] is a third, black only: the settings of the reference are a SHARP
 * wallpaper darkened by [PAGE_DIM], with glass cards on it.
 */
@Composable
fun WallpaperBackdrop(
    wallpaper: Wallpaper,
    palette: PhasePalette,
    motionEnabled: Boolean,
    dim: () -> Float,
    modifier: Modifier = Modifier,
    /** 0..1: how much of the black page scrim is lifted (the calendar over a light picture). */
    lift: () -> Float = { 0f },
    /** 0..1: how much of the frosted copy shows. By default it follows [dim]; settings keep the picture sharp. */
    blur: () -> Float = dim,
    /**
     * 0..1: the black page scrim alone, over ANY wallpaper (the live sky and black too) and without the blur.
     * The settings and the city page lie on it: a sharp picture, dimmed as in the reference, readable on a noon sky.
     */
    shade: () -> Float = { 0f },
    /**
     * 0.41.0, 0..1: how much of the SOFT copy (about 3 dp of blur, [WallpaperImages.soft]) shows. «Дела» lies on it: the
     * picture stays a picture, only calmer. It is drawn under the frost, so a page that also asks for [blur] covers it.
     */
    soft: () -> Float = { 0f }
) {
    val frost = rememberFrost()
    val softCopy = rememberSoftBackdrop(wallpaper)
    Box(modifier.fillMaxSize().deedsWindowWash(wallpaper.isImage, soft)
        .onSizeChanged { WallpaperScreen.size.value = it }) {
        RevealingWallpaper(wallpaper, palette, motionEnabled)
        Box(
            Modifier
                .fillMaxSize()
                .drawBehind {
                    val image = wallpaper.isImage
                    val k = if (image) dim().coerceIn(0f, 1f) else 0f
                    val b = if (image) blur().coerceIn(0f, 1f) else 0f
                    val sf = if (image) soft().coerceIn(0f, 1f) else 0f
                    if (sf > 0.001f) {
                        val calm = softCopy.value
                        if (calm != null) drawWallpaperIn(calm, wallpaper, size.width, size.height, FilterQuality.Low, alpha = sf)
                    }
                    if (b > 0.001f) {
                        val blurred = frost.bitmap
                        val of = frost.wallpaper
                        if (blurred != null && of != null && of.id == wallpaper.id) {
                            drawWallpaperIn(blurred, of, size.width, size.height, FilterQuality.Low, alpha = b)
                        }
                    }
                    // One black layer, never two: the strongest of the page scrim and the settings shade.
                    val black = max(k * (1f - lift().coerceIn(0f, 1f)), shade().coerceIn(0f, 1f)) * PAGE_DIM
                    if (black > 0.001f) drawRect(Color.Black.copy(alpha = black))
                }
        )
    }
}

/** The soft copy of [wallpaper] for the current screen; null until it is made (the sharp picture shows meanwhile). */
@Composable
private fun rememberSoftBackdrop(wallpaper: Wallpaper): State<ImageBitmap?> {
    val context = LocalContext.current.applicationContext
    val screen by WallpaperScreen.size
    val state = remember(wallpaper.id, screen) {
        mutableStateOf(if (wallpaper.isImage) WallpaperImages.peekSoft(wallpaper, screen.width, screen.height) else null)
    }
    LaunchedEffect(state) {
        if (wallpaper.isImage && state.value == null) state.value = WallpaperImages.soft(context, wallpaper, screen.width, screen.height)
    }
    return state
}

/**
 * [WallpaperLayer] that changes by a growing circle from the point the user tapped (root px — the box
 * is expected to start at the root's top-left, give or take [originShift]).
 *
 * 0.23.0:
 *  - Only a change the user just made ([WallpaperScreen.requestReveal]) is "set" with the circle. The
 *    stored wallpaper arriving after launch is not a new choice: it fades in quietly over the dark
 *    placeholder, so opening the app no longer replays the installation every time.
 *  - The new picture (and its scrim) is decoded before anything moves: never an empty frame.
 *  - A change during a running reveal finishes the old one at once (`finally`), so the old picture can
 *    never stay stuck under a half-open circle.
 */
@Composable
internal fun RevealingWallpaper(
    wallpaper: Wallpaper,
    palette: PhasePalette,
    motionEnabled: Boolean,
    modifier: Modifier = Modifier,
    sharp: Boolean = true,
    originShift: Offset = Offset.Zero
) {
    val context = LocalContext.current.applicationContext
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var shown by remember { mutableStateOf(wallpaper) }
    var under by remember { mutableStateOf<Wallpaper?>(null) }
    var origin by remember { mutableStateOf(Offset.Unspecified) }
    var circle by remember { mutableStateOf(true) }
    val reveal = remember { Animatable(1f) }

    LaunchedEffect(wallpaper) {
        if (wallpaper == shown) return@LaunchedEffect
        val s = boxSize
        if (wallpaper.isImage && s.width > 0 && s.height > 0) {
            val div = if (sharp) 1 else SOFT_DIVISOR
            WallpaperImages.load(context, wallpaper, s.width / div, s.height / div)
            if (sharp) WallpaperImages.scrim(context, wallpaper, s.width, s.height)
        }
        val requested = WallpaperScreen.revealFor(wallpaper.id)
        circle = requested != null
        origin = if (requested != null && requested.isSpecified) requested - originShift else Offset.Unspecified
        under = shown
        shown = wallpaper
        try {
            reveal.snapTo(0f)
            reveal.animateTo(
                1f,
                if (circle) tween(REVEAL_MILLIS, easing = RevealEasing) else tween(QUIET_MILLIS, easing = LinearOutSlowInEasing)
            )
        } finally {
            under = null
        }
    }

    Box(modifier.fillMaxSize().onSizeChanged { boxSize = it }) {
        under?.let { WallpaperLayer(it, palette, motionEnabled = false, sharp = sharp) }
        WallpaperLayer(
            shown, palette, motionEnabled && under == null,
            Modifier
                .graphicsLayer { alpha = if (under != null && !circle) reveal.value.coerceIn(0f, 1f) else 1f }
                .drawWithContent {
                    val p = reveal.value
                    if (p >= 1f || under == null || !circle) {
                        drawContent()
                        return@drawWithContent
                    }
                    val c = if (origin.isSpecified) origin else Offset(size.width / 2f, size.height * 0.92f)
                    val far = max(
                        max(hypot(c.x, c.y), hypot(size.width - c.x, c.y)),
                        max(hypot(c.x, size.height - c.y), hypot(size.width - c.x, size.height - c.y))
                    )
                    val r = far * p
                    val circlePath = Path().apply { addOval(Rect(c, r)) }
                    clipPath(circlePath) { this@drawWithContent.drawContent() }
                    // The wet edge of the paint: a light ring that fades as the circle grows.
                    drawCircle(Color.White.copy(alpha = 0.28f * (1f - p)), r, c, style = Stroke(width = 10f + 26f * (1f - p)))
                },
            sharp = sharp
        )
    }
}

/**
 * One wallpaper filling its box. [sharp] = false draws the picture from a small copy, stretched:
 * a soft, free blur (the gallery puts it behind its own content on every Android version).
 */
@Composable
internal fun WallpaperLayer(
    wallpaper: Wallpaper,
    palette: PhasePalette,
    motionEnabled: Boolean,
    modifier: Modifier = Modifier,
    sharp: Boolean = true
) {
    if (!wallpaper.isImage) {
        SkyBackdrop(palette, modifier, sky = wallpaper.kind == Wallpaper.Kind.SKY, motionEnabled = motionEnabled && sharp)
        return
    }
    BoxWithConstraints(modifier.fillMaxSize()) {
        val w = constraints.maxWidth
        val h = constraints.maxHeight
        val div = if (sharp) 1 else SOFT_DIVISOR
        val bitmap by rememberWallpaperBitmap(wallpaper, w / div, h / div)
        val scrim by rememberWallpaperScrim(wallpaper, w, h)
        Canvas(Modifier.fillMaxSize()) {
            drawRect(Ink)
            val b = bitmap ?: return@Canvas
            drawWallpaper(b, wallpaper, if (sharp) FilterQuality.High else FilterQuality.Low)
            if (sharp) scrim?.let { drawScrim(it) }
        }
    }
}

/** Black over a picture under a page of text (calendar, Today, Qibla): enough for 4.5:1 on any picture. */
internal const val PAGE_DIM = 0.62f
private const val REVEAL_MILLIS = 760
/** A quiet change (the stored wallpaper arriving at launch): a short fade, not a "set". */
private const val QUIET_MILLIS = 220
/** The gallery backdrop: soft, but still recognisably the picture (10 read as a dark smear). */
private const val SOFT_DIVISOR = 4

/** Starts fast like a dropped blob, then slows down as it reaches the corners. */
private val RevealEasing = CubicBezierEasing(0.2f, 0.9f, 0.3f, 1f)
