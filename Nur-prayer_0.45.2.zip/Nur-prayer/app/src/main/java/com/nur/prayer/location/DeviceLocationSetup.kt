package com.nur.prayer.location

import android.app.PendingIntent
import android.content.Context
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.Priority
import kotlin.coroutines.resume
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull

/** Google is optional and is used ONLY for its consent surface; fixes still come from Android. */
internal sealed interface DeviceLocationSetup {
    data object UsePlatform : DeviceLocationSetup
    data class Prompt(val consent: PendingIntent) : DeviceLocationSetup
}

internal suspend fun checkDeviceLocationSetup(context: Context, precise: Boolean): DeviceLocationSetup {
    val app = context.applicationContext
    return try {
        if (GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(app) != ConnectionResult.SUCCESS)
            return DeviceLocationSetup.UsePlatform
        val priority = if (precise) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        val settings = LocationSettingsRequest.Builder()
            .addLocationRequest(LocationRequest.Builder(priority, 10_000L).build()).setAlwaysShow(true).build()
        withTimeoutOrNull(5_000L) {
            suspendCancellableCoroutine<DeviceLocationSetup> { reply ->
                LocationServices.getSettingsClient(app).checkLocationSettings(settings).addOnCompleteListener { task ->
                    if (!reply.isActive) return@addOnCompleteListener
                    val error = task.exception as? ResolvableApiException
                    val pending = error?.takeIf { it.statusCode == com.google.android.gms.location.LocationSettingsStatusCodes.RESOLUTION_REQUIRED }?.resolution
                    reply.resume(if (pending == null) DeviceLocationSetup.UsePlatform else DeviceLocationSetup.Prompt(pending))
                }
            }
        } ?: DeviceLocationSetup.UsePlatform
    } catch (cancel: CancellationException) { throw cancel }
    catch (_: Exception) { DeviceLocationSetup.UsePlatform }
}
