package com.nur.prayer

import com.nur.prayer.i18n.tr

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.IntentSenderRequest
import androidx.lifecycle.withResumed
import com.nur.prayer.location.DeviceLocationSetup
import com.nur.prayer.location.checkDeviceLocationSetup
import kotlinx.coroutines.Job
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.nur.prayer.icon.AppIconSwitcher
import com.nur.prayer.location.LocationRequestPolicy
import com.nur.prayer.location.LocationRequestStep
import com.nur.prayer.notify.AzanPlayerService
import com.nur.prayer.notify.PrayerAlarmScheduler
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.AppViewModel
import com.nur.prayer.ui.NurRoot
import com.nur.prayer.ui.components.LaunchScreen
import com.nur.prayer.ui.theme.NurTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.nur.prayer.ui.AppEntry
import com.nur.prayer.ui.welcome.WelcomeFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()
    private var permissionEpoch by mutableIntStateOf(0)
    private var awaitingLocationSettings by mutableStateOf(false)
    private var askingLocation by mutableStateOf(false)
    private enum class SetupStage { IDLE, CHECKING, CONSENT }
    private var setupStage by mutableStateOf(SetupStage.IDLE)
    private var setupJob: Job? = null
    private var launchCoverVisible by mutableStateOf(false)

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { permissionEpoch++; viewModel.onPermissionsChanged() }

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (!askingLocation) return@registerForActivityResult
        askingLocation = false
        // "Only this time" expiring is not a permanent denial. Only a delivered negative
        // answer without a rationale redirects subsequent taps to app settings.
        val granted = viewModel.hasLocationPermission()
        getPreferences(MODE_PRIVATE).edit().putBoolean("location_permission_blocked",
            !granted && it.isNotEmpty() && !locationRationale()).apply()
        if (granted) {
            beginDeviceSetup() // never open Android Settings as a side effect of granting access
        } else {
            awaitingLocationSettings = false
            val step = nextLocationStep()
            viewModel.locationNeedsAction(step,
                tr("Доступ не выдан — разрешите точное или приблизительное местоположение"))
        }
    }

    private val locationSettings = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        finishSettingsReturn()
    }

    // Keep registered unconditionally so ActivityResultRegistry can redeliver after process death.
    private val deviceConsent = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (setupStage != SetupStage.CONSENT) return@registerForActivityResult
        setupStage = SetupStage.IDLE
        if (result.resultCode == RESULT_OK) usePlatformIfReady()
        else viewModel.locationNeedsAction(LocationRequestStep.LOCATE,
            tr("Включение отменено. Можно повторить или выбрать город вручную."))
    }

    /** Set by the launch screen's first composition: until then the system splash stays up. */
    @Volatile private var launchScreenDrawn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        // 0.24.0: swaps Theme.Nur.Starting (white, the «Нур» disc) for Theme.Nur. Must run before super.
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        awaitingLocationSettings = savedInstanceState?.getBoolean("awaiting_location_settings") ?: false
        askingLocation = savedInstanceState?.getBoolean("asking_location") ?: false
        setupStage = SetupStage.entries.firstOrNull { it.name == savedInstanceState?.getString("device_setup_stage") } ?: SetupStage.IDLE
        launchCoverVisible = savedInstanceState == null
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        syncSystemBars()
        runCatching { AppIconSwitcher.migrateArtworkSwap(this) }

        setContent {
            NurTheme {
                // A non-Russian first-run screen counts as a successful start too.
                LaunchedEffect(Unit) { kotlinx.coroutines.delay(1500); com.nur.prayer.i18n.L10n.confirm() }
                val entry by viewModel.entry.collectAsStateWithLifecycle()
                val locating by viewModel.locating.collectAsStateWithLifecycle()
                val locationStatus by viewModel.locationStatus.collectAsStateWithLifecycle()
                val locationStep by viewModel.locationStep.collectAsStateWithLifecycle()
                val committing by viewModel.committingPlace.collectAsStateWithLifecycle()
                val deviceBusy = askingLocation || awaitingLocationSettings || setupStage != SetupStage.IDLE || locating || committing
                val data = (entry as? AppEntry.Home)?.schedule
                if (data == null) {
                    if (entry == AppEntry.Welcome) WelcomeFlow(
                        busy = deviceBusy, launchCoverVisible = launchCoverVisible,
                        status = locationStatus,
                        step = locationStep,
                        search = viewModel::cities,
                        onLocate = ::requestLocation,
                        onPick = ::pickCity
                    ) else Box(Modifier.fillMaxSize().background(Color(0xFF06152E)))
                    return@NurTheme
                }
                // Deliberately *not* `by`: the clock travels down the tree as state, so this
                // composable never recomposes on a tick. See the doc on `NurRoot.now`.
                val now = viewModel.now.collectAsStateWithLifecycle()
                // System dialogs return through onResume. Re-check immediately rather than
                // reading the clock here and invalidating the root once every minute.
                val exactAllowed = remember(permissionEpoch) {
                    PrayerAlarmScheduler.canScheduleExact(this@MainActivity)
                }
                val notificationsAllowed = remember(permissionEpoch) {
                    androidx.core.app.NotificationManagerCompat.from(this@MainActivity).areNotificationsEnabled()
                }

                NurRoot(
                    data = data,
                    now = now,
                    locating = deviceBusy,
                    locationStatus = locationStatus,
                    locationButtonLabel = locationStep.buttonLabel,
                    exactAlarmsAllowed = exactAllowed,
                    notificationsAllowed = notificationsAllowed,
                    citySearch = { query -> viewModel.cities(query) },
                    onPickCity = ::pickCity,
                    actionsFactory = { openCityPicker ->
                        AppActions(
                            openCityPicker = openCityPicker,
                            requestLocation = { requestLocation() },
                            openLocationPermissions = { openLocationPermissions() },
                            openExactAlarmSettings = { openExactAlarmSettings() },
                            openBatterySettings = { openBatterySettings() },
                            openNotificationSettings = { openNotificationSettings() },
                            setMethod = { method ->
                                lifecycleScope.launch { viewModel.repository.setMethod(method) }
                            },
                            setMadhab = { madhab ->
                                lifecycleScope.launch { viewModel.repository.setMadhab(madhab) }
                            },
                            setHighLatitudeRule = { rule ->
                                lifecycleScope.launch { viewModel.repository.setHighLatitudeRule(rule) }
                            },
                            setRounding = { mode ->
                                lifecycleScope.launch { viewModel.repository.setRounding(mode) }
                            },
                            setNotification = { prayer, enabled ->
                                viewModel.setNotification(prayer, enabled)
                            },
                            setOffset = { prayer, minutes -> viewModel.setOffset(prayer, minutes) },
                            setAmbientBackdrop = { enabled ->
                                lifecycleScope.launch { viewModel.repository.setAmbientBackdrop(enabled) }
                            },
                            setSkyBackdrop = { enabled ->
                                lifecycleScope.launch { viewModel.repository.setSkyBackdrop(enabled) }
                            },
                            setWallpaper = { id ->
                                lifecycleScope.launch { viewModel.repository.setWallpaper(id) }
                            },
                            setHomeLayout = { layout ->
                                lifecycleScope.launch { viewModel.repository.setHomeLayout(layout) }
                            },
                            setPreAlert = { minutes ->
                                lifecycleScope.launch { viewModel.repository.setPreAlert(minutes) }
                            },
                            setAzanSound = { sound ->
                                lifecycleScope.launch { viewModel.repository.setAzanSound(sound) }
                            },
                            previewAzan = { sound ->
                                AzanPlayerService.play(
                                    this@MainActivity,
                                    tr("Проверка азана"),
                                    sound.title,
                                    sound,
                                    preview = true
                                )
                            },
                            stopAzan = { AzanPlayerService.stopPreview(this@MainActivity) },
                            setHijriOffset = { days ->
                                lifecycleScope.launch { viewModel.repository.setHijriOffset(days) }
                            }
                        )
                    }
                )
            }
        }

        // A fresh start only: a rotation or a re-created activity must not replay the launch screen.
        if (savedInstanceState == null) showLaunchScreen(splash)
    }

    /**
     * 0.24.0: the launch screen above the app. A separate ComposeView on top of the content, so NurRoot
     * is composed and loading underneath the whole time and is simply uncovered when the data is there.
     * The system splash shows the same picture (white, the «Нур» disc in the middle) and is removed without
     * its own exit animation the moment the first frame of this one is ready: no black window between.
     */
    private fun showLaunchScreen(splash: SplashScreen) {
        val deadline = SystemClock.uptimeMillis() + 1500L
        splash.setKeepOnScreenCondition { !launchScreenDrawn && SystemClock.uptimeMillis() < deadline }
        splash.setOnExitAnimationListener { it.remove() }
        val overlay = ComposeView(this)
        overlay.setContent {
            NurTheme {
                val entry by viewModel.entry.collectAsStateWithLifecycle()
                LaunchScreen(
                    ready = entry != AppEntry.Loading,
                    onShown = { launchScreenDrawn = true },
                    onFinished = { overlay.post { (overlay.parent as? ViewGroup)?.removeView(overlay); launchCoverVisible = false } }
                )
            }
        }
        addContentView(overlay, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    override fun onResume() {
        super.onResume()
        permissionEpoch++
        syncSystemBars()
        // Self-heal the alarm chain and the clock every time the user opens the app.
        // Forget a past permanent denial once Android settings grants access. Otherwise an
        // expiring one-time grant or automatic permission reset could send a later tap to settings.
        val prefs = getPreferences(MODE_PRIVATE)
        if (prefs.getBoolean("location_permission_blocked", false) && viewModel.hasLocationPermission()) {
            prefs.edit().remove("location_permission_blocked").apply()
        }
        if (setupStage == SetupStage.CHECKING) checkWhenResumed()
        viewModel.refresh()
        viewModel.onPermissionsChanged()
    }

    override fun onStart() {
        super.onStart()
        viewModel.setForeground(true)
    }

    override fun onStop() {
        viewModel.setForeground(false)
        // Left normally: whatever language is showing did not crash the process.
        com.nur.prayer.i18n.L10n.confirm()
        // A new launcher icon is applied only once the app is off screen: see AppIconSwitcher.
        if (!isChangingConfigurations) runCatching { AppIconSwitcher.applyPending(this) }
        super.onStop()
    }

    private fun syncSystemBars() {
        // 0.18.0 (targetSdk 35): edge-to-edge is no longer a choice — Android 15 draws the app under
        // both system bars and ignores the window bar colours (status, navigation, divider), so
        // they are not set any more. enableEdgeToEdge() in onCreate makes the bars transparent; the sky
        // runs under them, and on three-button navigation NurRoot draws the translucent scrim itself.
        // What is left to say here: no system scrim over the buttons, and the icon tone — light on
        // the sky, dark while the Quran's paper page is open (0.18.4, see SystemBarsTone).
        if (Build.VERSION.SDK_INT >= 29) {
            // App-owned, continuous contrast gradients; do not add an OEM contrast plate at either edge.
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        com.nur.prayer.ui.theme.SystemBarsTone.apply(window)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("device_setup_stage", setupStage.name)
        outState.putBoolean("asking_location", askingLocation)
        outState.putBoolean("awaiting_location_settings", awaitingLocationSettings)
        super.onSaveInstanceState(outState)
    }

    private fun locationRationale(): Boolean = shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_COARSE_LOCATION) ||
        shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun nextLocationStep(): LocationRequestStep = LocationRequestPolicy.next(
        hasPermission = viewModel.hasLocationPermission(),
        askedBefore = getPreferences(MODE_PRIVATE).getBoolean("location_permission_blocked", false),
        showRationale = locationRationale(),
        locationEnabled = viewModel.isLocationEnabled())

    private fun requestLocation() {
        if (askingLocation || awaitingLocationSettings || setupStage != SetupStage.IDLE || viewModel.locating.value || viewModel.committingPlace.value) return
        when (val step = nextLocationStep()) {
            LocationRequestStep.LOCATE, LocationRequestStep.OPEN_LOCATION_SETTINGS -> beginDeviceSetup()
            LocationRequestStep.REQUEST_PERMISSION -> {
                askingLocation = true
                try {
                    locationPermission.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                } catch (_: android.content.ActivityNotFoundException) {
                    askingLocation = false
                    viewModel.locationNeedsAction(step, tr("Не удалось открыть системный экран. Включите геолокацию и доступ к ней в настройках Android вручную."))
                }
            }
            LocationRequestStep.OPEN_APP_SETTINGS -> {
                // A permanently denied permission has no in-app grant API. Label the next tap
                // explicitly: a generic Detect must never navigate away from the welcome page.
                if (viewModel.locationStep.value == step && viewModel.locationStatus.value != null)
                    openLocationPermissions()
                else viewModel.locationNeedsAction(step,
                    tr("Откройте «Разрешения → Местоположение» и разрешите доступ при использовании. После возврата запрос продолжится."))
            }
        }
    }

    private fun pickCity(city: com.nur.prayer.data.City) {
        setupJob?.cancel(); setupJob = null
        setupStage = SetupStage.IDLE
        awaitingLocationSettings = false
        askingLocation = false
        viewModel.selectCity(city)
    }

    private fun beginDeviceSetup() {
        if (setupStage != SetupStage.IDLE) return
        setupStage = SetupStage.CHECKING
        checkWhenResumed()
    }

    private fun checkWhenResumed() {
        if (setupJob?.isActive == true || setupStage != SetupStage.CHECKING) return
        setupJob = lifecycleScope.launch {
            val precise = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            val result = checkDeviceLocationSetup(this@MainActivity, precise)
            lifecycle.withResumed {
                if (setupStage != SetupStage.CHECKING) return@withResumed
                if (result is DeviceLocationSetup.Prompt && viewModel.hasLocationPermission()) {
                    setupStage = SetupStage.CONSENT
                    try { deviceConsent.launch(IntentSenderRequest.Builder(result.consent).build()) }
                    catch (_: Exception) { setupStage = SetupStage.IDLE; usePlatformIfReady() }
                } else {
                    setupStage = SetupStage.IDLE
                    usePlatformIfReady()
                }
            }
        }
    }

    private fun usePlatformIfReady() {
        when {
            !viewModel.hasLocationPermission() -> viewModel.locationNeedsAction(nextLocationStep(),
                tr("Доступ не выдан — разрешите точное или приблизительное местоположение"))
            viewModel.isLocationEnabled() -> viewModel.useDeviceLocation(forceFresh = true)
            else -> viewModel.locationNeedsAction(LocationRequestStep.LOCATE,
                tr("Включите геолокацию в шторке Android и повторите или выберите город вручную."))
        }
    }

    private fun openLocationPermissions() {
        if (setupStage != SetupStage.IDLE || askingLocation || awaitingLocationSettings) return
        awaitingLocationSettings = true
        viewModel.locationNeedsAction(LocationRequestStep.OPEN_APP_SETTINGS,
            tr("В разделе «Разрешения → Местоположение» можно включить точный доступ. После возврата Nur запросит новую точку."))
        openLocationSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")),
            LocationRequestStep.OPEN_APP_SETTINGS)
    }

    private fun openLocationSettings(intent: Intent, step: LocationRequestStep) {
        runCatching { locationSettings.launch(intent) }.onFailure {
            awaitingLocationSettings = false
            viewModel.locationNeedsAction(step, tr("Не удалось открыть системный экран. Включите геолокацию и доступ к ней в настройках Android вручную."))
        }
    }

    private fun finishSettingsReturn() {
        if (!awaitingLocationSettings) return
        awaitingLocationSettings = false
        if (viewModel.hasLocationPermission()) beginDeviceSetup()
        else viewModel.locationNeedsAction(nextLocationStep(),
            tr("Доступ к местоположению пока не выдан. Нажмите кнопку разрешения или выберите город вручную."))
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            }
        }
    }

    private fun openNotificationSettings() {
        // Notifications are separate: ask only when the user opens their notification action.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            val prefs = getPreferences(MODE_PRIVATE)
            if (!prefs.getBoolean("notifications_requested", false) || shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                prefs.edit().putBoolean("notifications_requested", true).apply()
                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        runCatching {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
    }

    private fun openBatterySettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }.onFailure {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
    }

}
