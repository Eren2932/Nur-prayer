package com.nur.prayer.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/** Backgrounds and scrims use the whole window. Only their content avoids bars/cutouts.
 * Bottom space belongs to the dock, IME or scrolling screen; never add it twice here.
 * Compose consumes these insets, so nested controls can use the same rule safely. */
@Composable
internal fun Modifier.pageContentInsets(): Modifier = windowInsetsPadding(
    WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal)
)
