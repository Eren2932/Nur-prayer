package com.nur.prayer.ui.names

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.QuranRepository
import com.nur.prayer.quran.QuranTranslation
import com.nur.prayer.ui.schedule.PageMotion
import com.nur.prayer.ui.schedule.PeriodPager
import com.nur.prayer.ui.theme.uiScale
import com.nur.prayer.ui.today.DeedTone

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun NamesReader(rows: List<NameEntry>, startId: Int, onList: () -> Unit, onRead: (Int) -> Unit) {
    val pager = rememberPagerState(initialPage = (startId - 1).coerceIn(rows.indices)) { rows.size }
    val save by rememberUpdatedState(onRead)
    LaunchedEffect(pager, rows) { snapshotFlow { pager.settledPage }.collect { save(rows[it].id) } }
    Column(Modifier.fillMaxSize().padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            NameAction(tr("К списку"), false, onClick = onList)
        }
        PeriodPager(pager, Modifier.fillMaxWidth().weight(1f).testTag("names-pager"), motion = PageMotion.READING) { index -> NameLeaf(rows[index]) }
        // Keep the previous 48 dp footer (and therefore the paper's viewport), but not its two buttons.
        Box(Modifier.fillMaxWidth().heightIn(min = 48.dp), contentAlignment = Alignment.Center) {
            Text("${rows[pager.settledPage].id} / ${rows.size}", color = DeedTone.Ink,
                modifier = Modifier.background(NamesPaper, RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 6.dp))
        }
    }
}

@Composable
private fun NameLeaf(item: NameEntry) {
    val ui = uiScale()
    // One paper surface, one vertical scroll owner. The name, commentary and verse no
    // longer scroll as three disconnected cards. No text length cap on the reading page.
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)
        .clip(RoundedCornerShape(12.dp)).background(NamesPaper)
        .testTag("name-leaf-${item.id}").verticalScroll(rememberScrollState(), flingBehavior = rememberNamesFling()).padding(horizontal = 18.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)) {
            NameArabic(item.arabic, 40f)
            Text(item.reading, fontSize = ui.t(24f), lineHeight = ui.t(29f), fontWeight = FontWeight.Bold,
                color = DeedTone.Ink, textAlign = TextAlign.Center)
            Text(item.headline, fontSize = ui.t(18f), lineHeight = ui.t(23f), color = Color.Black,
                fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        }
        Text(item.note, fontSize = ui.t(17f), lineHeight = ui.t(26f), fontWeight = FontWeight.Normal, color = DeedTone.Ink)
        Text(tr("По книге аль-Газали «Аль-Максад аль-асна» · пересказ"), color = DeedTone.Quiet,
            fontSize = ui.t(12f), lineHeight = ui.t(17f))
        item.verse?.let { (surah, ayah) -> NameVerse(surah, ayah) }
    }
}

@Composable
private fun NameVerse(surah: Int, ayah: Int) {
    val ui = uiScale(); val context = LocalContext.current
    val book = remember(context) { QuranRepository.get(context) }
    fun cached() = book.cached(surah)?.firstOrNull { it.number == ayah }?.translation(QuranTranslation.RU)
    var quote by remember(surah, ayah) { mutableStateOf(cached()) }
    LaunchedEffect(book, surah, ayah) {
        quote = book.surah(surah).firstOrNull { it.number == ayah }?.translation(QuranTranslation.RU)
    }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(tr("Коран · {0}:{1}", surah, ayah), color = NamesJade, fontWeight = FontWeight.SemiBold)
        quote?.let { Text(it, fontSize = ui.t(16f), lineHeight = ui.t(24f), color = DeedTone.Ink) }
        Text(tr("Перевод смыслов: Эльмир Кулиев"), color = DeedTone.Quiet, fontSize = ui.t(12f), lineHeight = ui.t(17f))
    }
}
