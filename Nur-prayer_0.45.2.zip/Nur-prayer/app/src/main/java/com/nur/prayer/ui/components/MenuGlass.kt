package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.uiScale

/*
 * The card of the settings menu. 0.34.0 made it glass (blue, 68 % opaque, a white rim); 0.34.1 replaces that with the
 * flat grey of the new reference (576 × 1280 px of a 393 dp phone, 1.4656 px per dp), measured, not drawn by eye.
 * The object keeps its name so every user of it (settings, «Город») follows without a change.
 *
 *  - Fill. A flat neutral grey, #272728. Fitted over the whole picture: the card's pixels move by 0.07 for every
 *    1.0 the wallpaper behind it moves (correlation 0.34), i.e. the card is opaque; it does not take the blue of the
 *    wallpaper any more and shows nothing through itself.
 *  - No rim. The reference's edge goes from the page straight to the fill, with no lighter line.
 *  - Corner. Fitted on the arc of the first card: 27.5 px = 18.8 dp, kept at 19 dp. Cards are 17 dp from the edge
 *    and 28 dp from each other, as before; rows have no dividers.
 *  - Text. The title is white bold 16 sp, the line under it and the overline above it a neutral light grey
 *    (#B1B4BA, the peak of the reference's thin 14 sp strokes), no shadow: on a flat card it has nothing to lift off.
 *  - Row. The icon sits 33.8 dp from the card's edge, the text starts 66.7 dp from it and the chevron's middle is
 *    21.2 dp from the right edge (see `SettingsRow`).
 */
object MenuGlass {
    /** The flat grey of the card. */
    val Fill = Color(0xFF272728)
    /** The grey of the line under a title and of the overline above it. */
    val Subtitle = Color(0xFFB1B4BA)
    /** The note between cards («Ищем свежую точку…»): a step lighter than [Subtitle], as in the reference. */
    val Note = Color(0xFFBDBFC5)
    val Title = Color.White
    /** No shadow: the card is flat. Kept as a value so a caller may still pass it to a `TextStyle`. */
    val TextShadow = Shadow(Color.Transparent, Offset.Zero, 0f)

    /** Design numbers, in dp of a 393 dp screen (pass them through `uiScale().s`). */
    const val CORNER = 19f
    const val GAP = 28f
    const val SIDE = 17f

    /** Where the parts of a row stand, measured from the card's left (and right) edge. */
    const val ICON_BOX = 28f
    const val ICON_CENTER = 33.8f
    const val TEXT_START = 66.7f
    /** From the card's right edge to the chevron's right end (its middle is 21.2 dp in). */
    const val CHEVRON_END = 17.7f

    /** On a tablet or a landscape phone the cards keep a phone-like column in the middle instead of stretching. */
    val MaxWidth: Dp = 560.dp
}

/** A menu card: clip and the flat grey fill. */
fun Modifier.menuGlass(corner: Dp): Modifier {
    val shape = RoundedCornerShape(corner)
    return this.clip(shape).background(MenuGlass.Fill)
}

/** The thin white `›` at the end of a row; it mirrors in right-to-left layouts. */
@Composable
fun MenuChevron(modifier: Modifier = Modifier, color: Color = Color.White) {
    val ui = uiScale()
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Canvas(modifier.size(width = ui.s(7f), height = ui.s(11f))) {
        val w = size.width
        val h = size.height
        val stroke = 1.6.dp.toPx()
        val pad = stroke / 2f + 0.4.dp.toPx()
        fun x(v: Float): Float = if (rtl) w - v else v
        val path = Path().apply {
            moveTo(x(pad), pad)
            lineTo(x(w - pad), h / 2f)
            lineTo(x(pad), h - pad)
        }
        drawPath(path, color, style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
