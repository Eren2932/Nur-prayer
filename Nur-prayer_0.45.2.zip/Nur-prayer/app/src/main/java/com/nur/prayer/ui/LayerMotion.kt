package com.nur.prayer.ui

import androidx.compose.animation.ContentTransform
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import kotlin.math.roundToInt

/**
 * 0.41.0: ONE rule for every step inside the «Дела» layer (azkar, the counter, the Quran, the course, the dictionary,
 * the surahs): the new page slides in over the old one from a third of the width, the old one drifts a fifth of the
 * width the other way, shrinks a little and fades; the wallpaper does not move (it is the same soft picture under
 * both). Back is the same motion played the other way round: the page that leaves is on top and slides out to the
 * right, the page below comes back from the left. Pure numbers here, so [LayerMotionTest] can pin them down.
 * Stories keep their own card-lift motion (NurRoot).
 */
internal object LayerMotion {
    const val MILLIS = 300
    /** The incoming page starts this share of the width to the side. */
    const val ENTER_SHIFT = 0.34f
    /** The page underneath drifts this share of the width. */
    const val UNDER_SHIFT = 0.20f
    /** And shrinks to this scale while it goes. */
    const val UNDER_SCALE = 0.96f
    /** The incoming page is fully visible after this many ms; the one underneath is gone after [FADE_OUT_MILLIS]. */
    const val FADE_IN_MILLIS = 220
    const val FADE_OUT_MILLIS = 240

    fun enterOffset(width: Int): Int = (width * ENTER_SHIFT).roundToInt()
    fun underOffset(width: Int): Int = (width * UNDER_SHIFT).roundToInt()

    private val ease = FastOutSlowInEasing

    /** Deeper: the new page comes from the right (the left in a right-to-left language is mirrored by the layout). */
    fun forward(): ContentTransform =
        (slideInHorizontally(tween(MILLIS, easing = ease)) { enterOffset(it) } + fadeIn(tween(FADE_IN_MILLIS))) togetherWith
            (slideOutHorizontally(tween(MILLIS, easing = ease)) { -underOffset(it) } +
                scaleOut(tween(MILLIS, easing = ease), targetScale = UNDER_SCALE) + fadeOut(tween(FADE_OUT_MILLIS)))

    /** Shallower: the page that leaves is above and goes right; the one below returns from the left. */
    fun backward(): ContentTransform =
        (slideInHorizontally(tween(MILLIS, easing = ease)) { -underOffset(it) } +
            scaleIn(tween(MILLIS, easing = ease), initialScale = UNDER_SCALE) + fadeIn(tween(FADE_IN_MILLIS))) togetherWith
            (slideOutHorizontally(tween(MILLIS, easing = ease)) { enterOffset(it) } + fadeOut(tween(FADE_OUT_MILLIS)))
}
