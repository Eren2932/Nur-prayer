package com.nur.prayer.ui.shell

/*
 * 0.38.0: where the three things of the bar stand, in dp, as plain numbers so that ShellBarTest can pin them.
 *
 * The owner's reference (a 577 x 1280 px screenshot = 393 x 873 dp, 1.4667 px per dp, a 1080 px phone at 2.75 density)
 * measured at the edges of the rings and of the pill:
 *
 *   left ring    x 139.6 .. 191.5 px   51.9 px = 35.4 dp
 *   middle ring  x 240.9 .. 292.5 px   51.6 px = 35.2 dp, centre 266.7 px: 21.8 px (14.9 dp) LEFT of the screen's centre
 *   pill         x 339.4 .. 478.8 px   139.4 px = 95.0 dp wide, as high as the rings (52 px = 35.4 dp)
 *   gaps         49.4 px (33.7 dp) between the left ring and the middle one, 46.9 px (32.0 dp) between it and the pill
 *
 * So: the three are 35.5 dp high, the pill is 95 dp wide, the gaps are one number, 33 dp (the mean of the two), and the
 * middle button is exactly at the centre of the screen: the left one and the pill are placed from IT, not from the
 * edges. The pill is wider than the ring, so the group is not symmetric: the right edge of the pill is 50.8 dp from the
 * screen's edge at 393 dp, the left edge of the Quran button 110.3 dp.
 */
internal object BarLayout {
    /** Height of all three, width of the two rings. */
    const val BUTTON = 35.5f
    /** Between the left ring and the middle one, and between the middle one and the pill. */
    const val GAP = 33f
    /** The pill's own width: «Учёба» with 27 dp of air on both sides. A longer word widens it, a narrow phone narrows it. */
    const val PILL_WIDTH = 95f
    /** Least room between the pill and the edge of the screen. */
    const val MARGIN = 16f

    /** Start of the middle button, from the start of a bar [width] dp wide: it is centred. */
    fun middleStart(width: Float): Float = (width - BUTTON) / 2f

    /** Start of the left button. */
    fun leftStart(width: Float): Float = middleStart(width) - GAP - BUTTON

    /** Start of the pill. */
    fun pillStart(width: Float): Float = middleStart(width) + BUTTON + GAP

    /** How wide the pill may get before it meets the edge of the screen's margin. */
    fun pillRoom(width: Float): Float = width - pillStart(width) - MARGIN
}
