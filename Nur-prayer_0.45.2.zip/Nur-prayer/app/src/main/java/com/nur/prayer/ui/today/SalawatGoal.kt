package com.nur.prayer.ui.today

/** Personal all-time salawat, not a simulated community total. Keep floor rounding identical for every view. */
internal object SalawatGoal {
    const val TARGET = 500_000_000L
    fun fraction(n: Long): Float = when {
        n <= 0L -> 0f
        n >= TARGET -> 1f
        // Float rounds TARGET-1 to TARGET; keep 100% reserved for an actually completed goal.
        else -> (n.toDouble() / TARGET).toFloat().coerceAtMost(java.lang.Math.nextDown(1f))
    }
    fun percent(n: Long) = (n.coerceIn(0L, TARGET) * 100L / TARGET).toInt()
}
