package com.nur.prayer.ui.shell

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.translate
import kotlinx.coroutines.delay

/*
 * 0.38.0: the glint on the «Учёба» pill.
 *
 * The reference is the owner's recording of a button with a light that runs across it (864 x 176 px, 60 fps), measured
 * frame by frame: one pass takes ~0.4 s (from 1.00 s to 1.40 s of the clip), the passes repeat every 1.6 s (the pause is
 * ~1.2 s), the band is soft on both sides and about a third to a half of the button wide, it enters and leaves the
 * button whole (it starts and ends outside), and at its brightest it lightens the colour by about 45 % towards white.
 *
 * What the owner asked for: the same light, a little better, and calmer, "not the strip going slowly, but the passes
 * rarer". So the strip keeps its speed (0.52 s a pass, a hair softer than 0.4 s, with an ease at both ends) and the
 * pause grows from 1.2 s to 3.98 s: one pass in 4.5 s, 2.8 times rarer than in the clip. The first pass comes 1.4 s after the
 * pill appears, so that it is not part of the entrance of the bar.
 *
 * The pill is light grey (#DDDEDC), so the glint is white and a touch stronger than in the clip (peak alpha 0.75: the
 * grey rises to about #F6F6F5): on grey the same 45 % would be hardly visible.
 *
 * Between the passes nothing runs: no frame is requested, the coroutine sleeps. Only the pass itself (0.52 s) draws,
 * and it draws one translated rectangle with a gradient built once per size ([glint]).
 */
internal object PillShimmer {
    /** From the start of one pass to the start of the next. */
    const val CYCLE_MS = 4500
    /** One pass, from the band's edge entering the pill to its other edge leaving it. */
    const val SWEEP_MS = 520
    /** Pause between the end of a pass and the start of the next. */
    const val PAUSE_MS = CYCLE_MS - SWEEP_MS
    /** Before the first pass after the pill has appeared. */
    const val FIRST_MS = 1400
    /** The brightest the white gets over the pill. */
    const val PEAK_ALPHA = 0.75f
    /** Width of the band as a share of the pill's width. */
    const val BAND = 0.55f
    /** The profile of the band across its width: a raised cosine, so both edges are soft. 7 equal steps. */
    val PROFILE = floatArrayOf(0f, 0.25f, 0.75f, 1f, 0.75f, 0.25f, 0f)

    /** The ease of one pass: slow in, slow out, the middle a bit quicker than linear. */
    val EASING = CubicBezierEasing(0.45f, 0f, 0.35f, 1f)

    /** The left edge of the band for a pass at [progress] (0..1): from wholly outside on the left to wholly outside on the right. */
    fun bandLeft(progress: Float, width: Float, band: Float): Float = -band + (width + band) * progress

    /** What the band looks like at a point of its profile. */
    fun tint(profile: Float): Color = ShellColors.PillGlint.copy(alpha = profile * PEAK_ALPHA)
}

/**
 * The progress of the glint, 1 while nothing runs. Not running (battery saver, animations removed, the app not in
 * the foreground: [running] is false) it stays 1 and the pill is simply grey.
 */
@Composable
internal fun rememberGlint(running: Boolean): State<Float> {
    val progress = remember { Animatable(1f) }
    LaunchedEffect(running) {
        if (!running) {
            progress.snapTo(1f)
            return@LaunchedEffect
        }
        delay(PillShimmer.FIRST_MS.toLong())
        while (true) {
            progress.snapTo(0f)
            progress.animateTo(1f, tween(PillShimmer.SWEEP_MS, easing = PillShimmer.EASING))
            delay(PillShimmer.PAUSE_MS.toLong())
        }
    }
    return progress.asState()
}

/** Paints the glint over what is behind it (the pill's fill) and under what is in front of it (the text). Read while drawing only. */
internal fun Modifier.glint(progress: State<Float>): Modifier = drawWithCache {
    val band = size.width * PillShimmer.BAND
    val brush = Brush.horizontalGradient(
        colors = PillShimmer.PROFILE.map { PillShimmer.tint(it) },
        startX = 0f,
        endX = band
    )
    onDrawBehind {
        val p = progress.value
        if (p < 1f) {
            translate(left = PillShimmer.bandLeft(p, size.width, band)) {
                drawRect(brush, size = Size(band, size.height))
            }
        }
    }
}
