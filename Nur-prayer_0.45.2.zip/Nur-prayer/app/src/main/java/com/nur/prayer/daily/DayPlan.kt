package com.nur.prayer.daily

import com.nur.prayer.quran.KhatmPlan

/** What the «Дела» page tracks, in the order it shows it. */
enum class DayTask { AZKAR, READING, VIRD, STORY }

/**
 * Where one task of the day stands, 0.40.0.
 *
 * [counted] is false for a task that has no daily goal of its own: the Quran without a khatm plan (reading is
 * open-ended, there is no «norm» to finish) and an empty vird. Such a task stays on the page, but it neither holds
 * the day open nor counts towards «2 из 4»: «Дела дня выполнены» must be true when everything that has a goal is done,
 * not never true because the Quran has none.
 */
data class DayItem(val task: DayTask, val counted: Boolean, val complete: Boolean, val fraction: Float)

/**
 * The logic of the «Дела» page, pure so it is unit-tested: one [DayItem] per task, and from them the summary at the
 * top (how many are done, how far the day is, what is next). The screen only draws what this says.
 */
object DayPlan {
    private fun ratio(done: Int, total: Int): Float = if (total <= 0) 0f else (done / total.toFloat()).coerceIn(0f, 1f)

    fun azkar(done: Int, total: Int): DayItem =
        DayItem(DayTask.AZKAR, counted = total > 0, complete = total > 0 && done >= total, fraction = ratio(done, total))

    /** With a khatm the task is today's share of it (pages read against the norm); without one there is no goal. */
    fun quran(khatm: KhatmPlan?, today: Long): DayItem =
        if (khatm == null) DayItem(DayTask.READING, counted = false, complete = false, fraction = 0f)
        else DayItem(DayTask.READING, counted = true, complete = khatm.doneToday(today), fraction = khatm.todayFraction(today))

    /** The vird: every starred dhikr said to its target. An empty vird is no task. */
    fun dhikr(vird: List<String>, today: Map<String, Long>): DayItem {
        if (vird.isEmpty()) return DayItem(DayTask.VIRD, counted = false, complete = false, fraction = 0f)
        val complete = Vird.allDone(vird, today)
        val fraction = vird.sumOf { Vird.fraction(it, today).toDouble() }.toFloat() / vird.size
        return DayItem(DayTask.VIRD, counted = true, complete = complete, fraction = if (complete) 1f else fraction.coerceIn(0f, 1f))
    }

    /** [mask] is the story bits of StoryMath, [count] the slides of the day. */
    fun story(mask: Int, count: Int): DayItem {
        val seen = (0 until count).count { StoryMath.isSeen(mask, it) }
        return DayItem(DayTask.STORY, counted = count > 0, complete = count > 0 && seen >= count, fraction = ratio(seen, count))
    }

    fun build(
        azkarDone: Int, azkarTotal: Int,
        khatm: KhatmPlan?, today: Long,
        vird: List<String>, dhikrToday: Map<String, Long>,
        storyMask: Int, storyCount: Int
    ): List<DayItem> = listOf(
        azkar(azkarDone, azkarTotal),
        quran(khatm, today),
        dhikr(vird, dhikrToday),
        story(storyMask, storyCount)
    )

    /** How many of the tasks that have a goal are complete. */
    fun doneCount(items: List<DayItem>): Int = items.count { it.counted && it.complete }

    /** How many tasks the day holds, i.e. the ones that have a goal. */
    fun total(items: List<DayItem>): Int = items.count { it.counted }

    fun allDone(items: List<DayItem>): Boolean = total(items) > 0 && doneCount(items) == total(items)

    /** 0..1: the average of the tasks that have a goal, a finished one counting as a whole. Smooth, unlike done/total. */
    fun fraction(items: List<DayItem>): Float {
        val goals = items.filter { it.counted }
        if (goals.isEmpty()) return 0f
        return goals.sumOf { (if (it.complete) 1f else it.fraction.coerceIn(0f, 1f)).toDouble() }.toFloat() / goals.size
    }

    /** The first task, in the page's order, that has a goal and is not complete; null when the day is done. */
    fun next(items: List<DayItem>): DayTask? = items.firstOrNull { it.counted && !it.complete }?.task
}
