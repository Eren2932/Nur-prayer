package com.nur.prayer.ui.daily

import com.nur.prayer.ui.components.pageContentInsets
import com.nur.prayer.ui.components.ExitDock
import com.nur.prayer.ui.today.DeedCard
import com.nur.prayer.ui.today.DeedHeading
import com.nur.prayer.ui.today.DeedTone
import com.nur.prayer.ui.today.deedMatte
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.asPaddingValues
import com.nur.prayer.i18n.tr
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.draw.drawBehind
import com.nur.prayer.daily.Vird
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.RollingText

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.runtime.rememberUpdatedState
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.RollingNumber
import com.nur.prayer.ui.components.pressClick
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import kotlinx.coroutines.delay
import kotlin.math.abs
import androidx.compose.ui.graphics.graphicsLayer
import com.nur.prayer.ui.learn.HGap

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.DhikrPreset
import com.nur.prayer.daily.StorySlide
import com.nur.prayer.daily.TasbihMath
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.Tag
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.launch
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nur.prayer.ui.components.DoneSeal
import com.nur.prayer.ui.learn.textDp

/** A progress ring: the track and an arc from twelve o'clock. */
@Composable
internal fun Ring(fraction: Float, color: Color, size: Dp, stroke: Dp, modifier: Modifier = Modifier, track: Color = color.copy(alpha = 0.22f)) {
    val shown by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(220), label = "ring")
    Canvas(modifier.size(size)) {
        val w = stroke.toPx()
        val d = this.size.minDimension - w
        val tl = Offset(w / 2, w / 2)
        drawArc(track, 0f, 360f, false, tl, Size(d, d), style = Stroke(w))
        if (shown > 0f) drawArc(color, -90f, 360f * shown, false, tl, Size(d, d), style = Stroke(w, cap = StrokeCap.Round))
    }
}

// ── dhikr ──────────────────────────────────────────────────────────────────────────────────────

/**
 * One counter for every dhikr. 0.18.5: the vird of the day lives here — the starred dhikrs come
 * first in the chip row with their own little rings, and finishing one offers the next instead of
 * switching by itself (a counter that changes under a running thumb would count the wrong words).
 *
 * Every dhikr now goes round: a closed round shows the seal with a ring of light, the next tap
 * starts the following one. The tasbih after prayer used to stop at 100 for the whole day, though
 * it is said after each of the five prayers.
 */
@Composable
fun DhikrScreen(vm: DailyViewModel) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val selectedId by vm.selected.collectAsStateWithLifecycle()
    val today by vm.dhikrToday.collectAsStateWithLifecycle()
    val total by vm.dhikrTotal.collectAsStateWithLifecycle()
    val vird by vm.vird.collectAsStateWithLifecycle()
    val p = Dhikr.preset(selectedId)
    val count = (today[p.id] ?: 0L).toInt()
    val accent = DeedTone.GreenInk
    val sequence = p.id == Dhikr.AFTER_PRAYER
    val inVird = p.id in vird
    // A round of the tasbih after prayer is 100 (its target), of the others their own number:
    // one formula for both.
    val closed = count > 0 && count % p.target == 0
    val rounds = count / p.target
    val inRound = if (closed) p.target else count % p.target
    val fraction = inRound / p.target.toFloat()
    val nextId = if (inVird && Vird.done(p.id, today)) Vird.next(vird, today, after = p.id) else null
    val virdDone = inVird && Vird.allDone(vird, today)

    val dhikrScope = rememberCoroutineScope()
    // The circle gives under the finger on every count and lands with a little bounce.
    val pulse = remember { Animatable(1f) }
    // A closed round sends a ring of light outwards from the circle.
    val burst = remember { Animatable(1f) }

    fun tap() {
        dhikrScope.launch { pulse.snapTo(0.95f); pulse.animateTo(1f, NurMotion.bouncy()) }
        val n = vm.dhikrTap(p.id).toInt()
        val roundEnd = n % p.target == 0
        if (roundEnd) dhikrScope.launch { burst.snapTo(0f); burst.animateTo(1f, tween(BURST_MILLIS, easing = FastOutSlowInEasing)) }
        val phaseEnd = if (sequence) TasbihMath.phaseEnd(n) else roundEnd
        haptic.performHapticFeedback(if (phaseEnd) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove)
    }

    // The vird first, in its own order, then everything else in the usual order.
    val ordered = remember(vird) { vird.map { Dhikr.preset(it) } + Dhikr.PRESETS.filter { it.id !in vird } }
    val chips = rememberLazyListState()
    LaunchedEffect(p.id, vird) {
        val i = ordered.indexOfFirst { it.id == p.id }
        if (i >= 0) chips.animateScrollToItem((i - 1).coerceAtLeast(0))
    }

    Column(Modifier.fillMaxSize()) {
        DeedHeading(tr("Зикр"))
        LazyRow(state = chips, contentPadding = PaddingValues(horizontal = ui.s(16f)), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(ordered, key = { it.id }) { d ->
                DhikrChip(d, today[d.id] ?: 0L, d.id in vird, d.id == p.id, accent, Modifier.animateItem()) { vm.select(d.id) }
            }
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(20f)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Gap(14f)
            // Another dhikr slides in from the side it lies on in the chip row.
            AnimatedContent(
                targetState = p.id,
                transitionSpec = {
                    val forward = ordered.indexOfFirst { it.id == targetState } > ordered.indexOfFirst { it.id == initialState }
                    (slideInHorizontally(NurMotion.gentle()) { w: Int -> if (forward) w / 5 else -w / 5 } + fadeIn(tween(200))) togetherWith
                        (slideOutHorizontally(NurMotion.gentle()) { w: Int -> if (forward) -w / 5 else w / 5 } + fadeOut(tween(120)))
                },
                contentAlignment = Alignment.TopCenter,
                label = "dhikrWords"
            ) { id ->
                val d = Dhikr.preset(id)
                Column(Modifier.fillMaxWidth().deedMatte(RoundedCornerShape(ui.s(24f))).padding(ui.s(16f)), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (id == Dhikr.AFTER_PRAYER) {
                        val c = TasbihMath.inRound((today[id] ?: 0L).toInt())
                        val done = c == TasbihMath.TOTAL
                        val (phase, inPhase) = TasbihMath.phase(c)
                        AnimatedContent(
                            targetState = phase,
                            transitionSpec = { (fadeIn(tween(220)) + scaleIn(NurMotion.gentle(), initialScale = 0.92f)) togetherWith fadeOut(tween(120)) },
                            label = "tasbihPhase"
                        ) { ph ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                ArabicText(TasbihMath.arabic(ph), 34f, color = DeedTone.Ink)
                                Text(TasbihMath.reading(ph), color = DeedTone.Quiet, fontSize = ui.t(15f))
                            }
                        }
                        Gap(6f)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (0..2).forEach { i ->
                                val passed = i < phase || done
                                // A finished phase keeps its count next to the seal: «33» tells which one it was.
                                if (passed) Tag("${TasbihMath.size(i)}", color = DeedTone.GreenInk, background = DeedTone.Track) { DoneSeal(DeedTone.GreenInk, textDp(14f), animate = false) }
                                else Tag(if (i == phase) "$inPhase/${TasbihMath.size(i)}" else "${TasbihMath.size(i)}", color = if (i == phase) DeedTone.Ink else DeedTone.Quiet, background = DeedTone.Track)
                            }
                        }
                    } else {
                        ArabicText(d.arabic, if (d.arabic.length > 24) 26f else 34f, color = DeedTone.Ink)
                        Text(d.translit, color = DeedTone.Quiet, fontSize = ui.t(15f), textAlign = TextAlign.Center)
                        Text(d.ru, color = DeedTone.Quiet, fontSize = ui.t(13f), textAlign = TextAlign.Center)
                    }
                }
            }
            Gap(18f)
            val interaction = remember { MutableInteractionSource() }
            val ringColor by animateColorAsState(if (closed) DeedTone.GreenInk else accent, tween(240), label = "dhikrRing")
            Box(
                Modifier.size(260.dp)
                    .drawBehind {
                        val t = burst.value
                        if (t < 1f) {
                            val r = size.minDimension / 2f
                            drawCircle(DeedTone.GreenInk.copy(alpha = 0.55f * (1f - t)), radius = r + 26.dp.toPx() * t,
                                style = Stroke((6.dp.toPx() * (1f - t)).coerceAtLeast(1f)))
                        }
                    }
                    .graphicsLayer { scaleX = pulse.value; scaleY = pulse.value }.clip(CircleShape)
                    // The whole matte disc is the tap target.
                    .deedMatte(CircleShape)
                    .clickable(interactionSource = interaction, indication = androidx.compose.material3.ripple()) { tap() },
                contentAlignment = Alignment.Center
            ) {
                Ring(fraction, ringColor, 260.dp, 14.dp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    // The count rolls with every tap; the seal of a closed round pops in.
                    AnimatedContent(
                        targetState = closed,
                        transitionSpec = { (scaleIn(NurMotion.bouncy(), initialScale = 0.5f) + fadeIn(tween(140))) togetherWith fadeOut(tween(90)) },
                        contentAlignment = Alignment.Center,
                        label = "dhikrDone"
                    ) { f ->
                        if (f) DoneSeal(DeedTone.GreenInk, textDp(64f))
                        else RollingNumber(if (sequence) TasbihMath.phase(inRound).second else inRound, DeedTone.Ink, ui.t(64f))
                    }
                    RollingText(
                        when {
                            closed -> tr("круг {0} завершён", rounds)
                            sequence -> tr("из {0} · всего {1}", TasbihMath.size(TasbihMath.phase(inRound).first), inRound) +
                                if (rounds > 0) tr(" · кругов {0}", rounds) else ""
                            else -> tr("из {0}", p.target) + if (rounds > 0) tr(" · кругов {0}", rounds) else ""
                        },
                        DeedTone.Quiet, ui.t(13f)
                    )
                }
            }
            Gap(8f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (closed) tr("Нажмите, чтобы начать новый круг") else tr("Нажимайте на круг"), color = Color.White, fontSize = ui.t(12f))
                if (count > 0) {
                    HGap(12f)
                    // A slip of the finger is taken back without resetting the whole day.
                    Text("−1", color = DeedTone.Quiet, fontSize = ui.t(13f), fontWeight = FontWeight.Bold,
                        modifier = Modifier.pressClick(shape = RoundedCornerShape(50)) { vm.dhikrUndo(p.id) }
                            .background(DeedTone.Badge).padding(horizontal = 12.dp, vertical = 6.dp))
                }
            }
            // The vird walks on: the next open dhikr is offered, never forced.
            AnimatedVisibility(
                visible = nextId != null || virdDone,
                enter = expandVertically(NurMotion.gentle()) + fadeIn(tween(200)) + scaleIn(NurMotion.bouncy(), initialScale = 0.9f),
                exit = shrinkVertically(NurMotion.snappy()) + fadeOut(tween(120))
            ) {
                Box(Modifier.padding(top = 12.dp)) {
                    if (nextId != null) {
                        val next = Dhikr.preset(nextId)
                        Row(
                            Modifier.pressClick(shape = RoundedCornerShape(50)) { vm.select(next.id) }
                                .background(DeedTone.Badge).padding(horizontal = 18.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(tr("Дальше: {0}", next.title), color = DeedTone.Ink, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
                            HGap(8f)
                            Glyph(GlyphKind.CHEVRON, DeedTone.Ink, Modifier.size(textDp(12f)))
                        }
                    } else {
                        Row(
                            Modifier.clip(RoundedCornerShape(50)).background(DeedTone.Badge).padding(horizontal = 16.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            DoneSeal(DeedTone.GreenInk, textDp(16f))
                            HGap(8f)
                            Text(tr("Вирд дня выполнен"), color = DeedTone.GreenInk, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            Gap(16f)
            // 0.40.0: two cards instead of five blocks. The numbers of this dhikr; then what it is worth, the vird and the reset.
            DeedCard() {
                Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Fact(tr("сегодня"), count.toLong(), Modifier.weight(1f))
                    Box(Modifier.width(1.dp).height(32.dp).background(DeedTone.Track))
                    Fact(tr("за всё время"), total[p.id] ?: 0L, Modifier.weight(1f))
                }
            }
            Gap(10f)
            DeedCard() {
                Column(Modifier.fillMaxWidth().animateContentSize(NurMotion.gentle())) {
                    Column(Modifier.padding(ui.s(16f))) {
                        Text(p.virtue, color = DeedTone.Ink, fontSize = ui.t(14f), lineHeight = ui.t(20f))
                        Gap(4f)
                        Text(p.source, color = DeedTone.Quiet, fontSize = ui.t(12f))
                    }
                    CardRule()
                    VirdToggle(inVird, full = !inVird && Vird.isFull(vird), accent) { vm.toggleVird(p.id) }
                    // Nothing counted, nothing to reset: the row only appears when it has a meaning.
                    if (count > 0) {
                        CardRule()
                        Text(
                            tr("Сбросить счёт за сегодня"), color = DeedTone.Quiet, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.fillMaxWidth().pressClick(scaleTo = 1f) { vm.dhikrReset(p.id) }
                                .padding(horizontal = ui.s(16f), vertical = ui.s(14f))
                        )
                    }
                }
            }
            Gap(10f)
            Box(Modifier.height(LocalDockInset.current))
        }
    }
}

/** The hairline between the rows of a card. */
@Composable
private fun CardRule() {
    val ui = uiScale()
    Box(Modifier.fillMaxWidth().padding(horizontal = ui.s(16f)).height(1.dp).background(DeedTone.Track))
}

/** A chip of the dhikr row; a dhikr of the vird carries its ring, or the seal once its round is said. */
@Composable
private fun DhikrChip(d: DhikrPreset, count: Long, inVird: Boolean, selected: Boolean, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    val ui = uiScale()
    Row(
        modifier.pressClick(shape = RoundedCornerShape(50), onClick = onClick)
            .background(if (selected) DeedTone.Badge else Color(0xFFC3BEC0)).padding(start = if (inVird) 8.dp else 14.dp, end = 14.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (inVird) {
            val done = count >= d.target
            Box(Modifier.size(textDp(18f)), contentAlignment = Alignment.Center) {
                if (done) DoneSeal(DeedTone.GreenInk, textDp(18f))
                else Ring(count / d.target.toFloat(), if (selected) DeedTone.Ink else DeedTone.Quiet, textDp(16f), 2.5.dp)
            }
            HGap(6f)
        }
        Text(
            if (count > 0) "${d.title} · $count" else d.title,
            color = if (selected) DeedTone.Ink else DeedTone.Quiet, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold
        )
    }
}

/** «В вирде дня» — the star that puts a dhikr into the day's tasks. A row of the dhikr page's lower card. */
@Composable
private fun VirdToggle(inVird: Boolean, full: Boolean, accent: Color, onToggle: () -> Unit) {
    val ui = uiScale()
    val bg by animateColorAsState(if (inVird) accent.copy(alpha = 0.22f) else Color.Transparent, tween(220), label = "virdBg")
    val star by animateFloatAsState(if (inVird) 1f else 0.85f, NurMotion.bouncy(), label = "virdStar")
    Row(
        Modifier.fillMaxWidth().pressClick(enabled = !full, scaleTo = 1f, onClick = onToggle)
            .background(bg).padding(horizontal = ui.s(16f), vertical = ui.s(14f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Glyph(if (inVird) GlyphKind.STAR else GlyphKind.STAR_OUTLINE, if (inVird) DeedTone.Ink else DeedTone.Quiet,
            Modifier.size(textDp(18f)).graphicsLayer { scaleX = star; scaleY = star })
        HGap(12f)
        Column(Modifier.weight(1f)) {
            Text(if (inVird) tr("В вирде дня") else tr("Добавить в вирд дня"), color = DeedTone.Ink, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
            Text(
                when {
                    inVird -> tr("Вирд дня")
                    full -> tr("В вирде уже {0} зикра — уберите один, чтобы добавить", Vird.MAX)
                    else -> tr("Цель — один круг в день")
                },
                color = DeedTone.Quiet, fontSize = ui.t(12f)
            )
        }
    }
}

/** A number of the dhikr page's facts card, centred in its half. */
@Composable
private fun Fact(label: String, value: Long, modifier: Modifier) {
    val ui = uiScale()
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        RollingNumber(value, DeedTone.Ink, ui.t(22f))
        Text(label, color = DeedTone.Quiet, fontSize = ui.t(12f))
    }
}

/** Selection fades between chips instead of jumping. */
@Composable
internal fun chipBg(selected: Boolean, accent: Color): Color {
    val c by animateColorAsState(if (selected) accent.copy(alpha = 0.35f) else SurfaceRaised, tween(180), label = "chip")
    return c
}

@Composable
internal fun Chip(text: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val ui = uiScale()
    Text(
        text, color = if (selected) TextPrimary else TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold,
        modifier = Modifier.pressClick(shape = RoundedCornerShape(50), onClick = onClick)
            .background(chipBg(selected, accent)).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

// ── story of the day ───────────────────────────────────────────────────────────────────────────

/**
 * Stories, the familiar way. Segments on top fill with time (longer text, longer slide); a short
 * tap on the right goes on, on the left goes back; a hold pauses and hides the chrome, and letting
 * go resumes from the same point (0.10.0 skipped to the next slide here, see [StoryMath]).
 * Swipe left/right changes the slide, pull down closes, following the finger.
 */
@Composable
fun StoryScreen(
    slides: List<StorySlide>,
    start: Int,
    opening: Int,
    accent: Color,
    onSeen: (Int) -> Unit,
    onClose: () -> Unit
) {
    val ui = uiScale()
    if (slides.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    var index by rememberSaveable(opening) { mutableIntStateOf(start.coerceIn(0, slides.lastIndex)) }
    var restart by remember(opening) { mutableIntStateOf(0) }
    var held by remember { mutableStateOf(false) }
    var chromeHidden by remember { mutableStateOf(false) }
    var forward by remember { mutableStateOf(true) }
    val safeIndex = index.coerceIn(0, slides.lastIndex)
    val slide = slides[safeIndex]
    val duration = remember(slide) { StoryMath.durationMillis(slide) }
    val progress = remember(opening, safeIndex, restart) { Animatable(0f) }
    val dragY = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val swipePx = with(density) { 56.dp.toPx() }
    val closePx = with(density) { 120.dp.toPx() }
    val voiceStatus = com.nur.prayer.ui.learn.rememberVoiceStatus()
    val latestClose by rememberUpdatedState(onClose)
    // Closing starts an exit animation during which this screen is still alive: the timer or a
    // second gesture must not pop the back stack twice.
    var closed by remember(opening) { mutableStateOf(false) }
    fun closeOnce() { if (!closed) { closed = true; latestClose() } }

    fun go(delta: Int) {
        if (closed) return
        // Read the state, not safeIndex: the gesture handler below is keyed on (opening, size)
        // and keeps the closure of its first composition, where safeIndex is frozen.
        val n = index.coerceIn(0, slides.lastIndex) + delta
        when {
            n < 0 -> restart++
            n > slides.lastIndex -> closeOnce()
            else -> { forward = delta > 0; index = n }
        }
    }

    BackHandler { closeOnce() }
    LaunchedEffect(safeIndex, opening) { onSeen(safeIndex) }
    // The hold hides the chrome only after a beat, so a quick tap does not blink it.
    LaunchedEffect(held) {
        if (held) { delay(StoryMath.TAP_MAX_MILLIS); chromeHidden = true } else chromeHidden = false
    }
    LaunchedEffect(progress, held) {
        if (held || closed) return@LaunchedEffect
        val left = (1f - progress.value).coerceIn(0f, 1f)
        if (left > 0f) progress.animateTo(1f, tween((duration * left).toInt().coerceAtLeast(1), easing = LinearEasing))
        go(1)
    }
    val chromeAlpha by animateFloatAsState(if (chromeHidden) 0f else 1f, tween(180), label = "storyChrome")

    Box(
        Modifier.fillMaxSize()
            .graphicsLayer {
                val d = dragY.value.coerceAtLeast(0f)
                val k = if (size.height > 0f) (d / size.height).coerceIn(0f, 1f) else 0f
                translationY = d
                scaleX = 1f - 0.08f * k
                scaleY = 1f - 0.08f * k
                alpha = 1f - 0.4f * k
            }
            .clip(RoundedCornerShape(if (dragY.value > 1f) 28.dp else 0.dp))
            .background(Color.Black.copy(alpha = 0.12f))
            .pageContentInsets()
    ) {
        // Gesture layer with the slide itself. The chrome above is a sibling, so the close and
        // speaker buttons take their own touches and never reach this layer.
        Box(
            Modifier.fillMaxSize().pointerInput(opening, slides.size) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val t0 = down.uptimeMillis
                    val x0 = down.position.x
                    var dx = 0f
                    var dy = 0f
                    var upTime = t0 + 60_000L
                    held = true
                    var pressing = true
                    while (pressing) {
                        val ev = awaitPointerEvent()
                        val c = ev.changes.firstOrNull { it.id == down.id }
                        when {
                            c == null -> pressing = false
                            !c.pressed -> { upTime = c.uptimeMillis; pressing = false }
                            else -> {
                                val d = c.positionChange()
                                dx += d.x
                                dy += d.y
                                c.consume()
                                if (dy > 0f && dy > abs(dx)) { val y = dy; scope.launch { dragY.snapTo(y) } }
                            }
                        }
                    }
                    held = false
                    val g = StoryMath.classify(upTime - t0, dx, dy, x0, size.width.toFloat(), swipePx, closePx)
                    when (g) {
                        StoryMath.Gesture.CLOSE -> closeOnce()
                        StoryMath.Gesture.NEXT -> go(1)
                        StoryMath.Gesture.PREV -> go(-1)
                        StoryMath.Gesture.NONE -> {}
                    }
                    if (g != StoryMath.Gesture.CLOSE) scope.launch { dragY.animateTo(0f, NurMotion.gentle()) }
                }
            }
        ) {
            AnimatedContent(
                targetState = safeIndex,
                transitionSpec = {
                    val dir = if (forward) 1 else -1
                    (slideInHorizontally(NurMotion.gentle()) { w -> dir * w / 5 } + fadeIn(tween(220)) +
                        scaleIn(NurMotion.gentle(), initialScale = 0.96f)) togetherWith
                        (slideOutHorizontally(NurMotion.gentle()) { w -> -dir * w / 5 } + fadeOut(tween(160)))
                },
                label = "storySlide",
                modifier = Modifier.fillMaxSize()
            ) { i ->
                StorySlideBody(slides[i.coerceIn(0, slides.lastIndex)], accent)
            }
        }
        Column(Modifier.fillMaxWidth().graphicsLayer { alpha = chromeAlpha }.padding(horizontal = ui.s(16f)).padding(top = 10.dp)) {
            Canvas(Modifier.fillMaxWidth().height(3.dp)) {
                val n = slides.size
                val gap = 4.dp.toPx()
                val w = (size.width - gap * (n - 1)) / n
                val r = CornerRadius(size.height / 2f)
                for (s in 0 until n) {
                    val x = s * (w + gap)
                    drawRoundRect(Color(0x47FFFFFF), Offset(x, 0f), Size(w, size.height), r)
                    val f = when { s < safeIndex -> 1f; s == safeIndex -> progress.value; else -> 0f }
                    if (f > 0f) drawRoundRect(Color.White, Offset(x, 0f), Size(w * f, size.height), r)
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("История дня"), color = TextPrimary, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
                    // 0.40.0: the slide names its own kind in big letters; the header only counts (it said «Аят дня» twice).
                    Text("${safeIndex + 1} / ${slides.size}", color = TextTertiary, fontSize = ui.t(12f))
                }
                val word = slide.arabic
                if (slide.kind == WORD_KIND && slide.voiced && word != null) {
                    com.nur.prayer.ui.learn.SpeakButton(word, voiceStatus, size = 40.dp)
                    HGap(8f)
                }
            }
        }
        if (!chromeHidden) ExitDock(onClose = { closeOnce() }, bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding(),
            modifier = Modifier.align(Alignment.BottomCenter), description = tr("Закрыть"))
        // 0.13.0: the gesture legend under the story is gone — the gestures are the platform's own
        // and the line competed with the text of the slide.
    }
}

/** How long the ring of light of a closed dhikr round takes to fade out. */
private const val BURST_MILLIS = 720

/** The word of the day is the only slide the synthesiser may read: no Quran, hadith or dua by machine voice. */
internal const val WORD_KIND = "Слово дня"

@Composable
private fun StorySlideBody(slide: StorySlide, accent: Color) {
    val ui = uiScale()
    Box(Modifier.fillMaxSize().padding(horizontal = ui.s(23f)).padding(top = 80.dp, bottom = 82.dp),
        contentAlignment = Alignment.Center) {
      Column(Modifier.fillMaxWidth().deedMatte(RoundedCornerShape(ui.s(24f))).verticalScroll(rememberScrollState())
            .padding(horizontal = ui.s(20f), vertical = ui.s(24f)), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(tr(slide.kind).uppercase(), color = accent, fontSize = ui.t(13f), fontWeight = FontWeight.Bold, letterSpacing = ui.t(1f))
        Gap(14f)
        slide.arabic?.let { ArabicText(it, if (it.length > 60) 26f else 38f, color = DeedTone.Ink); Gap(10f) }
        slide.translit?.let { Text(it, color = DeedTone.Quiet, fontSize = ui.t(15f), textAlign = TextAlign.Center, lineHeight = ui.t(21f)); Gap(10f) }
        Text(slide.ru, color = DeedTone.Ink, fontSize = ui.t(if (slide.arabic == null) 24f else 19f), fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center, lineHeight = ui.t(if (slide.arabic == null) 32f else 26f))
        Gap(12f)
        Text(slide.source, color = DeedTone.Quiet, fontSize = ui.t(13f), textAlign = TextAlign.Center)
        slide.note?.let {
            Gap(18f)
            Text(it, color = DeedTone.Quiet, fontSize = ui.t(14f), textAlign = TextAlign.Center,
                modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(DeedTone.Track).padding(12.dp))
        }
    }
  }
}
