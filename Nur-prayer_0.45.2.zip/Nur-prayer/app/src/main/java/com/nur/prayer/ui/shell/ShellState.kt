package com.nur.prayer.ui.shell

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf

/*
 * 0.27.0 «Капсула»: the one object all navigation lives in.
 *
 * Closed, it is a capsule in reach of the thumb; open, the same glass is the panel (since 0.39.0 the sections and the
 * settings; before, the times of the day too). Not two views swapping: one surface whose bounds move between the two
 * (shared bounds), driven by one number, [progress]: 0 is the capsule, 1 the panel. Only layout and
 * draw read it, so the morph never recomposes. A spring, so a tap mid-way turns it around smoothly.
 *
 * Not saveable on purpose: an open panel must not greet the user after a return.
 */
@Stable
class ShellState {
    var open by mutableStateOf(false)
        private set
    private val morph = Animatable(0f)
    val progress: Float get() = morph.value

    /**
     * 0.27.1: a page that wants the whole screen for itself (the Quran reader while one reads) asks the
     * capsule to step aside. The capsule keeps its place in the tree, so showing it again on a tap is
     * one animated float, not a composition.
     */
    var capsuleHidden by mutableStateOf(false)

    /** Bottom edge of the glass in root px: the capsule and the panel share it (the panel grows upwards). */
    var glassBottomInRoot by mutableFloatStateOf(Float.NaN)

    fun show() { open = true }
    fun hide() { open = false }

    suspend fun settle() {
        if (open) morph.animateTo(1f, spring(dampingRatio = ShellMath.OPEN_DAMPING, stiffness = ShellMath.OPEN_STIFFNESS))
        else morph.animateTo(0f, spring(dampingRatio = ShellMath.CLOSE_DAMPING, stiffness = ShellMath.CLOSE_STIFFNESS))
    }

    suspend fun snap() { morph.snapTo(if (open) 1f else 0f) }
}

val LocalShell = staticCompositionLocalOf<ShellState?> { null }

/** The arithmetic of the morph, kept pure for ShellMathTest. */
object ShellMath {
    /**
     * 0.30.2: both springs are (almost) critically damped, the way the system's own sheets move: a quick
     * start, a soft landing, no bounce. Opening keeps a hair of life (0.92 → well under 0.1 % overshoot,
     * so the layout never has to grow past the panel); closing is critically damped and a little stiffer,
     * so the fold is brisk and never springs off the capsule. A tap mid-way turns either around with the
     * velocity it had.
     */
    const val OPEN_DAMPING = 0.92f
    const val OPEN_STIFFNESS = 460f
    const val CLOSE_DAMPING = 1f
    const val CLOSE_STIFFNESS = 560f

    /** The spring may overshoot a little; the glass may grow a hair past the panel, never further. */
    fun clampProgress(p: Float): Float = p.coerceIn(0f, 1.03f)

    fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    /** The capsule's own content leaves in the first third of the way. */
    fun capsuleAlpha(p: Float): Float = (1f - p / 0.3f).coerceIn(0f, 1f)

    /** The panel's content arrives once the glass has room for it. */
    fun panelAlpha(p: Float): Float = ((p - 0.28f) / 0.52f).coerceIn(0f, 1f)

    /**
     * 0.39.0 «Капля»: the glass grows like a drop spreading on a table, sideways first. [reachProgress] is its width:
     * quick at the start (a cubic ease-out), whole by [REACH_DONE_AT] of the way, so a flat wide pill stands there
     * while the height has hardly begun. [riseProgress] is its height: it starts only at [RISE_START_AT] and takes the
     * rest of the way in a smooth S, so it never overtakes the width. Both are functions of the one spring [p], so a
     * tap mid-way turns the whole shape around, and on the way back the slab is squashed flat first and narrows last:
     * the capsule is a circle again only at the very end.
     */
    const val REACH_DONE_AT = 0.62f
    const val RISE_START_AT = 0.22f

    fun reachProgress(p: Float): Float {
        val t = (p / REACH_DONE_AT).coerceIn(0f, 1f)
        val u = 1f - t
        return 1f - u * u * u
    }

    fun riseProgress(p: Float): Float {
        val t = ((p - RISE_START_AT) / (1f - RISE_START_AT)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /**
     * The cells of the panel appear from the middle outwards: [rank] 0 is the middle, each next rank starts
     * [CELL_STAGGER] of the way later and takes [CELL_SPAN] of it, in a smooth S. Whole before the spring's end.
     */
    const val CELL_START = 0.36f
    const val CELL_STAGGER = 0.06f
    const val CELL_SPAN = 0.30f
    /** A cell is this much of its size when it begins to show and grows to 1. */
    const val CELL_FROM_SCALE = 0.84f

    fun cellProgress(p: Float, rank: Int): Float {
        val start = CELL_START + CELL_STAGGER * rank
        val t = ((p - start) / CELL_SPAN).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    /** How far cell [index] of [count] is from the middle of the row, in whole steps: the two middle ones are 0. */
    fun cellRank(index: Int, count: Int): Int = kotlin.math.abs(2 * index - (count - 1)) / 2

    /**
     * 0.37.0: the closed capsule is a bar of three round things: Quran (home, inside a section), the button of the
     * panel and the task of the moment. The panel grows out of the middle one, a plain circle. While closed its glass
     * is a thin dark veil; by this share of the way it is the panel's paper, so the panel's text, which arrives from
     * [panelAlpha], never lies on a veil.
     */
    const val FILL_DONE_AT = 0.35f
    fun fillProgress(p: Float): Float = (p / FILL_DONE_AT).coerceIn(0f, 1f)

    /**
     * Black laid over the blurred picture under the glass: [pictureDim] at least, so a light wallpaper
     * cannot lift the glass, and as much as the page darkens the sharp picture when that is more.
     */
    fun pictureDim(pageDim: Float, pagePeak: Float): Float = maxOf(PICTURE_DIM, pageDim.coerceIn(0f, 1f) * pagePeak)

    const val PICTURE_DIM = 0.50f

    /** The capsule is on screen when its route has it and no page asked it to step aside. */
    fun capsuleVisible(routeHasIt: Boolean, hiddenByPage: Boolean): Boolean = routeHasIt && !hiddenByPage

    /**
     * The reader's chrome (its top bar and the capsule) is up when the user asked for it (a tap, the top
     * of the surah) and nothing docks at the bottom: a selected ayah's actions or a sheet own that edge.
     */
    fun readerChrome(chromeShown: Boolean, ayahSelected: Boolean, sheetOpen: Boolean): Boolean =
        chromeShown && !ayahSelected && !sheetOpen

    /** Slide of a capsule that comes or goes: it travels this far down while it fades. */
    const val SLIDE_DP = 48f
}
