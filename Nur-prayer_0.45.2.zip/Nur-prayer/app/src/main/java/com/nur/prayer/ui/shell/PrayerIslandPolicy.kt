package com.nur.prayer.ui.shell

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import java.time.Duration
import java.time.ZonedDateTime

/** A projection of the timetable, not another prayer-time calculation. */
internal object PrayerIslandPolicy {
    const val ENTRY_DELAY_MS = 2_000L
    private val horizon = Duration.ofMinutes(5)
    data class Target(val prayer: Prayer, val start: ZonedDateTime)

    fun schedule(days: List<PrayerDay>): List<Target> = days.flatMap { day ->
        day.times.filterKeys { it.isPrayer }.map { (p, time) -> Target(p, time) }
    }.sortedBy { it.start.toInstant() }

    fun imminent(schedule: List<Target>, now: ZonedDateTime): Target? =
        schedule.firstOrNull { it.start.isAfter(now) }?.takeIf { Duration.between(now, it.start) <= horizon }
}
