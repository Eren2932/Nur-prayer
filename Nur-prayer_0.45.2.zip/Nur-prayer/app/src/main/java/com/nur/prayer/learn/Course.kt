package com.nur.prayer.learn

/** What a lesson drills. The factory turns a plan into concrete exercises with a seeded random. */
sealed interface LessonPlan {
    /** 0.35.0. First lesson: how Arabic writing works, before any letter. */
    data object Orientation : LessonPlan
    /**
     * Letters in alphabet order. [vowels]: short vowels the learner can already read (the syllable
     * drills use them); [newVowel]: met in this very lesson, gets its own rule card first.
     */
    data class Letters(
        val fresh: List<Letter>,
        val known: List<Letter>,
        val vowels: List<Mark> = emptyList(),
        val newVowel: Mark? = null
    ) : LessonPlan
    /** 0.35.0. The row so far, in order: names, sounds, «what comes next», syllables. */
    data class RowReview(val row: List<Letter>, val vowels: List<Mark>) : LessonPlan
    /** 0.35.0. Hamza on alif, ta marbuta, alif maqsura: signs a Quran reader meets on the first page. */
    data object SpecialSigns : LessonPlan
    data object Joining : LessonPlan
    data class Forms(val form: LetterForm) : LessonPlan
    data object FindLetter : LessonPlan
    data object ShortVowels : LessonPlan
    data object Sukun : LessonPlan
    data object LongVowels : LessonPlan
    data object Shadda : LessonPlan
    data object Tanween : LessonPlan
    data class Reading(val minLetters: Int, val maxLetters: Int) : LessonPlan
    data object SunMoon : LessonPlan
    data class Vocabulary(val topic: String, val words: List<Word>) : LessonPlan
    /** level 1: any letters; 2: look-alike letters; 3: look-alikes in an unvowelled word. */
    data class MissingLetter(val level: Int) : LessonPlan
    data object Assemble : LessonPlan
    data object TranslitToArabic : LessonPlan
    data object Exam : LessonPlan
    data class Surah(val number: Int) : LessonPlan
    /** Spaced repetition of whatever is due today. */
    data object Review : LessonPlan
    /** Test-out: passing it completes every lesson before [stageIndex]. */
    data class Checkpoint(val stageIndex: Int) : LessonPlan
}

data class Lesson(val id: String, val title: String, val subtitle: String, val plan: LessonPlan)

/**
 * A block of lessons. [passCount] lessons must be completed to open the next stage: every lesson
 * for the strict foundations, a reasonable share for the vocabulary, where order is free.
 */
data class Stage(
    val id: String,
    val title: String,
    val subtitle: String,
    val lessons: List<Lesson>,
    val freeOrder: Boolean = false,
    val passCount: Int = lessons.size
)

class Course(val stages: List<Stage>) {
    val lessons: List<Lesson> = stages.flatMap { it.lessons }
    private val byId = lessons.associateBy { it.id }
    private val stageOf: Map<String, Int> = stages.withIndex()
        .flatMap { (i, s) -> s.lessons.map { it.id to i } }.toMap()

    fun lesson(id: String): Lesson? = byId[id] ?: special(id)

    fun stageIndex(lessonId: String): Int = stageOf[lessonId] ?: -1

    fun isStageUnlocked(index: Int, progress: LearnProgress): Boolean =
        index <= 0 || (0 until index).all { stageDone(it, progress) }

    fun stageDone(index: Int, progress: LearnProgress): Boolean {
        val stage = stages[index]
        return stage.lessons.count { progress.isDone(it.id) } >= stage.passCount
    }

    fun isUnlocked(lessonId: String, progress: LearnProgress): Boolean {
        val s = stageOf[lessonId] ?: return lessonId == REVIEW_ID
        if (!isStageUnlocked(s, progress)) return false
        val stage = stages[s]
        if (stage.freeOrder) return true
        val at = stage.lessons.indexOfFirst { it.id == lessonId }
        return at == 0 || progress.isDone(stage.lessons[at - 1].id)
    }

    /** The lesson the "continue" button opens: the first unlocked lesson not yet completed. */
    fun next(progress: LearnProgress): Lesson? =
        lessons.firstOrNull { !progress.isDone(it.id) && isUnlocked(it.id, progress) }

    fun completedCount(progress: LearnProgress): Int = lessons.count { progress.isDone(it.id) }

    fun stageIndexById(id: String): Int = stages.indexOfFirst { it.id == id }

    /**
     * 0.35.0. The stage this learner may test into, by what he said about himself: 0 for a
     * beginner. Never past the last stage; the claim is only proven by the checkpoint exam.
     */
    fun suggestedStart(profile: LearnProfile?): Int {
        val id = profile?.suggestedStageId() ?: return 0
        val at = if (id == LearnProfile.AFTER_READING) stageIndexById("reading") + 1 else stageIndexById(id)
        return at.coerceIn(0, stages.size - 1)
    }

    private fun special(id: String): Lesson? = when {
        id == REVIEW_ID -> Lesson(REVIEW_ID, "Повторение", "карточки, которым пора", LessonPlan.Review)
        id.startsWith(CHECKPOINT_PREFIX) -> id.removePrefix(CHECKPOINT_PREFIX).toIntOrNull()
            ?.takeIf { it in 1 until stages.size }
            ?.let { Lesson(id, "Экзамен на переход", "к разделу «${stages[it].title}»", LessonPlan.Checkpoint(it)) }
        else -> null
    }

    companion object {
        const val REVIEW_ID = "review"
        const val CHECKPOINT_PREFIX = "checkpoint-"
        private const val CHUNK = 8

        fun checkpointId(stageIndex: Int) = CHECKPOINT_PREFIX + stageIndex

        /**
         * 0.35.0. The course for a goal. Every goal shares the reading foundation (alphabet → forms →
         * vowels → reading); what follows depends on why the learner is here. Lesson ids are shared
         * across goals wherever the content is the same, so changing the goal keeps the progress.
         */
        fun build(lexicon: Lexicon, goal: LearnGoal = LearnGoal.QURAN): Course {
            val foundation = foundation()
            val fatihaWords = chunks(lexicon.byTopic[Lexicon.FATIHA].orEmpty()).mapIndexed { i, part ->
                Lesson("quran-fatiha-words-${i + 1}", "Аль-Фатиха: слова · ${i + 1}", "значение каждого слова",
                    LessonPlan.Vocabulary(Lexicon.FATIHA, part))
            }
            val surahs = QuranShort.SURAHS.map { s ->
                Lesson(QuranShort.lessonId(s.number), s.nameRu, "${s.ayatCount} аятов: смысл и пропуски", LessonPlan.Surah(s.number))
            }
            val quran = Stage("quran", "Коран", "Аль-Фатиха по словам и короткие суры", fatihaWords + surahs)
            val tail = when (goal) {
                LearnGoal.QURAN -> listOf(
                    Stage("practice", "Практика чтения", "похожие буквы, сборка слова", practice(full = false)),
                    quran
                )
                LearnGoal.MEANING -> {
                    val words = topicLessons(lexicon, MEANING_TOPICS)
                    listOf(
                        Stage("meaning", "Слова намаза и веры", "ислам, зикр, местоимения", words,
                            freeOrder = true, passCount = minOf(4, words.size)),
                        quran,
                        Stage("practice", "Практика чтения", "похожие буквы, сборка слова", practice(full = false))
                    )
                }
                LearnGoal.LANGUAGE -> {
                    val words = topicLessons(lexicon, Lexicon.TOPICS.map { it.id }.filter { it != Lexicon.FATIHA })
                    listOf(
                        Stage("words", "Словарь", "${lexicon.words.size} слов и фраз по темам", words,
                            freeOrder = true, passCount = minOf(12, words.size)),
                        Stage("mastery", "Мастерство", "пропуски, сборка, письмо без огласовок", practice(full = true)),
                        quran
                    )
                }
            }
            return Course(foundation + tail)
        }

        /** Topics of the "meaning" goal, in this order: what is said in prayer and about faith first. */
        val MEANING_TOPICS = listOf("islam", "phrases", "pronouns", "verbs")

        private fun foundation(): List<Stage> {
            val letters = Arabic.LETTERS
            val alphabet = ArrayList<Lesson>()
            alphabet += Lesson("abc-intro", "Как устроено письмо", "справа налево, 28 букв, огласовки", LessonPlan.Orientation)
            val known = ArrayList<Letter>()
            val vowels = ArrayList<Mark>()
            Arabic.LESSON_GROUPS.forEachIndexed { i, group ->
                val fresh = group.map { c -> letters.first { it.char == c.toString() } }
                val newVowel = Arabic.VOWEL_AT[i]?.let(Arabic::vowel)
                if (newVowel != null) vowels += newVowel
                val subtitle = fresh.joinToString(", ") { it.name } + (newVowel?.let { " + ${it.name}" } ?: "")
                alphabet += Lesson("abc-${i + 1}", fresh.joinToString(" ") { it.char }, subtitle,
                    LessonPlan.Letters(fresh, known.toList(), vowels.toList(), newVowel))
                known += fresh
                if (i in Arabic.ROW_REVIEW_AFTER) {
                    alphabet += Lesson("abc-row-${i + 1}", "Повторяем ряд: ${known.first().char} … ${known.last().char}",
                        "${known.size} букв по порядку", LessonPlan.RowReview(known.toList(), vowels.toList()))
                }
            }
            alphabet += Lesson("abc-row-all", "Весь алфавит по порядку", "28 букв от алифа до йа",
                LessonPlan.RowReview(letters, vowels.toList()))

            val forms = listOf(
                Lesson("forms-join", "Связки", "какие буквы не тянутся вперёд", LessonPlan.Joining),
                Lesson("forms-initial", "Начальная форма", "буква в начале слова", LessonPlan.Forms(LetterForm.INITIAL)),
                Lesson("forms-medial", "Средняя форма", "буква в середине", LessonPlan.Forms(LetterForm.MEDIAL)),
                Lesson("forms-final", "Конечная форма", "буква в конце", LessonPlan.Forms(LetterForm.FINAL)),
                Lesson("forms-find", "Найди букву", "в каком она слове", LessonPlan.FindLetter)
            )
            val signs = listOf(
                Lesson("vowels-short", "Фатха, касра, дамма", "закрепляем: а, и, у", LessonPlan.ShortVowels),
                Lesson("vowels-hamza", "Хамза, та марбута, алиф максура", "أ إ ة ى", LessonPlan.SpecialSigns),
                Lesson("vowels-sukun", "Сукун", "закрытый слог", LessonPlan.Sukun),
                Lesson("vowels-long", "Долгие гласные", "аа, ии, уу", LessonPlan.LongVowels),
                Lesson("vowels-shadda", "Шадда", "удвоение", LessonPlan.Shadda),
                Lesson("vowels-tanween", "Танвин", "ан, ин, ун", LessonPlan.Tanween)
            )
            val reading = listOf(
                Lesson("reading-short", "Короткие слова", "2–3 буквы", LessonPlan.Reading(2, 3)),
                Lesson("reading-middle", "Слова длиннее", "4–5 букв", LessonPlan.Reading(4, 5)),
                Lesson("reading-article", "Артикль аль-", "солнечные и лунные буквы", LessonPlan.SunMoon),
                Lesson("reading-long", "Длинные слова", "от 6 букв", LessonPlan.Reading(6, 99))
            )
            return listOf(
                Stage("alphabet", "Алфавит", "28 букв по порядку, первые слоги", alphabet),
                Stage("forms", "Формы букв", "как буква меняется в слове", forms),
                Stage("vowels", "Огласовки и знаки", "хамза, сукун, долгота, шадда, танвин", signs),
                Stage("reading", "Чтение", "от слогов к словам", reading)
            )
        }

        private fun topicLessons(lexicon: Lexicon, topics: List<String>): List<Lesson> = topics.flatMap { id ->
            val topic = Lexicon.TOPICS.firstOrNull { it.id == id } ?: return@flatMap emptyList()
            chunks(lexicon.byTopic[id].orEmpty()).mapIndexed { i, part ->
                Lesson("words-$id-${i + 1}", "${topic.title} · ${i + 1}", topic.subtitle, LessonPlan.Vocabulary(id, part))
            }
        }

        /** Reading practice on real words. [full]: also transliteration and unvowelled text (language goal). */
        private fun practice(full: Boolean): List<Lesson> = listOfNotNull(
            Lesson("master-missing-1", "Какой буквы не хватает", "подставьте букву", LessonPlan.MissingLetter(1)),
            Lesson("master-missing-2", "Похожие буквы", "точки решают всё", LessonPlan.MissingLetter(2)),
            Lesson("master-assemble", "Собери слово", "из букв по порядку", LessonPlan.Assemble),
            if (full) Lesson("master-translit", "Из транслита в арабский", "найдите точное написание", LessonPlan.TranslitToArabic) else null,
            if (full) Lesson("master-missing-3", "Без огласовок", "как пишут в книгах и газетах", LessonPlan.MissingLetter(3)) else null,
            Lesson("master-exam", "Большой экзамен", "всё вперемешку", LessonPlan.Exam)
        )

        /** Lessons of eight words; a short tail is folded into the previous lesson. */
        fun chunks(words: List<Word>): List<List<Word>> {
            if (words.isEmpty()) return emptyList()
            val parts = words.chunked(CHUNK).toMutableList()
            if (parts.size > 1 && parts.last().size < CHUNK / 2) {
                val tail = parts.removeAt(parts.lastIndex)
                parts[parts.lastIndex] = parts.last() + tail
            }
            return parts
        }
    }
}
