package com.nur.prayer.ui.names

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.uiScale
import com.nur.prayer.ui.today.DeedTone

@Composable
internal fun NamesIndex(rows: List<NameEntry>, state: LazyListState, query: String, change: (String) -> Unit,
    last: Int, open: (Int) -> Unit) {
    val ui = uiScale()
    val visible = remember(rows, query) { NamesCatalog.search(rows, query) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        // 575 px reference: margins 30, radius ~10.5, gap ~14, tallest row 118.
        // One scale per viewport, never one height per item. Cap the scale on tablets.
        val px = (maxWidth.value / 575f).coerceIn(.55f, .83f).dp
        val textFloor = with(LocalDensity.current) { ui.t(74f).toDp() }
        val rowHeight = maxOf(px * 118f, textFloor, 68.dp)
        val corner = px * 10.5f
        LazyColumn(state = state, flingBehavior = rememberNamesFling(), modifier = Modifier.fillMaxSize().testTag("names-index"),
            contentPadding = PaddingValues(start = px * 30f, end = px * 30f, top = 6.dp, bottom = 0.dp),
            verticalArrangement = Arrangement.spacedBy(px * 14f)) {
            item(key = "header", contentType = "header") {
                Column(Modifier.fillMaxWidth().background(NamesPaper, RoundedCornerShape(px * 25f))
                    .padding(horizontal = px * 23f, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(tr("99 имён Аллаха"), color = DeedTone.Ink, fontSize = ui.t(24f), lineHeight = ui.t(29f), fontWeight = FontWeight.Bold)
                    if (last in 1..rows.size) NameAction(tr("Продолжить · {0}", last), true) { open(last) }
                }
            }
            item(key = "search", contentType = "search") { NameSearch(query, change) }
            if (visible.isEmpty()) item(key = "empty") {
                Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("Ничего не найдено"), color = Color.White)
                    NameAction(tr("Сбросить поиск"), false) { change("") }
                }
            }
            items(visible, key = { it.id }, contentType = { "name" }) { item ->
                NameRow(item, rowHeight, corner, px, open)
            }
        }
    }
}

@Composable
private fun NameRow(item: NameEntry, rowHeight: Dp, corner: Dp, px: Dp, open: (Int) -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(corner)
    Row(Modifier.fillMaxWidth().height(rowHeight).testTag("name-row-${item.id}")
        .background(NamesPaper, shape).pressClick(shape = shape, onClick = { open(item.id) })
        .padding(horizontal = px * 29f), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(px * 12f)) {
        Text(item.id.toString().padStart(2, '0'), Modifier.width(px * 46f), color = NamesJade,
            fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
        Column(Modifier.weight(1f)) {
            Text(item.reading, color = DeedTone.Ink, fontSize = ui.t(17f), lineHeight = ui.t(20f),
                fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(item.gloss, color = DeedTone.Quiet, fontSize = ui.t(14f), lineHeight = ui.t(17f),
                maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        NameArabic(item.arabic, if (' ' in item.arabic) 15f else 22f,
            Modifier.width(px * 104f), align = TextAlign.Right)
    }
}

@Composable
private fun NameSearch(query: String, change: (String) -> Unit) {
    val ui = uiScale()
    val focus = LocalFocusManager.current
    val label = tr("Имя, смысл или номер")
    var focused by remember { mutableStateOf(false) }
    val ink = Color.White
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.padding(horizontal = 12.dp).size(20.dp)) {
            val s = size.minDimension
            drawCircle(ink, s * .32f, Offset(s * .40f, s * .40f), style = Stroke(s * .075f))
            drawLine(ink, Offset(s * .64f, s * .64f), Offset(s * .92f, s * .92f), s * .075f, StrokeCap.Round)
        }
        Row(Modifier.weight(1f).drawBehind {
            val stroke = if (focused) 2.dp.toPx() else 1.dp.toPx()
            drawLine(ink.copy(alpha = if (focused) .9f else .55f), Offset(0f, size.height - stroke / 2),
                Offset(size.width, size.height - stroke / 2), stroke)
        }, verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(value = query, onValueChange = change, singleLine = true,
                modifier = Modifier.weight(1f).onFocusChanged { focused = it.isFocused }.semantics { contentDescription = label },
                textStyle = TextStyle(color = ink, fontSize = ui.t(15f)), cursorBrush = SolidColor(ink),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }), decorationBox = { field ->
                    Box(Modifier.fillMaxWidth().heightIn(min = 48.dp), contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) Text(label, color = ink.copy(alpha = .84f), fontSize = ui.t(15f))
                        field()
                    }
                })
            if (query.isNotEmpty()) {
                val clear = tr("Очистить поиск")
                IconButton(onClick = { change("") }, modifier = Modifier.semantics { contentDescription = clear }) {
                    Glyph(GlyphKind.CLOSE, ink, Modifier.size(16.dp))
                }
            }
        }
    }
}
