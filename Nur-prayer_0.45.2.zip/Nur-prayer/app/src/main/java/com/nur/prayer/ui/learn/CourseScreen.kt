package com.nur.prayer.ui.learn

import com.nur.prayer.i18n.tr

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.learn.Course
import com.nur.prayer.learn.LearnProgress
import com.nur.prayer.learn.Lesson
import com.nur.prayer.learn.QuranShort
import com.nur.prayer.learn.Stage
import com.nur.prayer.ui.components.DoneSeal
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.StreakLamp
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.RollingNumber
import com.nur.prayer.ui.components.ScreenHeader
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.components.rememberEntranceClock
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/**
 * The course map. Stages open strictly in order (the dictionary stage in free order inside); a
 * locked stage offers a checkpoint exam, so someone who already reads is not forced through the
 * alphabet. The current stage is expanded by default, the rest on tap.
 */
@Composable
fun CourseScreen(
    vm: LearnViewModel,
    course: Course?,
    progress: LearnProgress,
    palette: PhasePalette,
    onBack: () -> Unit,
    onOpenLesson: () -> Unit,
    onOpenDictionary: () -> Unit,
    /** The dictionary opened on the given word, its card unfolded. */
    onOpenWord: (String) -> Unit,
    onOpenSurahs: () -> Unit
) {
    val ui = uiScale()
    val accent = palette.accent
    val today = vm.today()
    fun open(id: String) { if (vm.start(id)) onOpenLesson() }
    val profile by vm.profile.collectAsState()
    val learnContent by vm.content.collectAsState()
    val profileLoaded by vm.profileLoaded.collectAsState()
    var editingProfile by rememberSaveable { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(tr("Арабский язык"), onBack, Modifier.padding(horizontal = ui.s(16f)))
        if (course == null || !profileLoaded) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(tr("Готовим уроки…"), color = TextSecondary) }
            return
        }
        // 0.35.0. First run (or "change goal"): ask why and from where, then build the course for it.
        if (profile == null || editingProfile) {
            ProfileSetup(
                initial = profile,
                accent = accent,
                pathOf = { g -> vm.content.value?.forGoal(g)?.course?.stages?.joinToString(" → ") { tr(it.title) }.orEmpty() },
                onDone = { p -> vm.setProfile(p); editingProfile = false },
                onCancel = if (profile != null) ({ editingProfile = false }) else null
            )
            return
        }
        val suggested = course.suggestedStart(profile)
        var tableOpen by rememberSaveable { mutableStateOf(false) }
        val next = course.next(progress)
        val currentStage = next?.let { course.stageIndex(it.id) } ?: (course.stages.size - 1)
        var expanded by rememberSaveable { mutableStateOf(currentStage) }
        val due = progress.due(today).size
        // One clock for the cascade: items scrolled away and back show at once, not replay.
        val clock = rememberEntranceClock()
        var voiceOpen by rememberSaveable { mutableStateOf(false) }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth().entrance(0, clock = clock), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile(progress.streakOn(today).toLong(), tr("дней подряд"), Modifier.weight(1f)) { lit ->
                        StreakLamp(lit, TextPrimary, textDp(20f))
                    }
                    StatTile(progress.xp.toLong(), tr("опыта"), Modifier.weight(1f))
                    StatTile(progress.learnedWords().toLong(), tr("слов выучено"), Modifier.weight(1f))
                }
            }
            item {
                GlassCard(Modifier.entrance(1, clock = clock), color = accent.copy(alpha = 0.20f)) {
                    Column(Modifier.padding(ui.s(18f))) {
                        val done = course.completedCount(progress)
                        profile?.let { ProfileLine(it, accent) { editingProfile = true } }
                        Gap(4f)
                        Text(tr("Пройдено {0} из {1} уроков", done, course.lessons.size), color = TextSecondary, fontSize = ui.t(13f))
                        Gap(8f)
                        LessonBar(done.toFloat() / course.lessons.size.coerceAtLeast(1), accent)
                        Gap(14f)
                        if (next != null) {
                            Text(course.stages[currentStage].title.uppercase(), color = accent, fontSize = ui.t(12f), fontWeight = FontWeight.Bold)
                            Text(next.title, color = TextPrimary, fontSize = ui.t(22f), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(next.subtitle, color = TextSecondary, fontSize = ui.t(14f))
                            Gap(12f)
                            if (done == 0 && suggested > 0 && !course.isStageUnlocked(suggested, progress)) {
                                // He says he can already read: offer to test into his stage, keep the start as plan B.
                                Text(tr("По вашему уровню можно начать с раздела «{0}». Сдайте короткий экзамен — и предыдущие уроки засчитаются.",
                                    tr(course.stages[suggested].title)), color = TextSecondary, fontSize = ui.t(13f))
                                Gap(10f)
                                NurButton(tr("Экзамен на переход"), accent, { open(Course.checkpointId(suggested)) }, Modifier.fillMaxWidth(), primary = true)
                                Gap(8f)
                                NurButton(tr("Начать с самого начала"), accent, { open(next.id) }, Modifier.fillMaxWidth())
                            } else {
                                NurButton(if (done == 0) tr("Начать") else tr("Продолжить"), accent, { open(next.id) }, Modifier.fillMaxWidth(), primary = true)
                            }
                        } else {
                            Text(tr("Курс пройден целиком"), color = TextPrimary, fontSize = ui.t(20f), fontWeight = FontWeight.Bold)
                            Text(tr("Повторяйте карточки и улучшайте звёзды."), color = TextSecondary, fontSize = ui.t(14f))
                        }
                    }
                }
            }
            item {
                val lexicon = learnContent?.lexicon
                TileRow(Modifier.entrance(2, clock = clock)) {
                    ActionTile(tr("Повторение"), if (due > 0) tr("{0} карточек ждут", due) else tr("на сегодня всё"),
                        Modifier.weight(1f).fillMaxHeight(), enabled = due > 0) { open(Course.REVIEW_ID) }
                    ActionTile(tr("Словарь"), if (lexicon != null) tr("{0} слов и фраз, поиск", lexicon.words.size) else tr("поиск и темы"),
                        Modifier.weight(1f).fillMaxHeight()) { onOpenDictionary() }
                }
            }
            // 0.40.0: these two lived in «Дела» before, where they were not about the day. Here they sit with the rest of learning.
            item {
                val word = learnContent?.lexicon?.wordOfDay(today)
                val checked = QuranShort.SURAHS.count { progress.isDone(QuranShort.lessonId(it.number)) }
                TileRow(Modifier.entrance(3, clock = clock)) {
                    if (word != null) {
                        ActionTile(tr("Слово дня"), "${word.ru} · ${word.translit}", Modifier.weight(1f).fillMaxHeight(), mark = word.arabic) { onOpenWord(word.id) }
                    } else Box(Modifier.weight(1f))
                    ActionTile(
                        tr("Короткие суры"),
                        if (checked == 0) tr("заучивание и проверка себя") else tr("проверено {0} из {1}", checked, QuranShort.SURAHS.size),
                        Modifier.weight(1f).fillMaxHeight(), mark = "سُورَة"
                    ) { onOpenSurahs() }
                }
            }
            item {
                VoiceCard(voiceOpen, accent, Modifier.entrance(4, clock = clock)) { voiceOpen = !voiceOpen }
            }
            item {
                if (tableOpen) AlphabetTable(progress, accent, Modifier.entrance(4, clock = clock))
                else ActionTile(tr("Таблица алфавита"), tr("28 букв по порядку: звук, название, формы"),
                    Modifier.fillMaxWidth().entrance(4, clock = clock)) { tableOpen = true }
            }
            itemsIndexed(course.stages, key = { _, s -> s.id }) { index, stage ->
                StageCard(
                    course, index, stage, progress, accent,
                    modifier = Modifier.entrance(5 + index, clock = clock),
                    expanded = expanded == index,
                    onToggle = { expanded = if (expanded == index) -1 else index },
                    onLesson = { open(it.id) },
                    onCheckpoint = { open(Course.checkpointId(index)) }
                )
            }
        }
    }
}

@Composable
private fun StatTile(value: Long, label: String, modifier: Modifier, icon: (@Composable (lit: Boolean) -> Unit)? = null) {
    val ui = uiScale()
    GlassCard(modifier, corner = 18.dp) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            // Comes back from a lesson with more XP: the number rolls up instead of blinking.
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    icon(value > 0)
                    HGap(4f)
                }
                RollingNumber(value, TextPrimary, ui.t(20f))
            }
            Text(label, color = TextTertiary, fontSize = ui.t(11f))
        }
    }
}

/** A row of two tiles of one height, whatever their lines wrap to. */
@Composable
private fun TileRow(modifier: Modifier, content: @Composable RowScope.() -> Unit) {
    Row(modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

/** A tile that opens something; [mark] is an Arabic word set above the title, the way the app signs its sections. */
@Composable
private fun ActionTile(title: String, subtitle: String, modifier: Modifier, enabled: Boolean = true, mark: String? = null, onClick: () -> Unit) {
    val ui = uiScale()
    GlassCard(modifier.pressClick(enabled = enabled, shape = RoundedCornerShape(20.dp), onClick = onClick), corner = 20.dp) {
        Column(Modifier.fillMaxWidth().padding(ui.s(14f))) {
            if (mark != null) {
                ArabicText(mark, 22f, align = TextAlign.Start, modifier = Modifier.fillMaxWidth())
                Gap(6f)
            }
            Text(title, color = if (enabled) TextPrimary else TextSecondary, fontSize = ui.t(16f), fontWeight = FontWeight.Bold)
            Text(subtitle, color = TextTertiary, fontSize = ui.t(12f), maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun StageCard(
    course: Course, index: Int, stage: Stage, progress: LearnProgress, accent: Color,
    modifier: Modifier = Modifier,
    expanded: Boolean, onToggle: () -> Unit, onLesson: (Lesson) -> Unit, onCheckpoint: () -> Unit
) {
    val ui = uiScale()
    val unlocked = course.isStageUnlocked(index, progress)
    val done = stage.lessons.count { progress.isDone(it.id) }
    val complete = course.stageDone(index, progress)
    // The chevron turns on the same spring the body opens with.
    val turn by animateFloatAsState(if (expanded) 1f else 0f, NurMotion.snappy(), label = "stageChevron")
    GlassCard(modifier) {
        Row(
            Modifier.fillMaxWidth().pressClick(scaleTo = 0.98f, onClick = onToggle).padding(ui.s(16f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(
                    when { complete -> Mint.copy(alpha = 0.25f); unlocked -> accent.copy(alpha = 0.25f); else -> SurfaceInset }
                ),
                contentAlignment = Alignment.Center
            ) {
                when {
                    complete -> DoneSeal(Mint, 24.dp, animate = false)
                    unlocked -> Text("${index + 1}", color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.Bold)
                    else -> Glyph(GlyphKind.LOCK, TextSecondary, Modifier.size(18.dp))
                }
            }
            HGap(12f)
            Column(Modifier.weight(1f)) {
                Text(stage.title, color = if (unlocked) TextPrimary else TextSecondary, fontSize = ui.t(18f), fontWeight = FontWeight.Bold)
                Text(stage.subtitle, color = TextTertiary, fontSize = ui.t(13f))
            }
            Tag("$done/${stage.lessons.size}")
            HGap(6f)
            Glyph(GlyphKind.CHEVRON, TextTertiary, Modifier.size(textDp(16f)).graphicsLayer { rotationZ = 90f * turn })
        }
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(NurMotion.gentle()) + fadeIn(NurMotion.gentle()),
            exit = shrinkVertically(NurMotion.snappy()) + fadeOut(NurMotion.snappy())
        ) {
          Column {
            if (!unlocked && index > 0) {
                Column(Modifier.fillMaxWidth().padding(horizontal = ui.s(16f)).padding(bottom = 12.dp)) {
                    Text(tr("Раздел откроется после предыдущего. Уже знаете материал — сдайте экзамен на переход."),
                        color = TextSecondary, fontSize = ui.t(13f))
                    Gap(8f)
                    NurButton(tr("Экзамен на переход"), accent, onCheckpoint, Modifier.fillMaxWidth())
                }
            }
            if (stage.freeOrder && unlocked) {
                Text(tr("Темы — в любом порядке. Для следующего раздела хватит {0}.", stage.passCount),
                    color = TextTertiary, fontSize = ui.t(12f), modifier = Modifier.padding(horizontal = ui.s(16f)).padding(bottom = 6.dp))
            }
            stage.lessons.forEach { lesson ->
                val open = course.isUnlocked(lesson.id, progress)
                val isNext = open && !progress.isDone(lesson.id)
                Row(
                    Modifier.fillMaxWidth().pressClick(enabled = open, scaleTo = 0.98f) { onLesson(lesson) }
                        .padding(horizontal = ui.s(16f), vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(lesson.title, color = if (open) TextPrimary else TextTertiary, fontSize = ui.t(16f),
                            fontWeight = if (isNext) FontWeight.Bold else FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(lesson.subtitle, color = TextTertiary, fontSize = ui.t(12f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    HGap(8f)
                    when {
                        progress.isDone(lesson.id) -> Stars(progress.stars(lesson.id), size = 14f)
                        open -> Tag(tr("начать"), color = accent)
                        else -> Glyph(GlyphKind.LOCK, TextTertiary, Modifier.size(textDp(15f)))
                    }
                }
            }
            Gap(8f)
          }
        }
    }
}

/** Voice preferences, folded by default: one line until it is needed. */
@Composable
private fun VoiceCard(open: Boolean, accent: Color, modifier: Modifier, onToggle: () -> Unit) {
    val ui = uiScale()
    val turn by animateFloatAsState(if (open) 1f else 0f, NurMotion.snappy(), label = "voiceChevron")
    GlassCard(modifier, corner = 20.dp) {
        Row(
            Modifier.fillMaxWidth().pressClick(scaleTo = 0.98f, onClick = onToggle).padding(horizontal = ui.s(16f), vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(tr("Озвучка"), color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.Bold)
                Text(tr("автопроигрывание и скорость"), color = TextTertiary, fontSize = ui.t(12f))
            }
            Glyph(GlyphKind.CHEVRON, TextTertiary, Modifier.size(textDp(16f)).graphicsLayer { rotationZ = 90f * turn })
        }
        AnimatedVisibility(
            visible = open,
            enter = expandVertically(NurMotion.gentle()) + fadeIn(NurMotion.gentle()),
            exit = shrinkVertically(NurMotion.snappy()) + fadeOut(NurMotion.snappy())
        ) {
            VoiceSettings(accent, Modifier.padding(horizontal = ui.s(12f)).padding(bottom = 8.dp))
        }
    }
}
