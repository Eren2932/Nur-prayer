package com.nur.prayer.learn

/**
 * 0.35.0. Why the learner is here. The goal decides which stages the course holds after the common
 * reading foundation (alphabet → forms → vowels → reading).
 *
 * The language track is Modern Standard / literary Arabic (فُصْحَى, фусха): the language of the Quran,
 * books, news and dictionaries, understood in every Arab country. A dialect (Egyptian and others) is
 * a separate, spoken layer on top of it and is not mixed into this course.
 */
enum class LearnGoal(val id: String, val title: String, val subtitle: String) {
    QURAN("quran", "Читать Коран", "буквы, огласовки, чтение по мусхафу, короткие суры"),
    MEANING("meaning", "Понимать намаз и Коран", "чтение плюс смысл сур, зикров и слов намаза"),
    LANGUAGE("language", "Арабский язык целиком", "литературный арабский (фусха): читать, понимать, говорить");

    companion object {
        fun of(id: String?): LearnGoal? = values().firstOrNull { it.id == id }
    }
}

/** What the learner says he already knows. Only a suggestion: a checkpoint exam proves it. */
enum class LearnLevel(val id: String, val title: String, val subtitle: String) {
    ZERO("zero", "Начинаю с нуля", "не знаю ни одной буквы"),
    LETTERS("letters", "Знаю буквы", "узнаю буквы, но читаю с трудом"),
    READER("reader", "Читаю с огласовками", "читаю сам, пусть и медленно"),
    ADVANCED("advanced", "Читаю и немного понимаю", "знаю правила чтения и часть слов");

    companion object {
        fun of(id: String?): LearnLevel? = values().firstOrNull { it.id == id }
    }
}

/**
 * The learner's choice, kept on the device only (there is no server). Stored as one line,
 * `v1;goal=quran;level=zero;daily=10`, read leniently: an unknown key is ignored, a missing goal or
 * level means "not set yet" and the course asks again instead of guessing.
 */
data class LearnProfile(val goal: LearnGoal, val level: LearnLevel, val dailyMinutes: Int = DEFAULT_MINUTES) {

    fun encode(): String = "v1;goal=${goal.id};level=${level.id};daily=$dailyMinutes"

    /** The stage a learner at this level should try to test into; 0 means "start from the first lesson". */
    fun suggestedStageId(): String? = when (level) {
        LearnLevel.ZERO -> null
        LearnLevel.LETTERS -> "forms"
        LearnLevel.READER -> "reading"
        LearnLevel.ADVANCED -> AFTER_READING
    }

    companion object {
        const val DEFAULT_MINUTES = 10
        val DAILY_OPTIONS: List<Int> = listOf(5, 10, 20)
        /** Placeholder for "the first stage after the reading foundation", resolved by [Course.suggestedStart]. */
        const val AFTER_READING = "+reading"

        fun decode(raw: String?): LearnProfile? {
            if (raw.isNullOrBlank()) return null
            val fields = raw.split(';').mapNotNull { part ->
                val eq = part.indexOf('=')
                if (eq <= 0) null else part.substring(0, eq).trim() to part.substring(eq + 1).trim()
            }.toMap()
            val goal = LearnGoal.of(fields["goal"]) ?: return null
            val level = LearnLevel.of(fields["level"]) ?: return null
            val daily = fields["daily"]?.toIntOrNull()?.takeIf { it in 1..120 } ?: DEFAULT_MINUTES
            return LearnProfile(goal, level, daily)
        }
    }
}
