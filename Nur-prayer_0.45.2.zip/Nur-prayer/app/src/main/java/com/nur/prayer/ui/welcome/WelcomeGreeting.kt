package com.nur.prayer.ui.welcome

import android.graphics.BitmapShader
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.animation.core.withInfiniteAnimationFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.R
import com.nur.prayer.i18n.AppLanguage
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.rememberMotionBudget

// Both seamlessly repeating sheets meet again after 96 seconds. Save small integer timestamps,
// not frame counts or a large Float clock. A dropped frame skips a sample, not part of the path.
internal const val SILVER_LOOP_NS = 96_000_000_000L
private const val PRIMARY_NS = 24_000_000_000L
private const val SECONDARY_NS = 32_000_000_000L
private const val SECONDARY_X = 157f
private const val SECONDARY_Y = 71f
private const val SECONDARY_ALPHA = 128

internal fun silverTimeAt(anchorNs: Long, elapsedNs: Long, durationScale: Float): Long {
    if (durationScale <= 0f || !durationScale.isFinite()) return anchorNs
    return (anchorNs + (elapsedNs.coerceAtLeast(0L) / durationScale.toDouble()).toLong() % SILVER_LOOP_NS) % SILVER_LOOP_NS
}

@Composable
internal fun WelcomeGreeting(width: Dp, revealed: Boolean) {
    val scale = rememberMotionBudget().foregroundScale
    val visible = revealed && LocalWindowInfo.current.isWindowFocused
    GreetingPlayback(width, if (visible) scale else 0f)
}

@Composable
internal fun GreetingPlayback(width: Dp, scale: Float) {
    val time = rememberSaveable { mutableLongStateOf(0L) }
    LaunchedEffect(scale) {
        if (scale <= 0f || !scale.isFinite()) return@LaunchedEffect
        val offset = time.longValue
        val start = withInfiniteAnimationFrameNanos { it }
        while (true) withInfiniteAnimationFrameNanos { frame ->
            time.longValue = silverTimeAt(offset, frame - start, scale)
        }
    }
    // Pausing stops the clock only. A snapshot/overview/disabled-animation frame still has ink.
    GreetingLettering(width) { time.longValue }
}

@Composable
internal fun GreetingLettering(width: Dp, timeNs: () -> Long) {
    val title = tr("Ассаламу алейкум")
    val tile = ImageBitmap.imageResource(R.drawable.welcome_silver)
    val material = Modifier.graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }.drawWithCache {
        val tw = tile.width.toFloat()
        val th = tile.height.toFloat()
        val shader = BitmapShader(tile.asAndroidBitmap(), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        fun inkPaint(opacity: Int) = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG).also {
            it.shader = shader
            it.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
            it.alpha = opacity
        }
        val first = inkPaint(255)
        val second = inkPaint(SECONDARY_ALPHA)
        onDrawWithContent {
            drawContent() // White alpha silhouette or live translated lettering; never the wallpaper.
            val t = timeNs()
            val a = ((t % PRIMARY_NS) / PRIMARY_NS.toDouble()).toFloat()
            val b = ((t % SECONDARY_NS) / SECONDARY_NS.toDouble()).toFloat()
            drawIntoCanvas { output ->
                val canvas = output.nativeCanvas
                val sc = canvas.save()
                canvas.scale(size.width / tw, size.height / th)
                // Slide the coordinate system, not the clip: both draws always cover the full title.
                val ax = tw * a; val ay = th * a
                val bx = SECONDARY_X - tw * b; val by = SECONDARY_Y + th * b
                canvas.translate(ax, ay)
                canvas.drawRect(-ax, -ay, tw - ax, th - ay, first)
                canvas.translate(bx - ax, by - ay)
                canvas.drawRect(-bx, -by, tw - bx, th - by, second)
                canvas.restoreToCount(sc)
            }
        }
    }
    if (L10n.language == AppLanguage.RU) {
        Image(ImageBitmap.imageResource(R.drawable.welcome_letters), contentDescription = title,
            modifier = Modifier.width(width).aspectRatio(405f / 196f).then(material))
    } else {
        Text(title, modifier = material, color = Color.White, fontFamily = FontFamily.Cursive,
            fontSize = (width.value * .24f).sp, lineHeight = (width.value * .26f).sp, fontStyle = FontStyle.Italic)
    }
}
