package com.nur.prayer.ui.shell

/*
 * 0.39.0 «Капля»: the open panel is one compact slab: four sections and the settings, no times, no header.
 *
 * Every number is a measurement of the owner's mock (576 px = 393 dp, so 1.4656 px per dp; the screenshot is a phone
 * 1080 px wide at 2.75 density, downscaled). Measured from the pixels:
 *
 *   slab        x 36 … 540.5, y 1079.5 … 1212.5 px: 344.4 × 90.8 dp, 24.5 dp from each edge of the screen, the
 *               corner is 50 px = 34 dp (not a pill: the slab is 90.8 high)
 *   discs       55 px = 37.5 dp across, their tops 23 px = 15.7 dp under the slab's top; centres 43.3, 110.9, 179.5
 *               and 247.7 dp from its left edge (a pitch of 68.2 dp)
 *   labels      the baseline is 106 px = 72.3 dp under the slab's top (19.1 dp under a disc), the capitals are
 *               14 px = 9.5 dp high in the mock; the app sets them a size up (see [LABEL_SP]) because the owner asked
 *               for labels that read better
 *   settings    a 32 px = 21.8 dp icon, its centre 43 px = 29.4 dp from the slab's right edge and 64 px = 43.7 dp
 *               under its top
 *   open        the mock of the closed bar (screen 2 of the owner's pair) puts the slab's bottom 7.9 dp above the
 *               bottom of the bar's buttons: the slab rises that far while it opens ([LIFT])
 *
 * The grid is measured at the width of the mock and stretches on a wider or a narrower screen: the four cells share
 * what is left between [GRID_START] and [gridEnd] equally.
 */
internal object PanelLayout {
    /** Room between the slab and the edge of the screen; the slab is never wider than [MAX_WIDTH]. */
    const val SIDE = 24.5f
    const val MAX_WIDTH = 460f
    const val HEIGHT = 90.8f
    const val CORNER = 34f

    /** The width of the slab on the screen of the mock (393 dp). */
    const val REFERENCE_WIDTH = 344.4f

    const val DISC = 37.5f
    const val DISC_TOP = 15.7f
    const val LABEL_BASELINE = 72.3f
    /** The label sits this far under the disc: baseline minus the disc's bottom edge. */
    const val LABEL_UNDER_DISC = LABEL_BASELINE - DISC_TOP - DISC

    /** Distance between the centres of two neighbouring cells at the reference width. */
    const val CELL = 68.2f
    const val CELLS = 4
    /** The first cell starts this far from the slab's left edge: 43.3 dp to its centre minus half a cell. */
    const val GRID_START = 9.2f

    /** The settings icon: its size, how far its centre is from the right edge and from the top, the touch box around it. */
    const val GEAR_ICON = 21.8f
    const val GEAR_FROM_END = 29.4f
    const val GEAR_CENTER_Y = 43.7f
    const val GEAR_HIT = 44f

    /** The slab rises this far above the bar while it opens. */
    const val LIFT = 7.9f

    /** Label sizes: the mock's capitals measure about 13.4 sp; the app prints 14 sp, bold, as the owner asked. */
    const val LABEL_SP = 14f

    /** The settings icon takes the rank after the last section when the cells appear (see [ShellMath.cellRank]). */
    const val GEAR_RANK = 2

    /** Width of the slab on a screen of [screen] dp. */
    fun width(screen: Float): Float = minOf(screen - 2f * SIDE, MAX_WIDTH).coerceAtLeast(0f)

    /** What the grid leaves free on the right so that the four cells have [CELL] each at the reference width. */
    val gridEnd: Float = REFERENCE_WIDTH - GRID_START - CELLS * CELL

    /** Width of one cell in a slab of [panelWidth] dp. */
    fun cellWidth(panelWidth: Float): Float = (panelWidth - GRID_START - gridEnd) / CELLS

    /** Centre of cell [index] from the slab's left edge. */
    fun cellCenter(panelWidth: Float, index: Int): Float = GRID_START + cellWidth(panelWidth) * (index + 0.5f)

    /** Centre of the settings icon from the slab's left edge. */
    fun gearCenter(panelWidth: Float): Float = panelWidth - GEAR_FROM_END
}
