package com.nur.prayer.ui.shell

import com.nur.prayer.core.astro.Prayer

/**
 * The six times of the day: the five prayers and sunrise, in the order home prints them. (Until 0.38.1 the panel
 * listed them too; since 0.39.0 the panel holds only the sections and settings, home is the one place for the times.)
 */
internal object PanelTimes {
    val PRAYERS: List<Prayer> = listOf(Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)

    /**
     * Whether the card of [prayer] has a call to hear: the azan is switched on for it. Sunrise never has one,
     * whatever the settings hold: it is the end of fajr, not a prayer.
     */
    fun callOn(prayer: Prayer, notifications: Map<Prayer, Boolean>): Boolean =
        prayer.isPrayer && notifications[prayer] == true
}
