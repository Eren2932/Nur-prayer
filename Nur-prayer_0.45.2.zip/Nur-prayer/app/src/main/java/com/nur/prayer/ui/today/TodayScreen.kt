package com.nur.prayer.ui.today

import com.nur.prayer.ui.components.pageContentInsets
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.nur.prayer.R
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.Vird
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.daily.Ring
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.uiScale
import java.text.NumberFormat

internal data class TodayState(val currentSet: AzkarSet, val morning: Int, val evening: Int,
    val virdDone: Int, val virdSize: Int, val salawat: Long, val imageBackdrop: Boolean)

internal class TodayActions(val close: () -> Unit, val settings: () -> Unit, val names: () -> Unit,
    val vird: () -> Unit, val azkar: (AzkarSet) -> Unit, val salawat: () -> Unit, val story: () -> Unit)

@Composable
internal fun TodayScreen(state: TodayState, reveal: Reveal, on: TodayActions) {
    val ui = uiScale()
    val pull = rememberDraggableState { delta -> reveal.drag(-delta) }
    val side = ui.s(20f)
    val gap = ui.s(12f)
    val titleInk = if (state.imageBackdrop) DeedTone.Ink else Color.White
    BoxWithConstraints(Modifier.fillMaxSize().pageContentInsets()
        .onSizeChanged { reveal.extentPx = it.height.toFloat() }) {
        val titleBand = if (ui.compact) ui.s(178f) else (maxHeight * .315f).coerceIn(ui.s(218f), ui.s(280f))
        // Grow the grid upward into the empty header space, not over the exit controls.
        val hero = if (ui.compact) titleBand else titleBand - ui.s(46f)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = side)
            .padding(bottom = LocalDockInset.current + 8.dp), verticalArrangement = Arrangement.Top) {
            Box(Modifier.fillMaxWidth().height(hero)) {
                Column(Modifier.fillMaxWidth().padding(top = titleBand * .40f, start = ui.s(8f))
                    .draggable(state = pull, orientation = Orientation.Vertical, onDragStarted = { reveal.grab() }, onDragStopped = { v ->
                        if (reveal.release(-v, RevealMath.SHEET_KEEP_AT)) reveal.settle(true) else on.close()
                    })) {
                    Text(tr("Дела"), fontSize = ui.t(28f), lineHeight = ui.t(32f), fontWeight = FontWeight.Bold, color = titleInk)
                    Spacer(Modifier.height(ui.s(4f)))
                    Text(tr("Путь к спокойствию\nи довольству Аллаха"), fontSize = ui.t(13f), lineHeight = ui.t(16f),
                        color = if (state.imageBackdrop) DeedTone.Ink else Color.White.copy(alpha = .78f))
                }
                val label = tr("Настройки")
                Box(Modifier.align(Alignment.TopEnd).offset(x = ui.s(2f)).padding(top = ui.s(24f)).size(48.dp).semantics { contentDescription = label }
                    .pressClick(shape = CircleShape, onClick = on.settings), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(ui.s(38f)).deedMatte(CircleShape), contentAlignment = Alignment.Center) { Glyph(GlyphKind.SETTINGS, DeedTone.Utility, Modifier.size(ui.s(20f))) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                DeedTile(tr("99 имён Аллаха"), tr("Имена и смыслы"), R.drawable.deed_allah, tr("Новое"), Modifier.weight(1f), on.names)
                DeedTile(tr("Вирд дня"), if (state.virdSize == 0) tr("Выбрать зикры") else tr("Выполнено {0} из {1}", state.virdDone, state.virdSize), R.drawable.deed_star, null, Modifier.weight(1f), on.vird)
            }
            Spacer(Modifier.height(ui.s(11f)))
            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                for (set in AzkarSet.values()) {
                    val morning = set == AzkarSet.MORNING
                    DeedTile(tr(set.title), tr("Азкаров: {0}", if (morning) state.morning else state.evening),
                        if (morning) R.drawable.deed_sun else R.drawable.deed_moon,
                        if (state.currentSet == set) tr("Сейчас") else null, Modifier.weight(1f)) { on.azkar(set) }
                }
            }
            Spacer(Modifier.height(ui.s(17f)))
            SalawatPanel(state.salawat, on.salawat)
            Spacer(Modifier.height(ui.s(16f)))
            Row(Modifier.fillMaxWidth().deedMatte(RoundedCornerShape(ui.s(24f)), true).pressClick(onClick = on.story)
                .heightIn(min = ui.s(59f)).padding(horizontal = ui.s(19f)), verticalAlignment = Alignment.CenterVertically) {
                DeedIcon(R.drawable.deed_clock); Spacer(Modifier.width(ui.s(15f)))
                Text(tr("История дня"), Modifier.weight(1f), color = DeedTone.Ink, fontSize = ui.t(15.5f), fontWeight = FontWeight.SemiBold)
                Chevron()
            }
        }
    }
}

@Composable
private fun DeedTile(title: String, sub: String, icon: Int, badge: String?, modifier: Modifier, open: () -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(ui.s(24f))
    // Reserve two title lines and one subtitle even when accessibility type outgrows the spacing scale.
    val textRoom = with(LocalDensity.current) { ui.t(19f).toDp() * 2f + ui.t(16f).toDp() }
    val tileHeight = maxOf(ui.s(137f), ui.s(83f) + textRoom)
    Column(modifier.height(tileHeight).deedMatte(shape, true).pressClick(onClick = open)
        .padding(start = ui.s(18f), end = ui.s(12f), top = ui.s(11f), bottom = ui.s(23f))) {
        Box(Modifier.fillMaxWidth().height(ui.s(44f))) {
            // Reserve the badge’s width before measuring the icon on small screens.
            Row(Modifier.fillMaxWidth()) {
                Box(Modifier.weight(1f)) {
                    val azkar = icon == R.drawable.deed_sun || icon == R.drawable.deed_moon
                    DeedIcon(icon, Modifier.offset(y = ui.s(if (azkar) 5f else 3f)))
                }
                if (badge != null) Text(badge, Modifier.padding(start = ui.s(4f), top = ui.s(2f))
                    .background(DeedTone.Badge, CircleShape).padding(horizontal = ui.s(9f), vertical = ui.s(3f)),
                    color = DeedTone.GreenInk, fontSize = ui.t(10.5f), lineHeight = ui.t(14f), fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.weight(1f))
        AutoSizeText(title, DeedTone.Ink, ui.t(15f), Modifier.fillMaxWidth(), lineHeight = ui.t(19f),
            minFontSize = ui.t(12f), fontWeight = FontWeight.SemiBold, maxLines = 2)
        Spacer(Modifier.height(ui.s(5f)))
        AutoSizeText(sub, DeedTone.Quiet, ui.t(12.5f), Modifier.fillMaxWidth(), lineHeight = ui.t(16f),
            minFontSize = ui.t(10.5f))
    }
}

@Composable
private fun Chevron() = Glyph(GlyphKind.CHEVRON, DeedTone.Ink, Modifier.size(uiScale().s(14f)))

@Composable
private fun DeedIcon(id: Int, modifier: Modifier = Modifier) {
    // Each vector owns its aspect ratio and pigment; a uniform tint would erase the shading.
    val painter = painterResource(id)
    val scale = uiScale().space
    val density = LocalDensity.current
    with(density) {
        Image(painter, null, modifier.size(painter.intrinsicSize.width.toDp() * scale,
            painter.intrinsicSize.height.toDp() * scale))
    }
}

@Composable
private fun SalawatPanel(n: Long, open: () -> Unit) {
    val ui = uiScale()
    val locale = L10n.language.locale
    val formatted = remember(n, locale) { NumberFormat.getIntegerInstance(locale).format(n) }
    val fraction = SalawatGoal.fraction(n)
    Column(Modifier.fillMaxWidth().deedMatte(RoundedCornerShape(ui.s(24f)), true).pressClick(onClick = open)
        .heightIn(min = ui.s(121f)).padding(horizontal = ui.s(20f), vertical = ui.s(13f)), verticalArrangement = Arrangement.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    DeedIcon(R.drawable.deed_bars); Spacer(Modifier.width(ui.s(14f)))
                    Text(tr("Зикр"), color = DeedTone.Ink, fontSize = ui.t(16.5f), lineHeight = ui.t(20f), fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(ui.s(5f)))
                AutoSizeText(formatted, DeedTone.Ink, ui.t(27f), Modifier.fillMaxWidth(), lineHeight = ui.t(30f), fontWeight = FontWeight.Medium)
                Text(tr("Салават · Цель 500М"), color = DeedTone.Quiet, fontSize = ui.t(13f), lineHeight = ui.t(16f))
            }
            Spacer(Modifier.width(ui.s(8f)))
            Box(contentAlignment = Alignment.Center) {
                Ring(fraction, DeedTone.Green, ui.s(62f), ui.s(6f), track = DeedTone.Track)
                Text("${SalawatGoal.percent(n)}%", color = DeedTone.Ink, fontSize = ui.t(15f), fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(ui.s(8f)))
        Box(Modifier.fillMaxWidth().height(ui.s(6f)).clip(CircleShape).background(DeedTone.Track)) {
            Spacer(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(DeedTone.Green, CircleShape))
        }
    }
}

@Composable
internal fun VirdPage(ids: List<String>, counts: Map<String, Long>, open: (String?) -> Unit) {
    val ui = uiScale()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = LocalDockInset.current)) {
        DeedHeading(tr("Вирд дня"))
        Column(Modifier.padding(horizontal = ui.s(23f)), verticalArrangement = Arrangement.spacedBy(ui.s(10f))) {
            if (ids.isEmpty()) DeedCard {
                Text(tr("Выбрать зикры"), Modifier.fillMaxWidth().pressClick { open(null) }.padding(18.dp), color = DeedTone.Ink)
            }
            ids.forEach { id ->
                val preset = Dhikr.preset(id)
                DeedCard {
                    Row(Modifier.fillMaxWidth().pressClick { open(id) }.padding(ui.s(17f)), verticalAlignment = Alignment.CenterVertically) {
                        Ring(Vird.fraction(id, counts), DeedTone.Green, 28.dp, 3.dp, track = DeedTone.Track)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tr(preset.title), color = DeedTone.Ink, fontWeight = FontWeight.Medium)
                            Text("${counts[id] ?: 0L} / ${preset.target}", color = DeedTone.Quiet, fontSize = ui.t(12f))
                        }
                    }
                }
            }
        }
    }
}
