package com.nur.prayer.ui.shell

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.ui.home.HomeSection

/*
 * 0.36.0 «Бумага»: the colour of a place and of a task.
 *
 * In the open panel every section sits on a saturated disc with a white glyph (the mock: green Quran, violet
 * dhikr, brown qibla, blue to-do, deep blue study, green month). The closed capsule wears the same hue, softer:
 * a pastel disc with the glyph in a very dark shade of that hue and the dots button in a mid tone between the two
 * (measured on the mock's capsule: #ADD2BF disc, #031307 glyph, #799183 dots, for the evening azkar).
 *
 * The capsule's colour follows where the user is and what is offered to him:
 *  - in a section: the hue of that section ([ShellTones.of] a section);
 *  - on home: the hue of the task it offers, that is of the azkar of this part of the day
 *    ([ShellTones.ofAzkar]): mint for the evening (the mock), the warm gold of the sun for the morning.
 *
 * Pure colour arithmetic, no composables: ShellTonesTest pins it.
 */
@Immutable
class ShellTone(
    /** The saturated disc of the panel (white glyph on it). */
    val well: Color,
    /** The pastel disc of the capsule. */
    val container: Color,
    /** The lighter middle of the pastel disc (the mock's disc is brighter in the centre than at the rim). */
    val core: Color,
    /** The glyph on the pastel disc: the hue, almost black. */
    val ink: Color,
    /** The capsule's button (the dots, the moon): between the glyph and the disc. */
    val dots: Color
)

object ShellTones {
    /** Straight blend in sRGB, the way the measurements were made: 0 is [a], 1 is [b]. */
    internal fun mix(a: Color, b: Color, t: Float): Color = Color(
        red = a.red + (b.red - a.red) * t,
        green = a.green + (b.green - a.green) * t,
        blue = a.blue + (b.blue - a.blue) * t,
        alpha = 1f
    )

    /** What a hue is pulled towards to make the pastel: white with a breath of grey, so greens do not turn minty-neon. */
    private val PASTEL_WHITE = Color(0xFFE8ECEA)

    /** Share of [PASTEL_WHITE] in the pastel disc, of black in the glyph, of the disc in the button. */
    internal const val PASTEL = 0.64f
    internal const val INK_SHADE = 0.84f
    internal const val DOTS_OF_DISC = 0.70f
    internal const val CORE_LIGHT = 0.20f

    /** The tone of a hue; the pastel disc can be given when it was measured rather than derived. */
    fun of(well: Color, container: Color = mix(well, PASTEL_WHITE, PASTEL)): ShellTone {
        val ink = mix(well, Color.Black, INK_SHADE)
        return ShellTone(
            well = well,
            container = container,
            core = mix(container, Color.White, CORE_LIGHT),
            ink = ink,
            dots = mix(ink, container, DOTS_OF_DISC)
        )
    }

    // The discs of the panel, as measured on the mock (the median of the ring around the glyph).
    private val QURAN = of(Color(0xFF32A454))
    private val DHIKR = of(Color(0xFFA55CDF))
    private val QIBLA = of(Color(0xFFA66935))
    private val TODAY = of(Color(0xFF3B7BFB))
    private val COURSE = of(Color(0xFF3366F5))
    private val SCHEDULE = of(Color(0xFF2FA453))
    private val SETTINGS = of(Color(0xFF6B6F7A))

    /** The evening azkar of the mock's capsule: the mint disc as measured. */
    val EVENING = of(Color(0xFF32A454), container = Color(0xFFADD2BF))

    /** The morning azkar: the same construction on the gold of the sunrise. */
    val MORNING = of(Color(0xFFE3A12F))

    fun of(section: HomeSection): ShellTone = when (section) {
        HomeSection.QURAN -> QURAN
        HomeSection.DHIKR -> DHIKR
        HomeSection.QIBLA -> QIBLA
        HomeSection.TODAY -> TODAY
        HomeSection.COURSE -> COURSE
        HomeSection.SCHEDULE -> SCHEDULE
        HomeSection.SETTINGS -> SETTINGS
    }

    fun ofAzkar(set: AzkarSet): ShellTone = when (set) {
        AzkarSet.MORNING -> MORNING
        AzkarSet.EVENING -> EVENING
    }
}
