package com.nur.prayer.daily

/**
 * Where an Arabic paragraph may wrap. The text itself never changes, only which spaces become
 * no-break spaces, so the line breaker cannot:
 * - start a line with a pause sign (ۚ ۖ ۗ …) torn from its word;
 * - end a line with a short particle cut from the word it governs (فِي، مِنْ، لَا، يَا، رَبِّ …);
 * - leave the last word (or the ayah number already tied to it) alone on the last line.
 * A bound group never grows past [MAX_GROUP] words, so a line always has somewhere to break.
 */
object ArabicLines {
    private const val NBSP = '\u00A0'
    private const val MAX_GROUP = 3

    /** Particles that read with the next word. Compared without harakat and with one alef. */
    private val PARTICLES = setOf(
        "في", "فى", "من", "عن", "على", "علي", "الى", "إلى", "لا", "ولا", "ما", "وما", "يا", "رب", "اللهم",
        "وهو", "ان", "اني", "الا", "لم", "ولم", "ومن", "او", "قل"
    )

    private fun isPause(c: Char) = c in '\u06D6'..'\u06DC'
    private fun isMark(c: Char) = c in '\u064B'..'\u065F' || c == '\u0670' || c in '\u06D6'..'\u06ED' || c == '\u0640'

    /** The letters of a word: no harakat, no pause signs, every alef written plain. */
    fun bare(word: String): String = buildString {
        for (c in word) when {
            isMark(c) -> Unit
            c in "ٱأإآ" -> append('ا')
            else -> append(c)
        }
    }

    /** Words in a token; a pause sign or an ayah number tied on with a no-break space is not a word. */
    private fun words(token: String): Int =
        token.split(NBSP).count { part -> part.any { it.isLetter() && !isMark(it) && !it.isDigit() } }.coerceAtLeast(1)

    private fun lastWord(token: String): String =
        token.split(NBSP).lastOrNull { part -> part.any { it.isLetter() && !it.isDigit() } }.orEmpty()

    fun bind(text: String): String = text.split('\n').joinToString("\n") { bindLine(it) }

    private fun bindLine(line: String): String {
        // A pause sign belongs to the word before it.
        val tied = buildString {
            for (i in line.indices) {
                val c = line[i]
                append(if (c == ' ' && i + 1 < line.length && isPause(line[i + 1])) NBSP else c)
            }
        }
        val tokens = tied.split(' ').filter { it.isNotEmpty() }
        if (tokens.size < 2) return tied
        val out = StringBuilder(tokens[0])
        var group = words(tokens[0])
        for (i in 1 until tokens.size) {
            val w = words(tokens[i])
            val particle = bare(lastWord(tokens[i - 1])) in PARTICLES
            val last = i == tokens.lastIndex
            val bind = (particle || last) && group + w <= MAX_GROUP
            out.append(if (bind) NBSP else ' ').append(tokens[i])
            group = if (bind) group + w else w
        }
        return out.toString()
    }
}
