package com.nur.prayer.ui.names

import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.ui.theme.ArabicFont
import com.nur.prayer.ui.theme.uiScale

// The shipped Hafs is static Regular. Ink the same shaped layout, including GPOS marks,
// instead of requesting a weight the loaded native face doesn't have. One semantic Text.
private const val NAME_STROKE_EM = 0.036f

@OptIn(ExperimentalTextApi::class)
@Composable
internal fun NameArabic(text: String, size: Float, modifier: Modifier = Modifier,
    align: TextAlign = TextAlign.Center) {
    val ui = uiScale()
    val em = ui.t(size)
    val display = remember(text) { ArabicFont.mushaf(text) }
    var layout by remember(display) { mutableStateOf<TextLayoutResult?>(null) }
    BasicText(text = display, modifier = modifier.padding(horizontal = 1.dp).drawBehind {
        layout?.let { drawText(it, color = NamesJade, drawStyle = Stroke(width = em.toPx() * NAME_STROKE_EM, join = StrokeJoin.Round)) }
    }, style = TextStyle(color = NamesJade, fontFamily = ArabicFont.family, fontSize = em,
        letterSpacing = 0.sp, textAlign = align, textDirection = TextDirection.Rtl,
        lineHeight = ui.t(size * ArabicFont.lineHeight),
        lineHeightStyle = LineHeightStyle(LineHeightStyle.Alignment.Center, LineHeightStyle.Trim.None)),
        onTextLayout = { layout = it })
}
