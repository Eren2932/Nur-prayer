package com.nur.prayer.ui.names

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.gestures.ScrollScope
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember

// Drag remains 1:1; only the post-release coast is shorter than the default.
private const val RELEASE_VELOCITY = 0.90f

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun rememberNamesFling(): FlingBehavior {
    val native = ScrollableDefaults.flingBehavior()
    return remember(native) {
        object : FlingBehavior {
            override suspend fun ScrollScope.performFling(initialVelocity: Float): Float {
                val scroll = this
                return with(native) { scroll.performFling(initialVelocity * RELEASE_VELOCITY) } / RELEASE_VELOCITY
            }
        }
    }
}
