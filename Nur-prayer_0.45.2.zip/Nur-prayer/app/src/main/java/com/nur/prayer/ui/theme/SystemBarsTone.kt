package com.nur.prayer.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.Window
import java.util.WeakHashMap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat

/**
 * 0.18.4: who decides the colour of the status and navigation bar icons.
 *
 * The whole app sits on a dark sky, so the icons are light. The Quran's paper page is the one
 * light surface: while it is on screen the icons turn dark, or the clock and battery vanish into
 * the cream. The state lives here and not in a composable because MainActivity re-applies the bars
 * in onResume (back from the share chooser, from settings), and must re-apply the right tone.
 */
object SystemBarsTone {
    /** True while a light surface is under the system bars. Observed by NurRoot's nav-bar scrim. */
    var light by mutableStateOf(false)
        private set

    /** Who holds the light tone by [hold]; while somebody does, a plain `set(window, false)` of another screen is ignored. */
    private var holder: Any? = null

    fun set(window: Window?, light: Boolean) {
        // A screen that is still fading out hands the sky its light icons back late (its onDispose runs when the
        // transition ends): that must not take the dark icons away from the screen that has already come in.
        if (!light && holder != null) return
        this.light = light
        apply(window)
    }

    /** 0.28.0: the calendar on a light wallpaper keeps the dark icons until it lets go with [release]. */
    fun hold(window: Window?, owner: Any) {
        holder = owner
        this.light = true
        apply(window)
    }

    fun release(window: Window?, owner: Any) {
        if (holder !== owner) return
        holder = null
        this.light = false
        apply(window)
    }

    // A photo in Deeds has a light header, not a paper navigation bar. Keep this override
    // per window and owner so a late disposal or Activity recreation cannot reset a new owner.
    private val photoHeaders = WeakHashMap<Window, Any>()

    internal fun photoHeader(window: Window, owner: Any, visible: Boolean) {
        if (visible) photoHeaders[window] = owner
        else if (photoHeaders[window] === owner) photoHeaders.remove(window) else return
        apply(window)
    }

    fun apply(window: Window?) {
        window ?: return
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = light || photoHeaders.containsKey(window)
            isAppearanceLightNavigationBars = light
        }
    }
}

/** The activity behind a Compose context, through any wrappers (themes, locales). */
tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
