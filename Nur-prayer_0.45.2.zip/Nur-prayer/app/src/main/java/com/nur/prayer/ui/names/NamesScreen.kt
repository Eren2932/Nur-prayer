package com.nur.prayer.ui.names

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.uiScale
import com.nur.prayer.ui.today.DeedCard
import com.nur.prayer.ui.today.DeedTone
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// The wallpaper underneath is already blurred by the window. A single translucent fill
// preserves its colour without a separate wallpaper draw/position observer for every row.
internal val NamesPaper = Color(0xE3E1E1E9)

internal val NamesJade = Color(0xFF204E40)
private enum class NameFace { INTRO, LIST, READER }

@Composable
internal fun NamesScreen(active: Boolean) {
    val context = LocalContext.current.applicationContext
    val prefs = remember(context) { context.getSharedPreferences("nur_names_reading", Context.MODE_PRIVATE) }
    var showIntro by remember { mutableStateOf(!prefs.getBoolean("introduced", false)) }
    // Record an actual presentation, even if the user leaves with Android Back.
    LaunchedEffect(active, showIntro) {
        if (active && showIntro) prefs.edit().putBoolean("introduced", true).apply()
    }
    var last by remember { mutableStateOf(prefs.getInt("bookmark_id", 0)) }
    var reading by rememberSaveable { mutableStateOf(false) }
    val face = if (showIntro) NameFace.INTRO else if (reading) NameFace.READER else NameFace.LIST
    var opened by rememberSaveable { mutableStateOf(1) }
    var query by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    var rows by remember { mutableStateOf<List<NameEntry>>(emptyList()) }
    var failed by remember { mutableStateOf(false) }
    var attempt by remember { mutableStateOf(0) }
    LaunchedEffect(context, attempt) {
        failed = false
        rows = withContext(Dispatchers.IO) {
            try { context.assets.open(NamesCatalog.ASSET).bufferedReader().use { NamesCatalog.parse(it.readLines()) } }
            catch (_: java.io.IOException) { emptyList() }
            catch (_: IllegalArgumentException) { emptyList() }
        }
        failed = rows.isEmpty()
    }
    val focus = LocalFocusManager.current
    val open: (Int) -> Unit = { id -> focus.clearFocus(); opened = id; reading = true }
    BackHandler(active && face == NameFace.READER) { reading = false }
    val area = Modifier.fillMaxSize().padding(top = LocalIslandInset.current, bottom = maxOf(LocalDockInset.current, WindowInsets.ime.asPaddingValues().calculateBottomPadding()))
    AnimatedContent(targetState = face, modifier = area, label = "namesFace", transitionSpec = {
        val direction = if (targetState == NameFace.READER) 1 else -1
        ((fadeIn(tween(145, delayMillis = 55)) + slideInVertically(tween(200)) { direction * it / 36 }) togetherWith
            fadeOut(tween(75))).using(null)
    }) { page ->
        when {
            page == NameFace.INTRO -> NamesIntro {
                showIntro = false
            }
            rows.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (failed) NameAction(tr("Повторить загрузку"), true) { attempt++ }
                else Text(tr("Загрузка…"), color = Color.White)
            }
            page == NameFace.READER -> key(opened) { NamesReader(rows, opened, onList = { reading = false }, onRead = { id ->
                if (last != id) { last = id; prefs.edit().putInt("bookmark_id", id).apply() }
            }) }
            else -> NamesIndex(rows, listState, query, { query = it }, last, open)
        }
    }
}

@Composable
internal fun NameAction(label: String, primary: Boolean, enabled: Boolean = true, modifier: Modifier = Modifier,
    onClick: () -> Unit) {
    val ui = uiScale()
    val fill = if (primary) NamesJade else Color(0xFFF0F4EF)
    Box(modifier.background(fill, CircleShape).pressClick(enabled = enabled, shape = CircleShape, onClick = onClick)
        .heightIn(min = 48.dp).padding(horizontal = 14.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (primary) Color.White else if (enabled) NamesJade else Color(0xFF616A65),
            fontSize = ui.t(13f), lineHeight = ui.t(17f), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun NamesIntro(enter: () -> Unit) {
    val ui = uiScale()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        DeedCard { Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            ArabicText("الأسماء الحسنى", 38f, color = NamesJade)
            Text(tr("99 имён Аллаха"), color = DeedTone.Ink, fontSize = ui.t(27f), lineHeight = ui.t(32f), fontWeight = FontWeight.Bold)
            Text(tr("Откройте имя, прочитайте его смысл и листайте дальше в своём темпе."), color = DeedTone.Quiet, fontSize = ui.t(16f), lineHeight = ui.t(23f))
            NameAction(tr("Открыть имена"), true, modifier = Modifier.fillMaxWidth(), onClick = enter)
        } }
        DeedCard { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tr("Об источниках"), color = NamesJade, fontWeight = FontWeight.Bold)
            Text(tr("У аль-Бухари (2736) говорится о числе имён, но нет их списка. Здесь принят традиционный порядок; у учёных встречаются и другие перечни."), color = DeedTone.Ink, fontSize = ui.t(14f), lineHeight = ui.t(20f))
            Text(tr("Краткие смыслы даны на русском. Там, где указан аят, его перевод отделён от пояснения."), color = DeedTone.Quiet, fontSize = ui.t(14f), lineHeight = ui.t(20f))
            Text(tr("Пояснения — по книге аль-Газали «Аль-Максад аль-асна». Это пересказ, а не цитата."), color = DeedTone.Quiet, fontSize = ui.t(14f), lineHeight = ui.t(20f))
        } }
    }
}
