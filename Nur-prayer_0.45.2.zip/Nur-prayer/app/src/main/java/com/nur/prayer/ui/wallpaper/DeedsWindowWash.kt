package com.nur.prayer.ui.wallpaper

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// The same exposure behind the system clock and the page title. No status-bar-specific shadow.
private val PhotoHeader = Color(0xAAD1CBCD)

internal fun Modifier.deedsWindowWash(photo: Boolean, amount: () -> Float): Modifier = drawWithCache {
    val brush = if (photo) Brush.verticalGradient(
        0f to PhotoHeader, .30f to PhotoHeader, .5f to Color.Transparent,
        .75f to Color(0x4A252327), 1f to Color(0x8C2A282C)
    ) else Brush.verticalGradient(.5f to Color.Transparent, 1f to Color(0x45000000))
    onDrawWithContent {
        drawContent()
        val k = amount().coerceIn(0f, 1f)
        if (k > .001f) drawRect(brush, alpha = k)
    }
}
