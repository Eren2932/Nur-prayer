package com.nur.prayer.daily

/** Opening position is chosen once per session; counts never drive a turn. */
internal object AzkarPages {
    fun opening(list: List<Zikr>, counts: Map<String, Long>): Int =
        list.indexOfFirst { (counts[it.id] ?: 0L) < it.count }.coerceAtLeast(0)

    fun neighbour(index: Int, step: Int, size: Int): Int? =
        if (index in 0 until size && (step == -1 || step == 1)) (index + step).takeIf { it in 0 until size } else null

    fun fraction(position: Float, size: Int): Float =
        if (size > 0) ((position + 1f) / size).coerceIn(0f, 1f) else 0f
}
