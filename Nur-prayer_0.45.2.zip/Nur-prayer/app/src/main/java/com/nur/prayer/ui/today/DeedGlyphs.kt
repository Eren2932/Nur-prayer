package com.nur.prayer.ui.today

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * 0.41.0: the four marks of «Дела» that the shared sets do not have: the mosque (the island), the history clock, the
 * bowl (salawat) and the fruits (istighfar). Drawn from lines, circles and arcs on a 24-unit grid, outlined like the
 * rest of the page's icons; the geometry below is generated from one table and checked on a preview.
 */
internal enum class DeedGlyph { MOSQUE, HISTORY, BOWL, FRUITS }

private const val GRID = 24f
private const val STROKE = 1.8f

@Composable
internal fun DeedGlyphIcon(glyph: DeedGlyph, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val k = size.minDimension / GRID
        val stroke = Stroke(width = STROKE * k, cap = StrokeCap.Round)
        when (glyph) {
            DeedGlyph.MOSQUE -> {
                arc(color, 12f, 13f, 5f, 180f, 180f, k, stroke)
                line(color, 7f, 13f, 7f, 20f, k, stroke)
                line(color, 17f, 13f, 17f, 20f, k, stroke)
                line(color, 4.5f, 20f, 19.5f, 20f, k, stroke)
                line(color, 12f, 8f, 12f, 6f, k, stroke)
                dot(color, 12f, 5.1f, 0.9f, k)
                line(color, 3.2f, 20f, 3.2f, 9.5f, k, stroke)
                line(color, 20.8f, 20f, 20.8f, 9.5f, k, stroke)
                dot(color, 3.2f, 8.2f, 0.9f, k)
                dot(color, 20.8f, 8.2f, 0.9f, k)
                arc(color, 12f, 20f, 2.2f, 180f, 180f, k, stroke)
            }
            DeedGlyph.HISTORY -> {
                arc(color, 13f, 12f, 7.5f, 200f, 320f, k, stroke)
                line(color, 13f, 8.2f, 13f, 12f, k, stroke)
                line(color, 13f, 12f, 15.8f, 13.7f, k, stroke)
                line(color, 5.95f, 9.43f, 8.5f, 7.85f, k, stroke)
                line(color, 5.95f, 9.43f, 5.03f, 6.58f, k, stroke)
            }
            DeedGlyph.BOWL -> {
                arc(color, 12f, 12.5f, 8f, 0f, 180f, k, stroke)
                line(color, 3.2f, 12.5f, 20.8f, 12.5f, k, stroke)
                line(color, 8.5f, 20.5f, 15.5f, 20.5f, k, stroke)
                arc(color, 12f, 12.5f, 4.6f, 180f, 180f, k, stroke)
                dot(color, 12f, 6.4f, 0.9f, k)
            }
            DeedGlyph.FRUITS -> {
                ring(color, 9f, 15f, 5.2f, k, stroke)
                ring(color, 16.3f, 13.6f, 4.0f, k, stroke)
                line(color, 9f, 9.8f, 9.6f, 6.6f, k, stroke)
                line(color, 9.6f, 6.6f, 12.6f, 5.2f, k, stroke)
                line(color, 16.3f, 9.6f, 16.8f, 7.4f, k, stroke)
            }
        }
    }
}

private fun DrawScope.line(c: Color, x1: Float, y1: Float, x2: Float, y2: Float, k: Float, s: Stroke) =
    drawLine(c, Offset(x1 * k, y1 * k), Offset(x2 * k, y2 * k), strokeWidth = s.width, cap = StrokeCap.Round)

private fun DrawScope.ring(c: Color, cx: Float, cy: Float, r: Float, k: Float, s: Stroke) =
    drawCircle(c, r * k, Offset(cx * k, cy * k), style = s)

private fun DrawScope.dot(c: Color, cx: Float, cy: Float, r: Float, k: Float) =
    drawCircle(c, r * k, Offset(cx * k, cy * k))

private fun DrawScope.arc(c: Color, cx: Float, cy: Float, r: Float, start: Float, sweep: Float, k: Float, s: Stroke) =
    drawArc(c, start, sweep, useCenter = false, topLeft = Offset((cx - r) * k, (cy - r) * k), size = Size(2 * r * k, 2 * r * k), style = s)
