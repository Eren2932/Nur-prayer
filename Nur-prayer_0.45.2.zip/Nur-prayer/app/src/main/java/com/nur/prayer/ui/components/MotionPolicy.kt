package com.nur.prayer.ui.components

import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

val LocalBackdropPaused = staticCompositionLocalOf { mutableStateOf(false) }

internal data class NurMotionBudget(val ambient: Boolean = false, val foregroundScale: Float = 0f, val saving: Boolean = false)

/** Background sky/glints keep their original strict energy policy. */
@Composable
fun rememberAmbientMotionAllowed(): Boolean = rememberMotionBudget().ambient

/** Read the real lifecycle and settings again after every resume or policy change. */
@Composable
internal fun rememberMotionBudget(): NurMotionBudget {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var budget by remember(context, owner) { mutableStateOf(NurMotionBudget()) }
    DisposableEffect(context, owner) {
        fun update() {
            val saver = context.getSystemService(PowerManager::class.java)?.isPowerSaveMode == true
            val scale = Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
            val allowed = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) && !saver && scale > 0f
            budget = NurMotionBudget(allowed, if (owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) scale else 0f, saver)
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) = update()
        }
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) = update()
        }
        val lifecycle = LifecycleEventObserver { _, _ -> update() }
        owner.lifecycle.addObserver(lifecycle)
        ContextCompat.registerReceiver(context, receiver, IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED)
        context.contentResolver.registerContentObserver(
            Settings.Global.getUriFor(Settings.Global.ANIMATOR_DURATION_SCALE), false, observer)
        update()
        onDispose {
            owner.lifecycle.removeObserver(lifecycle)
            context.unregisterReceiver(receiver)
            context.contentResolver.unregisterContentObserver(observer)
        }
    }
    return budget
}
