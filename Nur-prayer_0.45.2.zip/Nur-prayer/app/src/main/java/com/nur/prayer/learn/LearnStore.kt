package com.nur.prayer.learn

import android.content.Context

/**
 * Learning progress on disk. One string in its own SharedPreferences file, written with apply():
 * the format is LearnProgress.encode(), lenient on read, so a damaged line costs one card, never
 * the whole history. Kept apart from the DataStore of the prayer settings on purpose: a lesson
 * writes after every answer and must never wake the prayer-time pipeline that observes settings.
 */
class LearnStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun load(): LearnProgress = LearnProgress.decode(prefs.getString(KEY_PROGRESS, null))

    fun save(progress: LearnProgress) {
        prefs.edit().putString(KEY_PROGRESS, progress.encode()).apply()
    }

    fun reset() {
        prefs.edit().remove(KEY_PROGRESS).apply()
    }

    /** 0.35.0. The learner's goal and level, on the device only; null until he has chosen. */
    fun loadProfile(): LearnProfile? = LearnProfile.decode(prefs.getString(KEY_PROFILE, null))

    fun saveProfile(profile: LearnProfile) {
        prefs.edit().putString(KEY_PROFILE, profile.encode()).apply()
    }

    private companion object {
        const val FILE = "nur_learn"
        const val KEY_PROGRESS = "progress"
        const val KEY_PROFILE = "profile"
    }
}

/** Bundled course data, parsed once. Pure loader so the JVM tests read the same files the app does. */
class LearnContent(val lexicon: Lexicon, val quran: QuranShort, val course: Course, val goal: LearnGoal = LearnGoal.QURAN) {

    /** 0.35.0. The same words and surahs, the course rebuilt for another goal. */
    fun forGoal(goal: LearnGoal): LearnContent =
        if (goal == this.goal) this else LearnContent(lexicon, quran, Course.build(lexicon, goal), goal)

    companion object {
        const val WORDS_ASSET = "learn/words.tsv"
        const val QURAN_ASSET = "learn/quran_short.tsv"

        fun parse(wordsTsv: String, quranTsv: String, goal: LearnGoal = LearnGoal.QURAN): LearnContent {
            val lexicon = Lexicon.parse(wordsTsv)
            return LearnContent(lexicon, QuranShort.parse(quranTsv), Course.build(lexicon, goal), goal)
        }

        fun fromAssets(context: Context, goal: LearnGoal = LearnGoal.QURAN): LearnContent {
            val assets = context.applicationContext.assets
            val words = assets.open(WORDS_ASSET).bufferedReader().use { it.readText() }
            val quran = assets.open(QURAN_ASSET).bufferedReader().use { it.readText() }
            return parse(words, quran, goal)
        }
    }
}
