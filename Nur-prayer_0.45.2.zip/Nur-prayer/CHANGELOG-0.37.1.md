# Nur 0.37.1 — исправление сборки 0.37.0

Только исправление, бар и панель не менялись.

- `androidTest/ObservatoryScreenTest.kt`: убран лишний `import androidx.compose.ui.test.assertDoesNotExist`.
  `assertDoesNotExist()` — метод `SemanticsNodeInteraction`, импорт ему не нужен.
- Версия 0.37.1 (versionCode 80).
