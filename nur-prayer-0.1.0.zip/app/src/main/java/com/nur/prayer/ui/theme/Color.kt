package com.nur.prayer.ui.theme

import androidx.compose.ui.graphics.Color
import com.nur.prayer.core.astro.Prayer

val Ink = Color(0xFF05060D)
val InkSoft = Color(0xFF0B0F1E)
val Gold = Color(0xFFE9C46A)
val GoldSoft = Color(0xFFF7E6B8)
val Mint = Color(0xFF6FE3C0)
val Violet = Color(0xFF8C7BF5)
val Azure = Color(0xFF4FA8F5)
val Amber = Color(0xFFF2A65A)
val Rose = Color(0xFFF07C8C)
val Crimson = Color(0xFFD9536B)

val TextPrimary = Color(0xFFF3F5FF)
val TextSecondary = Color(0xFFA7AECB)
val TextTertiary = Color(0xFF6E7691)

/** Colours for the living background: they follow the time of day. */
data class PhasePalette(
    val top: Color,
    val bottom: Color,
    val blobA: Color,
    val blobB: Color,
    val accent: Color,
    val accentSoft: Color,
    val stars: Boolean,
    val name: String
)

fun paletteFor(prayer: Prayer): PhasePalette = when (prayer) {
    Prayer.FAJR -> PhasePalette(
        top = Color(0xFF0C1030), bottom = Color(0xFF1B1436),
        blobA = Color(0xFF6C5CE7), blobB = Color(0xFFEE7B93),
        accent = Violet, accentSoft = Color(0xFFC9C1FF), stars = true, name = "Рассвет"
    )
    Prayer.SUNRISE -> PhasePalette(
        top = Color(0xFF14203F), bottom = Color(0xFF3A2340),
        blobA = Color(0xFFF2A65A), blobB = Color(0xFFEE7B93),
        accent = Amber, accentSoft = Color(0xFFFFD8A8), stars = false, name = "Восход"
    )
    Prayer.DHUHR -> PhasePalette(
        top = Color(0xFF0A1B38), bottom = Color(0xFF123152),
        blobA = Color(0xFF4FA8F5), blobB = Color(0xFF6FE3C0),
        accent = Azure, accentSoft = Color(0xFFB6DCFF), stars = false, name = "Полдень"
    )
    Prayer.ASR -> PhasePalette(
        top = Color(0xFF0E1D33), bottom = Color(0xFF2A2A45),
        blobA = Color(0xFF7FB2F0), blobB = Color(0xFFE9C46A),
        accent = Gold, accentSoft = GoldSoft, stars = false, name = "Предвечерье"
    )
    Prayer.MAGHRIB -> PhasePalette(
        top = Color(0xFF15132E), bottom = Color(0xFF3A1B2E),
        blobA = Color(0xFFD9536B), blobB = Color(0xFFF2A65A),
        accent = Crimson, accentSoft = Color(0xFFFFC0A8), stars = true, name = "Закат"
    )
    Prayer.ISHA -> PhasePalette(
        top = Color(0xFF05070F), bottom = Color(0xFF0E1430),
        blobA = Color(0xFF3D4CB8), blobB = Color(0xFF1D8F8F),
        accent = Mint, accentSoft = Color(0xFFB9FFEA), stars = true, name = "Ночь"
    )
}
