package com.nur.prayer.ui.qibla

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.GlassPanel
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun QiblaScreen(
    data: PrayerData,
    palette: PhasePalette,
    modifier: Modifier = Modifier
) {
    val heading = rememberHeading(data.place.coordinates.latitude, data.place.coordinates.longitude)
    val qibla = data.qibla.toFloat()
    val delta = angleDelta(heading.azimuth, qibla)
    val aligned = abs(delta) <= 3f
    val haptic = LocalHapticFeedback.current

    LaunchedEffect(aligned) {
        if (aligned) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    val ringColor by animateColorAsState(
        if (aligned) Mint else palette.accent, tween(400), label = "qiblaRing"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(6.dp))
        Text("Кыбла", color = TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
        Text(
            text = "${data.place.label} · ${data.kaabaDistanceKm.roundToInt()} км до Каабы",
            color = TextTertiary,
            fontSize = 12.sp
        )

        Spacer(Modifier.height(14.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f),
            contentAlignment = Alignment.Center
        ) {
            // Rotating dial: the world turns, the phone stays still.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { rotationZ = -heading.azimuth }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val radius = size.minDimension / 2f - 30f

                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(Color.White.copy(alpha = 0.05f), Color.Transparent),
                            center = center, radius = radius
                        ),
                        radius = radius, center = center
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.14f),
                        radius = radius,
                        center = center,
                        style = Stroke(width = 2f)
                    )
                    for (i in 0 until 72) {
                        val a = Math.toRadians(i * 5.0 - 90.0)
                        val major = i % 6 == 0
                        val outer = radius
                        val inner = radius - if (major) 22f else 10f
                        drawLine(
                            color = Color.White.copy(alpha = if (major) 0.35f else 0.14f),
                            start = Offset(
                                center.x + outer * cos(a).toFloat(),
                                center.y + outer * sin(a).toFloat()
                            ),
                            end = Offset(
                                center.x + inner * cos(a).toFloat(),
                                center.y + inner * sin(a).toFloat()
                            ),
                            strokeWidth = if (major) 3f else 1.5f,
                            cap = StrokeCap.Round
                        )
                    }
                    // Qibla ray
                    val qa = Math.toRadians(qibla - 90.0)
                    drawLine(
                        brush = Brush.linearGradient(
                            listOf(ringColor.copy(alpha = 0.1f), ringColor)
                        ),
                        start = center,
                        end = Offset(
                            center.x + (radius - 18f) * cos(qa).toFloat(),
                            center.y + (radius - 18f) * sin(qa).toFloat()
                        ),
                        strokeWidth = 8f,
                        cap = StrokeCap.Round
                    )
                }

                CardinalLabel("С", 0f, ringColor)
                CardinalLabel("В", 90f, TextSecondary)
                CardinalLabel("Ю", 180f, TextSecondary)
                CardinalLabel("З", 270f, TextSecondary)

                // Kaaba marker, kept upright while the dial spins.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { rotationZ = qibla }
                ) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .size(46.dp)
                            .graphicsLayer { rotationZ = heading.azimuth - qibla }
                            .clip(CircleShape)
                            .background(ringColor.copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🕋", fontSize = 22.sp)
                    }
                }
            }

            // Fixed device pointer
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.minDimension / 2f - 30f
                val path = Path().apply {
                    moveTo(center.x, center.y - radius - 16f)
                    lineTo(center.x - 12f, center.y - radius + 10f)
                    lineTo(center.x + 12f, center.y - radius + 10f)
                    close()
                }
                drawPath(path, color = ringColor)
                drawCircle(color = Color.White.copy(alpha = 0.9f), radius = 5f, center = center)
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 26.dp)
            ) {
                Text(
                    text = "${qibla.roundToInt()}°",
                    color = TextPrimary,
                    fontSize = 42.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Light
                )
                Text(
                    text = if (aligned) "Точно на Каабу" else if (delta > 0) "поверните вправо на ${abs(delta).roundToInt()}°"
                    else "поверните влево на ${abs(delta).roundToInt()}°",
                    color = if (aligned) Mint else TextSecondary,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = 16.dp) {
            Column {
                InfoRow("Азимут кыблы (от истинного севера)", "${qibla.roundToInt()}°")
                InfoRow("Курс устройства", "${heading.azimuth.roundToInt()}°")
                InfoRow("Магнитная поправка (WMM)", "${heading.declination.roundToInt()}°")
                InfoRow(
                    "Точность датчика",
                    when (heading.accuracy) {
                        3 -> "высокая"
                        2 -> "средняя"
                        1 -> "низкая"
                        0 -> "не калиброван"
                        else -> "определяется"
                    }
                )
                if (!heading.available) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "На этом устройстве нет магнитометра — компас недоступен, но азимут кыблы выше рассчитан точно.",
                        color = TextTertiary, fontSize = 12.sp
                    )
                }
                if (heading.accuracy in 0..1) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Проведите телефоном «восьмёркой» в воздухе 3-4 секунды и уберите его от металла и магнитов — это калибрует магнитометр.",
                        color = TextTertiary, fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(130.dp))
    }
}

@Composable
private fun CardinalLabel(text: String, angle: Float, color: Color) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { rotationZ = angle }
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 2.dp)
                .graphicsLayer { rotationZ = -angle }
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextTertiary, fontSize = 12.sp)
        Text(value, color = TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
    }
}
