package com.nur.prayer.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.ui.components.AuroraBackground
import com.nur.prayer.ui.components.NavItem
import com.nur.prayer.ui.components.NurNavBar
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.settings.SettingsScreen
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.paletteFor

private const val TAB_HOME = "home"
private const val TAB_SCHEDULE = "schedule"
private const val TAB_QIBLA = "qibla"
private const val TAB_SETTINGS = "settings"
private const val ROUTE_CITY = "city"

@Composable
fun NurRoot(
    data: PrayerData?,
    now: java.time.ZonedDateTime,
    locating: Boolean,
    exactAlarmsAllowed: Boolean,
    citySearch: (String) -> List<com.nur.prayer.data.City>,
    onPickCity: (com.nur.prayer.data.City) -> Unit,
    actionsFactory: (openCityPicker: () -> Unit) -> AppActions
) {
    var tab by remember { mutableStateOf(TAB_HOME) }
    var route by remember { mutableStateOf<String?>(null) }

    val palette = paletteFor(data?.window?.current ?: com.nur.prayer.core.astro.Prayer.ISHA)
    val actions = actionsFactory { route = ROUTE_CITY }

    Box(modifier = Modifier.fillMaxSize()) {
        AuroraBackground(palette = palette)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            AnimatedContent(
                targetState = route ?: tab,
                transitionSpec = {
                    (fadeIn(tween(320)) + slideInVertically(tween(320)) { it / 22 }) togetherWith
                        fadeOut(tween(180)) + slideOutVertically(tween(180)) { -it / 40 }
                },
                label = "screens",
                modifier = Modifier.fillMaxSize()
            ) { target ->
                if (data == null) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Считаем солнце…", color = TextSecondary, fontSize = 14.sp)
                    }
                } else {
                    when (target) {
                        ROUTE_CITY -> CityPickerScreen(
                            palette = palette,
                            selectedCityId = data.settings.cityId,
                            search = citySearch,
                            onPick = { city ->
                                onPickCity(city)
                                route = null
                            },
                            onBack = { route = null },
                            onUseLocation = { actions.requestLocation() },
                            locating = locating
                        )
                        TAB_SCHEDULE -> ScheduleScreen(data = data, palette = palette)
                        TAB_QIBLA -> QiblaScreen(data = data, palette = palette)
                        TAB_SETTINGS -> SettingsScreen(
                            data = data,
                            palette = palette,
                            actions = actions,
                            exactAlarmsAllowed = exactAlarmsAllowed
                        )
                        else -> HomeScreen(
                            data = data,
                            now = now,
                            palette = palette,
                            onOpenCity = { route = ROUTE_CITY }
                        )
                    }
                }
            }
        }

        if (route == null) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                NurNavBar(
                    items = listOf(
                        NavItem(TAB_HOME, "Намаз", Icons.Filled.Home),
                        NavItem(TAB_SCHEDULE, "2 недели", Icons.Filled.DateRange),
                        NavItem(TAB_QIBLA, "Кыбла", Icons.Filled.Place),
                        NavItem(TAB_SETTINGS, "Ещё", Icons.Filled.Settings)
                    ),
                    selected = tab,
                    onSelect = { tab = it },
                    accent = palette.accent
                )
            }
        }
    }
}
