package com.nur.prayer.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.CountdownRing
import com.nur.prayer.ui.components.GlassPanel
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import java.time.ZonedDateTime

@Composable
fun HomeScreen(
    data: PrayerData,
    now: ZonedDateTime,
    palette: PhasePalette,
    onOpenCity: () -> Unit,
    modifier: Modifier = Modifier
) {
    val window = data.window
    val remaining = window.remaining(now)
    val progress = window.progress(now)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.08f))
                    .clickable { onOpenCity() }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Icon(
                    Icons.Filled.LocationOn,
                    contentDescription = "Город",
                    tint = palette.accent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = data.place.label,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End) {
                Text(data.hijri, color = palette.accentSoft, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(
                    Format.dayMonth(now.toLocalDate()),
                    color = TextTertiary,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(Modifier.height(18.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            CountdownRing(
                progress = progress,
                accent = palette.accent,
                accentSoft = palette.accentSoft,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "ДО ${PrayerLabels.title(window.next).uppercase()}",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = Format.countdown(remaining),
                        color = TextPrimary,
                        fontSize = 52.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Light
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "начало в ${Format.time(window.nextStart)}",
                        color = palette.accentSoft,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.07f))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "сейчас ${PrayerLabels.title(window.current)} · ${palette.name}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = 8.dp) {
            Column {
                Prayer.entries.forEach { prayer ->
                    val time = data.today.times[prayer]
                    PrayerRow(
                        prayer = prayer,
                        timeText = time?.let { Format.time(it) } ?: "—",
                        isCurrent = prayer == window.current,
                        isNext = prayer == window.next,
                        accent = palette.accent,
                        enabled = data.settings.notifications[prayer] == true
                    )
                }
            }
        }

        val note = data.today.note
        if (note != null) {
            Spacer(Modifier.height(12.dp))
            GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = 14.dp, alpha = 0.05f) {
                Text(note, color = TextSecondary, fontSize = 13.sp, textAlign = TextAlign.Start)
            }
        }

        Spacer(Modifier.height(120.dp))
    }
}

@Composable
private fun PrayerRow(
    prayer: Prayer,
    timeText: String,
    isCurrent: Boolean,
    isNext: Boolean,
    accent: Color,
    enabled: Boolean
) {
    val highlight by animateColorAsState(
        when {
            isNext -> accent.copy(alpha = 0.16f)
            isCurrent -> Color.White.copy(alpha = 0.06f)
            else -> Color.Transparent
        },
        tween(600), label = "rowBg"
    )
    val titleColor by animateColorAsState(
        if (isNext) accent else TextPrimary, tween(600), label = "rowTitle"
    )
    val alpha by animateFloatAsState(if (enabled || prayer == Prayer.SUNRISE) 1f else 0.55f, label = "rowAlpha")

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(highlight)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(
                    if (isNext) Brush.linearGradient(listOf(accent, Color.White))
                    else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.1f)))
                )
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = PrayerLabels.title(prayer),
                color = titleColor.copy(alpha = alpha),
                fontSize = 16.sp,
                fontWeight = if (isNext) FontWeight.SemiBold else FontWeight.Medium
            )
            Text(
                text = PrayerLabels.hint(prayer),
                color = TextTertiary,
                fontSize = 11.sp
            )
        }
        Text(
            text = PrayerLabels.arabic(prayer),
            color = TextTertiary,
            fontSize = 15.sp
        )
        Spacer(Modifier.width(14.dp))
        Text(
            text = timeText,
            color = titleColor.copy(alpha = alpha),
            fontSize = 19.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium,
            style = MaterialTheme.typography.titleMedium.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 19.sp
            )
        )
    }
}
