package com.nur.prayer.ui.schedule

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import java.time.LocalDate

@Composable
fun ScheduleScreen(
    data: PrayerData,
    palette: PhasePalette,
    modifier: Modifier = Modifier
) {
    val today = data.days.first().date
    var expanded by remember { mutableStateOf<LocalDate?>(today) }

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 130.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(bottom = 6.dp)) {
                Text("Расписание", color = TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "${data.days.size} дней · ${data.place.label} · ${data.settings.method.title}",
                    color = TextTertiary,
                    fontSize = 12.sp
                )
            }
        }
        items(data.days, key = { it.date.toString() }) { day ->
            DayCard(
                day = day,
                isToday = day.date == today,
                isExpanded = expanded == day.date,
                hijriOffset = data.settings.hijriOffset,
                palette = palette,
                onClick = { expanded = if (expanded == day.date) null else day.date }
            )
        }
    }
}

@Composable
private fun DayCard(
    day: PrayerDay,
    isToday: Boolean,
    isExpanded: Boolean,
    hijriOffset: Int,
    palette: PhasePalette,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                if (isToday) palette.accent.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.06f)
            )
            .border(
                width = 1.dp,
                color = if (isToday) palette.accent.copy(alpha = 0.45f) else Color.White.copy(alpha = 0.10f),
                shape = shape
            )
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = Format.dayMonth(day.date),
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.padding(horizontal = 4.dp))
                    Text(
                        text = "· ${Format.weekdayShort(day.date)}",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    if (isToday) {
                        Spacer(Modifier.padding(horizontal = 4.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(palette.accent.copy(alpha = 0.25f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("сегодня", color = palette.accentSoft, fontSize = 10.sp)
                        }
                    }
                }
                Text(
                    text = HijriCalendar.format(day.date, hijriOffset),
                    color = TextTertiary,
                    fontSize = 11.sp
                )
            }
            Text(
                text = day.times[Prayer.FAJR]?.let { Format.time(it) } ?: "—",
                color = palette.accentSoft,
                fontFamily = FontFamily.Monospace,
                fontSize = 15.sp
            )
        }

        Spacer(Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Prayer.entries.forEach { prayer ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = PrayerLabels.title(prayer),
                        color = TextTertiary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(3.dp))
                    Text(
                        text = day.times[prayer]?.let { Format.time(it) } ?: "—",
                        color = if (prayer == Prayer.SUNRISE) TextSecondary else TextPrimary,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        if (isExpanded) {
            val note = day.note
            Spacer(Modifier.height(10.dp))
            Text(
                text = note ?: "Все времена рассчитаны локально на устройстве: без интернета и без API.",
                color = TextTertiary,
                fontSize = 11.sp
            )
        }
    }
}
