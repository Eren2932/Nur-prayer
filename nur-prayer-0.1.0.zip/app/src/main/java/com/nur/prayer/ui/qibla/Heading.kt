package com.nur.prayer.ui.qibla

import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlin.math.abs

/**
 * Device heading in degrees clockwise from TRUE north.
 *
 * The magnetometer gives magnetic north; in Russia the declination reaches 15+ degrees, which is
 * a whole city block of error at Qibla distances, so we correct it with the WMM model built into
 * Android ([GeomagneticField]).
 */
data class Heading(
    val azimuth: Float = 0f,
    /** SensorManager.SENSOR_STATUS_ACCURACY_*, -1 when unknown. */
    val accuracy: Int = -1,
    val available: Boolean = true,
    val declination: Float = 0f
)

@Composable
fun rememberHeading(latitude: Double, longitude: Double): Heading {
    val context = LocalContext.current
    var heading by remember { mutableStateOf(Heading()) }

    DisposableEffect(latitude, longitude) {
        val manager = context.getSystemService(SensorManager::class.java)
        val rotationSensor = manager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val magnetSensor = manager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        val declination = GeomagneticField(
            latitude.toFloat(), longitude.toFloat(), 0f, System.currentTimeMillis()
        ).declination

        var listener: SensorEventListener? = null

        if (manager == null || rotationSensor == null) {
            heading = Heading(available = false, declination = declination)
        } else {
            val matrix = FloatArray(9)
            val orientation = FloatArray(3)
            var smoothed = Float.NaN

            listener = object : SensorEventListener {
                override fun onSensorChanged(event: SensorEvent) {
                    if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
                    SensorManager.getRotationMatrixFromVector(matrix, event.values)
                    SensorManager.getOrientation(matrix, orientation)
                    val magnetic = Math.toDegrees(orientation[0].toDouble()).toFloat()
                    val trueNorth = normalize(magnetic + declination)
                    smoothed = if (smoothed.isNaN()) trueNorth else lerpAngle(smoothed, trueNorth, 0.16f)
                    heading = heading.copy(
                        azimuth = smoothed,
                        available = true,
                        declination = declination
                    )
                }

                override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
                    heading = heading.copy(accuracy = accuracy)
                }
            }
            manager.registerListener(listener, rotationSensor, SensorManager.SENSOR_DELAY_GAME)
            if (magnetSensor != null) {
                manager.registerListener(listener, magnetSensor, SensorManager.SENSOR_DELAY_UI)
            }
        }

        onDispose {
            val current = listener
            if (current != null) manager?.unregisterListener(current)
        }
    }

    return heading
}

internal fun normalize(angle: Float): Float = ((angle % 360f) + 360f) % 360f

/** Shortest-path angular interpolation: no 359 -> 0 jump. */
internal fun lerpAngle(from: Float, to: Float, factor: Float): Float {
    var delta = ((to - from + 540f) % 360f) - 180f
    if (abs(delta) < 0.05f) return to
    return normalize(from + delta * factor)
}

/** Signed difference in degrees, -180..180. */
internal fun angleDelta(from: Float, to: Float): Float = ((to - from + 540f) % 360f) - 180f
