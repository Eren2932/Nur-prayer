package com.nur.prayer.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.GlassPanel
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary

@Composable
fun SettingsScreen(
    data: PrayerData,
    palette: PhasePalette,
    actions: AppActions,
    exactAlarmsAllowed: Boolean,
    modifier: Modifier = Modifier
) {
    val settings = data.settings

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 140.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Настройки", color = TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
                Text("Всё считается офлайн на устройстве", color = TextTertiary, fontSize = 12.sp)
            }
        }

        item {
            SectionCard("Местоположение") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { actions.openCityPicker() }
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.LocationOn, null, tint = palette.accent, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(data.place.label, color = TextPrimary, fontSize = 15.sp)
                        Text(data.place.subtitle, color = TextTertiary, fontSize = 11.sp)
                    }
                    Text("изменить", color = palette.accentSoft, fontSize = 12.sp)
                }
                PillButton(
                    text = "Определить по геолокации",
                    accent = palette.accent,
                    onClick = { actions.requestLocation() }
                )
            }
        }

        item {
            SectionCard("Метод расчёта") {
                CalculationMethod.entries.forEach { method ->
                    SelectableRow(
                        title = method.title,
                        subtitle = subtitleFor(method),
                        selected = settings.method == method,
                        accent = palette.accent,
                        onClick = { actions.setMethod(method) }
                    )
                }
            }
        }

        item {
            SectionCard("Мазхаб (время Асра)") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillToggle(
                        text = "Ханафитский",
                        selected = settings.madhab == Madhab.HANAFI,
                        accent = palette.accent,
                        modifier = Modifier.weight(1f)
                    ) { actions.setMadhab(Madhab.HANAFI) }
                    PillToggle(
                        text = "Шафиитский",
                        selected = settings.madhab == Madhab.STANDARD,
                        accent = palette.accent,
                        modifier = Modifier.weight(1f)
                    ) { actions.setMadhab(Madhab.STANDARD) }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Ханафитский Аср наступает позже: тень объекта равна двум его высотам.",
                    color = TextTertiary, fontSize = 11.sp
                )
            }
        }

        item {
            SectionCard("Высокие широты") {
                HighLatitudeRule.entries.forEach { rule ->
                    SelectableRow(
                        title = ruleTitle(rule),
                        subtitle = ruleSubtitle(rule),
                        selected = settings.highLatitudeRule == rule,
                        accent = palette.accent,
                        onClick = { actions.setHighLatitudeRule(rule) }
                    )
                }
            }
        }

        item {
            SectionCard("Уведомления") {
                if (!exactAlarmsAllowed) {
                    WarningBlock(
                        text = "Android запрещает приложению точные будильники. Без этого разрешения " +
                            "уведомления могут опаздывать на несколько минут.",
                        actionText = "Разрешить точные будильники",
                        accent = palette.accent,
                        onClick = { actions.openExactAlarmSettings() }
                    )
                    Spacer(Modifier.height(10.dp))
                }
                Prayer.entries.filter { it.isPrayer }.forEach { prayer ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(PrayerLabels.title(prayer), color = TextPrimary, fontSize = 15.sp)
                            Text(PrayerLabels.hint(prayer), color = TextTertiary, fontSize = 11.sp)
                        }
                        Switch(
                            checked = settings.notifications[prayer] == true,
                            onCheckedChange = { actions.setNotification(prayer, it) },
                            colors = SwitchDefaults.colors(
                                checkedTrackColor = palette.accent.copy(alpha = 0.55f),
                                checkedThumbColor = Color.White
                            )
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Stepper(
                    label = "Напомнить заранее",
                    value = "${settings.preAlertMinutes} мин",
                    accent = palette.accent,
                    onMinus = { actions.setPreAlert(settings.preAlertMinutes - 5) },
                    onPlus = { actions.setPreAlert(settings.preAlertMinutes + 5) }
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Без звука", color = TextPrimary, fontSize = 15.sp)
                        Text("Только вибрация и всплывающее уведомление", color = TextTertiary, fontSize = 11.sp)
                    }
                    Switch(
                        checked = settings.silentNotifications,
                        onCheckedChange = { actions.setSilent(it) },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = palette.accent.copy(alpha = 0.55f),
                            checkedThumbColor = Color.White
                        )
                    )
                }
                Spacer(Modifier.height(8.dp))
                PillButton(
                    text = "Отключить экономию батареи для Nur",
                    accent = palette.accent,
                    onClick = { actions.openBatterySettings() }
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Xiaomi, Huawei, Samsung и Oppo убивают фоновые процессы: разрешите автозапуск " +
                        "и снимите ограничения батареи, иначе система задержит любое уведомление.",
                    color = TextTertiary, fontSize = 11.sp
                )
            }
        }

        item {
            SectionCard("Ручная коррекция, минуты") {
                Prayer.entries.forEach { prayer ->
                    val value = settings.offsets[prayer] ?: 0
                    Stepper(
                        label = PrayerLabels.title(prayer),
                        value = (if (value > 0) "+$value" else "$value"),
                        accent = palette.accent,
                        onMinus = { actions.setOffset(prayer, value - 1) },
                        onPlus = { actions.setOffset(prayer, value + 1) }
                    )
                }
                Spacer(Modifier.height(6.dp))
                Stepper(
                    label = "Сдвиг даты по хиджре",
                    value = "${settings.hijriOffset} дн.",
                    accent = palette.accent,
                    onMinus = { actions.setHijriOffset(settings.hijriOffset - 1) },
                    onPlus = { actions.setHijriOffset(settings.hijriOffset + 1) }
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Сверьте расписание с вашей мечетью и выровняйте разницу здесь: коррекция " +
                        "применяется и к уведомлениям.",
                    color = TextTertiary, fontSize = 11.sp
                )
            }
        }

        item {
            SectionCard("О расчёте") {
                InfoLine("Координаты", format(data.place.coordinates.latitude) + ", " + format(data.place.coordinates.longitude))
                InfoLine("Часовой пояс", data.place.zone.id)
                InfoLine("Азимут кыблы", "${Math.round(data.qibla)}°")
                InfoLine("Углы метода", "Фаджр ${settings.method.fajrAngle}° · Иша " +
                    if (settings.method.ishaIntervalMinutes > 0) "${settings.method.ishaIntervalMinutes} мин"
                    else "${settings.method.ishaAngle}°")
                Spacer(Modifier.height(8.dp))
                Text(
                    "Алгоритм: астрономические формулы Жана Мееса (Astronomical Algorithms, 2-е изд.), " +
                        "точность солнечных событий — единицы секунд. Nur 0.1.0",
                    color = TextTertiary, fontSize = 11.sp
                )
            }
        }
    }
}

private fun format(value: Double): String = String.format(java.util.Locale.US, "%.4f", value)

private fun subtitleFor(method: CalculationMethod): String = when (method) {
    CalculationMethod.RUSSIA_DUM -> "Рекомендуется для России и СНГ"
    CalculationMethod.SPIRITUAL_BOARD_TATARSTAN -> "Поволжье, Татарстан"
    CalculationMethod.UMM_AL_QURA -> "Саудовская Аравия, Иша через 90 минут"
    CalculationMethod.TURKEY -> "С поправками Diyanet"
    else -> "Фаджр ${method.fajrAngle}° · Иша " +
        if (method.ishaIntervalMinutes > 0) "${method.ishaIntervalMinutes} мин" else "${method.ishaAngle}°"
}

private fun ruleTitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> "Автоматически"
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> "Середина ночи"
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> "Одна седьмая ночи"
    HighLatitudeRule.TWILIGHT_ANGLE -> "Пропорция по углу сумерек"
}

private fun ruleSubtitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> "Выше 48° широты — 1/7 ночи, иначе середина ночи"
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> "Фаджр и Иша не переходят середину ночи"
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> "Классика для Москвы, Казани, Петербурга летом"
    HighLatitudeRule.TWILIGHT_ANGLE -> "Доля ночи пропорциональна углу метода"
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = 16.dp) {
        Column {
            Text(
                title.uppercase(),
                color = TextSecondary,
                fontSize = 11.sp,
                letterSpacing = 1.5.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SelectableRow(
    title: String,
    subtitle: String,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) accent.copy(alpha = 0.14f) else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = TextTertiary, fontSize = 11.sp)
        }
        if (selected) {
            Icon(Icons.Filled.Check, null, tint = accent, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun PillToggle(
    text: String,
    selected: Boolean,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) accent.copy(alpha = 0.20f) else Color.White.copy(alpha = 0.05f))
            .border(
                1.dp,
                if (selected) accent.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.10f),
                RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (selected) TextPrimary else TextSecondary, fontSize = 13.sp)
    }
}

@Composable
private fun PillButton(text: String, accent: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(accent.copy(alpha = 0.16f))
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun WarningBlock(
    text: String,
    actionText: String,
    accent: Color,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x33FF6B6B))
            .padding(12.dp)
    ) {
        Text(text, color = TextPrimary, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        PillButton(actionText, accent, onClick)
    }
}

@Composable
private fun Stepper(
    label: String,
    value: String,
    accent: Color,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
        StepperButton("−", accent, onMinus)
        Text(
            value,
            color = TextPrimary,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier
                .width(72.dp)
                .padding(horizontal = 8.dp),
        )
        StepperButton("+", accent, onPlus)
    }
}

@Composable
private fun StepperButton(text: String, accent: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(accent.copy(alpha = 0.18f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextTertiary, fontSize = 12.sp)
        Text(value, color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    }
}
