package com.nur.prayer.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.PhasePalette
import kotlin.math.sin
import kotlin.random.Random

/**
 * The signature of the app: a slow, GPU-cheap aurora that re-colours itself with the time of day.
 * Two large radial blobs drift on sine paths, plus a deterministic star field at night.
 * Everything is drawn in a single Canvas: no bitmaps, no blur shaders, 120 Hz friendly.
 */
@Composable
fun AuroraBackground(
    palette: PhasePalette,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "aurora")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(26_000, easing = LinearEasing), RepeatMode.Restart),
        label = "drift"
    )
    val breathe by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "breathe"
    )
    val twinkle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3_500, easing = LinearEasing), RepeatMode.Reverse),
        label = "twinkle"
    )

    val top by animateColorAsState(palette.top, tween(1400), label = "top")
    val bottom by animateColorAsState(palette.bottom, tween(1400), label = "bottom")
    val blobA by animateColorAsState(palette.blobA, tween(1400), label = "blobA")
    val blobB by animateColorAsState(palette.blobB, tween(1400), label = "blobB")
    val starAlpha by animateColorAsState(
        if (palette.stars) Color.White else Color.Transparent, tween(1400), label = "stars"
    )

    val stars = remember {
        val random = Random(1445)
        List(70) {
            Triple(random.nextFloat(), random.nextFloat() * 0.75f, 0.6f + random.nextFloat() * 1.6f)
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(brush = Brush.verticalGradient(listOf(top, bottom)))

        val angle = drift * 2f * Math.PI.toFloat()
        val radiusA = size.minDimension * (0.85f + 0.1f * breathe)
        val centerA = Offset(
            x = size.width * (0.22f + 0.16f * sin(angle)),
            y = size.height * (0.16f + 0.06f * sin(angle * 1.3f))
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(blobA.copy(alpha = 0.55f), blobA.copy(alpha = 0.12f), Color.Transparent),
                center = centerA,
                radius = radiusA
            ),
            radius = radiusA,
            center = centerA
        )

        val radiusB = size.minDimension * (0.95f - 0.08f * breathe)
        val centerB = Offset(
            x = size.width * (0.85f - 0.18f * sin(angle * 0.8f)),
            y = size.height * (0.62f + 0.1f * sin(angle * 1.1f))
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(blobB.copy(alpha = 0.42f), blobB.copy(alpha = 0.10f), Color.Transparent),
                center = centerB,
                radius = radiusB
            ),
            radius = radiusB,
            center = centerB
        )

        if (starAlpha.alpha > 0.01f) {
            stars.forEachIndexed { index, (x, y, r) ->
                val phase = if (index % 2 == 0) twinkle else 1f - twinkle
                drawCircle(
                    color = Color.White.copy(alpha = (0.20f + 0.45f * phase) * starAlpha.alpha),
                    radius = r,
                    center = Offset(size.width * x, size.height * y)
                )
            }
        }

        // A soft vignette so that text always stays readable over the aurora.
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color.Black.copy(alpha = 0.28f), Color.Transparent, Color.Black.copy(alpha = 0.45f))
            )
        )
    }
}

val GlassCornerRadius = 26.dp
