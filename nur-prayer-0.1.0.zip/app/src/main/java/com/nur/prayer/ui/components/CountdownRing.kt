package com.nur.prayer.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/**
 * The countdown ring. Progress runs from the previous prayer to the next one, so the user can feel
 * how much of the window is left without reading a single digit.
 */
@Composable
fun CountdownRing(
    progress: Float,
    accent: Color,
    accentSoft: Color,
    modifier: Modifier = Modifier,
    strokeWidth: Float = 26f,
    content: @Composable BoxScope.() -> Unit
) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(900),
        label = "ringProgress"
    )

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val inset = strokeWidth * 1.6f
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            val topLeft = Offset(inset, inset)
            val radius = arcSize.minDimension / 2f
            val center = Offset(size.width / 2f, size.height / 2f)

            // Ambient halo
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(accent.copy(alpha = 0.18f), Color.Transparent),
                    center = center,
                    radius = radius * 1.25f
                ),
                radius = radius * 1.25f,
                center = center
            )

            // Track
            drawArc(
                color = Color.White.copy(alpha = 0.10f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Ticks: 60 minute marks, subtle
            for (i in 0 until 60) {
                val a = Math.toRadians(i * 6.0 - 90.0)
                val outer = radius + strokeWidth * 0.95f
                val inner = outer - if (i % 5 == 0) strokeWidth * 0.55f else strokeWidth * 0.28f
                drawLine(
                    color = Color.White.copy(alpha = if (i % 5 == 0) 0.20f else 0.09f),
                    start = Offset(center.x + outer * cos(a).toFloat(), center.y + outer * sin(a).toFloat()),
                    end = Offset(center.x + inner * cos(a).toFloat(), center.y + inner * sin(a).toFloat()),
                    strokeWidth = 2f
                )
            }

            // Progress
            val sweep = 360f * animated
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(accent, accentSoft, accent.copy(alpha = 0.85f), accent)
                ),
                startAngle = -90f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Leading glow dot
            val headAngle = Math.toRadians(-90.0 + sweep)
            val head = Offset(
                center.x + radius * cos(headAngle).toFloat(),
                center.y + radius * sin(headAngle).toFloat()
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(accentSoft, accent.copy(alpha = 0.0f)),
                    center = head,
                    radius = strokeWidth * 1.8f
                ),
                radius = strokeWidth * 1.8f,
                center = head
            )
            drawCircle(color = Color.White, radius = strokeWidth * 0.30f, center = head)
        }
        content()
    }
}

val RingStroke = 26.dp
