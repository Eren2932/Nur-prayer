package com.nur.prayer.ui.learn

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nur.prayer.learn.Course
import com.nur.prayer.learn.Exercise
import com.nur.prayer.learn.ExerciseFactory
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.learn.LearnProgress
import com.nur.prayer.learn.LearnStore
import com.nur.prayer.learn.Lesson
import com.nur.prayer.learn.LessonPlan
import com.nur.prayer.learn.LessonSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

/** The verdict on the current exercise, shown before the user moves on. */
data class Verdict(val correct: Boolean, val explain: String?)

/** A lesson in progress, or its result once [result] is set. */
data class ActiveLesson(
    val lesson: Lesson,
    val session: LessonSession,
    val verdict: Verdict? = null,
    val result: LessonOutcome? = null,
    /** Bumped on every step, so a screen keyed on it resets its local selection state. */
    val step: Int = 0
)

data class LessonOutcome(
    val stars: Int,
    val accuracy: Int,
    val xpGained: Int,
    val mistakes: List<Exercise>,
    /** A checkpoint that was passed: how many earlier lessons it marked as done. */
    val unlocked: Int = 0,
    val bestBefore: Int = 0
)

/**
 * State of the learning section. Course data loads off the main thread once per process; the
 * progress lives in [LearnStore] and is written after every graded answer, so killing the app in
 * the middle of a lesson loses at most the lesson's stars, never the spaced-repetition cards.
 */
class LearnViewModel(application: Application) : AndroidViewModel(application) {
    private val store = LearnStore(application)

    private val _content = MutableStateFlow<LearnContent?>(null)
    val content: StateFlow<LearnContent?> = _content.asStateFlow()

    private val _progress = MutableStateFlow(LearnProgress())
    val progress: StateFlow<LearnProgress> = _progress.asStateFlow()

    private val _active = MutableStateFlow<ActiveLesson?>(null)
    val active: StateFlow<ActiveLesson?> = _active.asStateFlow()

    private val _tasbih = MutableStateFlow(0)
    val tasbih: StateFlow<Int> = _tasbih.asStateFlow()

    private var seed = (System.nanoTime() and 0x7fffffff).toInt()

    init {
        viewModelScope.launch {
            val (loaded, saved) = withContext(Dispatchers.IO) {
                val c = runCatching { LearnContent.fromAssets(application) }.getOrNull()
                c to store.load()
            }
            _progress.value = saved
            _tasbih.value = withContext(Dispatchers.IO) { store.tasbih(today()) }
            _content.value = loaded
        }
    }

    fun today(): Long = LocalDate.now().toEpochDay()

    fun course(): Course? = _content.value?.course

    /**
     * Builds a fresh run of the lesson. Returns false when the lesson is locked or yields nothing.
     * [force] opens a locked lesson: "check yourself" in the surah reader is not gated by the course.
     */
    fun start(lessonId: String, force: Boolean = false): Boolean {
        val c = _content.value ?: return false
        val lesson = c.course.lesson(lessonId) ?: return false
        val progress = _progress.value
        if (!force && lesson.plan !is LessonPlan.Checkpoint && lessonId != Course.REVIEW_ID && !c.course.isUnlocked(lessonId, progress)) return false
        seed = seed * 1103515245 + 12345
        val exercises = ExerciseFactory(c.lexicon, c.quran, seed).build(lesson.plan, c.course, progress, today())
        if (exercises.isEmpty()) return false
        _active.value = ActiveLesson(lesson, LessonSession(exercises))
        return true
    }

    /** Intro cards are not graded: their cards enter the Leitner system and the lesson moves on. */
    fun acknowledge() {
        val a = _active.value ?: return
        val ex = a.session.current ?: return
        if (!ex.isIntro) return
        if (ex.cards.isNotEmpty()) persist(_progress.value.introduce(ex.cards, today()))
        advance(a.copy(session = a.session.skip()))
    }

    /** First press: grade and show the verdict. The answer is final once given. */
    fun check(correct: Boolean) {
        val a = _active.value ?: return
        if (a.verdict != null || a.session.current == null) return
        val ex = a.session.current!!
        persist(_progress.value.introduce(ex.cards, today()).answer(ex.cards, correct, today()))
        _active.value = a.copy(verdict = Verdict(correct, explainOf(ex)))
    }

    /** Second press after a verdict: record it in the session and go to the next exercise. */
    fun next() {
        val a = _active.value ?: return
        val v = a.verdict ?: return
        advance(a.copy(session = a.session.answer(v.correct), verdict = null))
    }

    private fun advance(a: ActiveLesson) {
        if (!a.session.finished) {
            _active.value = a.copy(step = a.step + 1)
            return
        }
        val before = _progress.value
        val best = before.stars(a.lesson.id)
        var after = before.complete(a.lesson.id, a.session.accuracy, a.session.firstTryCorrect, today())
        var unlocked = 0
        val plan = a.lesson.plan
        val stars = LearnProgress.starsFor(a.session.accuracy)
        if (plan is LessonPlan.Checkpoint && stars > 0) {
            val earlier = course()?.stages?.take(plan.stageIndex)?.flatMap { s -> s.lessons.map { it.id } }.orEmpty()
            unlocked = earlier.count { !after.isDone(it) }
            after = after.pass(earlier)
        }
        persist(after)
        _active.value = a.copy(
            step = a.step + 1,
            result = LessonOutcome(
                stars = stars,
                accuracy = (a.session.accuracy * 100).toInt(),
                xpGained = after.xp - before.xp,
                mistakes = a.session.mistakes,
                unlocked = unlocked,
                bestBefore = best
            )
        )
    }

    fun quit() {
        _active.value = null
    }

    fun tasbihTap(): Int {
        val next = _tasbih.value + 1
        _tasbih.value = next
        val day = today()
        viewModelScope.launch(Dispatchers.IO) { store.saveTasbih(day, next) }
        return next
    }

    fun tasbihReset() {
        _tasbih.value = 0
        val day = today()
        viewModelScope.launch(Dispatchers.IO) { store.saveTasbih(day, 0) }
    }

    fun resetProgress() {
        _progress.value = LearnProgress()
        viewModelScope.launch(Dispatchers.IO) { store.reset() }
    }

    private fun persist(p: LearnProgress) {
        _progress.value = p
        viewModelScope.launch(Dispatchers.IO) { store.save(p) }
    }

    private fun explainOf(ex: Exercise): String? = when (ex) {
        is Exercise.Choice -> ex.explain
        is Exercise.Missing -> "${ex.word.arabic} — ${ex.word.translit}, «${ex.word.ru}»"
        is Exercise.Assemble -> "${ex.word.translit} — «${ex.word.ru}»"
        else -> null
    }
}
