package com.nur.prayer.learn

import kotlin.random.Random

/** What is shown on a prompt or an answer tile. */
sealed interface Face {
    /** Arabic text; [highlight] holds grapheme indices drawn in the accent, [hidden] ones left blank. */
    data class Ar(val text: String, val highlight: Set<Int> = emptySet(), val hidden: Set<Int> = emptySet()) : Face
    data class Tr(val text: String) : Face
    data class Txt(val text: String, val caption: String? = null) : Face
}

/** Concrete steps of a lesson. [cards] are the Leitner keys the answer is graded against. */
sealed interface Exercise {
    val cards: List<String>

    data class LetterIntro(val letter: Letter, val example: Word?) : Exercise {
        override val cards get() = listOf(LearnProgress.letterKey(letter))
    }
    data class WordIntro(val word: Word) : Exercise {
        override val cards get() = listOf(LearnProgress.wordKey(word))
    }
    /** A rule card: a title, an explanation and Arabic samples with their reading. */
    data class Info(val title: String, val body: String, val samples: List<Pair<String, String>>) : Exercise {
        override val cards get() = emptyList<String>()
    }
    data class Choice(
        val question: String,
        val prompt: Face,
        val options: List<Face>,
        val answer: Int,
        val explain: String? = null,
        override val cards: List<String> = emptyList()
    ) : Exercise
    /** The word drawn with one letter blank; pick the letter. */
    data class Missing(
        val word: Word, val index: Int, val shown: String, val options: List<Letter>, val answer: Int
    ) : Exercise {
        override val cards get() = listOf(LearnProgress.wordKey(word))
    }
    /** Tap graphemes in order; [tiles] includes the word's graphemes and a few decoys. */
    data class Assemble(val word: Word, val tiles: List<String>, val target: List<String>) : Exercise {
        override val cards get() = listOf(LearnProgress.wordKey(word))
    }
    /** Match left[i] with right[i]; the screen shuffles the right column. */
    data class Pairs(val left: List<Face>, val right: List<Face>, override val cards: List<String>) : Exercise

    val isIntro: Boolean get() = this is LetterIntro || this is WordIntro || this is Info
}

/**
 * Builds lessons. Deterministic for a given seed, so a lesson is reproducible in tests and a retry
 * with a new seed gets fresh questions. Invariants (checked by LearnCourseTest for every lesson):
 * each Choice has 2–4 options with distinct text and exactly one right answer; a Missing exercise's
 * decoys never spell another dictionary word; Assemble targets are a sub-multiset of the tiles.
 */
class ExerciseFactory(private val lexicon: Lexicon, private val quran: QuranShort?, seed: Int) {
    private val rnd = Random(seed)
    private val letters = Arabic.LETTERS
    private val plainWords: Set<String> = lexicon.words.map { it.plain }.toSet()

    fun build(plan: LessonPlan, course: Course? = null, progress: LearnProgress? = null, today: Long = 0): List<Exercise> = when (plan) {
        is LessonPlan.Letters -> lettersLesson(plan.fresh, plan.known)
        LessonPlan.AlphabetReview -> List(14) { letterQuestion(letters.random(rnd), letters) } + letterPairs(letters) + letterPairs(letters)
        LessonPlan.Joining -> joining()
        is LessonPlan.Forms -> forms(plan.form)
        LessonPlan.FindLetter -> findLetter()
        LessonPlan.ShortVowels -> shortVowels()
        LessonPlan.Sukun -> sukun()
        LessonPlan.LongVowels -> longVowels()
        LessonPlan.Shadda -> shadda()
        LessonPlan.Tanween -> tanween()
        is LessonPlan.Reading -> reading(plan.minLetters, plan.maxLetters)
        LessonPlan.SunMoon -> sunMoon()
        is LessonPlan.Vocabulary -> vocabulary(plan.words, lexicon.byTopic[plan.topic].orEmpty())
        is LessonPlan.MissingLetter -> List(10) { missing(plan.level) }.filterNotNull()
        LessonPlan.Assemble -> List(8) { assemble() }.filterNotNull()
        LessonPlan.TranslitToArabic -> List(10) { translitToArabic() }.filterNotNull()
        LessonPlan.Exam -> exam()
        is LessonPlan.Surah -> surah(plan.number)
        LessonPlan.Review -> review(progress ?: LearnProgress(), today)
        is LessonPlan.Checkpoint -> checkpoint(plan.stageIndex, course)
    }

    // ── helpers ──────────────────────────────────────────────────────────────────────────────

    private fun text(face: Face): String = when (face) {
        is Face.Ar -> face.text
        is Face.Tr -> face.text
        is Face.Txt -> face.text
    }

    /** Correct + distinct decoys (preferred ones first), shuffled; null when no decoy exists. */
    private fun choice(
        question: String, prompt: Face, correct: Face, preferred: List<Face>, fallback: List<Face>,
        explain: String? = null, cards: List<String> = emptyList(), size: Int = 4
    ): Exercise.Choice? {
        val seen = hashSetOf(text(correct))
        val decoys = ArrayList<Face>()
        for (f in preferred.shuffled(rnd) + fallback.shuffled(rnd)) {
            if (decoys.size == size - 1) break
            if (seen.add(text(f))) decoys += f
        }
        if (decoys.isEmpty()) return null
        val options = (decoys + correct).shuffled(rnd)
        return Exercise.Choice(question, prompt, options, options.indexOf(correct), explain, cards)
    }

    private fun nameFace(l: Letter) = Face.Txt(l.name, l.sound)

    private fun letterQuestion(l: Letter, pool: List<Letter>): Exercise {
        val near = Arabic.confusable(l)
        val key = listOf(LearnProgress.letterKey(l))
        return when (rnd.nextInt(3)) {
            0 -> choice("Как называется буква?", Face.Ar(l.char), nameFace(l),
                near.filter { it in pool }.map(::nameFace), pool.map(::nameFace), cards = key)
            1 -> choice("Найдите букву «${l.name}»", Face.Txt(l.name, l.sound), Face.Ar(l.char),
                near.map { Face.Ar(it.char) }, pool.map { Face.Ar(it.char) }, l.hint, key)
            else -> choice("Какой звук у этой буквы?", Face.Ar(l.char), Face.Tr(l.sound),
                near.map { Face.Tr(it.sound) }, pool.map { Face.Tr(it.sound) }, l.hint, key)
        } ?: Exercise.LetterIntro(l, exampleFor(l))
    }

    private fun letterPairs(pool: List<Letter>): Exercise.Pairs {
        val pick = pool.shuffled(rnd).distinctBy { it.name }.take(4)
        return Exercise.Pairs(pick.map { Face.Ar(it.char) }, pick.map { nameFace(it) }, pick.map(LearnProgress::letterKey))
    }

    /** A short word containing [l], preferably at the start, for the letter card. */
    fun exampleFor(l: Letter): Word? = lexicon.singleWords
        .filter { w -> w.letters.any { it == l } }
        .sortedWith(compareBy({ it.letters.firstOrNull() != l }, { it.letters.size }))
        .firstOrNull()

    private fun lettersLesson(fresh: List<Letter>, known: List<Letter>): List<Exercise> {
        val pool = (known + fresh).let { if (it.size >= 4) it else (it + letters).distinct() }
        val out = ArrayList<Exercise>()
        fresh.forEach { out += Exercise.LetterIntro(it, exampleFor(it)) }
        val drills = fresh.flatMap { l -> List(2) { letterQuestion(l, pool) } } +
            known.shuffled(rnd).take(2).map { letterQuestion(it, pool) }
        out += drills.shuffled(rnd)
        out += letterPairs(fresh + known.shuffled(rnd).take((4 - fresh.size).coerceAtLeast(0)))
        return out
    }

    private fun joining(): List<Exercise> {
        val info = Exercise.Info("Шесть букв не соединяются вперёд",
            "Почти все буквы тянутся к следующей. Но ا د ذ ر ز و соединяются только с предыдущей — " +
                "после них слово разрывается, и следующая буква начинается заново.",
            listOf("دَرَس" to "д + р + с: три отдельных кусочка", "كَتَبَ" to "к-т-б: одна связка"))
        val yes = Face.Txt("Соединяется")
        val no = Face.Txt("Не соединяется")
        val nonJoining = letters.filter { !it.joinsNext }
        val sample = (nonJoining + letters.filter { it.joinsNext }.shuffled(rnd).take(6)).shuffled(rnd)
        val questions = sample.map { l ->
            val options = listOf(yes, no)
            Exercise.Choice("Соединяется ли «${l.name}» со следующей буквой?", Face.Ar(l.char), options,
                if (l.joinsNext) 0 else 1, l.hint, listOf(LearnProgress.letterKey(l)))
        }
        return listOf(info) + questions
    }

    /** Words in which letter [l] (unfolded) stands in [form], with that grapheme's index. */
    private fun occurrences(form: LetterForm): List<Triple<Word, Int, Letter>> = lexicon.singleWords.flatMap { w ->
        val g = Arabic.graphemes(w.arabic)
        val f = Arabic.formsIn(w.arabic)
        g.indices.mapNotNull { i ->
            val l = Arabic.letter(g[i].substring(0, 1))
            if (l != null && f[i] == form) Triple(w, i, l) else null
        }
    }

    private fun forms(form: LetterForm): List<Exercise> {
        val demo = listOf("ب", "ج", "ع", "ه").mapNotNull(Arabic::letter)
        val info = Exercise.Info("${form.title.replaceFirstChar { it.uppercase() }} форма",
            "Буква пишется по-разному в зависимости от места в слове. Вот как выглядят буквы в форме «${form.title}»; " +
                "справа налево: отдельная → ${form.title}.",
            demo.map { "${it.char}   ${Arabic.shape(it, form)}" to it.name })
        val pool = occurrences(form).shuffled(rnd)
        val byWord = pool.distinctBy { it.first.id }.take(6)
        val highlighted = byWord.mapNotNull { (w, i, l) ->
            choice("Какая буква выделена?", Face.Ar(w.arabic, highlight = setOf(i)), Face.Ar(l.char),
                Arabic.confusable(l).map { Face.Ar(it.char) }, letters.map { Face.Ar(it.char) },
                "${w.arabic} — ${w.translit}, «${w.ru}»", listOf(LearnProgress.letterKey(l)))
        }
        val shapes = letters.filter { form != LetterForm.INITIAL || it.joinsNext }
            .shuffled(rnd).take(5).mapNotNull { l ->
                choice("Какая это буква?", Face.Ar(Arabic.shape(l, form)), Face.Ar(l.char),
                    Arabic.confusable(l).map { Face.Ar(it.char) }, letters.map { Face.Ar(it.char) },
                    cards = listOf(LearnProgress.letterKey(l)))
            }
        return listOf(info) + (highlighted + shapes).shuffled(rnd)
    }

    private fun findLetter(): List<Exercise> = letters.shuffled(rnd).take(10).mapNotNull { l ->
        val with = lexicon.singleWords.filter { w -> l in w.letters }
        val without = lexicon.singleWords.filter { w -> l !in w.letters }
        val word = with.randomOrNull(rnd) ?: return@mapNotNull null
        val near = Arabic.confusable(l)
        val tricky = without.filter { w -> w.letters.any { it in near } }
        choice("В каком слове есть буква «${l.name}» ${l.char}?", Face.Txt(l.name, l.sound),
            Face.Ar(word.arabic), tricky.map { Face.Ar(it.arabic) }, without.map { Face.Ar(it.arabic) },
            "${word.arabic} — ${word.translit}, «${word.ru}»",
            listOf(LearnProgress.letterKey(l)))
    }

    private val consonants get() = letters.filter { it.char != "ا" }

    private fun syllableChoice(question: String, ar: String, sound: String, decoys: List<Pair<String, String>>, explain: String?): Exercise? {
        return if (rnd.nextBoolean()) choice(question, Face.Ar(ar), Face.Tr(sound), decoys.map { Face.Tr(it.second) }, emptyList(), explain)
        else choice("Найдите «$sound»", Face.Tr(sound), Face.Ar(ar), decoys.map { Face.Ar(it.first) }, emptyList(), explain)
    }

    private fun shortVowels(): List<Exercise> {
        val info = Exercise.Info("Три короткие гласные",
            "Гласные пишутся значками над и под буквой. Фатха — «а», касра — «и», дамма — «у».",
            Arabic.VOWELS.map { v -> Arabic.syllable(Arabic.letter("ب")!!, v) to "${v.name}: б${v.sound}" })
        val qs = consonants.shuffled(rnd).take(12).mapNotNull { l ->
            val v = Arabic.VOWELS.random(rnd)
            val decoys = Arabic.VOWELS.filter { it != v }.map { Arabic.syllable(l, it) to Arabic.syllableSound(l, it) } +
                Arabic.confusable(l).filter { it.char != "ا" }.map { Arabic.syllable(it, v) to Arabic.syllableSound(it, v) }
            syllableChoice("Как читается слог?", Arabic.syllable(l, v), Arabic.syllableSound(l, v), decoys, v.explain)
        }
        return listOf(info) + qs
    }

    private fun closed(a: Letter, v: Mark, b: Letter) = (Arabic.syllable(a, v) + b.char + Arabic.SUKUN) to (Arabic.syllableSound(a, v) + b.sound)

    private fun sukun(): List<Exercise> {
        val b = Arabic.letter("ب")!!
        val info = Exercise.Info("Сукун закрывает слог", Arabic.SUKUN_MARK.explain,
            listOf(closed(b, Arabic.VOWELS[0], Arabic.letter("ل")!!), closed(Arabic.letter("م")!!, Arabic.VOWELS[2], Arabic.letter("ن")!!)))
        val qs = List(8) {
            val a = consonants.random(rnd); val c = consonants.random(rnd); val v = Arabic.VOWELS.random(rnd)
            val (ar, sound) = closed(a, v, c)
            val decoys = Arabic.VOWELS.filter { it != v }.map { closed(a, it, c) } +
                Arabic.confusable(c).filter { it.char != "ا" }.map { closed(a, v, it) } +
                listOf(Arabic.syllable(a, v) + c.char + v.char to Arabic.syllableSound(a, v) + Arabic.syllableSound(c, v))
            syllableChoice("Как читается?", ar, sound, decoys, Arabic.SUKUN_MARK.explain)
        }.filterNotNull()
        val words = lexicon.singleWords.filter { Arabic.SUKUN in it.arabic && it.letters.size <= 4 }.shuffled(rnd).take(4)
        return listOf(info) + qs + words.mapNotNull { readWord(it, lexicon.singleWords) }
    }

    private fun longVowels(): List<Exercise> {
        val b = Arabic.letter("ب")!!
        val info = Exercise.Info("Долгие гласные",
            "Буква ا после фатхи, ي после касры и و после даммы тянут гласную вдвое: «аа», «ии», «уу». " +
                "В транслите долгота — двойная буква.",
            Arabic.VOWELS.map { Arabic.longSyllable(b, it) })
        val qs = consonants.shuffled(rnd).take(10).mapNotNull { l ->
            val v = Arabic.VOWELS.random(rnd)
            val (ar, sound) = Arabic.longSyllable(l, v)
            val decoys = listOf(Arabic.syllable(l, v) to Arabic.syllableSound(l, v)) +
                Arabic.VOWELS.filter { it != v }.map { Arabic.longSyllable(l, it) } +
                Arabic.VOWELS.filter { it != v }.map { Arabic.syllable(l, it) to Arabic.syllableSound(l, it) }
            syllableChoice("Долгий или короткий?", ar, sound, decoys, "Долгота — буква-продлитель после огласовки.")
        }
        return listOf(info) + qs
    }

    private val doubled = Regex("([бвгджзйклмнпрстфхцчшһҳқғ])\\1")

    private fun shadda(): List<Exercise> {
        val info = Exercise.Info("Шадда удваивает согласный", Arabic.SHADDA_MARK.explain,
            listOf("رَبّ" to "рабб", "سُكَّر" to "суккар", "جَدَّة" to "джадда"))
        val words = lexicon.singleWords.filter { Arabic.SHADDA in it.arabic && !it.arabic.startsWith("ال") }.shuffled(rnd).take(10)
        val qs = words.mapNotNull { w ->
            val fake = doubled.find(w.translit)?.let { w.translit.replaceRange(it.range, it.groupValues[1]) }
            val near = listOfNotNull(fake).map { Face.Tr(it) }
            choice("Как читается слово?", Face.Ar(w.arabic), Face.Tr(w.translit), near,
                lexicon.singleWords.filter { it.letters.size == w.letters.size }.map { Face.Tr(it.translit) },
                "«${w.ru}»: шадда — двойной согласный.", listOf(LearnProgress.wordKey(w)))
        }
        return listOf(info) + qs
    }

    private fun tanween(): List<Exercise> {
        val b = Arabic.letter("ب")!!
        val info = Exercise.Info("Танвин — «-н» на конце", "Удвоенный значок гласной добавляет «н»: ан, ин, ун. Так пишется неопределённость: «какой-то».",
            Arabic.TANWEEN.map { Arabic.syllable(b, it) to Arabic.syllableSound(b, it) })
        val qs = consonants.shuffled(rnd).take(10).mapNotNull { l ->
            val t = Arabic.TANWEEN.random(rnd)
            val decoys = Arabic.TANWEEN.filter { it != t }.map { Arabic.syllable(l, it) to Arabic.syllableSound(l, it) } +
                Arabic.VOWELS.map { Arabic.syllable(l, it) to Arabic.syllableSound(l, it) }
            syllableChoice("Как читается?", Arabic.syllable(l, t), Arabic.syllableSound(l, t), decoys, t.explain)
        }
        return listOf(info) + qs
    }

    private fun readWord(w: Word, pool: List<Word>): Exercise? {
        val similar = pool.filter { it.id != w.id && kotlin.math.abs(it.letters.size - w.letters.size) <= 1 }
        return if (rnd.nextInt(3) < 2) choice("Прочитайте слово", Face.Ar(w.arabic), Face.Tr(w.translit),
            similar.map { Face.Tr(it.translit) }, pool.map { Face.Tr(it.translit) }, "«${w.ru}»", listOf(LearnProgress.wordKey(w)))
        else choice("Где написано «${w.translit}»?", Face.Tr(w.translit), Face.Ar(w.arabic),
            similar.map { Face.Ar(it.arabic) }, pool.map { Face.Ar(it.arabic) }, "«${w.ru}»", listOf(LearnProgress.wordKey(w)))
    }

    private fun reading(min: Int, max: Int): List<Exercise> {
        val pool = lexicon.singleWords.filter { it.letters.size in min..max && !it.arabic.startsWith("ال") }
        return pool.shuffled(rnd).take(12).mapNotNull { readWord(it, pool) }
    }

    /** "ال" + word: sun letters take a shadda and swallow the lam. Matches learn_data's article rule. */
    fun withArticle(w: Word): Pair<String, String>? {
        val g = Arabic.graphemes(w.arabic)
        val first = Arabic.letter(g.first().substring(0, 1)) ?: return null
        if (first.char == "ا" || first.char == "ل" || w.isPhrase || w.arabic.startsWith("ال")) return null
        if (!w.translit.startsWith(first.sound)) return null
        return if (first.sun) {
            val shaddaFirst = g.first().substring(0, 1) + Arabic.SHADDA + g.first().substring(1)
            ("ال" + shaddaFirst + g.drop(1).joinToString("")) to ("а" + first.sound + "-" + w.translit)
        } else ("ال" + Arabic.SUKUN + w.arabic) to ("аль-" + w.translit)
    }

    private fun sunMoon(): List<Exercise> {
        val info = Exercise.Info("Солнечные и лунные буквы",
            "Перед 14 «солнечными» буквами (т с̱ д з̱ р з с ш с̣ д̣ т̣ з̣ л н) лям артикля не читается, а буква удваивается: " +
                "аш-шамс. Перед «лунными» лям звучит: аль-қамар.",
            listOf("الشَّمْس" to "аш-шамс — солнце", "الْقَمَر" to "аль-қамар — луна"))
        val sun = Face.Txt("Солнечная", "лям сливается")
        val moon = Face.Txt("Лунная", "лям звучит")
        val candidates = lexicon.singleWords.mapNotNull { w -> withArticle(w)?.let { w to it } }.shuffled(rnd).take(12)
        val qs = candidates.mapIndexedNotNull { i, (w, form) ->
            val (ar, tr) = form
            val first = w.letters.first()
            if (i % 2 == 0) Exercise.Choice("Какая буква после артикля?", Face.Ar(ar, highlight = setOf(2)),
                listOf(sun, moon), if (first.sun) 0 else 1, "$tr — «${w.ru}»", listOf(LearnProgress.letterKey(first)))
            else {
                val wrong = if (first.sun) "аль-" + w.translit else "а" + first.sound + "-" + w.translit
                choice("Прочитайте с артиклем", Face.Ar(ar), Face.Tr(tr), listOf(Face.Tr(wrong)), emptyList(),
                    "«${w.ru}»", listOf(LearnProgress.wordKey(w)), size = 2)
            }
        }
        return listOf(info) + qs
    }

    private fun vocabulary(words: List<Word>, topicWords: List<Word>): List<Exercise> {
        val pool = topicWords.ifEmpty { lexicon.words }
        val out = ArrayList<Exercise>()
        words.forEach { out += Exercise.WordIntro(it) }
        val drills = words.flatMap { w ->
            val key = listOf(LearnProgress.wordKey(w))
            listOfNotNull(
                choice("Что значит это слово?", Face.Ar(w.arabic), Face.Txt(w.ru), pool.map { Face.Txt(it.ru) },
                    lexicon.words.map { Face.Txt(it.ru) }, w.translit, key),
                choice("Как будет «${w.ru}»?", Face.Txt(w.ru), Face.Ar(w.arabic), pool.map { Face.Ar(it.arabic) },
                    lexicon.words.map { Face.Ar(it.arabic) }, w.translit, key)
            )
        }.shuffled(rnd)
        out += drills
        words.shuffled(rnd).chunked(4).filter { it.size >= 3 }.take(2).forEach { part ->
            val unique = part.distinctBy { it.ru }
            out += Exercise.Pairs(unique.map { Face.Ar(it.arabic) }, unique.map { Face.Txt(it.ru) }, unique.map(LearnProgress::wordKey))
        }
        return out
    }

    /** Replaces grapheme [index]'s base letter with [with], keeping its vowel marks. */
    private fun swapLetter(word: String, index: Int, with: Letter): String {
        val g = Arabic.graphemes(word).toMutableList()
        g[index] = with.char + g[index].substring(1)
        return g.joinToString("")
    }

    fun missing(level: Int): Exercise.Missing? {
        repeat(20) {
            val w = lexicon.singleWords.filter { it.letters.size >= (if (level >= 3) 4 else 3) }.randomOrNull(rnd) ?: return null
            val g = Arabic.graphemes(w.arabic)
            val slots = g.indices.filter { Arabic.letter(g[it].substring(0, 1)) != null && g[it][0] != 'ا' }
            val index = slots.randomOrNull(rnd) ?: return@repeat
            val target = Arabic.letter(g[index].substring(0, 1))!!
            val ordered = if (level == 1) letters.shuffled(rnd) else Arabic.confusable(target) + letters.shuffled(rnd)
            val decoys = ordered.filter { it != target && it.char != "ا" }.filter { d ->
                Arabic.stripMarks(swapLetter(w.arabic, index, d)) !in plainWords
            }.distinct().take(3)
            if (decoys.size < 3) return@repeat
            val options = (decoys + target).shuffled(rnd)
            val shown = if (level >= 3) Arabic.stripMarks(w.arabic) else w.arabic
            return Exercise.Missing(w, index, shown, options, options.indexOf(target))
        }
        return null
    }

    fun assemble(): Exercise.Assemble? {
        val w = lexicon.singleWords.filter { it.letters.size in 3..6 }.randomOrNull(rnd) ?: return null
        val target = Arabic.graphemes(w.arabic)
        val decoys = target.mapNotNull { g -> Arabic.letter(g.substring(0, 1))?.let { l -> Arabic.confusable(l).firstOrNull()?.let { it.char + g.substring(1) } } }
            .filter { it !in target }.distinct().shuffled(rnd).take(2)
        return Exercise.Assemble(w, (target + decoys).shuffled(rnd), target)
    }

    private fun translitToArabic(): Exercise? {
        val w = lexicon.singleWords.filter { it.letters.size >= 3 }.randomOrNull(rnd) ?: return null
        val g = Arabic.graphemes(w.arabic)
        val fakes = g.indices.shuffled(rnd).mapNotNull { i ->
            val l = Arabic.letter(g[i].substring(0, 1)) ?: return@mapNotNull null
            val d = Arabic.confusable(l).firstOrNull { it.char != "ا" } ?: return@mapNotNull null
            swapLetter(w.arabic, i, d).takeIf { Arabic.stripMarks(it) !in plainWords }
        }.take(3)
        return choice("Как пишется «${w.translit}»?", Face.Tr(w.translit), Face.Ar(w.arabic), fakes.map { Face.Ar(it) },
            lexicon.singleWords.filter { it.letters.size == w.letters.size }.map { Face.Ar(it.arabic) },
            "«${w.ru}»", listOf(LearnProgress.wordKey(w)))
    }

    private fun exam(): List<Exercise> {
        val parts = listOfNotNull(
            letterQuestion(letters.random(rnd), letters), letterQuestion(letters.random(rnd), letters),
            missing(2), missing(3), assemble(), translitToArabic(), translitToArabic()
        ) + reading(3, 6).take(4) + vocabulary(lexicon.singleWords.shuffled(rnd).take(3), lexicon.singleWords).filter { !it.isIntro }.take(4)
        return parts.shuffled(rnd)
    }

    private fun surah(number: Int): List<Exercise> {
        val q = quran ?: return emptyList()
        val ayat = q.ayat(number)
        val others = q.ayat.filter { it.surah != number }
        val out = ArrayList<Exercise>()
        ayat.forEach { a ->
            choice("Что означает аят ${a.number}?", Face.Ar(a.arabic), Face.Txt(a.ru), ayat.filter { it != a }.map { Face.Txt(it.ru) },
                others.map { Face.Txt(it.ru) }, a.translit)?.let { out += it }
            val words = a.arabic.split(' ')
            if (words.size >= 2) {
                val k = rnd.nextInt(words.size)
                val shown = words.mapIndexed { i, s -> if (i == k) "…" else s }.joinToString(" ")
                val pool = q.ayat.flatMap { it.arabic.split(' ') }.distinct()
                choice("Какое слово пропущено?", Face.Ar(shown), Face.Ar(words[k]), emptyList(), pool.map { Face.Ar(it) }, a.translit)?.let { out += it }
            }
        }
        return out
    }

    private fun review(progress: LearnProgress, today: Long): List<Exercise> = progress.due(today).take(15).mapNotNull { key ->
        when {
            key.startsWith(LearnProgress.LETTER) -> Arabic.letter(key.removePrefix(LearnProgress.LETTER))?.let { letterQuestion(it, letters) }
            key.startsWith(LearnProgress.WORD) -> lexicon.byId[key.removePrefix(LearnProgress.WORD)]?.let { w ->
                val pool = lexicon.byTopic[w.topic].orEmpty()
                if (rnd.nextBoolean()) choice("Что значит это слово?", Face.Ar(w.arabic), Face.Txt(w.ru), pool.map { Face.Txt(it.ru) },
                    lexicon.words.map { Face.Txt(it.ru) }, w.translit, listOf(key))
                else choice("Как будет «${w.ru}»?", Face.Txt(w.ru), Face.Ar(w.arabic), pool.map { Face.Ar(it.arabic) },
                    lexicon.words.map { Face.Ar(it.arabic) }, w.translit, listOf(key))
            }
            else -> null
        }
    }

    private fun checkpoint(stageIndex: Int, course: Course?): List<Exercise> {
        val stages = course?.stages?.take(stageIndex) ?: return emptyList()
        val plans = stages.flatMap { s -> s.lessons.map { it.plan } }.filter { it !is LessonPlan.Checkpoint }
        return plans.shuffled(rnd).take(8).flatMap { p -> build(p, course).filter { !it.isIntro }.shuffled(rnd).take(2) }.take(16)
    }
}
