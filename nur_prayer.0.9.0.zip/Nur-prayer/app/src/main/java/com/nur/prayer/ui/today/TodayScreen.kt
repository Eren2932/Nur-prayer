package com.nur.prayer.ui.today

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.learn.Course
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.learn.LearnProgress
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.HGap
import com.nur.prayer.ui.learn.LessonBar
import com.nur.prayer.ui.learn.Tag
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/** Tasbih after prayer: 33 · 33 · 34, one hundred in all. */
internal object TasbihMath {
    const val TOTAL = 100
    private val PHASES = listOf(
        Triple("سُبْحَانَ اللَّهِ", "Субхана-ллах", 33),
        Triple("الْحَمْدُ لِلَّهِ", "Аль-хамду ли-ллях", 33),
        Triple("اللَّهُ أَكْبَرُ", "Аллаху акбар", 34)
    )

    /** Phase index, its words and the count inside it; past 100 it stays on the finished last phase. */
    fun phase(count: Int): Pair<Int, Int> {
        var left = count.coerceIn(0, TOTAL)
        PHASES.forEachIndexed { i, p ->
            if (left < p.third || i == PHASES.lastIndex) return i to left.coerceAtMost(p.third)
            left -= p.third
        }
        return PHASES.lastIndex to PHASES.last().third
    }

    fun arabic(i: Int) = PHASES[i].first
    fun reading(i: Int) = PHASES[i].second
    fun size(i: Int) = PHASES[i].third
}

/**
 * The layer pulled up from home. It shares one [Reveal] with home: the same number that the pull
 * gesture drives places this layer, and a drag down on its header drives it back, so the layer
 * can be closed by the same gesture that opened it.
 */
@Composable
fun TodayScreen(
    hijri: String,
    content: LearnContent?,
    progress: LearnProgress,
    today: Long,
    tasbih: Int,
    palette: PhasePalette,
    reveal: Reveal,
    onClose: () -> Unit,
    onContinueLesson: () -> Unit,
    onOpenCourse: () -> Unit,
    onOpenReview: () -> Unit,
    onOpenDictionary: () -> Unit,
    onOpenSurah: () -> Unit,
    onOpenSchedule: () -> Unit,
    onTasbih: () -> Unit,
    onTasbihReset: () -> Unit
) {
    val ui = uiScale()
    val accent = palette.accent
    val haptic = LocalHapticFeedback.current
    val pullDown = rememberDraggableState { delta -> reveal.drag(-delta) }
    Column(Modifier.fillMaxSize().onSizeChanged { reveal.extentPx = it.height.toFloat() }) {
        Column(
            Modifier.fillMaxWidth().draggable(
                state = pullDown,
                orientation = Orientation.Vertical,
                onDragStarted = { reveal.grab() },
                onDragStopped = { v ->
                    if (reveal.release(-v, RevealMath.SHEET_KEEP_AT)) reveal.settle(true) else onClose()
                }
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.padding(top = 8.dp).width(40.dp).height(5.dp).clip(RoundedCornerShape(50)).background(SurfaceEdge))
            Row(Modifier.fillMaxWidth().padding(horizontal = ui.s(16f), vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Сегодня", color = TextPrimary, fontSize = ui.t(28f), fontWeight = FontWeight.Bold)
                    Text(hijri, color = TextSecondary, fontSize = ui.t(13f))
                }
                RoundIconButton(GlyphKind.CLOSE, "Закрыть", onClose)
            }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = ui.s(16f)).padding(bottom = LocalDockInset.current),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LearnCard(content, progress, today, accent, onContinueLesson, onOpenCourse)
            content?.let { c ->
                val w = c.lexicon.wordOfDay(today)
                GlassCard(Modifier.clip(RoundedCornerShape(24.dp)).clickable(onClick = onOpenDictionary)) {
                    Row(Modifier.fillMaxWidth().padding(ui.s(16f)), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("СЛОВО ДНЯ", color = accent, fontSize = ui.t(11f), fontWeight = FontWeight.Bold)
                            Text(w.ru, color = TextPrimary, fontSize = ui.t(20f), fontWeight = FontWeight.Bold)
                            Text(w.translit, color = TextTertiary, fontSize = ui.t(14f))
                        }
                        ArabicText(w.arabic, 36f, align = TextAlign.End)
                    }
                }
            }
            Text("ДЕЛА ДНЯ", color = TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 4.dp, top = 6.dp))
            val due = progress.due(today).size
            GlassCard {
                TaskRow("Аль-Фатиха", "читать по аятам, со смыслом", "الفاتحة", onOpenSurah)
                TaskRow("Повторение", if (due > 0) "$due карточек ждут" else "на сегодня всё повторено",
                    if (due > 0) "$due" else "✓", onOpenReview, done = due == 0)
                TaskRow("Словарь", "${content?.lexicon?.words?.size ?: 0} слов и фраз", "ق", onOpenDictionary)
                TaskRow("Календарь намазов", "месяц, время, хиджра", "▦", onOpenSchedule)
            }
            TasbihCard(tasbih, accent, onTap = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onTasbih() }, onReset = onTasbihReset)
        }
    }
}

@Composable
private fun LearnCard(
    content: LearnContent?, progress: LearnProgress, today: Long, accent: Color,
    onContinue: () -> Unit, onCourse: () -> Unit
) {
    val ui = uiScale()
    GlassCard(color = accent.copy(alpha = 0.22f)) {
        Column(Modifier.padding(ui.s(18f))) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ОБУЧЕНИЕ · АРАБСКИЙ", color = TextPrimary, fontSize = ui.t(12f), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Tag("🔥 ${progress.streakOn(today)}")
            }
            Gap(8f)
            val course = content?.course
            if (course == null) {
                Text("Готовим уроки…", color = TextSecondary, fontSize = ui.t(14f))
                return@Column
            }
            val next = course.next(progress)
            val done = course.completedCount(progress)
            Text(next?.title ?: "Курс пройден", color = TextPrimary, fontSize = ui.t(22f), fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(next?.let { course.stages[course.stageIndex(it.id)].title + " · " + it.subtitle } ?: "повторяйте карточки",
                color = TextSecondary, fontSize = ui.t(14f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Gap(10f)
            LessonBar(done.toFloat() / course.lessons.size.coerceAtLeast(1), accent)
            Gap(4f)
            Text("$done из ${course.lessons.size} уроков · ${progress.learnedWords()} слов · ${progress.learnedLetters()} из 28 букв",
                color = TextTertiary, fontSize = ui.t(12f))
            Gap(12f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (next != null) NurButton(if (done == 0) "Начать" else "Продолжить", accent, onContinue, Modifier.weight(1f), primary = true)
                NurButton("Весь курс", accent, onCourse, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun TaskRow(title: String, subtitle: String, badge: String, onClick: () -> Unit, done: Boolean = false) {
    val ui = uiScale()
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = ui.s(16f), vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(if (done) Mint.copy(alpha = 0.22f) else SurfaceInset), contentAlignment = Alignment.Center) {
            Text(badge, color = if (done) Mint else TextPrimary, fontSize = ui.t(if (badge.length > 3) 12f else 18f), fontWeight = FontWeight.Bold, maxLines = 1)
        }
        HGap(12f)
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = TextTertiary, fontSize = ui.t(13f))
        }
        Text("›", color = TextTertiary, fontSize = ui.t(22f))
    }
}

@Composable
private fun TasbihCard(count: Int, accent: Color, onTap: () -> Unit, onReset: () -> Unit) {
    val ui = uiScale()
    val (phase, inPhase) = TasbihMath.phase(count)
    val finished = count >= TasbihMath.TOTAL
    GlassCard {
        Column(Modifier.fillMaxWidth().padding(ui.s(16f)), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("ТАСБИХ ПОСЛЕ НАМАЗА", color = TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text("сбросить", color = TextTertiary, fontSize = ui.t(12f), modifier = Modifier.clickable(onClick = onReset).padding(4.dp))
            }
            Gap(6f)
            ArabicText(TasbihMath.arabic(phase), 30f)
            Text(TasbihMath.reading(phase), color = TextSecondary, fontSize = ui.t(14f))
            Gap(10f)
            Box(
                Modifier.size(132.dp).clip(CircleShape).background(if (finished) Mint.copy(alpha = 0.25f) else accent.copy(alpha = 0.25f))
                    .clickable(enabled = !finished, onClick = onTap),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (finished) "✓" else "$inPhase", color = TextPrimary, fontSize = ui.t(40f), fontWeight = FontWeight.Bold)
                    Text(if (finished) "100 из 100" else "из ${TasbihMath.size(phase)}", color = TextSecondary, fontSize = ui.t(12f))
                }
            }
            Gap(8f)
            Text("Всего за день: $count", color = TextTertiary, fontSize = ui.t(12f))
        }
    }
}

/** The lesson the "continue" button of the today layer opens. */
internal fun continueId(course: Course?, progress: LearnProgress): String? = course?.next(progress)?.id
