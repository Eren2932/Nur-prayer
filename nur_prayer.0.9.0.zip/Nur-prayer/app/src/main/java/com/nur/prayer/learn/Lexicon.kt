package com.nur.prayer.learn

/** A vocabulary topic: one lesson block in the course, one filter chip in the dictionary. */
data class Topic(val id: String, val title: String, val subtitle: String)

/**
 * One dictionary entry. [arabic] is fully vowelled; [translit] is derived from it by
 * tools/learn_data.py and checked in CI, never typed by hand.
 */
data class Word(val id: String, val topic: String, val arabic: String, val translit: String, val ru: String) {
    val letters: List<Letter> by lazy { Arabic.lettersOf(arabic) }
    val plain: String by lazy { Arabic.stripMarks(arabic) }
    val isPhrase: Boolean get() = ' ' in arabic
}

class Lexicon(val words: List<Word>) {
    val byId: Map<String, Word> = words.associateBy { it.id }
    val byTopic: Map<String, List<Word>> = words.groupBy { it.topic }

    fun topic(id: String): Topic? = TOPICS.firstOrNull { it.id == id }

    /** Words (not phrases) a reader can use to practise single letters. */
    val singleWords: List<Word> by lazy { words.filter { !it.isPhrase && it.topic != FATIHA } }

    /**
     * Search by Russian meaning, transliteration or Arabic (with or without vowels). Diacritics of the
     * transliteration are ignored, so "сабах" finds "с̣абааҳ".
     */
    fun search(query: String, topic: String? = null): List<Word> {
        val pool = if (topic == null) words else byTopic[topic].orEmpty()
        val q = query.trim().lowercase()
        if (q.isEmpty()) return pool
        val qArabic = Arabic.stripMarks(q)
        val qLatin = simplify(q)
        val scored = pool.mapNotNull { w ->
            val ru = w.ru.lowercase()
            val tr = simplify(w.translit.lowercase())
            val score = when {
                ru == q || w.plain == qArabic || tr == qLatin -> 0
                ru.startsWith(q) || w.plain.startsWith(qArabic) || tr.startsWith(qLatin) -> 1
                q in ru || qArabic in w.plain || qLatin in tr -> 2
                else -> return@mapNotNull null
            }
            score to w
        }
        return scored.sortedBy { it.first }.map { it.second }
    }

    /** Same word for everyone on the same day, cycling through the whole dictionary. */
    fun wordOfDay(epochDay: Long): Word {
        val pool = singleWords.ifEmpty { words }
        // A multiplicative step co-prime with the size visits every word once per cycle.
        val step = 7919L
        val index = Math.floorMod(epochDay * step, pool.size.toLong()).toInt()
        return pool[index]
    }

    companion object {
        const val FATIHA = "fatiha"

        val TOPICS: List<Topic> = listOf(
            Topic("family", "Семья", "родные и близкие"),
            Topic("body", "Тело", "части тела"),
            Topic("home", "Дом", "комнаты и вещи"),
            Topic("food", "Еда", "продукты и напитки"),
            Topic("nature", "Природа", "небо, земля, вода"),
            Topic("animals", "Животные", "звери и птицы"),
            Topic("colors", "Цвета", "палитра"),
            Topic("numbers", "Числа", "от нуля до тысячи"),
            Topic("time", "Время", "дни, части суток"),
            Topic("city", "Город", "места и транспорт"),
            Topic("school", "Учёба", "книга, урок, слово"),
            Topic("islam", "Ислам", "основные понятия"),
            Topic("verbs", "Глаголы", "прошедшее время"),
            Topic("adjectives", "Описания", "какой предмет"),
            Topic("people", "Люди", "профессии"),
            Topic("pronouns", "Местоимения", "я, ты, где, когда"),
            Topic("phrases", "Фразы", "приветствия и зикр"),
            Topic("fatiha", "Аль-Фатиха", "сура по словам")
        )

        /** Parses assets/learn/words.tsv (id, topic, arabic, translit, ru). Malformed rows are skipped. */
        fun parse(tsv: String): Lexicon {
            val known = TOPICS.map { it.id }.toSet()
            val words = tsv.lineSequence().drop(1).mapNotNull { line ->
                val c = line.split('\t')
                if (c.size != 5 || c.any { it.isBlank() } || c[1] !in known) null
                else Word(c[0], c[1], c[2], c[3], c[4])
            }.toList()
            return Lexicon(words)
        }

        private val LATIN_MARKS = Regex("[\u0300-\u036F‘’'\\-]")

        /** Transliteration without dots, macrons and apostrophes; long vowels count as short. */
        fun simplify(s: String): String = LATIN_MARKS.replace(s, "")
            .replace('ҳ', 'х').replace('һ', 'х').replace('қ', 'к').replace('ғ', 'г')
            .replace("аа", "а").replace("ии", "и").replace("уу", "у")
    }
}
