package com.nur.prayer.learn

import android.content.Context

/**
 * Learning progress on disk. One string in its own SharedPreferences file, written with apply():
 * the format is LearnProgress.encode(), lenient on read, so a damaged line costs one card, never
 * the whole history. Kept apart from the DataStore of the prayer settings on purpose: a lesson
 * writes after every answer and must never wake the prayer-time pipeline that observes settings.
 */
class LearnStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun load(): LearnProgress = LearnProgress.decode(prefs.getString(KEY_PROGRESS, null))

    fun save(progress: LearnProgress) {
        prefs.edit().putString(KEY_PROGRESS, progress.encode()).apply()
    }

    /** Tasbih of the day: the count resets itself when the stored day is not today. */
    fun tasbih(today: Long): Int =
        if (prefs.getLong(KEY_TASBIH_DAY, Long.MIN_VALUE) == today) prefs.getInt(KEY_TASBIH_COUNT, 0) else 0

    fun saveTasbih(today: Long, count: Int) {
        prefs.edit().putLong(KEY_TASBIH_DAY, today).putInt(KEY_TASBIH_COUNT, count).apply()
    }

    fun reset() {
        prefs.edit().remove(KEY_PROGRESS).apply()
    }

    private companion object {
        const val FILE = "nur_learn"
        const val KEY_PROGRESS = "progress"
        const val KEY_TASBIH_DAY = "tasbih_day"
        const val KEY_TASBIH_COUNT = "tasbih_count"
    }
}

/** Bundled course data, parsed once. Pure loader so the JVM tests read the same files the app does. */
class LearnContent(val lexicon: Lexicon, val quran: QuranShort, val course: Course) {
    companion object {
        const val WORDS_ASSET = "learn/words.tsv"
        const val QURAN_ASSET = "learn/quran_short.tsv"

        fun parse(wordsTsv: String, quranTsv: String): LearnContent {
            val lexicon = Lexicon.parse(wordsTsv)
            return LearnContent(lexicon, QuranShort.parse(quranTsv), Course.build(lexicon))
        }

        fun fromAssets(context: Context): LearnContent {
            val assets = context.applicationContext.assets
            val words = assets.open(WORDS_ASSET).bufferedReader().use { it.readText() }
            val quran = assets.open(QURAN_ASSET).bufferedReader().use { it.readText() }
            return parse(words, quran)
        }
    }
}
