package com.nur.prayer.data

import android.content.Context
import com.nur.prayer.core.astro.Coordinates
import org.json.JSONArray
import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.cos

/**
 * Offline city database, loaded once from assets. No network, no API keys, works in the metro.
 */
class CityRepository(private val context: Context) {

    private val all: List<City> by lazy { load() }

    /**
     * Search keys, normalised once.
     *
     * The old implementation ran [Normalizer] over every city name and region on every keystroke,
     * allocated a pair per city, then sorted the whole list. That is one normalisation per city plus a
     * full sort per typed character, on the composition thread — the reason the city list shivered
     * while typing. Now folding happens once, at load, and a keystroke is a plain scan over
     * pre-folded strings with a bounded insertion instead of a sort.
     */
    private class Key(val city: City, val name: String, val region: String)

    private val keys: List<Key> by lazy {
        all.map { Key(it, fold(it.name), fold(it.region)) }
    }

    private fun load(): List<City> {
        val json = context.assets.open("cities_ru.json").bufferedReader().use { it.readText() }
        val array = JSONArray(json)
        val result = ArrayList<City>(array.length())
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            result.add(
                City(
                    id = o.getInt("id"),
                    name = o.getString("name"),
                    region = o.getString("region"),
                    latitude = o.getDouble("lat"),
                    longitude = o.getDouble("lon"),
                    timeZoneId = o.getString("tz")
                )
            )
        }
        return result
    }

    fun cities(): List<City> = all

    fun byId(id: Int): City? = all.firstOrNull { it.id == id }

    /**
     * [limit] caps the *matches* of a real query, never the idle list.
     *
     * The old default was `take(60)` on a blank query, and that was a data bug wearing the costume
     * of a performance optimisation: the picker said "В базе 60 городов" while the asset held far
     * more, so every city after the sixtieth existed but could not be reached by scrolling — the
     * user had to already know the name to type it. The list is a `LazyColumn`; handing it the
     * whole database costs nothing, because only the visible rows are ever composed.
     */
    fun search(query: String, limit: Int = 200): List<City> {
        val q = fold(query)
        if (q.isBlank()) return all
        // Bucket by score instead of sorting: five buckets, one pass, no comparator, no boxing.
        val buckets = Array(6) { ArrayList<City>(8) }
        var found = 0
        for (key in keys) {
            val score = score(key, q)
            if (score == 0) continue
            buckets[score].add(key.city)
            found++
        }
        if (found == 0) return emptyList()
        val result = ArrayList<City>(minOf(found, limit))
        for (bucket in 5 downTo 1) {
            for (city in buckets[bucket]) {
                if (result.size == limit) return result
                result.add(city)
            }
        }
        return result
    }

    private fun score(key: Key, q: String): Int = when {
        key.name == q -> 5
        key.name.startsWith(q) -> 4
        key.name.contains(q) -> 3
        key.region.startsWith(q) -> 2
        key.region.contains(q) -> 1
        else -> 0
    }

    /** Case/diacritic insensitive, treats "ё" as "е" so that "елец"/"ёлец" both match. */
    private fun fold(value: String): String =
        Normalizer.normalize(value.trim().lowercase(), Normalizer.Form.NFC)
            .replace('ё', 'е')
            .replace('-', ' ')

    /** Nearest known city to a GPS fix, used to resolve the time zone of a raw location. */
    fun nearest(coordinates: Coordinates): City = all.minByOrNull { city ->
        val dLat = abs(city.latitude - coordinates.latitude)
        val dLon = abs(city.longitude - coordinates.longitude) *
            cos(Math.toRadians((city.latitude + coordinates.latitude) / 2))
        dLat * dLat + dLon * dLon
    } ?: City.MOSCOW
}
