package com.nur.prayer.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import com.nur.prayer.data.City
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.PanelLevel
import com.nur.prayer.ui.components.nurPanel
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/**
 * The city list.
 *
 * ### Why it used to stutter
 *
 * Three separate reasons, all of them per-row work that had no business being per-row:
 *
 * 1. **A time-zone lookup inside the row.** Every visible row called `ZoneId.of(...)`, `Instant.now()`
 *    and `rules.getOffset(...)` *on every recomposition*. During a fling that is a dozen rows a frame
 *    doing a map lookup, an allocation and a rules query on the main thread. The answer changes twice
 *    a year. It is memoised now — see [utcLabel].
 * 2. **The rows were not skippable.** Everything was inlined into the `items` lambda, so Compose had
 *    no separate function it was allowed to skip; combined with `City` being an unstable type (now
 *    `@Immutable`), any recomposition of the screen re-ran every visible row.
 * 3. **The result list was rebuilt more often than the query changed.** `remember(query)` re-ran on
 *    trailing spaces and IME composition events too; it is a `derivedStateOf` over the trimmed query
 *    now, so an edit that does not change the *search* does not touch the list.
 */
@Composable
fun CityPickerScreen(
    palette: PhasePalette,
    selectedCityId: Int,
    search: (String) -> List<City>,
    onPick: (City) -> Unit,
    onBack: () -> Unit,
    onUseLocation: () -> Unit,
    locating: Boolean,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    var query by remember { mutableStateOf("") }
    // `rememberUpdatedState` so the derived state is created exactly once and still calls the current
    // lambda. Keying `remember` on the lambda instead would rebuild everything whenever the caller
    // happens to allocate a new one.
    val searchFn by rememberUpdatedState(search)
    val results by remember { derivedStateOf { searchFn(query.trim()) } }

    Column(modifier = modifier.fillMaxWidth().padding(horizontal = ui.s(20f))) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(ui.s(38f))
                    .nurPanel(RoundedCornerShape(ui.s(13f)), PanelLevel.FLAT)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onBack() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.ArrowBack,
                    "Назад",
                    tint = TextPrimary,
                    modifier = Modifier.size(ui.s(17f))
                )
            }
            Spacer(Modifier.width(ui.s(12f)))
            Column(modifier = Modifier.weight(1f)) {
                AutoSizeText(
                    text = "Город",
                    color = TextPrimary,
                    fontSize = ui.t(22f),
                    minFontSize = ui.t(16f),
                    fontWeight = FontWeight.SemiBold
                )
                AutoSizeText(
                    text = if (query.isEmpty()) "В базе ${results.size} городов"
                    else "${results.size} совпадений",
                    color = TextTertiary,
                    fontSize = ui.t(11f),
                    minFontSize = ui.t(9f)
                )
            }
        }

        Spacer(Modifier.height(ui.s(12f)))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .nurPanel(RoundedCornerShape(ui.s(15f)), PanelLevel.INSET)
                .padding(horizontal = ui.s(13f), vertical = ui.s(12f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Filled.Search,
                null,
                tint = TextTertiary,
                modifier = Modifier.size(ui.s(17f))
            )
            Spacer(Modifier.width(ui.s(10f)))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    AutoSizeText(
                        text = "Название города",
                        color = TextTertiary,
                        fontSize = ui.t(15f),
                        minFontSize = ui.t(12f)
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    textStyle = TextStyle(color = TextPrimary, fontSize = ui.t(15f)),
                    cursorBrush = SolidColor(palette.accent),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (query.isNotEmpty()) {
                Spacer(Modifier.width(ui.s(8f)))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(ui.s(10f)))
                        .background(Color.White.copy(alpha = 0.08f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { query = "" }
                        .padding(horizontal = ui.s(9f), vertical = ui.s(4f))
                ) {
                    AutoSizeText(
                        text = "стереть",
                        color = TextSecondary,
                        fontSize = ui.t(10.5f),
                        minFontSize = ui.t(9f)
                    )
                }
            }
        }

        Spacer(Modifier.height(ui.s(10f)))

        NurButton(
            text = if (locating) "Определяем координаты…" else "Определить по геолокации",
            accent = palette.accent,
            onClick = onUseLocation,
            enabled = !locating
        )

        Spacer(Modifier.height(ui.s(10f)))

        if (results.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = ui.s(28f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Ничего не нашли. Поиск не различает «е» и «ё», дефисы можно не ставить: " +
                        "попробуйте «улан удэ» или «наб челны».",
                    color = TextTertiary,
                    fontSize = ui.t(12.5f),
                    lineHeight = ui.t(18f)
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
            contentPadding = PaddingValues(bottom = ui.s(24f)),
            verticalArrangement = Arrangement.spacedBy(ui.s(4f))
        ) {
            // A stable key keeps row instances alive across a query change, and `contentType` lets
            // Compose reuse the node layout instead of rebuilding it.
            items(results, key = { it.id }, contentType = { "city" }) { city ->
                CityRow(
                    city = city,
                    selected = city.id == selectedCityId,
                    accent = palette.accent,
                    onPick = onPick
                )
            }
        }
    }
}

/**
 * One row, extracted so that Compose has something it is allowed to skip.
 *
 * All four parameters are stable ([City] is `@Immutable`, `onPick` is a captured lambda that does not
 * change identity), so scrolling and typing no longer re-run rows whose data has not moved.
 */
@Composable
private fun CityRow(
    city: City,
    selected: Boolean,
    accent: Color,
    onPick: (City) -> Unit
) {
    val ui = uiScale()
    val shape = RoundedCornerShape(ui.s(15f))
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .nurPanel(shape, PanelLevel.FLAT, if (selected) accent else null)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onPick(city) }
            .padding(horizontal = ui.s(13f), vertical = ui.s(11f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(ui.s(6f))
                .clip(CircleShape)
                .background(if (selected) accent else Color.White.copy(alpha = 0.14f))
        )
        Spacer(Modifier.width(ui.s(11f)))
        Column(Modifier.weight(1f)) {
            // Only the name can be long enough to need shrinking ("Петропавловск-Камчатский"), and
            // it is the one line worth the extra measuring pass. The region and the offset are
            // plain single-line text: with three hundred cities in the list, a shrink-to-fit search
            // on every row is measurable work during a fling and buys nothing here.
            AutoSizeText(
                text = city.name,
                color = TextPrimary,
                fontSize = ui.t(15f),
                minFontSize = ui.t(12f),
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = city.region,
                color = TextTertiary,
                fontSize = ui.t(11f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(ui.s(10f)))
        Text(
            text = utcLabel(city.timeZoneId),
            color = TextSecondary,
            fontSize = ui.t(11f),
            maxLines = 1,
            fontFamily = FontFamily.Monospace
        )
    }
}

/**
 * "Europe/Moscow" told the user nothing. The UTC offset does: it is the number that has to match their
 * phone clock, and it is how people here actually name a zone ("МСК+2").
 *
 * Computed once per zone and kept. There is a handful of distinct offsets across the whole database, the value
 * changes twice a year at most, and the previous code recomputed it per row per frame.
 */
private val utcLabels = HashMap<String, String>(24)

private fun utcLabel(zoneId: String): String = utcLabels.getOrPut(zoneId) {
    runCatching {
        val hours = java.time.ZoneId.of(zoneId)
            .rules
            .getOffset(java.time.Instant.now())
            .totalSeconds / 3600
        if (hours >= 0) "UTC+$hours" else "UTC$hours"
    }.getOrDefault("UTC?")
}
