package com.nur.prayer.ui.settings

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.font.FontWeight
import com.nur.prayer.core.astro.Calibration
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.RegionalProfiles
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.core.astro.TimeSource
import com.nur.prayer.notify.AzanSound
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Caption
import com.nur.prayer.ui.components.ChoiceRow
import com.nur.prayer.ui.components.FactRow
import com.nur.prayer.ui.components.GlassPanel
import com.nur.prayer.ui.components.HairRule
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.PanelLevel
import com.nur.prayer.ui.components.SectionLabel
import com.nur.prayer.ui.components.SegmentedControl
import com.nur.prayer.ui.components.StepperField
import com.nur.prayer.ui.components.SwitchRow
import com.nur.prayer.ui.components.nurPanel
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/**
 * Settings.
 *
 * ### The layout
 *
 * Every group is one row that *states its own answer* ("Метод расчёта — Муфтият Узбекистана") and
 * opens only when tapped. Exactly one group is open at a time: a UI decision (you cannot lose
 * yourself in two long lists at once) and a performance one — the composition stays a fraction of
 * its old size and `LazyColumn` measures only what is on screen.
 *
 * ### What 0.2.7 changed here
 *
 * The method group is no longer a flat list of twelve. Its first row is "Автоматически по стране",
 * which is now the default and the honest answer: the profile is a property of the place, not of the
 * app (see `RegionalProfile`). The group header states which profile is in force *and* how well it is
 * verified, so a user in Bukhara can see "сверено с печатным календарём" and a user in Almaty can see
 * that the local calendar has not been compared yet instead of being told a comfortable lie.
 *
 * Sound moved out of the notification group into its own: a switch called "Без звука" cannot express
 * a choice between the full adhan, its first 25 seconds and a plain system chirp.
 *
 * Nothing here is "liquid glass" any more; the reasoning is on `GlassPanel`.
 */
@Composable
fun SettingsScreen(
    data: PrayerData,
    palette: PhasePalette,
    actions: AppActions,
    exactAlarmsAllowed: Boolean,
    locating: Boolean = false,
    locationStatus: String? = null,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val dockInset = LocalDockInset.current
    val settings = data.settings
    val accent = palette.accent
    val effectiveMethod = data.params.method

    // Survives rotation and process death, so coming back to the app does not silently collapse the
    // group the user was working in.
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    val toggle: (String) -> Unit = { key -> open = if (open == key) null else key }

    // Leaving the screen must never leave the adhan playing: the preview is the one place in the app
    // where sound starts without a prayer time behind it.
    DisposableEffect(Unit) { onDispose { actions.stopAzan() } }

    // Built here, in composable scope, and not inside the LazyColumn body: the body is a
    // LazyListScope lambda, which is not composable, so state read there would not subscribe to
    // recomposition and a tile could keep showing a value the user had already changed.
        /* -- Calculation method ---------------------------------------------------------------- */
        /* -- Everything else: the tile grid ---------------------------------------------------
         * Eight settings, two to a row, icon on top — the layout the user asked for by pointing at
         * the location card and saying "make the rest look like this". A tile carries the icon, the
         * name and the value it currently holds, so the whole state of the app is readable in one
         * screen without opening anything. Tapping a tile unfolds its full panel directly under its
         * own row, which keeps the thing being edited next to the thing that was tapped instead of
         * pushing it off-screen.
         *
         * The panels themselves are untouched — same controls, same captions. Only the way in is new.
         */
        val specs = buildList<SettingsTile> {
            run {
                val countryDefault = RegionalProfiles.forCountry(data.place.country)
                add(
                    SettingsTile(
                        id = "method",
                        title = "Метод расчёта",
                        value = if (settings.methodIsAutomatic) {
                                "Автоматически · ${effectiveMethod.title}"
                            } else {
                                "Вручную · ${effectiveMethod.title}"
                            },
                        icon = Icons.Filled.Build
                    ) {
                        Column {
                            ChoiceRow(
                                title = "Автоматически по стране",
                                subtitle = "${data.place.country} → ${countryDefault.method.title}",
                                selected = settings.methodIsAutomatic,
                                accent = accent,
                                onClick = { actions.setMethod(null) }
                            )
                            HairRule()
                            /*
                             * Only the methods that mean something here, plus whatever the user has already
                             * chosen by hand — a selected row must never disappear from the list it lives in.
                             * `remember` keys on the country so this is computed on a city change, not on
                             * every recomposition of a screen that also carries a one-second clock.
                             */
                            val methods = remember(
                                data.place.country,
                                effectiveMethod,
                                settings.methodIsAutomatic
                            ) {
                                val offered = RegionalProfiles.methodsFor(data.place.country)
                                if (settings.methodIsAutomatic || effectiveMethod in offered) {
                                    offered
                                } else {
                                    offered + effectiveMethod
                                }
                            }
                            methods.forEach { method ->
                                ChoiceRow(
                                    title = method.title,
                                    subtitle = subtitleFor(method),
                                    selected = !settings.methodIsAutomatic && effectiveMethod == method,
                                    accent = accent,
                                    onClick = { actions.setMethod(method) }
                                )
                            }
                            HairRule()
                            Caption(calibrationLine(data), color = TextSecondary)
                            Spacer(Modifier.height(ui.s(6f)))
                            Caption(
                                "В списке — методы, которые действительно применяются в стране выбранного " +
                                    "города (${data.place.country}), и международные наборы углов. " +
                                    "Печатные календари других стран не показываются: они совпадают со " +
                                    "своей страной и расходятся на минуты с любой другой."
                            )
                            Spacer(Modifier.height(ui.s(6f)))
                            Caption(
                                "Метод — это углы солнца и правила печати местного муфтията, а не подпись: " +
                                    "переключатель меняет арифметику, поэтому углы указаны у каждой строки. " +
                                    "Ручной выбор остаётся ручным и не становится новым правилом для " +
                                    "остальных стран."
                            )
                        }
                    }
                )
            }
            run {
                add(
                    SettingsTile(
                        id = "madhab",
                        title = "Мазхаб · время Асра",
                        value = if (settings.madhab == Madhab.HANAFI) "Ханафитский" else "Шафиитский",
                        icon = Icons.Filled.Star
                    ) {
                        Column {
                            SegmentedControl(
                                options = listOf("Ханафитский", "Шафиитский"),
                                selectedIndex = if (settings.madhab == Madhab.HANAFI) 0 else 1,
                                accent = accent,
                                onSelect = { index ->
                                    actions.setMadhab(if (index == 0) Madhab.HANAFI else Madhab.STANDARD)
                                }
                            )
                            Spacer(Modifier.height(ui.s(10f)))
                            Caption(
                                "Ханафитский Аср наступает позже: тень предмета должна вырасти до двух его " +
                                    "высот вместо одной."
                            )
                        }
                    }
                )
            }
            run {
                val on = Prayer.entries.count { it.isPrayer && settings.notifications[it] == true }
                val total = Prayer.entries.count { it.isPrayer }
                val lead = if (settings.preAlertMinutes > 0) " · за ${settings.preAlertMinutes} мин" else ""
                add(
                    SettingsTile(
                        id = "notify",
                        title = "Уведомления",
                        value = if (exactAlarmsAllowed) "$on из $total$lead"
                            else "$on из $total$lead · нет точных будильников",
                        icon = Icons.Filled.Notifications
                    ) {
                        Column {
                            if (!exactAlarmsAllowed) {
                                WarningBlock(
                                    text = "Android запрещает приложению точные будильники. Без этого " +
                                        "разрешения уведомление может опоздать на несколько минут.",
                                    actionText = "Разрешить точные будильники",
                                    onClick = { actions.openExactAlarmSettings() }
                                )
                                Spacer(Modifier.height(ui.s(12f)))
                            }
                            Prayer.entries.filter { it.isPrayer }.forEach { prayer ->
                                SwitchRow(
                                    title = PrayerLabels.title(prayer),
                                    subtitle = PrayerLabels.hint(prayer),
                                    checked = settings.notifications[prayer] == true,
                                    accent = accent,
                                    onCheckedChange = { actions.setNotification(prayer, it) }
                                )
                            }
                            HairRule()
                            StepperField(
                                label = "Напомнить заранее",
                                value = "${settings.preAlertMinutes} мин",
                                accent = accent,
                                onMinus = { actions.setPreAlert(settings.preAlertMinutes - 5) },
                                onPlus = { actions.setPreAlert(settings.preAlertMinutes + 5) }
                            )
                            Spacer(Modifier.height(ui.s(10f)))
                            NurButton(
                                text = "Отключить экономию батареи для Nur",
                                accent = accent,
                                onClick = { actions.openBatterySettings() }
                            )
                            Spacer(Modifier.height(ui.s(8f)))
                            Caption(
                                "Xiaomi, Huawei, Samsung и Oppo выгружают фоновые процессы: разрешите " +
                                    "автозапуск и снимите ограничения батареи, иначе система задержит любое " +
                                    "уведомление."
                            )
                        }
                    }
                )
            }
            run {
                add(
                    SettingsTile(
                        id = "azan",
                        title = "Звук азана",
                        value = settings.azanSound.title,
                        icon = Icons.Filled.PlayArrow
                    ) {
                        Column {
                            AzanSound.entries.forEach { sound ->
                                ChoiceRow(
                                    title = sound.title,
                                    subtitle = sound.explanation,
                                    selected = settings.azanSound == sound,
                                    accent = accent,
                                    onClick = {
                                        actions.setAzanSound(sound)
                                        // Choosing is the only moment the choice can be judged, and the
                                        // alternative is judging it at four in the morning.
                                        if (sound.playsAzan) actions.previewAzan(sound) else actions.stopAzan()
                                    }
                                )
                            }
                            HairRule()
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.weight(1f)) {
                                    NurButton(
                                        text = "Прослушать",
                                        accent = accent,
                                        onClick = { actions.previewAzan(settings.azanSound) },
                                        enabled = settings.azanSound.playsAzan
                                    )
                                }
                                Spacer(Modifier.width(ui.s(10f)))
                                Box(Modifier.weight(1f)) {
                                    NurButton(
                                        text = "Остановить",
                                        accent = accent,
                                        onClick = { actions.stopAzan() }
                                    )
                                }
                            }
                            Spacer(Modifier.height(ui.s(8f)))
                            Caption(
                                "Запись — азан Мохаммада Башира, встроена в приложение: интернет для звука " +
                                    "не нужен. Играет на будильничном канале и забирает аудиофокус, поэтому " +
                                    "музыка ставится на паузу, а не мешается. В беззвучном режиме телефона " +
                                    "азан молчит, уведомление всё равно приходит."
                            )
                        }
                    }
                )
            }
            run {
                add(
                    SettingsTile(
                        id = "highlat",
                        title = "Высокие широты",
                        value = ruleTitle(settings.highLatitudeRule),
                        icon = Icons.Filled.Warning
                    ) {
                        Column {
                            HighLatitudeRule.entries.forEach { rule ->
                                ChoiceRow(
                                    title = ruleTitle(rule),
                                    subtitle = ruleSubtitle(rule),
                                    selected = settings.highLatitudeRule == rule,
                                    accent = accent,
                                    onClick = { actions.setHighLatitudeRule(rule) }
                                )
                            }
                            HairRule()
                            Caption(
                                "Правило из этого списка — запасной вариант, а не потолок: оно включается " +
                                    "только в те дни, когда солнце физически не доходит до угла метода."
                            )
                        }
                    }
                )
            }
            run {
                add(
                    SettingsTile(
                        id = "rounding",
                        title = "Округление секунд",
                        value = settings.rounding.title,
                        icon = Icons.Filled.Refresh
                    ) {
                        Column {
                            SegmentedControl(
                                options = listOf("Ближайшая", "Вверх", "Вниз"),
                                selectedIndex = RoundingMode.entries.indexOf(settings.rounding),
                                accent = accent,
                                onSelect = { index -> actions.setRounding(RoundingMode.entries[index]) }
                            )
                            Spacer(Modifier.height(ui.s(10f)))
                            Caption(settings.rounding.explanation, color = TextSecondary)
                            Spacer(Modifier.height(ui.s(6f)))
                            Caption(
                                "Расхождение в одну минуту между двумя приложениями в одном городе почти " +
                                    "всегда именно это: секунды упали по разные стороны границы минуты."
                            )
                        }
                    }
                )
            }
            run {
                val edited = Prayer.entries.filter { (settings.offsets[it] ?: 0) != 0 }
                add(
                    SettingsTile(
                        id = "offsets",
                        title = "Ручная коррекция",
                        value = when {
                                edited.isEmpty() && settings.hijriOffset == 0 -> "без правок"
                                edited.isEmpty() -> "хиджра ${signed(settings.hijriOffset)} дн."
                                else -> edited.joinToString(", ") {
                                    "${PrayerLabels.title(it)} ${signed(settings.offsets[it] ?: 0)}"
                                }
                            },
                        icon = Icons.Filled.Edit
                    ) {
                        Column {
                            Prayer.entries.forEach { prayer ->
                                val value = settings.offsets[prayer] ?: 0
                                StepperField(
                                    label = PrayerLabels.title(prayer),
                                    value = "${signed(value)} мин",
                                    accent = accent,
                                    onMinus = { actions.setOffset(prayer, value - 1) },
                                    onPlus = { actions.setOffset(prayer, value + 1) }
                                )
                            }
                            HairRule()
                            StepperField(
                                label = "Сдвиг даты по хиджре",
                                value = "${signed(settings.hijriOffset)} дн.",
                                accent = accent,
                                onMinus = { actions.setHijriOffset(settings.hijriOffset - 1) },
                                onPlus = { actions.setHijriOffset(settings.hijriOffset + 1) }
                            )
                            Spacer(Modifier.height(ui.s(8f)))
                            Caption(
                                "Сверьте расписание со своей мечетью и выровняйте разницу здесь: коррекция " +
                                    "применяется и к уведомлениям. Если время уже совпадает с местным " +
                                    "календарём, держите здесь нули — профиль страны делает эту работу сам."
                            )
                        }
                    }
                )
            }
            run {
                add(
                    SettingsTile(
                        id = "about",
                        title = "О расчёте",
                        value = "${effectiveMethod.angleSummary} · ${data.place.zone.id}",
                        icon = Icons.Filled.Info
                    ) {
                        Column {
                            FactRow("Страна профиля", data.place.country)
                            FactRow("Метод", effectiveMethod.title)
                            FactRow("Углы метода", effectiveMethod.angleSummary)
                            FactRow("Сверка", data.profile.calibration.label)
                            FactRow(
                                "Координаты",
                                format(data.place.coordinates.latitude) + ", " +
                                    format(data.place.coordinates.longitude)
                            )
                            FactRow("Часовой пояс", data.place.zone.id)
                            FactRow("Пояс определён", zoneSourceLabel(data.place.zoneSource))
                            data.place.accuracyMeters?.let { FactRow("Точность точки", "±${it.toInt()} м") }
                            FactRow("Азимут кыблы", "${Math.round(data.qibla)}°")
                            FactRow("Сухур сегодня", sourceLabel(data.today.saharSource))
                            FactRow("Фаджр сегодня", sourceLabel(data.today.fajrSource))
                            FactRow("Иша сегодня", sourceLabel(data.today.ishaSource))
                            HairRule()
                            Caption(data.profile.note, color = TextSecondary)
                            data.place.zoneExplanation.takeIf { it.isNotEmpty() }?.let {
                                HairRule()
                                Caption(it, color = TextSecondary)
                            }
                            data.today.note?.let {
                                HairRule()
                                Caption(it, color = TextSecondary)
                            }
                            HairRule()
                            Caption(
                                "Алгоритм: астрономические формулы Жана Мееса (Astronomical Algorithms, 2-е " +
                                    "изд.), точность солнечных событий — единицы секунд. Каждое пересечение " +
                                    "проверяется по высоте солнца и по смене знака остатка, поэтому касание " +
                                    "угла в белую ночь не выдаётся за наступление времени, а существующее " +
                                    "время не теряется на плоском дне летней ночи. Nur 0.2.9"
                            )
                        }
                    }
                )
            }
        }

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(
            start = ui.s(20f),
            end = ui.s(20f),
            top = ui.s(6f),
            bottom = dockInset
        ),
        verticalArrangement = Arrangement.spacedBy(ui.s(10f))
    ) {
        item(key = "title") {
            Column(modifier = Modifier.padding(bottom = ui.s(2f))) {
                AutoSizeText(
                    text = "Настройки",
                    color = TextPrimary,
                    fontSize = ui.t(26f),
                    minFontSize = ui.t(19f),
                    fontWeight = FontWeight.SemiBold
                )
                AutoSizeText(
                    text = "Всё считается офлайн, на устройстве",
                    color = TextTertiary,
                    fontSize = ui.t(12f),
                    minFontSize = ui.t(9.5f),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        /* -- Location -------------------------------------------------------------------------- */
        item(key = "place") {
            GlassPanel(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = ui.s(16f),
                corner = ui.s(20f)
            ) {
                Column {
                    SectionLabel("Местоположение")
                    Spacer(Modifier.height(ui.s(10f)))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(ui.s(14f)))
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { actions.openCityPicker() }
                            .padding(vertical = ui.s(8f)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(ui.s(8f))
                                .clip(CircleShape)
                                .background(accent)
                        )
                        Spacer(Modifier.width(ui.s(11f)))
                        Column(Modifier.weight(1f)) {
                            AutoSizeText(
                                text = data.place.label,
                                color = TextPrimary,
                                fontSize = ui.t(15.5f),
                                minFontSize = ui.t(12f),
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.fillMaxWidth()
                            )
                            AutoSizeText(
                                text = data.place.subtitle,
                                color = TextTertiary,
                                fontSize = ui.t(11f),
                                minFontSize = ui.t(9f),
                                maxLines = 2,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Spacer(Modifier.width(ui.s(8f)))
                        Text("изменить", color = palette.accentSoft, fontSize = ui.t(11.5f))
                    }
                    Spacer(Modifier.height(ui.s(10f)))
                    NurButton(
                        text = if (locating) "Ищем спутники…" else "Определить по местоположению",
                        accent = accent,
                        onClick = { actions.requestLocation() },
                        enabled = !locating
                    )
                    if (locationStatus != null) {
                        Spacer(Modifier.height(ui.s(8f)))
                        Caption(locationStatus)
                    }
                }
            }
        }


        specs.chunked(2).forEachIndexed { rowIndex, row ->
            item(key = "row-$rowIndex") {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(ui.s(10f))
                    ) {
                        row.forEach { spec ->
                            SettingsTileCard(
                                spec = spec,
                                selected = open == spec.id,
                                accent = accent,
                                onClick = { toggle(spec.id) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        // A lone tile on the last row keeps half the width instead of stretching:
                        // a grid that loses its column on the final item stops reading as a grid.
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                    row.firstOrNull { it.id == open }?.let { openSpec ->
                        Spacer(Modifier.height(ui.s(10f)))
                        GlassPanel(
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = ui.s(16f),
                            corner = ui.s(20f),
                            accent = accent
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                SectionLabel(openSpec.title)
                                Spacer(Modifier.height(ui.s(12f)))
                                openSpec.content()
                            }
                        }
                    }
                }
            }
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * The tile grid
 * ---------------------------------------------------------------------------------------------- */

/**
 * One settings tile: what it is called, what it is currently set to, and the panel behind it.
 *
 * The panel is carried as a composable lambda rather than being looked up by id, so a tile and its
 * contents cannot drift apart when one of them is edited — the compiler keeps them in the same
 * expression. [content] is only invoked for the open tile, so the eight panels cost nothing while
 * they are closed.
 */
private class SettingsTile(
    val id: String,
    val title: String,
    val value: String,
    val icon: ImageVector,
    val content: @Composable () -> Unit
)

/**
 * The tile itself: icon badge on top, name under it, current value at the bottom.
 *
 * Fixed height, not intrinsic. Two tiles side by side with text of different lengths would otherwise
 * end up different heights, and a grid whose rows do not line up looks broken in a way that is hard
 * to name but impossible to unsee. The value line is allowed two lines and shrinks to fit, so
 * "Автоматически · ДУМ РФ" reads in full instead of being cut mid-word.
 */
@Composable
private fun SettingsTileCard(
    spec: SettingsTile,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    GlassPanel(
        modifier = modifier
            .height(ui.s(132f))
            .clip(RoundedCornerShape(ui.s(20f)))
            .clickable(onClick = onClick),
        contentPadding = ui.s(14f),
        corner = ui.s(20f),
        accent = if (selected) accent else null
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(ui.s(38f))
                        .clip(RoundedCornerShape(ui.s(12f)))
                        .background(accent.copy(alpha = if (selected) 0.30f else 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = spec.icon,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(ui.s(20f))
                    )
                }
                Spacer(Modifier.weight(1f))
                Icon(
                    imageVector = Icons.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    tint = TextTertiary,
                    modifier = Modifier
                        .size(ui.s(18f))
                        .rotate(if (selected) 90f else 0f)
                )
            }
            Spacer(Modifier.height(ui.s(10f)))
            AutoSizeText(
                text = spec.title,
                color = TextPrimary,
                fontSize = ui.t(14f),
                minFontSize = ui.t(11f),
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.weight(1f))
            AutoSizeText(
                text = spec.value,
                color = TextTertiary,
                fontSize = ui.t(11.5f),
                minFontSize = ui.t(9f),
                maxLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * Local pieces
 * ---------------------------------------------------------------------------------------------- */

/** A signed number states a direction, so the plus sign is never dropped. */
private fun signed(value: Int): String = if (value > 0) "+$value" else "$value"

private fun format(value: Double): String = String.format(java.util.Locale.US, "%.4f", value)

/**
 * One sentence about how much the current profile has actually been checked.
 *
 * Printed in the method group rather than hidden in "О расчёте" because it is the answer to the
 * question that brings a user here: "why does your app disagree with the site I usually read".
 */
private fun calibrationLine(data: PrayerData): String = when (data.profile.calibration) {
    Calibration.PRINTED_CALENDAR ->
        "Профиль «${data.profile.method.title}» сверен с печатным календарём этой страны."
    Calibration.OFFICIAL_ANGLES ->
        "Профиль «${data.profile.method.title}»: официальные углы местного управления, " +
            "печатный календарь ещё не сверялся построчно."
    Calibration.ASSUMED ->
        "Профиль «${data.profile.method.title}» — общий региональный: углы официальные, " +
            "редакционных поправок местного календаря в нём нет."
}

@Composable
private fun WarningBlock(text: String, actionText: String, onClick: () -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(ui.s(16f))
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .nurPanel(shape, PanelLevel.FLAT, Crimson)
            .padding(ui.s(13f))
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(ui.s(7f))
                    .clip(CircleShape)
                    .background(Crimson)
            )
            Spacer(Modifier.width(ui.s(8f)))
            Text(
                text = "Требуется разрешение",
                color = Crimson,
                fontSize = ui.t(11.5f),
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(Modifier.height(ui.s(7f)))
        Text(text = text, color = TextSecondary, fontSize = ui.t(12f), lineHeight = ui.t(16.5f))
        Spacer(Modifier.height(ui.s(11f)))
        NurButton(text = actionText, accent = Crimson, onClick = onClick, primary = true)
    }
}

private fun subtitleFor(method: CalculationMethod): String {
    val hint = when (method) {
        CalculationMethod.RUSSIA_DUM -> "Россия и Беларусь"
        CalculationMethod.SPIRITUAL_BOARD_TATARSTAN -> "Сверено с календарём ДУМ РТ"
        CalculationMethod.UZBEKISTAN_BOARD -> "Узбекистан, сверено с namozvaqti.uz"
        CalculationMethod.UMM_AL_QURA -> "Саудовская Аравия"
        CalculationMethod.TURKEY -> "С поправками Diyanet"
        CalculationMethod.TEHRAN -> "Иран, Магриб по углу"
        else -> null
    }
    return if (hint == null) method.angleSummary else "$hint · ${method.angleSummary}"
}

private fun ruleTitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> "Автоматически"
    HighLatitudeRule.FIXED_INTERVAL -> "Фиксированный интервал (ДУМ РФ)"
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> "Середина ночи"
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> "Одна седьмая ночи"
    HighLatitudeRule.TWILIGHT_ANGLE -> "Пропорция по углу сумерек"
}

private fun ruleSubtitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> "Выше 48° широты — фиксированный интервал, иначе середина ночи"
    HighLatitudeRule.FIXED_INTERVAL -> "Восход − 120 мин и закат + 90 мин, как печатает ДУМ РТ"
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> "Фаджр и Иша не переходят середину ночи"
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> "Классическая доля ночи 1/7"
    HighLatitudeRule.TWILIGHT_ANGLE -> "Доля ночи пропорциональна углу метода"
}

/**
 * Which piece of evidence decided the time zone.
 *
 * Worth a row of its own: a zone taken from longitude means the app is guessing within an hour, and
 * the user is the only one who can tell it the truth by picking a city.
 */
private fun zoneSourceLabel(source: com.nur.prayer.location.ZoneSource): String = when (source) {
    com.nur.prayer.location.ZoneSource.DEVICE -> "по часам телефона"
    com.nur.prayer.location.ZoneSource.NEIGHBOURHOOD -> "по городам рядом"
    com.nur.prayer.location.ZoneSource.LONGITUDE -> "по долготе (приближённо)"
}

/**
 * Plain words for where today's Sahar / Fajr / Isha actually came from.
 *
 * Exhaustive on purpose, with no `else` branch: when a new [TimeSource] appears, this has to fail to
 * compile, so the explanation shown to the user cannot quietly fall behind the engine.
 */
private fun sourceLabel(source: TimeSource): String = when (source) {
    TimeSource.ANGLE -> "по углу солнца"
    TimeSource.PRINTED_TABLE -> "из печатной таблицы муфтията"
    TimeSource.METHOD_INTERVAL -> "интервал метода"
    TimeSource.FIXED_INTERVAL -> "фикс. интервал (короткая ночь)"
    TimeSource.NIGHT_FRACTION -> "доля ночи (короткая ночь)"
    TimeSource.MIDNIGHT_BOUND -> "ограничено серединой ночи"
    TimeSource.CONGREGATION -> "как в мечети: восход − 90 мин"
    TimeSource.DAWN_BOUND -> "поднято до рассвета"
}
