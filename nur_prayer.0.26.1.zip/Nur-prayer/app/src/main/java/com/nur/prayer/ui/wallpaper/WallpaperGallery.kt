package com.nur.prayer.ui.wallpaper

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.settings.CheckMark
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlin.math.absoluteValue
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * 0.22.0: «Все обои» — the whole catalog over a soft copy of the wallpaper that is on now.
 *
 * Sections are categories, each a row of miniatures with this screen's proportions. A tap does not
 * set anything: the tile itself flies out and grows into a big card (the tile is hidden meanwhile, so
 * it reads as one object, not a copy), with the home screen mocked over it — the place, the date and
 * the big clock exactly where home puts them, on the scrim home would compute. Swipe for the next
 * one; «Установить» sets it, the backdrop changes by a circle out of the button and a toast pops.
 * 0.25.0: the card stays open after «Установить» (the button turns into «Текущие обои») — the user
 * closes it when they want; the tile under it just takes the check, with no jump.
 *
 * Hosted at the root of the app (root px = screen px), above every page.
 */
@Composable
fun WallpaperGallery(
    open: Boolean,
    current: Wallpaper,
    palette: PhasePalette,
    mock: MockHome?,
    onSet: (Wallpaper) -> Unit,
    onClose: () -> Unit
) {
    val shown = remember { Animatable(0f) }
    LaunchedEffect(open) {
        if (open) shown.animateTo(1f, Toon.card<Float>())
        else shown.animateTo(0f, spring(dampingRatio = 1f, stiffness = 520f))
    }
    val visible by remember { derivedStateOf { shown.value > 0.002f } }
    if (!open && !visible) return
    GalleryContent(open, shown, current, palette, mock, onSet, onClose)
}

/** The preview card: which page it opened on, the rect it flies from / back to, and its progress. */
private class PreviewState {
    var start by mutableStateOf<Int?>(null)
    var page by mutableStateOf<String?>(null)
    var from by mutableStateOf(Rect.Zero)
    val progress = Animatable(0f)
}

@Composable
private fun GalleryContent(
    open: Boolean,
    shown: Animatable<Float, *>,
    current: Wallpaper,
    palette: PhasePalette,
    mock: MockHome?,
    onSet: (Wallpaper) -> Unit,
    onClose: () -> Unit
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val accent = palette.accent
    val sections = remember { WallpaperCatalog.sections() }
    val flat = remember { sections.flatMap { it.second } }
    // Where every tile is on screen (root px): the card flies from it and lands back into it.
    val tiles = remember { HashMap<String, Rect>() }
    val preview = remember { PreviewState() }
    var toast by remember { mutableIntStateOf(0) }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    fun openPreview(w: Wallpaper) {
        if (preview.start != null) return
        val rect = tiles[w.id] ?: return
        preview.from = rect
        preview.page = w.id
        preview.start = flat.indexOf(w).coerceAtLeast(0)
        scope.launch {
            preview.progress.snapTo(0f)
            // 0.23.0: no overshoot on the big card — a 260-stiffness bounce on a near-fullscreen
            // surface read as a jerk. The tile copy is drawn from the first frame (WallpaperThumb).
            preview.progress.animateTo(1f, CardOpen)
        }
    }

    fun closePreview(target: Wallpaper?) {
        if (preview.start == null) return
        val id = target?.id ?: preview.page
        preview.page = id
        // Lands into the tile of the page it is on now; a tile never laid out → shrink in place.
        preview.from = id?.let { tiles[it] } ?: Rect.Zero
        scope.launch {
            preview.progress.animateTo(0f, CardClose)
            preview.start = null
            preview.page = null
        }
    }

    BackHandler(enabled = open) { if (preview.start != null) closePreview(null) else onClose() }
    val popMemory = rememberPopMemory()

    CompositionLocalProvider(LocalPopMemory provides popMemory) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val screenW = maxWidth
        // Backdrop: the wallpaper on now, soft, under a dark veil. Swallows touches.
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = shown.value.coerceIn(0f, 1f) }
                .clickable(remember { MutableInteractionSource() }, indication = null) {}
        ) {
            RevealingWallpaper(current, palette, motionEnabled = false, sharp = false)
            // 0.23.0: the wallpaper that is on now, darkened — recognisable, not a black page.
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                0f to Color.Black.copy(alpha = 0.58f), 0.45f to Color.Black.copy(alpha = 0.38f), 1f to Color.Black.copy(alpha = 0.66f)
            )))
        }

        val gap = ui.s(10f)
        val side = ui.s(18f)
        val aspect = WallpaperScreen.aspect(constraints.maxWidth, constraints.maxHeight)
        val tileW = (screenW - side * 2 - gap * 2) / 2.7f
        val tileH = tileW / aspect

        LazyColumn(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal))
                .graphicsLayer {
                    val s = shown.value
                    // 0.23.0: under an open card the list steps back and almost disappears: behind
                    // the card is the current wallpaper, not a page of other tiles and titles.
                    val c = if (preview.start != null) preview.progress.value.coerceIn(0f, 1f) else 0f
                    alpha = s.coerceIn(0f, 1f) * (1f - 0.9f * c)
                    translationY = (1f - s) * 90.dp.toPx()
                    val k = 1f - 0.04f * c
                    scaleX = k
                    scaleY = k
                },
            contentPadding = PaddingValues(top = top + 22.dp, bottom = bottom + 112.dp)
        ) {
            item(key = "head") {
                Column(Modifier.padding(horizontal = side).padding(bottom = ui.s(8f)).popIn(0, "head")) {
                    Text(tr("Обои"), color = TextPrimary, fontSize = ui.t(30f), fontWeight = FontWeight.Bold, maxLines = 1)
                    Spacer(Modifier.height(ui.s(2f)))
                    Text(tr("Нажмите, чтобы примерить"), color = TextSecondary, fontSize = ui.t(14f), maxLines = 2)
                }
            }
            sections.forEachIndexed { si, (category, list) ->
                item(key = "title-${category.name}") {
                    Text(
                        category.title(), color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = side, end = side, top = ui.s(18f), bottom = ui.s(10f)).popIn(si * 2 + 1, "title-${category.name}")
                    )
                }
                item(key = "row-${category.name}") {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = side),
                        horizontalArrangement = Arrangement.spacedBy(gap)
                    ) {
                        itemsIndexed(list, key = { _, w -> w.id }) { i, w ->
                            GalleryTile(
                                w, w == current, palette, accent, tileW, tileH, order = si * 2 + 2 + i,
                                hidden = { preview.page == w.id && preview.start != null },
                                onBounds = { tiles[w.id] = it }
                            ) { openPreview(w) }
                        }
                    }
                }
            }
        }

        // Close: bottom corner, under the thumb, like the reference — and pops in last.
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(end = side, bottom = bottom + 22.dp)
                .graphicsLayer {
                    val s = shown.value
                    scaleX = s
                    scaleY = s
                    alpha = s.coerceIn(0f, 1f)
                }
                .size(54.dp)
                .squishClick { if (preview.start != null) closePreview(null) else onClose() }
                .semantics { contentDescription = tr("Закрыть") }
                .clip(CircleShape)
                .background(Color(0xD81C1A2A))
                .border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Glyph(GlyphKind.CLOSE, TextPrimary, Modifier.size(22.dp))
        }

        val start = preview.start
        if (start != null) {
            PreviewLayer(
                preview, start, flat, current, palette, mock, top, bottom,
                onDismiss = { closePreview(null) }
            ) { w, origin ->
                WallpaperScreen.requestReveal(w.id, origin)
                onSet(w)
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                toast++
            }
        }

        SetToast(toast, accent, Modifier.align(Alignment.BottomCenter).padding(bottom = bottom + 96.dp))
    }
    }
}

/** A miniature of the gallery: same as the settings row, plus it reports where it is and can hide. */
@Composable
private fun GalleryTile(
    wallpaper: Wallpaper,
    selected: Boolean,
    palette: PhasePalette,
    accent: Color,
    width: Dp,
    height: Dp,
    order: Int,
    hidden: () -> Boolean,
    onBounds: (Rect) -> Unit,
    onClick: () -> Unit
) {
    val ui = uiScale()
    val shape = RoundedCornerShape(ui.s(16f))
    // 0.25.0: no jump on selection — the ring and the check just settle in (Toon.select, no overshoot).
    val ring by animateColorAsState(if (selected) accent else Color.White.copy(alpha = 0.12f), Toon.select<Color>(), label = "galleryRing")
    val ringWidth by animateDpAsState(if (selected) 2.5.dp else 1.dp, Toon.select<Dp>(), label = "galleryRingWidth")
    val check by animateFloatAsState(if (selected) 1f else 0f, Toon.select<Float>(), label = "galleryCheck")
    val name = wallpaper.title()
    Column(Modifier.width(width).popIn(order, wallpaper.id), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(width, height)
                .onGloballyPositioned { onBounds(it.boundsInRoot()) }
                .graphicsLayer { alpha = if (hidden()) 0f else 1f }
                .squishClick(role = Role.Button, onClick = onClick)
                .semantics {
                    contentDescription = name
                    this.selected = selected
                }
                .clip(shape)
                .border(ringWidth, ring, shape)
        ) {
            WallpaperThumb(wallpaper, palette, Modifier.fillMaxSize())
            if (check > 0.01f) {
                CheckMark(accent, check, Modifier.align(Alignment.BottomEnd).padding(ui.s(7f)).size(ui.s(22f)))
            }
        }
        Spacer(Modifier.height(ui.s(6f)))
        Text(
            name, color = if (selected) TextPrimary else TextSecondary, fontSize = ui.t(12f),
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun PreviewLayer(
    state: PreviewState,
    start: Int,
    flat: List<Wallpaper>,
    current: Wallpaper,
    palette: PhasePalette,
    mock: MockHome?,
    top: Dp,
    bottom: Dp,
    onDismiss: () -> Unit,
    onSet: (Wallpaper, Offset) -> Unit
) {
    val ui = uiScale()
    val density = LocalDensity.current
    val pager = rememberPagerState(initialPage = start) { flat.size }
    // The page the card is on is the tile it will land into.
    LaunchedEffect(pager) {
        androidx.compose.runtime.snapshotFlow { pager.currentPage }.collect { state.page = flat[it].id }
    }
    var showMock by remember { mutableStateOf(true) }
    val mockAlpha by animateFloatAsState(if (showMock) 1f else 0f, Toon.squash<Float>(), label = "mockAlpha")

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val sw = constraints.maxWidth.toFloat()
        val sh = constraints.maxHeight.toFloat()
        val aspect = WallpaperScreen.aspect(constraints.maxWidth, constraints.maxHeight)
        val controls = with(density) { 150.dp.toPx() }
        val topPx = with(density) { (top + 20.dp).toPx() }
        val bottomPx = with(density) { (bottom + 12.dp).toPx() }
        // As large as the screen allows with room for the name, the counter and the button.
        val cardH = min((sh - topPx - bottomPx - controls) * 0.98f, sw * 0.78f / aspect).coerceAtLeast(1f)
        val cardW = cardH * aspect
        val cardTop = max(topPx, (sh - cardH - controls) / 2f)
        val target = Rect(Offset((sw - cardW) / 2f, cardTop), Size(cardW, cardH))
        val tileRadius = with(density) { ui.s(16f).toPx() }
        val cardRadius = with(density) { ui.s(26f).toPx() }

        // Dim + tap outside to close.
        Box(
            Modifier
                .fillMaxSize()
                .drawBehind { drawRect(Color.Black.copy(alpha = 0.28f * state.progress.value.coerceIn(0f, 1f))) }
                .clickable(remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
        )

        val sidePad = with(density) { ((sw - cardW) / 2f).toDp() }
        HorizontalPager(
            state = pager,
            modifier = Modifier
                .fillMaxWidth()
                .height(with(density) { cardH.toDp() })
                .offset { IntOffset(0, cardTop.roundToInt()) }
                .graphicsLayer {
                    val p = state.progress.value
                    val f = state.from
                    val s0 = if (f.width > 0f) f.width / target.width else 0.3f
                    val fc = if (f.width > 0f) f.center else target.center
                    val s = s0 + (1f - s0) * p
                    scaleX = s
                    scaleY = s
                    translationX = (fc.x - target.center.x) * (1f - p)
                    translationY = (fc.y - target.center.y) * (1f - p)
                    if (f.width <= 0f) alpha = p.coerceIn(0f, 1f)
                },
            contentPadding = PaddingValues(horizontal = sidePad),
            pageSpacing = ui.s(14f),
            beyondViewportPageCount = 1,
            key = { flat[it].id }
        ) { page ->
            val w = flat[page]
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val d = ((pager.currentPage - page) + pager.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                        val k = 1f - 0.1f * d
                        scaleX = k
                        scaleY = k
                        val p = state.progress.value
                        val pc = p.coerceIn(0f, 1f)
                        alpha = if (page == pager.currentPage) 1f else pc * (1f - 0.3f * d)
                        // The tile's corners at the start, the card's at the end (in unscaled px).
                        val s0 = if (state.from.width > 0f) state.from.width / target.width else 1f
                        shape = RoundedCornerShape(tileRadius / s0 + (cardRadius - tileRadius / s0) * pc)
                        clip = true
                    }
                    .clickable(remember { MutableInteractionSource() }, indication = null) { showMock = !showMock }
                    .semantics { contentDescription = w.title() }
            ) {
                WallpaperThumb(w, palette, Modifier.fillMaxSize(), scrim = true)
                if (mock != null) {
                    MockHomeOverlay(mock, cardW / sw, Modifier.graphicsLayer { alpha = mockAlpha * state.progress.value.coerceIn(0f, 1f) })
                }
            }
        }

        // Name, counter and the button, under the card; they arrive after it.
        val w = flat[pager.currentPage.coerceIn(0, flat.size - 1)]
        val isCurrent = w == current
        var buttonCenter by remember { mutableStateOf(Offset.Unspecified) }
        Column(
            Modifier
                .fillMaxWidth()
                .offset { IntOffset(0, (cardTop + cardH).roundToInt()) }
                .padding(top = ui.s(16f))
                .graphicsLayer {
                    val p = state.progress.value
                    alpha = ((p - 0.35f) / 0.65f).coerceIn(0f, 1f)
                    translationY = (1f - p.coerceIn(0f, 1f)) * 46.dp.toPx()
                },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AnimatedContent(w.title(), transitionSpec = {
                (scaleIn(Toon.pop<Float>(), initialScale = 0.7f) + fadeIn()) togetherWith (scaleOut(targetScale = 0.7f) + fadeOut())
            }, label = "previewName") { title ->
                Text(title, color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(
                "${pager.currentPage + 1} / ${flat.size}" + if (showMock) "" else "  ·  " + tr("часы скрыты"),
                color = TextTertiary, fontSize = ui.t(12.5f), maxLines = 1
            )
            Spacer(Modifier.height(ui.s(12f)))
            Box(
                Modifier
                    .width(with(density) { cardW.toDp() })
                    .height(52.dp)
                    .onGloballyPositioned { buttonCenter = it.boundsInRoot().center }
                    .squishClick(enabled = !isCurrent) { onSet(w, buttonCenter) }
                    .clip(RoundedCornerShape(50))
                    .background(if (isCurrent) Color.White.copy(alpha = 0.12f) else palette.accent),
                contentAlignment = Alignment.Center
            ) {
                AnimatedContent(isCurrent, transitionSpec = {
                    (scaleIn(Toon.pop<Float>(), initialScale = 0.6f) + fadeIn()) togetherWith (scaleOut(targetScale = 0.6f) + fadeOut())
                }, label = "previewButton") { on ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        if (on) {
                            CheckMark(palette.accent, 1f, Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(
                            if (on) tr("Текущие обои") else tr("Установить"),
                            color = if (on) TextPrimary else ButtonInk, fontSize = ui.t(16f), fontWeight = FontWeight.Bold, maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

/** «Обои установлены»: pops up from below, stays a breath, sinks back. Each [key] change plays it once. */
@Composable
private fun SetToast(key: Int, accent: Color, modifier: Modifier = Modifier) {
    if (key == 0) return
    val ui = uiScale()
    val v = remember { Animatable(0f) }
    LaunchedEffect(key) {
        v.snapTo(0f)
        v.animateTo(1f, Toon.pop<Float>())
        delay(1500)
        v.animateTo(0f, spring(dampingRatio = 1f, stiffness = 600f))
    }
    Row(
        modifier
            .graphicsLayer {
                val p = v.value
                scaleX = 0.6f + 0.4f * p
                scaleY = 0.6f + 0.4f * p
                alpha = p.coerceIn(0f, 1f)
                translationY = (1f - p) * 28.dp.toPx()
            }
            .clip(RoundedCornerShape(50))
            .background(Color(0xEE201E30))
            .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(50))
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CheckMark(accent, 1f, Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(tr("Обои установлены"), color = TextPrimary, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** The card opens without overshoot (critically damped) and lands back a touch faster. */
private val CardOpen = spring<Float>(dampingRatio = 0.86f, stiffness = 300f)
private val CardClose = spring<Float>(dampingRatio = 0.9f, stiffness = 420f)

/** Dark type on the pale accent: the accent is light in every phase, white on it would fade. */
private val ButtonInk = Color(0xFF15132B)
