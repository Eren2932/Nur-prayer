package com.nur.prayer.ui.qibla

import com.nur.prayer.i18n.tr

import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Pure presentation policy.
 *
 * 0.23.0: the hold no longer matters (see [forwardAzimuth]), so "lay the phone flat" is gone. Two
 * levels of trust remain:
 *  - *usable* — the dial may point: turn instructions are shown;
 *  - *trustworthy* — calibrated as well: only then is "you face the Kaaba" confirmed.
 * Confirmation has hysteresis: it is entered within [ALIGN_TOLERANCE] and kept until [RELEASE_TOLERANCE],
 * so hand tremor at the edge does not make it blink (and buzz).
 */
object QiblaGuidance {
    const val ALIGN_TOLERANCE = 2.5f
    const val RELEASE_TOLERANCE = 4.5f

    fun aligned(delta: Float, available: Boolean, trustworthy: Boolean, wasAligned: Boolean = false): Boolean =
        delta.isFinite() && available && trustworthy &&
            abs(delta) <= (if (wasAligned) RELEASE_TOLERANCE else ALIGN_TOLERANCE)

    fun instruction(delta: Float, available: Boolean, usable: Boolean, trustworthy: Boolean): String = when {
        !available -> tr("Компас недоступен")
        !delta.isFinite() || !usable -> tr("Проверьте калибровку и помехи")
        abs(delta) <= ALIGN_TOLERANCE && trustworthy -> tr("Направление на Каабу")
        abs(delta) <= ALIGN_TOLERANCE -> tr("Почти на Каабу — откалибруйте компас")
        delta > 0f -> tr("Поверните вправо на {0}°", abs(delta).roundToInt())
        else -> tr("Поверните влево на {0}°", abs(delta).roundToInt())
    }

    fun degrees(value: Float): String = if (value.isFinite()) "${normalize(value).roundToInt() % 360}°" else "—"
}
