package com.nur.prayer.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.octagram

/*
 * 0.26.0: the sections of the «Орбита дня» ring, clockwise from the top.
 *
 * Each one has its own drawn mark, two-tone: the figure in the ink of the moment and one detail in
 * the accent — the star over the mushaf, the dot under the letter, the counted bead, the gold band
 * of the Kaaba. Drawn, not taken from a font: the same stroke weight as every other Nur glyph and
 * crisp at any size.
 */
enum class HomeSection {
    TODAY, QURAN, COURSE, QIBLA, DHIKR, SCHEDULE, SETTINGS;

    fun label(): String = when (this) {
        TODAY -> tr("Дела дня")
        QURAN -> tr("Коран")
        COURSE -> tr("Обучение")
        QIBLA -> tr("Кыбла")
        DHIKR -> tr("Зикр")
        SCHEDULE -> tr("Календарь")
        SETTINGS -> tr("Настройки")
    }
}

@Composable
fun SectionGlyph(section: HomeSection, ink: Color, detail: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) { drawSection(section, ink, detail) }
}

internal fun DrawScope.drawSection(section: HomeSection, ink: Color, detail: Color) {
    val s = size.minDimension
    if (s <= 0f) return
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val w = s * 0.085f
    val stroke = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(ox + x * s, oy + y * s)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Color = ink, width: Float = w) =
        drawLine(color, p(x1, y1), p(x2, y2), strokeWidth = width, cap = StrokeCap.Round)

    when (section) {
        HomeSection.TODAY -> {
            // A tablet of the day: one deed ticked, one still waiting, a small sun over them.
            drawRoundRect(
                ink, topLeft = p(0.16f, 0.2f), size = Size(s * 0.68f, s * 0.68f),
                cornerRadius = CornerRadius(s * 0.16f, s * 0.16f), style = stroke
            )
            val tick = Path().apply {
                moveTo(ox + 0.29f * s, oy + 0.45f * s)
                lineTo(ox + 0.35f * s, oy + 0.51f * s)
                lineTo(ox + 0.45f * s, oy + 0.39f * s)
            }
            drawPath(tick, detail, style = stroke)
            line(0.54f, 0.45f, 0.7f, 0.45f)
            drawCircle(ink, s * 0.045f, p(0.36f, 0.69f))
            line(0.54f, 0.69f, 0.7f, 0.69f)
            drawCircle(detail, s * 0.075f, p(0.5f, 0.12f))
        }
        HomeSection.QURAN -> {
            // An open mushaf on its rahle, the eight-pointed star of a hizb above it.
            val left = Path().apply {
                moveTo(ox + 0.5f * s, oy + 0.4f * s)
                quadraticBezierTo(ox + 0.32f * s, oy + 0.3f * s, ox + 0.13f * s, oy + 0.34f * s)
                lineTo(ox + 0.13f * s, oy + 0.64f * s)
                quadraticBezierTo(ox + 0.32f * s, oy + 0.6f * s, ox + 0.5f * s, oy + 0.7f * s)
            }
            val right = Path().apply {
                moveTo(ox + 0.5f * s, oy + 0.4f * s)
                quadraticBezierTo(ox + 0.68f * s, oy + 0.3f * s, ox + 0.87f * s, oy + 0.34f * s)
                lineTo(ox + 0.87f * s, oy + 0.64f * s)
                quadraticBezierTo(ox + 0.68f * s, oy + 0.6f * s, ox + 0.5f * s, oy + 0.7f * s)
            }
            drawPath(left, ink, style = stroke)
            drawPath(right, ink, style = stroke)
            line(0.5f, 0.4f, 0.5f, 0.7f, width = w * 0.8f)
            line(0.3f, 0.74f, 0.7f, 0.92f)
            line(0.7f, 0.74f, 0.3f, 0.92f)
            drawPath(octagram(ox + 0.5f * s, oy + 0.15f * s, s * 0.1f), detail)
        }
        HomeSection.COURSE -> {
            // A reed pen (qalam) that has just drawn a letter's bowl and its dot.
            val nib = Path().apply {
                moveTo(ox + 0.86f * s, oy + 0.1f * s)
                lineTo(ox + 0.92f * s, oy + 0.16f * s)
                lineTo(ox + 0.5f * s, oy + 0.58f * s)
                lineTo(ox + 0.4f * s, oy + 0.62f * s)
                lineTo(ox + 0.44f * s, oy + 0.52f * s)
                close()
            }
            drawPath(nib, ink, style = stroke)
            line(0.48f, 0.54f, 0.81f, 0.21f, width = w * 0.55f)
            val bowl = Path().apply {
                moveTo(ox + 0.1f * s, oy + 0.6f * s)
                quadraticBezierTo(ox + 0.12f * s, oy + 0.86f * s, ox + 0.42f * s, oy + 0.84f * s)
                quadraticBezierTo(ox + 0.62f * s, oy + 0.82f * s, ox + 0.66f * s, oy + 0.7f * s)
            }
            drawPath(bowl, ink, style = stroke)
            val dot = Path().apply {
                moveTo(ox + 0.3f * s, oy + 0.58f * s)
                lineTo(ox + 0.36f * s, oy + 0.64f * s)
                lineTo(ox + 0.3f * s, oy + 0.7f * s)
                lineTo(ox + 0.24f * s, oy + 0.64f * s)
                close()
            }
            drawPath(dot, detail)
        }
        HomeSection.QIBLA -> {
            // The Kaaba in a compass ring, its gold band in the accent, a pointer on the rim.
            drawCircle(ink, s * 0.4f, p(0.5f, 0.54f), style = stroke)
            val pointer = Path().apply {
                moveTo(ox + 0.5f * s, oy + 0.02f * s)
                lineTo(ox + 0.58f * s, oy + 0.16f * s)
                lineTo(ox + 0.42f * s, oy + 0.16f * s)
                close()
            }
            drawPath(pointer, detail)
            drawRoundRect(
                ink, topLeft = p(0.35f, 0.4f), size = Size(s * 0.3f, s * 0.3f),
                cornerRadius = CornerRadius(s * 0.03f, s * 0.03f)
            )
            drawRect(detail, topLeft = p(0.35f, 0.47f), size = Size(s * 0.3f, s * 0.05f))
        }
        HomeSection.DHIKR -> {
            // A tasbih: a loop of beads, the imam bead and the tassel; one bead is being counted.
            val c = p(0.5f, 0.42f)
            val r = s * 0.27f
            val beads = 11
            for (i in 0 until beads) {
                // An open gap at the bottom where the imam bead sits.
                val a = Math.toRadians(90.0 + 30.0 + i * (300.0 / (beads - 1)))
                val at = Offset(c.x + r * kotlin.math.cos(a).toFloat(), c.y + r * kotlin.math.sin(a).toFloat())
                drawCircle(if (i == 7) detail else ink, s * (if (i == 7) 0.06f else 0.045f), at)
            }
            val imam = p(0.5f, 0.76f)
            drawCircle(ink, s * 0.07f, imam)
            line(0.5f, 0.8f, 0.5f, 0.94f, width = w * 0.8f)
            line(0.5f, 0.88f, 0.42f, 0.96f, width = w * 0.6f)
            line(0.5f, 0.88f, 0.58f, 0.96f, width = w * 0.6f)
        }
        HomeSection.SCHEDULE -> {
            // A calendar sheet with the new crescent on it: months here begin with the hilal.
            drawRoundRect(
                ink, topLeft = p(0.12f, 0.2f), size = Size(s * 0.76f, s * 0.68f),
                cornerRadius = CornerRadius(s * 0.14f, s * 0.14f), style = stroke
            )
            line(0.32f, 0.1f, 0.32f, 0.27f)
            line(0.68f, 0.1f, 0.68f, 0.27f)
            line(0.12f, 0.4f, 0.88f, 0.4f, width = w * 0.8f)
            val r = s * 0.17f
            val disk = Path().apply { addOval(Rect(p(0.5f, 0.64f), r)) }
            val bite = Path().apply { addOval(Rect(p(0.58f, 0.58f), r * 0.86f)) }
            drawPath(Path().apply { op(disk, bite, PathOperation.Difference) }, detail)
        }
        HomeSection.SETTINGS -> {
            // The Rub el Hizb as a gear: the star is the rim, a ring is the axle.
            val c = p(0.5f, 0.5f)
            drawPath(octagram(c.x, c.y, s * 0.44f), ink, style = stroke)
            drawCircle(detail, s * 0.13f, c, style = Stroke(width = w * 1.1f))
        }
    }
}
