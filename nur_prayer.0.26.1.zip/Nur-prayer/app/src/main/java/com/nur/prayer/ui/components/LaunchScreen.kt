package com.nur.prayer.ui.components

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.nur.prayer.R
import com.nur.prayer.ui.theme.SystemBarsTone
import com.nur.prayer.ui.theme.findActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * 0.24.0: the launch screen. It continues the system splash (Theme.Nur.Starting: the same white, the
 * same picture, the same size and place) so there is no black window and no jump between the two.
 *
 * 0.25.0: the picture is the «Нур» disc of the launcher icon again (the praying figure), the very file
 * the system splash shows (res/drawable-<dpi>/ic_splash_art.webp, written by build_icons.py). And it is
 * faster: the screen leaves as soon as the data is there (a short [MIN_MILLIS] only so it never
 * flashes), in a quick [EXIT_MILLIS] fade. Only if the data is late does a quiet spinner come up under
 * the disc, so a slow first start never looks frozen.
 */
object LaunchScreenSpec {
    /** Matches @color/splash_bg. */
    val Background = Color(0xFFFFFFFF)
    val Wordmark = Color(0xFF9B93B8)
    val Spinner = Color(0xFF8A5CF6)
    /** The splash icon canvas: Android draws ic_splash_art on 288dp; the disc on it is 128dp. */
    const val ART_DP = 288
    const val MIN_MILLIS = 300L
    /** Never trap the user: if the data has not come by now, the app opens anyway. */
    const val MAX_MILLIS = 5000L
    const val EXIT_MILLIS = 260
    /** The spinner shows up only when the wait is longer than this. */
    const val SPINNER_AFTER_MILLIS = 600L
}

@Composable
fun LaunchScreen(ready: Boolean, onShown: () -> Unit, onFinished: () -> Unit) {
    val readyNow by rememberUpdatedState(ready)
    val exit = remember { Animatable(0f) }
    val spinner = remember { Animatable(0f) }
    var late by remember { mutableStateOf(false) }

    // Dark system-bar icons on the white screen; the app's own tone comes back when it is gone.
    val window = LocalContext.current.findActivity()?.window
    val view = LocalView.current
    DisposableEffect(window) {
        window?.let {
            WindowCompat.getInsetsController(it, view).apply {
                isAppearanceLightStatusBars = true
                isAppearanceLightNavigationBars = true
            }
        }
        onDispose { SystemBarsTone.apply(window) }
    }
    // The system splash is held until this first frame exists, so it hands over to white, not black.
    SideEffect { onShown() }

    LaunchedEffect(Unit) {
        val started = SystemClock.uptimeMillis()
        val hint = launch {
            delay(LaunchScreenSpec.SPINNER_AFTER_MILLIS)
            late = true
            spinner.animateTo(1f, tween(220))
        }
        withTimeoutOrNull(LaunchScreenSpec.MAX_MILLIS) { snapshotFlow { readyNow }.first { it } }
        val left = LaunchScreenSpec.MIN_MILLIS - (SystemClock.uptimeMillis() - started)
        if (left > 0) delay(left)
        hint.cancel()
        exit.animateTo(1f, tween(LaunchScreenSpec.EXIT_MILLIS, easing = FastOutSlowInEasing))
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = 1f - exit.value }
            .background(LaunchScreenSpec.Background)
            // Nothing underneath may be tapped while the screen is up.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Image(
            painter = painterResource(R.drawable.ic_splash_art),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.Center)
                .size(LaunchScreenSpec.ART_DP.dp)
                .graphicsLayer {
                    val s = 1f + 0.05f * exit.value
                    scaleX = s
                    scaleY = s
                }
        )
        if (late) {
            CircularProgressIndicator(
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = 108.dp)
                    .size(22.dp)
                    .graphicsLayer { alpha = spinner.value * (1f - exit.value) },
                color = LaunchScreenSpec.Spinner,
                strokeWidth = 2.dp
            )
        }
        Text(
            text = "Nur",
            color = LaunchScreenSpec.Wordmark,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 5.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 44.dp)
        )
    }
}
