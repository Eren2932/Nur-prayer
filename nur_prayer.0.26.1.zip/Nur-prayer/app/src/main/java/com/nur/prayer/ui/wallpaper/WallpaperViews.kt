package com.nur.prayer.ui.wallpaper

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import kotlinx.coroutines.delay

/*
 * 0.22.0: the small pieces of the wallpaper screens — a miniature of a wallpaper, the cartoon
 * motion (squash on press, pop on appear) and the mock home drawn over a preview.
 *
 * Motion vocabulary, shared by the row, the gallery and the preview:
 *   squash  — a pressed thing flattens (wider, lower) and springs back past its size (rubber);
 *   pop     — a thing that appears grows from half its size with an overshoot, one after another;
 *   boing   — a thing that was chosen jumps once.
 * All are springs with low damping, all are one-shot: nothing on these screens runs in a loop.
 */

/** Damping < 0.5 is what reads as "cartoon": the release overshoots and settles in one wobble. */
internal object Toon {
    fun <T> rubber(): FiniteAnimationSpec<T> = spring(dampingRatio = 0.38f, stiffness = 520f)
    fun <T> pop(): FiniteAnimationSpec<T> = spring(dampingRatio = 0.52f, stiffness = 380f)
    fun <T> squash(): FiniteAnimationSpec<T> = spring(dampingRatio = 0.9f, stiffness = 1400f)
    /** 0.25.0: a selection settling in — quick, critically damped, never past its target. */
    fun <T> select(): FiniteAnimationSpec<T> = spring(dampingRatio = 1f, stiffness = 1400f)
    /** Big surfaces (the preview card) open with a softer bounce than small tiles. */
    fun <T> card(): FiniteAnimationSpec<T> = spring(dampingRatio = 0.62f, stiffness = 260f)
}

/**
 * Click with squash & stretch: under the finger the thing flattens (×1.05 wide, ×0.9 tall), on
 * release it springs back through a little stretch. Light haptic on tap.
 */
internal fun Modifier.squishClick(
    enabled: Boolean = true,
    role: Role = Role.Button,
    onClick: () -> Unit
): Modifier = composed {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val down = pressed && enabled
    val sx by animateFloatAsState(if (down) 1.05f else 1f, if (down) Toon.squash<Float>() else Toon.rubber<Float>(), label = "squishX")
    val sy by animateFloatAsState(if (down) 0.9f else 1f, if (down) Toon.squash<Float>() else Toon.rubber<Float>(), label = "squishY")
    val haptic = LocalHapticFeedback.current
    this
        .graphicsLayer {
            scaleX = sx
            scaleY = sy
        }
        .clickable(interactionSource = interaction, indication = null, enabled = enabled, role = role) {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }
}

/**
 * What has already popped in on this screen. 0.23.0: lazy rows drop the tiles that scroll away and
 * compose them anew when they come back — with a fresh pop each time, so every scroll made the row
 * "boil". A screen keeps one memory ([rememberPopMemory]); a key that has played once appears as is.
 */
internal class PopMemory {
    private val played = HashSet<Any>()
    /** 0.25.0: once the screen has settled (the row was reordered), new keys appear as is, too. */
    var settled = false
    fun played(key: Any): Boolean = settled || key in played
    fun mark(key: Any) { played.add(key) }
}

internal val LocalPopMemory = staticCompositionLocalOf<PopMemory?> { null }

@Composable
internal fun rememberPopMemory(): PopMemory = remember { PopMemory() }

/**
 * Appear by popping: from half size and transparent, [order] × 45 ms after the first frame.
 * With a [key] and a [LocalPopMemory], only the first appearance of that key pops.
 */
internal fun Modifier.popIn(order: Int, key: Any? = null): Modifier = composed {
    val memory = LocalPopMemory.current
    val already = key != null && memory?.played(key) == true
    val v = remember { Animatable(if (already) 1f else 0f) }
    val lift = with(LocalDensity.current) { 22.dp.toPx() }
    LaunchedEffect(Unit) {
        if (already) return@LaunchedEffect
        if (key != null) memory?.mark(key)
        delay(45L * order.coerceIn(0, 6))
        v.animateTo(1f, Toon.pop<Float>())
    }
    graphicsLayer {
        val p = v.value
        val s = 0.5f + 0.5f * p
        scaleX = s
        scaleY = s
        alpha = p.coerceIn(0f, 1f)
        translationY = (1f - p) * lift
    }
}

/**
 * A wallpaper in a box of any size: the same crop rule as the real screen (so a tile with the
 * screen's proportions is a true miniature). [scrim] adds the contrast scrim computed for the real
 * screen — the preview shows what home will look like, the tiles show the picture itself.
 */
@Composable
internal fun WallpaperThumb(
    wallpaper: Wallpaper,
    palette: PhasePalette,
    modifier: Modifier = Modifier,
    scrim: Boolean = false
) {
    BoxWithConstraints(modifier) {
        val w = constraints.maxWidth
        val h = constraints.maxHeight
        when (wallpaper.kind) {
            Wallpaper.Kind.SKY -> Canvas(Modifier.fillMaxSize()) { drawSkyThumb(palette) }
            Wallpaper.Kind.AMOLED -> Canvas(Modifier.fillMaxSize()) { drawBlackThumb() }
            Wallpaper.Kind.IMAGE -> {
                val bitmap by rememberWallpaperBitmap(wallpaper, w, h)
                // 0.23.0: until this size is decoded, the sharpest copy already in memory (the tile's
                // when a preview card grows out of it) — the first frame is the picture, not a blank.
                val fallback = remember(wallpaper.id) { WallpaperImages.peekAny(wallpaper) }
                val screen = WallpaperScreen.size.value
                val stops by rememberWallpaperScrim(wallpaper, if (scrim) screen.width else 0, if (scrim) screen.height else 0)
                val shown = remember(wallpaper.id) { Animatable(if (bitmap != null || fallback != null) 1f else 0f) }
                LaunchedEffect(bitmap != null) { if (bitmap != null) shown.animateTo(1f, Toon.squash<Float>()) }
                Canvas(Modifier.fillMaxSize()) {
                    drawRect(Color(0xFF15132B))
                    val b = bitmap ?: fallback ?: return@Canvas
                    val a = shown.value.coerceIn(0f, 1f)
                    drawWallpaper(b, wallpaper, FilterQuality.High)
                    if (scrim) stops?.let { drawScrim(it) }
                    if (a < 1f) drawRect(Color(0xFF15132B).copy(alpha = 1f - a))
                }
            }
        }
    }
}

private fun DrawScope.drawSkyThumb(palette: PhasePalette) {
    drawRect(Brush.verticalGradient(0f to palette.zenith, 0.55f to palette.mid, 1f to palette.horizon))
    if (palette.glow.alpha > 0f) {
        drawRect(Brush.radialGradient(listOf(palette.glow, Color.Transparent), Offset(size.width / 2f, size.height * 1.05f), size.width * 0.9f))
    }
    val m = size.minDimension
    val stars = floatArrayOf(0.18f, 0.12f, 0.72f, 0.08f, 0.44f, 0.22f, 0.86f, 0.3f, 0.3f, 0.36f, 0.62f, 0.42f)
    val a = (0.35f + 0.65f * palette.starIntensity).coerceIn(0f, 1f)
    for (i in stars.indices step 2) {
        drawCircle(Color.White.copy(alpha = a * (if (i % 4 == 0) 0.9f else 0.55f)), m * 0.014f, Offset(stars[i] * size.width, stars[i + 1] * size.height))
    }
    drawCrescent(Offset(size.width * 0.7f, size.height * 0.2f), m * 0.11f, Color(0xFFFFF4D6), palette.zenith)
}

private fun DrawScope.drawBlackThumb() {
    drawRect(Ink)
    val m = size.minDimension
    drawCrescent(Offset(size.width * 0.5f, size.height * 0.42f), m * 0.16f, Color.White.copy(alpha = 0.85f), Ink)
}

/** A crescent: a disc with a disc of the background bitten out of it. */
private fun DrawScope.drawCrescent(center: Offset, radius: Float, color: Color, background: Color) {
    drawCircle(color, radius, center)
    drawCircle(background, radius * 0.86f, center + Offset(radius * 0.42f, -radius * 0.22f))
}

/** What the home screen will put on the wallpaper, in miniature: place, date, the big clock. */
class MockHome(val place: String, val date: String, val time: String, val next: String)

/**
 * The mock home over a preview card. Sizes follow the card's share of the real screen width, so the
 * type sits on the picture exactly where and as large as it will at home.
 */
@Composable
internal fun MockHomeOverlay(mock: MockHome, screenFraction: Float, modifier: Modifier = Modifier) {
    val k = screenFraction.coerceIn(0.2f, 1f)
    Column(modifier.fillMaxSize().padding(horizontal = (20 * k).dp, vertical = (18 * k).dp)) {
        Text(mock.place, color = TextPrimary, fontSize = (17 * k).sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(mock.date, color = TextSecondary, fontSize = (12.5f * k).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.weight(0.75f))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(mock.time, color = TextPrimary, fontSize = (64 * k).sp, fontWeight = FontWeight.Bold, maxLines = 1, textAlign = TextAlign.Center)
            Text(mock.next, color = TextPrimary, fontSize = (15 * k).sp, fontWeight = FontWeight.SemiBold, maxLines = 1, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.weight(1f))
        Box(Modifier.fillMaxWidth().height((44 * k).dp))
    }
}
