package com.nur.prayer.ui.home

import com.nur.prayer.i18n.tr

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/*
 * 0.26.0 «Орбита дня»: the day is a ring.
 *
 *  - midnight at the bottom, noon at the top, the prayers stand on it at their real times;
 *  - the warm arc is daylight (sunrise → maghrib), the accent arc is the prayer going on now and
 *    fills up towards the next one; the sun or the moon sits on the ring at this very minute;
 *  - turning the ring with a finger moves through the days (one day = 120° of travel, with a tick
 *    of the motor on each new day); a tap on the centre comes back to today;
 *  - a tap on a prayer opens its sheet; holding the centre (or flicking out of it) opens the
 *    sections, see OrbitMenu.
 *
 * Everything that moves every frame (rotation, bloom, intro) or every second (progress, the sun)
 * is read in draw lambdas: the ring is composed once per day, not once per second.
 */

/** Days the wheel can reach: a week back, a month ahead. */
internal object OrbitDays {
    const val MIN = -7
    const val MAX = 30
}

/** The day wheel: which day the ring shows and how far it is turned. Hoisted so home can offer «к сегодня». */
@Stable
internal class OrbitWheelState {
    private val anim = Animatable(0f)
    private var held by mutableStateOf(false)
    private var heldDeg by mutableFloatStateOf(0f)

    /** The day the ring shows, relative to today. */
    var day by mutableIntStateOf(0)
        private set

    /** Drawn rotation of the hour ticks, degrees; day × DAY_STEP_DEG at rest. Read in draw only. */
    val rotation: Float get() = if (held) heldDeg else anim.value

    fun drag(deg: Float, shownDay: Int): Boolean {
        held = true
        heldDeg = deg
        if (shownDay == day) return false
        day = shownDay
        return true
    }

    suspend fun release() {
        anim.snapTo(heldDeg)
        held = false
        anim.animateTo(day * OrbitMath.DAY_STEP_DEG, spring(dampingRatio = 0.8f, stiffness = 320f))
    }

    suspend fun goTo(target: Int) {
        held = false
        day = target.coerceIn(OrbitDays.MIN, OrbitDays.MAX)
        anim.animateTo(day * OrbitMath.DAY_STEP_DEG, tween(420, easing = FastOutSlowInEasing))
    }
}

/** Text drawn straight on the sky keeps a soft shadow, like the rest of home. */
private val Sky = Shadow(Color(0x73000000), blurRadius = 10f)
private val RingBase = Color(0x2EFFFFFF)
private val TickMinor = Color(0x33FFFFFF)
private val TickMajor = Color(0x73FFFFFF)
private val Daylight = Color(0xFFFFC98B)
private val SunCore = Color(0xFFFFE3A3)
private val MoonLight = Color(0xFFF1E9D2)

/** One prayer on the ring of the day shown. */
private data class OrbitMark(val prayer: Prayer, val time: ZonedDateTime, val angle: Float)

private fun minutesOf(t: ZonedDateTime): Float = t.hour * 60f + t.minute + t.second / 60f

/** The day [offset] days from today: from what is already computed when possible, else one more day. */
private fun dayOf(data: PrayerData, offset: Int): PrayerDay? {
    if (offset in data.days.indices) return data.days[offset]
    return runCatching {
        PrayerEngine.days(
            data.today.date.plusDays(offset.toLong()), 1, data.place.coordinates, data.place.zone, data.params
        ).firstOrNull()
    }.getOrNull()
}

@Composable
internal fun OrbitDial(
    data: PrayerData,
    now: State<ZonedDateTime>,
    palette: PhasePalette,
    menu: OrbitMenuState,
    wheel: OrbitWheelState,
    haptic: HapticFeedback,
    onOpenPrayer: (Prayer) -> Unit,
    onOpenMenu: (sticky: Boolean) -> Unit,
    onChoose: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val offset = wheel.day
    val equal = data.fajrEqualsDawn
    val day = remember(data, offset) { dayOf(data, offset) }
    val marks = remember(day, equal) {
        HomeTimeline.prayers(equal).mapNotNull { p ->
            day?.times?.get(p)?.let { OrbitMark(p, it, OrbitMath.angleOfMinutes(minutesOf(it))) }
        }
    }
    val current = HomeTimeline.current(data.window, equal)
    val next = HomeTimeline.next(data.window, equal)
    val isToday = offset == 0
    val accent = palette.accent

    // The ring draws itself in once per process; returning from a page does not replay it.
    var introDone by rememberSaveable { mutableStateOf(false) }
    val intro = remember { Animatable(if (introDone) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!introDone) {
            intro.animateTo(1f, tween(OrbitMotion.INTRO_MILLIS, easing = FastOutSlowInEasing))
            introDone = true
        }
    }
    // A new day on the ring comes in softly instead of blinking.
    val dayFade = remember { Animatable(1f) }
    val firstDay = remember { intArrayOf(offset) }
    LaunchedEffect(offset) {
        if (offset == firstDay[0]) return@LaunchedEffect
        firstDay[0] = Int.MIN_VALUE
        dayFade.snapTo(0.3f)
        dayFade.animateTo(1f, tween(OrbitMotion.DAY_FADE_MILLIS))
    }

    val openPrayer by rememberUpdatedState(onOpenPrayer)
    val openMenu by rememberUpdatedState(onOpenMenu)
    val choose by rememberUpdatedState(onChoose)
    val todayMarks by rememberUpdatedState(if (isToday) marks else emptyList())

    BoxWithConstraints(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        // Room for the labels outside the ring: wide on the sides, low above and below.
        val roomX = ui.s(64f)
        val roomY = ui.s(40f)
        val ringR = minOf((maxWidth - roomX * 2) / 2, (maxHeight - roomY * 2) / 2).coerceIn(84.dp, 168.dp)
        val gap = 10.dp
        val side = minOf(maxWidth, ringR * 2 + roomX * 2)
        val height = minOf(maxHeight, ringR * 2 + roomY * 2)

        Box(
            Modifier
                .size(side, height)
                .onGloballyPositioned { coords ->
                    val p = coords.positionInRoot()
                    menu.dialCenterInRoot = Offset(p.x + coords.size.width / 2f, p.y + coords.size.height / 2f)
                    // The geometry of the sections, here and not in pointerInput: that block starts only
                    // with the first touch, and TalkBack can open the sections before any touch.
                    with(density) {
                        menu.hubPx = ringR.toPx() * HUB
                        // Symmetric on every side and clear of the screen edge: every section the same size.
                        menu.outerPx = minOf(ringR.toPx() + 40.dp.toPx(), coords.size.width / 2f - 12.dp.toPx())
                        menu.reachPx = menu.outerPx + 22.dp.toPx()
                    }
                }
                .pointerInput(menu, wheel, ringR, roomX) {
                    val hub = ringR.toPx() * HUB
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val r0 = (down.position - c).getDistance()
                        val ringOuter = ringR.toPx() + roomX.toPx()
                        val slop = viewConfiguration.touchSlop
                        if (r0 > ringOuter) return@awaitEachGesture // the sky: nothing to do
                        // From the centre a gesture is decided by the first thing the finger does:
                        // stays still for HOLD_MILLIS → sections; moves → it is turning the ring.
                        var turnFrom: Offset? = if (r0 <= hub) null else down.position
                        if (r0 <= hub) {
                            val charging = scope.launch {
                                delay(OrbitMath.HOLD_SHOW_MILLIS)
                                menu.charge.animateTo(
                                    1f, tween((OrbitMath.HOLD_MILLIS - OrbitMath.HOLD_SHOW_MILLIS).toInt(), easing = LinearEasing)
                                )
                            }
                            var last = down.position
                            val outcome = withTimeoutOrNull(OrbitMath.HOLD_MILLIS) {
                                var out = HUB_PENDING
                                while (out == HUB_PENDING) {
                                    val change = awaitPointerEvent().changes.firstOrNull { it.id == down.id }
                                    if (change != null) last = change.position
                                    out = when {
                                        change == null -> HUB_CANCEL
                                        !change.pressed -> {
                                            change.consume()
                                            HUB_TAP
                                        }
                                        (change.position - down.position).getDistance() > slop -> HUB_MOVE
                                        else -> HUB_PENDING
                                    }
                                }
                                out
                            }
                            charging.cancel()
                            if (outcome != null) scope.launch { menu.charge.animateTo(0f, tween(160)) }
                            when (outcome) {
                                HUB_CANCEL -> return@awaitEachGesture
                                HUB_TAP -> {
                                    // A tap never opens the sections (it is what a turning finger does by
                                    // accident); on another day it brings today back, on today it reminds
                                    // how the centre works.
                                    if (wheel.day != 0) scope.launch { wheel.goTo(0) } else menu.nudge()
                                    return@awaitEachGesture
                                }
                                HUB_MOVE -> turnFrom = last
                                else -> {
                                    // Held still: the sections open under the finger and follow it.
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    openMenu(false)
                                    // A page sheet may have refused the menu: then the finger has nothing to steer.
                                    if (!menu.open) {
                                        scope.launch { menu.charge.animateTo(0f, tween(160)) }
                                        return@awaitEachGesture
                                    }
                                    var lifted = false
                                    var pointed = false
                                    while (true) {
                                        val change = awaitPointerEvent().changes.firstOrNull { it.id == down.id } ?: break
                                        change.consume()
                                        if (!change.pressed) {
                                            lifted = true
                                            break
                                        }
                                        val d = change.position - c
                                        val target = OrbitMath.target(d.x, d.y, hub, menu.reachPx, menu.count, menu.highlighted)
                                        if (target >= 0) pointed = true
                                        menu.follow(target, haptic)
                                    }
                                    val lit = menu.highlighted
                                    when {
                                        lifted && menu.finger == OrbitFinger.SECTOR && lit >= 0 -> choose(lit)
                                        // Held and let go where it started: the user is looking, keep them open.
                                        lifted && menu.finger == OrbitFinger.HUB && !pointed -> menu.stick()
                                        // Back to the centre after pointing, off past the edge, or the
                                        // gesture was taken away: taken back, nothing opens.
                                        else -> {
                                            if (lifted) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            menu.hide()
                                        }
                                    }
                                    return@awaitEachGesture
                                }
                            }
                        }
                        // The ring: turn it to move through the days, or tap a prayer.
                        val from = turnFrom ?: return@awaitEachGesture
                        val start = wheel.day
                        var prev = OrbitMath.pointerAngle(from.x - c.x, from.y - c.y)
                        var turned = 0f
                        // Coming out of the centre the finger has already moved past the slop.
                        var turning = from != down.position
                        var tapped = false
                        var tapAt = down.position
                        while (true) {
                            val change = awaitPointerEvent().changes.firstOrNull { it.id == down.id } ?: break
                            if (!change.pressed) {
                                if (turning) change.consume() else if (!change.isConsumed) {
                                    tapped = true
                                    tapAt = change.position
                                }
                                break
                            }
                            if (!turning && (change.position - down.position).getDistance() > slop) turning = true
                            if (turning) {
                                change.consume()
                                val d = change.position - c
                                // Near the very centre the angle jumps about: hold it still there.
                                if (d.getDistance() > hub * 0.35f) {
                                    val a = OrbitMath.pointerAngle(d.x, d.y)
                                    turned += OrbitMath.turn(prev, a)
                                    prev = a
                                }
                                val shown = OrbitMath.wheel(turned, start, OrbitDays.MIN, OrbitDays.MAX)
                                val dayNow = OrbitMath.dayAt(shown, start, OrbitDays.MIN, OrbitDays.MAX)
                                if (wheel.drag(start * OrbitMath.DAY_STEP_DEG + shown, dayNow)) {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                            }
                        }
                        if (turning) scope.launch { wheel.release() }
                        else if (tapped && r0 > hub) {
                            val d = tapAt - c
                            val a = OrbitMath.pointerAngle(d.x, d.y)
                            todayMarks.minByOrNull { abs(OrbitMath.turn(it.angle, a)) }
                                ?.takeIf { abs(OrbitMath.turn(it.angle, a)) <= TAP_REACH_DEG }
                                ?.let { openPrayer(it.prayer) }
                        }
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val c = center
                val r = ringR.toPx()
                // Under the open sections the ring gives way: nothing of it ghosts through them.
                val k = intro.value * (1f - menu.bloom.value.coerceIn(0f, 1f))
                if (k <= 0f) return@Canvas
                val fade = dayFade.value
                val charge = menu.charge.value
                // The base ring and 24 hour ticks, turned by the wheel — and wound up by a hold.
                drawArc(
                    RingBase, startAngle = 90f, sweepAngle = 360f * intro.value, useCenter = false,
                    topLeft = Offset(c.x - r, c.y - r), size = Size(r * 2, r * 2),
                    style = Stroke(width = 2.dp.toPx()), alpha = k
                )
                rotate(wheel.rotation + OrbitMath.CHARGE_TURN_DEG * charge + menu.spin.value, c) {
                    val tickIn = r - 9.dp.toPx()
                    for (h in 0 until 24) {
                        val a = Math.toRadians((90.0 + h * OrbitMath.TICK_DEG))
                        val major = h % 6 == 0
                        val len = if (major) 6.dp.toPx() else 3.5.dp.toPx()
                        val from = tickIn
                        val to = tickIn - len
                        drawLine(
                            if (major) TickMajor else TickMinor,
                            Offset(c.x + from * cos(a).toFloat(), c.y + from * sin(a).toFloat()),
                            Offset(c.x + to * cos(a).toFloat(), c.y + to * sin(a).toFloat()),
                            strokeWidth = (if (major) 1.6f else 1.1f).dp.toPx(), alpha = k
                        )
                    }
                }
                val sunrise = marks.firstOrNull { it.prayer == Prayer.SUNRISE }
                val maghrib = marks.firstOrNull { it.prayer == Prayer.MAGHRIB }
                if (sunrise != null && maghrib != null) {
                    drawArc(
                        Daylight, startAngle = sunrise.angle, sweepAngle = OrbitMath.sweep(sunrise.angle, maghrib.angle) * k,
                        useCenter = false, alpha = 0.45f * fade,
                        topLeft = Offset(c.x - r, c.y - r), size = Size(r * 2, r * 2),
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
                if (isToday) drawNow(data, now, accent, r, k * fade)
                marks.forEach { m ->
                    val a = Math.toRadians(m.angle.toDouble())
                    val p = Offset(c.x + r * cos(a).toFloat(), c.y + r * sin(a).toFloat())
                    val isNext = isToday && m.prayer == next
                    val isCurrent = isToday && m.prayer == current
                    when {
                        isNext -> {
                            drawCircle(accent, radius = 6.5.dp.toPx(), center = p, alpha = fade * k)
                            drawCircle(Color.White, radius = 3.dp.toPx(), center = p, alpha = fade * k)
                        }
                        isCurrent -> drawCircle(Color.White, radius = 5.5.dp.toPx(), center = p, alpha = fade * k)
                        else -> {
                            drawCircle(Color.White, radius = 3.5.dp.toPx(), center = p, alpha = 0.9f * fade * k)
                        }
                    }
                }
                // The hold charging: an arc runs clockwise round the ring from the top, a soft glow
                // under it; full circle = the sections spring out of it.
                if (charge > 0f) {
                    val box = Offset(c.x - r, c.y - r)
                    val square = Size(r * 2, r * 2)
                    drawArc(accent, 270f, 360f * charge, false, topLeft = box, size = square,
                        alpha = 0.22f * k * charge, style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round))
                    drawArc(accent, 270f, 360f * charge, false, topLeft = box, size = square,
                        alpha = k, style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round))
                }
            }

            // Labels outside the ring, spread so that close times (Сухур/Фаджр) never overlap.
            Layout(
                content = {
                    marks.forEach { m ->
                        val title = PrayerLabels.title(m.prayer)
                        val time = Format.time(m.time)
                        val strong = isToday && (m.prayer == next || m.prayer == current)
                        Column(
                            Modifier
                                .graphicsLayer { alpha = dayFade.value * intro.value * (1f - menu.bloom.value.coerceIn(0f, 1f)) }
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    enabled = isToday,
                                    role = Role.Button,
                                    onClick = { openPrayer(m.prayer) }
                                )
                                .clearAndSetSemantics {
                                    contentDescription = buildString {
                                        append("$title, $time")
                                        if (isToday && m.prayer == current) append(tr(", идёт сейчас"))
                                        if (isToday && m.prayer == next) append(tr(", следующий"))
                                    }
                                    if (isToday) {
                                        role = Role.Button
                                        onClick(label = tr("Открыть")) { openPrayer(m.prayer); true }
                                    }
                                }
                                .heightIn(min = 36.dp)
                                .padding(horizontal = 4.dp, vertical = 2.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                title, color = if (isToday && m.prayer == next) palette.accentSoft else TextPrimary,
                                fontSize = ui.t(12.5f), fontWeight = if (strong) FontWeight.Bold else FontWeight.SemiBold,
                                maxLines = 1, style = TextStyle(shadow = Sky)
                            )
                            Text(
                                time, color = TextSecondary, fontSize = ui.t(11.5f), fontWeight = FontWeight.Medium,
                                maxLines = 1, style = TextStyle(shadow = Sky)
                            )
                        }
                    }
                }
            ) { measurables, constraints ->
                val loose = Constraints(maxWidth = constraints.maxWidth, maxHeight = constraints.maxHeight)
                val placeables = measurables.map { it.measure(loose) }
                val w = constraints.maxWidth
                val h = constraints.maxHeight
                layout(w, h) {
                    if (placeables.isEmpty()) return@layout
                    val labelR = ringR.toPx() + gap.toPx()
                    val angles = FloatArray(marks.size) { marks[it].angle }
                    val extents = FloatArray(marks.size) {
                        OrbitMath.tangentExtent(angles[it], placeables[it].width.toFloat(), placeables[it].height.toFloat())
                    }
                    val spread = OrbitMath.spread(angles, extents, labelR, 4.dp.toPx())
                    placeables.forEachIndexed { i, p ->
                        val a = spread[i]
                        val rad = Math.toRadians(a.toDouble())
                        val ax = w / 2f + labelR * cos(rad).toFloat()
                        val ay = h / 2f + labelR * sin(rad).toFloat()
                        val x = (ax - OrbitMath.anchorX(a) * p.width).roundToInt().coerceIn(0, (w - p.width).coerceAtLeast(0))
                        val y = (ay - OrbitMath.anchorY(a) * p.height).roundToInt().coerceIn(0, (h - p.height).coerceAtLeast(0))
                        p.place(x, y)
                    }
                }
            }

            // The centre: what is going on now, or which day the ring shows.
            Box(
                Modifier
                    .align(Alignment.Center)
                    .size(ringR * HUB * 2f)
                    .graphicsLayer {
                        alpha = (1f - menu.bloom.value.coerceIn(0f, 1f)) * intro.value
                        // Pressed in while the hold charges.
                        val press = 1f - 0.05f * menu.charge.value
                        scaleX = press
                        scaleY = press
                    }
                    .clearAndSetSemantics {
                        role = Role.Button
                        contentDescription = if (isToday) tr("Разделы") else tr("Вернуться к сегодня")
                        onClick(label = if (isToday) tr("Открыть разделы") else tr("Вернуться к сегодня")) {
                            if (wheel.day != 0) scope.launch { wheel.goTo(0) } else openMenu(true)
                            true
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                if (isToday) TodayCentre(data, now, current, next, palette)
                else OtherDayCentre(day, offset, palette)
            }
        }
    }
}

/** Hub radius as a share of the ring radius: the centre text fits in it, the sections start at it. */
private const val HUB = 0.64f
/** How far from a prayer (in degrees of the ring) a tap on the ring still opens it. */
private const val TAP_REACH_DEG = 12f
private const val HUB_PENDING = 0
private const val HUB_TAP = 1
private const val HUB_MOVE = 2
private const val HUB_CANCEL = 3

/**
 * The prayer going on now as an arc that fills towards the next one, and the sun or the moon at this
 * minute. Reads the clock in draw: once a second only this redraws, nothing recomposes.
 */
private fun DrawScope.drawNow(data: PrayerData, now: State<ZonedDateTime>, accent: Color, r: Float, alpha: Float) {
    if (alpha <= 0f) return
    val c = center
    val w = data.window
    val t = now.value
    val from = OrbitMath.angleOfMinutes(minutesOf(w.currentStart))
    val to = OrbitMath.angleOfMinutes(minutesOf(w.nextStart))
    val total = OrbitMath.sweep(from, to).let { if (it == 0f) 360f else it }
    val done = total * w.progress(t)
    val box = Offset(c.x - r, c.y - r)
    val square = Size(r * 2, r * 2)
    drawArc(accent, from, total, false, topLeft = box, size = square, alpha = 0.26f * alpha,
        style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round))
    if (done > 0.5f) drawArc(accent, from, done, false, topLeft = box, size = square, alpha = alpha,
        style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round))
    // The sky body rides on the ring at this minute.
    val today = data.today
    val rise = today.times[Prayer.SUNRISE]
    val set = today.times[Prayer.MAGHRIB]
    val day = rise != null && set != null && !t.isBefore(rise) && t.isBefore(set)
    val a = Math.toRadians(OrbitMath.angleOfMinutes(minutesOf(t)).toDouble())
    val p = Offset(c.x + r * cos(a).toFloat(), c.y + r * sin(a).toFloat())
    val body = 8.dp.toPx()
    if (day) {
        drawCircle(SunCore, radius = body * 2.1f, center = p, alpha = 0.18f * alpha)
        drawCircle(SunCore, radius = body, center = p, alpha = alpha)
    } else {
        drawCircle(MoonLight, radius = body * 2f, center = p, alpha = 0.12f * alpha)
        val disk = Path().apply { addOval(Rect(p, body)) }
        val bite = Path().apply { addOval(Rect(Offset(p.x + body * 0.55f, p.y - body * 0.35f), body * 0.9f)) }
        drawPath(Path().apply { op(disk, bite, PathOperation.Difference) }, MoonLight, alpha = alpha)
    }
}

@Composable
private fun TodayCentre(data: PrayerData, now: State<ZonedDateTime>, current: Prayer, next: Prayer, palette: PhasePalette) {
    val ui = uiScale()
    val sky = TextStyle(shadow = Sky)
    Column(Modifier.widthIn(max = 220.dp).padding(horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            tr("Сейчас {0} · с {1}", PrayerLabels.title(current), Format.time(data.window.currentStart)),
            color = TextSecondary, fontSize = ui.t(11.5f), fontWeight = FontWeight.Medium, maxLines = 1,
            textAlign = TextAlign.Center, style = sky
        )
        CentreCountdown(data, now, next)
        Text(
            tr("до {0} · {1}", PrayerLabels.title(next), Format.time(data.window.nextStart)),
            color = palette.accentSoft, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold, maxLines = 1,
            textAlign = TextAlign.Center, style = sky
        )
    }
}

/**
 * The countdown of the centre, for the centre of the open sections: the time stays where it was
 * while the user chooses. Same size as on home, the same leaf reading the clock.
 */
@Composable
internal fun OrbitHubClock(data: PrayerData, now: State<ZonedDateTime>, palette: PhasePalette) {
    val ui = uiScale()
    val next = HomeTimeline.next(data.window, data.fajrEqualsDawn)
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        CentreCountdown(data, now, next)
        Text(
            tr("до {0} · {1}", PrayerLabels.title(next), Format.time(data.window.nextStart)),
            color = palette.accentSoft, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold, maxLines = 1,
            textAlign = TextAlign.Center
        )
    }
}

/** The only composable on home that reads the clock in composition: one text, once a second. */
@Composable
private fun CentreCountdown(data: PrayerData, now: State<ZonedDateTime>, next: Prayer) {
    val ui = uiScale()
    val text = Format.clock(data.window.remaining(now.value))
    AutoSizeText(
        text, color = TextPrimary, fontSize = ui.t(40f), minFontSize = ui.t(24f),
        fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, letterSpacing = ui.t(-0.8f),
        resizeKey = text.length,
        modifier = Modifier.fillMaxWidth().clearAndSetSemantics {
            contentDescription = tr("До {0}: {1}", PrayerLabels.title(next), text)
        }
    )
}

@Composable
private fun OtherDayCentre(day: PrayerDay?, offset: Int, palette: PhasePalette) {
    val ui = uiScale()
    val sky = TextStyle(shadow = Sky)
    val title = when (offset) {
        1 -> tr("Завтра")
        -1 -> tr("Вчера")
        else -> day?.date?.let { Format.weekday(it).replaceFirstChar { c -> c.uppercase() } } ?: ""
    }
    val fajr = day?.times?.get(Prayer.FAJR)
    Column(Modifier.widthIn(max = 220.dp).padding(horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold, maxLines = 1, style = sky)
        Text(
            fajr?.let(Format::time) ?: "—", color = TextPrimary, fontSize = ui.t(40f), fontWeight = FontWeight.Bold,
            maxLines = 1, letterSpacing = ui.t(-0.8f), style = sky
        )
        Text(
            if (day != null) "${PrayerLabels.title(Prayer.FAJR)} · ${Format.dayMonth(day.date)}" else "",
            color = palette.accentSoft, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold, maxLines = 1,
            textAlign = TextAlign.Center, style = sky
        )
    }
}
