package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * 0.23.0: the Kaaba as a small isometric cube in a white hexagonal frame — the badge that rides the
 * compass rim. Black kiswa with the gold band (hizam) across both visible faces and the gold door on
 * the right face. The top face is kept shallow (camera slightly above) so the band reads at 40 dp.
 *
 * [frame] is the frame colour, [glow] 0..1 a soft halo in [glowColor]; both read in the draw phase.
 */
@Composable
fun KaabaIcon(
    modifier: Modifier = Modifier,
    frame: Color = Color.White,
    glowColor: Color = KaabaGold,
    glow: () -> Float = { 0f }
) {
    Canvas(modifier) {
        val s = size.minDimension
        if (s < 4f) return@Canvas
        val h = s * 0.40f
        val c = center
        fun p(x: Float, y: Float) = Offset(c.x + x * h, c.y + y * h)

        val g = glow().coerceIn(0f, 1f)
        if (g > 0f) {
            drawCircle(glowColor.copy(alpha = 0.18f * g), s * 0.62f, c)
            drawCircle(glowColor.copy(alpha = 0.26f * g), s * 0.50f, c)
        }

        // Outer frame: the same hexagon, larger, with rounded joins.
        val frameScale = 1.13f
        val outer = hexagon { x, y -> p(x * frameScale, y * frameScale) }
        drawPath(hexagon { x, y -> p(x * frameScale, y * frameScale + 0.07f) }, Color.Black.copy(alpha = 0.28f))
        drawPath(outer, frame)
        drawPath(outer, frame, style = Stroke(width = s * 0.07f, join = StrokeJoin.Round))

        // Cube: T top, UR/UL upper sides, O front-top corner, LR/LL lower sides, B bottom.
        val t = p(0f, -1f)
        val ur = p(W, -UPPER)
        val ul = p(-W, -UPPER)
        val o = p(0f, 1f - 2f * UPPER)
        val lr = p(W, UPPER)
        val ll = p(-W, UPPER)
        val b = p(0f, 1f)
        quad(t, ur, o, ul, KaabaTop)
        quad(ul, o, b, ll, KaabaLeft)
        quad(o, ur, lr, b, KaabaRight)

        // Point on the left face: u along the top edge UL→O, v down the vertical edge.
        fun left(u: Float, v: Float) = Offset(
            ul.x + u * (o.x - ul.x) + v * (ll.x - ul.x),
            ul.y + u * (o.y - ul.y) + v * (ll.y - ul.y)
        )
        fun right(u: Float, v: Float) = Offset(
            o.x + u * (ur.x - o.x) + v * (b.x - o.x),
            o.y + u * (ur.y - o.y) + v * (b.y - o.y)
        )
        // Hizam: the gold band a little below the roof line.
        quad(left(0f, BAND_TOP), left(1f, BAND_TOP), left(1f, BAND_BOTTOM), left(0f, BAND_BOTTOM), KaabaGoldShade)
        quad(right(0f, BAND_TOP), right(1f, BAND_TOP), right(1f, BAND_BOTTOM), right(0f, BAND_BOTTOM), KaabaGold)
        // Door on the right face: a gold frame with the dark leaf inside.
        quad(right(0.50f, 0.38f), right(0.80f, 0.38f), right(0.80f, 0.96f), right(0.50f, 0.96f), KaabaGold)
        quad(right(0.59f, 0.47f), right(0.71f, 0.47f), right(0.71f, 0.96f), right(0.59f, 0.96f), KaabaRight)
    }
}

/** Half-width of the cube hexagon, as a share of its half-height. */
private const val W = 0.95f
/** Height of the side vertices above the centre: > 0.5 makes the roof shallower than isometric. */
private const val UPPER = 0.62f
private const val BAND_TOP = 0.10f
private const val BAND_BOTTOM = 0.27f

/** The silhouette: T(0,-1), UR(W,-U), LR(W,U), B(0,1), LL(-W,U), UL(-W,-U); O = (0, 1-2U) inside. */
private inline fun hexagon(point: (Float, Float) -> Offset): Path = Path().apply {
    val pts = listOf(
        point(0f, -1f), point(W, -UPPER), point(W, UPPER),
        point(0f, 1f), point(-W, UPPER), point(-W, -UPPER)
    )
    moveTo(pts[0].x, pts[0].y)
    for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y)
    close()
}

private fun DrawScope.quad(a: Offset, b: Offset, c: Offset, d: Offset, color: Color) {
    drawPath(Path().apply {
        moveTo(a.x, a.y); lineTo(b.x, b.y); lineTo(c.x, c.y); lineTo(d.x, d.y); close()
    }, color)
}

val KaabaGold = Color(0xFFF2B33D)
private val KaabaGoldShade = Color(0xFFD5952A)
private val KaabaTop = Color(0xFF34343C)
private val KaabaLeft = Color(0xFF17171C)
private val KaabaRight = Color(0xFF0B0B0E)
