package com.nur.prayer.ui.theme

import android.content.Context
import android.graphics.Paint
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Typeface
import com.nur.prayer.quran.MushafGlyphs

/**
 * 0.21.0. One Arabic face for everything Arabic the app shows: the Quran, basmala, duas, dhikr,
 * letters and words of the lessons, prayer names, Hijri month names and the shared ayah picture.
 *
 * The face is the King Fahd Complex «KFGQPC Uthmanic Script HAFS» — the Madinah mushaf letterforms
 * most Quran apps use. It ships as an *asset*, not as `res/font`, on purpose:
 *  - a missing or damaged file must never break the build or the launch of a prayer app, it only
 *    falls back to the system Naskh (an `R.font` reference would fail compilation instead);
 *  - `tools/fonts.py install|check` validate the exact bytes that land in the APK against every
 *    codepoint of the shipped Quran text.
 *
 * The UI in Arabic (lang = ar) keeps the system font: a mushaf face is made for scripture, not for
 * buttons and numbers.
 */
object ArabicFont {
    const val ASSET = "fonts/quran_hafs.ttf"

    /** The app's own line height for Arabic before this face existed: kept as the minimum. */
    private const val MIN_LINE = 1.65f
    /** A mushaf face with stacked marks must never be cut, nor float in a 3-line gap. */
    private const val MAX_LINE = 2.3f

    @Volatile private var appContext: Context? = null
    @Volatile private var loaded = false
    @Volatile private var face: android.graphics.Typeface? = null
    @Volatile private var familyCache: FontFamily? = null
    @Volatile private var lineCache = MIN_LINE

    /** Called once from [com.nur.prayer.NurApplication]; loads the face off the main thread. */
    fun install(context: Context) {
        appContext = context.applicationContext
        Thread({ typeface() }, "nur-arabic-font").apply { isDaemon = true; start() }
    }

    /** The mushaf face, or null when the asset is absent (previews, a stripped build). */
    fun typeface(): android.graphics.Typeface? {
        if (loaded) return face
        synchronized(this) {
            if (loaded) return face
            val context = appContext ?: return null
            face = runCatching { android.graphics.Typeface.createFromAsset(context.assets, ASSET) }.getOrNull()
            face?.let { tf ->
                // Line height from the face's own ascent and descent, so marks above a shadda and
                // below a kasra are never clipped, whatever version of the font is dropped in.
                val m = Paint().apply { typeface = tf; textSize = 100f }.fontMetrics
                lineCache = ((m.descent - m.ascent) / 100f * 1.08f).coerceIn(MIN_LINE, MAX_LINE)
            }
            loaded = true
            return face
        }
    }

    /** Compose family: the mushaf face when present, the system default otherwise. */
    val family: FontFamily
        get() {
            familyCache?.let { return it }
            val tf = typeface() ?: return FontFamily.Default
            // Compose's Typeface(android.graphics.Typeface): an already loaded face, no async loader.
            return FontFamily(Typeface(tf)).also { familyCache = it }
        }

    /** Line height as a multiple of the font size. */
    val lineHeight: Float get() { typeface(); return lineCache }

    /**
     * 0.21.1. Uthmani (Tanzil) text in the marks this face draws, see [MushafGlyphs]. Same length as
     * [text], so spans computed on the Tanzil text still fit. Without the face the text is unchanged.
     */
    fun mushaf(text: String): String = if (typeface() != null) MushafGlyphs.encode(text) else text

    /** For Canvas/StaticLayout drawing (shared pictures). */
    fun paintTypeface(): android.graphics.Typeface = typeface() ?: android.graphics.Typeface.DEFAULT

    /**
     * StaticLayout line-spacing multiplier that gives [lineHeight] for [paint]: StaticLayout multiplies
     * the font's natural height, Compose sets an absolute one; both must end up equal. Without the
     * mushaf face the picture keeps its old [fallback] spacing exactly.
     */
    fun spacingFor(paint: Paint, fallback: Float): Float {
        if (typeface() == null) return fallback
        val m = paint.fontMetrics
        val natural = (m.descent - m.ascent).takeIf { it > 0f } ?: return MIN_LINE
        return (paint.textSize * lineHeight / natural).coerceAtLeast(1f)
    }
}
