package com.nur.prayer.ui.qibla

import com.nur.prayer.i18n.tr

import android.os.SystemClock
import com.nur.prayer.ui.components.ScreenHeader
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.KaabaGold
import com.nur.prayer.ui.components.KaabaIcon
import com.nur.prayer.ui.theme.Amber
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Qibla, 0.23.0: a light instrument on the night sky — lavender-white disc, violet bezel, a quiet
 * ring of graduations with the four cardinal letters, one two-tone needle, and the Kaaba as a badge
 * that rides the bezel.
 *
 *  - Accuracy is untouched where it matters: the heading still comes from [rememberHeading] (true
 *    north via WMM, display-rotation remap, unit-vector filter), and [QiblaGuidance] alone decides
 *    "aligned". New: the hold no longer matters ([forwardAzimuth]) — flat, tilted or upright.
 *  - Search runs by itself and is short: the dial spins, a light runs round the bezel. The first
 *    usable reading does not snap: the spin decelerates onto the true bearing with one soft overshoot
 *    ([lockDialRotation]), the badge pops in and a ring pulse marks "found". From then on the needle
 *    *always* points at the Kaaba; the user turns the phone until the badge reaches the top index.
 *  - A brief sensor hiccup (a passing magnet, a blip of LOW accuracy) does not throw the dial back
 *    into search: the lock is released only if the reading stays unusable for [QiblaDial.DROP_MILLIS].
 *  - Confirmation (gold halo, gold index, one haptic) needs the calibrated policy *and* the dial,
 *    as drawn, really having the Kaaba under the index.
 */
@Composable
fun QiblaScreen(
    data: PrayerData,
    palette: PhasePalette,
    modifier: Modifier = Modifier,
    headingOverride: Heading? = null,
    onBack: (() -> Unit)? = null
) {
    val ui = uiScale()
    var showDetails by rememberSaveable { mutableStateOf(false) }
    val heading = headingOverride
        ?: rememberHeading(data.place.coordinates.latitude, data.place.coordinates.longitude)
    val qibla = data.qibla.toFloat()
    val delta = angleDelta(heading.azimuth, qibla)
    val usable = heading.available && heading.usable && delta.isFinite()
    var wasAligned by remember { mutableStateOf(false) }
    val aligned = QiblaGuidance.aligned(delta, heading.available, heading.trustworthy, wasAligned)
    SideEffect { wasAligned = aligned }

    val motion = rememberDialMotion(heading.azimuth, usable, heading.available || heading.waiting)
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(aligned && motion.locked) {
        if (aligned && motion.locked) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }
    // "Found": one ring pulse and a light tick when the spin has settled on the bearing.
    val found = remember { Animatable(0f) }
    LaunchedEffect(motion.locked) {
        if (!motion.locked) return@LaunchedEffect
        delay(QiblaDial.FOUND_DELAY_MILLIS)
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        found.snapTo(0f)
        found.animateTo(1f, tween(QiblaDial.PULSE_MILLIS))
    }
    // Draw-phase values only: none of these recomposes the screen per frame.
    val lock = animateFloatAsState(if (aligned) 1f else 0f, tween(260), label = "qiblaLock")
    val live = animateFloatAsState(
        if (usable && motion.locked) 1f else 0f,
        spring(dampingRatio = 0.55f, stiffness = 320f), label = "qiblaLive"
    )
    val rotation: () -> Float = { motion.rotation() }
    /** Screen angle of the Kaaba from the top index, 0..180, as actually drawn. */
    val offTop: () -> Float = { abs(angleDelta(0f, normalize(qibla + rotation()))) }
    /** Confirmation, scaled by how exactly the drawn badge sits under the index. */
    val gold: () -> Float = {
        val visual = 1f - ((offTop() - QiblaGuidance.ALIGN_TOLERANCE) / 3f).coerceIn(0f, 1f)
        lock.value * visual
    }
    val near: () -> Float = { live.value.coerceIn(0f, 1f) * (1f - (offTop() / 40f).coerceIn(0f, 1f)) }

    val searching = (heading.available || heading.waiting) && !(usable && motion.locked)
    val status = when {
        searching && (heading.waiting || usable) -> tr("Ищем направление…")
        // Same hysteresis as the gold index: the text never says "turn 3°" while the badge is lit.
        aligned -> tr("Направление на Каабу")
        else -> QiblaGuidance.instruction(delta, heading.available, usable, heading.trustworthy)
    }
    val hint = when {
        heading.waiting -> null
        !heading.available -> tr("Нет датчика направления — используйте азимут по карте или компасу")
        heading.interference -> tr("Отойдите от металла, магнитного чехла и динамиков.")
        !heading.trustworthy -> tr("Проведите телефоном «восьмёркой» для калибровки.")
        else -> null
    }

    val screenDensity = LocalDensity.current
    val measurer = rememberTextMeasurer()
    val letters = listOf(tr("С"), tr("В"), tr("Ю"), tr("З"))

    Column(
        modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(24f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScreenHeader(tr("Кыбла"), onBack) {
            AutoSizeText(data.place.label, color = TextSecondary, fontSize = ui.t(13f), maxLines = 2,
                textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
        }
        Spacer(Modifier.height(if (ui.compact) 14.dp else 32.dp))

        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val dialSize = min(maxWidth, min((ui.heightDp * 0.50f).dp, if (ui.compact) 320.dp else 380.dp))
            val radiusPx = with(screenDensity) { dialSize.toPx() } / 2f * QiblaDial.RADIUS
            val letterLayouts = remember(letters, radiusPx) {
                val style = TextStyle(
                    fontSize = with(screenDensity) { (radiusPx * QiblaDial.LETTER_SIZE).toSp() },
                    fontWeight = FontWeight.Bold
                )
                letters.map { measurer.measure(it, style) }
            }
            Box(
                Modifier
                    .width(dialSize)
                    .aspectRatio(1f)
                    .align(Alignment.Center)
                    .testTag("qibla-instrument")
                    .semantics {
                        stateDescription = when {
                            // Said only once the dial has really settled on the bearing, as the eye sees it.
                            aligned && motion.locked -> tr("Направление найдено")
                            usable -> tr("Поиск направления")
                            else -> tr("Нет достоверного направления")
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                // 1. The body, fixed to the screen: shadow, glow, bezel, disc, search light, top index.
                Canvas(Modifier.fillMaxSize()) {
                    val r = size.minDimension / 2f * QiblaDial.RADIUS
                    if (r < 4f) return@Canvas
                    val c = center
                    val ring = r * QiblaDial.RING_WIDTH
                    val nr = near()
                    val g = gold()
                    drawCircle(Color.Black.copy(alpha = 0.40f), r * 1.02f, Offset(c.x, c.y + r * 0.05f))
                    val glowR = r * 1.16f
                    drawCircle(
                        Brush.radialGradient(
                            0f to Color.Transparent,
                            (r * 0.97f / glowR) to lerp(Violet, KaabaGold, g).copy(alpha = 0.30f + 0.25f * nr + 0.20f * g),
                            1f to Color.Transparent,
                            center = c, radius = glowR
                        ),
                        glowR, c
                    )
                    // Bezel.
                    drawCircle(
                        Brush.linearGradient(
                            listOf(VioletLight, Violet, VioletDeep),
                            start = Offset(c.x - r, c.y - r), end = Offset(c.x + r, c.y + r)
                        ),
                        r - ring / 2f, c, style = Stroke(ring)
                    )
                    drawCircle(Color.White.copy(alpha = 0.18f), r - density, c, style = Stroke(1.2f * density))
                    // Disc, with the thin white lip between it and the bezel.
                    val disc = r - ring
                    drawCircle(
                        Brush.radialGradient(
                            listOf(DiscCore, DiscMid, DiscEdge),
                            center = Offset(c.x - disc * 0.18f, c.y - disc * 0.22f), radius = disc * 1.25f
                        ),
                        disc, c
                    )
                    drawCircle(Color.White, disc, c, style = Stroke(2f * density))
                    drawCircle(VioletInk.copy(alpha = 0.10f), disc - 2f * density, c, style = Stroke(1f * density))

                    val sweep = motion.sweep()
                    if (sweep != null) {
                        rotate(sweep, c) {
                            drawCircle(
                                Brush.sweepGradient(
                                    0f to Color.Transparent,
                                    0.62f to Color.Transparent,
                                    1f to Color.White.copy(alpha = 0.85f),
                                    center = c
                                ),
                                r - ring / 2f, c, style = Stroke(ring * 0.55f, cap = StrokeCap.Round)
                            )
                        }
                    }
                    // "Found": a ring that leaves the bezel and fades.
                    val f = found.value
                    if (f > 0f && f < 1f) {
                        drawCircle(
                            VioletLight.copy(alpha = 0.55f * (1f - f)),
                            r * (1f + 0.16f * f), c, style = Stroke(ring * (1f - 0.6f * f))
                        )
                    }
                    // The phone's index: a short bar across the top of the bezel (the badge docks on it).
                    drawLine(
                        lerp(Color.White, KaabaGold, g),
                        Offset(c.x, c.y - r + ring * 0.18f), Offset(c.x, c.y - r + ring * 0.82f),
                        strokeWidth = 3f * density, cap = StrokeCap.Round
                    )
                }

                // 2. The world: graduations, letters, the needle and the pointer. Turns with the heading.
                Box(Modifier.fillMaxSize().graphicsLayer {
                    rotationZ = rotation()
                    alpha = if (heading.available || heading.waiting) 0.72f + 0.28f * live.value.coerceIn(0f, 1f) else 0.6f
                }) {
                    Canvas(Modifier.fillMaxSize()) {
                        val r = size.minDimension / 2f * QiblaDial.RADIUS
                        if (r < 4f) return@Canvas
                        val c = center
                        for (i in 0 until QiblaDial.TICKS) {
                            val a = Math.toRadians(i * 360.0 / QiblaDial.TICKS - 90.0)
                            val outer = r * QiblaDial.TICK_OUTER
                            val inner = r * QiblaDial.TICK_INNER
                            drawLine(
                                color = VioletInk,
                                start = Offset(c.x + outer * cos(a).toFloat(), c.y + outer * sin(a).toFloat()),
                                end = Offset(c.x + inner * cos(a).toFloat(), c.y + inner * sin(a).toFloat()),
                                strokeWidth = 1.6f * density,
                                cap = StrokeCap.Round
                            )
                        }
                        // Cardinal letters, set radially like the bezel of a real compass.
                        letterLayouts.forEachIndexed { k, layout ->
                            rotate(k * 90f, c) {
                                val w = layout.size.width.toFloat()
                                val h = layout.size.height.toFloat()
                                drawText(
                                    layout,
                                    color = if (k == 0) VioletDeep else VioletInk,
                                    topLeft = Offset(c.x - w / 2f, c.y - r * QiblaDial.LETTER_RADIUS - h / 2f)
                                )
                            }
                        }
                        rotate(qibla, c) {
                            val g = gold()
                            // Pointer under the badge, pointing at the centre.
                            val tip = r * QiblaDial.POINTER_TIP
                            val base = r * QiblaDial.POINTER_BASE
                            val half = r * QiblaDial.POINTER_HALF
                            drawPath(Path().apply {
                                moveTo(c.x, c.y - tip)
                                lineTo(c.x - half, c.y - base)
                                lineTo(c.x + half, c.y - base)
                                close()
                            }, lerp(Violet, KaabaGold, g))
                            // Needle: the deep half points at the Kaaba, the pale half trails behind.
                            val nTip = r * QiblaDial.NEEDLE_TIP
                            val nTail = r * QiblaDial.NEEDLE_TAIL
                            val nHalf = r * QiblaDial.NEEDLE_HALF
                            drawPath(Path().apply {
                                moveTo(c.x, c.y + nTail)
                                lineTo(c.x - nHalf, c.y)
                                lineTo(c.x + nHalf, c.y)
                                close()
                            }, Brush.verticalGradient(
                                listOf(NeedlePale.copy(alpha = 0.85f), NeedlePale.copy(alpha = 0.15f)),
                                startY = c.y, endY = c.y + nTail
                            ))
                            drawPath(Path().apply {
                                moveTo(c.x, c.y - nTip)
                                lineTo(c.x - nHalf, c.y)
                                lineTo(c.x + nHalf, c.y)
                                close()
                            }, Brush.verticalGradient(
                                listOf(lerp(Violet, KaabaGold, g * 0.85f), lerp(VioletDeep, VioletInk, 0.5f)),
                                startY = c.y - nTip, endY = c.y
                            ))
                        }
                    }
                    // The Kaaba rides the bezel at the bearing and stays upright for the reader.
                    Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = qibla }) {
                        val kaaba = dialSize / 2 * QiblaDial.RADIUS * QiblaDial.BADGE_SIZE
                        val top = dialSize / 2 * (1f - QiblaDial.RADIUS * QiblaDial.BADGE_ORBIT) - kaaba / 2
                        KaabaIcon(
                            frame = Color.White,
                            glow = gold,
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = top)
                                .size(kaaba)
                                .graphicsLayer {
                                    rotationZ = -rotation() - qibla
                                    val l = live.value
                                    val pop = if (heading.available || heading.waiting) 0.82f + 0.18f * l else 1f
                                    scaleX = pop
                                    scaleY = pop
                                    alpha = if (heading.available || heading.waiting) 0.55f + 0.45f * l.coerceIn(0f, 1f) else 1f
                                }
                                .semantics { contentDescription = tr("Кааба — направление кыблы") }
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        // One short line; the slot keeps its height so the dial never moves.
        Box(Modifier.fillMaxWidth().heightIn(min = 24.dp), contentAlignment = Alignment.Center) {
            AutoSizeText(status, color = if (aligned) KaabaGold else TextSecondary, fontSize = ui.t(15f),
                maxLines = 2, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
        if (hint != null) {
            Text(hint, color = Amber, fontSize = ui.t(12f), lineHeight = ui.t(18f),
                textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
        }

        Spacer(Modifier.height(28.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(SurfaceEdge))
        Row(
            Modifier.fillMaxWidth().heightIn(min = 56.dp)
                .clickable(role = Role.Button, onClick = { showDetails = !showDetails })
                .semantics { stateDescription = if (showDetails) tr("Развёрнуто") else tr("Свёрнуто") },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(tr("Точность и датчики"), color = TextSecondary, fontSize = ui.t(14f), modifier = Modifier.weight(1f))
            Text(if (showDetails) "−" else "+", color = palette.accent, fontSize = ui.t(22f))
        }
        AnimatedVisibility(showDetails) {
            Column {
                InfoRow(tr("Азимут кыблы"), QiblaGuidance.degrees(qibla))
                InfoRow(tr("До Каабы"), tr("{0} км", data.kaabaDistanceKm.roundToInt()))
                InfoRow(tr("Курс устройства"), if (heading.available) QiblaGuidance.degrees(heading.azimuth) else "—")
                InfoRow(tr("Магнитный курс"), if (heading.available) QiblaGuidance.degrees(heading.magneticAzimuth) else "—")
                InfoRow(tr("Магнитная поправка"), "${heading.declination.roundToInt()}°")
                InfoRow(tr("Наклон"), if (heading.available) "${heading.tiltDegrees.roundToInt()}°" else "—")
                InfoRow(tr("Магнитное поле"), if (heading.fieldStrength > 0f) tr("{0} мкТл", heading.fieldStrength.roundToInt()) else "—")
                InfoRow(tr("Калибровка"), when (heading.accuracy) {
                    3 -> tr("Высокая")
                    2 -> tr("Средняя")
                    1 -> tr("Низкая")
                    else -> tr("Не определена")
                })
                InfoRow(tr("Датчики"), when (heading.source) {
                    HeadingSource.FUSED -> tr("Гироскоп, магнитометр")
                    HeadingSource.GEOMAGNETIC -> tr("Магнитометр, акселерометр")
                    HeadingSource.RAW -> tr("Сырые показания")
                    HeadingSource.NONE -> tr("Недоступны")
                })
                Text(tr("Азимут от истинного севера, магнитная поправка учтена. Держите телефон как удобно — плашмя или вертикально."),
                    color = TextTertiary, fontSize = ui.t(12f), lineHeight = ui.t(18f), modifier = Modifier.padding(top = 12.dp))
            }
        }
        Spacer(Modifier.height(LocalDockInset.current))
    }
}

internal object QiblaDial {
    /** Bezel outer radius as a share of half the instrument box (room for the badge and the glow). */
    const val RADIUS = 0.86f
    /** Everything below is a share of that radius. */
    const val RING_WIDTH = 0.072f
    const val TICKS = 24
    const val TICK_OUTER = 0.82f
    const val TICK_INNER = 0.775f
    const val LETTER_RADIUS = 0.655f
    const val LETTER_SIZE = 0.105f
    const val NEEDLE_TIP = 0.37f
    const val NEEDLE_TAIL = 0.39f
    const val NEEDLE_HALF = 0.095f
    const val POINTER_TIP = 0.735f
    const val POINTER_BASE = 0.815f
    const val POINTER_HALF = 0.042f
    /** Badge centre sits on the bezel; badge edge. */
    const val BADGE_ORBIT = 0.965f
    const val BADGE_SIZE = 0.36f

    /** One slow revolution of the dial while searching; the light on the bezel runs faster. */
    const val SPIN_MILLIS = 2400
    const val SWEEP_MILLIS = 1100
    /** The search is shown at least this long, even when the sensors are ready at once. */
    const val SEARCH_MIN_MILLIS = 1000L
    /** Retargets during this window keep the soft lock spring instead of the tracking one. */
    const val LOCK_MILLIS = 1200L
    const val LOCK_MIN_TRAVEL = 120f
    /** The lock is released only after the reading has stayed unusable this long. */
    const val DROP_MILLIS = 1500L
    /** "Found" pulse: when the lock spring has mostly settled, and how long the ring lives. */
    const val FOUND_DELAY_MILLIS = 650L
    const val PULSE_MILLIS = 700

    /** Degrees per second of the search spin (negative: counter-clockwise). */
    const val SPIN_VELOCITY = -360f * 1000f / SPIN_MILLIS
}

private val Violet = Color(0xFF7C3AED)
private val VioletLight = Color(0xFF9F6BFF)
private val VioletDeep = Color(0xFF4C1D95)
private val VioletInk = Color(0xFF34137A)
private val NeedlePale = Color(0xFFC4B5FD)
private val DiscCore = Color(0xFFFFFFFF)
private val DiscMid = Color(0xFFF4F1FD)
private val DiscEdge = Color(0xFFE6E0F8)

/**
 * The dial's motion: auto-search spin → lock → tracking, and back to search whenever trust is lost.
 * All values are read in draw lambdas. Pure policy (where to stop) lives in [lockDialRotation] and
 * [nearestDialRotation].
 *
 * Without a usable reading the dial never holds a bearing for long — not even the last good one,
 * which would look like a valid direction. After [QiblaDial.DROP_MILLIS] it spins again:
 * unmistakably "searching", and confirmation is impossible because it needs [QiblaGuidance.aligned].
 */
internal class DialMotion {
    val tracked = Animatable(0f)
    var target by mutableFloatStateOf(0f)
    /** True only while tracking a usable reading. */
    var locked by mutableStateOf(false)
    var lockUntil = 0L
    var launchVelocity = 0f
    /** The search spin continues from wherever the dial was, without a jump. */
    var spinBase = 0f
    var wasSearching = false
    /** Present only while composed in the search phase. */
    var spin: State<Float>? = null
    var sweepState: State<Float>? = null
    var sweeping = false

    fun searchAngle(): Float = spinBase + (spin?.value ?: 0f)
    /**
     * Between the last search frame and the lock (one composition: `ready` flipped, the lock effect
     * has not run yet) the dial holds the spin's last angle — it used to snap to 0° for that frame.
     */
    fun rotation(): Float = if (locked) tracked.value else searchAngle()
    fun sweep(): Float? = if (sweeping) sweepState?.value else null
}

@Composable
private fun rememberDialMotion(azimuth: Float, usable: Boolean, available: Boolean): DialMotion {
    val motion = remember { DialMotion() }
    var searchShown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(QiblaDial.SEARCH_MIN_MILLIS)
        searchShown = true
    }
    // A blip of untrust (a passing magnet, one LOW accuracy report) must not throw a locked dial
    // back into search; only a reading that stays unusable releases it.
    var steady by remember { mutableStateOf(usable) }
    LaunchedEffect(usable) {
        if (usable) {
            steady = true
        } else {
            if (motion.locked) delay(QiblaDial.DROP_MILLIS)
            steady = false
        }
    }
    val ready = steady && (usable || motion.locked) && searchShown
    val searching = available && !ready

    if (searching && !motion.wasSearching) motion.spinBase = if (motion.locked) motion.tracked.value else 0f
    motion.wasSearching = searching
    motion.sweeping = searching
    if (searching) {
        val transition = rememberInfiniteTransition(label = "qiblaSearch")
        motion.sweepState = transition.animateFloat(
            0f, 360f, infiniteRepeatable(tween(QiblaDial.SWEEP_MILLIS, easing = LinearEasing)), label = "qiblaSweep"
        )
        motion.spin = transition.animateFloat(
            0f, -360f, infiniteRepeatable(tween(QiblaDial.SPIN_MILLIS, easing = LinearEasing)), label = "qiblaSpin"
        )
    }

    // Lock on every usable reading that follows a search; drop the lock once trust is really gone.
    LaunchedEffect(ready) {
        if (!ready) {
            motion.locked = false
            return@LaunchedEffect
        }
        val spun = motion.spin != null
        val from = if (spun) motion.searchAngle() else 0f
        motion.launchVelocity = if (spun) QiblaDial.SPIN_VELOCITY else 0f
        motion.tracked.snapTo(from)
        motion.target = lockDialRotation(from, azimuth, QiblaDial.LOCK_MIN_TRAVEL)
        motion.lockUntil = SystemClock.uptimeMillis() + QiblaDial.LOCK_MILLIS
        motion.locked = true
    }
    // Tracking: every fresh reading moves the unwrapped target by the short way round.
    // During the grace period after a blip the dial holds still rather than following a bad reading.
    LaunchedEffect(azimuth, ready, usable) {
        if (ready && usable && motion.locked) motion.target = nearestDialRotation(motion.target, azimuth)
    }
    // One driver for both phases. A new target retargets the running spring and keeps its velocity.
    LaunchedEffect(motion) {
        snapshotFlow { motion.target to motion.locked }.collectLatest { (target, locked) ->
            if (!locked) return@collectLatest
            val locking = SystemClock.uptimeMillis() < motion.lockUntil
            val velocity = if (motion.launchVelocity != 0f) motion.launchVelocity else motion.tracked.velocity
            motion.launchVelocity = 0f
            motion.tracked.animateTo(
                target,
                if (locking) spring(dampingRatio = 0.62f, stiffness = 40f)
                else spring(dampingRatio = 0.92f, stiffness = 260f),
                initialVelocity = velocity
            )
        }
    }
    return motion
}

@Composable
private fun InfoRow(label: String, value: String) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextSecondary, fontSize = ui.t(13f), modifier = Modifier.weight(1f))
        Spacer(Modifier.width(16.dp))
        AutoSizeText(value, color = TextPrimary, fontSize = ui.t(14f), maxLines = 2,
            textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}
