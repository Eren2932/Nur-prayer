package com.nur.prayer.quran

/**
 * 0.21.1. Tanzil Uthmani text -> the mark encoding of the KFGQPC HAFS face.
 *
 * Both encode the same Madinah mushaf, but not every sign the same way:
 *  - Tanzil writes the ordinary sukun as U+0652 and the «silent letter» circle as U+06DF (أُو۟لَٰٓئِكَ);
 *  - the KFGQPC face draws the mushaf sukun (the khah head ۡ) at U+06E1 and the circle at U+0652. Its
 *    U+06DF is a wide base placeholder, not a mark: drawn as is, a box sits inside 3988 words.
 *  - U+06E3 (small low seen, 52:37) and U+06EB (ishmam, 12:11) have no glyph in the face at all, only
 *    the same placeholder; they become a zero-width joiner, which keeps the letters joined and draws
 *    nothing (two signs in the whole Quran, listed in QURAN_SOURCES.md).
 *
 * The map is char-for-char, so the text keeps its length: tajweed spans computed on the Tanzil text
 * (the rules read U+06DF) apply to the encoded one unchanged. The data stays in Tanzil encoding, the
 * only one that can be checked against the source; this is applied at the last step, only when the
 * mushaf face is the one drawing (the system Naskh draws the Tanzil encoding correctly).
 * tools/fonts.py MUSHAF_GLYPHS mirrors the table; tools/fonts.py check proves every mark of the
 * encoded Quran is a real zero-width mark of the face.
 */
object MushafGlyphs {
    private const val SUKUN = '\u0652'
    private const val SUKUN_KHAH = '\u06E1'
    private const val ROUND_ZERO = '\u06DF'
    private const val LOW_SEEN = '\u06E3'
    private const val ISHMAM = '\u06EB'
    private const val ZWJ = '\u200D'

    fun encode(text: String): String {
        if (text.none { it == SUKUN || it == ROUND_ZERO || it == LOW_SEEN || it == ISHMAM }) return text
        val out = CharArray(text.length)
        for (i in text.indices) {
            out[i] = when (val c = text[i]) {
                SUKUN -> SUKUN_KHAH
                ROUND_ZERO -> SUKUN
                LOW_SEEN, ISHMAM -> ZWJ
                else -> c
            }
        }
        return String(out)
    }
}
