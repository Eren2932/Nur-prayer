package com.nur.prayer.ui.quran

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.AyahSelection
import com.nur.prayer.quran.AyahShareText
import com.nur.prayer.quran.QuranAyah
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.quran.QuranRepository
import com.nur.prayer.quran.QuranStore
import com.nur.prayer.quran.QuranTranslation
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.theme.ArabicFont
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.launch

/*
 * 0.18.2 — the actions of selected ayat.
 *
 * 0.18.0 opened a row of chips under the pressed ayah. With a long ayah, a large Arabic size and a
 * translation the row landed below the screen, the reader had to scroll for it, and the list jumped
 * as it unfolded. Now the actions live in one panel docked at the bottom of the reader: always at
 * the same place under the thumb, whatever the length of the ayah or the size of the type. The
 * list makes room for it and brings the selected ayah into view above it (see SurahPage).
 *
 * The selection is a range (AyahSelection): a long press picks an ayah, a tap on another one
 * stretches the selection to it — copy, share and the picture then take the whole passage.
 */

/** Ayat a picture can hold and still be read on a phone. */
private const val IMAGE_MAX = 7

private enum class AyahAction { COPY, SHARE, IMAGE, BOOKMARK, REVIEW }

@Composable
internal fun BoxScope.AyahActionPanel(
    selection: AyahSelection?,
    store: QuranStore,
    lang: String,
    colors: QuranColors,
    reviewed: Set<Int>,
    onReview: (Int, Int) -> Boolean,
    onClear: () -> Unit,
    onHeight: (Int) -> Unit
) {
    // The panel slides out with the last selection on it, not with an empty plate.
    val shown = remember { arrayOfNulls<AyahSelection>(1) }
    if (selection != null) shown[0] = selection
    AnimatedVisibility(
        visible = selection != null,
        enter = slideInVertically(NurMotion.gentle()) { h: Int -> h } + fadeIn(tween(140)),
        exit = slideOutVertically(NurMotion.snappy()) { h: Int -> h } + fadeOut(tween(120)),
        modifier = Modifier.align(Alignment.BottomCenter)
    ) {
        val sel = shown[0] ?: return@AnimatedVisibility
        PanelBody(sel, store, lang, colors, reviewed, onReview, onClear, Modifier.onSizeChanged { onHeight(it.height) })
    }
}

@Composable
private fun PanelBody(
    sel: AyahSelection,
    store: QuranStore,
    lang: String,
    colors: QuranColors,
    reviewed: Set<Int>,
    onReview: (Int, Int) -> Boolean,
    onClear: () -> Unit,
    modifier: Modifier
) {
    val ui = uiScale()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val surah = QuranMath.surah(sel.surah)
    val translation = store.translation(lang)
    val title = QuranMath.title(surah, lang)
    // The page that shows the selection has its surah loaded; the cache answers without IO.
    val all = QuranRepository.get(context).cached(sel.surah).orEmpty()
    val ayat = all.filter { it.number in sel.from..sel.to }

    val copiedOne = tr("Аят скопирован")
    val copiedMany = tr("Аяты скопированы")
    val addedOne = tr("Аят добавлен в повторение")
    val alreadyOne = tr("Аят уже в повторении")

    val anchorKey = sel.surah * 1000 + sel.from
    val bookmarked = sel.single && store.isBookmarked(anchorKey)
    val allReviewed = ayat.isNotEmpty() && ayat.all { it.key in reviewed }

    fun act(action: AyahAction) {
        if (ayat.isEmpty()) return
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        when (action) {
            AyahAction.COPY -> {
                clipboard.setText(AnnotatedString(AyahShareText.build(ayat, title, translation)))
                Toast.makeText(context, if (sel.single) copiedOne else copiedMany, Toast.LENGTH_SHORT).show()
                onClear()
            }
            AyahAction.SHARE -> {
                shareAyahText(context, AyahShareText.build(ayat, title, translation))
                onClear()
            }
            AyahAction.IMAGE -> {
                val card = ayahCard(ayat, title, translation, colors)
                onClear()
                scope.launch { AyahImageShare.share(context, card) }
            }
            // The bookmark stays in the panel: the star answers at once, the reader may go on.
            AyahAction.BOOKMARK -> store.toggleBookmark(anchorKey)
            AyahAction.REVIEW -> {
                val added = ayat.count { onReview(it.surah, it.number) }
                val message = when {
                    !sel.single -> tr("Добавлено в повторение: {0}", added)
                    added > 0 -> addedOne
                    else -> alreadyOne
                }
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                onClear()
            }
        }
    }

    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier.widthIn(max = READER_MAX_WIDTH).fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = ui.s(10f), vertical = 10.dp)
            .clip(shape).background(colors.bar)
            .border(1.dp, colors.hairline, shape)
            // Taps on the plate stay on it and never reach the text under it.
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .padding(start = ui.s(16f), end = 8.dp, top = 10.dp, bottom = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = sel.reference,
                    transitionSpec = {
                        (fadeIn(tween(160)) + slideInVertically(tween(200)) { h: Int -> h / 3 }) togetherWith
                            (fadeOut(tween(120)) + slideOutVertically(tween(160)) { h: Int -> -h / 3 })
                    },
                    label = "ayahSelectionRef"
                ) { ref ->
                    Text("$title · $ref", color = colors.text, fontSize = ui.t(16f), fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                // The hint says why a button went grey or a tap stopped stretching, instead of
                // leaving the reader to guess.
                val hint = when {
                    sel.single -> tr("Нажмите на другой аят, чтобы выделить несколько")
                    sel.count >= AyahSelection.MAX -> tr("Выбрано аятов: {0} — больше за раз нельзя", sel.count)
                    sel.count > IMAGE_MAX -> tr("Выбрано аятов: {0} · картинкой — до {1}", sel.count, IMAGE_MAX)
                    else -> tr("Выбрано аятов: {0}", sel.count)
                }
                Text(
                    hint,
                    color = colors.textTertiary, fontSize = ui.t(12f), lineHeight = ui.t(16f), maxLines = 2
                )
            }
            RoundIconButton(GlyphKind.CLOSE, tr("Закрыть"), onClear, size = 40.dp, tint = colors.textSecondary, background = colors.inset)
        }
        Gap(10f)
        val actions = listOf(
            ActionSpec(AyahAction.COPY, tr("Копировать"), enabled = true, active = false),
            ActionSpec(AyahAction.SHARE, tr("Поделиться"), enabled = true, active = false),
            ActionSpec(AyahAction.IMAGE, tr("Картинкой"), enabled = sel.count <= IMAGE_MAX, active = false),
            ActionSpec(AyahAction.BOOKMARK, if (bookmarked) tr("В закладках") else tr("В закладки"), enabled = sel.single, active = bookmarked),
            ActionSpec(AyahAction.REVIEW, if (allReviewed) tr("В повторении") else tr("В повторение"), enabled = true, active = allReviewed)
        )
        // Five in a row while each keeps ~64dp; on a narrow phone or with a large font, 3 + 2.
        BoxWithConstraints(Modifier.fillMaxWidth().padding(end = 8.dp)) {
            val perRow = if (maxWidth / actions.size >= 64.dp && !ui.largeFont) actions.size else 3
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (row in actions.chunked(perRow)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (spec in row) ActionButton(spec, colors, Modifier.weight(1f)) { act(spec.action) }
                        // A short last row keeps the cell width of the full ones.
                        repeat(perRow - row.size) { Box(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

private class ActionSpec(val action: AyahAction, val label: String, val enabled: Boolean, val active: Boolean)

@Composable
private fun ActionButton(spec: ActionSpec, colors: QuranColors, modifier: Modifier, onClick: () -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(18.dp)
    val plate by animateColorAsState(
        if (spec.active) colors.accent.copy(alpha = 0.24f) else colors.raised, tween(200), label = "ayahActionPlate"
    )
    val tint = when {
        !spec.enabled -> colors.textTertiary.copy(alpha = 0.5f)
        spec.active -> colors.accentText
        else -> colors.text
    }
    // A state that flips (bookmark, repetition) answers with a small bounce of its icon.
    val pop by animateFloatAsState(if (spec.active) 1f else 0f, NurMotion.bouncy(), label = "ayahActionPop")
    Column(
        modifier.heightIn(min = 64.dp).clip(shape).background(plate)
            .pressClick(enabled = spec.enabled, scaleTo = 0.94f, shape = shape, onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Canvas(Modifier.size(22.dp).scale(1f + 0.12f * pop * (1f - pop) * 4f)) { drawAction(spec.action, tint, spec.active) }
        Gap(6f)
        Text(spec.label, color = tint, fontSize = ui.t(11.5f), lineHeight = ui.t(14f), fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

/** Line icons in the weight of the app's glyphs, drawn in a 24-unit box. */
private fun DrawScope.drawAction(action: AyahAction, color: Color, filled: Boolean) {
    val u = size.minDimension / 24f
    val stroke = Stroke(width = 1.8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(x * u, y * u)
    when (action) {
        AyahAction.COPY -> {
            drawRoundRect(color, p(8f, 8f), Size(12f * u, 13f * u), CornerRadius(2.5f * u), style = stroke)
            val back = Path().apply {
                moveTo(5f * u, 16f * u); lineTo(5f * u, 5.5f * u)
                quadraticBezierTo(5f * u, 3f * u, 7.5f * u, 3f * u); lineTo(15f * u, 3f * u)
            }
            drawPath(back, color, style = stroke)
        }
        AyahAction.SHARE -> {
            drawLine(color, p(8f, 11f), p(16f, 6.5f), stroke.width, StrokeCap.Round)
            drawLine(color, p(8f, 13f), p(16f, 17.5f), stroke.width, StrokeCap.Round)
            drawCircle(color, 2.8f * u, p(6f, 12f), style = stroke)
            drawCircle(color, 2.8f * u, p(18f, 5.5f), style = stroke)
            drawCircle(color, 2.8f * u, p(18f, 18.5f), style = stroke)
        }
        AyahAction.IMAGE -> {
            drawRoundRect(color, p(3f, 4.5f), Size(18f * u, 15f * u), CornerRadius(3f * u), style = stroke)
            val hills = Path().apply {
                moveTo(4f * u, 17.5f * u); lineTo(9.5f * u, 12f * u); lineTo(13f * u, 15.5f * u)
                lineTo(15.5f * u, 13f * u); lineTo(20f * u, 17.5f * u)
            }
            drawPath(hills, color, style = stroke)
            drawCircle(color, 1.7f * u, p(15.5f, 9f))
        }
        AyahAction.BOOKMARK -> {
            val ribbon = Path().apply {
                moveTo(6f * u, 4.5f * u); quadraticBezierTo(6f * u, 3f * u, 7.5f * u, 3f * u)
                lineTo(16.5f * u, 3f * u); quadraticBezierTo(18f * u, 3f * u, 18f * u, 4.5f * u)
                lineTo(18f * u, 21f * u); lineTo(12f * u, 16.5f * u); lineTo(6f * u, 21f * u); close()
            }
            if (filled) drawPath(ribbon, color)
            drawPath(ribbon, color, style = stroke)
        }
        AyahAction.REVIEW -> {
            // A circle that closes on itself: the ayah comes back for repetition.
            drawArc(color, 40f, 290f, false, p(4f, 4f), Size(16f * u, 16f * u), style = stroke)
            val head = Path().apply { moveTo(20.5f * u, 4.5f * u); lineTo(19.6f * u, 10f * u); lineTo(14.4f * u, 8.6f * u) }
            drawPath(head, color, style = stroke)
            if (filled) {
                val tick = Path().apply { moveTo(8.8f * u, 12.2f * u); lineTo(11f * u, 14.4f * u); lineTo(15.4f * u, 9.8f * u) }
                drawPath(tick, color, style = stroke)
            }
        }
    }
}

/** The picture of one ayah or a short passage, in the colours of the reading surface. */
private fun ayahCard(ayat: List<QuranAyah>, title: String, translation: QuranTranslation?, colors: QuranColors): AyahCard {
    val many = ayat.size > 1
    // 0.21.1: the picture shows the mushaf spelling (Uthmani); copied text stays simple, see AyahSelection.
    val arabic = ayat.joinToString(" ") { ArabicFont.mushaf(it.display) + " \uFD3F" + QuranMath.arabicDigits(it.number) + "\uFD3E" }
    val meaning = ayat.mapNotNull { a -> a.translation(translation)?.let { if (many) "(${a.number}) $it" else it } }
        .joinToString(" ").ifBlank { null }
    val first = ayat.first()
    val ref = if (many) "${first.surah}:${first.number}–${ayat.last().number}" else "${first.surah}:${first.number}"
    return AyahCard(arabic = arabic, translation = meaning, caption = "$title · $ref", colors = colors)
}

internal fun shareAyahText(context: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    runCatching { context.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
