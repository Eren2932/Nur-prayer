package com.nur.prayer.ui.home

import com.nur.prayer.i18n.tr

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.PillButton
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/*
 * 0.26.0 home: «Орбита дня». No curtain to pull, no list, no capsule.
 *
 *  - the ring of the day (OrbitDial): the prayers at their real times, the one going on now as an
 *    arc filling towards the next, the sun or the moon at this minute;
 *  - turn the ring → other days; tap the centre → back to today;
 *  - tap a prayer → its sheet; hold the centre still → the sections (OrbitMenu): hold, slide,
 *    let go. Back to the centre or off the edge before letting go → nothing opens.
 *  - the line under the ring always says how: it never goes away (0.26.1), and while the sections
 *    are open it follows the finger («отпустите — откроется», «отпустите — отмена»).
 *
 * Back closes the sheet, then the sections, then the other day; from today it leaves the app.
 */

/** Text drawn straight on the sky gets a soft shadow so it survives the light horizon of noon. */
private val OnSky = Shadow(Color(0x73000000), blurRadius = 10f)
private val SheetScrim = Color(0x8C000000)
private val TodayPill = Color(0x33FFFFFF)

@Composable
fun HomeScreen(
    data: PrayerData,
    now: State<ZonedDateTime>,
    palette: PhasePalette,
    actions: AppActions,
    notificationsAllowed: Boolean,
    exactAlarmsAllowed: Boolean,
    onOpenCity: () -> Unit,
    /** The day chip under the header: the month calendar, opened plainly. */
    onOpenSchedule: () -> Unit,
    /** A section chosen on the orbit, and the middle of its sector in root coordinates: the page grows from it. */
    onOpenSection: (HomeSection, Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    // The open sheet survives rotation and process death; stored by name, validated on read.
    var sheetName by rememberSaveable { mutableStateOf<String?>(null) }
    val sheetPrayer = sheetName?.let { name -> Prayer.entries.firstOrNull { it.name == name } }

    // Not saveable on purpose: open sections or another day must not greet the user after a return.
    val menu = remember { OrbitMenuState() }
    val wheel = remember { OrbitWheelState() }

    BackHandler(enabled = sheetPrayer != null) { sheetName = null }
    BackHandler(enabled = sheetPrayer == null && menu.open) { menu.hide() }
    BackHandler(enabled = sheetPrayer == null && !menu.open && wheel.day != 0) { scope.launch { wheel.goTo(0) } }

    // The hold has wound the ring up; on open it spins on and the sections unfurl out of it with a
    // soft spring. On close everything unwinds together; the chosen one stays lit while they fold.
    LaunchedEffect(menu.open) {
        if (menu.open) {
            launch { menu.charge.animateTo(1f, tween(120)) }
            launch {
                menu.spin.animateTo(OrbitMotion.SPIN_DEG, tween(OrbitMotion.SPIN_MILLIS, easing = FastOutSlowInEasing))
            }
            menu.bloom.animateTo(1f, spring(dampingRatio = 0.8f, stiffness = 420f))
        } else {
            launch { menu.charge.animateTo(0f, tween(OrbitMotion.CLOSE_MILLIS)) }
            launch { menu.spin.animateTo(0f, tween(OrbitMotion.CLOSE_MILLIS + 120, easing = FastOutSlowInEasing)) }
            menu.bloom.animateTo(0f, tween(OrbitMotion.CLOSE_MILLIS))
            menu.clearChosen()
        }
    }
    // A tap on the centre does not open the sections; the hint answers it with a short pulse.
    val hintPulse = remember { Animatable(0f) }
    LaunchedEffect(menu.nudges) {
        if (menu.nudges == 0) return@LaunchedEffect
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        hintPulse.snapTo(0f)
        hintPulse.animateTo(1f, tween(140))
        hintPulse.animateTo(0f, tween(420))
    }
    val menuOnScreen by remember { derivedStateOf { menu.open || menu.bloom.value > 0f } }

    val choose: (Int) -> Unit = { i ->
        if (menu.markChosen(i)) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            scope.launch {
                // A short flash of the chosen sector, then its page starts growing out of it.
                delay(OrbitMotion.CHOOSE_DELAY_MILLIS)
                onOpenSection(HomeSection.entries[i], menu.originInRoot(i))
                menu.hide()
            }
        }
    }

    // The prayer sheet is a layer driven by a Reveal: a finger and an animation move the same number,
    // and only draw lambdas read it (see Reveal). Nothing here recomposes per frame.
    val sheet = remember { Reveal(initiallyOpen = sheetPrayer != null) }
    LaunchedEffect(sheetPrayer != null) {
        if (sheetPrayer != null) {
            // Let the heavy first composition of the sheet land before the clock of the slide starts;
            // otherwise its first frames are spent composing and the slide visibly skips ahead.
            withFrameNanos { }
            withFrameNanos { }
            sheet.settle(true)
        } else {
            sheet.settle(false)
        }
    }
    val sheetOnScreen by remember(sheetPrayer != null) {
        derivedStateOf { sheetPrayer != null || sheet.progress > 0f }
    }

    Box(
        modifier
            .fillMaxSize()
            .onGloballyPositioned { menu.homeTopLeftInRoot = it.positionInRoot() }
    ) {
        Column(Modifier.fillMaxSize()) {
            HomeHeader(data, onOpenCity)
            // 0.19.0: a feast, a night or a fast of the Islamic year, in its colour (see HomeDayChip).
            HomeDayChip(
                data.today.date, data.settings.hijriOffset, onOpen = onOpenSchedule,
                modifier = Modifier.padding(start = ui.s(20f), end = ui.s(20f), top = 10.dp)
            )

            OrbitDial(
                data = data, now = now, palette = palette, menu = menu, wheel = wheel, haptic = haptic,
                onOpenPrayer = { if (!menu.open) sheetName = it.name },
                onOpenMenu = { sticky -> if (sheetPrayer == null) menu.show(sticky) },
                onChoose = choose,
                modifier = Modifier.weight(1f).padding(horizontal = ui.s(8f))
            )

            // One fixed slot under the ring, so the ring never moves when its content changes. The
            // line itself is drawn above the sections (below), so it stays readable while they are open.
            Spacer(
                Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(top = 6.dp, bottom = ui.s(18f))
                    .height(52.dp)
            )
        }

        if (menuOnScreen) {
            OrbitMenuLayer(
                menu, palette, haptic, onChoose = choose, onDismiss = { menu.hide() },
                hubClock = { OrbitHubClock(data, now, palette) }
            )
        }

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = ui.s(20f))
                .padding(top = 6.dp, bottom = ui.s(18f))
                .height(52.dp)
                .graphicsLayer {
                    val k = 1f + 0.06f * hintPulse.value
                    scaleX = k
                    scaleY = k
                },
            contentAlignment = Alignment.Center
        ) {
            Crossfade(
                targetState = when {
                    menu.open && menu.chosen < 0 -> menuLine(menu.finger)
                    menu.open -> BottomLine.NONE
                    wheel.day != 0 -> BottomLine.TODAY
                    else -> BottomLine.HINT
                },
                animationSpec = tween(160),
                label = "orbitBottom"
            ) { line ->
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    if (line == BottomLine.TODAY) PillButton(
                        tr("Вернуться к сегодня"), { scope.launch { wheel.goTo(0) } },
                        background = TodayPill, contentColor = TextPrimary
                    ) else if (line != BottomLine.NONE) Text(
                        when (line) {
                            BottomLine.MENU_LIT -> tr("Отпустите — откроется · уведите за край — отмена")
                            BottomLine.MENU_AWAY -> tr("Отпустите — ничего не откроется")
                            BottomLine.MENU_HOLD -> tr("Ведите к разделу · отпустите в центре — отмена")
                            BottomLine.MENU_TAP -> tr("Коснитесь раздела · мимо — закрыть")
                            BottomLine.HINT, BottomLine.TODAY, BottomLine.NONE ->
                                tr("Зажмите центр — разделы · крутите кольцо — дни")
                        },
                        color = if (line == BottomLine.HINT) TextSecondary else TextPrimary,
                        fontSize = ui.t(12f), fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center, maxLines = 2, style = TextStyle(shadow = OnSky)
                    )
                }
            }
        }

        // The sheet keeps rendering the last prayer while it slides away.
        // A plain holder, not state: it only has to remember, never to trigger a recomposition.
        val lastSheet = remember { arrayOfNulls<Prayer>(1) }
        if (sheetPrayer != null) lastSheet[0] = sheetPrayer
        if (sheetOnScreen) {
            Box(Modifier.fillMaxSize().onSizeChanged { sheet.extentPx = it.height.toFloat() }) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .drawBehind { drawRect(SheetScrim, alpha = sheet.progress) }
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClickLabel = tr("Закрыть"),
                            onClick = { sheetName = null }
                        )
                )
                Box(Modifier.fillMaxSize().graphicsLayer { translationY = (1f - sheet.progress) * size.height }) {
                    PrayerSheet(
                        data = data,
                        initial = lastSheet[0] ?: Prayer.FAJR,
                        now = now,
                        actions = actions,
                        notificationsAllowed = notificationsAllowed,
                        exactAlarmsAllowed = exactAlarmsAllowed,
                        onDismiss = { sheetName = null },
                        onOpenSettings = { sheetName = null; onOpenSection(HomeSection.SETTINGS, Offset.Unspecified) },
                        motion = sheet
                    )
                }
            }
        }
    }
}

private enum class BottomLine { TODAY, HINT, NONE, MENU_HOLD, MENU_LIT, MENU_AWAY, MENU_TAP }

/** The line under the ring while the sections are open follows the finger. */
private fun menuLine(finger: OrbitFinger): BottomLine =
    if (finger == OrbitFinger.SECTOR) BottomLine.MENU_LIT
    else if (finger == OrbitFinger.AWAY) BottomLine.MENU_AWAY
    else if (finger == OrbitFinger.HUB) BottomLine.MENU_HOLD
    else BottomLine.MENU_TAP

@Composable
private fun HomeHeader(data: PrayerData, onOpenCity: () -> Unit) {
    val ui = uiScale()
    val sky = TextStyle(shadow = OnSky)
    Row(
        Modifier.fillMaxWidth().padding(start = ui.s(20f), end = ui.s(12f), top = 8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Column(Modifier.weight(1f).padding(top = 6.dp)) {
            Text(
                Format.weekday(data.today.date).replaceFirstChar { it.uppercase() },
                color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Bold, style = sky
            )
            // 0.19.0: on a feast or a fast the hijri date takes the colour of the day.
            val dayTone = remember(data.today.date, data.settings.hijriOffset) {
                com.nur.prayer.data.IslamicDays.primary(data.today.date, data.settings.hijriOffset)
                    ?.takeIf { it.kind == com.nur.prayer.data.DayKind.FEAST || it.kind == com.nur.prayer.data.DayKind.FAST }
                    ?.let { com.nur.prayer.ui.schedule.DayTone.of(it.kind) }
            }
            Text(
                HijriCalendar.format(data.today.date, data.settings.hijriOffset),
                color = dayTone ?: TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.Medium, style = sky,
                maxLines = 1
            )
        }
        Column(
            Modifier
                .weight(1f)
                .clip(RoundedCornerShape(14.dp))
                .clickable(role = Role.Button, onClickLabel = tr("Выбрать город"), onClick = onOpenCity)
                .heightIn(min = 48.dp)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.End
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (data.settings.useDeviceLocation) {
                    Glyph(GlyphKind.LOCATION, TextPrimary, Modifier.size(13.dp))
                    Spacer(Modifier.width(6.dp))
                }
                AutoSizeText(
                    data.place.label, color = TextPrimary, fontSize = ui.t(17f), minFontSize = ui.t(13f),
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.End
                )
            }
            Text(
                Format.dayMonth(data.today.date), color = TextSecondary, fontSize = ui.t(13f),
                fontWeight = FontWeight.Medium, style = sky
            )
        }
    }
}
