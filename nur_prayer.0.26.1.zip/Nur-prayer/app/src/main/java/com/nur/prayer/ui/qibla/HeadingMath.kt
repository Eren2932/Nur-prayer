package com.nur.prayer.ui.qibla

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Pure compass mathematics: no Android types, so it is unit-tested on the JVM instead of being
 * verified by waving a phone around. Everything here is exercised by `HeadingMathTest`.
 */

/**
 * Low-pass filter on the unit vector, not on the angle: immune to the 359°/0° discontinuity.
 * The gain adapts — a big movement is followed almost immediately, a resting phone is averaged
 * hard, which is what kills the jitter you see in cheap compass apps.
 */
internal class HeadingFilter {
    private var sinAcc = Float.NaN
    private var cosAcc = Float.NaN

    fun push(degrees: Float): Float {
        val radians = Math.toRadians(degrees.toDouble()).toFloat()
        val s = sin(radians)
        val c = cos(radians)
        if (sinAcc.isNaN()) {
            sinAcc = s
            cosAcc = c
            return normalize(degrees)
        }
        val current = normalize(Math.toDegrees(atan2(sinAcc, cosAcc).toDouble()).toFloat())
        val jump = abs(angleDelta(current, degrees))
        val gain = (0.10f + 0.60f * (jump / 25f).coerceAtMost(1f)).coerceIn(0.10f, 0.70f)
        sinAcc += (s - sinAcc) * gain
        cosAcc += (c - cosAcc) * gain
        return normalize(Math.toDegrees(atan2(sinAcc, cosAcc).toDouble()).toFloat())
    }
}

internal fun normalize(angle: Float): Float = ((angle % 360f) + 360f) % 360f

/** Shortest-path angular interpolation: no 359 -> 0 jump. */
internal fun lerpAngle(from: Float, to: Float, factor: Float): Float {
    val delta = ((to - from + 540f) % 360f) - 180f
    if (abs(delta) < 0.05f) return normalize(to)
    return normalize(from + delta * factor)
}

/** Signed difference in degrees, -180..180. Positive means [to] is clockwise from [from]. */
internal fun angleDelta(from: Float, to: Float): Float = ((to - from + 540f) % 360f) - 180f

/** Unwrapped rotation target: 359° -> 1° turns the dial 2°, never an entire revolution. */
internal fun nearestDialRotation(currentRotation: Float, heading: Float): Float =
    currentRotation - angleDelta(normalize(-currentRotation), normalize(heading))

/**
 * 0.14.2: where the auto-search spin comes to rest. The dial was spinning toward negative angles;
 * the lock continues in that direction (no reversal), travels at least [minTravel] so the
 * deceleration is visible, and ends exactly on a rotation equivalent to −[heading] — the same
 * point [nearestDialRotation] would track afterwards, so tracking takes over without a jump.
 */
internal fun lockDialRotation(spinRotation: Float, heading: Float, minTravel: Float = 120f): Float {
    val goal = -normalize(heading)
    var rotation = spinRotation - normalize(spinRotation - goal)
    if (spinRotation - rotation < minTravel) rotation -= 360f
    return rotation
}

/**
 * 0.23.0: where the phone *looks*, for any hold — flat on the palm, tilted, or upright like a camera.
 *
 * [r] is a device→world rotation matrix (row-major 3×3, world X = east, Y = north, Z = up), already
 * remapped through the display rotation; column j is device axis j expressed in world coordinates.
 *
 *  - Lying flat, the direction is the top edge (device +Y) projected on the horizon.
 *  - Upright, the top edge points at the sky and its projection is noise; the direction is where
 *    the back of the phone looks (device −Z).
 *  - In between both projections point the same way under a pure tilt, so any blend of them is
 *    exact; the blend weight (zᵤ⁴, zᵤ = vertical part of the screen normal) only decides which one
 *    dominates when the phone is also rolled. There is no switch, so no jump at any angle — the old
 *    55° remap switch jumped by the roll angle.
 *  - When the top edge dips below the horizon the back faces the floor-ward side, so −Z is flipped
 *    by the sign of the top edge's vertical part (softly, over ±20°).
 *
 * Returns degrees clockwise from the matrix's north, or NaN when the hold has no horizontal
 * direction at all (upright in landscape with a portrait UI): the caller keeps its last reading.
 */
internal fun forwardAzimuth(r: FloatArray): Float {
    val yE = r[1]
    val yN = r[4]
    val yU = r[7]
    val zE = r[2]
    val zN = r[5]
    val zU = r[8]
    val zz = (zU * zU).coerceIn(0f, 1f)
    val flat = zz * zz
    val upright = 1f - flat
    val back = (yU * 3f).coerceIn(-1f, 1f)
    val e = flat * yE - upright * back * zE
    val n = flat * yN - upright * back * zN
    if (e * e + n * n < FORWARD_MIN_SQUARED) return Float.NaN
    return normalize(Math.toDegrees(atan2(e.toDouble(), n.toDouble())).toFloat())
}

/** Below |forward| = 0.05 the horizontal direction is mostly sensor noise. */
private const val FORWARD_MIN_SQUARED = 0.0025f
