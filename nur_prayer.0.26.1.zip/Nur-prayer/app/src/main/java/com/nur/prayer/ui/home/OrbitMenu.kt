package com.nur.prayer.ui.home

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/*
 * The sections of the ring — a marking menu. 0.26.1 rules, one per intention:
 *
 *  - hold the centre still            → the ring charges (an arc runs round it, the ticks wind up),
 *                                        then spins on and unfurls into the sections under the finger;
 *  - move first                        → it is a turn of the ring (days), never the menu: the two
 *                                        gestures can no longer fight over one finger;
 *  - slide onto a section and let go   → it opens;
 *  - slide back to the centre, let go  → nothing opens, the menu folds away (taken back);
 *  - slide off past the edge, let go   → the same: nothing opens. The sections dim while the finger
 *                                        is out there, so the cancel is visible before it happens;
 *  - hold and let go without moving    → the sections stay, for a tap;
 *  - TalkBack «open» on the centre     → the same, open for a tap;
 *  - tap outside, Back, tap the centre → closed.
 *
 * The finger is owned by whoever saw it go down: the dial during a hold, this layer once the menu
 * stays open. Both hit-test with the same OrbitMath.target and the same radii, so what lights up
 * under the finger is always what opens.
 */

object OrbitMotion {
    /** The chosen section flashes this long before its page starts to come. */
    const val CHOOSE_DELAY_MILLIS = 70L
    const val CLOSE_MILLIS = 190
    const val INTRO_MILLIS = 560
    const val DAY_FADE_MILLIS = 220
    /** After the hold the ticks keep spinning this far while the sections unfurl. */
    const val SPIN_DEG = 75f
    const val SPIN_MILLIS = 520
}

/** Where the finger is while the menu is open: drives the dimming and the line under the ring. */
internal enum class OrbitFinger { NONE, HUB, SECTOR, AWAY }

@Stable
internal class OrbitMenuState {
    var open by mutableStateOf(false)
        private set

    /** Open without a finger on it: waits for a tap. */
    var sticky by mutableStateOf(false)
        private set

    var highlighted by mutableIntStateOf(-1)
        private set

    var finger by mutableStateOf(OrbitFinger.NONE)
        private set

    /** The section on its way to open; it stays lit while the rest fold away. */
    var chosen by mutableIntStateOf(-1)
        private set

    /** A tap on the centre: the hint under the ring answers (see HomeScreen). */
    var nudges by mutableIntStateOf(0)
        private set

    /** 0 → 1: the sections unfurl. Read in draw and layer lambdas only. */
    val bloom = Animatable(0f)

    /** 0 → 1 while the centre is held: the arc around the ring. Read in draw only. */
    val charge = Animatable(0f)

    /** Extra turn of the ticks after the hold, degrees. Read in draw only. */
    val spin = Animatable(0f)

    // Geometry, rewritten by the dial on every layout. Plain fields: read by gestures and draws only.
    var dialCenterInRoot: Offset = Offset.Unspecified
    var homeTopLeftInRoot: Offset = Offset.Zero
    var hubPx = 0f
    var outerPx = 0f
    /** Past this distance from the centre a finger is «away»: letting go there opens nothing. */
    var reachPx = 0f

    val count: Int get() = HomeSection.entries.size

    /**
     * Distance of a section's label from the centre: the visual middle of an annular sector sits a
     * little outside the arithmetic middle. [gapPx] is the gap between the hub and the sections.
     */
    fun labelRadius(gapPx: Float): Float {
        val inner = hubPx + gapPx
        return inner + (outerPx - inner) * 0.52f
    }

    /** Centre of the dial in the coordinates of the home screen (and of this layer, which fills it). */
    val localCenter: Offset
        get() = if (dialCenterInRoot.isSpecified) dialCenterInRoot - homeTopLeftInRoot else Offset.Unspecified

    /** Where the page of section [i] grows from: the middle of its sector, in root coordinates. */
    fun originInRoot(i: Int): Offset {
        if (!dialCenterInRoot.isSpecified) return Offset.Unspecified
        val a = Math.toRadians(OrbitMath.sectorCenter(i, count).toDouble())
        val r = (hubPx + outerPx) / 2f
        return dialCenterInRoot + Offset((r * cos(a)).toFloat(), (r * sin(a)).toFloat())
    }

    fun show(sticky: Boolean) {
        this.sticky = sticky
        highlighted = -1
        chosen = -1
        finger = if (sticky) OrbitFinger.NONE else OrbitFinger.HUB
        open = true
    }

    fun stick() {
        sticky = true
        highlighted = -1
        finger = OrbitFinger.NONE
    }

    fun hide() {
        open = false
        highlighted = -1
        finger = OrbitFinger.NONE
    }

    fun nudge() {
        nudges++
    }

    /**
     * The finger is at [target] (a section, OrbitMath.AT_HUB or AT_AWAY): light what it points to,
     * with a light tick of the motor on every new section.
     */
    fun follow(target: Int, haptic: HapticFeedback) {
        if (chosen >= 0) return
        finger = when (target) {
            OrbitMath.AT_HUB -> OrbitFinger.HUB
            OrbitMath.AT_AWAY -> OrbitFinger.AWAY
            else -> OrbitFinger.SECTOR
        }
        val lit = if (target >= 0) target else -1
        if (lit == highlighted) return
        highlighted = lit
        if (lit >= 0) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    /** The finger left the screen without a choice. */
    fun release() {
        if (chosen >= 0) return
        highlighted = -1
        finger = OrbitFinger.NONE
    }

    /** False when a section is already on its way: a second tap must not open a second page. */
    fun markChosen(i: Int): Boolean {
        if (chosen >= 0 || i !in 0 until count) return false
        chosen = i
        highlighted = i
        finger = OrbitFinger.SECTOR
        return true
    }

    fun clearChosen() {
        chosen = -1
    }
}

private val SectorFill = Color(0xE61B1838)
private val SectorEdge = Color(0x24FFFFFF)
private val HubFill = Color(0xF0120F26)

/**
 * Dimming of home under the open sections: a little deeper around the ring than at the edges, so
 * the sections read clearly and the wallpaper still shows. Tuned against the plain home screen:
 * the sky stays recognisable, the header stays legible.
 */
private const val SCRIM_RING = 0.46f
private const val SCRIM_EDGE = 0.30f

/**
 * The open sections, over a dimmed home. Composed only while the menu is open or folding away; the
 * bloom is read in draw and layer lambdas, so the animation itself never recomposes.
 * [hubClock] is the countdown of home, so the centre keeps the time while the sections are open.
 */
@Composable
internal fun OrbitMenuLayer(
    menu: OrbitMenuState,
    palette: PhasePalette,
    haptic: HapticFeedback,
    onChoose: (Int) -> Unit,
    onDismiss: () -> Unit,
    hubClock: @Composable () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val sections = HomeSection.entries
    val n = sections.size
    val accent = palette.accent
    val choose by rememberUpdatedState(onChoose)
    val dismiss by rememberUpdatedState(onDismiss)
    // Off the edge: the sections step back, so «nothing will open» is visible before the finger lifts.
    val away by animateFloatAsState(
        if (menu.finger == OrbitFinger.AWAY) 1f else 0f, tween(140), label = "orbitAway"
    )
    Box(
        modifier
            .fillMaxSize()
            .pointerInput(menu) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    val c = menu.localCenter
                    if (!c.isSpecified) {
                        dismiss()
                        return@awaitEachGesture
                    }
                    val d0 = down.position - c
                    val first = OrbitMath.target(d0.x, d0.y, menu.hubPx, menu.reachPx, n, menu.highlighted)
                    val onSections = first >= 0
                    if (onSections) menu.follow(first, haptic)
                    var up = false
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        change.consume()
                        if (!change.pressed) {
                            up = true
                            break
                        }
                        if (onSections) {
                            val d = change.position - c
                            menu.follow(OrbitMath.target(d.x, d.y, menu.hubPx, menu.reachPx, n, menu.highlighted), haptic)
                        }
                    }
                    when {
                        !up -> menu.release()
                        // The centre or the sky around: close, as every sheet in the app does.
                        !onSections -> dismiss()
                        menu.finger == OrbitFinger.SECTOR && menu.highlighted >= 0 -> choose(menu.highlighted)
                        // Pressed a section, then slid off it: taken back, the sections stay for another try.
                        else -> menu.release()
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val b = menu.bloom.value
            val shown = b.coerceIn(0f, 1f)
            val c = menu.localCenter
            val focus = if (c.isSpecified) c else center
            drawRect(
                Brush.radialGradient(
                    0f to Color.Black.copy(alpha = SCRIM_RING),
                    1f to Color.Black.copy(alpha = SCRIM_EDGE),
                    center = focus,
                    radius = max(size.width, size.height) * 0.7f
                ),
                alpha = shown
            )
            if (!c.isSpecified || menu.outerPx <= 0f) return@Canvas
            val inner = menu.hubPx + 3.dp.toPx()
            val outerMax = menu.outerPx - 6.dp.toPx() * away
            val width = 360f / n
            // The same physical gap at the inner edge for any number of sections.
            val gapDeg = Math.toDegrees((5.dp.toPx() / inner).toDouble()).toFloat()
            val chosen = menu.chosen
            val dim = 1f - 0.45f * away
            for (i in 0 until n) {
                val t = if (i == chosen) 1f else OrbitMath.stagger(b, i, n)
                if (t <= 0f) continue
                val outer = inner + (outerMax - inner) * t
                val sweepDeg = width - gapDeg
                val start = OrbitMath.sectorCenter(i, n) - sweepDeg / 2f + OrbitMath.bloomTurn(t)
                val path = Path().apply {
                    arcTo(Rect(c, outer), start, sweepDeg, true)
                    arcTo(Rect(c, inner), start + sweepDeg, -sweepDeg, false)
                    close()
                }
                val lit = i == menu.highlighted
                val alpha = t.coerceIn(0f, 1f) * dim
                drawPath(path, if (lit) accent else SectorFill, alpha = alpha)
                if (!lit) drawPath(path, SectorEdge, alpha = alpha, style = Stroke(width = 1.dp.toPx()))
            }
            val hubR = menu.hubPx * (0.9f + 0.1f * shown)
            drawCircle(HubFill, radius = hubR, center = c, alpha = shown)
            drawCircle(
                if (menu.finger == OrbitFinger.HUB) accent else Color.White, radius = hubR, center = c,
                alpha = (if (menu.finger == OrbitFinger.HUB) 0.55f else 0.10f) * shown,
                style = Stroke(width = 1.5.dp.toPx())
            )
        }

        // The centre keeps the clock of home; above it, what the finger is on.
        Layout(
            content = {
                Column(
                    Modifier
                        .padding(horizontal = 6.dp)
                        .graphicsLayer { alpha = menu.bloom.value.coerceIn(0f, 1f) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val lit = menu.highlighted
                    Text(
                        if (lit >= 0) sections[lit].label() else tr("Разделы"),
                        color = if (lit >= 0) palette.accentSoft else TextSecondary,
                        fontSize = ui.t(12.5f), fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center, maxLines = 1
                    )
                    Box(Modifier.clearAndSetSemantics { }) { hubClock() }
                }
                sections.forEachIndexed { i, section ->
                    val lit = i == menu.highlighted
                    Column(
                        Modifier
                            .widthIn(max = 92.dp)
                            .graphicsLayer {
                                val t = if (i == menu.chosen) 1f else OrbitMath.stagger(menu.bloom.value, i, n)
                                alpha = t.coerceIn(0f, 1f)
                                // Labels grow in with their section but never past their size.
                                val k = 0.7f + 0.3f * t.coerceAtMost(1f)
                                scaleX = k
                                scaleY = k
                                // …and ride round with it while it unfurls (layer transform only).
                                val turn = OrbitMath.bloomTurn(t)
                                if (turn != 0f) {
                                    val mid = menu.labelRadius(3.dp.toPx())
                                    val a0 = Math.toRadians(OrbitMath.sectorCenter(i, n).toDouble())
                                    val a1 = a0 + Math.toRadians(turn.toDouble())
                                    translationX = (mid * (cos(a1) - cos(a0))).toFloat()
                                    translationY = (mid * (sin(a1) - sin(a0))).toFloat()
                                } else {
                                    translationX = 0f
                                    translationY = 0f
                                }
                            }
                            .clearAndSetSemantics {
                                contentDescription = section.label()
                                role = Role.Button
                                selected = lit
                                onClick(label = section.label()) { onChoose(i); true }
                            },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        SectionGlyph(section, if (lit) Ink else TextPrimary, if (lit) Ink else accent, Modifier.size(26.dp))
                        Text(
                            section.label(), color = if (lit) Ink else TextPrimary, fontSize = ui.t(11.5f),
                            fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 1
                        )
                    }
                }
            }
        ) { measurables, constraints ->
            val loose = Constraints(maxWidth = constraints.maxWidth, maxHeight = constraints.maxHeight)
            // The hub text gets the same width as the centre of home: the clock is the same size here.
            val hubSide = (menu.hubPx * 2f).roundToInt().coerceAtLeast(1)
            val placeables = measurables.mapIndexed { k, m ->
                if (k == 0) m.measure(Constraints(maxWidth = hubSide, maxHeight = hubSide)) else m.measure(loose)
            }
            layout(constraints.maxWidth, constraints.maxHeight) {
                val c = menu.localCenter
                if (!c.isSpecified) return@layout
                val mid = menu.labelRadius(3.dp.toPx())
                placeables.forEachIndexed { k, p ->
                    val at = if (k == 0) c else {
                        val a = Math.toRadians(OrbitMath.sectorCenter(k - 1, n).toDouble())
                        c + Offset((mid * cos(a)).toFloat(), (mid * sin(a)).toFloat())
                    }
                    p.place((at.x - p.width / 2f).roundToInt(), (at.y - p.height / 2f).roundToInt())
                }
            }
        }
    }
}
