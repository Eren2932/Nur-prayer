package com.nur.prayer.quran

/**
 * 0.21.1. Tajweed colouring of the Uthmani text, computed from its Unicode marks alone (no tables).
 *
 * Mirrors `tools/tajweed.py` line for line; `TajweedTest` checks both against
 * `src/test/resources/tajweed_golden.tsv`, so a change on one side without the other fails CI.
 *
 * Every span covers whole graphemes (a letter with all its marks): on Android a vowel mark coloured
 * apart from its letter is shaped on its own and drifts or loses the joining, so it never happens.
 *
 * Rules, highest priority first:
 *  - [Rule.SILENT]: hamzat al-wasl ٱ; a letter with ۟ or ۠; a bare consonant before a shadda (lam
 *    shamsiyya, idgham: مِّن رَّبِّهِمْ).
 *  - [Rule.MADD_LONG]: a letter with maddah ٓ (lazim, wajib, ja'iz, silah kubra).
 *  - [Rule.MADD]: dagger alif ٰ, small waw/yeh ۥ ۦ; a madd or leen letter before the last letter at a
 *    stop (end of the ayah or a pause sign other than ۙ).
 *  - [Rule.GHUNNA]: نّ مّ; small high noon ۨ; ikhfa; idgham with ghunna; iqlab ۢ ۭ; ikhfa shafawi.
 *  - [Rule.QALQALA]: ق ط ب ج د with sukun or last at a stop.
 *  - [Rule.TAFKHIM]: خ ص ض غ ط ق ظ, and a heavy ر.
 */
object Tajweed {
    enum class Rule { SILENT, MADD_LONG, MADD, GHUNNA, QALQALA, TAFKHIM }

    data class Span(val start: Int, val end: Int, val rule: Rule)

    private const val FATHA = '\u064E'
    private const val DAMMA = '\u064F'
    private const val KASRA = '\u0650'
    private const val FATHATAN = '\u064B'
    private const val DAMMATAN = '\u064C'
    private const val KASRATAN = '\u064D'
    private const val SHADDA = '\u0651'
    private const val SUKUN = '\u0652'
    private const val MADDAH = '\u0653'
    private const val DAGGER = '\u0670'
    private const val ROUND_ZERO = '\u06DF'
    private const val RECT_ZERO = '\u06E0'
    private const val SUKUN_KHAH = '\u06E1'
    private const val IMALA = '\u06EA'
    private const val SMALL_NOON = '\u06E8'
    private const val WASLA = '\u0671'
    private const val ALIF = '\u0627'
    private const val MAQSURA = '\u0649'
    private const val WAW = '\u0648'
    private const val YA = '\u064A'
    private const val SMALL_WAW = '\u06E5'
    private const val SMALL_YA = '\u06E6'
    private const val TATWEEL = '\u0640'
    private const val NOON = '\u0646'
    private const val MEEM = '\u0645'
    private const val RA = '\u0631'
    private const val BA = '\u0628'

    private val IQLAB = setOf('\u06E2', '\u06ED')
    private val TANWEEN = setOf(FATHATAN, DAMMATAN, KASRATAN)
    private val SUKUNS = setOf(SUKUN, SUKUN_KHAH)
    private val BARE_BLOCKERS: Set<Char> =
        setOf(FATHA, DAMMA, KASRA, SHADDA, DAGGER, ROUND_ZERO, RECT_ZERO, MADDAH) + TANWEEN + SUKUNS + IQLAB
    private val STOP_SIGNS = setOf('\u06D6', '\u06D7', '\u06D8', '\u06DA', '\u06DB')
    private val PAUSE_SIGNS = STOP_SIGNS + '\u06D9'
    private val QALQALA_LETTERS = setOf('ق', 'ط', 'ب', 'ج', 'د')
    private val ISTILA = setOf('خ', 'ص', 'ض', 'غ', 'ط', 'ق', 'ظ')
    private val IKHFA_LETTERS = "تثجدذزسشصضطظفقك".toSet()
    private val IDGHAM_GHUNNA = setOf('ي', 'ن', 'م', 'و')

    private fun isLetter(ch: Char): Boolean =
        (ch in '\u0621'..'\u064A' && ch != TATWEEL) || ch == WASLA || ch == SMALL_WAW || ch == SMALL_YA

    private fun isMark(ch: Char): Boolean = Character.getType(ch) == Character.NON_SPACING_MARK.toInt()

    private class G(val start: Int, val base: Char) {
        var end = start + 1
        val marks = HashSet<Char>(4)
        var word = -1
        fun has(vararg ms: Char): Boolean = ms.any { it in marks }
        fun hasAny(set: Set<Char>): Boolean = marks.any { it in set }
        /** No vowel, sukun, shadda, dagger alif, silence, madd or iqlab sign at all. */
        val bare: Boolean get() = marks.none { it in BARE_BLOCKERS }
    }

    private fun graphemes(text: String): List<G> {
        val out = ArrayList<G>(text.length)
        text.forEachIndexed { i, ch ->
            val last = out.lastOrNull()
            if (isMark(ch) && last != null && last.base != ' ' && last.base !in PAUSE_SIGNS) {
                last.marks.add(ch)
                last.end = i + 1
            } else {
                out.add(G(i, ch))
            }
        }
        return out
    }

    /** Spans over [text], sorted, non-overlapping, on grapheme boundaries. */
    fun spans(text: String): List<Span> {
        val words = ArrayList<List<G>>()
        var cur = ArrayList<G>()
        val stopWords = HashSet<Int>()
        for (g in graphemes(text)) {
            when {
                g.base == ' ' -> if (cur.isNotEmpty()) { words.add(cur); cur = ArrayList() }
                g.base in PAUSE_SIGNS -> {
                    if (cur.isNotEmpty()) { words.add(cur); cur = ArrayList() }
                    if (g.base in STOP_SIGNS && words.isNotEmpty()) stopWords.add(words.size - 1)
                }
                // A tatweel with marks carries a hamza (ٱلْـَٔاخِرَةِ): it counts as a letter.
                isLetter(g.base) || (g.base == TATWEEL && g.marks.isNotEmpty()) -> cur.add(g)
            }
        }
        if (cur.isNotEmpty()) words.add(cur)
        if (words.isNotEmpty()) stopWords.add(words.size - 1) // end of the ayah
        val letters = ArrayList<G>()
        words.forEachIndexed { w, word -> word.forEach { it.word = w; letters.add(it) } }
        val n = letters.size

        fun at(i: Int): G? = letters.getOrNull(i)

        fun vowelOf(g: G?): Char? = when {
            g == null -> null
            g.has(FATHA, FATHATAN) -> FATHA
            g.has(DAMMA, DAMMATAN) -> DAMMA
            g.has(KASRA, KASRATAN) -> KASRA
            else -> null
        }

        fun isMaddLetter(i: Int): Boolean {
            val g = at(i)
            val p = at(i - 1)
            if (g == null || p == null || p.word != g.word || (!g.bare && !g.has(DAGGER))) return false
            val v = vowelOf(p)
            return (g.base == ALIF && (v == FATHA || p.has(DAGGER))) || (g.base == MAQSURA && (v == FATHA || v == KASRA)) ||
                (g.base == WAW && v == DAMMA) || (g.base == YA && v == KASRA)
        }

        fun isLeen(i: Int): Boolean {
            val g = at(i)
            val p = at(i - 1)
            return g != null && p != null && p.word == g.word && (g.base == WAW || g.base == YA) &&
                g.hasAny(SUKUNS) && vowelOf(p) == FATHA
        }

        fun isTanweenCarrier(i: Int): Boolean {
            val g = at(i)
            val p = at(i - 1)
            return g != null && p != null && p.word == g.word && g.bare && p.hasAny(TANWEEN)
        }

        fun tanweenTarget(i: Int): Int? {
            var j = i + 1
            while (j < n && letters[j].word == letters[i].word && isTanweenCarrier(j)) j++
            return if (j < n && letters[j].word != letters[i].word) j else null
        }

        fun heavyRa(i: Int, atStop: Boolean): Boolean {
            val g = letters[i]
            if (g.has(IMALA)) return false
            if (!atStop) {
                if (g.has(FATHA, FATHATAN, DAMMA, DAMMATAN)) return true
                if (g.has(KASRA, KASRATAN)) return false
            }
            if (atStop && g.has(FATHATAN)) return true
            val j = i - 1
            val p = at(j)
            if (p == null || p.word != g.word) return true
            if (p.base == WASLA) return true // ٱرْجِعِىٓ: the kasra of the wasla is not a real one
            if ((p.base == YA || p.base == MAQSURA) && (p.hasAny(SUKUNS) || isMaddLetter(j))) return false
            if (p.hasAny(SUKUNS) || p.bare || isMaddLetter(j)) {
                val q = at(j - 1)
                if (q == null || q.word != g.word) return true
                if (q.base == WASLA) return true
                return vowelOf(q) != KASRA
            }
            if (vowelOf(p) == KASRA) {
                val nx = at(i + 1)
                // قِرْطَاسٍ, مِرْصَادًا: an isti'la letter right after keeps the ر heavy
                return nx != null && nx.word == g.word && nx.base in ISTILA && !atStop
            }
            return true
        }

        val rules = Array(n) { HashSet<Rule>(2) }
        for (i in 0 until n) {
            val g = letters[i]
            val nx = at(i + 1)
            val lastOfWord = nx == null || nx.word != g.word
            val atStop = lastOfWord && g.word in stopWords
            val crossesStop = atStop && nx != null && nx.word != g.word
            // silent
            if (g.base == WASLA || g.has(ROUND_ZERO, RECT_ZERO)) {
                rules[i].add(Rule.SILENT)
            } else if (g.bare && g.base != ALIF && g.base != MAQSURA && g.base != SMALL_WAW && g.base != SMALL_YA &&
                !isMaddLetter(i) && !isTanweenCarrier(i) && nx != null && nx.has(SHADDA) && !crossesStop
            ) {
                rules[i].add(Rule.SILENT)
            }
            // madd
            if (g.has(MADDAH)) rules[i].add(Rule.MADD_LONG)
            if (g.has(DAGGER) || g.base == SMALL_WAW || g.base == SMALL_YA) rules[i].add(Rule.MADD)
            // ghunna family
            if ((g.base == NOON || g.base == MEEM) && g.has(SHADDA)) rules[i].add(Rule.GHUNNA)
            if (g.hasAny(IQLAB) || g.has(SMALL_NOON)) rules[i].add(Rule.GHUNNA)
            if (g.base == NOON && (g.bare || g.hasAny(SUKUNS)) && nx != null && !crossesStop) {
                if (nx.base in IKHFA_LETTERS && !nx.has(SHADDA)) {
                    rules[i].add(Rule.GHUNNA)
                } else if (lastOfWord && g.bare && nx.base in IDGHAM_GHUNNA && !nx.has(SHADDA)) {
                    rules[i].add(Rule.GHUNNA) // idgham naqis: مَن يَقُولُ (no shadda in the Madinah mushaf)
                }
            }
            if (g.hasAny(TANWEEN) && !g.hasAny(IQLAB) && !atStop) {
                val t = tanweenTarget(i)
                if (t != null && (letters[t].base in IKHFA_LETTERS || letters[t].base in IDGHAM_GHUNNA)) rules[i].add(Rule.GHUNNA)
            }
            if (g.base == MEEM && g.bare && nx != null && nx.base == BA && !crossesStop) rules[i].add(Rule.GHUNNA) // ikhfa shafawi
            // qalqala
            if (g.base in QALQALA_LETTERS && (g.hasAny(SUKUNS) || (atStop && !g.has(FATHATAN)))) rules[i].add(Rule.QALQALA)
            // tafkhim
            if (g.base in ISTILA) rules[i].add(Rule.TAFKHIM)
            if (g.base == RA && heavyRa(i, atStop)) rules[i].add(Rule.TAFKHIM)
        }
        // madd 'arid / leen at a stop: the madd letter right before the last letter of a stop word
        for (w in stopWords) {
            var li = -1
            for (i in 0 until n) if (letters[i].word == w) li = i
            if (li < 1 || letters[li].has(FATHATAN)) continue
            val last = letters[li]
            if ((last.base == ALIF || last.base == MAQSURA) && isMaddLetter(li)) continue
            val p = li - 1
            if (letters[p].word == w && (isMaddLetter(p) || isLeen(p))) rules[p].add(Rule.MADD)
        }

        val out = ArrayList<Span>()
        for (i in 0 until n) {
            if (rules[i].isEmpty()) continue
            val g = letters[i]
            val r = Rule.entries.first { it in rules[i] }
            val prev = out.lastOrNull()
            if (prev != null && prev.end == g.start && prev.rule == r) {
                out[out.size - 1] = prev.copy(end = g.end)
            } else {
                out.add(Span(g.start, g.end, r))
            }
        }
        return out
    }
}
