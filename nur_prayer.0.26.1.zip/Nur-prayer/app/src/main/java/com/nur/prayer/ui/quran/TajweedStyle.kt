package com.nur.prayer.ui.quran

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.Tajweed
import com.nur.prayer.ui.theme.ArabicFont
import com.nur.prayer.ui.theme.uiScale

/*
 * 0.21.1. The tajweed colours of the reader, on top of quran/Tajweed.kt (pure rules, unit-tested).
 *
 * Two palettes, one per kind of surface. On paper the colours are inks (≥ 3 : 1 on the page, the
 * AA level for text this large; the silent grey is quieter on purpose, as in a printed tajweed
 * mushaf). On the dark and black surfaces they are lifted so that none is darker than the tertiary
 * text. Only colour changes: a colour span does not split Arabic shaping, so letters keep joining.
 */
internal object TajweedStyle {
    private val PAPER = mapOf(
        Tajweed.Rule.SILENT to Color(0xFF8F8679),
        Tajweed.Rule.MADD_LONG to Color(0xFFB3261E),
        Tajweed.Rule.MADD to Color(0xFFB85C00),
        Tajweed.Rule.GHUNNA to Color(0xFF2E7D32),
        Tajweed.Rule.QALQALA to Color(0xFF00809E),
        Tajweed.Rule.TAFKHIM to Color(0xFF2850A8)
    )
    private val NIGHT = mapOf(
        Tajweed.Rule.SILENT to Color(0xFF7E8590),
        Tajweed.Rule.MADD_LONG to Color(0xFFFF6B6B),
        Tajweed.Rule.MADD to Color(0xFFFFA94D),
        Tajweed.Rule.GHUNNA to Color(0xFF5FD07A),
        Tajweed.Rule.QALQALA to Color(0xFF4DD0E1),
        Tajweed.Rule.TAFKHIM to Color(0xFF7FA8FF)
    )

    fun color(rule: Tajweed.Rule, colors: QuranColors): Color = (if (colors.light) PAPER else NIGHT).getValue(rule)

    /** [text] with its tajweed spans; [on] false returns it uncoloured (the switch, hifz). */
    fun annotate(text: String, colors: QuranColors, on: Boolean): AnnotatedString {
        // The rules read the Tanzil marks; the face gets its own encoding of them (same length).
        val shown = ArabicFont.mushaf(text)
        if (!on) return AnnotatedString(shown)
        val b = AnnotatedString.Builder(shown)
        for (s in Tajweed.spans(text)) b.addStyle(SpanStyle(color = color(s.rule, colors)), s.start, s.end)
        return b.toAnnotatedString()
    }

    /** What each colour means, in the order of [Tajweed.Rule]. */
    fun label(rule: Tajweed.Rule): String = when (rule) {
        Tajweed.Rule.SILENT -> tr("Не читается")
        Tajweed.Rule.MADD_LONG -> tr("Долгий мадд")
        Tajweed.Rule.MADD -> tr("Мадд")
        Tajweed.Rule.GHUNNA -> tr("Гунна")
        Tajweed.Rule.QALQALA -> tr("Калькаля")
        Tajweed.Rule.TAFKHIM -> tr("Твёрдые")
    }
}

/** The colour key under the switch in the reading settings. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun TajweedLegend(colors: QuranColors) {
    val ui = uiScale()
    FlowRow(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (rule in Tajweed.Rule.entries) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.size(9.dp).background(TajweedStyle.color(rule, colors), CircleShape))
                Text(TajweedStyle.label(rule), color = colors.textSecondary, fontSize = ui.t(12f))
            }
        }
    }
}
