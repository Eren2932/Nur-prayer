package com.nur.prayer

import android.app.Application
import androidx.test.runner.AndroidJUnitRunner
import com.nur.prayer.i18n.AppLanguage
import com.nur.prayer.i18n.L10n
import java.util.Locale

/**
 * UI tests assert the Russian source strings ("Поиск города", "Фаджр"). Since the app learned
 * other languages, [L10n.install] picks the phone's language on first launch, and a CI emulator
 * boots in en-US: every tr() returned English and the whole instrumentation suite failed on a
 * fresh device while passing on a Russian phone. The tests pin the source language instead of
 * depending on how the emulator image happens to be configured.
 */
class NurTestRunner : AndroidJUnitRunner() {
    override fun callApplicationOnCreate(app: Application) {
        Locale.setDefault(Locale.forLanguageTag("ru-RU")) // first-launch choice and String.format
        super.callApplicationOnCreate(app)
        L10n.set(AppLanguage.RU) // a language saved by an earlier run on the same device
    }
}
