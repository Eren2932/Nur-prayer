package com.nur.prayer

import com.nur.prayer.ui.qibla.forwardAzimuth
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** 0.23.0: the heading no longer depends on how the phone is held. */
class ForwardAzimuthTest {
    /** Device→world matrix (row-major, E/N/U) for a phone turned to [yaw] and tilted up by [pitch]. */
    private fun matrix(yaw: Double, pitch: Double): FloatArray {
        val p = Math.toRadians(pitch)
        val y = Math.toRadians(yaw)
        fun turn(e: Double, n: Double, u: Double) = doubleArrayOf(e * cos(y) + n * sin(y), -e * sin(y) + n * cos(y), u)
        val axes = listOf(turn(1.0, 0.0, 0.0), turn(0.0, cos(p), sin(p)), turn(0.0, -sin(p), cos(p)))
        return FloatArray(9) { i -> axes[i % 3][i / 3].toFloat() }
    }

    private fun diff(a: Float, b: Float): Float = abs(((a - b + 540f) % 360f) - 180f)

    @Test fun anyTiltGivesTheSameDirection() {
        for (yaw in 0 until 360 step 15) for (pitch in listOf(-30, 0, 20, 45, 55, 60, 80, 90, 110)) {
            val a = forwardAzimuth(matrix(yaw.toDouble(), pitch.toDouble()))
            assertTrue("yaw=$yaw pitch=$pitch got $a", diff(a, yaw.toFloat()) < 0.01f)
        }
    }

    @Test fun noJumpWhenRaisingThePhone() {
        var previous = forwardAzimuth(matrix(250.0, 0.0))
        var step = 0
        while (step <= 1000) {
            val a = forwardAzimuth(matrix(250.0, step / 10.0))
            assertTrue("jump at ${step / 10.0}°", diff(a, previous) < 0.5f)
            previous = a
            step++
        }
    }

    @Test fun northIsZeroNotThreeSixty() {
        assertEquals(0f, forwardAzimuth(matrix(0.0, 30.0)), 0.01f)
    }
}
