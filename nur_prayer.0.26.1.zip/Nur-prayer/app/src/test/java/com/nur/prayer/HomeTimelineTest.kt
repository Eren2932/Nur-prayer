package com.nur.prayer

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.core.astro.PrayerWindow
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.home.HomeTimeline
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class HomeTimelineTest {
    private val zone = ZoneId.of("Europe/Moscow")
    private val date = LocalDate.of(2026, 10, 31)
    private fun at(h: Int, m: Int, d: LocalDate = date) = ZonedDateTime.of(d.atTime(h, m), zone)

    private fun day(d: LocalDate, saharEqualsFajr: Boolean) = PrayerDay(d, mapOf(
        Prayer.SAHAR to at(5, if (saharEqualsFajr) 28 else 10, d),
        Prayer.FAJR to at(5, 28, d),
        Prayer.SUNRISE to at(7, 28, d),
        Prayer.DHUHR to at(12, 19, d),
        Prayer.ASR to at(14, 22, d),
        Prayer.MAGHRIB to at(16, 57, d),
        Prayer.ISHA to at(18, 36, d)
    ))

    @Test fun suhoorRowOnlyWhenItIsADistinctTime() {
        assertFalse(Prayer.SAHAR in HomeTimeline.prayers(fajrEqualsDawn = true))
        assertEquals(Prayer.entries.toList(), HomeTimeline.prayers(fajrEqualsDawn = false))
    }

    @Test fun hiddenSuhoorWindowLandsOnFajr() {
        val w = PrayerWindow(Prayer.ISHA, at(18, 36), Prayer.SAHAR, at(5, 28, date.plusDays(1)))
        assertEquals(Prayer.FAJR, HomeTimeline.next(w, fajrEqualsDawn = true))
        assertEquals(Prayer.SAHAR, HomeTimeline.next(w, fajrEqualsDawn = false))
        assertEquals(0, HomeTimeline.pageOf(Prayer.SAHAR, fajrEqualsDawn = true))
    }

    @Test fun windowEndsAtTheNextTimeAndIshaRollsOver() {
        val today = day(date, true)
        val tomorrow = day(date.plusDays(1), true)
        assertEquals(Prayer.SUNRISE to at(7, 28), HomeTimeline.endOf(Prayer.FAJR, today, tomorrow, true))
        assertEquals(Prayer.MAGHRIB to at(16, 57), HomeTimeline.endOf(Prayer.ASR, today, tomorrow, true))
        assertEquals(Prayer.FAJR to at(5, 28, date.plusDays(1)), HomeTimeline.endOf(Prayer.ISHA, today, tomorrow, true))
        assertNull(HomeTimeline.endOf(Prayer.ISHA, today, null, true))
        // With a distinct suhoor the night ends at suhoor, not at the congregational Fajr.
        val t2 = day(date.plusDays(1), false)
        assertEquals(Prayer.SAHAR to at(5, 10, date.plusDays(1)), HomeTimeline.endOf(Prayer.ISHA, day(date, false), t2, false))
    }

    @Test fun bigClockKeepsAFixedWidth() {
        assertEquals("01:28:40", Format.clock(Duration.ofSeconds(5320)))
        assertEquals("00:00:00", Format.clock(Duration.ZERO))
        assertEquals(8, Format.clock(Duration.ofHours(9)).length)
    }
}
