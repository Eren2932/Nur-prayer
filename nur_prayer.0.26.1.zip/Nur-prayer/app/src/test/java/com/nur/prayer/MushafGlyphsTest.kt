package com.nur.prayer

import com.nur.prayer.quran.MushafGlyphs
import com.nur.prayer.quran.QuranMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * 0.21.1. Tanzil marks -> KFGQPC marks. The face draws U+06DF as a wide placeholder: before this map
 * a box stood inside every أُو۟لَٰٓئِكَ. tools/fonts.py check proves the face side (every mark of the
 * encoded text is a GDEF mark); this proves the text side and that tajweed offsets survive.
 */
class MushafGlyphsTest {
    @Test fun silentCircleAndSukunSwapToTheFaceEncoding() {
        // أُو۟لَٰٓئِكَ: the silent circle becomes U+0652, the face's circle.
        assertEquals("\u0623\u064F\u0648\u0652\u0644\u064E", MushafGlyphs.encode("\u0623\u064F\u0648\u06DF\u0644\u064E"))
        // رَيْبَ: the ordinary sukun becomes the mushaf khah head U+06E1.
        assertEquals("\u0631\u064E\u064A\u06E1\u0628\u064E", MushafGlyphs.encode("\u0631\u064E\u064A\u0652\u0628\u064E"))
        // 52:37 and 12:11: signs the face has no glyph for draw nothing and keep the letters joined.
        assertEquals("\u0635\u064E\u200D\u064A", MushafGlyphs.encode("\u0635\u064E\u06E3\u064A"))
        assertEquals("\u0645\u064E\u200D\u0646", MushafGlyphs.encode("\u0645\u064E\u06EB\u0646"))
        val plain = "\u0644\u064E\u0627"
        assertTrue(plain === MushafGlyphs.encode(plain))
    }

    @Test fun everyAyahKeepsItsLengthAndLosesThePlaceholders() {
        fun file(name: String) = listOf(File("src/$name"), File("app/src/$name")).first { it.isFile }
        var ayat = 0
        for (surah in 1..114) {
            for (a in QuranMath.parse(surah, file("main/assets/" + QuranMath.asset(surah)).readText())) {
                val shown = MushafGlyphs.encode(a.uthmani)
                assertEquals("$surah:${a.number}", a.uthmani.length, shown.length)
                assertFalse("$surah:${a.number}", shown.any { it == '\u06DF' || it == '\u06E3' || it == '\u06EB' })
                ayat++
            }
        }
        assertEquals(6236, ayat)
    }
}
