package com.nur.prayer

import com.nur.prayer.quran.QuranMath
import com.nur.prayer.quran.Tajweed
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * 0.21.1. Tajweed colouring of the Uthmani text.
 *
 * The golden file is written by tools/tajweed.py (the reference implementation), so Kotlin and Python
 * cannot drift apart: a rule changed on one side only fails here. On top of it, the cases of the
 * mushaf the colours were tuned on, and invariants over all 6236 ayat.
 */
class TajweedTest {
    private fun golden(): List<String> =
        checkNotNull(javaClass.classLoader?.getResourceAsStream("tajweed_golden.tsv")) { "нет tajweed_golden.tsv" }
            .bufferedReader().readLines().filter { it.isNotBlank() && !it.startsWith("#") }

    private fun render(text: String): String =
        Tajweed.spans(text).joinToString(" ") { "${it.start}-${it.end}:${it.rule}" }

    /** The coloured pieces of [text] as (piece, rule), the easiest form to read in a failure. */
    private fun pieces(text: String): List<Pair<String, Tajweed.Rule>> =
        Tajweed.spans(text).map { text.substring(it.start, it.end) to it.rule }

    @Test fun kotlinMatchesTheReferenceImplementation() {
        val lines = golden()
        assertTrue("golden file is empty", lines.size >= 50)
        for (line in lines) {
            val (ref, text, expected) = line.split('\t').let { Triple(it[0], it[1], it.getOrElse(2) { "" }) }
            assertEquals("tajweed of $ref", expected, render(text))
        }
    }

    @Test fun muqattaatAreLongMadd() {
        // الٓمٓ: lam and meem carry the maddah, the alif of «alif» does not stretch.
        assertEquals(listOf("\u0644\u0653\u0645\u0653" to Tajweed.Rule.MADD_LONG), pieces("\u0627\u0644\u0653\u0645\u0653"))
    }

    @Test fun salatHasSilentWaslaAndSunLamThenTheDaggerAlif() {
        val salat = "\u0671\u0644\u0635\u0651\u064E\u0644\u064E\u0648\u0670\u0629\u064E" // ٱلصَّلَوٰةَ
        val p = pieces(salat)
        assertEquals("\u0671\u0644" to Tajweed.Rule.SILENT, p[0])
        assertEquals("\u0635\u0651\u064E" to Tajweed.Rule.TAFKHIM, p[1])
        assertEquals("\u0648\u0670" to Tajweed.Rule.MADD, p[2])
    }

    @Test fun qalqalaGhunnaAndIdghamWithoutGhunna() {
        // رَزَقْنَٰهُمْ: qaf with sukun bounces.
        assertTrue(("\u0642\u0652" to Tajweed.Rule.QALQALA) in pieces("\u0631\u064E\u0632\u064E\u0642\u0652\u0646\u064E\u0670\u0647\u064F\u0645\u0652"))
        // مِمَّا: meem with shadda.
        assertTrue(("\u0645\u0651\u064E" to Tajweed.Rule.GHUNNA) in pieces("\u0648\u064E\u0645\u0650\u0645\u0651\u064E\u0627 \u0643\u064E"))
        // مِّن رَّبِّهِمْ: the noon merges into the ra without ghunna and is not read.
        val p = pieces("\u0645\u0651\u0650\u0646 \u0631\u0651\u064E\u0628\u0651\u0650\u0647\u0650\u0645\u0652")
        assertTrue(("\u0646" to Tajweed.Rule.SILENT) in p)
        // يُنفِقُونَ: ikhfa before fa.
        assertTrue(("\u0646" to Tajweed.Rule.GHUNNA) in pieces("\u064A\u064F\u0646\u0641\u0650\u0642\u064F\u0648\u0646\u064E"))
    }

    @Test fun everyAyahIsColouredOnWholeLetters() {
        fun file(name: String) = listOf(File("src/$name"), File("app/src/$name")).first { it.isFile }
        fun mark(c: Char) = Character.getType(c) == Character.NON_SPACING_MARK.toInt()
        var ayat = 0
        for (surah in 1..114) {
            val list = QuranMath.parse(surah, file("main/assets/" + QuranMath.asset(surah)).readText())
            for (a in list) {
                val text = a.uthmani
                assertTrue("no Uthmani text in $surah:${a.number}", text.isNotEmpty())
                var last = 0
                for (s in Tajweed.spans(text)) {
                    assertTrue("$surah:${a.number} spans overlap or are empty", s.start >= last && s.end > s.start)
                    assertTrue("$surah:${a.number} span starts on a mark", !mark(text[s.start]))
                    assertTrue("$surah:${a.number} span leaves a mark behind", s.end == text.length || !mark(text[s.end]))
                    last = s.end
                }
                ayat++
            }
        }
        assertEquals(6236, ayat)
    }
}
