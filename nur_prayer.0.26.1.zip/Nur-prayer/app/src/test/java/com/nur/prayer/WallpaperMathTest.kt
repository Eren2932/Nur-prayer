package com.nur.prayer

import com.nur.prayer.ui.wallpaper.WallpaperCatalog
import com.nur.prayer.ui.wallpaper.WallpaperContrast
import com.nur.prayer.ui.wallpaper.WallpaperFit
import com.nur.prayer.ui.wallpaper.WallpaperOrder
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.22.0: where a wallpaper lands on any screen, how dark its scrim is, and the order of the settings row. */
class WallpaperMathTest {

    // ── Fit ──────────────────────────────────────────────────────────────────────────────────────

    /** Phones from 21:9 to 4:3 and a landscape tablet, in px. */
    private val screens = listOf(
        1080f to 2520f, 1080f to 2400f, 1440f to 3200f, 1080f to 1920f, 720f to 1280f,
        1536f to 2048f, 1600f to 2560f, 2560f to 1600f, 1768f to 2208f
    )
    /** The real proportions of the bundled pictures (portrait, ≈ 0.45…0.56). */
    private val pictures = listOf(749f to 1538f, 747f to 1538f, 865f to 1538f, 694f to 1538f)

    @Test fun theFitCoversTheScreenUnlessTheZoomCapStopsIt() {
        for ((iw, ih) in pictures) for ((sw, sh) in screens) {
            val f = WallpaperFit.fit(iw, ih, sw, sh, 0.5f, 0.75f)
            val sx = sw / iw
            val sy = sh / ih
            val cover = maxOf(sx, sy)
            val capped = minOf(sx, sy) / WallpaperFit.MIN_VISIBLE
            if (cover <= capped) {
                // Cover is allowed: no strip anywhere, whatever the phone.
                assertTrue("no strip on the left of $sw×$sh", f.dx <= 0.01f)
                assertTrue("no strip on top of $sw×$sh", f.dy <= 0.01f)
                assertTrue("right edge covered on $sw×$sh", f.dx + iw * f.scale >= sw - 0.01f)
                assertTrue("bottom edge covered on $sw×$sh", f.dy + ih * f.scale >= sh - 0.01f)
            } else {
                // The cap wins (3:4 tablet + the narrowest picture, a landscape tablet): the picture
                // stops at the cap and the strips are drawn by edge extension (CLAMP), by design.
                assertEquals("capped scale on $sw×$sh", capped, f.scale, 1e-4f)
            }
        }
    }

    @Test fun everyPhoneFrom21by9To9by16IsFullyCoveredByEveryBundledPicture() {
        val phones = screens.filter { (w, h) -> w / h <= 0.6f }
        assertTrue(phones.size >= 5)
        for ((iw, ih) in pictures) for ((sw, sh) in phones) {
            val f = WallpaperFit.fit(iw, ih, sw, sh, 0.5f, 0.75f)
            assertTrue("no strip on the left of $sw×$sh", f.dx <= 0.01f)
            assertTrue("no strip on top of $sw×$sh", f.dy <= 0.01f)
            assertTrue("right edge covered on $sw×$sh", f.dx + iw * f.scale >= sw - 0.01f)
            assertTrue("bottom edge covered on $sw×$sh", f.dy + ih * f.scale >= sh - 0.01f)
        }
    }

    @Test fun onAWideScreenThePictureNeverZoomsPastTheMinimumVisibleShare() {
        for ((iw, ih) in pictures) for ((sw, sh) in screens) {
            val f = WallpaperFit.fit(iw, ih, sw, sh, 0.5f, 0.75f)
            val visibleW = (sw / (iw * f.scale)).coerceAtMost(1f)
            val visibleH = (sh / (ih * f.scale)).coerceAtMost(1f)
            assertTrue("$sw×$sh keeps ≥ ${WallpaperFit.MIN_VISIBLE} of the picture", minOf(visibleW, visibleH) >= WallpaperFit.MIN_VISIBLE - 1e-4f)
        }
    }

    @Test fun theFocusKeepsItsPlaceOnTheScreen() {
        // A mosque drawn at 3/4 of the picture height lands at 3/4 of the screen height.
        val (iw, ih) = 749f to 1538f
        for ((sw, sh) in screens) {
            val f = WallpaperFit.fit(iw, ih, sw, sh, 0.5f, 0.75f)
            val focusOnScreen = (f.dy + 0.75f * ih * f.scale) / sh
            assertEquals("$sw×$sh", 0.75f, focusOnScreen, 1e-3f)
        }
    }

    @Test fun degenerateSizesGiveTheIdentity() {
        assertEquals(WallpaperFit.Fit(1f, 0f, 0f), WallpaperFit.fit(0f, 10f, 100f, 100f, 0.5f, 0.5f))
        assertEquals(WallpaperFit.Fit(1f, 0f, 0f), WallpaperFit.fit(10f, 10f, 100f, 0f, 0.5f, 0.5f))
    }

    @Test fun sampleSizeNeverDecodesBelowScreenResolution() {
        assertEquals(1, WallpaperFit.sampleSize(1f))
        assertEquals(1, WallpaperFit.sampleSize(0.6f))
        assertEquals(2, WallpaperFit.sampleSize(0.3f))
        assertEquals(8, WallpaperFit.sampleSize(0.1f))
        assertEquals(1, WallpaperFit.sampleSize(0f))
        assertEquals(1, WallpaperFit.sampleSize(Float.NaN))
        for (i in 1..400) {
            val s = i / 400f
            assertTrue(WallpaperFit.sampleSize(s) * s <= 1f + 1e-6f)
        }
    }

    // ── Contrast ─────────────────────────────────────────────────────────────────────────────────

    @Test fun alphaForBringsAnyColourUnderTheLimit() {
        val limit = WallpaperContrast.limit(WallpaperContrast.PRIMARY_LUMINANCE, 4.5)
        var c = 0
        for (r in 0..10) for (g in 0..10) for (b in 0..10) {
            val (rr, gg, bb) = Triple(r / 10.0, g / 10.0, b / 10.0)
            val a = WallpaperContrast.alphaFor(rr, gg, bb, limit, 0.05, 0.04, 0.03).toDouble()
            val k = 1 - a
            val lum = WallpaperContrast.luminance(rr * k + 0.05 * a, gg * k + 0.04 * a, bb * k + 0.03 * a)
            assertTrue("($rr,$gg,$bb) a=$a", lum <= limit + 1e-6)
            c++
        }
        assertEquals(1331, c)
    }

    @Test fun aDarkPictureNeedsNoScrimAndABrightOneGetsOneEverywhere() {
        val w = 40
        val h = 80
        val fit = WallpaperFit.fit(w.toFloat(), h.toFloat(), 1080f, 2400f, 0.5f, 0.5f)
        val black = WallpaperContrast.scrim(IntArray(w * h) { 0xFF0A0A12.toInt() }, w, h, fit, 1080f, 2400f)
        assertTrue(black.all { it == 0f })
        val cream = WallpaperContrast.scrim(IntArray(w * h) { 0xFFF6E9D6.toInt() }, w, h, fit, 1080f, 2400f)
        assertEquals(WallpaperContrast.ROWS, cream.size)
        assertTrue(cream.all { it > 0.3f && it <= WallpaperContrast.MAX_ALPHA })
    }

    @Test fun theScrimGuaranteeHoldsAtEveryScreenRowNotOnlyAtSlabCentres() {
        // A picture bright at the top (sky) fading darker to the bottom: every slab has its own need.
        val w = 30
        val h = 120
        fun shade(y: Int): Int = (200 - y).coerceIn(40, 200)
        val px = IntArray(w * h) { i ->
            val v = shade(i / w)
            (0xFF shl 24) or (v shl 16) or (v shl 8) or (v + 20).coerceAtMost(255)
        }
        for ((sw, sh) in listOf(1080f to 2400f, 1080f to 1920f, 1440f to 3200f)) {
            val fit = WallpaperFit.fit(w.toFloat(), h.toFloat(), sw, sh, 0.5f, 0.75f)
            val stops = WallpaperContrast.scrim(px, w, h, fit, sw, sh)
            val n = WallpaperContrast.ROWS
            for (yi in 0 until 2000) {
                val y = (yi + 0.5f) / 2000f
                // The gradient as drawn: stops at slab centres, the end stops held to the edges.
                val t = (y * n - 0.5f).coerceIn(0f, (n - 1).toFloat())
                val i = t.toInt().coerceAtMost(n - 2)
                val a = (stops[i] + (stops[i + 1] - stops[i]) * (t - i)).toDouble()
                val iy = ((y * sh - fit.dy) / fit.scale).toInt().coerceIn(0, h - 1)
                val v = shade(iy) / 255.0
                val bl = (shade(iy) + 20).coerceAtMost(255) / 255.0
                val k = 1 - a
                val lum = WallpaperContrast.luminance(v * k, v * k, bl * k)
                val (text, ratio) = WallpaperContrast.requirement(y)
                assertTrue("$sw×$sh row $y: ${WallpaperContrast.contrast(text, lum)} < $ratio",
                    WallpaperContrast.contrast(text, lum) >= ratio - 1e-6)
            }
        }
    }

    @Test fun smoothingAndDilationOnlyEverAddDarkness() {
        val raw = floatArrayOf(0f, 0f, 0.6f, 0f, 0.2f, 0f, 0f, 0.9f)
        val smooth = WallpaperContrast.smooth(raw)
        for (i in raw.indices) assertTrue(smooth[i] >= raw[i])
        // No hard 0 → 0.6 step: a cone max falls off by at most SLOPE per slab.
        for (i in 1 until smooth.size) assertTrue(kotlin.math.abs(smooth[i] - smooth[i - 1]) <= WallpaperContrast.SLOPE + 1e-6f)
        val dilated = WallpaperContrast.dilate(smooth)
        for (i in smooth.indices) {
            val m = maxOf(smooth[i], smooth.getOrElse(i - 1) { 0f }, smooth.getOrElse(i + 1) { 0f })
            assertTrue(dilated[i] >= minOf(m, WallpaperContrast.MAX_ALPHA))
            assertTrue(dilated[i] <= WallpaperContrast.MAX_ALPHA)
        }
    }

    @Test fun theTintIsTheDarkestToneOfThePictureDarkerStill() {
        val px = IntArray(1000) { if (it < 100) 0xFF402010.toInt() else 0xFFF0E0C0.toInt() }
        val tint = WallpaperContrast.tintOf(px, step = 1)
        assertEquals(0xFF.toLong(), (tint ushr 24).toLong())
        assertEquals((0x40 * WallpaperContrast.TINT_DEPTH).toInt(), tint shr 16 and 0xFF)
        assertEquals(0xFF000000.toInt(), WallpaperContrast.tintOf(IntArray(0)))
    }

    // ── Order and persistence ────────────────────────────────────────────────────────────────────

    @Test fun theRowShowsCurrentThenRecentThenTheRestWithoutRepeats() {
        val catalog = listOf("sky", "amoled", "a", "b", "c", "d", "e", "f", "g", "h")
        val row = WallpaperOrder.row("c", listOf("a", "c", "gone", "sky"), catalog)
        assertEquals(listOf("c", "a", "sky", "amoled", "b", "d", "e", "f"), row)
        assertEquals(WallpaperOrder.ROW_LIMIT, row.size)
        assertEquals(row.distinct(), row)
    }

    @Test fun rememberPutsTheNewChoiceFirstAndCutsTheTail() {
        assertEquals(listOf("b", "a", "c"), WallpaperOrder.remember("b", listOf("a", "b", "c")))
        val long = (1..30).map { "w$it" }
        val r = WallpaperOrder.remember("new", long)
        assertEquals(WallpaperOrder.RECENT_LIMIT, r.size)
        assertEquals("new", r.first())
    }

    @Test fun recentListSurvivesStorage() {
        val l = listOf("kaaba_day", "sky", "night_mosque")
        assertEquals(l, WallpaperOrder.decode(WallpaperOrder.encode(l)))
        assertEquals(emptyList<String>(), WallpaperOrder.decode(null))
        assertEquals(listOf("a", "b"), WallpaperOrder.decode(" a,, b ,"))
    }

    // ── Catalog ──────────────────────────────────────────────────────────────────────────────────

    @Test fun installsFromBeforeWallpapersKeepWhatTheySaw() {
        assertEquals(WallpaperCatalog.SKY_ID, WallpaperCatalog.resolve(null, skyBackdrop = true).id)
        assertEquals(WallpaperCatalog.AMOLED_ID, WallpaperCatalog.resolve(null, skyBackdrop = false).id)
        assertEquals("kaaba_day", WallpaperCatalog.resolve("kaaba_day", skyBackdrop = false).id)
        // A wallpaper removed in a later version falls back to the sky, never to a blank screen.
        assertEquals(WallpaperCatalog.SKY_ID, WallpaperCatalog.resolve("removed_one", skyBackdrop = false).id)
    }

    @Test fun everyPictureOfTheCatalogIsBundledAndIdsAreUnique() {
        val ids = WallpaperCatalog.all.map { it.id }
        assertEquals(ids.distinct(), ids)
        for (w in WallpaperCatalog.all.filter { it.isImage }) {
            assertTrue("${w.asset} is bundled", File("src/main/assets/${w.asset}").isFile)
        }
        // Every category that has a wallpaper is a section, in catalog order.
        assertEquals(WallpaperCatalog.all.size, WallpaperCatalog.sections().sumOf { it.second.size })
    }
}
