#!/usr/bin/env python3
"""0.24.0 / 0.25.0: the launch screen must stay one picture, stay white and stay quick.

Before 0.24.0 the activity's starting theme was Theme.Nur, whose window is black: the dark flash between
the tap on the icon and the first frame. The fix has four parts that only work together, and each can be
broken silently by an innocent edit:

  1. Theme.Nur.Starting (Theme.SplashScreen): white background, ic_splash_art as the icon, hand-over to
     Theme.Nur; the manifest gives it to MainActivity.
  2. res/drawable-<dpi>/ic_splash_art.webp — the «Нур» disc (0.25.0: the launcher artwork with the praying
     figure, not a separate mark) on the 288dp splash canvas, written by build_icons.py --splash.
  3. LaunchScreen draws that same file at the same 288dp, so the hand-over has no jump.
  4. MainActivity installs the splash before super.onCreate, keeps it until the launch screen has its first
     frame, removes it without its own exit animation, and shows the launch screen on a fresh start only.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class _Icons:
    """The splash numbers of tools/launcher_icons/build_icons.py, read from its source: the CI python has
    no numpy/Pillow at this step, so the generator itself is not imported."""
    def __init__(self, root=ROOT):
        src = (root / 'tools/launcher_icons/build_icons.py').read_text(encoding='utf-8')
        num = lambda n: float(re.search(r'^%s\s*=\s*([0-9.]+)' % n, src, re.M)[1])
        self.SPLASH_DP, self.SPLASH_DISC_DP = num('SPLASH_DP'), num('SPLASH_DISC_DP')
        dens = re.search(r'^DENS\s*=\s*\{(.*?)\}', src, re.M)[1]
        self.DENS = {k: float(v) for k, v in re.findall(r'"(\w+)":\s*([0-9.]+)', dens)}


build_icons = _Icons()


def webp_size(path):
    """Canvas size from the RIFF header (VP8X / VP8L / VP8), no image library needed."""
    b = Path(path).read_bytes()[:40]
    if b[:4] != b'RIFF' or b[8:12] != b'WEBP':
        return None
    kind = b[12:16]
    if kind == b'VP8X':
        return (int.from_bytes(b[24:27], 'little') + 1, int.from_bytes(b[27:30], 'little') + 1)
    if kind == b'VP8L':
        v = int.from_bytes(b[21:25], 'little')
        return ((v & 0x3FFF) + 1, ((v >> 14) & 0x3FFF) + 1)
    if kind == b'VP8 ':
        return (int.from_bytes(b[26:28], 'little') & 0x3FFF, int.from_bytes(b[28:30], 'little') & 0x3FFF)
    return None

FILES = {
    'themes': 'app/src/main/res/values/themes.xml',
    'colors': 'app/src/main/res/values/colors.xml',
    'manifest': 'app/src/main/AndroidManifest.xml',
    'gradle': 'app/build.gradle.kts',
    'launch': 'app/src/main/java/com/nur/prayer/ui/components/LaunchScreen.kt',
    'activity': 'app/src/main/java/com/nur/prayer/MainActivity.kt',
}
ART = 'app/src/main/res/drawable-{}/ic_splash_art.webp'


def read_all(root=ROOT):
    return {k: (root / v).read_text(encoding='utf-8') for k, v in FILES.items()}


def const(src, name):
    m = re.search(r'const val %s\s*=\s*(-?[0-9.]+)[fL]?\b' % name, src)
    return float(m[1]) if m else None


def colour(src, name):
    m = re.search(r'val %s\s*=\s*Color\(0xFF([0-9A-Fa-f]{6})\)' % name, src)
    return '#' + m[1].upper() if m else None


def art_problems(root=ROOT):
    """Every density has the picture, on the full splash canvas, disc centred and nowhere near the mask."""
    try:
        from PIL import Image
        import numpy as np
    except ImportError:            # CI: header sizes only; the full check runs wherever Pillow is
        Image = np = None
    out = []
    for dn, s in build_icons.DENS.items():
        p = root / ART.format(dn)
        if not p.exists():
            out.append(f'missing {ART.format(dn)}: run python3 tools/launcher_icons/build_icons.py --splash')
            continue
        want = int(round(build_icons.SPLASH_DP * s))
        size = webp_size(p)
        if size != (want, want):
            out.append(f'{ART.format(dn)}: {size} but the splash canvas is {want}px')
            continue
        if Image is None:
            continue
        a = np.asarray(Image.open(p).convert('RGBA'))[..., 3]
        ys, xs = np.nonzero(a > 8)
        if not len(xs):
            out.append(f'{ART.format(dn)}: empty'); continue
        disc = (xs.max() - xs.min() + 1) / s
        if abs(disc - build_icons.SPLASH_DISC_DP) > 2:
            out.append(f'{ART.format(dn)}: disc {disc:.0f}dp, expected {build_icons.SPLASH_DISC_DP}dp')
        if abs((xs.max() + xs.min()) / 2 - want / 2) > s * 1.5 or abs((ys.max() + ys.min()) / 2 - want / 2) > s * 1.5:
            out.append(f'{ART.format(dn)}: disc is off centre')
    if build_icons.SPLASH_DISC_DP > build_icons.SPLASH_DP * 2 / 3:
        out.append('SPLASH_DISC_DP is larger than the visible splash circle (2/3 of the canvas): it would be cut')
    return out


def problems(f):
    out = []
    # 1. theme and manifest
    themes = f['themes']
    m = re.search(r'<style name="Theme\.Nur\.Starting" parent="Theme\.SplashScreen">(.*?)</style>', themes, re.S)
    if not m:
        out.append('themes.xml: Theme.Nur.Starting (parent Theme.SplashScreen) is missing')
    else:
        body = m[1]
        for need, why in (('windowSplashScreenBackground">@color/splash_bg<', 'the white background'),
                          ('windowSplashScreenAnimatedIcon">@drawable/ic_splash_art<', 'the «Нур» disc'),
                          ('postSplashScreenTheme">@style/Theme.Nur<', 'the hand-over to Theme.Nur')):
            if need not in body:
                out.append(f'Theme.Nur.Starting: lost {why}')
    if not re.search(r'<color name="splash_bg">#FFFFFFFF</color>', f['colors']):
        out.append('colors.xml: splash_bg must be opaque white (the launch screen is drawn on white)')
    if not re.search(r'android:name="\.MainActivity"[^>]*?android:theme="@style/Theme\.Nur\.Starting"', f['manifest'], re.S):
        out.append('AndroidManifest: MainActivity must use @style/Theme.Nur.Starting (a black window flashes otherwise)')
    if 'androidx.core:core-splashscreen:' not in f['gradle']:
        out.append('build.gradle.kts: androidx.core:core-splashscreen is missing')

    # 3. the launch screen draws the same file at the same size
    launch = f['launch']
    if 'painterResource(R.drawable.ic_splash_art)' not in launch:
        out.append('LaunchScreen: must draw R.drawable.ic_splash_art, the picture of the system splash')
    if const(launch, 'ART_DP') != build_icons.SPLASH_DP:
        out.append('LaunchScreenSpec.ART_DP must equal the splash canvas (build_icons.SPLASH_DP)')
    if '.size(LaunchScreenSpec.ART_DP.dp)' not in launch:
        out.append('LaunchScreen: the picture must be drawn at LaunchScreenSpec.ART_DP')
    if colour(launch, 'Background') != '#FFFFFF':
        out.append('LaunchScreenSpec.Background must be the splash white')
    exit_ms, min_ms, max_ms = const(launch, 'EXIT_MILLIS'), const(launch, 'MIN_MILLIS'), const(launch, 'MAX_MILLIS')
    # 0.25.0: quick. The whole visible tail (minimum + fade) stays under 0.7 s.
    if not (min_ms and 150 <= min_ms <= 450):
        out.append('LaunchScreen: MIN_MILLIS must be a short minimum (0.15-0.45 s): long enough not to flash, no longer')
    if not (max_ms and max_ms <= 8000):
        out.append('LaunchScreen: MAX_MILLIS must cap the wait (<= 8 s): the screen may never trap the user')
    if 'withTimeoutOrNull(LaunchScreenSpec.MAX_MILLIS)' not in launch:
        out.append('LaunchScreen: the wait for the data must be capped by MAX_MILLIS')
    if not (exit_ms and 150 <= exit_ms <= 350):
        out.append('LaunchScreen: EXIT_MILLIS out of range (0.15-0.35 s)')
    if min_ms and exit_ms and min_ms + exit_ms > 700:
        out.append('LaunchScreen: MIN_MILLIS + EXIT_MILLIS > 0.7 s — the launch feels slow')
    if '.pointerInput(Unit) { detectTapGestures { } }' not in launch:
        out.append('LaunchScreen: must swallow touches while it is up')
    if 'SideEffect { onShown() }' not in launch:
        out.append('LaunchScreen: must report its first frame (onShown) so the system splash can go')

    # 4. activity order and conditions
    act = f['activity']
    i_install, i_super = act.find('installSplashScreen()'), act.find('super.onCreate(savedInstanceState)')
    if not (0 <= i_install < i_super):
        out.append('MainActivity: installSplashScreen() must come before super.onCreate')
    if not re.search(r'if \(savedInstanceState == null\) showLaunchScreen\(splash\)', act):
        out.append('MainActivity: the launch screen belongs to a fresh start only (savedInstanceState == null)')
    if 'splash.setOnExitAnimationListener { it.remove() }' not in act:
        out.append('MainActivity: the system splash must be removed without its own exit animation')
    if not re.search(r'setKeepOnScreenCondition \{ !launchScreenDrawn && SystemClock\.uptimeMillis\(\) < deadline \}', act):
        out.append('MainActivity: keep the system splash until the launch screen is drawn, with a deadline')
    if 'ready = data != null' not in act:
        out.append('MainActivity: the launch screen is ready only when the data is')
    return out


def main():
    found = problems(read_all()) + art_problems()
    if found:
        print('\n'.join(found))
        sys.exit(f'check_splash: {len(found)} problem(s)')
    print('PASS: launch screen — white starting theme, the «Нур» disc on both sides of the hand-over, quick exit.')


if __name__ == '__main__':
    main()
