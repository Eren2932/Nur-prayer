#!/usr/bin/env python3
"""Full Quran data for Nur 0.16.x: builds and verifies the reader's assets from the Tanzil sources.

  python3 tools/quran_data.py build   -> app/src/main/assets/quran/NNN.tsv + quran/QuranIndex.kt
  python3 tools/quran_data.py check   -> rebuilds in memory and fails if the shipped files differ (CI)

Sources (tools/quran_src, downloaded verbatim from tanzil.net, licence headers kept):
  quran-simple.txt   Tanzil Quran Text, "simple" script, Hafs ‘an ‘Asim, with pause and sajda marks
  quran-uthmani.txt  Tanzil Quran Text, "Uthmani" script (Madinah mushaf orthography), same ayah keys
  quran-data.js      Tanzil metadata: surah order, ayah counts, Meccan/Medinan, juz starts, sajdas
  ru.kuliev.txt      Э. Кулиев, «Смысловой перевод Корана»
  en.sahih.txt       Saheeh International
  tr.diyanet.txt     Diyanet İşleri
  uz.sodik.txt       Muhammad Sodiq Muhammad Yusuf (Cyrillic in the source, shipped in Latin Uzbek)

The transliteration is not a source: tools/quran_translit.py derives it from the vowelled text,
so it can be regenerated and audited instead of trusted. The Latin reading is derived from the
Cyrillic one letter for letter (to_latin), so the two can never disagree.

Columns of NNN.tsv: ayah, arabic, translit (Cyrillic), latin, ru, en, tr, uz, uthmani.
`arabic` (simple) stays the working text: search, hifz, first letters, transliteration, copying.
`uthmani` (0.21.1) is only what the reader and the ayah picture display, with the mushaf face and the
tajweed colours (quran/Tajweed.kt). It is appended last so older column positions never move.
"""
import os
import re
import sys
import unicodedata

sys.path.insert(0, os.path.dirname(__file__))
from quran_translit import to_latin, transliterate_ayah, units, uz_latin  # noqa: E402

ROOT = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
SRC = os.path.join(ROOT, 'tools/quran_src')
ASSETS = os.path.join(ROOT, 'app/src/main/assets/quran')
PAGE_COUNT = 604
HIZB_QUARTERS = 240
INDEX_KT = os.path.join(ROOT, 'app/src/main/java/com/nur/prayer/quran/QuranIndex.kt')
TRANSLATIONS = ('ru.kuliev', 'en.sahih', 'tr.diyanet', 'uz.sodik')
TOTAL_AYAT = 6236

# Russian name and meaning of every surah, in mushaf order (names as in the app's short-surah list).
RU = [
    ('Аль-Фатиха', 'Открывающая'), ('Аль-Бакара', 'Корова'), ('Али ‘Имран', 'Семейство ‘Имрана'),
    ('Ан-Ниса', 'Женщины'), ('Аль-Маида', 'Трапеза'), ('Аль-Ан‘ам', 'Скот'), ('Аль-А‘раф', 'Преграды'),
    ('Аль-Анфаль', 'Трофеи'), ('Ат-Тауба', 'Покаяние'), ('Юнус', 'Пророк Юнус'), ('Худ', 'Пророк Худ'),
    ('Юсуф', 'Пророк Юсуф'), ('Ар-Ра‘д', 'Гром'), ('Ибрахим', 'Пророк Ибрахим'), ('Аль-Хиджр', 'Аль-Хиджр'),
    ('Ан-Нахль', 'Пчёлы'), ('Аль-Исра', 'Ночной перенос'), ('Аль-Кахф', 'Пещера'), ('Марьям', 'Марьям'),
    ('Та Ха', 'Та Ха'), ('Аль-Анбийа', 'Пророки'), ('Аль-Хадж', 'Паломничество'),
    ('Аль-Му’минун', 'Верующие'), ('Ан-Нур', 'Свет'), ('Аль-Фуркан', 'Различение'),
    ('Аш-Шу‘ара', 'Поэты'), ('Ан-Намль', 'Муравьи'), ('Аль-Касас', 'Рассказ'), ('Аль-‘Анкабут', 'Паук'),
    ('Ар-Рум', 'Римляне'), ('Лукман', 'Лукман'), ('Ас-Саджда', 'Земной поклон'), ('Аль-Ахзаб', 'Союзники'),
    ('Саба', 'Саба'), ('Фатыр', 'Творец'), ('Йа Син', 'Йа Син'), ('Ас-Саффат', 'Выстроившиеся в ряды'),
    ('Сад', 'Сад'), ('Аз-Зумар', 'Толпы'), ('Гафир', 'Прощающий'), ('Фуссылят', 'Разъяснены'),
    ('Аш-Шура', 'Совет'), ('Аз-Зухруф', 'Украшения'), ('Ад-Духан', 'Дым'),
    ('Аль-Джасийа', 'Коленопреклонённые'), ('Аль-Ахкаф', 'Барханы'), ('Мухаммад', 'Мухаммад'),
    ('Аль-Фатх', 'Победа'), ('Аль-Худжурат', 'Комнаты'), ('Каф', 'Каф'), ('Аз-Зарийат', 'Рассеивающие'),
    ('Ат-Тур', 'Гора'), ('Ан-Наджм', 'Звезда'), ('Аль-Камар', 'Месяц'), ('Ар-Рахман', 'Милостивый'),
    ('Аль-Ваки‘а', 'Неотвратимое событие'), ('Аль-Хадид', 'Железо'), ('Аль-Муджадала', 'Препирающаяся'),
    ('Аль-Хашр', 'Сбор'), ('Аль-Мумтахана', 'Испытуемая'), ('Ас-Сафф', 'Ряд'), ('Аль-Джуму‘а', 'Пятница'),
    ('Аль-Мунафикун', 'Лицемеры'), ('Ат-Тагабун', 'Взаимное обделение'), ('Ат-Талак', 'Развод'),
    ('Ат-Тахрим', 'Запрещение'), ('Аль-Мульк', 'Власть'), ('Аль-Калам', 'Письменная трость'),
    ('Аль-Хакка', 'Неизбежное'), ('Аль-Ма‘аридж', 'Ступени'), ('Нух', 'Пророк Нух'), ('Аль-Джинн', 'Джинны'),
    ('Аль-Муззаммиль', 'Закутавшийся'), ('Аль-Муддассир', 'Завернувшийся'), ('Аль-Кийама', 'Воскресение'),
    ('Аль-Инсан', 'Человек'), ('Аль-Мурсалат', 'Посылаемые'), ('Ан-Наба', 'Весть'),
    ('Ан-Нази‘ат', 'Исторгающие'), ('‘Абаса', 'Нахмурился'), ('Ат-Таквир', 'Скручивание'),
    ('Аль-Инфитар', 'Раскалывание'), ('Аль-Мутаффифин', 'Обвешивающие'), ('Аль-Иншикак', 'Разверзнется'),
    ('Аль-Бурудж', 'Созвездия'), ('Ат-Тарик', 'Ночной путник'), ('Аль-А‘ля', 'Всевышний'),
    ('Аль-Гашийа', 'Покрывающее'), ('Аль-Фаджр', 'Заря'), ('Аль-Балад', 'Город'), ('Аш-Шамс', 'Солнце'),
    ('Аль-Лайль', 'Ночь'), ('Ад-Духа', 'Утро'), ('Аш-Шарх', 'Раскрытие'), ('Ат-Тин', 'Смоковница'),
    ('Аль-‘Аляк', 'Сгусток'), ('Аль-Кадр', 'Предопределение'), ('Аль-Баййина', 'Ясное знамение'),
    ('Аз-Зальзаля', 'Землетрясение'), ('Аль-‘Адийат', 'Скачущие'), ('Аль-Кари‘а', 'Великое бедствие'),
    ('Ат-Такасур', 'Страсть к приумножению'), ('Аль-‘Аср', 'Время'), ('Аль-Хумаза', 'Хулитель'),
    ('Аль-Филь', 'Слон'), ('Курайш', 'Курайшиты'), ('Аль-Ма‘ун', 'Мелочь'), ('Аль-Каусар', 'Изобилие'),
    ('Аль-Кафирун', 'Неверующие'), ('Ан-Наср', 'Помощь'), ('Аль-Масад', 'Пальмовые волокна'),
    ('Аль-Ихлас', 'Очищение веры'), ('Аль-Фаляк', 'Рассвет'), ('Ан-Нас', 'Люди'),
]
BASMALA_SKELETON = 'بسم الله الرحمن الرحيم'.split()
DROP = str.maketrans('', '', '\u0640\u06de\u06e9\ufeff')  # tatweel, rub el-hizb, sajda sign (shown by the UI)
# Uthmani: the same two decorative signs go; tatweel stays where it carries a hamza (ٱلْـَٔاخِرَةِ) and is
# dropped only under a superscript alif (ٱلْكِتَـٰبُ -> ٱلْكِتَٰبُ), which is Tanzil's own download option
# and the spelling of the Madinah mushaf. Nothing else is touched.
DROP_UTHMANI = str.maketrans('', '', '\u06de\u06e9\ufeff')


def uthmani_skeleton(word):
    """Letters only, for finding the basmala: marks out, wasla as alif, small waw/yeh and tatweel out."""
    out = []
    for ch in word:
        if unicodedata.category(ch) == 'Mn' or ch in '\u0640\u06e5\u06e6':
            continue
        out.append('\u0627' if ch == '\u0671' else ch)
    return ''.join(out)


def clean_uthmani(key, text):
    text = text.translate(DROP_UTHMANI).replace('\u0640\u0670', '\u0670')
    text = re.sub(' +', ' ', text).strip()
    s, a = key
    if a == 1 and s != 1:
        words = text.split(' ')
        if [uthmani_skeleton(w) for w in words[:4]] == BASMALA_SKELETON:
            text = ' '.join(words[4:])
    return text


def read_pipe(name):
    out = {}
    with open(os.path.join(SRC, name), encoding='utf-8-sig') as f:
        for line in f:
            line = line.rstrip('\n')
            if not line or line.startswith('#'):
                continue
            s, a, text = line.split('|', 2)
            out[(int(s), int(a))] = text
    return out


def metadata():
    js = open(os.path.join(SRC, 'quran-data.js'), encoding='utf-8').read()

    def block(name):
        m = re.search(r'QuranData\.%s = \[(.*?)\];' % name, js, re.S)
        return m.group(1)
    suras = []
    for m in re.finditer(r"\[(\d+), (\d+), (\d+), (\d+), '([^']*)', \"([^\"]*)\", '([^']*)', '(Meccan|Medinan)'\]", block('Sura')):
        suras.append(dict(start=int(m[1]), ayat=int(m[2]), arabic=m[5], latin=m[6], english=m[7], medinan=m[8] == 'Medinan'))
    juz = [(int(a), int(b)) for a, b in re.findall(r'\[(\d+), (\d+)\]', block('Juz'))][:30]
    sajda = [(int(a), int(b)) for a, b, _ in re.findall(r"\[(\d+), (\d+), '(\w+)'\]", block('Sajda'))]
    # 0.18.0: the Madani mushaf layout. Both lists end with a [115, 1] sentinel, dropped here.
    pages = [(int(a), int(b)) for a, b in re.findall(r'\[(\d+), (\d+)\]', block('Page'))][:PAGE_COUNT]
    hizb = [(int(a), int(b)) for a, b in re.findall(r'\[(\d+), (\d+)\]', block('HizbQaurter'))][:HIZB_QUARTERS]
    return suras, juz, sajda, pages, hizb


def skeleton(word):
    return ''.join(u.ch for u in units(word))


def clean_arabic(key, text):
    text = re.sub(' +', ' ', text.translate(DROP)).strip()
    if key[1] == 1 and key[0] != 1:
        words = text.split(' ')
        if [skeleton(w) for w in words[:4]] == BASMALA_SKELETON:
            text = ' '.join(words[4:])
    return text


def clean_translation(text, code='ru'):
    text = re.sub(r'\s+', ' ', text).strip()
    return uz_latin(text) if code == 'uz' else text


def check_layout(suras, juz, pages, hizb):
    """Page and hizb starts: complete, strictly in mushaf order, real ayat, aligned with the juz."""
    assert len(pages) == PAGE_COUNT, len(pages)
    assert len(hizb) == HIZB_QUARTERS, len(hizb)
    for name, starts in (('Page', pages), ('HizbQaurter', hizb)):
        assert starts[0] == (1, 1), (name, starts[0])
        keys = [a * 1000 + b for a, b in starts]
        assert keys == sorted(set(keys)), name + ' not strictly increasing'
        for a, b in starts:
            assert 1 <= a <= 114 and 1 <= b <= suras[a - 1]['ayat'], (name, a, b)
    # every juz is two hizbs, eight quarters: quarter 8k opens juz k+1
    assert [hizb[8 * k] for k in range(30)] == juz, 'hizb quarters do not open the juz'


def build():
    suras, juz, sajda, pages, hizb = metadata()
    check_layout(suras, juz, pages, hizb)
    assert len(suras) == 114, len(suras)
    assert sum(s['ayat'] for s in suras) == TOTAL_AYAT
    arabic = read_pipe('quran-simple.txt')
    uthmani = read_pipe('quran-uthmani.txt')
    assert set(uthmani) == set(arabic), 'uthmani and simple must have the same ayah keys'
    trans = {t: read_pipe(t + '.txt') for t in TRANSLATIONS}
    for name, table in [('quran-simple', arabic)] + list(trans.items()):
        assert len(table) == TOTAL_AYAT, (name, len(table))
    files = {}
    start = 0
    for n, s in enumerate(suras, 1):
        assert s['start'] == start, (n, s['start'], start)
        start += s['ayat']
        rows = ['ayah\tarabic\ttranslit\tlatin\t' + '\t'.join(t.split('.')[0] for t in TRANSLATIONS) + '\tuthmani']
        for a in range(1, s['ayat'] + 1):
            k = (n, a)
            ar = clean_arabic(k, arabic[k])
            assert ar, k
            # nothing but basmala, tatweel and the two decorative signs was removed
            src_words = [skeleton(w) for w in arabic[k].translate(DROP).split() if skeleton(w)]
            if a == 1 and n != 1 and src_words[:4] == BASMALA_SKELETON:
                src_words = src_words[4:]
            assert [skeleton(w) for w in ar.split() if skeleton(w)] == src_words, k
            tl = transliterate_ayah(ar, n, a)
            assert tl and not re.search(r'[\u0600-\u06ff]', tl), (k, tl)
            lat = to_latin(tl)
            cols = [str(a), ar, tl, lat] + [clean_translation(trans[t][k], t.split('.')[0]) for t in TRANSLATIONS]
            assert not re.search(r'[\u0400-\u04ff]', cols[-1]), (k, 'Cyrillic left in Uzbek')
            uth = clean_uthmani(k, uthmani[k])
            # the basmala goes from the Uthmani ayah exactly where it went from the simple one
            had = a == 1 and n != 1 and [uthmani_skeleton(w) for w in uthmani[k].split()[:4]] == BASMALA_SKELETON
            assert had == (a == 1 and n != 1 and [skeleton(w) for w in arabic[k].translate(DROP).split()[:4]] == BASMALA_SKELETON), k
            assert uth and not re.search(r'[\u0400-\u04ffA-Za-z]', uth), k
            cols.append(uth)
            for c in cols:
                assert c and '\t' not in c and '\n' not in c, k
            rows.append('\t'.join(cols))
        files['%03d.tsv' % n] = '\n'.join(rows) + '\n'
    return files, kotlin_index(suras, juz, sajda, pages, hizb)


def wrap_ints(values, per_line=12):
    rows = [', '.join(str(v) for v in values[i:i + per_line]) for i in range(0, len(values), per_line)]
    return ['        ' + r + (',' if i < len(rows) - 1 else '') for i, r in enumerate(rows)]


def kq(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('$', '\\$') + '"'


def kotlin_index(suras, juz, sajda, pages, hizb):
    lines = [
        'package com.nur.prayer.quran',
        '',
        '// GENERATED by tools/quran_data.py from the Tanzil metadata (tools/quran_src). Do not edit by hand:',
        '// change the script and run `python3 tools/quran_data.py build`; CI runs `check`.',
        '',
        '/** The 114 surahs in mushaf order, with the juz starts and the places of prostration. */',
        'object QuranIndex {',
        '    const val SURAH_COUNT = 114',
        '    const val AYAH_COUNT = %d' % TOTAL_AYAT,
        '',
        '    val SURAHS: List<SurahMeta> = listOf(',
    ]
    for n, (s, (ru, meaning)) in enumerate(zip(suras, RU), 1):
        lines.append('        SurahMeta(%d, %s, %s, %s, %s, %s, %d, %s, %d),' % (
            n, kq(s['arabic']), kq(s['latin']), kq(ru), kq(meaning), kq(s['english']), s['ayat'],
            'true' if s['medinan'] else 'false', s['start']))
    lines[-1] = lines[-1].rstrip(',')
    lines += [
        '    )',
        '',
        '    /** Juz 1..30 start at JUZ[i] = surah * 1000 + ayah. */',
        '    val JUZ: IntArray = intArrayOf(' + ', '.join(str(a * 1000 + b) for a, b in juz) + ')',
        '',
        '    /** Ayat after which a prostration of recitation is made (Tanzil list, 15 places). */',
        '    val SAJDA: Set<Int> = setOf(' + ', '.join(str(a * 1000 + b) for a, b in sajda) + ')',
        '',
        '    /** 22:77 is a place of prostration in the Shafi‘i school only; the Hanafi school counts 14. */',
        '    const val SAJDA_SHAFII_ONLY = 22077',
        '',
        '    /** 0.18.0. The Madani mushaf (King Fahd Complex print): 604 pages, 60 hizbs of 4 quarters. */',
        '    const val PAGE_COUNT = ' + str(PAGE_COUNT),
        '    const val HIZB_QUARTERS = ' + str(HIZB_QUARTERS),
        '',
        '    /** 0.18.0. Madani mushaf page p (1..604) starts at PAGE_STARTS[p - 1] = surah * 1000 + ayah. */',
        '    val PAGE_STARTS: IntArray = intArrayOf(',
    ] + wrap_ints([a * 1000 + b for a, b in pages]) + [
        '    )',
        '',
        '    /** 0.18.0. Quarter q (0..239) of the 60 hizbs starts at HIZB_STARTS[q]; quarter 8k opens juz k + 1. */',
        '    val HIZB_STARTS: IntArray = intArrayOf(',
    ] + wrap_ints([a * 1000 + b for a, b in hizb]) + [
        '    )',
        '}',
        '',
    ]
    return '\n'.join(lines)


QURAN_TEST = os.path.join(ROOT, 'app/src/test/java/com/nur/prayer/QuranTest.kt')
QURAN_SCREEN = os.path.join(ROOT, 'app/src/main/java/com/nur/prayer/ui/quran/QuranScreen.kt')


def kotlin_literals(path):
    """String literals of a Kotlin file with \\uXXXX decoded and "a" + "b" joined."""
    if not os.path.exists(path):
        return []
    src = open(path, encoding='utf-8').read()
    out = []
    for m in re.finditer(r'"(?:\\.|[^"\\\n])*"(?:\s*\+\s*"(?:\\.|[^"\\\n])*")*', src):
        parts = re.findall(r'"((?:\\.|[^"\\\n])*)"', m.group(0))
        out.append(re.sub(r'\\u([0-9A-Fa-f]{4})', lambda u: chr(int(u.group(1), 16)), ''.join(parts)))
    return out


def arabic_literals_match(files):
    """0.16.1: every vowelled Arabic literal in QuranTest/QuranScreen must occur verbatim in the data.
    Catches mark order (fatha+shadda typed vs Tanzil shadda+fatha): same glyphs, unequal strings."""
    ayat = set()
    for body in files.values():
        for line in body.split('\n')[1:]:
            cols = line.split('\t')
            if len(cols) > 1:
                ayat.add(cols[1])
            if len(cols) > 8:
                ayat.add(cols[8])  # 0.21.1: Uthmani literals (BASMALA_UTHMANI) are checked the same way
    bad = []
    for path in (QURAN_TEST, QURAN_SCREEN):
        for lit in kotlin_literals(path):
            if not re.search('[\u064B-\u0652]', lit):
                continue
            if lit not in ayat:
                hint = ' (same text after NFC: mark order differs from Tanzil)' if any(
                    unicodedata.normalize('NFC', lit) == unicodedata.normalize('NFC', a) for a in ayat) else ''
                bad.append('%s: Arabic literal not found verbatim in the data%s: %s'
                           % (os.path.basename(path), hint, lit[:40]))
    return bad


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'check'
    files, index = build()
    if cmd == 'build':
        os.makedirs(ASSETS, exist_ok=True)
        for name in os.listdir(ASSETS):
            if name.endswith('.tsv') and name not in files:
                os.remove(os.path.join(ASSETS, name))
        for name, body in files.items():
            with open(os.path.join(ASSETS, name), 'w', encoding='utf-8', newline='\n') as f:
                f.write(body)
        os.makedirs(os.path.dirname(INDEX_KT), exist_ok=True)
        with open(INDEX_KT, 'w', encoding='utf-8', newline='\n') as f:
            f.write(index)
        print('built %d surah files, %d ayat' % (len(files), TOTAL_AYAT))
        return
    bad = []
    shipped = sorted(n for n in os.listdir(ASSETS) if n.endswith('.tsv')) if os.path.isdir(ASSETS) else []
    if shipped != sorted(files):
        bad.append('surah file set differs: %d shipped, %d expected' % (len(shipped), len(files)))
    for name, body in files.items():
        p = os.path.join(ASSETS, name)
        if not os.path.exists(p) or open(p, encoding='utf-8').read() != body:
            bad.append('stale or missing ' + name)
    if not os.path.exists(INDEX_KT) or open(INDEX_KT, encoding='utf-8').read() != index:
        bad.append('stale QuranIndex.kt')
    bad += arabic_literals_match(files)
    if bad:
        print('\n'.join(bad[:20]))
        sys.exit('quran_data: %d problem(s); run python3 tools/quran_data.py build' % len(bad))
    print('PASS: 114 surahs, %d ayat in mushaf order; Arabic, two readings and 4 translations match the Tanzil sources.' % TOTAL_AYAT)


if __name__ == '__main__':
    main()
