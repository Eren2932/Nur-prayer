#!/usr/bin/env python3
"""Every `androidx.compose.animation*` import must name a symbol that exists.

0.12.0 failed `compileDebugKotlin` on `import androidx.compose.animation.using`: `using` is a member
of the transition scope inside `AnimatedContent { transitionSpec }`, not a top-level function, so
the import is unresolved. Static checks cannot see the Compose jar, so this keeps an allowlist of
the animation symbols the project is known to compile with. A new import is not an error in itself:
confirm the symbol in the Compose API docs, then add it below.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

ANIMATION = {
    'AnimatedContent', 'AnimatedVisibility', 'Crossfade', 'AnimatedVisibilityScope', 'EnterExitState', 'ExperimentalAnimationApi', 'SizeTransform', 'animateColorAsState', 'animateContentSize',
    'expandVertically', 'expandHorizontally', 'shrinkVertically', 'shrinkHorizontally', 'fadeIn', 'fadeOut',
    'scaleIn', 'scaleOut', 'slideInHorizontally', 'slideOutHorizontally', 'slideInVertically',
    'slideOutVertically', 'togetherWith', 'EnterTransition', 'ExitTransition', 'ContentTransform',
}
ANIMATION_CORE = {
    'Animatable', 'FastOutLinearInEasing', 'FastOutSlowInEasing', 'LinearEasing', 'LinearOutSlowInEasing',
    'FiniteAnimationSpec', 'AnimationSpec', 'RepeatMode', 'Spring', 'animate', 'animateDpAsState',
    'animateFloat', 'animateFloatAsState', 'infiniteRepeatable', 'rememberInfiniteTransition', 'spring',
    'tween', 'keyframes', 'snap', 'updateTransition', 'Easing', 'CubicBezierEasing',
}
KNOWN = {'androidx.compose.animation': ANIMATION, 'androidx.compose.animation.core': ANIMATION_CORE}
IMPORT = re.compile(r'^import\s+(androidx\.compose\.animation(?:\.core)?)\.([A-Za-z0-9_]+)(?:\s+as\s+\w+)?\s*$')


def problems(root=ROOT):
    out = []
    for path in sorted((root / 'app/src').rglob('*.kt')):
        for n, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
            m = IMPORT.match(line.strip())
            if m and m[2] not in KNOWN[m[1]]:
                out.append(f'{path.relative_to(root)}:{n}: {m[1]}.{m[2]} is not a known Compose symbol')
    return out


def main():
    found = problems()
    if found:
        print('\n'.join(found))
        sys.exit(f'check_compose_imports: {len(found)} unknown animation import(s)')
    print('PASS: every androidx.compose.animation import is a known symbol (source preflight only).')


if __name__ == '__main__':
    main()
