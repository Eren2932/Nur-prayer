#!/usr/bin/env python3
"""Nur 0.21.1: reference implementation of the tajweed colouring (quran/Tajweed.kt mirrors it).

The rules read only the Unicode marks of the Tanzil Uthmani text (Madinah mushaf orthography), no
external tables. Every colour covers a whole grapheme (letter + its marks): splitting a mark from
its letter breaks Arabic shaping on Android, so a mark is never coloured apart from its letter.

  python3 tools/tajweed.py golden   -> rewrites app/src/test/resources/tajweed_golden.tsv
  python3 tools/tajweed.py check    -> golden file is up to date with this implementation
  python3 tools/tajweed.py stats    -> rule counts over the whole Quran
  python3 tools/tajweed.py show S:A -> spans of one ayah

Rules (priority from top):
  SILENT      grey    hamzat al-wasl ٱ; a letter with ۟ or ۠; a bare consonant before a shadda
                      (lam shamsiyya, idgham: مِّن رَّبِّهِمْ, قَد تَّبَيَّنَ)
  MADD_LONG   red     a letter with maddah ٓ (lazim, wajib, ja'iz, silah kubra; الٓمٓ, بِمَآ)
  MADD        orange  dagger alif ٰ, small waw/yeh ۥ ۦ (2 counts); madd/leen letter before the last
                      letter at a stop (end of ayah or a pause sign): ٱلْمُتَّقِينَ, رَيْبَ ۛ
  GHUNNA      green   نّ مّ; small high noon ۨ; ikhfa (ن or tanween before ت ث ج د ذ ز س ش ص ض ط ظ ف ق ك); idgham with
                      ghunna (ن or tanween before ي ن م و of the next word); iqlab ۢ ۭ; ikhfa shafawi م ب
  QALQALA     cyan    ق ط ب ج د with sukun, or last letter at a stop
  TAFKHIM     blue    خ ص ض غ ط ق ظ; ر with fatha/damma, or sakin after fatha/damma (and the usual
                      exceptions: after ي sakin and after kasra light, after hamzat al-wasl or before an
                      isti'la letter heavy, imala ۪ light)
"""
import pathlib
import sys
import unicodedata

ROOT = pathlib.Path(__file__).resolve().parent.parent
GOLDEN = ROOT / 'app/src/test/resources/tajweed_golden.tsv'
QURAN = ROOT / 'app/src/main/assets/quran'

SILENT, MADD_LONG, MADD, GHUNNA, QALQALA, TAFKHIM = 'SILENT', 'MADD_LONG', 'MADD', 'GHUNNA', 'QALQALA', 'TAFKHIM'
PRIORITY = [SILENT, MADD_LONG, MADD, GHUNNA, QALQALA, TAFKHIM]

FATHA, DAMMA, KASRA = '\u064E', '\u064F', '\u0650'
FATHATAN, DAMMATAN, KASRATAN = '\u064B', '\u064C', '\u064D'
SHADDA, SUKUN, MADDAH, DAGGER = '\u0651', '\u0652', '\u0653', '\u0670'
ROUND_ZERO, RECT_ZERO, SUKUN_KHAH = '\u06DF', '\u06E0', '\u06E1'
IQLAB = {'\u06E2', '\u06ED'}
IMALA = '\u06EA'
SMALL_NOON = '\u06E8'  # نُۨجِى: a hidden second noon, read with ikhfa
WASLA, ALIF, MAQSURA, WAW, YA = '\u0671', '\u0627', '\u0649', '\u0648', '\u064A'
SMALL_WAW, SMALL_YA, TATWEEL = '\u06E5', '\u06E6', '\u0640'
NOON, MEEM, RA, BA = '\u0646', '\u0645', '\u0631', '\u0628'
TANWEEN = {FATHATAN, DAMMATAN, KASRATAN}
VOWEL_MARKS = {FATHA, DAMMA, KASRA} | TANWEEN
SUKUNS = {SUKUN, SUKUN_KHAH}
# Pause signs after which a reader stops; ۙ (06D9, "do not stop") is not one of them.
STOP_SIGNS = {'\u06D6', '\u06D7', '\u06D8', '\u06DA', '\u06DB'}
PAUSE_SIGNS = STOP_SIGNS | {'\u06D9'}
QALQALA_LETTERS = set('قطبجد')
ISTILA = set('خصضغطقظ')
IKHFA_LETTERS = set('تثجدذزسشصضطظفقك')
IDGHAM_GHUNNA = set('ينمو')


def is_letter(ch):
    return ('\u0621' <= ch <= '\u064A' and ch != TATWEEL) or ch in (WASLA, SMALL_WAW, SMALL_YA)


class G:
    __slots__ = ('start', 'end', 'base', 'marks', 'word')

    def __init__(self, start, base):
        self.start, self.end, self.base, self.marks, self.word = start, start + 1, base, set(), -1

    def has(self, *ms):
        return any(m in self.marks for m in ms)

    @property
    def bare(self):
        """No vowel, sukun, shadda, dagger alif, silence or madd sign at all."""
        return not (self.marks & (VOWEL_MARKS | SUKUNS | IQLAB | {SHADDA, DAGGER, ROUND_ZERO, RECT_ZERO, MADDAH}))


def graphemes(text):
    out = []
    for i, ch in enumerate(text):
        mark = unicodedata.category(ch) == 'Mn'
        if mark and out and out[-1].base != ' ' and not (out[-1].base in PAUSE_SIGNS):
            out[-1].marks.add(ch)
            out[-1].end = i + 1
        else:
            out.append(G(i, ch))
    return out


def spans(text):
    """[(start, end, rule)] over [text], sorted, non-overlapping, whole graphemes."""
    gs = graphemes(text)
    # Words of letters; a pause sign is its own token and marks a stop on the word before it.
    words, cur = [], []
    stop_words = set()
    for g in gs:
        if g.base == ' ':
            if cur:
                words.append(cur)
                cur = []
        elif g.base in PAUSE_SIGNS:
            if cur:
                words.append(cur)
                cur = []
            if g.base in STOP_SIGNS and words:
                stop_words.add(len(words) - 1)
        elif is_letter(g.base) or (g.base == TATWEEL and g.marks):
            cur.append(g)  # a tatweel with marks carries a hamza (ٱلْـَٔاخِرَةِ): it is a letter
    if cur:
        words.append(cur)
    if words:
        stop_words.add(len(words) - 1)  # end of the ayah
    letters = []
    for w, word in enumerate(words):
        for g in word:
            g.word = w
            letters.append(g)
    n = len(letters)

    def at(i):
        return letters[i] if 0 <= i < n else None

    def vowel_of(g):
        if g is None:
            return None
        if g.has(FATHA, FATHATAN):
            return FATHA
        if g.has(DAMMA, DAMMATAN):
            return DAMMA
        if g.has(KASRA, KASRATAN):
            return KASRA
        return None

    def is_madd_letter(i):
        """ا after fatha, و after damma, ي/ى after kasra, written without a vowel or sukun."""
        g, p = at(i), at(i - 1)
        if g is None or p is None or p.word != g.word or not g.bare and not g.has(DAGGER):
            return False
        v = vowel_of(p)
        return (g.base == ALIF and (v == FATHA or p.has(DAGGER))) or (g.base == MAQSURA and v in (FATHA, KASRA)) \
            or (g.base == WAW and v == DAMMA) or (g.base == YA and v == KASRA)

    def is_leen(i):
        g, p = at(i), at(i - 1)
        return g is not None and p is not None and p.word == g.word and g.base in (WAW, YA) \
            and g.has(*SUKUNS) and vowel_of(p) == FATHA

    def is_tanween_carrier(i):
        """ا or ى after a letter with fathatan, or any bare letter right after a tanween."""
        g, p = at(i), at(i - 1)
        return g is not None and p is not None and p.word == g.word and g.bare and p.has(*TANWEEN)

    def last_index(w):
        idx = [i for i in range(n) if letters[i].word == w]
        return idx[-1] if idx else -1

    def tanween_target(i):
        """For a tanween on letter i, the first letter of what follows (after a carrier ا/ى)."""
        j = i + 1
        while j < n and letters[j].word == letters[i].word and is_tanween_carrier(j):
            j += 1
        return j if j < n and letters[j].word != letters[i].word else None

    rule = [set() for _ in range(n)]
    for i, g in enumerate(letters):
        nx = at(i + 1)
        last_of_word = nx is None or nx.word != g.word
        at_stop = last_of_word and g.word in stop_words
        # ── silent ──
        if g.base == WASLA or g.has(ROUND_ZERO, RECT_ZERO):
            rule[i].add(SILENT)
        elif g.bare and g.base not in (ALIF, MAQSURA, SMALL_WAW, SMALL_YA) and not is_madd_letter(i) \
                and not is_tanween_carrier(i) and nx is not None and nx.has(SHADDA) and not (at_stop and g.word != nx.word):
            rule[i].add(SILENT)
        # ── madd ──
        if g.has(MADDAH):
            rule[i].add(MADD_LONG)
        if g.has(DAGGER) or g.base in (SMALL_WAW, SMALL_YA):
            rule[i].add(MADD)
        # ── ghunna family ──
        if g.base in (NOON, MEEM) and g.has(SHADDA):
            rule[i].add(GHUNNA)
        if g.marks & IQLAB or g.has(SMALL_NOON):
            rule[i].add(GHUNNA)
        if g.base == NOON and (g.bare or g.has(*SUKUNS)) and nx is not None and not (at_stop and nx.word != g.word):
            if nx.base in IKHFA_LETTERS and not nx.has(SHADDA):
                rule[i].add(GHUNNA)
            elif last_of_word and g.bare and nx.base in IDGHAM_GHUNNA and not nx.has(SHADDA):
                rule[i].add(GHUNNA)  # idgham naqis: مَن يَقُولُ (no shadda in the Madinah mushaf)
        if g.has(*TANWEEN) and not (g.marks & IQLAB) and not at_stop:
            t = tanween_target(i)
            if t is not None and (letters[t].base in IKHFA_LETTERS or letters[t].base in IDGHAM_GHUNNA):
                rule[i].add(GHUNNA)
        if g.base == MEEM and g.bare and nx is not None and nx.base == BA and not (at_stop and nx.word != g.word):
            rule[i].add(GHUNNA)  # ikhfa shafawi
        # ── qalqala ──
        if g.base in QALQALA_LETTERS and (g.has(*SUKUNS) or (at_stop and not g.has(FATHATAN))):
            rule[i].add(QALQALA)
        # ── tafkhim ──
        if g.base in ISTILA:
            rule[i].add(TAFKHIM)
        if g.base == RA and heavy_ra(i, at_stop, letters, at, vowel_of, is_madd_letter):
            rule[i].add(TAFKHIM)
    # madd 'arid / leen at a stop: the madd letter right before the last letter of a stop word
    for w in stop_words:
        li = last_index(w)
        if li < 1 or letters[li].has(FATHATAN):
            continue
        last = letters[li]
        if last.base in (ALIF, MAQSURA) and is_madd_letter(li):
            continue  # the word ends in a madd letter itself: plain 2 counts
        p = li - 1
        if letters[p].word == w and (is_madd_letter(p) or is_leen(p)):
            rule[p].add(MADD)

    out = []
    for i, g in enumerate(letters):
        if rule[i]:
            r = next(r for r in PRIORITY if r in rule[i])
            if out and out[-1][1] == g.start and out[-1][2] == r:
                out[-1] = (out[-1][0], g.end, r)
            else:
                out.append((g.start, g.end, r))
    return out


def heavy_ra(i, at_stop, letters, at, vowel_of, is_madd_letter):
    g = letters[i]
    if g.has(IMALA):
        return False
    if not at_stop:
        if g.has(FATHA, FATHATAN, DAMMA, DAMMATAN):
            return True
        if g.has(KASRA, KASRATAN):
            return False
    # ر sakin (written sukun, or any ر that ends a word at a stop)
    if at_stop and g.has(FATHATAN):
        return True  # stop on ـرًا: read with fatha
    j = i - 1
    p = at(j)
    if p is None or p.word != g.word:
        return True
    if p.base == WASLA:
        return True  # ٱرْجِعِىٓ: the kasra of the wasla is not a real one
    if p.base in (YA, MAQSURA) and (p.has(*SUKUNS) or is_madd_letter(j)):
        return False  # خَيْرٌ, قَدِيرٌ at a stop
    if p.has(*SUKUNS) or p.bare or is_madd_letter(j):
        q = at(j - 1)
        if q is None or q.word != g.word:
            return True
        if q.base == WASLA:
            return True
        v = vowel_of(q)
        return v != KASRA
    v = vowel_of(p)
    if v == KASRA:
        nx = at(i + 1)
        # قِرْطَاسٍ, مِرْصَادًا, فِرْقَةٍ: an isti'la letter right after keeps the ر heavy
        return nx is not None and nx.word == g.word and nx.base in ISTILA and not at_stop
    return True


# ── data access ──────────────────────────────────────────────────────────────────────────────────
def uthmani(sura, ayah):
    lines = (QURAN / f'{sura:03d}.tsv').read_text(encoding='utf-8').splitlines()
    head = lines[0].split('\t')
    for line in lines[1:]:
        c = line.split('\t')
        if int(c[0]) == ayah:
            return c[head.index('uthmani')]
    raise KeyError(f'{sura}:{ayah}')


def all_ayat():
    for f in sorted(QURAN.glob('*.tsv')):
        lines = f.read_text(encoding='utf-8').splitlines()
        head = lines[0].split('\t')
        col = head.index('uthmani')
        for line in lines[1:]:
            c = line.split('\t')
            yield int(f.stem), int(c[0]), c[col]


# Golden ayat: every rule, its exceptions, stops, muqatta'at, Surah 1 and the reference screens.
GOLDEN_AYAT = ['1:1', '1:2', '1:3', '1:4', '1:5', '1:6', '1:7', '2:1', '2:2', '2:3', '2:4', '2:5', '2:6',
               '2:7', '2:10', '2:255', '3:7', '4:58', '5:3', '6:1', '7:54', '11:41', '12:4', '19:1', '20:5',
               '36:1', '36:2', '41:44', '55:13', '68:1', '70:1', '78:30', '89:1', '89:4', '96:1', '96:19',
               '97:1', '97:5', '99:7', '99:8', '102:1', '103:3', '105:4', '108:1', '108:3', '111:1',
               '112:1', '112:2', '112:3', '112:4', '113:1', '113:5', '114:1', '114:4', '114:6']


def golden_lines():
    out = ['# ref\tuthmani text\tspans (start-end:RULE ...), generated by tools/tajweed.py golden']
    for ref in GOLDEN_AYAT:
        s, a = map(int, ref.split(':'))
        t = uthmani(s, a)
        out.append(ref + '\t' + t + '\t' + ' '.join(f'{x}-{y}:{r}' for x, y, r in spans(t)))
    return out


def main(args):
    if args == ['golden']:
        GOLDEN.parent.mkdir(parents=True, exist_ok=True)
        GOLDEN.write_text('\n'.join(golden_lines()) + '\n', encoding='utf-8')
        print(f'wrote {GOLDEN.relative_to(ROOT)} ({len(GOLDEN_AYAT)} ayat)')
    elif args == ['check']:
        want = '\n'.join(golden_lines()) + '\n'
        if not GOLDEN.is_file() or GOLDEN.read_text(encoding='utf-8') != want:
            print('tajweed golden is stale: python3 tools/tajweed.py golden')
            sys.exit(1)
        print(f'tajweed: golden OK ({len(GOLDEN_AYAT)} ayat)')
    elif args == ['stats']:
        from collections import Counter
        c = Counter()
        for _, _, t in all_ayat():
            for _, _, r in spans(t):
                c[r] += 1
        for r in PRIORITY:
            print(f'{r:10} {c[r]}')
    elif len(args) == 2 and args[0] == 'show':
        s, a = map(int, args[1].split(':'))
        t = uthmani(s, a)
        print(t)
        for x, y, r in spans(t):
            print(f'{x:4}-{y:<4} {r:10} {t[x:y]}')
    else:
        print(__doc__)
        sys.exit(2)


if __name__ == '__main__':
    main(sys.argv[1:])
