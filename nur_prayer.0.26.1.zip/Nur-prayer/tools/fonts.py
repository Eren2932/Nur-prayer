#!/usr/bin/env python3
"""Nur 0.21.0: the Arabic (mushaf) face shipped in the APK.

  python3 tools/fonts.py install PATH   -> validate a .ttf/.otf/.woff/.woff2/.zip, write
                                           app/src/main/assets/fonts/quran_hafs.ttf + tools/fonts.lock
  python3 tools/fonts.py fetch          -> best effort: download from FETCH_URLS, then the same as install
  python3 tools/fonts.py check          -> CI: validates the shipped face against the lock and against
                                           every Arabic codepoint the app shows. No face = warning only
                                           (the app falls back to the system Naskh), a bad face = failure.
  python3 tools/fonts.py report         -> which codepoints the app needs and where they come from

The face is «KFGQPC Uthmanic Script HAFS» of the King Fahd Glorious Quran Printing Complex
(fonts.qurancomplex.gov.sa). It is free to use and redistribute unmodified; keep the licence text that
comes with the download in docs/fonts/. The app reads it through ui/theme/ArabicFont.kt.

Needs fontTools (pip install fonttools; brotli as well for .woff2).
"""
import hashlib
import io
import json
import os
import pathlib
import re
import sys
import unicodedata
import urllib.request
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
ASSET = ROOT / 'app/src/main/assets/fonts/quran_hafs.ttf'
LOCK = ROOT / 'tools/fonts.lock'
QURAN = ROOT / 'app/src/main/assets/quran'
KOTLIN = ROOT / 'app/src/main/java'
EXTRA_ASSETS = [ROOT / 'app/src/main/assets/learn', ROOT / 'app/src/main/assets/hifz']

# The family must look like the KFGQPC Hafs face, not any Arabic font that happens to be at hand.
FAMILY_HINTS = ('hafs', 'uthman')
# Tried in order by `fetch`; each result is validated, a wrong file is rejected, not shipped.
FETCH_URLS = [
    'https://github.com/quran/quran.com-frontend-next/raw/production/public/fonts/quran/hafs/uthmanic_hafs/UthmanicHafs1Ver18.ttf',
    'https://github.com/quran/quran.com-frontend-next/raw/production/public/fonts/quran/hafs/uthmanic_hafs/UthmanicHafs1Ver18.woff2',
]
ARABIC = re.compile(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]')
# Joiners, directional marks and spaces are layout controls, not glyphs a font has to draw.
IGNORED = {0x200C, 0x200D, 0x200E, 0x200F, 0x061C, 0x00A0, 0x0020, 0x202F}


def die(msg):
    print('fonts: ' + msg, file=sys.stderr)
    sys.exit(1)


def _tt():
    try:
        from fontTools.ttLib import TTFont  # noqa: F401
        return TTFont
    except ImportError:
        die('fontTools is required: pip install fonttools brotli')


# ── what the app needs ──────────────────────────────────────────────────────────────────────────
# 0.21.1. Tanzil Uthmani marks -> the marks the KFGQPC face draws (mirror of quran/MushafGlyphs.kt).
# The face draws the mushaf sukun (khah head) at U+06E1 and the silent-letter circle at U+0652; its
# U+06DF/06E3/06EB are wide placeholders. Char-for-char, so tajweed spans keep their offsets.
MUSHAF_GLYPHS = {'\u0652': '\u06E1', '\u06DF': '\u0652', '\u06E3': '\u200D', '\u06EB': '\u200D'}


def mushaf(text):
    return ''.join(MUSHAF_GLYPHS.get(ch, ch) for ch in text)


def quran_texts():
    """(file, text as the face receives it) for every ayah: the simple text and the encoded Uthmani."""
    for f in sorted(QURAN.glob('*.tsv')):
        lines = f.read_text(encoding='utf-8').splitlines()
        head = lines[0].split('\t')
        cols = [head.index('arabic')]
        uth = head.index('uthmani') if 'uthmani' in head else -1
        for line in lines[1:]:
            parts = line.split('\t')
            yield f.name, parts[cols[0]]
            if 0 <= uth < len(parts) and parts[uth]:
                yield f.name, mushaf(parts[uth])


def quran_codepoints():
    need = {}
    for name, text in quran_texts():
        for ch in text:
            cp = ord(ch)
            if cp not in IGNORED and not ch.isspace() and cp != 0x200D:
                need.setdefault(cp, name)
    # Ayah numbers are drawn at run time (QuranMath.arabicDigits) in the same face.
    for cp in range(0x0660, 0x066A):
        need.setdefault(cp, 'ayah numbers')
    return need


def app_codepoints():
    """Arabic in Kotlin sources and content assets (lessons, hifz), excluding the Arabic UI language."""
    need = {}
    files = list(KOTLIN.rglob('*.kt'))
    for d in EXTRA_ASSETS:
        if d.is_dir():
            files += [p for p in d.rglob('*') if p.is_file()]
    for f in files:
        try:
            text = f.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            continue
        for run in re.findall(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF\u064B-\u065F\u0670]+', text):
            for ch in run:
                cp = ord(ch)
                if cp not in IGNORED:
                    need.setdefault(cp, str(f.relative_to(ROOT)))
    return need


# ── validation ──────────────────────────────────────────────────────────────────────────────────
def family_name(font):
    names = font['name']
    for nid in (16, 1, 4):
        n = names.getDebugName(nid)
        if n:
            return n
    return '?'


def version_name(font):
    return font['name'].getDebugName(5) or '?'


def validate(font, strict_family=True):
    """Returns (errors, warnings)."""
    errors, warnings = [], []
    fam = family_name(font)
    if strict_family and not any(h in fam.lower() for h in FAMILY_HINTS):
        errors.append(f'family «{fam}» is not the KFGQPC Uthmanic HAFS face')
    cmap = font.getBestCmap() or {}
    gsub = font['GSUB'].table if 'GSUB' in font else None
    scripts = {r.ScriptTag for r in gsub.ScriptList.ScriptRecord} if gsub and gsub.ScriptList else set()
    if 'arab' not in scripts:
        errors.append('no GSUB "arab" script: letters would not join')
    else:
        feats = {r.FeatureTag for r in gsub.FeatureList.FeatureRecord}
        for f in ('init', 'medi', 'fina'):
            if f not in feats:
                errors.append(f'GSUB feature {f} missing: letters would not join')
    if 'GPOS' not in font:
        errors.append('no GPOS: vowel marks would not be positioned')
    q = quran_codepoints()
    missing_q = sorted(cp for cp in q if cp not in cmap)
    if missing_q:
        errors.append('missing in the Quran text: ' + ', '.join(
            f'U+{cp:04X} {unicodedata.name(chr(cp), "?")} ({q[cp]})' for cp in missing_q))
    # A combining mark must reach the face as a mark (GDEF class 3): a base glyph with an advance
    # would be drawn as its own wide symbol inside the word (the U+06DF placeholder of 0.21.1).
    gdef = font['GDEF'].table if 'GDEF' in font else None
    classes = gdef.GlyphClassDef.classDefs if gdef and gdef.GlyphClassDef else {}
    not_marks = sorted(cp for cp in q if cp in cmap and unicodedata.category(chr(cp)) == 'Mn'
                       and classes.get(cmap[cp]) != 3)
    if not_marks:
        errors.append('drawn as a base glyph, not a mark: ' + ', '.join(
            f'U+{cp:04X} {unicodedata.name(chr(cp), "?")} ({q[cp]})' for cp in not_marks))
    a = app_codepoints()
    missing_a = sorted(cp for cp in a if cp not in cmap and cp not in q)
    if missing_a:
        warnings.append('missing elsewhere (system fallback draws them): ' + ', '.join(
            f'U+{cp:04X} {unicodedata.name(chr(cp), "?")} ({a[cp]})' for cp in missing_a))
    return errors, warnings


def load_any(data, name):
    """bytes of .ttf/.otf/.woff/.woff2/.zip -> (TTFont, label)."""
    TTFont = _tt()
    if name.lower().endswith('.zip') or data[:2] == b'PK':
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            members = [m for m in z.namelist() if re.search(r'\.(ttf|otf|woff2?)$', m, re.I)]
            if not members:
                die(f'{name}: no font inside the archive')
            # Prefer the Hafs face when the archive holds the whole KFGQPC family.
            members.sort(key=lambda m: (not any(h in m.lower() for h in FAMILY_HINTS), len(m)))
            return load_any(z.read(members[0]), members[0])
    try:
        font = TTFont(io.BytesIO(data))
    except Exception as e:  # noqa: BLE001
        die(f'{name}: not a font ({e})')
    if font.flavor:
        font.flavor = None  # woff/woff2 -> plain sfnt: Android reads only TTF/OTF
        font._nur_original = None
    else:
        # The KFGQPC licence forbids modifying the font (and the file is digitally signed): a TTF/OTF
        # is shipped byte for byte, never re-serialised by fontTools.
        font._nur_original = data
    return font, name


def write(font, label):
    errors, warnings = validate(font)
    for w in warnings:
        print('warning: ' + w)
    if errors:
        die('rejected ' + label + ':\n  - ' + '\n  - '.join(errors))
    ASSET.parent.mkdir(parents=True, exist_ok=True)
    data = getattr(font, '_nur_original', None)
    if data is None:
        buf = io.BytesIO()
        font.save(buf)
        data = buf.getvalue()
    ASSET.write_bytes(data)
    lock = {
        'asset': str(ASSET.relative_to(ROOT)),
        'sha256': hashlib.sha256(data).hexdigest(),
        'bytes': len(data),
        'family': family_name(font),
        'version': version_name(font),
        'source': label,
    }
    LOCK.write_text(json.dumps(lock, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f'installed {lock["family"]} ({lock["version"]}), {len(data) // 1024} KB, sha256 {lock["sha256"][:16]}…')
    print(f'covers all {len(quran_codepoints())} codepoints of the Quran text')


def cmd_install(path):
    p = pathlib.Path(path)
    if not p.is_file():
        die(f'{path}: no such file')
    font, label = load_any(p.read_bytes(), p.name)
    write(font, label)


def cmd_fetch():
    for url in FETCH_URLS:
        try:
            print('trying ' + url)
            with urllib.request.urlopen(url, timeout=30) as r:
                data = r.read()
            font, label = load_any(data, url.rsplit('/', 1)[-1])
            errors, _ = validate(font)
            if errors:
                print('  rejected: ' + '; '.join(errors))
                continue
            write(font, url)
            return
        except SystemExit:
            raise
        except Exception as e:  # noqa: BLE001
            print(f'  failed: {e}')
    die('no candidate worked; download the font from fonts.qurancomplex.gov.sa and run `install PATH`')


def cmd_check():
    if not ASSET.is_file():
        msg = f'{ASSET.relative_to(ROOT)} is absent: Arabic falls back to the system font. Run tools/fonts.py install.'
        # GitHub annotation: visible on the run page, does not fail the build.
        print(('::warning::' if os.environ.get('GITHUB_ACTIONS') else 'warning: ') + msg)
        return
    data = ASSET.read_bytes()
    if LOCK.is_file():
        lock = json.loads(LOCK.read_text(encoding='utf-8'))
        if lock.get('sha256') != hashlib.sha256(data).hexdigest():
            die(f'{ASSET.name} differs from tools/fonts.lock: install fonts with tools/fonts.py install')
    else:
        die('tools/fonts.lock is missing: install fonts with tools/fonts.py install')
    font, _ = load_any(data, ASSET.name)
    errors, warnings = validate(font)
    for w in warnings:
        print('warning: ' + w)
    if errors:
        die('shipped face is not usable:\n  - ' + '\n  - '.join(errors))
    print(f'fonts: OK — {family_name(font)} ({version_name(font)}), Quran text fully covered')


def cmd_report():
    q, a = quran_codepoints(), app_codepoints()
    print(f'Quran text: {len(q)} codepoints; elsewhere in the app: {len(set(a) - set(q))} more')
    for cp in sorted(set(q) | set(a)):
        print(f'U+{cp:04X}  {unicodedata.name(chr(cp), "?"):<45} {q.get(cp) or a.get(cp)}')


if __name__ == '__main__':
    args = sys.argv[1:]
    if args[:1] == ['install'] and len(args) == 2:
        cmd_install(args[1])
    elif args == ['fetch']:
        cmd_fetch()
    elif args == ['check']:
        cmd_check()
    elif args == ['report']:
        cmd_report()
    else:
        print(__doc__)
        sys.exit(2)
