#!/usr/bin/env python3
"""0.22.0 wallpapers: one pipeline from a picture in `art/wallpapers/` to a ready asset.

    python3 tools/wallpapers.py build     # needs Pillow: trim, encode, lock (run after adding a picture)
    python3 tools/wallpapers.py check     # stdlib only, runs in CI

Adding a wallpaper is two steps:
  1. drop `art/wallpapers/<id>.jpg|png|webp` (id = lowercase latin, digits, `_`) and run `build`;
     it prints the suggested focus point of the picture;
  2. add one line to `WallpaperCatalog.kt` (`image("<id>", <category>, fx, fy) { tr("Название") }`).
Everything else — crop on any screen, contrast scrim, thumbnails, gallery sections, order — is
computed by the app from the picture itself.

What `build` does to each picture:
  * trims the thin dark frame AI upscalers leave on the edges (measured, up to 12 px a side) — on a
    phone it shows as a hairline around the screen;
  * caps the long side at 2560 px (QHD+ phones; more is only APK weight);
  * encodes WebP q90, method 6, sharp YUV: flat illustrations, gradient skies — this keeps the
    sky free of banding at ~1/4 of the JPEG size;
  * records the sha256, the size and a saliency focus in `art/wallpapers/wallpapers.lock.json`.

What `check` proves (no Pillow needed): every catalog id has its asset and every asset its
catalog line; the asset bytes are the locked ones; the WebP header agrees with the lock; the
picture is a portrait one; the catalog focus point is inside the picture.
"""
import hashlib
import json
import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / 'art/wallpapers'
ASSETS = ROOT / 'app/src/main/assets/wallpapers'
LOCK = ART / 'wallpapers.lock.json'
CATALOG = ROOT / 'app/src/main/java/com/nur/prayer/ui/wallpaper/WallpaperCatalog.kt'
ID = re.compile(r'^[a-z][a-z0-9_]{1,31}$')
ENTRY = re.compile(r'image\(\s*"([a-z0-9_]+)"\s*,\s*WallpaperCategory\.(\w+)\s*,\s*([0-9.]+)f\s*,\s*([0-9.]+)f\s*\)')
MAX_SIDE = 2560
MAX_TRIM = 12


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def webp_size(data):
    """Width and height from a RIFF/WEBP header (VP8, VP8L or VP8X), stdlib only."""
    if data[:4] != b'RIFF' or data[8:12] != b'WEBP':
        raise ValueError('not a WebP file')
    chunk = data[12:16]
    if chunk == b'VP8 ':
        w, h = struct.unpack('<HH', data[26:30])
        return w & 0x3FFF, h & 0x3FFF
    if chunk == b'VP8L':
        b = data[21:25]
        w = 1 + (((b[1] & 0x3F) << 8) | b[0])
        h = 1 + (((b[3] & 0xF) << 10) | (b[2] << 2) | ((b[1] & 0xC0) >> 6))
        return w, h
    if chunk == b'VP8X':
        w = 1 + int.from_bytes(data[24:27], 'little')
        h = 1 + int.from_bytes(data[27:30], 'little')
        return w, h
    raise ValueError('unknown WebP chunk ' + chunk.decode('latin1'))


def catalog_entries(source=None):
    source = source if source is not None else CATALOG.read_text(encoding='utf-8')
    return [(m[1], m[2], float(m[3]), float(m[4])) for m in ENTRY.finditer(source)]


def problems():
    out = []
    lock = json.loads(LOCK.read_text(encoding='utf-8')) if LOCK.exists() else {}
    entries = catalog_entries()
    ids = [e[0] for e in entries]
    if len(ids) != len(set(ids)):
        out.append('WallpaperCatalog.kt: duplicate wallpaper id')
    assets = {p.stem for p in ASSETS.glob('*.webp')} if ASSETS.exists() else set()
    for wid, category, fx, fy in entries:
        if not ID.match(wid):
            out.append(f'{wid}: id must be lowercase latin, digits and _')
        if not (0.0 <= fx <= 1.0 and 0.0 <= fy <= 1.0):
            out.append(f'{wid}: focus ({fx}, {fy}) is outside the picture')
        asset = ASSETS / f'{wid}.webp'
        if not asset.exists():
            out.append(f'{wid}: missing app/src/main/assets/wallpapers/{wid}.webp (run tools/wallpapers.py build)')
            continue
        if wid not in lock:
            out.append(f'{wid}: not in wallpapers.lock.json (run tools/wallpapers.py build)')
            continue
        data = asset.read_bytes()
        if hashlib.sha256(data).hexdigest() != lock[wid]['sha256']:
            out.append(f'{wid}: asset bytes differ from the lock (rebuild, do not hand-edit assets)')
        try:
            w, h = webp_size(data)
        except ValueError as e:
            out.append(f'{wid}: {e}')
            continue
        if [w, h] != [lock[wid]['width'], lock[wid]['height']]:
            out.append(f'{wid}: WebP is {w}x{h}, lock says {lock[wid]["width"]}x{lock[wid]["height"]}')
        if not 0.35 <= w / h <= 0.80:
            out.append(f'{wid}: {w}x{h} is not a portrait wallpaper (ratio {w / h:.3f})')
        if max(w, h) > MAX_SIDE:
            out.append(f'{wid}: {w}x{h} is larger than {MAX_SIDE} px')
    for stray in sorted(assets - set(ids)):
        out.append(f'assets/wallpapers/{stray}.webp has no line in WallpaperCatalog.kt (dead APK weight)')
    return out


def check():
    found = problems()
    if found:
        print('\n'.join(found))
        sys.exit(f'wallpapers: {len(found)} problem(s)')
    print(f'PASS: {len(catalog_entries())} wallpapers: catalog, assets and lock agree.')


# ---------------------------------------------------------------------------------------- build

def frame_width(gray, side):
    """Rows/columns of the outer frame: they differ from the picture just inside them."""
    import numpy as np
    h, w = gray.shape
    if side == 'top':
        lines = [gray[i, w // 4: 3 * w // 4].mean() for i in range(MAX_TRIM + 4)]
    elif side == 'bottom':
        lines = [gray[h - 1 - i, w // 4: 3 * w // 4].mean() for i in range(MAX_TRIM + 4)]
    elif side == 'left':
        lines = [gray[h // 10: h // 3, i].mean() for i in range(MAX_TRIM + 4)]
    else:
        lines = [gray[h // 10: h // 3, w - 1 - i].mean() for i in range(MAX_TRIM + 4)]
    inner = float(np.median(lines[MAX_TRIM:]))
    n = 0
    while n < MAX_TRIM and abs(lines[n] - inner) > 1.5:
        n += 1
    return n + 1 if n else 0  # one more line of JPEG ringing


def focus(image):
    """Saliency centroid: where the drawing is (edges), not where the empty sky is."""
    import numpy as np
    from PIL import ImageFilter
    small = image.convert('L').resize((200, max(1, int(200 * image.height / image.width))))
    a = np.asarray(small.filter(ImageFilter.GaussianBlur(1))).astype(float)
    g = np.hypot(np.abs(np.diff(a, axis=1))[:-1], np.abs(np.diff(a, axis=0))[:, :-1])
    g[g < 6] = 0
    if g.sum() == 0:
        return 0.5, 0.5
    ys, xs = np.mgrid[0:g.shape[0], 0:g.shape[1]]
    return (round(float((g * xs).sum() / g.sum() / g.shape[1]), 2),
            round(float((g * ys).sum() / g.sum() / g.shape[0]), 2))


def build():
    import numpy as np
    from PIL import Image
    ASSETS.mkdir(parents=True, exist_ok=True)
    lock = {}
    for src in sorted(p for p in ART.iterdir() if p.suffix.lower() in ('.jpg', '.jpeg', '.png', '.webp')):
        wid = src.stem
        if not ID.match(wid):
            sys.exit(f'{src.name}: rename to a lowercase latin id (a-z, 0-9, _)')
        image = Image.open(src).convert('RGB')
        gray = np.asarray(image.convert('L')).astype(float)
        t, b, l, r = (frame_width(gray, s) for s in ('top', 'bottom', 'left', 'right'))
        image = image.crop((l, t, image.width - r, image.height - b))
        if max(image.size) > MAX_SIDE:
            k = MAX_SIDE / max(image.size)
            image = image.resize((round(image.width * k), round(image.height * k)), Image.LANCZOS)
        out = ASSETS / f'{wid}.webp'
        image.save(out, 'WEBP', quality=90, method=6, use_sharp_yuv=True)
        fx, fy = focus(image)
        lock[wid] = {'sha256': sha256(out), 'width': image.width, 'height': image.height,
                     'trim': [l, t, r, b], 'source': src.name, 'suggestedFocus': [fx, fy]}
        print(f'{wid}: {image.width}x{image.height}, trimmed l{l} t{t} r{r} b{b}, '
              f'{out.stat().st_size // 1024} KB, focus {fx:.2f} {fy:.2f}')
    LOCK.write_text(json.dumps(lock, indent=1, sort_keys=True) + '\n', encoding='utf-8')
    known = {e[0] for e in catalog_entries()} if CATALOG.exists() else set()
    for wid in sorted(set(lock) - known):
        fx, fy = lock[wid]['suggestedFocus']
        print(f'  add to WallpaperCatalog.kt:  image("{wid}", WallpaperCategory.MOSQUES, {fx}f, {fy}f) {{ tr("…") }},')


if __name__ == '__main__':
    command = sys.argv[1] if len(sys.argv) > 1 else 'check'
    build() if command == 'build' else check()
