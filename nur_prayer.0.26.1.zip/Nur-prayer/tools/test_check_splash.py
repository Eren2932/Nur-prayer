#!/usr/bin/env python3
"""check_splash.py must fail on each way of bringing the black flash, a jump or a slow launch back."""
import unittest

import check_splash as cs


class SplashChecks(unittest.TestCase):
    def setUp(self):
        self.files = cs.read_all()

    def test_current_sources_pass(self):
        self.assertEqual(cs.problems(self.files), [])
        self.assertEqual(cs.art_problems(), [])

    def broken(self, key, old, new):
        self.assertIn(old, self.files[key], f'{key}: the mutation target is gone — update this test')
        mutated = dict(self.files, **{key: self.files[key].replace(old, new, 1)})
        self.assertTrue(cs.problems(mutated), f'not caught: {old!r} -> {new!r}')

    def test_mutations(self):
        for key, old, new in (
            ('manifest', '@style/Theme.Nur.Starting', '@style/Theme.Nur'),
            ('themes', '@color/splash_bg', '@color/ink'),
            ('themes', '@drawable/ic_splash_art', '@drawable/ic_splash_mark'),
            ('themes', 'postSplashScreenTheme">@style/Theme.Nur<', 'postSplashScreenTheme">@style/Other<'),
            ('colors', '#FFFFFFFF', '#FF000000'),
            ('gradle', 'core-splashscreen', 'core-other'),
            ('launch', 'painterResource(R.drawable.ic_splash_art)', 'painterResource(R.drawable.ic_other)'),
            ('launch', 'const val ART_DP = 288', 'const val ART_DP = 240'),
            ('launch', '.size(LaunchScreenSpec.ART_DP.dp)', '.size(200.dp)'),
            ('launch', 'const val MIN_MILLIS = 300L', 'const val MIN_MILLIS = 700L'),
            ('launch', 'const val EXIT_MILLIS = 260', 'const val EXIT_MILLIS = 420'),
            ('launch', 'withTimeoutOrNull(LaunchScreenSpec.MAX_MILLIS)', 'run'),
            ('launch', 'SideEffect { onShown() }', ''),
            ('launch', '.pointerInput(Unit) { detectTapGestures { } }', ''),
            ('activity', 'if (savedInstanceState == null) showLaunchScreen(splash)', 'showLaunchScreen(splash)'),
            ('activity', 'splash.setOnExitAnimationListener { it.remove() }', ''),
            ('activity', 'val splash = installSplashScreen()\n        super.onCreate(savedInstanceState)',
                         'super.onCreate(savedInstanceState)\n        val splash = installSplashScreen()'),
            ('activity', 'ready = data != null', 'ready = true'),
        ):
            with self.subTest(change=old):
                self.broken(key, old, new)


if __name__ == '__main__':
    unittest.main()
