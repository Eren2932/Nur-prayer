package com.nur.prayer.ui.today

import com.nur.prayer.ui.components.pageContentInsets
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Density
import com.nur.prayer.ui.theme.LocalUiScale
import com.nur.prayer.ui.theme.UiScale
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.unit.dp
import com.nur.prayer.R
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.Vird
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.daily.Ring
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.uiScale
import java.text.NumberFormat

internal data class TodayState(val currentSet: AzkarSet, val morning: Int, val evening: Int,
    val virdDone: Int, val virdSize: Int, val salawat: Long, val imageBackdrop: Boolean,
    val day: Long, val storyMask: Int, val storiesReady: Boolean)

internal class TodayActions(val close: () -> Unit, val names: () -> Unit,
    val vird: () -> Unit, val azkar: (AzkarSet) -> Unit, val salawat: () -> Unit, val story: () -> Unit)

@Composable
internal fun TodayScreen(state: TodayState, reveal: Reveal, on: TodayActions) {
    // This illustrated overview is a set of tiles, not reader text. Keep its typography
    // and grid at the standard setting. Readers, settings and the rest of the app keep sp.
    val screen = uiScale()
    val density = LocalDensity.current.density
    val standard = remember(screen.widthDp, screen.heightDp) {
        UiScale.of(screen.widthDp.toInt(), screen.heightDp.toInt(), 1f)
    }
    CompositionLocalProvider(LocalUiScale provides standard, LocalDensity provides Density(density, 1f)) {
        TodayGrid(state, reveal, on)
    }
}

@Composable
private fun TodayGrid(state: TodayState, reveal: Reveal, on: TodayActions) {
    val ui = uiScale()
    val pull = rememberDraggableState { delta -> reveal.drag(-delta) }
    val side = ui.s(18f)
    val gap = ui.s(11f)
    val titleInk = if (state.imageBackdrop) DeedTone.Ink else Color.White
    BoxWithConstraints(Modifier.fillMaxSize().pageContentInsets()
        .onSizeChanged { reveal.extentPx = it.height.toFloat() }, contentAlignment = Alignment.TopCenter) {
        val single = maxWidth - side * 2f < ui.s(285f)
        // Keep the reference rhythm on a tall screen; on shorter phones reclaim unused vertical
        // whitespace before falling back to scrolling (narrow split-screen is still navigable).
        val tileBudget = maxHeight - LocalIslandInset.current - LocalDockInset.current - 8.dp -
            ui.s(12f + 34f + 16f + 11f + 21f + 16f + 121f)
        val squeeze = (tileBudget / ui.s(129f * 2f + 141f)).coerceIn(.76f, 1f)
        val small = ui.s(129f) * squeeze
        val lower = ui.s(141f) * squeeze
        Column(Modifier.widthIn(max = 600.dp).fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = side).padding(top = LocalIslandInset.current + ui.s(12f), bottom = LocalDockInset.current + 8.dp)) {
            Text(tr("Дела"), Modifier.fillMaxWidth().draggable(state = pull, orientation = Orientation.Vertical,
                onDragStarted = { reveal.grab() }, onDragStopped = { v ->
                    if (reveal.release(-v, RevealMath.SHEET_KEEP_AT)) reveal.settle(true) else on.close()
                }), fontSize = ui.t(28f), lineHeight = ui.t(34f), fontWeight = FontWeight.Bold, color = titleInk)
            Spacer(Modifier.height(ui.s(16f)))
            if (single) {
                StatusCover(state.day, state.storyMask, state.storiesReady, Modifier.fillMaxWidth().height(ui.s(212f)), on.story)
                Spacer(Modifier.height(gap))
                SecondaryTiles(state, on, small, gap, Modifier.fillMaxWidth())
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    StatusCover(state.day, state.storyMask, state.storiesReady, Modifier.weight(1.035f).height(small * 2f + gap), on.story)
                    SecondaryTiles(state, on, small, gap, Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(ui.s(21f)))
            if (single) {
                Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                    for (set in AzkarSet.values()) AzkarTile(set, state, lower, Modifier.fillMaxWidth(), on.azkar)
                }
            } else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                for (set in AzkarSet.values()) AzkarTile(set, state, lower, Modifier.weight(1f), on.azkar)
            }
            Spacer(Modifier.height(ui.s(16f)))
            SalawatPanel(state.salawat, on.salawat)
        }
    }
}

@Composable
private fun SecondaryTiles(state: TodayState, on: TodayActions, height: Dp, gap: Dp, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(gap)) {
        DeedTile(tr("99 имён Аллаха"), tr("Имена и смыслы"), TileMark.NAMES, Modifier.fillMaxWidth(), height, open = on.names)
        DeedTile(tr("Вирд дня"), if (state.virdSize == 0) tr("Выбрать зикры") else tr("Выполнено {0} из {1}", state.virdDone, state.virdSize),
            TileMark.VIRD, Modifier.fillMaxWidth(), height, open = on.vird)
    }
}

private enum class TileMark(val image: Int, val w: Float, val h: Float, val inset: Float, val down: Float) {
    // Reuse the original calligraphy, not a typed approximation. Optical margin even at the top curve.
    NAMES(R.drawable.deed_allah, 82f, 69f, 7f, 4f),
    VIRD(R.drawable.deeds_mark_star, 88f, 88f, -11f, -2f),
    MORNING(R.drawable.deeds_mark_sun, 92f, 54f, -6f, 5f),
    EVENING(R.drawable.deeds_mark_moon, 76f, 76f, -6f, -2f)
}

@Composable
private fun AzkarTile(set: AzkarSet, state: TodayState, height: Dp, modifier: Modifier, open: (AzkarSet) -> Unit) {
    val morning = set == AzkarSet.MORNING
    DeedTile(tr(set.title), tr("Азкаров: {0}", if (morning) state.morning else state.evening),
        if (morning) TileMark.MORNING else TileMark.EVENING, modifier, height, current = set == state.currentSet) { open(set) }
}

@Composable
private fun DeedTile(title: String, sub: String, mark: TileMark, modifier: Modifier, tileHeight: Dp,
    current: Boolean = false, open: () -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(ui.s(24f))
    val night = current && mark == TileMark.EVENING
    val accent = if (night) DeedTone.DuskLink else DeedTone.DawnLink
    val veil = when { night -> DeedTone.DuskWash; current -> DeedTone.DawnWash; else -> Color.Transparent }
    BoxWithConstraints(modifier.height(tileHeight).deedMatte(shape, true).background(veil).pressClick(onClick = open)) {
        // Reserve the lower half for the copy. Keep the silhouette's aspect ratio as the
        // viewport shrinks; alpha is applied only to the watermark, never to the tile text.
        val w = minOf(ui.s(mark.w), maxWidth * .55f, (maxHeight * .61f) * (mark.w / mark.h))
        Image(painterResource(mark.image), contentDescription = null,
            modifier = Modifier.align(Alignment.TopEnd).offset(x = ui.s(-mark.inset), y = ui.s(mark.down))
                .size(w, w * (mark.h / mark.w)),
            colorFilter = ColorFilter.tint(if (night) DeedTone.DuskMark else DeedTone.PaperMark))
        if (current || mark == TileMark.NAMES) {
            Row(Modifier.align(Alignment.TopStart).fillMaxWidth(.52f).padding(start = ui.s(16f), top = ui.s(15f)),
                verticalAlignment = Alignment.CenterVertically) {
                if (current) {
                    Text(tr("Читать"), color = accent, fontSize = ui.t(12f), lineHeight = ui.t(15f), fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(ui.s(4f)))
                    Canvas(Modifier.size(ui.s(9f))) {
                        val rtl = layoutDirection == LayoutDirection.Rtl
                        val a = if (rtl) .65f else .35f; val b = 1f - a
                        val mid = Offset(size.width * b, size.height / 2f)
                        drawLine(accent, Offset(size.width * a, size.height * .19f), mid, size.width * .14f, StrokeCap.Round)
                        drawLine(accent, mid, Offset(size.width * a, size.height * .81f), size.width * .14f, StrokeCap.Round)
                    }
                } else {
                    AutoSizeText(tr("Новое").uppercase(L10n.language.locale), DeedTone.NewLabel, ui.t(11f),
                        minFontSize = ui.t(10f), lineHeight = ui.t(14f), letterSpacing = ui.t(.95f), fontWeight = FontWeight.Bold)
                }
            }
        }
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = ui.s(16f), end = ui.s(8f), bottom = ui.s(12f))) {
            AutoSizeText(title, if (night) DeedTone.DuskTitle else DeedTone.Ink, ui.t(15f), Modifier.fillMaxWidth(), lineHeight = ui.t(18f),
                minFontSize = ui.t(12f), fontWeight = FontWeight.Bold, maxLines = 2)
            Spacer(Modifier.height(ui.s(5f)))
            AutoSizeText(sub, if (night) DeedTone.DuskSub else DeedTone.Quiet, ui.t(12.5f), Modifier.fillMaxWidth(), lineHeight = ui.t(15f),
                minFontSize = ui.t(10.5f), maxLines = 2)
        }
    }
}

@Composable
private fun SalawatPanel(n: Long, open: () -> Unit) {
    val ui = uiScale()
    val locale = L10n.language.locale
    val formatted = remember(n, locale) { NumberFormat.getIntegerInstance(locale).format(n) }
    val fraction = SalawatGoal.fraction(n)
    Column(Modifier.fillMaxWidth().deedMatte(RoundedCornerShape(ui.s(24f)), true).pressClick(onClick = open)
        .heightIn(min = ui.s(121f)).padding(horizontal = ui.s(20f), vertical = ui.s(13f)), verticalArrangement = Arrangement.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("Зикр"), color = DeedTone.Ink, fontSize = ui.t(16.5f), lineHeight = ui.t(20f), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(ui.s(5f)))
                AutoSizeText(formatted, DeedTone.Ink, ui.t(27f), Modifier.fillMaxWidth(), lineHeight = ui.t(30f), fontWeight = FontWeight.Medium)
                Text(tr("Салават · Цель 500М"), color = DeedTone.Quiet, fontSize = ui.t(13f), lineHeight = ui.t(16f))
            }
            Spacer(Modifier.width(ui.s(8f)))
            Box(contentAlignment = Alignment.Center) {
                Ring(fraction, DeedTone.Green, ui.s(62f), ui.s(6f), track = DeedTone.Track)
                Text("${SalawatGoal.percent(n)}%", color = DeedTone.Ink, fontSize = ui.t(15f), fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(ui.s(8f)))
        Box(Modifier.fillMaxWidth().height(ui.s(6f)).clip(CircleShape).background(DeedTone.Track)) {
            Spacer(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(DeedTone.Green, CircleShape))
        }
    }
}

@Composable
internal fun VirdPage(ids: List<String>, counts: Map<String, Long>, open: (String?) -> Unit) {
    val ui = uiScale()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = LocalDockInset.current)) {
        DeedHeading(tr("Вирд дня"))
        Column(Modifier.padding(horizontal = ui.s(23f)), verticalArrangement = Arrangement.spacedBy(ui.s(10f))) {
            if (ids.isEmpty()) DeedCard {
                Text(tr("Выбрать зикры"), Modifier.fillMaxWidth().pressClick { open(null) }.padding(18.dp), color = DeedTone.Ink)
            }
            ids.forEach { id ->
                val preset = Dhikr.preset(id)
                DeedCard {
                    Row(Modifier.fillMaxWidth().pressClick { open(id) }.padding(ui.s(17f)), verticalAlignment = Alignment.CenterVertically) {
                        Ring(Vird.fraction(id, counts), DeedTone.Green, 28.dp, 3.dp, track = DeedTone.Track)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tr(preset.title), color = DeedTone.Ink, fontWeight = FontWeight.Medium)
                            Text("${counts[id] ?: 0L} / ${preset.target}", color = DeedTone.Quiet, fontSize = ui.t(12f))
                        }
                    }
                }
            }
        }
    }
}
