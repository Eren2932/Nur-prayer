package com.nur.prayer.ui.schedule

import com.nur.prayer.i18n.tr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

/*
 * 0.19.0 — «Таблица на месяц»: the paper timetable of the mosque, on the sky. One row per day,
 * Fridays and today lit, the days of the Islamic year marked by a coloured edge and a coloured
 * hijri number. The same rows feed the shared picture, so what is on screen is what is sent.
 */

/** A computed month: the days in order and the columns the place actually has. */
internal class MonthTimes(val month: YearMonth, val days: List<PrayerDay>, val columns: List<Prayer>)

/** Short column names for a narrow phone; the full name stays in the accessibility label. */
internal fun columnLabel(prayer: Prayer): String = when (prayer) {
    Prayer.SAHAR -> tr("Сухур")
    Prayer.FAJR -> tr("Фаджр")
    Prayer.SUNRISE -> tr("Восход")
    Prayer.DHUHR -> tr("Зухр")
    Prayer.ASR -> tr("Аср")
    Prayer.MAGHRIB -> tr("Магриб")
    Prayer.ISHA -> tr("Иша")
}

@Composable
internal fun MonthTable(times: MonthTimes, today: LocalDate, hijriOffset: Int, palette: PhasePalette, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val shape = RoundedCornerShape(20.dp)
    val narrow = times.columns.size > 6
    val timeSize = ui.t(if (narrow) 12.5f else 13.5f)
    Column(
        modifier.fillMaxWidth().clip(shape).background(Color(0x1FFFFFFF)).border(1.dp, Color(0x24FFFFFF), shape)
            .testTag("month-table")
    ) {
        // Header band.
        Row(
            Modifier.fillMaxWidth().background(palette.accent.copy(alpha = 0.26f)).heightIn(min = 40.dp)
                .padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(tr("Дата").uppercase(), color = TextPrimary, fontSize = ui.t(10.5f), fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1.45f).padding(start = 12.dp), maxLines = 1)
            times.columns.forEach { p ->
                Text(
                    columnLabel(p).uppercase(), color = TextPrimary, fontSize = ui.t(if (narrow) 9f else 10f),
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1, softWrap = false,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        times.days.forEachIndexed { index, day ->
            val date = day.date
            val event = IslamicDays.primary(date, hijriOffset)
            val tone = event?.let { DayTone.of(it.kind) }
            val isToday = date == today
            val friday = date.dayOfWeek == DayOfWeek.FRIDAY
            val fill = when {
                isToday -> palette.accent.copy(alpha = 0.34f)
                tone != null && event?.kind != DayKind.SEASON -> tone.copy(alpha = 0.16f)
                tone != null -> tone.copy(alpha = 0.07f)
                friday -> Color(0x12FFFFFF)
                else -> Color.Transparent
            }
            if (index > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x12FFFFFF)))
            Row(
                Modifier.fillMaxWidth().heightIn(min = 40.dp).background(fill)
                    .entrance(index.coerceAtMost(10), distance = 12f)
                    .semantics(mergeDescendants = true) {
                        contentDescription = buildString {
                            append(Format.fullDate(date))
                            event?.let { append(", ").append(IslamicDayText.title(it.day)) }
                            times.columns.forEach { p ->
                                append(", ").append(PrayerLabels.title(p)).append(' ')
                                append(day.times[p]?.let { Format.time(it) } ?: "—")
                            }
                        }
                    }
                    .testTag("table-row-$date"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // The coloured edge of a marked day.
                Box(Modifier.width(3.dp).height(26.dp).background(tone ?: Color.Transparent))
                Row(Modifier.weight(1.45f).padding(start = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        date.dayOfMonth.toString(), color = TextPrimary, fontSize = ui.t(14f),
                        fontWeight = if (isToday) FontWeight.Bold else FontWeight.SemiBold,
                        modifier = Modifier.width(ui.s(20f))
                    )
                    Column(Modifier.padding(start = 4.dp)) {
                        Text(Format.weekdayShort(date), color = if (friday) palette.accent else TextSecondary,
                            fontSize = ui.t(10.5f), fontWeight = if (friday) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
                        Text(HijriCalendar.dayOfMonth(date, hijriOffset).toString(), color = tone ?: TextTertiary,
                            fontSize = ui.t(9.5f), maxLines = 1)
                    }
                }
                times.columns.forEach { p ->
                    Text(
                        day.times[p]?.let { Format.time(it) } ?: "—",
                        color = if (p == Prayer.SUNRISE || p == Prayer.SAHAR) TextSecondary else TextPrimary,
                        fontSize = timeSize, fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                        fontFeatureSettings = "tnum", textAlign = TextAlign.Center, maxLines = 1, softWrap = false,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

/** The spec of the shared picture, from the same rows as the screen. */
internal fun calendarShareSpec(
    times: MonthTimes, today: LocalDate, hijriOffset: Int, placeLabel: String, palette: PhasePalette
): CalendarShareSpec {
    val first = times.month.atDay(1)
    val last = times.month.atEndOfMonth()
    val h0 = HijriCalendar.monthAndYear(first, hijriOffset)
    val h1 = HijriCalendar.monthAndYear(last, hijriOffset)
    val rows = times.days.map { d ->
        CalendarShareRow(
            day = d.date.dayOfMonth.toString(),
            weekday = Format.weekdayShort(d.date),
            hijriDay = HijriCalendar.dayOfMonth(d.date, hijriOffset).toString(),
            times = times.columns.map { p -> d.times[p]?.let { Format.time(it) } ?: "—" },
            friday = d.date.dayOfWeek == DayOfWeek.FRIDAY,
            today = d.date == today,
            tone = IslamicDays.primary(d.date, hijriOffset)?.let { DayTone.argb(it.kind) }
        )
    }
    val legend = monthEvents(times.month, hijriOffset).map { o -> DayTone.argb(o.kind) to legendLine(o) }
    return CalendarShareSpec(
        kicker = tr("Время намаза"),
        title = "${Format.monthName(times.month.monthValue)} ${times.month.year}",
        subtitle = if (h0 == h1) h0 else "$h0 — $h1",
        place = placeLabel,
        dateHeader = tr("Дата"),
        columns = times.columns.map { columnLabel(it) },
        rows = rows,
        legend = legend,
        footnote = IslamicDayText.datesNote(hijriOffset).substringBefore(". ") + ".",
        palette = palette
    )
}

/** "10 нояб. — 12 нояб. · Дни ташрика" / "25 июня · Ашура". */
internal fun legendLine(o: DayOccurrence): String {
    val start = "${o.start.dayOfMonth} ${Format.monthShort(o.start)}"
    val span = if (o.days > 1) "$start — ${o.end.dayOfMonth} ${Format.monthShort(o.end)}" else start
    return "$span · ${IslamicDayText.title(o.day)}"
}

/** Everything that touches a Gregorian month, in order. */
internal fun monthEvents(month: YearMonth, hijriOffset: Int): List<DayOccurrence> =
    IslamicDays.between(month.atDay(1), month.atEndOfMonth(), hijriOffset)

