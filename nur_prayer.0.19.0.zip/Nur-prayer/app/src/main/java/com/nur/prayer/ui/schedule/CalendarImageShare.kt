package com.nur.prayer.ui.schedule

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.FileProvider
import com.nur.prayer.ui.quran.AyahImageShare
import com.nur.prayer.ui.theme.PhasePalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/*
 * 0.19.0 — the month as a picture, the way the mosques print it on paper: the month and the hijri
 * months it spans, the city, a ruled table of the times with Fridays and the days of the Islamic
 * year marked in their colours, a legend of those days, and the quiet «Nur» at the foot — the same
 * signature as the ayah picture. Drawn straight onto a Bitmap over the sky of the moment.
 *
 * The spec is plain strings and colours, built on the UI side (where tr() and the palette live), so
 * this file only lays out and paints.
 */

internal class CalendarShareRow(
    val day: String,
    val weekday: String,
    val hijriDay: String,
    val times: List<String>,
    val friday: Boolean,
    val today: Boolean,
    /** ARGB of the kind of day, or null on an ordinary day. */
    val tone: Int?
)

internal class CalendarShareSpec(
    val kicker: String,
    val title: String,
    val subtitle: String,
    val place: String,
    val dateHeader: String,
    val columns: List<String>,
    val rows: List<CalendarShareRow>,
    /** ARGB colour → "10 нояб. · Ашура". */
    val legend: List<Pair<Int, String>>,
    val footnote: String,
    val palette: PhasePalette
)

internal object CalendarImageShare {
    private const val WIDTH = 1080
    private const val MARGIN = 64
    private const val ROW = 62
    private const val HEAD = 78
    private const val FILE_NAME = "calendar.png"

    fun render(spec: CalendarShareSpec): Bitmap {
        val p = spec.palette
        val accent = p.accent.toArgb()
        val white = 0xFFFFFFFF.toInt()
        val quiet = 0xB3FFFFFF.toInt()
        val faint = 0x73FFFFFF.toInt()
        val inner = WIDTH - 2 * MARGIN

        val kicker = paint(26f, accent, bold = true).apply { letterSpacing = 0.22f }
        val title = paint(88f, white, bold = true)
        val subtitle = paint(32f, quiet, bold = false)
        val place = paint(30f, white, bold = true)
        val legendPaint = paint(30f, white, bold = false)

        // Vertical budget: header, table, legend, footer.
        val headerHeight = 64 + 40 + 100 + 48 + 46 + 56
        val tableHeight = HEAD + spec.rows.size * ROW
        val legendHeight = if (spec.legend.isEmpty()) 0 else 56 + spec.legend.size * 50
        val footerHeight = 40 + 44 + 40 + 60 + 70
        val height = headerHeight + tableHeight + legendHeight + footerHeight

        val bitmap = Bitmap.createBitmap(WIDTH, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        // Our sky: zenith → mid → horizon, with the glow of the horizon rising from the foot.
        canvas.drawRect(0f, 0f, WIDTH.toFloat(), height.toFloat(), Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, height.toFloat(),
                intArrayOf(p.zenith.toArgb(), p.mid.toArgb(), p.horizon.toArgb()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        })
        val glow = p.glow.toArgb()
        if ((glow ushr 24) > 0) canvas.drawRect(0f, 0f, WIDTH.toFloat(), height.toFloat(), Paint().apply {
            shader = RadialGradient(WIDTH / 2f, height.toFloat(), WIDTH * 0.9f, glow, 0, Shader.TileMode.CLAMP)
        })
        // A dark wash under the table keeps every figure legible on the lightest sky.
        canvas.drawRect(0f, 0f, WIDTH.toFloat(), height.toFloat(), Paint().apply { color = 0x33000000 })

        var y = 64f
        canvas.drawText(spec.kicker.uppercase(), MARGIN.toFloat(), y - kicker.fontMetrics.ascent, kicker)
        y += 40f
        canvas.drawText(fit(spec.title, title, inner.toFloat()), MARGIN.toFloat(), y - title.fontMetrics.ascent, title)
        y += 100f
        canvas.drawText(fit(spec.subtitle, subtitle, inner.toFloat()), MARGIN.toFloat(), y - subtitle.fontMetrics.ascent, subtitle)
        y += 48f
        drawPin(canvas, MARGIN + 11f, y + 20f, accent)
        canvas.drawText(fit(spec.place, place, inner - 40f), MARGIN + 36f, y - place.fontMetrics.ascent, place)
        y += 46f + 56f

        // ── The table ────────────────────────────────────────────────────────────────────────
        val left = MARGIN.toFloat()
        val right = (WIDTH - MARGIN).toFloat()
        val card = RectF(left, y, right, y + tableHeight)
        canvas.drawRoundRect(card, 36f, 36f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x24FFFFFF })
        canvas.save()
        canvas.clipPath(Path().apply { addRoundRect(card, 36f, 36f, Path.Direction.CW) })
        canvas.drawRect(left, y, right, y + HEAD, Paint().apply { color = withAlpha(accent, 0x47) })

        val dateWidth = 196f
        val colWidth = (inner - dateWidth) / spec.columns.size.coerceAtLeast(1)
        fun colCenter(i: Int) = left + dateWidth + colWidth * i + colWidth / 2f
        val headPaint = paint(25f, white, bold = true).apply { textAlign = Paint.Align.CENTER }
        val headSize = spec.columns.minOfOrNull { fitSize(it.uppercase(), 25f, colWidth - 12f, true) } ?: 25f
        headPaint.textSize = headSize
        val headBase = y + HEAD / 2f - (headPaint.fontMetrics.ascent + headPaint.fontMetrics.descent) / 2f
        val dateHead = paint(25f, white, bold = true)
        canvas.drawText(fit(spec.dateHeader.uppercase(), dateHead, dateWidth - 28f), left + 28f, headBase, dateHead)
        spec.columns.forEachIndexed { i, c -> canvas.drawText(c.uppercase(), colCenter(i), headBase, headPaint) }
        y += HEAD

        val dayPaint = paint(32f, white, bold = true)
        val weekPaint = paint(24f, quiet, bold = false)
        val hijriPaint = paint(22f, faint, bold = false).apply { textAlign = Paint.Align.RIGHT }
        val timePaint = paint(31f, white, bold = false).apply { textAlign = Paint.Align.CENTER; fontFeatureSettings = "tnum" }
        val timeBold = paint(31f, white, bold = true).apply { textAlign = Paint.Align.CENTER; fontFeatureSettings = "tnum" }
        val rule = Paint().apply { color = 0x1AFFFFFF; strokeWidth = 2f }
        spec.rows.forEachIndexed { index, r ->
            val top = y + index * ROW
            when {
                r.today -> canvas.drawRect(left, top, right, top + ROW, Paint().apply { color = withAlpha(accent, 0x55) })
                r.tone != null -> canvas.drawRect(left, top, right, top + ROW, Paint().apply { color = withAlpha(r.tone, 0x2E) })
                r.friday -> canvas.drawRect(left, top, right, top + ROW, Paint().apply { color = 0x14FFFFFF })
            }
            if (r.tone != null) canvas.drawRect(left, top + 8f, left + 8f, top + ROW - 8f, Paint().apply { color = r.tone })
            if (index > 0) canvas.drawLine(left, top, right, top, rule)
            val base = top + ROW / 2f - (dayPaint.fontMetrics.ascent + dayPaint.fontMetrics.descent) / 2f
            canvas.drawText(r.day, left + 28f, base, dayPaint)
            val dw = dayPaint.measureText(r.day)
            weekPaint.color = if (r.friday) accent else quiet
            canvas.drawText(r.weekday, left + 28f + maxOf(dw, dayPaint.measureText("00")) + 14f, base, weekPaint)
            hijriPaint.color = r.tone ?: faint
            canvas.drawText(r.hijriDay, left + dateWidth - 14f, base, hijriPaint)
            r.times.forEachIndexed { i, t -> canvas.drawText(t, colCenter(i), base, if (r.today) timeBold else timePaint) }
        }
        canvas.restore()
        canvas.drawRoundRect(card, 36f, 36f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 2f; color = 0x2EFFFFFF
        })
        y += spec.rows.size * ROW

        // ── The days of the month ────────────────────────────────────────────────────────────
        if (spec.legend.isNotEmpty()) {
            y += 56f
            spec.legend.forEach { (tone, text) ->
                canvas.drawCircle(left + 12f, y + 20f, 10f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tone })
                canvas.drawText(fit(text, legendPaint, inner - 40f), left + 40f, y + 20f - (legendPaint.fontMetrics.ascent + legendPaint.fontMetrics.descent) / 2f, legendPaint)
                y += 50f
            }
        }

        // ── The signature ────────────────────────────────────────────────────────────────────
        y += 40f
        val note = paint(22f, faint, bold = false).apply { textAlign = Paint.Align.CENTER }
        canvas.drawText(fit(spec.footnote, note, inner.toFloat()), WIDTH / 2f, y - note.fontMetrics.ascent, note)
        y += 44f + 40f
        drawDivider(canvas, y, accent)
        y += 60f
        val mark = paint(38f, accent, bold = true).apply { letterSpacing = 0.3f; alpha = 190; textAlign = Paint.Align.CENTER }
        canvas.drawText("Nur", WIDTH / 2f, y - mark.fontMetrics.ascent, mark)
        return bitmap
    }

    /** Writes the picture to cacheDir/share/calendar.png and opens the share sheet. */
    suspend fun share(context: Context, spec: CalendarShareSpec): Boolean {
        val file = withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(context.cacheDir, "share").apply { mkdirs() }
                val out = File(dir, FILE_NAME)
                val bitmap = render(spec)
                try {
                    out.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                } finally {
                    bitmap.recycle()
                }
                out
            }.getOrNull()
        } ?: return false
        return runCatching {
            // Same provider and path as the ayah picture (cache/share/).
            val uri = FileProvider.getUriForFile(context, AyahImageShare.authority(context), file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.isSuccess
    }

    private fun paint(size: Float, color: Int, bold: Boolean) = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
        textSize = size
        this.color = color
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun withAlpha(argb: Int, alpha: Int): Int = (argb and 0x00FFFFFF) or (alpha shl 24)

    /** Ellipsize a single line to [width]; the header names are short, a long city is not. */
    private fun fit(text: String, paint: TextPaint, width: Float): String =
        TextUtils.ellipsize(text, paint, width, TextUtils.TruncateAt.END).toString()

    /** The largest size ≤ [start] at which [text] fits [width] (prayer names differ by language). */
    private fun fitSize(text: String, start: Float, width: Float, bold: Boolean): Float {
        val p = paint(start, 0, bold)
        var size = start
        while (size > 16f && p.measureText(text) > width) {
            size -= 1f
            p.textSize = size
        }
        return size
    }

    private fun drawPin(canvas: Canvas, cx: Float, cy: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        val pin = Path().apply {
            moveTo(cx, cy + 16f)
            cubicTo(cx - 16f, cy - 2f, cx - 12f, cy - 18f, cx, cy - 18f)
            cubicTo(cx + 12f, cy - 18f, cx + 16f, cy - 2f, cx, cy + 16f)
            close()
        }
        canvas.drawPath(pin, paint)
        canvas.drawCircle(cx, cy - 6f, 5f, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFF14122E.toInt() })
    }

    /** ──── ◆ ────, the ornament of the ayah picture. */
    private fun drawDivider(canvas: Canvas, cy: Float, accent: Int) {
        val mid = WIDTH / 2f
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF; strokeWidth = 2f }
        canvas.drawLine(MARGIN + 220f, cy, mid - 36f, cy, line)
        canvas.drawLine(mid + 36f, cy, WIDTH - MARGIN - 220f, cy, line)
        val d = Path().apply { moveTo(mid, cy - 12f); lineTo(mid + 12f, cy); lineTo(mid, cy + 12f); lineTo(mid - 12f, cy); close() }
        canvas.drawPath(d, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent })
    }
}
