package com.nur.prayer.ui.schedule

import com.nur.prayer.i18n.tr

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.launch
import java.time.LocalDate

/*
 * 0.19.0 — what a day is. Opens from the grid, the month list, the year view and the home chip.
 * Order of reading: kind → name (and the Arabic) → when exactly, how long until → why it matters
 * → what to do → where it is written. The tint of the sheet takes the colour of the kind, so a
 * feast reads golden and a blessed night lavender before a word is read.
 */

/** What the sheet shows: one occurrence, or the note on the four sacred months. */
sealed interface SheetTopic {
    data class Day(val occurrence: DayOccurrence) : SheetTopic
    data object Sacred : SheetTopic
}

@Composable
internal fun DaySheet(
    topic: SheetTopic?,
    today: LocalDate,
    hijriOffset: Int,
    sheetTint: Color,
    onDismiss: () -> Unit
) {
    // The last topic stays composed while the sheet slides away.
    var shown by remember { mutableStateOf(topic) }
    if (topic != null) shown = topic
    BackHandler(enabled = topic != null) { onDismiss() }
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(topic != null, enter = fadeIn(tween(220)), exit = fadeOut(tween(180))) {
            Box(
                Modifier.fillMaxSize().background(Color(0x8C000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
            )
        }
        AnimatedVisibility(
            topic != null, modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.86f, stiffness = 380f)) { it } + fadeIn(tween(120)),
            exit = slideOutVertically(tween(220)) { it } + fadeOut(tween(200))
        ) {
            shown?.let { SheetBody(it, today, hijriOffset, sheetTint, onDismiss) }
        }
    }
}

@Composable
private fun SheetBody(topic: SheetTopic, today: LocalDate, hijriOffset: Int, sheetTint: Color, onDismiss: () -> Unit) {
    val ui = uiScale()
    val scope = rememberCoroutineScope()
    val drag = remember { Animatable(0f) }
    val closeAt = with(LocalDensity.current) { 120.dp.toPx() }
    LaunchedEffect(topic) { drag.snapTo(0f) }
    val dragState = rememberDraggableState { delta -> scope.launch { drag.snapTo((drag.value + delta).coerceAtLeast(0f)) } }
    val tone = when (topic) {
        is SheetTopic.Day -> DayTone.of(topic.occurrence.kind)
        SheetTopic.Sacred -> DayTone.Night
    }
    val top = lerp(sheetTint, tone, 0.2f)
    Column(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.9f)
            .graphicsLayer { translationY = drag.value }
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(Brush.verticalGradient(listOf(top, lerp(sheetTint, Ink, 0.55f))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .testTag("day-sheet")
    ) {
        Column(
            Modifier.fillMaxWidth()
                .draggable(dragState, Orientation.Vertical, onDragStopped = { velocity ->
                    if (drag.value > closeAt || velocity > 1800f) onDismiss()
                    else drag.animateTo(0f, spring(dampingRatio = 0.8f, stiffness = 500f))
                })
                .padding(start = ui.s(20f), end = ui.s(14f), top = 10.dp, bottom = 4.dp)
        ) {
            Box(
                Modifier.align(Alignment.CenterHorizontally).width(36.dp).height(4.dp)
                    .clip(RoundedCornerShape(2.dp)).background(Color(0x59FFFFFF))
            )
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(tone))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        (if (topic is SheetTopic.Day) DayTone.label(topic.occurrence.kind) else tr("Четыре месяца")).uppercase(),
                        color = tone, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold, letterSpacing = ui.t(0.8f)
                    )
                }
                RoundIconButton(GlyphKind.CLOSE, tr("Закрыть"), onDismiss, size = 40.dp, background = Color(0x33FFFFFF))
            }
        }
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = ui.s(20f)).navigationBarsPadding().padding(bottom = 28.dp)
        ) {
            when (topic) {
                is SheetTopic.Day -> DayContent(topic.occurrence, today, hijriOffset, tone)
                SheetTopic.Sacred -> SacredContent(tone)
            }
        }
    }
}

@Composable
private fun DayContent(o: DayOccurrence, today: LocalDate, hijriOffset: Int, tone: Color) {
    val ui = uiScale()
    Text(
        IslamicDayText.title(o.day), color = TextPrimary, fontSize = ui.t(26f), fontWeight = FontWeight.Bold,
        modifier = Modifier.semantics { heading() }
    )
    Text(
        IslamicDayText.arabic(o.day), color = tone.copy(alpha = 0.9f), fontSize = ui.t(22f),
        style = TextStyle(textDirection = TextDirection.Rtl), modifier = Modifier.padding(top = 6.dp)
    )
    Spacer(Modifier.height(18.dp))
    DateCard(o, today, hijriOffset, tone)
    Spacer(Modifier.height(20.dp))
    IslamicDayText.paragraphs(o.day).forEach { p ->
        Text(p, color = TextSecondary, fontSize = ui.t(15f), lineHeight = ui.t(23f), modifier = Modifier.padding(bottom = 12.dp))
    }
    val deeds = IslamicDayText.deeds(o.day)
    if (deeds.isNotEmpty()) {
        Text(
            tr("Что делать").uppercase(), color = TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold,
            letterSpacing = ui.t(0.8f), modifier = Modifier.padding(top = 8.dp, bottom = 10.dp)
        )
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0x1FFFFFFF)).padding(vertical = 6.dp)
        ) {
            deeds.forEachIndexed { i, d ->
                if (i > 0) Box(Modifier.padding(start = 40.dp).fillMaxWidth().height(1.dp).background(SurfaceEdge))
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(tone))
                    Spacer(Modifier.width(16.dp))
                    Text(d, color = TextPrimary, fontSize = ui.t(15f))
                }
            }
        }
    }
    Text(
        tr("Источники").uppercase(), color = TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold,
        letterSpacing = ui.t(0.8f), modifier = Modifier.padding(top = 22.dp, bottom = 6.dp)
    )
    Text(IslamicDayText.sources(o.day).joinToString(" · "), color = TextTertiary, fontSize = ui.t(13f), lineHeight = ui.t(19f))
    Text(
        IslamicDayText.datesNote(hijriOffset), color = TextTertiary, fontSize = ui.t(12f), lineHeight = ui.t(18f),
        modifier = Modifier.padding(top = 14.dp)
    )
}

/** The badge of the reference app («25 июн.»), with the hijri date, the span and the countdown. */
@Composable
private fun DateCard(o: DayOccurrence, today: LocalDate, hijriOffset: Int, tone: Color) {
    val ui = uiScale()
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0x1FFFFFFF)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)).background(tone.copy(alpha = 0.22f)),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Text(o.start.dayOfMonth.toString(), color = TextPrimary, fontSize = ui.t(24f), fontWeight = FontWeight.Bold)
            Text(Format.monthShort(o.start), color = tone, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(DayWhen.span(o), color = TextPrimary, fontSize = ui.t(15f), fontWeight = FontWeight.SemiBold)
            Text(
                HijriCalendar.format(o.start, hijriOffset), color = TextSecondary, fontSize = ui.t(13f),
                modifier = Modifier.padding(top = 2.dp)
            )
            Text(DayWhen.countdown(o, today), color = tone, fontSize = ui.t(13f), fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun SacredContent(tone: Color) {
    val ui = uiScale()
    Text(
        IslamicDayText.sacredTitle(), color = TextPrimary, fontSize = ui.t(26f), fontWeight = FontWeight.Bold,
        modifier = Modifier.semantics { heading() }
    )
    Text(
        "الأَشْهُر الحُرُم", color = tone.copy(alpha = 0.9f), fontSize = ui.t(22f),
        style = TextStyle(textDirection = TextDirection.Rtl), modifier = Modifier.padding(top = 6.dp, bottom = 18.dp)
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(1, 7, 11, 12).forEach { m ->
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(tone.copy(alpha = 0.16f)).padding(vertical = 10.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(IslamicDays.arabicMonth(m), color = TextPrimary, fontSize = ui.t(14f), textAlign = TextAlign.Center, maxLines = 1)
                Text(HijriCalendar.monthName(m), color = TextSecondary, fontSize = ui.t(11f), textAlign = TextAlign.Center, maxLines = 2)
            }
        }
    }
    Spacer(Modifier.height(18.dp))
    IslamicDayText.sacredParagraphs().forEach { p ->
        Text(p, color = TextSecondary, fontSize = ui.t(15f), lineHeight = ui.t(23f), modifier = Modifier.padding(bottom = 12.dp))
    }
}

/** Sentences about "when", shared by the sheet, the month list and the home chip. */
object DayWhen {
    /** "10 февраля — 11 марта · 30 дн.", "ночь на 6 марта", "25 июня, четверг". */
    fun span(o: DayOccurrence): String = when {
        o.kind == DayKind.NIGHT -> tr("Ночь на {0} — после магриба {1}", Format.dayMonth(o.start), Format.dayMonth(o.start.minusDays(1)))
        o.days > 1 -> tr("{0} — {1} · {2} дн.", Format.dayMonth(o.start), Format.dayMonth(o.end), o.days)
        else -> "${Format.dayMonth(o.start)}, ${Format.weekday(o.start)}"
    }

    fun countdown(o: DayOccurrence, today: LocalDate): String {
        val until = IslamicDays.daysBetween(today, o.start)
        return when {
            o.contains(today) && o.days > 1 -> tr("Идёт: день {0} из {1}", IslamicDays.daysBetween(o.start, today) + 1, o.days)
            o.contains(today) -> tr("Сегодня")
            o.kind == DayKind.NIGHT && until == 1L -> tr("Сегодня вечером")
            until == 1L -> tr("Завтра")
            until > 1 -> tr("Через {0} дн.", until)
            else -> tr("Прошло: {0} дн. назад", -IslamicDays.daysBetween(today, o.end))
        }
    }
}
