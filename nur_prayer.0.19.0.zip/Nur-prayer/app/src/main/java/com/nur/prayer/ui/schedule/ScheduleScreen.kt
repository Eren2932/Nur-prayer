package com.nur.prayer.ui.schedule

import com.nur.prayer.i18n.tr

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.components.ScreenHeader
import com.nur.prayer.ui.components.SegmentedControl
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.home.HomeTimeline
import com.nur.prayer.ui.theme.Glass
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.UiScale
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZonedDateTime

/*
 * 0.19.0 — the calendar, rebuilt around three readings of time:
 *
 *   Год     — the hijri year as the mosques print it: twelve months, each with its Gregorian bounds and
 *             the days of the Islamic year that fall in it (YearView);
 *   Месяц   — the grid, with the days of the year painted in their colours, and the selected day;
 *   Таблица — the month as a timetable, one row per day (MonthTable), shared as a picture.
 *
 * A tap on the title of any period raises the drums (PeriodPicker); a tap on a day of the year opens
 * its sheet (DaySheet). Both are overlays of this screen, so the back gesture closes them first.
 */

/** Order of the tabs; the index is what is saved. */
internal object CalendarTabs {
    const val YEAR = 0
    const val MONTH = 1
    const val TABLE = 2
}

@Composable
fun ScheduleScreen(
    data: PrayerData, now: State<ZonedDateTime>, palette: PhasePalette,
    modifier: Modifier = Modifier, onBack: (() -> Unit)? = null
) {
    val ui = uiScale()
    val today = data.today.date
    val hijriOffset = data.settings.hijriOffset
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var tab by rememberSaveable { mutableIntStateOf(CalendarTabs.MONTH) }
    var monthText by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(YearMonth.from(today).toString()) }
    var selectedEpoch by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(today.toEpochDay()) }
    var hijriYear by rememberSaveable(today.toEpochDay(), hijriOffset) { mutableIntStateOf(IslamicDays.hijriOf(today, hijriOffset).year) }
    var picker by rememberSaveable { mutableStateOf(false) }
    // A DayOccurrence is not Parcelable: the sheet is closed after a rotation, which is the honest state.
    var topic by remember { mutableStateOf<SheetTopic?>(null) }
    val month = YearMonth.parse(monthText)
    val selectedDate = LocalDate.ofEpochDay(selectedEpoch)
    fun goMonth(target: YearMonth) {
        monthText = target.toString()
        selectedEpoch = CalendarMonthModel.moveSelection(selectedDate, target).toEpochDay()
    }

    // The month timetable: the table tab shows it, the share button sends it. 31 solar days are cheap.
    val columns = remember(data.fajrEqualsDawn) { HomeTimeline.prayers(data.fajrEqualsDawn) }
    var times by remember(data.place, data.params, columns) { mutableStateOf<MonthTimes?>(null) }
    LaunchedEffect(month, data.place, data.params, columns) {
        times = try {
            withContext(Dispatchers.Default) {
                MonthTimes(month, PrayerEngine.days(month.atDay(1), month.lengthOfMonth(), data.place.coordinates, data.place.zone, data.params), columns)
            }
        } catch (cancel: CancellationException) { throw cancel } catch (_: Exception) { null }
    }
    val monthTimes = times?.takeIf { it.month == month }
    var sharing by remember { mutableStateOf(false) }
    val shareFailed = tr("Не удалось подготовить картинку")
    val share: () -> Unit = share@{
        val t = monthTimes ?: return@share
        if (sharing) return@share
        sharing = true
        val spec = calendarShareSpec(t, today, hijriOffset, data.place.label, palette)
        scope.launch {
            val ok = CalendarImageShare.share(context, spec)
            sharing = false
            if (!ok) Toast.makeText(context, shareFailed, Toast.LENGTH_SHORT).show()
        }
    }

    Box(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxWidth().padding(horizontal = ui.s(24f))) {
                ScreenHeader(tr("Календарь"), onBack, Modifier.padding(bottom = 6.dp)) {
                    AutoSizeText(data.place.label, color = TextSecondary, fontSize = ui.t(13f), maxLines = 2,
                        modifier = Modifier.weight(0.6f), textAlign = TextAlign.End)
                    AnimatedVisibility(tab != CalendarTabs.YEAR, enter = fadeIn(tween(160)), exit = fadeOut(tween(120))) {
                        RoundIconButton(
                            GlyphKind.SHARE, tr("Поделиться таблицей месяца"), share,
                            modifier = Modifier.padding(start = 6.dp).graphicsLayer { alpha = if (monthTimes == null || sharing) 0.4f else 1f }
                                .testTag("calendar-share"),
                            size = 44.dp
                        )
                    }
                }
                SegmentedControl(
                    listOf(tr("Год"), tr("Месяц"), tr("Таблица")), tab, palette.accent,
                    onSelect = { tab = it }, modifier = Modifier.testTag("calendar-tabs")
                )
                Spacer(Modifier.height(14.dp))
            }
            AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    val forward = targetState > initialState
                    (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { w -> if (forward) w / 6 else -w / 6 } +
                        fadeIn(tween(260, delayMillis = 40))) togetherWith
                        (slideOutHorizontally(tween(240)) { w -> if (forward) -w / 8 else w / 8 } + fadeOut(tween(160)))
                },
                label = "calendarTab",
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) { page ->
                when (page) {
                    CalendarTabs.YEAR -> YearView(
                        hijriYear, today, hijriOffset, palette,
                        bottomInset = LocalDockInset.current + 16.dp,
                        onPickYear = { picker = true }, onYear = { hijriYear = it }, onOpen = { topic = it }
                    )
                    CalendarTabs.TABLE -> TablePage(
                        month, monthTimes, today, hijriOffset, palette,
                        onMonth = { goMonth(it) }, onPick = { picker = true }, onOpen = { topic = it }, onShare = share
                    )
                    else -> MonthPage(
                        data, now, palette, month, selectedDate,
                        onMonth = { goMonth(it) },
                        onSelect = { selectedEpoch = it.toEpochDay() },
                        onToday = { monthText = YearMonth.from(today).toString(); selectedEpoch = today.toEpochDay() },
                        onPick = { picker = true }, onOpen = { topic = it }
                    )
                }
            }
        }
        PeriodPicker(
            visible = picker,
            mode = if (tab == CalendarTabs.YEAR) PickerMode.HIJRI_YEAR else PickerMode.MONTH,
            month = month, hijriYear = hijriYear, today = today, hijriOffset = hijriOffset,
            accent = palette.accent, surface = palette.sheet,
            onMonth = { goMonth(it) }, onHijriYear = { hijriYear = it }, onDismiss = { picker = false }
        )
        DaySheet(topic, today, hijriOffset, palette.sheet, onDismiss = { topic = null })
    }
}

/* ------------------------------------------------------------------------------------------------
 * Месяц: the grid and the selected day
 * ---------------------------------------------------------------------------------------------- */

/** Full month navigation; only the selected day and its following dawn need solar computation. */
@Composable
private fun MonthPage(
    data: PrayerData, now: State<ZonedDateTime>, palette: PhasePalette, month: YearMonth, selectedDate: LocalDate,
    onMonth: (YearMonth) -> Unit, onSelect: (LocalDate) -> Unit, onToday: () -> Unit, onPick: () -> Unit,
    onOpen: (SheetTopic) -> Unit
) {
    val ui = uiScale()
    val today = data.today
    val hijriOffset = data.settings.hijriOffset
    // State is keyed by the complete calculation identity: stale times cannot flash under a new city/date.
    var loaded by remember(selectedDate, data.place, data.params) { mutableStateOf<List<PrayerDay>?>(null) }
    var failed by remember(selectedDate, data.place, data.params) { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    LaunchedEffect(selectedDate, data.place, data.params, retry) {
        failed = false
        try {
            loaded = withContext(Dispatchers.Default) {
                PrayerEngine.days(selectedDate, 2, data.place.coordinates, data.place.zone, data.params)
            }
        } catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { failed = true }
    }
    val selected = loaded?.firstOrNull()
    val isToday = selectedDate == today.date
    var showDetails by rememberSaveable { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val events = remember(month, hijriOffset) { monthEvents(month, hijriOffset) }
    val dayEvents = remember(selectedDate, hijriOffset) { IslamicDays.on(selectedDate, hijriOffset) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(24f))) {
        MonthCalendar(month, selectedDate, today.date, hijriOffset, palette,
            onMonth = onMonth,
            onSelect = { date ->
                if (date != selectedDate) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onSelect(date)
                }
            },
            onToday = onToday, onPickMonth = onPick)
        DayToneLegend(Modifier.padding(top = 14.dp))
        Spacer(Modifier.height(22.dp))
        Box(Modifier.fillMaxWidth().testTag("calendar-detail")) {
            Column {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        AutoSizeText(Format.fullDate(selectedDate).replaceFirstChar { it.uppercase() },
                            color = TextPrimary, fontSize = ui.t(18f), minFontSize = ui.t(13f), fontWeight = FontWeight.Medium)
                        Text(HijriCalendar.format(selectedDate, hijriOffset), color = palette.accentSoft,
                            fontSize = ui.t(12f), modifier = Modifier.padding(top = 4.dp))
                    }
                    if (isToday) DayNote(tr("сегодня"), palette.accent, ui)
                }
                // The day of the year that falls here (or the night that began the evening before).
                dayEvents.forEach { o -> DayBanner(o, selectedDate, onOpen, Modifier.padding(top = 12.dp)) }
                Spacer(Modifier.height(12.dp))
                when {
                    failed -> {
                        Text(tr("Не удалось рассчитать этот день. Текущие настройки сохранены."), color = TextSecondary)
                        TextButton(onClick = { retry++ }) { Text(tr("Повторить"), color = palette.accentSoft) }
                    }
                    selected == null -> Text(tr("Рассчитываем время…"), color = TextSecondary,
                        modifier = Modifier.heightIn(min = 120.dp))
                    else -> {
                        // Seven named events in chronological rows, not a 3×3 grid with two empty slots.
                        Prayer.entries.forEach { prayer ->
                            Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(PrayerLabels.title(prayer), color = TextSecondary, fontSize = ui.t(14f),
                                    modifier = Modifier.weight(1f))
                                Text(selected.times[prayer]?.let { Format.time(it) } ?: "—", color =
                                    if (isToday && prayer == data.window.next) palette.accentSoft else TextPrimary,
                                    fontSize = ui.t(21f), fontFamily = FontFamily.Monospace)
                            }
                        }
                        TextButton(onClick = { showDetails = !showDetails }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (showDetails) tr("Скрыть сведения") else tr("Сведения о дне"), color = palette.accent, fontSize = ui.t(13f))
                        }
                        AnimatedVisibility(showDetails) {
                            Column {
                                DayTimeline(selected, if (isToday) now else null, palette.accent, ui)
                                Spacer(Modifier.height(16.dp))
                                val dayLength = daylight(selected)
                                SummaryRow(tr("Световой день"), Format.hoursMinutes(dayLength), ui)
                                if (!isToday) {
                                    SummaryRow(tr("Разница с сегодня"), Format.signedMinutes(dayLength.toMinutes() - daylight(today).toMinutes()), ui)
                                    SummaryRow(tr("Фаджр сдвинулся"), Format.signedMinutes(minuteShift(today, selected, Prayer.FAJR)), ui)
                                    SummaryRow(tr("Магриб сдвинулся"), Format.signedMinutes(minuteShift(today, selected, Prayer.MAGHRIB)), ui)
                                }
                                SummaryRow(tr("От Иша до Фаджра"), Format.hoursMinutes(nightLength(loaded.orEmpty(), 0)), ui)
                                Text(tr("Малая цифра в календаре — день хиджры по Умм аль-Кура. Местное наблюдение луны может отличаться."),
                                    color = TextSecondary, fontSize = ui.t(12f), lineHeight = ui.t(18f), modifier = Modifier.padding(top = 12.dp))
                            }
                        }
                        selected.note?.let {
                            Text(it, color = palette.accentSoft, fontSize = ui.t(11f), lineHeight = ui.t(16f),
                                modifier = Modifier.padding(top = 10.dp))
                        }
                    }
                }
            }
        }
        if (events.isNotEmpty()) MonthEvents(events, today.date, onOpen, Modifier.padding(top = 20.dp))
        Spacer(Modifier.height(LocalDockInset.current))
    }
}

/** The colours of the grid, once, under it: what a gold or a lavender day means. */
@Composable
private fun DayToneLegend(modifier: Modifier = Modifier) {
    val ui = uiScale()
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)) {
        listOf(
            com.nur.prayer.data.DayKind.FEAST, com.nur.prayer.data.DayKind.NIGHT,
            com.nur.prayer.data.DayKind.FAST, com.nur.prayer.data.DayKind.SEASON
        ).forEach { kind ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(DayTone.of(kind)))
                Spacer(Modifier.width(5.dp))
                Text(DayTone.label(kind), color = TextTertiary, fontSize = ui.t(11f), maxLines = 1)
            }
        }
    }
}

/** "Ид аль-Адха — Курбан-байрам · Праздник жертвоприношения", tinted, opens the sheet. */
@Composable
private fun DayBanner(o: DayOccurrence, date: LocalDate, onOpen: (SheetTopic) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val tone = DayTone.of(o.kind)
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier.fillMaxWidth().clip(shape).background(tone.copy(alpha = 0.16f)).border(1.dp, tone.copy(alpha = 0.35f), shape)
            .pressClick(scaleTo = 0.98f, role = Role.Button, onClick = { onOpen(SheetTopic.Day(o)) })
            .semantics(mergeDescendants = true) { contentDescription = IslamicDayText.title(o.day) }
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .testTag("day-banner-${o.day.name}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(tone))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(IslamicDayText.title(o.day), color = TextPrimary, fontSize = ui.t(15f), fontWeight = FontWeight.SemiBold)
            val line = if (o.days > 1) tr("День {0} из {1}", IslamicDays.daysBetween(o.start, date) + 1, o.days)
                else IslamicDayText.short(o.day)
            Text(line, color = tone, fontSize = ui.t(12.5f), modifier = Modifier.padding(top = 2.dp))
        }
        Text(tr("Подробнее"), color = TextSecondary, fontSize = ui.t(12f))
        Spacer(Modifier.width(4.dp))
        Glyph(GlyphKind.CHEVRON, TextSecondary, Modifier.size(12.dp))
    }
}

/** The days of the year that touch this Gregorian month, in a glass card. */
@Composable
private fun MonthEvents(events: List<DayOccurrence>, today: LocalDate, onOpen: (SheetTopic) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Column(modifier.fillMaxWidth()) {
        Text(
            tr("В этом месяце").uppercase(), color = TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold,
            letterSpacing = ui.t(0.8f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
        )
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Glass).padding(vertical = 4.dp)) {
            events.forEachIndexed { i, o ->
                if (i > 0) Box(Modifier.padding(start = 80.dp).fillMaxWidth().height(1.dp).background(Color(0x14FFFFFF)))
                EventRow(o, today, onOpen)
            }
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * Таблица: the month as a timetable
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun TablePage(
    month: YearMonth, times: MonthTimes?, today: LocalDate, hijriOffset: Int, palette: PhasePalette,
    onMonth: (YearMonth) -> Unit, onPick: () -> Unit, onOpen: (SheetTopic) -> Unit, onShare: () -> Unit
) {
    val ui = uiScale()
    val years = remember(today) { PeriodRange.gregorianYears(today) }
    val min = YearMonth.of(years.first, 1)
    val max = YearMonth.of(years.last, 12)
    val events = remember(month, hijriOffset) { monthEvents(month, hijriOffset) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(16f))) {
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TableArrow(true, tr("Предыдущий месяц"), month > min) { onMonth(month.minusMonths(1)) }
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                    .pressClick(role = Role.Button, onClick = onPick).padding(vertical = 4.dp)
                    .testTag("table-month"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${Format.monthName(month.monthValue)} ${month.year}", color = TextPrimary,
                        fontSize = ui.t(22f), fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.width(6.dp))
                    Glyph(GlyphKind.CHEVRON, TextSecondary, Modifier.size(14.dp).graphicsLayer { rotationZ = 90f })
                }
                val h0 = HijriCalendar.monthAndYear(month.atDay(1), hijriOffset)
                val h1 = HijriCalendar.monthAndYear(month.atEndOfMonth(), hijriOffset)
                Text(if (h0 == h1) h0 else "$h0 — $h1", color = palette.accentSoft, fontSize = ui.t(12f),
                    modifier = Modifier.padding(top = 2.dp))
            }
            TableArrow(false, tr("Следующий месяц"), month < max) { onMonth(month.plusMonths(1)) }
        }
        AnimatedContent(
            targetState = times,
            transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
            label = "monthTable"
        ) { t ->
            if (t == null) Box(Modifier.fillMaxWidth().heightIn(min = 320.dp), contentAlignment = Alignment.Center) {
                Text(tr("Рассчитываем время…"), color = TextSecondary)
            } else MonthTable(t, today, hijriOffset, palette)
        }
        if (events.isNotEmpty()) MonthEvents(events, today, onOpen, Modifier.padding(top = 20.dp))
        Row(
            Modifier.fillMaxWidth().padding(top = 18.dp).clip(RoundedCornerShape(50))
                .background(palette.accent.copy(alpha = 0.18f))
                .pressClick(enabled = times != null, role = Role.Button, onClick = onShare)
                .heightIn(min = 52.dp).padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
        ) {
            Glyph(GlyphKind.SHARE, TextPrimary, Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
            Text(tr("Поделиться картинкой"), color = TextPrimary, fontSize = ui.t(15f), fontWeight = FontWeight.SemiBold)
        }
        Text(
            IslamicDayText.datesNote(hijriOffset), color = TextTertiary, fontSize = ui.t(12f), lineHeight = ui.t(18f),
            modifier = Modifier.padding(top = 14.dp, start = 6.dp, end = 6.dp)
        )
        Spacer(Modifier.height(LocalDockInset.current))
    }
}

@Composable
private fun TableArrow(back: Boolean, label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape)
            .pressClick(enabled = enabled, onClick = onClick)
            .graphicsLayer { alpha = if (enabled) 1f else 0.3f }
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) { Glyph(GlyphKind.CHEVRON, TextPrimary, Modifier.size(18.dp).graphicsLayer { rotationZ = if (back) 180f else 0f }) }
}

/**
 * The day on an hour scale: 00:00 on the left, 24:00 on the right, night dark, daylight lit, six
 * markers where the prayers fall, and a live "now" needle on today. This is the compact, horizontal
 * reading of a day that a vertical list can never give.
 */
@Composable
private fun DayTimeline(
    day: PrayerDay,
    now: State<ZonedDateTime>?,
    accent: Color,
    ui: UiScale
) {
    val fajr = fraction(day, Prayer.FAJR)
    val sunrise = fraction(day, Prayer.SUNRISE)
    val maghrib = fraction(day, Prayer.MAGHRIB)
    val markers = Prayer.entries.mapNotNull { prayer ->
        day.times[prayer]?.let { prayer to fraction(day, prayer) }
    }

    Column {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(ui.s(34f))
        ) {
            if (size.width < 8f || size.height < 4f) return@Canvas
            val h = size.height
            val barTop = h * 0.30f
            val barHeight = h * 0.36f
            val corner = barHeight / 2f

            // Night bed.
            drawRoundRect(
                color = Color.White.copy(alpha = 0.06f),
                topLeft = Offset(0f, barTop),
                size = androidx.compose.ui.geometry.Size(size.width, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(corner, corner)
            )
            // Twilight (fajr -> sunrise) and daylight (sunrise -> maghrib).
            fun band(from: Float, to: Float, color: Color) {
                if (to <= from) return
                drawRoundRect(
                    color = color,
                    topLeft = Offset(size.width * from, barTop),
                    size = androidx.compose.ui.geometry.Size(size.width * (to - from), barHeight),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(corner, corner)
                )
            }
            band(fajr, sunrise, accent.copy(alpha = 0.24f))
            band(sunrise, maghrib, accent.copy(alpha = 0.55f))

            // Hour grid every three hours.
            for (i in 1 until 8) {
                val x = size.width * (i / 8f)
                drawLine(
                    color = Color.White.copy(alpha = 0.09f),
                    start = Offset(x, barTop),
                    end = Offset(x, barTop + barHeight),
                    strokeWidth = 1f * density
                )
            }

            // Prayer markers.
            markers.forEach { (_, f) ->
                val x = size.width * f
                drawLine(
                    color = Color.White.copy(alpha = 0.85f),
                    start = Offset(x, barTop - h * 0.16f),
                    end = Offset(x, barTop + barHeight + h * 0.16f),
                    strokeWidth = 1.6f * density,
                    cap = StrokeCap.Round
                )
            }

            // Now.
            // The state is read *here*, inside the draw scope. Compose then re-runs this lambda and
            // nothing else — no recomposition, no relayout.
            val moment = now?.value
            if (moment != null) {
                val secondOfDay = moment.hour * 3600 + moment.minute * 60 + moment.second
                val nowFraction = (secondOfDay / 86400f).coerceIn(0f, 1f)
                val x = size.width * nowFraction
                drawLine(
                    color = accent,
                    start = Offset(x, 0f),
                    end = Offset(x, h),
                    strokeWidth = 2.2f * density,
                    cap = StrokeCap.Round
                )
                drawCircle(color = accent, radius = 3f * density, center = Offset(x, h * 0.06f))
            }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            listOf("00", "06", "12", "18", "24").forEachIndexed { index, label ->
                Text(
                    text = label,
                    color = TextTertiary,
                    fontSize = ui.t(8.5f),
                    textAlign = when (index) {
                        0 -> TextAlign.Start
                        4 -> TextAlign.End
                        else -> TextAlign.Center
                    },
                    modifier = Modifier.weight(if (index == 0 || index == 4) 0.5f else 1f)
                )
            }
        }
    }
}

@Composable
private fun DayNote(text: String, color: Color, ui: UiScale) {
    AutoSizeText(
        text = text,
        color = color.copy(alpha = 0.92f),
        fontSize = ui.t(11f),
        minFontSize = ui.t(9f),
        fontWeight = FontWeight.Medium,
        letterSpacing = ui.t(0.4f),
        resizeKey = text.length
    )
}

@Composable
private fun SummaryRow(label: String, value: String, ui: UiScale) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(4f)),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AutoSizeText(
            text = label,
            color = TextTertiary,
            fontSize = ui.t(11.5f),
            minFontSize = ui.t(9f),
            maxLines = 2,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(ui.s(10f)))
        AutoSizeText(
            text = value,
            color = TextPrimary,
            fontSize = ui.t(12.5f),
            minFontSize = ui.t(10f),
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun HairLine(ui: UiScale) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(8f))
            .height(1.dp)
            .background(SurfaceEdge)
    )
}

/* ------------------------------------------------------------------------------------------------
 * Small calculations
 * ---------------------------------------------------------------------------------------------- */

/** Where a prayer falls inside its own local day, 0..1. */
private fun fraction(day: PrayerDay, prayer: Prayer): Float {
    val time = day.times[prayer] ?: return 0f
    val local = time.toLocalTime()
    val seconds = local.hour * 3600 + local.minute * 60 + local.second
    // A prayer pushed past midnight (short northern nights) belongs to the far right edge.
    val rolled = if (time.toLocalDate().isAfter(day.date)) 86400 else seconds
    return (rolled / 86400f).coerceIn(0f, 1f)
}

private fun daylight(day: PrayerDay): Duration {
    val sunrise = day.times[Prayer.SUNRISE]
    val maghrib = day.times[Prayer.MAGHRIB]
    if (sunrise == null || maghrib == null) return Duration.ZERO
    return Duration.between(sunrise, maghrib)
}

/** How many minutes a prayer moved between two days. */
private fun minuteShift(from: PrayerDay, to: PrayerDay, prayer: Prayer): Long {
    val a = from.times[prayer] ?: return 0
    val b = to.times[prayer] ?: return 0
    val aMinutes = a.toLocalTime().toSecondOfDay() / 60L
    val bMinutes = b.toLocalTime().toSecondOfDay() / 60L
    return bMinutes - aMinutes
}

/** Isha of the selected day to Fajr of the following one — the real night, across midnight. */
private fun nightLength(days: List<PrayerDay>, index: Int): Duration {
    val current = days.getOrNull(index) ?: return Duration.ZERO
    val isha = current.times[Prayer.ISHA] ?: return Duration.ZERO
    val nextFajr = days.getOrNull(index + 1)?.times?.get(Prayer.FAJR)
        ?: return Duration.ZERO
    val length = Duration.between(isha, nextFajr)
    return if (length.isNegative) Duration.ZERO else length
}
