package com.nur.prayer.ui.schedule

import com.nur.prayer.i18n.tr

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.abs

/*
 * 0.19.0 — choosing a period. The reference app drops a plain list of twelve months; Nur's tables
 * are computed for any year, so the block carries two drums instead — month and year — that spin
 * under the thumb, snap to the centre row with a haptic tick and tilt away like a real wheel.
 * The sky behind dims; tap outside or Back to leave without changes, «Готово» to apply.
 */

/** Which drums the block shows: month + Gregorian year (grid, table) or the hijri year (year view). */
enum class PickerMode { MONTH, HIJRI_YEAR }

/** The years the wheels offer around today; prayer times and Umm al-Qura are valid far beyond. */
object PeriodRange {
    const val SPAN = 10

    fun gregorianYears(today: LocalDate): IntRange = (today.year - SPAN)..(today.year + SPAN)

    fun hijriYears(today: LocalDate, offset: Int): IntRange {
        val y = IslamicDays.hijriOf(today, offset).year
        return (y - SPAN).coerceAtLeast(IslamicDays.MIN_YEAR)..(y + SPAN).coerceAtMost(IslamicDays.MAX_YEAR)
    }
}

@Composable
internal fun PeriodPicker(
    visible: Boolean,
    mode: PickerMode,
    month: YearMonth,
    hijriYear: Int,
    today: LocalDate,
    hijriOffset: Int,
    accent: Color,
    surface: Color,
    onMonth: (YearMonth) -> Unit,
    onHijriYear: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    BackHandler(enabled = visible) { onDismiss() }
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible, enter = fadeIn(tween(200)), exit = fadeOut(tween(160))) {
            Box(
                Modifier.fillMaxSize().background(Color(0x99000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
                    .semantics { contentDescription = tr("Закрыть") }
            )
        }
        AnimatedVisibility(
            visible, modifier = Modifier.align(Alignment.Center),
            enter = fadeIn(tween(200)) + scaleIn(tween(240), initialScale = 0.9f) + slideInVertically(tween(260)) { it / 10 },
            exit = fadeOut(tween(140)) + scaleOut(tween(160), targetScale = 0.94f) + slideOutVertically(tween(160)) { it / 14 }
        ) {
            PickerCard(mode, month, hijriYear, today, hijriOffset, accent, surface, onMonth, onHijriYear, onDismiss)
        }
    }
}

@Composable
private fun PickerCard(
    mode: PickerMode, month: YearMonth, hijriYear: Int, today: LocalDate, hijriOffset: Int,
    accent: Color, surface: Color,
    onMonth: (YearMonth) -> Unit, onHijriYear: (Int) -> Unit, onDismiss: () -> Unit
) {
    val ui = uiScale()
    val years = remember(today) { PeriodRange.gregorianYears(today) }
    val hijriYears = remember(today, hijriOffset) { PeriodRange.hijriYears(today, hijriOffset) }
    // The drums edit a draft; nothing behind the scrim moves until «Готово».
    var draftMonth by remember(month) { mutableIntStateOf(month.monthValue - 1) }
    var draftYear by remember(month) { mutableIntStateOf((month.year - years.first).coerceIn(0, years.count() - 1)) }
    var draftHijri by remember(hijriYear) { mutableIntStateOf((hijriYear - hijriYears.first).coerceIn(0, hijriYears.count() - 1)) }
    val cardShape = RoundedCornerShape(28.dp)
    Column(
        Modifier
            .padding(horizontal = 28.dp)
            .widthIn(max = 420.dp)
            .fillMaxWidth()
            .clip(cardShape)
            .background(surface)
            // Taps inside the card must not reach the scrim.
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .padding(horizontal = 20.dp, vertical = 22.dp)
            .testTag("period-picker"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            if (mode == PickerMode.MONTH) tr("Выберите месяц") else tr("Год по хиджре"),
            color = TextPrimary, fontSize = ui.t(18f), fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(16.dp))
        if (mode == PickerMode.MONTH) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Wheel(12, draftMonth, { Format.monthName(it + 1) }, { draftMonth = it }, accent, surface,
                    Modifier.weight(1.4f).testTag("wheel-month"))
                Wheel(years.count(), draftYear, { (years.first + it).toString() }, { draftYear = it }, accent, surface,
                    Modifier.weight(1f).testTag("wheel-year"))
            }
            val picked = YearMonth.of(years.first + draftYear, draftMonth + 1)
            val start = HijriCalendar.monthAndYear(picked.atDay(1), hijriOffset)
            val end = HijriCalendar.monthAndYear(picked.atEndOfMonth(), hijriOffset)
            Text(
                if (start == end) start else "$start — $end", color = TextSecondary, fontSize = ui.t(12f),
                textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp)
            )
        } else {
            Wheel(hijriYears.count(), draftHijri, { "${hijriYears.first + it}" }, { draftHijri = it }, accent, surface,
                Modifier.fillMaxWidth(0.6f).testTag("wheel-hijri"))
            val y = hijriYears.first + draftHijri
            val first = IslamicDays.gregorian(y, 1, 1, hijriOffset)
            val last = IslamicDays.gregorian(y, 12, IslamicDays.monthLength(y, 12), hijriOffset)
            if (first != null && last != null) Text(
                "${Format.dayMonth(first)} ${first.year} — ${Format.dayMonth(last)} ${last.year}",
                color = TextSecondary, fontSize = ui.t(12f), textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NurButton(tr("Сегодня"), accent, {
                if (mode == PickerMode.MONTH) onMonth(YearMonth.from(today)) else onHijriYear(IslamicDays.hijriOf(today, hijriOffset).year)
                onDismiss()
            }, Modifier.weight(1f))
            NurButton(tr("Готово"), accent, {
                if (mode == PickerMode.MONTH) onMonth(YearMonth.of(years.first + draftYear, draftMonth + 1))
                else onHijriYear(hijriYears.first + draftHijri)
                onDismiss()
            }, Modifier.weight(1f).testTag("period-done"), primary = true)
        }
    }
}

/**
 * A drum of [count] rows. The list scrolls freely; when the finger and the fling have stopped, the
 * nearest row is pulled to the centre. Rows tilt with their distance from the centre (rotationX,
 * scale, alpha), read in the draw phase: spinning does not recompose the rows.
 */
@Composable
internal fun Wheel(
    count: Int,
    selected: Int,
    label: (Int) -> String,
    onSelected: (Int) -> Unit,
    accent: Color,
    fade: Color,
    modifier: Modifier = Modifier,
    rows: Int = 5,
    rowHeight: Dp = 44.dp
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val state = rememberLazyListState(initialFirstVisibleItemIndex = selected.coerceIn(0, (count - 1).coerceAtLeast(0)))
    val rowPx = with(LocalDensity.current) { rowHeight.toPx() }
    val density = LocalDensity.current.density
    val centre by remember(count, rowPx) {
        derivedStateOf {
            val extra = if (state.firstVisibleItemScrollOffset > rowPx / 2f) 1 else 0
            (state.firstVisibleItemIndex + extra).coerceIn(0, (count - 1).coerceAtLeast(0))
        }
    }
    val select by rememberUpdatedState(onSelected)
    // A tick for every row that crosses the centre line, like the detent of a real wheel.
    LaunchedEffect(state) {
        snapshotFlow { centre }.drop(1).collect { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
    }
    // Snap when the scroll is over (finger lifted and fling finished).
    LaunchedEffect(state) {
        snapshotFlow { state.isScrollInProgress }.filter { !it }.collect {
            val target = centre
            if (state.firstVisibleItemIndex != target || state.firstVisibleItemScrollOffset != 0) state.animateScrollToItem(target)
            select(target)
        }
    }
    // Moved from outside («Сегодня» in a parent): follow without a jump.
    LaunchedEffect(selected) {
        if (!state.isScrollInProgress && centre != selected) state.animateScrollToItem(selected.coerceIn(0, count - 1))
    }
    val half = rows / 2
    Box(modifier.height(rowHeight * rows)) {
        Box(
            Modifier.align(Alignment.Center).fillMaxWidth().height(rowHeight)
                .clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = 0.16f))
        )
        LazyColumn(
            state = state,
            contentPadding = PaddingValues(vertical = rowHeight * half),
            modifier = Modifier.fillMaxSize()
        ) {
            items(count) { i ->
                val active = i == centre
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(rowHeight)
                        .graphicsLayer {
                            val pos = state.firstVisibleItemIndex + state.firstVisibleItemScrollOffset / rowPx
                            val d = i - pos
                            val a = abs(d).coerceAtMost(3f)
                            rotationX = (-d * 22f).coerceIn(-75f, 75f)
                            val s = 1f - 0.08f * a
                            scaleX = s
                            scaleY = s
                            alpha = (1f - 0.32f * a).coerceAtLeast(0.06f)
                            cameraDistance = 10f * density
                        }
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                            scope.launch { state.animateScrollToItem(i) }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label(i), color = if (active) TextPrimary else TextTertiary,
                        fontSize = ui.t(if (active) 19f else 17f),
                        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                        maxLines = 1
                    )
                }
            }
        }
        // The drum fades into the card at both ends.
        Box(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().height(rowHeight * 1.4f)
                .background(Brush.verticalGradient(listOf(fade, fade.copy(alpha = 0f))))
        )
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(rowHeight * 1.4f)
                .background(Brush.verticalGradient(listOf(fade.copy(alpha = 0f), fade)))
        )
    }
}
