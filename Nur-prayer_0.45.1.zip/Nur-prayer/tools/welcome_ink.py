"""Build the greeting's stroke-time texture from WHITE alpha only, never reference luminance.

Two channels encode a unit circle; the Android colour matrix projects it onto the moving clock.
The third channel varies the depth. No bitmap frames or offscreen blend are needed on Android.
Usage: python tools/welcome_ink.py [build|check]; Pillow and NumPy for asset authoring only.
"""
from pathlib import Path
import sys
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'app/src/main/res/drawable-nodpi'

def texture():
    white=np.array(Image.open(ROOT/'art/welcome/lettering_white.webp').convert('RGBA'))
    a=white[:,:,3]; assert a.shape==(196,405) and (white[:,:,:3][a>0]==255).all()
    y,x=np.indices(a.shape); tau=2*np.pi
    # The capital A: upstroke -> downstroke -> crossbar. Blend at ink junctions, not across the sky.
    def segment(ax,ay,bx,by,start,end):
        dx,dy=bx-ax,by-ay; t=np.clip(((x-ax)*dx+(y-ay)*dy)/(dx*dx+dy*dy),0,1)
        dist=(x-ax-t*dx)**2+(y-ay-t*dy)**2
        return np.exp(-dist/44),start+t*(end-start)
    cap=[segment(3,79,64,6,.000,.053),segment(65,5,62,77,.053,.090),segment(7,56,66,49,.088,.118)]
    ac=sum(w*t for w,t in cap)/np.maximum(1.e-10,sum(w for w,t in cap))
    def script(x0,width,beg,end,mid):
        f=np.clip((x-x0)/width,0,1)
        # Vary passage time with height and curvature: loops and tails do not dim in a straight bar.
        return beg+(end-beg)*f+.012*np.sin(15*tau*f+.049*(y-mid))+.00044*(y-mid)*np.cos(7*tau*f)
    top=np.where(x<75,ac,script(80,323,.149,.615,58)); lower=script(1,345,.435,.887,151)
    # The detached breve above й belongs to the lower word; final descending у of line 1 is upper.
    bottom=(y>=116)|((y>=96)&(x>140)&(x<185)); p=np.where(bottom,lower,top)
    depth=.55+.42*(.5+.5*np.cos(.074*x-.095*y))
    field=np.stack([(1+np.cos(tau*p))*127.5,(1+np.sin(tau*p))*127.5,depth*255,a],axis=2)
    return np.rint(field).clip(0,255).astype('uint8')

def colors(tex,p):
    g=np.array([116,108,93])/.16; theta=(p%1.)*2*np.pi
    q=(tex[:,:,0].astype(float)/127.5-1)*np.cos(theta)+(tex[:,:,1].astype(float)/127.5-1)*np.sin(theta)
    return np.rint(255+(.84-q[:,:,None])*g+20*(1-tex[:,:,2:3]/255)).clip(0,255).astype('uint8')

if __name__=='__main__':
    out=D/'welcome_ink_field.webp'; expected=texture()
    if sys.argv[1:]==['build']: Image.fromarray(expected).save(out,lossless=True,method=6)
    actual=np.asarray(Image.open(out).convert('RGBA')); a=expected[:,:,3]; assert np.array_equal(actual[:,:,3],a) and np.array_equal(actual[a>0],expected[a>0]); ink=a==255
    y,x=np.indices(a.shape); start=colors(actual,0)[:,:,0]; dark=ink&(start<215)
    assert dark.any() and ((x[dark]<75)&(y[dark]<85)).all() and (start[ink&(x<16)&(y>67)&(y<83)]<190).any()
    frames=np.stack([colors(actual,k/100)[:,:,0] for k in range(100)]); assert (frames.max(0)[ink]==255).all() and (frames.min(0)[ink]<190).all(); assert np.array_equal(colors(actual,0),colors(actual,1))
    print(f'PASS: {ink.sum()} opaque ink pixels return to white AND turn silver; phase zero starts on A only; alpha and loop verified')
