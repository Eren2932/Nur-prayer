package com.nur.prayer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PixelMap
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.ui.welcome.GreetingLettering
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class WelcomeInkRenderTest {
    @get:Rule val compose = createComposeRule()

    @Test fun firstCapitalThenMiddleStrokeAndWhiteRestFrame() {
        val phase = mutableStateOf<Float?>(0f)
        compose.setContent {
            Box(Modifier.background(Color.Black)) { GreetingLettering(180.dp) { phase.value } }
        }
        val title = compose.onNodeWithContentDescription("Ассаламу алейкум")
        val atStart = title.captureToImage().toPixelMap()
        compose.runOnIdle { phase.value = .38f }
        val inMotion = title.captureToImage().toPixelMap()
        compose.runOnIdle { phase.value = null }
        val white = title.captureToImage().toPixelMap()
        // Count only solid, nearly white interior pixels; antialiased outlines can differ by GPU.
        fun toned(frame: PixelMap, lo: Float, hi: Float): Int {
            var n = 0
            for (y in 0 until white.height / 2) for (x in (lo * white.width).toInt() until (hi * white.width).toInt()) {
                if (white[x, y].red > .97f && white[x, y].red - frame[x, y].red > .15f) n++
            }
            return n
        }
        assertTrue(toned(atStart, 0f, .19f) > 8)
        assertTrue(toned(atStart, .24f, .82f) == 0)
        assertTrue(toned(inMotion, .32f, .8f) > 8)
        assertTrue(toned(inMotion, 0f, .17f) == 0)
    }
}
