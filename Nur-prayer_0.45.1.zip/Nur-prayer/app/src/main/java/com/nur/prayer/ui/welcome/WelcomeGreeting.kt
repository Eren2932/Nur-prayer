package com.nur.prayer.ui.welcome

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntSize
import kotlin.math.roundToInt
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.R
import com.nur.prayer.i18n.AppLanguage
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.rememberMotionBudget
import kotlinx.coroutines.delay

private const val CYCLE_NS = 9_200_000_000.0

@Composable
internal fun WelcomeGreeting(width: Dp, revealed: Boolean) {
    val budget = rememberMotionBudget()
    val phase = remember { mutableFloatStateOf(0f) }
    val active = revealed && budget.foregroundScale > 0f
    LaunchedEffect(budget, revealed) {
        if (!active) return@LaunchedEffect
        var previous = 0L
        while (true) {
            withFrameNanos { now ->
                if (previous != 0L) {
                    val dt = (now - previous).coerceIn(0L, 150_000_000L)
                    phase.floatValue = ((phase.floatValue + dt / (CYCLE_NS * budget.foregroundScale)) % 1.0).toFloat()
                }
                previous = now
            }
            delay(if (budget.saving) 65L else 28L)
        }
    }
    GreetingLettering(width) { if (active) phase.floatValue else null }
}

/** The phase asset is not a coloured title: R/G store cos/sin of each stroke's arrival time.
 * A single colour filter projects that vector onto the clock and leaves alpha untouched. */
internal fun inkAt(phase: Float): ColorFilter {
    val theta = 2.0 * Math.PI * (phase % 1f)
    val c = cos(theta).toFloat(); val s = sin(theta).toFloat()
    val m = ColorMatrix()
    for (row in 0..2) {
        val gain = (when (row) { 0 -> 116f; 1 -> 108f; else -> 93f }) / .16f
        m[row, 0] = -gain * c / 127.5f
        m[row, 1] = -gain * s / 127.5f
        m[row, 2] = -20f / 255f
        m[row, 3] = 0f
        m[row, 4] = 275f + gain * (.84f + c + s)
    }
    return ColorFilter.colorMatrix(m)
}

@Composable
internal fun GreetingLettering(width: Dp, phase: () -> Float?) {
    val title = tr("Ассаламу алейкум")
    if (L10n.language == AppLanguage.RU) {
        val map = ImageBitmap.imageResource(R.drawable.welcome_ink_field)
        val white = remember { ColorFilter.tint(Color.White) }
        Canvas(Modifier.width(width).aspectRatio(405f / 196f).semantics { contentDescription = title }) {
            drawImage(map, dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
                colorFilter = phase()?.let(::inkAt) ?: white)
        }
    } else {
        // Translated text stays live text. Never apply Cyrillic stroke coordinates to other scripts.
        val ink = Modifier.graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }.drawWithCache {
            val w = size.width.coerceAtLeast(1f)
            val brush = Brush.linearGradient(0f to Color(0xFF98A1AF), .13f to Color.White,
                .87f to Color.White, 1f to Color(0xFF98A1AF), start = Offset.Zero,
                end = Offset(w, w * .16f), tileMode = TileMode.Repeated)
            onDrawWithContent {
                drawContent()
                phase()?.let { p ->
                    val dx = p * (w * 1.0256f)
                    translate(dx, 0f) { drawRect(brush, Offset(-dx, 0f), size, blendMode = BlendMode.SrcAtop) }
                }
            }
        }
        Text(title, modifier = ink, color = Color.White, fontFamily = FontFamily.Cursive,
            fontSize = (width.value * .24f).sp, lineHeight = (width.value * .26f).sp, fontStyle = FontStyle.Italic)
    }
}
