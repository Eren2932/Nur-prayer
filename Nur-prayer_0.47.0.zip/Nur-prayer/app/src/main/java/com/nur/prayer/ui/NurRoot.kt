package com.nur.prayer.ui

import com.nur.prayer.i18n.tr
import com.nur.prayer.CrashReport
import com.nur.prayer.ui.home.HomeSection
import com.nur.prayer.ui.shell.CapsuleRoom
import com.nur.prayer.ui.shell.FrostSource
import com.nur.prayer.ui.shell.SectionBarRoom
import com.nur.prayer.ui.shell.PrayerIslandHost
import com.nur.prayer.ui.shell.rememberPrayerIslandTarget
import com.nur.prayer.ui.shell.IslandRoom
import com.nur.prayer.ui.shell.LocalFrost
import com.nur.prayer.ui.shell.LocalShell
import com.nur.prayer.ui.shell.PrayerSheetHost
import com.nur.prayer.ui.shell.ShellLayer
import com.nur.prayer.ui.shell.ShellRoutes
import com.nur.prayer.ui.shell.ShellState
import com.nur.prayer.ui.theme.LocalIslandInset
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import com.nur.prayer.i18n.AppLanguage
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.LocalLanguageSwitcher
import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.launch

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.runtime.DisposableEffect
import com.nur.prayer.ui.theme.findActivity
import com.nur.prayer.ui.theme.SystemBarsTone
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.absolutePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.systemBars
import com.nur.prayer.ui.components.pageContentInsets
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.City
import com.nur.prayer.ui.components.LocalBackdropPaused
import com.nur.prayer.ui.home.rememberDayReveal
import com.nur.prayer.data.HomeLayout
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.learn.CourseScreen
import com.nur.prayer.ui.learn.DictionaryScreen
import com.nur.prayer.ui.learn.LearnViewModel
import com.nur.prayer.ui.learn.LessonScreen
import com.nur.prayer.ui.learn.SurahScreen
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.daily.Vird
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.ui.today.DeedTone
import com.nur.prayer.ui.today.VirdPage
import com.nur.prayer.ui.today.TodayActions
import com.nur.prayer.ui.today.TodayScreen
import com.nur.prayer.ui.today.TodayState
import com.nur.prayer.ui.daily.AzkarScreen
import com.nur.prayer.ui.daily.DailyViewModel
import com.nur.prayer.ui.daily.DhikrScreen
import com.nur.prayer.ui.daily.StoryScreen
import com.nur.prayer.daily.Azkar
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.DailyStories
import com.nur.prayer.learn.QuranShort
import com.nur.prayer.daily.StorySlide
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.components.ExitDock
import com.nur.prayer.ui.components.ExitButtonSpec
import com.nur.prayer.ui.components.rememberSystemBack
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.settings.SettingsScreen
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.layout.statusBars
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.animatedPhasePalette
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime

/**
 * 0.27.0 «Капсула»: all navigation lives in one floating capsule at the bottom (ShellLayer). It
 * opens in place into a panel with the times of the day and the grid of sections; inside a section
 * it names the section, the countdown moves into the island at the top and the moon leads home.
 * The pages do not know how they were opened: the shell only calls [NurNavigator] (go from home,
 * switchTo between sections), so another way of navigating can replace it without touching them.
 *
 * 0.9.0: the pull-up from home raises «Сегодня» (learning, word of the day, tasks of the day); the
 * course, a lesson, the dictionary and the surah reader open inside that layer, so going deeper
 * never drops it. Календарь became an ordinary page opened from the right.
 *
 * 0.6.0 shell: no dock. Home is the root and owns the whole screen; Календарь, Кыбла and Настройки
 * open over it from the right and close back to it, Город opens one level deeper from wherever it
 * was called. The sky is drawn once, behind every route, so a transition never flashes black.
 */
@Composable
fun NurRoot(
    data: PrayerData?, now: State<ZonedDateTime>, locating: Boolean, locationStatus: String?,
    exactAlarmsAllowed: Boolean, notificationsAllowed: Boolean, citySearch: suspend (String) -> List<City>, onPickCity: (City) -> Unit,
    actionsFactory: (openCityPicker: () -> Unit) -> AppActions,
    locationButtonLabel: String = tr("Определить местоположение")
) {
    val nav = rememberSaveable(saver = NurNavigator.Saver) { NurNavigator() }
    // Where the menu item that opened Кыбла / Настройки sits on screen. Deliberately not saved: after
    // a restore the page simply has no origin and uses the ordinary slide.
    val menuOrigin = remember { arrayOf(Offset.Unspecified) }
    // 0.26.0: the same for the layer (Дела дня, Коран, Обучение, Зикр) opened from a cell of the
    // panel (0.27.0). With an origin the layer grows out of the sector and sinks back into it; without one
    // (a restore) it rises from below as before.
    val layerOrigin = remember { arrayOf(Offset.Unspecified) }
    val layerTopLeft = remember { arrayOf(Offset.Zero) }
    val pages = rememberSaveableStateHolder()
    val quranNav = androidx.compose.runtime.saveable.rememberSaveable(saver = com.nur.prayer.ui.quran.QuranNav.Saver) { com.nur.prayer.ui.quran.QuranNav() }
    val backdropPaused = remember { mutableStateOf(false) }
    BackHandler(nav.canGoBack) { nav.back() }
    // The capsule and its panel. Not saveable: an open panel must not greet the user after a return.
    val shell = remember { ShellState() }
    // The prayer sheet is above every page (a time on home and a card in the panel open it); its
    // prayer survives rotation and process death, stored by name and validated on read.
    var sheetName by rememberSaveable { mutableStateOf<String?>(null) }
    val sheetPrayer = sheetName?.let { name -> Prayer.entries.firstOrNull { it.name == name } }
    val targetPalette = remember(data?.window?.current) { paletteFor(data?.window?.current ?: Prayer.ISHA) }
    val palette = animatedPhasePalette(targetPalette)
    // 0.23.0: a wallpaper the user just chose is on screen at once. The stored id travels through
    // DataStore and a full PrayerData recomputation (two passes of the schedule) before it comes
    // back; until it does, this choice is what the backdrop, the gallery and the settings row show.
    var wallpaperChoice by remember { mutableStateOf<String?>(null) }
    val baseActions = remember(nav) { actionsFactory { nav.go(ROUTE_CITY) } }
    val actions = remember(baseActions) {
        baseActions.copy(setWallpaper = { id ->
            wallpaperChoice = id
            baseActions.setWallpaper(id)
        })
    }
    // «Сегодня» is not a page that slides in from the side: it is a layer above home that rises
    // from the bottom, under the finger when pulled. A route change only tells it where to settle;
    // its position is one number (see Reveal). Learning pages live inside it.
    val learn: LearnViewModel = viewModel()
    val learnContent by learn.content.collectAsStateWithLifecycle()
    val learnProgress by learn.progress.collectAsStateWithLifecycle()
    // Ayat the reader has sent to the repetition (hifz); the reader marks them "В повторении".
    val quranReviewed = remember(learnProgress) { learnProgress.reviewedAyat() }
    val activeLesson by learn.active.collectAsStateWithLifecycle()
    val daily: DailyViewModel = viewModel()
    val totals by daily.dhikrTotal.collectAsStateWithLifecycle()
    val dhikrToday by daily.dhikrToday.collectAsStateWithLifecycle()
    val vird by daily.vird.collectAsStateWithLifecycle()
    // The word the dictionary opens on: the word of the day from its tile, nothing from anywhere else.
    val dictionaryFocus = rememberSaveable { mutableStateOf<String?>(null) }
    val storyMask by daily.storyMask.collectAsStateWithLifecycle()
    val voiceContext = androidx.compose.ui.platform.LocalContext.current
    // The engine itself connects only when a screen that may speak asks for it (rememberVoiceStatus).
    val arabicVoice = remember { com.nur.prayer.audio.ArabicVoice.get(voiceContext) }
    val scheduleOpen = nav.layerOpen
    val calendar = remember { Reveal(initiallyOpen = scheduleOpen) }
    LaunchedEffect(scheduleOpen) { calendar.settle(scheduleOpen) }
    // A lesson does not survive process death (its exercises are random); a restored lesson route
    // without a running lesson steps back to the course instead of showing an empty page.
    LaunchedEffect(nav.current, activeLesson == null) {
        if (nav.current == ROUTE_LESSON && activeLesson == null) nav.back()
    }
    // The layer keeps drawing its last page while it falls back.
    val lastLayer = remember { arrayOf(ROUTE_TODAY) }
    if (nav.layerOpen) lastLayer[0] = nav.current
    // Fully covered home is removed from the tree: nothing hidden ticks, draws or answers touches.
    // Going back flips scheduleOpen a frame before the layer starts to fall, so home is composed
    // in time and the first frames of the fall are not spent on it.
    val homeOnScreen by remember(scheduleOpen) { derivedStateOf { !scheduleOpen || calendar.progress < 1f } }
    val scheduleOnScreen by remember(scheduleOpen) { derivedStateOf { scheduleOpen || calendar.progress > 0f } }
    // Without a dock, the bottom inset of scrolling screens is just the system bar plus air.
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    // 0.18.0: with edge-to-edge enforced the content must also keep clear of the sides: a landscape phone
    // with three-button navigation has the bar on one side, and a camera cutout may sit on the other.
    // Physical left/right (absolutePadding), so the Arabic layout direction does not swap them.
    val sideBars = WindowInsets.systemBars.asPaddingValues()
    val sideCutout = WindowInsets.displayCutout.asPaddingValues()
    val sideLeft = maxOf(sideBars.calculateLeftPadding(LayoutDirection.Ltr), sideCutout.calculateLeftPadding(LayoutDirection.Ltr))
    val sideRight = maxOf(sideBars.calculateRightPadding(LayoutDirection.Ltr), sideCutout.calculateRightPadding(LayoutDirection.Ltr))
    // Which route the root was on before the current one: the menu reveal runs only between home
    // and a menu page, never between Настройки and «Город».
    val rootTarget = if (scheduleOpen) TAB_HOME else nav.current
    val rootPrevious = remember { arrayOf(rootTarget, rootTarget) } // [previous, current]
    if (rootPrevious[1] != rootTarget) { rootPrevious[0] = rootPrevious[1]; rootPrevious[1] = rootTarget }
    // 0.22.0: the backdrop is a wallpaper; «Живое небо» and «Чёрный» are two of them.
    // Before the settings are read there is no wallpaper yet: a black placeholder, so the stored one
    // fades in quietly instead of "being set" (sky → picture) on every launch.
    val storedWallpaper = data?.settings?.wallpaperId
    LaunchedEffect(storedWallpaper) { if (storedWallpaper != null && storedWallpaper == wallpaperChoice) wallpaperChoice = null }
    val wallpaper = remember(data == null, wallpaperChoice, storedWallpaper, data?.settings?.skyBackdrop) {
        when {
            data == null -> com.nur.prayer.ui.wallpaper.WallpaperCatalog.Amoled
            else -> com.nur.prayer.ui.wallpaper.WallpaperCatalog.resolve(wallpaperChoice ?: storedWallpaper, data.settings.skyBackdrop)
        }
    }
    // 0.28.0: the calendar is a light "paper" page. Over a light picture (kaaba_day) the black page scrim
    // is lifted; over a dark one the page stays dimmed and its header text stays white.
    val paperPage = rootTarget == TAB_SCHEDULE && wallpaper.light
    val paperLift by animateFloatAsState(
        if (paperPage) 1f else 0f, tween(NavigationMotion.DETAIL_ENTER_MILLIS), label = "paperLift"
    )
    // A picture is darkened and frosted under pages that put lists of text straight on the backdrop (Календарь,
    // Кыбла).
    val pageDim by animateFloatAsState(
        if (rootTarget == TAB_SCHEDULE || rootTarget == TAB_QIBLA) 1f else 0f,
        tween(NavigationMotion.DETAIL_ENTER_MILLIS), label = "wallpaperDim"
    )
    // 0.34.0: settings and the city picker are glass cards on the SHARP wallpaper, darkened (not frosted) by the
    // page scrim, over any wallpaper: the reference's settings, measured. They used to be opaque pages.
    val pageShade by animateFloatAsState(
        if (rootTarget == TAB_SETTINGS || rootTarget == ROUTE_CITY) 1f else 0f,
        tween(NavigationMotion.DETAIL_ENTER_MILLIS), label = "wallpaperShade"
    )
    // 0.41.0: «Дела» lies on the SOFT copy of the picture (about 3 dp of blur, measured on the reference); a page opened
    // from it (the Quran, azkar, the counter...) goes on to the ordinary frost. One number moves between the two.
    val deepLayer = animateFloatAsState(
        if (lastLayer[0] != ROUTE_TODAY) 1f else 0f,
        tween(NavigationMotion.DETAIL_ENTER_MILLIS), label = "layerDeep"
    )
    // The matte glass of the capsule, the panel and the island shows this wallpaper, blurred, darkened
    // exactly as the page darkens the sharp one.
    val wallpaperNow = rememberUpdatedState(wallpaper)
    val pageDimNow = rememberUpdatedState(pageDim)
    val frostSource = remember { FrostSource(wallpaper = { wallpaperNow.value }, dim = { maxOf(calendar.progress, pageDimNow.value) }) }
    var wallpapersOpen by rememberSaveable { mutableStateOf(false) }
    // Leaving settings by any path closes the gallery with it.
    LaunchedEffect(rootTarget) { if (rootTarget != TAB_SETTINGS) wallpapersOpen = false }
    // 0.13.0 language switch: the words fade out over the sky, change while nothing is readable and
    // come back — one calm breath instead of a flash of half-translated text. The sky never blinks,
    // the page and its scroll stay where they were. A second tap mid-way cancels the first cleanly.
    val languageScope = rememberCoroutineScope()
    val languageFade = remember { Animatable(0f) }
    val switchLanguage: (AppLanguage) -> Unit = remember {
        { language ->
            if (language != L10n.language) languageScope.launch {
                languageFade.animateTo(1f, tween(LANGUAGE_OUT_MILLIS, easing = FastOutLinearInEasing))
                L10n.set(language)
                withFrameNanos { } // recompose in the new language while invisible
                languageFade.animateTo(0f, tween(LANGUAGE_IN_MILLIS, easing = FastOutSlowInEasing))
                delay(1500)
                L10n.confirm() // survived: the crash-loop guard in L10n.install lets go of it
            }
        }
    }
    // The trace of the previous crash, if there was one: shown once over everything, ready to copy.
    val appContext = LocalContext.current
    val crashReport = remember { mutableStateOf(CrashReport.take(appContext)) }
    // A section chosen in the panel. From home it is a step forward (back returns home); from inside a
    // section it replaces the section, so back never walks through every section visited.
    val openSection: (HomeSection, Offset) -> Unit = { section, origin ->
        val route = ShellRoutes.routeOf(section)
        if (section == HomeSection.SETTINGS) {
            // The gear of the panel (0.29.0). Settings are a page with its own way out, not a section of the grid.
            menuOrigin[0] = origin
            if (nav.current == TAB_HOME) nav.go(TAB_SETTINGS) else nav.switchTo(TAB_SETTINGS)
        } else if (route != null) {
            if (route in LAYER_ROUTES) layerOrigin[0] = origin else menuOrigin[0] = origin
            when (section) {
                HomeSection.DHIKR -> daily.openVird(null)
                HomeSection.QURAN -> {
                    // The bookmark if there is one, al-Fatiha on the very first visit.
                    val mark = com.nur.prayer.quran.QuranStore.get(appContext).mark
                    quranNav.read(mark?.surah ?: 1, mark?.ayah ?: 0)
                }
                else -> Unit
            }
            if (nav.current == TAB_HOME) nav.go(route) else nav.switchTo(route)
        }
    }
    // The moon in the capsule: home, the page sinking back into the moon it was left by.
    val goHome: (Offset) -> Unit = { origin ->
        if (nav.layerOpen) layerOrigin[0] = origin else menuOrigin[0] = origin
        nav.go(TAB_HOME)
    }
    // The soft picture and its neutral exposure crossfade together. Only switch status glyphs
    // once the header is present; the dark bottom dock never needs the paper navigation tone.
    val photoHeaderVisible by remember(calendar, deepLayer) { derivedStateOf {
        calendar.progress * (1f - deepLayer.value) >= .90f
    } }
    if (wallpaper.isImage && photoHeaderVisible && !shell.open && sheetName == null && !wallpapersOpen) {
        val window = LocalContext.current.findActivity()?.window
        if (window != null) DisposableEffect(window) {
            val owner = Any()
            SystemBarsTone.photoHeader(window, owner, true)
            onDispose { SystemBarsTone.photoHeader(window, owner, false) }
        }
    }
    val capsuleRoute = nav.current
    val panelVisible by remember(shell) { derivedStateOf { shell.open || shell.progress > .001f } }
    var calendarModal by remember { mutableStateOf(false) }
    val island = if (data != null && ShellRoutes.islandOn(capsuleRoute) && !panelVisible &&
        sheetPrayer == null && !wallpapersOpen && crashReport.value == null && !(capsuleRoute == TAB_SCHEDULE && calendarModal))
        rememberPrayerIslandTarget(capsuleRoute, data.days, now) else null
    val islandInset = if (island != null) IslandRoom else 0.dp
    val layoutDirection = if (L10n.language.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(
        // Scrolling pages keep their last line above the capsule when it is there.
        LocalDockInset provides pageDock(capsuleRoute, bottom),
        LocalIslandInset provides islandInset,
        LocalShell provides shell,
        LocalFrost provides frostSource,
        LocalBackdropPaused provides backdropPaused,
        LocalLanguageSwitcher provides switchLanguage,
        LocalLayoutDirection provides layoutDirection
    ) {
        Box(Modifier.fillMaxSize()) {
            val compactHome = nav.current == TAB_HOME && data?.settings?.homeLayout == HomeLayout.CARDS
            val day = rememberDayReveal(compactHome && !panelVisible && sheetPrayer == null)
            val backdropContrast = animateFloatAsState(if (compactHome) 0f else 1f, tween(220), label = "backdropContrast")
            com.nur.prayer.ui.wallpaper.WallpaperBackdrop(
                wallpaper, palette,
                motionEnabled = data?.settings?.ambientBackdrop == true,
                backdropContrast = { backdropContrast.value },
                daySoft = { if (compactHome) day.progress else 0f },
                dim = { maxOf(calendar.progress * deepLayer.value, pageDim) },
                lift = { paperLift },
                // The layer darkens every wallpaper, the live sky and black included, as it darkens a picture.
                shade = { maxOf(pageShade, calendar.progress * deepLayer.value) },
                blur = { maxOf(pageDim, calendar.progress * deepLayer.value) },
                soft = { calendar.progress * (1f - deepLayer.value) }
            )
            Box(Modifier.fillMaxSize().graphicsLayer {
                val f = languageFade.value
                alpha = 1f - f
                scaleX = 1f - 0.015f * f
                scaleY = 1f - 0.015f * f
            }) {
              if (homeOnScreen) Box(
                Modifier.fillMaxSize().graphicsLayer {
                    val p = calendar.progress
                    compositingStrategy = CompositingStrategy.ModulateAlpha
                    alpha = RevealMath.homeAlpha(p)
                    translationY = if (layerOrigin[0].isSpecified) 0f else -p * 40.dp.toPx()
                    scaleX = 1f - 0.04f * p
                    scaleY = 1f - 0.04f * p
                }
              ) {
                AnimatedContent(
                    targetState = rootTarget,
                    transitionSpec = spec@{
                        val menuPair = menuOrigin[0].isSpecified && (
                            (initialState == TAB_HOME && targetState in MENU_ROUTES) ||
                                (targetState == TAB_HOME && initialState in MENU_ROUTES))
                        if (menuPair) {
                            // 0.30.2: the page (MenuRevealBox) and home (HomeRevealBox) carry their own motion, both
                            // from layer transforms with per-draw-call alpha: nothing is added or faded here. These
                            // two only keep the outgoing side alive for as long as its own clock runs (an alpha of
                            // 1 → 1 draws nothing extra); the page is above on the way in, below on the way out.
                            return@spec if (targetState == TAB_HOME)
                                (fadeIn(tween(MenuRevealMotion.CLOSE_MILLIS), initialAlpha = 1f) togetherWith
                                    fadeOut(tween(MenuRevealMotion.CLOSE_MILLIS), targetAlpha = 1f))
                                    .apply { targetContentZIndex = -1f }.using(null)
                            else (fadeIn(tween(MenuRevealMotion.OPEN_MILLIS), initialAlpha = 1f) togetherWith
                                fadeOut(tween(MenuRevealMotion.OPEN_MILLIS), targetAlpha = 1f))
                                .apply { targetContentZIndex = 1f }.using(null)
                        }
                        if (targetState == ROUTE_CITY || initialState == ROUTE_CITY) {
                            // 0.34.0: «Город» is a page of glass on the wallpaper now, not an opaque one: a full-width push
                            // would show the page under it through the cards. A short hand-over instead: the old page is
                            // gone in 100 ms, the new one comes in right after it with a nudge of an eighth of the width.
                            val toCity = targetState == ROUTE_CITY
                            val cityIn = fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS, delayMillis = 50, easing = LinearOutSlowInEasing)) +
                                slideInHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS, easing = FastOutSlowInEasing)) { w -> if (toCity) w / 8 else -w / 8 }
                            val cityOut = fadeOut(tween(NavigationMotion.EXIT_MILLIS - 40, easing = FastOutLinearInEasing))
                            return@spec (cityIn togetherWith cityOut).apply { targetContentZIndex = if (toCity) 1f else -1f }.using(null)
                        }
                        val deeper = routeDepth(targetState) > routeDepth(initialState)
                        val shallower = routeDepth(targetState) < routeDepth(initialState)
                        val enter = when {
                            deeper -> slideInHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS, easing = FastOutSlowInEasing)) { it } +
                                fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS))
                            shallower -> fadeIn(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) +
                                slideInHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) { -it / 10 }
                            else -> fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS))
                        }
                        val exit = when {
                            shallower -> slideOutHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS, easing = FastOutLinearInEasing)) { it } +
                                fadeOut(tween(NavigationMotion.DETAIL_EXIT_MILLIS))
                            deeper -> fadeOut(tween(NavigationMotion.EXIT_MILLIS)) +
                                slideOutHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS)) { -it / 10 }
                            else -> fadeOut(tween(NavigationMotion.EXIT_MILLIS))
                        }
                        (enter togetherWith exit).apply { targetContentZIndex = if (shallower) -1f else 1f }.using(null)
                    }, label = "nurRoute", modifier = Modifier.fillMaxSize()
                ) { route ->
                    pages.SaveableStateProvider(route) {
                      // 0.30.2: a page keeps the insets of ITS OWN route. They used to follow `nav.current`, so the
                      // instant the route changed, the page that was still sliding out lost its island room and its
                      // dock room and jumped by 50 dp: the "main window twitches" on every close.
                      CompositionLocalProvider(
                          LocalDockInset provides pageDock(route, bottom),
                          LocalIslandInset provides pageIslandInset(route == capsuleRoute, islandInset)
                      ) {
                        // Windows with a local scrim inset their controls, never their painting area.
                        Box(Modifier.fillMaxSize().then(if (route == TAB_SCHEDULE) Modifier else Modifier.pageContentInsets())) {
                            if (data == null) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(tr("Считаем солнце…"), color = TextSecondary)
                                }
                            } else when (route) {
                                ROUTE_CITY -> CityPickerScreen(palette, data.settings.cityId, citySearch,
                                    onPick = { city -> onPickCity(city); nav.back() }, onBack = { nav.back() },
                                    onUseLocation = actions.requestLocation, locating = locating, locationStatus = locationStatus,
                                    currentPlace = data.place, locationButtonLabel = locationButtonLabel,
                                    onOpenLocationPermissions = actions.openLocationPermissions)
                                TAB_SETTINGS, TAB_QIBLA, TAB_SCHEDULE -> MenuRevealBox(
                                    active = {
                                        val other = if (rootPrevious[1] == route) rootPrevious[0] else rootPrevious[1]
                                        other == TAB_HOME
                                    },
                                    originInRoot = { menuOrigin[0] }
                                ) {
                                    if (route == TAB_SCHEDULE) ScheduleScreen(data, now, palette, lightBackdrop = paperPage,
                                        onModalChange = { calendarModal = it })
                                    else if (route == TAB_SETTINGS) SettingsScreen(withWallpaperChoice(data, wallpaperChoice), palette, actions, exactAlarmsAllowed, locating, locationStatus,
                                        notificationsAllowed = notificationsAllowed, locationButtonLabel = locationButtonLabel,
                                        onOpenWallpapers = { wallpapersOpen = true })
                                    else QiblaScreen(data, palette, onBack = { nav.back() })
                                }
                                else -> HomeRevealBox(
                                    active = {
                                        val other = if (rootPrevious[1] == route) rootPrevious[0] else rootPrevious[1]
                                        menuOrigin[0].isSpecified && other in MENU_ROUTES
                                    }
                                ) { HomeScreen(
                                    data = data, now = now, day = day, onSetNotification = actions.setNotification,
                                    onOpenCity = { nav.go(ROUTE_CITY) },
                                    onOpenSchedule = { menuOrigin[0] = Offset.Unspecified; nav.go(TAB_SCHEDULE) },
                                    onOpenPrayer = { prayer -> sheetName = prayer.name }
                                )
                                }
                            }
                        }
                      }
                    }
                }
              }
              if (data != null && scheduleOnScreen) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .onGloballyPositioned { layerTopLeft[0] = it.positionInRoot() }
                        .graphicsLayer {
                            compositingStrategy = CompositingStrategy.ModulateAlpha
                            val p = calendar.progress
                            val origin = layerOrigin[0]
                            if (origin.isSpecified && p < 1f) {
                                // Out of the sector it was chosen on, the same motion as Кыбла and Настройки.
                                val local = origin - layerTopLeft[0]
                                transformOrigin = TransformOrigin(
                                    (local.x / size.width).coerceIn(0f, 1f),
                                    (local.y / size.height).coerceIn(0f, 1f)
                                )
                                val s = MenuRevealMotion.FROM_SCALE + (1f - MenuRevealMotion.FROM_SCALE) * p
                                scaleX = s
                                scaleY = s
                                translationY = 0f
                                alpha = RevealGeometry.contentAlpha(p)
                                clip = true
                                shape = RoundedCornerShape(((1f - p) * MenuRevealMotion.CORNER_DP).dp)
                            } else {
                                transformOrigin = TransformOrigin.Center
                                scaleX = 1f
                                scaleY = 1f
                                translationY = if (origin.isSpecified) 0f else (1f - p) * size.height
                                alpha = if (origin.isSpecified) 1f else RevealMath.calendarAlpha(p)
                                clip = false
                                shape = RectangleShape
                            }
                        }
                ) {
                    AnimatedContent(
                        targetState = lastLayer[0],
                        transitionSpec = {
                            val deeper = layerDepth(targetState) > layerDepth(initialState)
                            // Every layer page fills the screen, so there is no size to animate; without a
                            // SizeTransform nothing clips a page or its window-sized scrim mid-transition.
                            // Stories open like a card lifting off the page, not as a sideways step.
                            (if (targetState == ROUTE_STORY) (fadeIn(tween(200)) + androidx.compose.animation.scaleIn(tween(260, easing = FastOutSlowInEasing), initialScale = 0.9f)) togetherWith
                                fadeOut(tween(200))
                            else if (initialState == ROUTE_STORY) fadeIn(tween(200)) togetherWith
                                (fadeOut(tween(200)) + androidx.compose.animation.scaleOut(tween(220), targetScale = 0.92f))
                            else if (deeper) LayerMotion.forward().apply { targetContentZIndex = 1f }
                            else LayerMotion.backward().apply { targetContentZIndex = -1f }).using(null)
                        }, label = "layerRoute", modifier = Modifier.fillMaxSize()
                    ) { route ->
                        pages.SaveableStateProvider(route) {
                          androidx.compose.runtime.CompositionLocalProvider(
                              com.nur.prayer.ui.learn.LocalArabicVoice provides arabicVoice,
                              LocalDockInset provides pageDock(route, bottom),
                              LocalIslandInset provides pageIslandInset(route == capsuleRoute, islandInset)
                          ) {
                            Box(Modifier.fillMaxSize().then(when (route) {
                                ROUTE_TODAY, ROUTE_STORY, ROUTE_QURAN, ROUTE_LESSON -> Modifier
                                else -> Modifier.pageContentInsets()
                            })) {
                                when (route) {
                                    ROUTE_COURSE -> CourseScreen(learn, learnContent?.course, learnProgress, palette,
                                        onOpenLesson = { nav.go(ROUTE_LESSON) },
                                        onOpenDictionary = { dictionaryFocus.value = null; nav.go(ROUTE_DICTIONARY) },
                                        // 0.40.0: the word of the day and the short surahs live here now, not in «Дела».
                                        onOpenWord = { id -> dictionaryFocus.value = id; nav.go(ROUTE_DICTIONARY) },
                                        onOpenSurahs = { nav.go(ROUTE_SURAH) })
                                    ROUTE_LESSON -> LessonScreen(learn, activeLesson, palette, current = nav.current == ROUTE_LESSON, onClose = { nav.back() })
                                    ROUTE_DICTIONARY -> DictionaryScreen(learnContent, learnProgress, palette, focus = dictionaryFocus.value)
                                    ROUTE_SURAH -> SurahScreen(learnContent, learnProgress, palette,
                                        onPractice = { n -> if (learn.enter(QuranShort.lessonId(n), force = true)) nav.go(ROUTE_LESSON) })
                                    ROUTE_NAMES -> com.nur.prayer.ui.names.NamesScreen(active = nav.current == ROUTE_NAMES)
                                    ROUTE_VIRD -> VirdPage(vird, dhikrToday) { id -> daily.openVird(id); nav.go(ROUTE_DHIKR) }
                                    ROUTE_AZKAR, ROUTE_AZKAR_EVENING -> {
                                        val set = if (route == ROUTE_AZKAR_EVENING) AzkarSet.EVENING else AzkarSet.MORNING
                                        // Quran items read the reader's own asset, so ayat look as they do in the Quran screen.
                                        val ayat by androidx.compose.runtime.produceState<Map<Int, List<com.nur.prayer.quran.QuranAyah>>?>(null) {
                                            val repo = com.nur.prayer.quran.QuranRepository.get(appContext)
                                            value = Azkar.QURAN_SURAHS.associateWith { n -> repo.surah(n) }
                                        }
                                        val list = remember(set, ayat) { ayat?.let { Azkar.of(set, it) } ?: emptyList() }
                                        AzkarScreen(daily, list, set, azkarSession(set, data.window))
                                    }
                                    ROUTE_DHIKR -> DhikrScreen(daily)
                                    ROUTE_QURAN -> com.nur.prayer.ui.quran.QuranScreen(
                                        quranNav, palette, onBack = { nav.back() },
                                        reviewed = quranReviewed, onReview = { s, a -> learn.addAyah(s, a) }
                                    )
                                    ROUTE_STORY -> StoryScreen(
                                        storySlides(learn.today(), learnContent), daily.storyStart, daily.storyOpening, DeedTone.GreenInk,
                                        onSeen = { i -> daily.markStorySeen(i) }, onClose = { nav.back() })
                                    ROUTE_TODAY -> {
                                        val counts = Azkar.size(AzkarSet.MORNING) to Azkar.size(AzkarSet.EVENING)
                                        val day = learn.today()
                                        val stories = remember(day, learnContent) { storySlides(day, learnContent).size }
                                        TodayScreen(TodayState(AzkarSet.at(data.window.current), counts.first, counts.second,
                                            Vird.doneCount(vird, dhikrToday), vird.size, totals[Dhikr.SALAWAT] ?: 0L, wallpaper.isImage), calendar,
                                            TodayActions(close = { nav.back() }, settings = { menuOrigin[0] = Offset.Unspecified; nav.go(TAB_SETTINGS) },
                                                names = { nav.go(ROUTE_NAMES) }, vird = { nav.go(ROUTE_VIRD) },
                                                azkar = { nav.go(if (it == AzkarSet.MORNING) ROUTE_AZKAR else ROUTE_AZKAR_EVENING) },
                                                salawat = { daily.openVird(Dhikr.SALAWAT); nav.go(ROUTE_DHIKR) },
                                                story = { daily.openStory(StoryMath.firstUnseen(storyMask, stories)); nav.go(ROUTE_STORY) }))
                                    }
                                    else -> Unit
                                }
                            }
                          }
                        }
                    }
                }
              }
            }
            // A light scrim under the system navigation bar: three-button navigation draws white
            // glyphs, and the horizon of a noon or sunset sky is light enough to swallow them.
            // Over the Quran's paper page the glyphs are dark, and the scrim is paper too.
            val paperBars = com.nur.prayer.ui.theme.SystemBarsTone.light
            // Names uses a continuous wallpaper directly down to its dock: no painted bottom strip.
            if (!compactHome && capsuleRoute != ROUTE_NAMES && !ShellRoutes.azkarReader(capsuleRoute)) Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .windowInsetsBottomHeight(WindowInsets.navigationBars)
                    .background(if (paperBars) NAV_SCRIM_PAPER else NAV_SCRIM_SKY)
            )
            // 0.34.0: the one way out of every page, bottom right, in the place the reference puts it. It asks the
            // system's back (see rememberSystemBack), so an editor inside a page closes before the page does, the
            // reader goes from a surah to the contents before it leaves the Quran. Under the capsule's panel and the
            // prayer sheet (they are drawn after it); the Quran hides it with the capsule while one reads.
            val ringBack = rememberSystemBack()
            val ringOn = data != null && nav.canGoBack && ringWanted(nav.current) && nav.current != TAB_SCHEDULE && sheetName == null && !wallpapersOpen && !shell.capsuleHidden
            val ringAlpha by animateFloatAsState(if (ringOn) 1f else 0f, tween(ExitButtonSpec.FADE_MILLIS), label = "exitRing")
            if (ringAlpha > 0.01f && !ShellRoutes.study(nav.current) && nav.current != TAB_SCHEDULE && !ShellRoutes.azkarReader(nav.current) &&
                !(nav.current == ROUTE_QURAN && panelVisible)) Box(
                Modifier.fillMaxSize().absolutePadding(left = sideLeft, right = sideRight).graphicsLayer {
                    alpha = ringAlpha * (1f - languageFade.value)
                }
            ) {
                ExitDock(onClose = { if (ringOn) ringBack() }, bottom = bottom,
                    modifier = Modifier.align(Alignment.BottomCenter),
                    onMenu = if (nav.current == ROUTE_QURAN && ringOn) ({ shell.show() }) else null,
                    tint = if (com.nur.prayer.ui.theme.SystemBarsTone.light) RING_INK else Color.White
                )
            }
            if (data != null) Box(Modifier.fillMaxSize().graphicsLayer {
                alpha = 1f - languageFade.value
            }) {
                ShellLayer(
                    shell = shell,
                    route = capsuleRoute,
                    onOpenSection = openSection,
                    onHome = goHome
                )
                Box(Modifier.fillMaxSize().pageContentInsets()) {
                    PrayerIslandHost(island, now, goHome, Modifier.align(Alignment.TopCenter))
                }
                PrayerSheetHost(
                    prayer = sheetPrayer, data = data, now = now, actions = actions,
                    notificationsAllowed = notificationsAllowed, exactAlarmsAllowed = exactAlarmsAllowed,
                    onDismiss = { sheetName = null },
                    onOpenSettings = { sheetName = null; menuOrigin[0] = Offset.Unspecified; nav.go(TAB_SETTINGS) }
                )
            }
            if (data != null) {
                val mock = remember(data.place.label, data.today.date, data.settings.hijriOffset, data.window) {
                    com.nur.prayer.ui.wallpaper.MockHome(
                        place = data.place.label,
                        date = com.nur.prayer.data.HijriCalendar.format(data.today.date, data.settings.hijriOffset),
                        time = Format.clock(data.window.remaining(now.value)),
                        next = "${tr("Следующий")} · ${com.nur.prayer.notify.PrayerLabels.title(data.window.next)} · ${Format.time(data.window.nextStart)}"
                    )
                }
                com.nur.prayer.ui.wallpaper.WallpaperGallery(
                    open = wallpapersOpen,
                    current = wallpaper,
                    palette = palette,
                    mock = mock,
                    onSet = { w -> actions.setWallpaper(w.id) },
                    onClose = { wallpapersOpen = false }
                )
            }
            crashReport.value?.let { report -> CrashReportSheet(report) { crashReport.value = null } }
        }
    }
}

/** [data] as the settings will be once the pending wallpaper [choice] is stored (same instance when none). */
private fun withWallpaperChoice(data: PrayerData, choice: String?): PrayerData {
    if (choice == null || data.settings.wallpaperId == choice) return data
    val s = data.settings
    return data.copy(settings = s.copy(
        wallpaperId = choice,
        recentWallpapers = com.nur.prayer.ui.wallpaper.WallpaperOrder.remember(choice, s.recentWallpapers),
        skyBackdrop = choice != com.nur.prayer.ui.wallpaper.WallpaperCatalog.AMOLED_ID
    ))
}

private val NAV_SCRIM_SKY = Brush.verticalGradient(listOf(Color.Transparent, Color(0x59000000)))
private val NAV_SCRIM_PAPER = Brush.verticalGradient(listOf(Color(0x00F3EAD3), Color(0xB3F3EAD3)))

/** Pages opened from a cell of the panel or the avatar: they grow out of it and sink back into it. */
internal val MENU_ROUTES = setOf(TAB_QIBLA, TAB_SETTINGS, TAB_SCHEDULE)

/**
 * Inside the pulled-up layer: «Дела» 0; what it opens (azkar, the counter, the reader) and the course 1; what the
 * course opens, the dictionary and the short surahs, 2; a lesson or a story 3. 0.40.0: the dictionary and the surahs
 * are reached from the course now, so they sit one level under it — «deeper» picks the slide-in direction.
 */
internal fun layerDepth(route: String): Int = when (route) {
    ROUTE_TODAY -> 0
    ROUTE_VIRD -> 1
    ROUTE_DHIKR, ROUTE_DICTIONARY, ROUTE_SURAH -> 2
    ROUTE_LESSON, ROUTE_STORY -> 3
    else -> 1
}

/** Home 0, the three sections 1, the city picker 2: deeper slides in from the right. */
internal fun routeDepth(route: String): Int = when (route) {
    TAB_HOME -> 0
    ROUTE_CITY -> 2
    else -> 1
}

/** The azkar session the counters belong to: the set and the day its prayer window began. */
internal fun azkarSession(set: AzkarSet, window: com.nur.prayer.core.astro.PrayerWindow): String {
    val day = if (AzkarSet.at(window.current) == set) window.currentStart.toLocalDate() else java.time.LocalDate.now()
    return AzkarSet.sessionKey(set, day)
}

/** Ayah, hadith and dua of the day, then the word of the day from the course lexicon. */
internal fun storySlides(today: Long, content: com.nur.prayer.learn.LearnContent?): List<StorySlide> {
    val base = DailyStories.of(today)
    val w = content?.lexicon?.wordOfDay(today) ?: return base
    return base + StorySlide(com.nur.prayer.ui.daily.WORD_KIND, w.arabic, w.translit, w.ru, tr("Словарь курса · ") + w.letters.joinToString(" · ") { it.name },
        voiced = w.machineVoiceAllowed)
}

private const val LANGUAGE_OUT_MILLIS = 150
private const val LANGUAGE_IN_MILLIS = 260

/**
 * 0.30.2: the room a page keeps under its content and under the island is a property of the page's own route,
 * not of where the shell is right now. A page that is leaving keeps what it had until it is gone.
 */
private fun pageDock(route: String, bottom: Dp): Dp =
    when {
        route == TAB_HOME -> bottom + CapsuleRoom
        ShellRoutes.capsuleOn(route) -> bottom + SectionBarRoom + if (ringWanted(route)) ExitButtonSpec.BarClearance else 0.dp
        ringWanted(route) -> ExitButtonSpec.contentFloor(bottom)
        else -> bottom + 28.dp
    }

/**
 * 0.34.0: the pages that get the exit ring. Home is the root; Qibla keeps the capsule's moon (its details button
 * stands where the ring would); a lesson and a story have their own bottom buttons and a ✕ wired to their own
 * confirmation.
 */
internal fun ringWanted(route: String): Boolean =
    route != TAB_HOME && route != TAB_QIBLA && !ShellRoutes.study(route) && route != ROUTE_STORY && !ShellRoutes.azkarReader(route)

/** The ring on the cream of the Quran and of the calendar over a light picture: dark brown ink. */
private val RING_INK = Color(0xFF2E2418)

/** Freeze the outgoing page at its previous height until its transition has finished. */
@Composable
private fun pageIslandInset(active: Boolean, current: Dp): Dp {
    val previous = remember { mutableStateOf(if (active) current else 0.dp) }
    if (active) androidx.compose.runtime.SideEffect { previous.value = current }
    return if (active) current else previous.value
}
