package com.nur.prayer.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyListState
import com.nur.prayer.i18n.L10n
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import java.time.ZonedDateTime

private val NextMatte = Color(0xFFF2F0EC)
private val DarkInk = Color(0xFF191A1D)

@Composable
internal fun InlineDaySchedule(data: PrayerData, now: State<ZonedDateTime>, prayers: List<Prayer>,
    list: LazyListState, onSetNotification: (Prayer, Boolean) -> Unit, onCollapse: () -> Unit,
    onDetails: (Prayer) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.widthIn(max = 480.dp).fillMaxWidth().testTag("home-day-list"), state = list,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item(key = "date") {
            val date = Format.fullDate(data.today.date).replaceFirstChar { it.titlecase(L10n.language.locale) }
            Box(Modifier.fillMaxWidth().clickable(role = Role.Button, onClickLabel = tr("Свернуть"), onClick = onCollapse)
                .heightIn(min = 48.dp).semantics { heading() }, contentAlignment = Alignment.Center) {
                AutoSizeText(date, Color.White.copy(alpha = 0.88f), 16.sp, maxLines = 1, fontWeight = FontWeight.Medium)
            }
        }
        items(prayers, key = { it.name }) { prayer ->
            DayScheduleRow(data, now, prayer, onSetNotification) { onDetails(prayer) }
        }
    }
}

@Composable
private fun DayScheduleRow(data: PrayerData, now: State<ZonedDateTime>, prayer: Prayer,
    onSetNotification: (Prayer, Boolean) -> Unit, onDetails: () -> Unit) {
    val state = HomeMath.dayRowState(prayer, data.window, data.today, data.fajrEqualsDawn)
    val checked = data.settings.notifications[prayer] == true
    val title = PrayerLabels.title(prayer)
    val time = data.today.times[prayer]?.let(Format::time) ?: "—"
    val ink = when (state) {
        RowState.NEXT -> DarkInk
        RowState.PAST -> Color.White.copy(alpha = 0.73f)
        else -> Color.White
    }
    val label = when (state) {
        RowState.CURRENT -> tr("Сейчас")
        RowState.NEXT -> tr("Далее")
        else -> null
    }
    val shape = RoundedCornerShape(14.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(if (state == RowState.NEXT) NextMatte else Color.Transparent)
        .padding(end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).clickable(role = Role.Button, onClickLabel = tr("Подробнее"), onClick = onDetails)
            .heightIn(min = 54.dp).padding(start = 12.dp, end = 8.dp, top = 4.dp, bottom = 4.dp)
            .semantics { if (label != null) stateDescription = label }, verticalArrangement = Arrangement.Center) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AutoSizeText(title, ink, 20.sp, Modifier.weight(1f), minFontSize = 14.sp,
                    fontWeight = if (state == RowState.NEXT) FontWeight.SemiBold else FontWeight.Medium)
                Spacer(Modifier.width(8.dp))
                Text(time, color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
            if (state == RowState.CURRENT) {
                val progress = rememberWindowProgress(now, data.window)
                Spacer(Modifier.padding(top = 4.dp).fillMaxWidth().height(2.dp).drawBehind {
                    drawRect(Color.White.copy(alpha = 0.18f))
                    drawRect(Color.White, size = Size(size.width * progress.value, size.height))
                })
            }
        }
        // Same per-event preference as PrayerSheet, including Sunrise. No shadow copy of the switch.
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(50)).toggleable(value = checked, role = Role.Switch,
            onValueChange = { onSetNotification(prayer, it) }).semantics {
                contentDescription = "${tr("Уведомление")} · $title"
            }, contentAlignment = Alignment.Center) {
            BellGlyph(HomeMath.bellState(checked, state), ink, ink,
                Modifier.size(HomeSpec.Compact.BELL_WIDTH.dp, HomeSpec.Compact.BELL_HEIGHT.dp))
        }
    }
}
