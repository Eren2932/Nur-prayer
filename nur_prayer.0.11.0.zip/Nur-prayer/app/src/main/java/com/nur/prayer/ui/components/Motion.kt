package com.nur.prayer.ui.components

import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit

/**
 * One motion language for the learning and daily screens: springs, not fixed durations, so a
 * touch that interrupts an animation picks it up from where it is instead of jumping. Springs
 * also ignore nothing: with Android's "remove animations" they settle at once, which is the
 * behaviour the user asked for.
 */
object NurMotion {
    /** Presses, toggles, small state changes: fast and without overshoot. */
    fun <T> snappy(): AnimationSpec<T> = spring(dampingRatio = 0.8f, stiffness = 900f)
    /** Things that "land": a star, a counter, a correct answer. A little overshoot. */
    fun <T> bouncy(): AnimationSpec<T> = spring(dampingRatio = 0.5f, stiffness = 520f)
    /** Large surfaces: sheets, story drag-back. */
    fun <T> gentle(): AnimationSpec<T> = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 420f)

    const val PRESS_SCALE = 0.95f
}

/**
 * A clickable that gives way under the finger and springs back: scale on press, ripple, light
 * haptic. The caller clips; this does not, so it composes with any shape.
 */
fun Modifier.pressClick(
    enabled: Boolean = true,
    scaleTo: Float = NurMotion.PRESS_SCALE,
    haptic: Boolean = true,
    role: Role = Role.Button,
    shape: Shape? = null,
    onClick: () -> Unit
): Modifier = composed {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed && enabled) scaleTo else 1f, NurMotion.snappy(), label = "pressClick")
    val feedback = LocalHapticFeedback.current
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .then(if (shape != null) Modifier.clip(shape) else Modifier)
        .clickable(interactionSource = interaction, indication = ripple(), enabled = enabled, role = role) {
            if (haptic) feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }
}

/**
 * Staggered entrance: the [order]-th block rises and fades in [order] × 45 ms after the screen
 * appears. Runs once per composition of the block; pure graphicsLayer, no relayout.
 */
fun Modifier.entrance(order: Int, distance: Float = 36f): Modifier = composed {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(durationMillis = 380, delayMillis = (order * 45).coerceAtMost(360)))
    }
    this.graphicsLayer {
        val p = progress.value
        alpha = p
        translationY = (1f - p) * distance * density
    }
}

/** A number that rolls up when it grows and down when it shrinks, instead of blinking. */
@Composable
fun RollingNumber(
    value: Long,
    color: Color,
    fontSize: TextUnit,
    modifier: Modifier = Modifier,
    fontWeight: FontWeight = FontWeight.Bold,
    prefix: String = "",
    suffix: String = ""
) {
    AnimatedContent(
        targetState = value,
        transitionSpec = {
            val up = targetState > initialState
            (slideInVertically(NurMotion.snappy()) { h -> if (up) h / 2 else -h / 2 } + fadeIn(tween(120))) togetherWith
                (slideOutVertically(NurMotion.snappy()) { h -> if (up) -h / 2 else h / 2 } + fadeOut(tween(90)))
        },
        label = "rollingNumber",
        modifier = modifier
    ) { v ->
        Text(prefix + v + suffix, color = color, fontSize = fontSize, fontWeight = fontWeight)
    }
}
