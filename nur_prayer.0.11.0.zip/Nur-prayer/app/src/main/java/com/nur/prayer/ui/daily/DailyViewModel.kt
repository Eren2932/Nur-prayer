package com.nur.prayer.ui.daily

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nur.prayer.daily.DailyStore
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.StoryMath
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

/**
 * Daily counters. Every tap updates memory first and writes in the background; the day rolls over
 * lazily on the first tap of a new day, so a counter left open overnight starts from zero.
 *
 * 0.11.0: all writes go through one queue drained by one coroutine. In 0.10.0 every tap launched
 * its own IO job; fast dhikr taps could land out of order and leave an older count on disk.
 */
class DailyViewModel(application: Application) : AndroidViewModel(application) {
    private val store = DailyStore(application)

    private val _dhikrToday = MutableStateFlow<Map<String, Long>>(emptyMap())
    val dhikrToday: StateFlow<Map<String, Long>> = _dhikrToday.asStateFlow()
    private val _dhikrTotal = MutableStateFlow<Map<String, Long>>(emptyMap())
    val dhikrTotal: StateFlow<Map<String, Long>> = _dhikrTotal.asStateFlow()
    private val _selected = MutableStateFlow(Dhikr.PRESETS.first().id)
    val selected: StateFlow<String> = _selected.asStateFlow()
    private val _azkar = MutableStateFlow<Map<String, Map<String, Long>>>(emptyMap())
    val azkar: StateFlow<Map<String, Map<String, Long>>> = _azkar.asStateFlow()
    /** Slides seen today, one bit per slide (see [StoryMath]). */
    private val _storyMask = MutableStateFlow(0)
    val storyMask: StateFlow<Int> = _storyMask.asStateFlow()
    private val _translit = MutableStateFlow(true)
    val translit: StateFlow<Boolean> = _translit.asStateFlow()

    /** Which slide the story viewer opens on. */
    var storyStart: Int = 0
        private set
    /** Bumped on every opening, so the viewer starts fresh instead of restoring the last slide. */
    var storyOpening: Int = 0
        private set

    private var dhikrDay = today()
    private var storyDay = today()

    private val writes = Channel<() -> Unit>(Channel.UNLIMITED)

    init {
        viewModelScope.launch(Dispatchers.IO) { for (w in writes) runCatching { w() } }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                // A tap made before the disk answered is kept on top of what was stored.
                val early = _dhikrToday.value
                val earlyTotal = _dhikrTotal.value
                _dhikrToday.value = merge(store.dhikrToday(dhikrDay), early)
                _dhikrTotal.value = merge(store.dhikrTotal(), earlyTotal)
                store.selectedDhikr()?.let { id -> if (Dhikr.PRESETS.any { it.id == id }) _selected.value = id }
                if (_azkar.value.isEmpty()) _azkar.value = store.azkar()
                _storyMask.value = _storyMask.value or store.storySeenMask(storyDay)
                _translit.value = store.showTranslit()
            }
        }
    }

    private fun merge(a: Map<String, Long>, b: Map<String, Long>): Map<String, Long> {
        if (b.isEmpty()) return a
        val out = LinkedHashMap(a)
        b.forEach { (k, v) -> out[k] = (out[k] ?: 0L) + v }
        return out
    }

    private fun write(block: () -> Unit) { writes.trySend(block) }

    fun today(): Long = LocalDate.now().toEpochDay()

    private fun rollDay() {
        val t = today()
        if (t != dhikrDay) { dhikrDay = t; _dhikrToday.value = emptyMap() }
        if (t != storyDay) { storyDay = t; _storyMask.value = 0 }
    }

    fun dhikrTap(id: String): Long {
        rollDay()
        val n = (_dhikrToday.value[id] ?: 0L) + 1
        _dhikrToday.value = _dhikrToday.value + (id to n)
        _dhikrTotal.value = _dhikrTotal.value + (id to ((_dhikrTotal.value[id] ?: 0L) + 1))
        saveDhikr()
        return n
    }

    /** Takes back the last tap (a slip of the finger). Today and the all-time total both lose one. */
    fun dhikrUndo(id: String): Long {
        rollDay()
        val cur = _dhikrToday.value[id] ?: 0L
        if (cur <= 0L) return 0L
        _dhikrToday.value = _dhikrToday.value + (id to (cur - 1))
        val tot = _dhikrTotal.value[id] ?: 0L
        if (tot > 0L) _dhikrTotal.value = _dhikrTotal.value + (id to (tot - 1))
        saveDhikr()
        return cur - 1
    }

    /** Resets today's count only; the all-time total keeps what was said. */
    fun dhikrReset(id: String) {
        rollDay()
        _dhikrToday.value = _dhikrToday.value - id
        saveDhikr()
    }

    fun select(id: String) {
        _selected.value = id
        write { store.saveSelectedDhikr(id) }
    }

    fun todayCount(id: String): Long {
        rollDay()
        return _dhikrToday.value[id] ?: 0L
    }

    private fun saveDhikr() {
        val day = dhikrDay
        val t = _dhikrToday.value
        val total = _dhikrTotal.value
        write { store.saveDhikr(day, t, total) }
    }

    /** One more repetition of azkar [id] in [session], capped at [max]. Returns the new count. */
    fun azkarTap(session: String, id: String, max: Int): Long {
        val cur = _azkar.value[session].orEmpty()
        val n = ((cur[id] ?: 0L) + 1).coerceAtMost(max.toLong())
        val next = LinkedHashMap(_azkar.value)
        next.remove(session)
        next[session] = cur + (id to n)
        _azkar.value = next
        write { store.saveAzkar(next) }
        return n
    }

    fun azkarReset(session: String) {
        val next = LinkedHashMap(_azkar.value)
        next.remove(session)
        _azkar.value = next
        write { store.saveAzkar(next) }
    }

    fun openStory(start: Int) {
        storyStart = start.coerceAtLeast(0)
        storyOpening++
    }

    fun markStorySeen(index: Int) {
        rollDay()
        val mask = StoryMath.withSeen(_storyMask.value, index)
        if (mask == _storyMask.value) return
        _storyMask.value = mask
        val day = storyDay
        write { store.saveStorySeen(day, mask) }
    }

    fun setTranslit(v: Boolean) {
        _translit.value = v
        write { store.saveShowTranslit(v) }
    }
}
