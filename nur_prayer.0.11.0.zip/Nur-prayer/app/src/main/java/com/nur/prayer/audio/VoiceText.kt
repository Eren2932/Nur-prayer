package com.nur.prayer.audio

import com.nur.prayer.learn.Arabic
import com.nur.prayer.learn.Letter

/**
 * What the voice is asked to say, kept pure so it is unit-tested. A letter is voiced as an open
 * syllable with fatha ("بَ" → "ба"): a synthesiser given a bare letter reads its name or nothing.
 * Alif carries no sound of its own, so its sound button says its name.
 */
object VoiceText {
    fun letterSound(letter: Letter): String =
        if (letter.char == "ا") letter.nameArabic else Arabic.syllable(letter, Arabic.VOWELS[0])

    fun letterName(letter: Letter): String = letter.nameArabic

    /** The lookup key of a phrase: trimmed, inner whitespace collapsed. Marks are kept: they change the reading. */
    fun key(text: String): String = text.trim().split(WHITESPACE).filter { it.isNotEmpty() }.joinToString(" ")

    /**
     * The recorded-clip index, `assets/audio/clips.tsv`: one `arabic<TAB>file` per line, `#`
     * comments and blank lines skipped. A recorded clip always wins over the synthesiser.
     */
    fun parseClips(tsv: String?): Map<String, String> {
        if (tsv.isNullOrBlank()) return emptyMap()
        val out = LinkedHashMap<String, String>()
        tsv.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) return@forEach
            val tab = line.indexOf('\t')
            if (tab <= 0) return@forEach
            val text = key(line.substring(0, tab))
            val file = line.substring(tab + 1).trim()
            if (text.isNotEmpty() && SAFE_FILE.matches(file)) out[text] = file
        }
        return out
    }

    /** Speech rate: learners hear words slower than a native speaker says them. */
    fun rate(slow: Boolean): Float = if (slow) 0.55f else 0.85f

    private val WHITESPACE = Regex("\\s+")
    /** Only plain names inside assets/audio: no paths, no traversal. */
    private val SAFE_FILE = Regex("[A-Za-z0-9_\\-]+\\.(ogg|mp3|m4a|wav)")
}
