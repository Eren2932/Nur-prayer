package com.nur.prayer.ui.learn

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.learn.Arabic
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.learn.LearnProgress
import com.nur.prayer.learn.Lexicon
import com.nur.prayer.learn.QuranShort
import com.nur.prayer.learn.Word
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.ScreenHeader
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/** The whole lexicon: search in three scripts, filter by topic, tap a word for its letters. */
@Composable
fun DictionaryScreen(content: LearnContent?, progress: LearnProgress, palette: PhasePalette, onBack: () -> Unit) {
    val ui = uiScale()
    val voice = rememberVoiceStatus()
    val accent = palette.accent
    var query by rememberSaveable { mutableStateOf("") }
    var topic by rememberSaveable { mutableStateOf<String?>(null) }
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Словарь", onBack, Modifier.padding(horizontal = ui.s(16f))) {
            content?.let { Tag("${it.lexicon.words.size}") }
        }
        if (content == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Загружаем словарь…", color = TextSecondary) }
            return
        }
        val lexicon = content.lexicon
        val results = remember(query, topic, lexicon) { lexicon.search(query, topic) }
        Box(
            Modifier.padding(horizontal = ui.s(16f)).fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(SurfaceRaised).padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            if (query.isEmpty()) Text("Слово по-русски, транслитом или по-арабски", color = TextTertiary, fontSize = ui.t(15f))
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = TextPrimary, fontSize = ui.t(16f)),
                cursorBrush = SolidColor(accent), modifier = Modifier.fillMaxWidth()
            )
        }
        Gap(10f)
        LazyRow(contentPadding = PaddingValues(horizontal = ui.s(16f)), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item { Chip("Все", topic == null, accent) { topic = null } }
            items(Lexicon.TOPICS, key = { it.id }) { t -> Chip(t.title, topic == t.id, accent) { topic = if (topic == t.id) null else t.id } }
        }
        Gap(10f)
        if (results.isEmpty()) {
            Text("Ничего не нашлось", color = TextSecondary, fontSize = ui.t(15f), textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 32.dp))
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(results, key = { it.id }) { w ->
                WordRow(w, progress, accent, open == w.id, voice) { open = if (open == w.id) null else w.id }
            }
        }
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, accent: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    val ui = uiScale()
    Text(
        text, color = if (selected) TextPrimary else TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (selected) accent.copy(alpha = 0.35f) else SurfaceRaised)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun WordRow(w: Word, progress: LearnProgress, accent: androidx.compose.ui.graphics.Color, expanded: Boolean, voice: com.nur.prayer.audio.ArabicVoice.Status, onClick: () -> Unit) {
    val ui = uiScale()
    val card = progress.cards[LearnProgress.wordKey(w)]
    GlassCard(Modifier.animateContentSize().clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick), corner = 20.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(w.ru, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
                Text(w.translit, color = TextTertiary, fontSize = ui.t(13f))
                when {
                    card == null -> {}
                    card.box >= LearnProgress.LEARNED_BOX -> Text("выучено", color = Mint, fontSize = ui.t(11f))
                    else -> Text("в повторении", color = accent, fontSize = ui.t(11f))
                }
            }
            ArabicText(w.arabic, if (w.isPhrase) 22f else 28f, align = TextAlign.End)
        }
        if (expanded) {
            Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 14.dp)) {
                if (voiceAllowed(w)) {
                    AutoSay(w.arabic, w.id, voice)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SpeakButton(w.arabic, voice, size = 38.dp, slow = false)
                        SpeakButton(w.arabic, voice, size = 38.dp, slow = true, label = "Медленно")
                        Text("обычно · медленно", color = TextTertiary, fontSize = ui.t(12f))
                    }
                    Gap(8f)
                }
                Text("По буквам, справа налево", color = TextTertiary, fontSize = ui.t(12f))
                Gap(6f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End)) {
                    w.letters.reversed().forEach { l ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            ArabicText(l.char, 24f)
                            Text(l.sound, color = TextSecondary, fontSize = ui.t(11f))
                        }
                    }
                }
                Gap(4f)
                Text("Без огласовок: ", color = TextTertiary, fontSize = ui.t(12f))
                ArabicText(Arabic.stripMarks(w.arabic), 24f, align = TextAlign.End, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

/** List of bundled surahs, or one surah ayah by ayah: Arabic, transliteration, meaning. */
@Composable
fun SurahScreen(content: LearnContent?, palette: PhasePalette, onBack: () -> Unit, onPractice: (Int) -> Unit) {
    val ui = uiScale()
    var surah by rememberSaveable { mutableStateOf(1) }
    var showTranslit by rememberSaveable { mutableStateOf(true) }
    val info = QuranShort.SURAHS.firstOrNull { it.number == surah } ?: QuranShort.SURAHS.first()
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Короткие суры", onBack, Modifier.padding(horizontal = ui.s(16f)))
        LazyRow(contentPadding = PaddingValues(horizontal = ui.s(16f)), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(QuranShort.SURAHS, key = { it.number }) { s -> Chip(s.nameRu, s.number == surah, palette.accent) { surah = s.number } }
        }
        Gap(8f)
        if (content == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Загружаем…", color = TextSecondary) }
            return
        }
        val ayat = content.quran.ayat(surah)
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                GlassCard {
                    Column(Modifier.fillMaxWidth().padding(ui.s(16f)), horizontalAlignment = Alignment.CenterHorizontally) {
                        ArabicText(info.nameArabic, 30f)
                        Text("${info.nameRu} · ${info.ayatCount} аятов", color = TextSecondary, fontSize = ui.t(14f))
                        if (surah != 1) {
                            Gap(10f)
                            ArabicText(QuranShort.BASMALA, 24f)
                            Text(QuranShort.BASMALA_TRANSLIT, color = TextTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center)
                        }
                        Gap(10f)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip(if (showTranslit) "Скрыть транслит" else "Показать транслит", false, palette.accent) { showTranslit = !showTranslit }
                            Chip("Проверить себя", true, palette.accent) { onPractice(surah) }
                        }
                    }
                }
            }
            items(ayat, key = { "${it.surah}:${it.number}" }) { a ->
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Text("${a.surah}:${a.number}", color = TextTertiary, fontSize = ui.t(12f))
                    ArabicText(a.arabic, 28f, align = TextAlign.End, modifier = Modifier.fillMaxWidth())
                    if (showTranslit) Text(a.translit, color = TextTertiary, fontSize = ui.t(14f), lineHeight = ui.t(19f))
                    Gap(4f)
                    Text(a.ru, color = TextPrimary, fontSize = ui.t(15f), lineHeight = ui.t(21f))
                }
            }
        }
    }
}
