package com.nur.prayer.ui.quran

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.QuranIndex
import com.nur.prayer.quran.QuranMark
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.quran.QuranRepository
import com.nur.prayer.quran.QuranStore
import com.nur.prayer.quran.SurahMeta
import com.nur.prayer.ui.components.EntranceClock
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.components.rememberEntranceClock
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.HGap
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/*
 * Table of contents, 0.17.0.
 *
 * Surahs, juz and bookmarks are three pages of one pager under a segmented control whose
 * indicator follows the finger, so "Суры ↔ Джузы" is a swipe as well as a tap. Typing in the
 * search replaces the pages with results (names in any script, numbers, "2:255"). Every list keeps
 * its scroll across a visit to the reader; coming back, the surah just read is brought into view.
 */
@Composable
internal fun QuranContents(
    store: QuranStore,
    colors: QuranColors,
    lastSurah: Int,
    query: String,
    onQuery: (String) -> Unit,
    tabs: PagerState,
    surahList: LazyListState,
    juzList: LazyListState,
    bookmarkList: LazyListState,
    onBack: () -> Unit,
    onOpen: (Int, Int) -> Unit
) {
    val ui = uiScale()
    val lang = L10n.language.code
    val clock = rememberEntranceClock()
    val searching = query.isNotBlank()

    // Back from the reader: the surah just read must be on screen, not 40 rows away. The list
    // state outlived the reader, so its first visible row is still the one the reader left.
    LaunchedEffect(Unit) {
        val row = (if (store.mark != null) 1 else 0) + lastSurah - 1
        val first = surahList.firstVisibleItemIndex
        if (row < first || row > first + VISIBLE_ROWS_GUESS) surahList.scrollToItem((row - 2).coerceAtLeast(0))
    }

    Column(Modifier.fillMaxSize()) {
        QuranTopBar(tr("Коран"), colors, onBack)
        SearchField(query, onQuery, colors)
        Gap(12f)
        AnimatedContent(
            targetState = searching,
            transitionSpec = {
                (fadeIn(tween(200)) + slideInVertically(tween(260)) { h: Int -> h / 24 }) togetherWith
                    (fadeOut(tween(140)) + slideOutVertically(tween(200)) { h: Int -> -h / 32 })
            },
            label = "quranSearch", modifier = Modifier.weight(1f).fillMaxWidth()
        ) { showResults ->
            if (showResults) SearchResults(query, lang, colors, store.mark?.surah, onOpen)
            else Column(Modifier.fillMaxSize()) {
                QuranTabs(tabs, listOf(tr("Суры"), tr("Джузы"), tr("Закладки")), colors)
                Gap(10f)
                HorizontalPager(state = tabs, key = { it }, modifier = Modifier.weight(1f).fillMaxWidth()) { page ->
                    when (page) {
                        0 -> SurahTab(store, colors, lang, surahList, clock, onOpen)
                        1 -> JuzTab(store, colors, lang, juzList, clock, onOpen)
                        else -> BookmarkTab(store, colors, lang, bookmarkList, onOpen)
                    }
                }
            }
        }
    }
}

// ── chrome ───────────────────────────────────────────────────────────────────────────────────────

@Composable
internal fun QuranTopBar(title: String, colors: QuranColors, onBack: () -> Unit) {
    val ui = uiScale()
    Row(
        Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = ui.s(16f), vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundIconButton(GlyphKind.BACK, tr("Назад"), onBack, tint = colors.text, background = colors.raised)
        HGap(14f)
        Text(title, color = colors.text, fontSize = ui.t(26f), fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun SearchField(query: String, onQuery: (String) -> Unit, colors: QuranColors) {
    val ui = uiScale()
    Row(
        Modifier.padding(horizontal = ui.s(16f)).fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(colors.raised).padding(start = 16.dp, end = 6.dp).heightIn(min = 52.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f).padding(vertical = 14.dp)) {
            if (query.isEmpty()) Text(tr("Сура, номер или 2:255"), color = colors.textTertiary, fontSize = ui.t(15f), maxLines = 1)
            BasicTextField(
                value = query, onValueChange = onQuery, singleLine = true,
                textStyle = TextStyle(color = colors.text, fontSize = ui.t(16f)),
                cursorBrush = SolidColor(colors.accent), modifier = Modifier.fillMaxWidth()
            )
        }
        if (query.isNotEmpty()) {
            RoundIconButton(GlyphKind.CLOSE, tr("Очистить"), { onQuery("") }, size = 40.dp,
                tint = colors.textSecondary, background = colors.inset)
        }
    }
}

/**
 * Segmented tabs bound to the pager: the plate under the labels sits at
 * (currentPage + currentPageOffsetFraction) × segment width, so it slides with the finger and
 * lands with the page. `offset` is layout-relative, which mirrors it for Arabic.
 */
@Composable
private fun QuranTabs(tabs: PagerState, labels: List<String>, colors: QuranColors) {
    val ui = uiScale()
    val scope = rememberCoroutineScope()
    BoxWithConstraints(
        Modifier.padding(horizontal = ui.s(16f)).fillMaxWidth().height(46.dp)
            .clip(RoundedCornerShape(50)).background(colors.inset).padding(4.dp)
    ) {
        val segment = maxWidth / labels.size
        Box(
            Modifier
                .offset { IntOffset(((tabs.currentPage + tabs.currentPageOffsetFraction) * segment.toPx()).roundToInt(), 0) }
                .width(segment).fillMaxHeight().clip(RoundedCornerShape(50)).background(colors.raised)
        )
        Row(Modifier.fillMaxSize()) {
            labels.forEachIndexed { i, label ->
                val tint by animateColorAsState(
                    if (tabs.targetPage == i) colors.text else colors.textTertiary, tween(200), label = "quranTab"
                )
                Box(
                    Modifier.weight(1f).fillMaxHeight()
                        .pressClick(scaleTo = 0.97f, shape = RoundedCornerShape(50)) { scope.launch { tabs.animateScrollToPage(i) } },
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, color = tint, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
    }
}

// ── surahs ───────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun SurahTab(
    store: QuranStore,
    colors: QuranColors,
    lang: String,
    list: LazyListState,
    clock: EntranceClock,
    onOpen: (Int, Int) -> Unit
) {
    val ui = uiScale()
    val mark = store.mark
    LazyColumn(
        Modifier.fillMaxSize(),
        state = list,
        contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (mark != null) {
            item(key = "continue") {
                ContinueCard(mark, lang, colors, Modifier.entrance(0, clock = clock)) { onOpen(mark.surah, mark.ayah) }
            }
        }
        items(QuranIndex.SURAHS, key = { it.number }) { s ->
            val current = mark?.surah == s.number
            SurahRow(
                s, lang, colors, current,
                progress = if (current && mark != null) mark.ayah.toFloat() / s.ayat else null,
                modifier = Modifier.entrance(s.number, clock = clock)
            ) { onOpen(s.number, 0) }
        }
    }
}

/**
 * «Продолжить чтение» with the numbers that matter: the place, how much of the surah and of the
 * whole Quran lies behind it. The bar is the surah; the percentage is the mushaf (6236 ayat).
 */
@Composable
private fun ContinueCard(mark: QuranMark, lang: String, colors: QuranColors, modifier: Modifier, onClick: () -> Unit) {
    val ui = uiScale()
    val s = QuranMath.surah(mark.surah)
    val inSurah = mark.ayah.toFloat() / s.ayat
    val whole = QuranMath.quranProgress(mark.surah, mark.ayah)
    val percent = if (whole < 0.01f) "<1" else (whole * 100f).toInt().toString()
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(colors.card)
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(24.dp), onClick = onClick)
            .padding(ui.s(16f))
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("Продолжить чтение"), color = colors.accent.liftedForText(), fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
                Gap(2f)
                Text(tr("{0} · аят {1}", QuranMath.title(s, lang), mark.ayah), color = colors.text, fontSize = ui.t(18f),
                    fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (lang != "ar") ArabicText(s.arabic, 24f, color = colors.text, align = TextAlign.End)
        }
        Gap(12f)
        val track = colors.hairline
        val fill = colors.accent
        Box(
            Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(50)).drawBehind {
                drawRect(track)
                val w = size.width * inSurah.coerceIn(0f, 1f)
                drawRect(fill, topLeft = Offset(if (rtl) size.width - w else 0f, 0f), size = Size(w, size.height))
            }
        )
        Gap(8f)
        Text(
            tr("джуз {0}", QuranMath.juzOf(mark.surah, mark.ayah)) + " · " + tr("аят {0} из {1}", mark.ayah, s.ayat) +
                " · " + tr("{0}% Корана", percent),
            color = colors.textTertiary, fontSize = ui.t(12f)
        )
    }
}

@Composable
private fun SurahRow(
    s: SurahMeta,
    lang: String,
    colors: QuranColors,
    current: Boolean,
    progress: Float?,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val ui = uiScale()
    val meaning = QuranMath.meaning(s, lang)
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(colors.card)
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(20.dp), onClick = onClick)
            .padding(horizontal = ui.s(12f), vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NumberBadge(s.number, colors, highlighted = current, progress = progress)
        HGap(12f)
        Column(Modifier.weight(1f)) {
            Text(QuranMath.title(s, lang), color = colors.text, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            val place = if (s.medinan) tr("Мединская") else tr("Мекканская")
            Text(
                (if (meaning.isNotEmpty()) "$meaning · " else "") + place + " · " + tr("аятов: {0}", s.ayat),
                color = colors.textTertiary, fontSize = ui.t(13f), lineHeight = ui.t(18f)
            )
        }
        HGap(8f)
        if (lang != "ar") ArabicText(s.arabic, 22f, color = colors.text, align = TextAlign.End)
    }
}

// ── juz ──────────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun JuzTab(
    store: QuranStore,
    colors: QuranColors,
    lang: String,
    list: LazyListState,
    clock: EntranceClock,
    onOpen: (Int, Int) -> Unit
) {
    val ui = uiScale()
    val mark = store.mark
    val currentJuz = mark?.let { QuranMath.juzOf(it.surah, it.ayah) }
    LazyColumn(
        Modifier.fillMaxSize(),
        state = list,
        contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(QuranIndex.JUZ.size, key = { "juz$it" }) { i ->
            val juz = i + 1
            val current = juz == currentJuz
            JuzRow(
                juz, lang, colors, current,
                progress = if (current && mark != null) QuranMath.juzProgress(mark.surah, mark.ayah) else null,
                modifier = Modifier.entrance(i, clock = clock),
                onOpen = onOpen
            )
        }
    }
}

/** A juz names where it starts and ends — «Аль-Бакара 2:142 — Аль-Бакара 2:252» — and its size. */
@Composable
private fun JuzRow(
    juz: Int,
    lang: String,
    colors: QuranColors,
    current: Boolean,
    progress: Float?,
    modifier: Modifier,
    onOpen: (Int, Int) -> Unit
) {
    val ui = uiScale()
    val start = QuranMath.juzStart(juz)
    val end = QuranMath.juzEnd(juz)
    val from = QuranMath.surah(start.surah)
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(colors.card)
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(20.dp)) { onOpen(start.surah, start.ayah) }
            .padding(horizontal = ui.s(12f), vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NumberBadge(juz, colors, highlighted = current, progress = progress)
        HGap(12f)
        Column(Modifier.weight(1f)) {
            Text(tr("Джуз {0}", juz), color = colors.text, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
            Text(
                "${QuranMath.title(from, lang)} ${start.surah}:${start.ayah} — ${end.surah}:${end.ayah}",
                color = colors.textSecondary, fontSize = ui.t(13f), maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(tr("аятов: {0}", QuranMath.juzAyat(juz)), color = colors.textTertiary, fontSize = ui.t(12f))
        }
        if (lang != "ar") ArabicText(from.arabic, 20f, color = colors.textSecondary, align = TextAlign.End)
    }
}

// ── bookmarks ────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun BookmarkTab(
    store: QuranStore,
    colors: QuranColors,
    lang: String,
    list: LazyListState,
    onOpen: (Int, Int) -> Unit
) {
    val ui = uiScale()
    val marks = store.bookmarks
    if (marks.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = ui.s(32f)).padding(top = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("۞", color = colors.accent, fontSize = ui.t(40f))
            Gap(12f)
            Text(tr("Закладок пока нет"), color = colors.text, fontSize = ui.t(17f), fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center)
            Gap(6f)
            Text(
                tr("Удерживайте аят во время чтения и нажмите «В закладки» — он появится здесь."),
                color = colors.textTertiary, fontSize = ui.t(14f), lineHeight = ui.t(20f), textAlign = TextAlign.Center
            )
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        state = list,
        contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(marks, key = { it }) { key ->
            BookmarkRow(key, store, lang, colors, Modifier.animateItem(), onOpen)
        }
    }
}

@Composable
private fun BookmarkRow(key: Int, store: QuranStore, lang: String, colors: QuranColors, modifier: Modifier, onOpen: (Int, Int) -> Unit) {
    val ui = uiScale()
    val context = LocalContext.current
    val repo = remember { QuranRepository.get(context) }
    val surah = key / 1000
    val ayah = key % 1000
    val s = QuranMath.surah(surah)
    val translation = store.translation(lang)
    val preview by produceState<String?>(null, key, translation) {
        val a = runCatching { repo.surah(surah) }.getOrNull()?.getOrNull(ayah - 1)
        value = a?.let { it.translation(translation) ?: it.arabic }
    }
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(colors.card)
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(20.dp)) { onOpen(surah, ayah) }
            .padding(start = ui.s(12f), end = 6.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NumberBadge(surah, colors)
        HGap(12f)
        Column(Modifier.weight(1f)) {
            Text("${QuranMath.title(s, lang)} · $surah:$ayah", color = colors.text, fontSize = ui.t(16f),
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(preview.orEmpty(), color = colors.textTertiary, fontSize = ui.t(13f), lineHeight = ui.t(18f),
                maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        RoundIconButton(GlyphKind.CLOSE, tr("Убрать из закладок"), { store.toggleBookmark(key) }, size = 40.dp,
            tint = colors.textTertiary, background = colors.card)
    }
}

// ── search ───────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun SearchResults(query: String, lang: String, colors: QuranColors, markSurah: Int?, onOpen: (Int, Int) -> Unit) {
    val ui = uiScale()
    val results = remember(query) { QuranMath.search(query) }
    val reference = remember(query) { QuranMath.parseReference(query) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (reference != null) {
            item(key = "ref") {
                val s = QuranMath.surah(reference.surah)
                Row(
                    Modifier.animateItem().fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(colors.accent.copy(alpha = 0.16f))
                        .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(20.dp)) { onOpen(reference.surah, reference.ayah) }
                        .padding(ui.s(16f)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("Открыть аят {0}:{1}", reference.surah, reference.ayah), color = colors.text,
                            fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
                        Text(QuranMath.title(s, lang), color = colors.textTertiary, fontSize = ui.t(13f))
                    }
                    MushafChevron(colors.text, pointsLeft = true, modifier = Modifier.size(18.dp))
                }
            }
        }
        if (results.isEmpty() && reference == null) item(key = "empty") {
            Text(tr("Ничего не нашлось"), color = colors.textSecondary, fontSize = ui.t(15f), textAlign = TextAlign.Center,
                modifier = Modifier.animateItem().fillMaxWidth().padding(top = 32.dp))
        }
        items(results, key = { it.number }) { s ->
            SurahRow(s, lang, colors, markSurah == s.number, progress = null, modifier = Modifier.animateItem()) { onOpen(s.number, 0) }
        }
    }
}

/** Rows that surely fit on a phone screen; a surah inside this window counts as visible. */
private const val VISIBLE_ROWS_GUESS = 5
