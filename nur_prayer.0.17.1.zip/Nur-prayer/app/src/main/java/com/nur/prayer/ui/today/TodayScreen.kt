package com.nur.prayer.ui.today

import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.QuranMark
import com.nur.prayer.quran.QuranMath

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import com.nur.prayer.daily.StoryMath
import androidx.compose.runtime.getValue
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.components.RollingText

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.learn.LearnProgress
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.daily.Ring
import com.nur.prayer.ui.daily.azkarBrush
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.HGap
import com.nur.prayer.ui.learn.LessonBar
import com.nur.prayer.ui.learn.Tag
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/** What the today layer shows; computed by the root from the view models. */
data class TodayState(
    val hijri: String,
    val today: Long,
    val content: LearnContent?,
    val progress: LearnProgress,
    val azkarSet: AzkarSet,
    val azkarDone: Int,
    val azkarTotal: Int,
    val salawatToday: Long,
    val salawatTotal: Long,
    val salawatTarget: Int,
    val dhikrToday: Long,
    /** Story slides seen today, one bit each (StoryMath). */
    val storyMask: Int,
    /** Where the Quran reader stopped; null before the first reading. */
    val quranMark: QuranMark? = null
)

/** Everything the today layer can open. */
class TodayActions(
    val close: () -> Unit,
    val story: (Int) -> Unit,
    /** The reader, on the bookmark (al-Fatiha the first time). */
    val quran: () -> Unit,
    /** The table of contents of the whole Quran. */
    val quranContents: () -> Unit,
    val azkar: () -> Unit,
    val salawat: () -> Unit,
    val dhikr: () -> Unit,
    val continueLesson: () -> Unit,
    val course: () -> Unit,
    val review: () -> Unit,
    val dictionary: () -> Unit,
    val surahs: () -> Unit,
    val schedule: () -> Unit
)

/**
 * The layer pulled up from home, in four blocks read top to bottom: the story of the day, the
 * tasks of the day (as a 2×2 grid — Quran, azkar, salawat, dhikr), learning, and the rest. It
 * shares one [Reveal] with home: a drag down on its header drives the same number back.
 */
@Composable
fun TodayScreen(state: TodayState, palette: PhasePalette, reveal: Reveal, on: TodayActions) {
    val ui = uiScale()
    val accent = palette.accent
    val pullDown = rememberDraggableState { delta -> reveal.drag(-delta) }
    Column(Modifier.fillMaxSize().onSizeChanged { reveal.extentPx = it.height.toFloat() }) {
        Column(
            Modifier.fillMaxWidth().draggable(
                state = pullDown,
                orientation = Orientation.Vertical,
                onDragStarted = { reveal.grab() },
                onDragStopped = { v -> if (reveal.release(-v, RevealMath.SHEET_KEEP_AT)) reveal.settle(true) else on.close() }
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.padding(top = 8.dp).width(40.dp).height(5.dp).clip(RoundedCornerShape(50)).background(SurfaceEdge))
            Row(Modifier.fillMaxWidth().padding(horizontal = ui.s(16f), vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("Сегодня"), color = TextPrimary, fontSize = ui.t(28f), fontWeight = FontWeight.Bold)
                    Text(state.hijri, color = TextSecondary, fontSize = ui.t(13f))
                }
                RoundIconButton(GlyphKind.CLOSE, tr("Закрыть"), on.close)
            }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = ui.s(16f)).padding(bottom = LocalDockInset.current + 16.dp)
        ) {
            StoriesRow(state.storyMask, accent, on.story, Modifier.entrance(0))

            Section(tr("Дела дня"), Modifier.entrance(1))
            Row(Modifier.fillMaxWidth().entrance(2), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val mark = state.quranMark
                val lang = L10n.language.code
                TaskTile(tr("Коран"),
                    if (mark == null) tr("Аль-Фатиха и все 114 сур")
                    else tr("{0} · аят {1}", QuranMath.title(QuranMath.surah(mark.surah), lang), mark.ayah),
                    Modifier.weight(1f), onClick = on.quran) {
                    ArabicText(if (mark == null) "الفاتحة" else QuranMath.surah(mark.surah).arabic, 26f, align = TextAlign.Start)
                }
                val azkarFull = state.azkarTotal > 0 && state.azkarDone >= state.azkarTotal
                TaskTile(state.azkarSet.title, if (azkarFull) tr("прочитаны ✓") else "${state.azkarDone} / ${state.azkarTotal}",
                    Modifier.weight(1f), brush = azkarBrush(state.azkarSet), onClick = on.azkar) {
                    Ring(if (state.azkarTotal == 0) 0f else state.azkarDone / state.azkarTotal.toFloat(), Color.White, 46.dp, 5.dp)
                }
            }
            Gap(10f)
            Row(Modifier.fillMaxWidth().entrance(3), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val inRound = (state.salawatToday % state.salawatTarget).toInt()
                val full = state.salawatToday > 0 && inRound == 0
                TaskTile(tr("Салават"), "${if (full) state.salawatTarget else inRound} / ${state.salawatTarget} (${state.salawatTotal})",
                    Modifier.weight(1f), onClick = on.salawat) {
                    Ring(if (full) 1f else inRound / state.salawatTarget.toFloat(), if (full) Mint else TextPrimary, 46.dp, 5.dp)
                }
                TaskTile(tr("Зикр"), if (state.dhikrToday > 0) tr("сегодня {0}", state.dhikrToday) else tr("тасбих, истигфар…"),
                    Modifier.weight(1f), onClick = on.dhikr) {
                    ArabicText("ذِكْر", 26f, align = TextAlign.Start)
                }
            }

            Section(tr("Обучение"), Modifier.entrance(4))
            Box(Modifier.entrance(5)) { LearnCard(state, accent, on.continueLesson, on.course) }
            Gap(10f)
            Row(Modifier.fillMaxWidth().entrance(6), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                state.content?.let { c ->
                    val w = c.lexicon.wordOfDay(state.today)
                    TaskTile(tr("Слово дня"), "${w.ru} · ${w.translit}", Modifier.weight(1f), onClick = on.dictionary) {
                        ArabicText(w.arabic, 26f, align = TextAlign.Start)
                    }
                } ?: Spacer(Modifier.weight(1f))
                val due = state.progress.due(state.today).size
                TaskTile(tr("Повторение"), if (due > 0) tr("{0} карточек ждут", due) else tr("на сегодня всё"), Modifier.weight(1f), onClick = on.review) {
                    Text(if (due > 0) "$due" else "✓", color = if (due > 0) TextPrimary else Mint, fontSize = ui.t(30f), fontWeight = FontWeight.Bold)
                }
            }

            Section(tr("Ещё"), Modifier.entrance(7))
            GlassCard(Modifier.entrance(8)) {
                RowLink(tr("Коран"), tr("114 сур с переводом, поиск по суре и аяту"), on.quranContents)
                RowLink(tr("Короткие суры"), tr("заучивание и проверка себя"), on.surahs)
                RowLink(tr("Словарь"), tr("{0} слов и фраз, поиск", state.content?.lexicon?.words?.size ?: 0), on.dictionary)
                RowLink(tr("Календарь намазов"), tr("месяц, время, хиджра"), on.schedule)
            }
        }
    }
}

@Composable
private fun Section(title: String, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Text(title, color = TextPrimary, fontSize = ui.t(20f), fontWeight = FontWeight.Bold,
        modifier = modifier.padding(start = 4.dp, top = 22.dp, bottom = 10.dp))
}

private val STORY_LABELS = listOf("Аят", "Хадис", "Дуа", "Слово")
private val STORY_GLYPHS = listOf("ﷻ", "ﷺ", "دعاء", "ك")

@Composable
private fun StoriesRow(mask: Int, accent: Color, onOpen: (Int) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val count = STORY_LABELS.size
    val all = StoryMath.allSeen(mask, count)
    Column(modifier) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 6.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("История дня"), color = TextPrimary, fontSize = ui.t(20f), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            // One tap to watch from the first slide not yet seen, like the "play" of a story tray.
            Text(if (all) tr("смотреть снова") else tr("смотреть"), color = if (all) TextTertiary else accent, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold,
                modifier = Modifier.pressClick(shape = RoundedCornerShape(50)) { onOpen(StoryMath.firstUnseen(mask, count)) }
                    .padding(horizontal = 10.dp, vertical = 6.dp))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            STORY_LABELS.forEachIndexed { i, label ->
                val seen = StoryMath.isSeen(mask, i)
                val ringAlpha by animateFloatAsState(if (seen) 0f else 1f, tween(400), label = "storyRing")
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.pressClick(shape = RoundedCornerShape(16.dp)) { onOpen(i) }.padding(4.dp)) {
                    Box(Modifier.size(68.dp), contentAlignment = Alignment.Center) {
                        Box(Modifier.matchParentSize().clip(CircleShape).border(3.dp, SurfaceEdge, CircleShape))
                        Box(Modifier.matchParentSize().graphicsLayer { alpha = ringAlpha }.clip(CircleShape)
                            .border(3.dp, Brush.linearGradient(listOf(Color(0xFFF2C077), accent, Color(0xFFD0453F))), CircleShape))
                        Box(Modifier.matchParentSize().padding(6.dp).clip(CircleShape).background(SurfaceInset), contentAlignment = Alignment.Center) {
                            ArabicText(STORY_GLYPHS[i], if (STORY_GLYPHS[i].length > 2) 16f else 24f)
                        }
                    }
                    Gap(4f)
                    Text(tr(label), color = if (seen) TextTertiary else TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** A square-ish tile of the 2×2 grid: an icon area on top, title and status below. */
@Composable
private fun TaskTile(
    title: String,
    subtitle: String,
    modifier: Modifier,
    brush: Brush? = null,
    onClick: () -> Unit,
    icon: @Composable () -> Unit
) {
    val ui = uiScale()
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.heightIn(min = 150.dp).pressClick(shape = shape, onClick = onClick)
            .then(if (brush != null) Modifier.background(brush) else Modifier.background(SurfaceInset))
            .padding(ui.s(16f)),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(Modifier.height(52.dp), contentAlignment = Alignment.CenterStart) { icon() }
        Column {
            Text(title, color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            // Salawat and dhikr counts change while you watch (back from the counter): roll, not blink.
            RollingText(subtitle, if (brush != null) Color(0xDDFFFFFF) else TextTertiary, ui.t(13f))
        }
    }
}

@Composable
private fun LearnCard(state: TodayState, accent: Color, onContinue: () -> Unit, onCourse: () -> Unit) {
    val ui = uiScale()
    GlassCard(color = accent.copy(alpha = 0.22f)) {
        Column(Modifier.padding(ui.s(18f))) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("АРАБСКИЙ ЯЗЫК"), color = TextPrimary, fontSize = ui.t(12f), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Tag("🔥 ${state.progress.streakOn(state.today)}")
            }
            Gap(8f)
            val course = state.content?.course
            if (course == null) {
                Text(tr("Готовим уроки…"), color = TextSecondary, fontSize = ui.t(14f))
                return@Column
            }
            val next = course.next(state.progress)
            val done = course.completedCount(state.progress)
            Text(next?.title ?: tr("Курс пройден"), color = TextPrimary, fontSize = ui.t(22f), fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(next?.let { course.stages[course.stageIndex(it.id)].title + " · " + it.subtitle } ?: tr("повторяйте карточки"),
                color = TextSecondary, fontSize = ui.t(14f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Gap(10f)
            LessonBar(done.toFloat() / course.lessons.size.coerceAtLeast(1), accent)
            Gap(4f)
            Text(tr("{0} из {1} уроков · {2} слов · {3} из 28 букв", done, course.lessons.size, state.progress.learnedWords(), state.progress.learnedLetters()),
                color = TextTertiary, fontSize = ui.t(12f))
            Gap(12f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (next != null) NurButton(if (done == 0) tr("Начать") else tr("Продолжить"), accent, onContinue, Modifier.weight(1f), primary = true)
                NurButton(tr("Весь курс"), accent, onCourse, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun RowLink(title: String, subtitle: String, onClick: () -> Unit) {
    val ui = uiScale()
    Row(
        Modifier.fillMaxWidth().pressClick(scaleTo = 0.98f, onClick = onClick).padding(horizontal = ui.s(16f), vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = TextTertiary, fontSize = ui.t(13f))
        }
        HGap(8f)
        Text("›", color = TextTertiary, fontSize = ui.t(22f))
    }
}
