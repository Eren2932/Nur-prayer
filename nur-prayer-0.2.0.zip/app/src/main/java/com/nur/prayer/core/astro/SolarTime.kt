package com.nur.prayer.core.astro

import java.time.LocalDate
import kotlin.math.abs
import kotlin.math.atan

/** Geographic coordinates in decimal degrees. */
data class Coordinates(val latitude: Double, val longitude: Double)

/** Apparent solar coordinates for a given Julian Day. */
internal class SolarCoordinates(julianDay: Double) {
    /** Apparent declination of the Sun, degrees. */
    val declination: Double

    /** Apparent right ascension of the Sun, degrees. */
    val rightAscension: Double

    /** Apparent sidereal time at Greenwich, degrees. */
    val apparentSiderealTime: Double

    init {
        val t = julianCentury(julianDay)
        val l0 = meanSolarLongitude(t)
        val lp = meanLunarLongitude(t)
        val omega = ascendingLunarNodeLongitude(t)
        val lambda = apparentSolarLongitude(t, l0)
        val theta0 = meanSiderealTime(t)
        val dPsi = nutationInLongitude(l0, lp, omega)
        val dEpsilon = nutationInObliquity(l0, lp, omega)
        val epsilon0 = meanObliquityOfTheEcliptic(t)
        val epsilonApparent = apparentObliquityOfTheEcliptic(t, epsilon0)

        declination = dasin(epsilonApparent.dsin() * lambda.dsin())
        rightAscension = unwindAngle(datan2(epsilonApparent.dcos() * lambda.dsin(), lambda.dcos()))
        apparentSiderealTime = theta0 + (dPsi * 3600 * (epsilon0 + dEpsilon).dcos()) / 3600
    }
}

/**
 * Solar events for one calendar day at a given location.
 * All values are hours of UTC counted from 00:00 UTC of [date]; [Double.NaN] when the event
 * does not happen (polar day / polar night).
 */
internal class SolarTime(date: LocalDate, private val coordinates: Coordinates) {

    private val previous: SolarCoordinates
    private val solar: SolarCoordinates
    private val next: SolarCoordinates
    private val approximateTransit: Double

    /** Solar noon. */
    val transit: Double
    val sunrise: Double
    val sunset: Double

    init {
        val jd = julianDay(date.year, date.monthValue, date.dayOfMonth)
        previous = SolarCoordinates(jd - 1)
        solar = SolarCoordinates(jd)
        next = SolarCoordinates(jd + 1)
        approximateTransit = approximateTransit(
            coordinates.longitude, solar.apparentSiderealTime, solar.rightAscension
        )
        // Standard refraction + solar disc correction for sunrise/sunset.
        val solarAltitude = -50.0 / 60.0

        transit = correctedTransit(
            approximateTransit, coordinates.longitude, solar.apparentSiderealTime,
            solar.rightAscension, previous.rightAscension, next.rightAscension
        )
        sunrise = hourAngle(solarAltitude, afterTransit = false)
        sunset = hourAngle(solarAltitude, afterTransit = true)
    }

    fun hourAngle(angle: Double, afterTransit: Boolean): Double = correctedHourAngle(
        approximateTransit, angle, coordinates.latitude, coordinates.longitude, afterTransit,
        solar.apparentSiderealTime, solar.rightAscension, previous.rightAscension, next.rightAscension,
        solar.declination, previous.declination, next.declination
    )

    /**
     * Time when the shadow of an object reaches [shadowLength] times its own height
     * (1x = Shafi'i/Maliki/Hanbali Asr, 2x = Hanafi Asr).
     */
    fun afternoon(shadowLength: Double): Double {
        val tangent = abs(coordinates.latitude - solar.declination)
        val inverse = shadowLength + tangent.dtan()
        val angle = Math.toDegrees(atan(1.0 / inverse))
        return hourAngle(angle, afterTransit = true)
    }
}
