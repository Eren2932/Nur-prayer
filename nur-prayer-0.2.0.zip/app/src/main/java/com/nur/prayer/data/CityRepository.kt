package com.nur.prayer.data

import android.content.Context
import com.nur.prayer.core.astro.Coordinates
import org.json.JSONArray
import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.cos

/**
 * Offline city database, loaded once from assets. No network, no API keys, works in the metro.
 */
class CityRepository(private val context: Context) {

    private val all: List<City> by lazy { load() }

    private fun load(): List<City> {
        val json = context.assets.open("cities_ru.json").bufferedReader().use { it.readText() }
        val array = JSONArray(json)
        val result = ArrayList<City>(array.length())
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            result.add(
                City(
                    id = o.getInt("id"),
                    name = o.getString("name"),
                    region = o.getString("region"),
                    latitude = o.getDouble("lat"),
                    longitude = o.getDouble("lon"),
                    timeZoneId = o.getString("tz")
                )
            )
        }
        return result
    }

    fun cities(): List<City> = all

    fun byId(id: Int): City? = all.firstOrNull { it.id == id }

    fun search(query: String, limit: Int = 60): List<City> {
        val q = fold(query)
        if (q.isBlank()) return all.take(limit)
        return all.asSequence()
            .map { city -> city to score(city, q) }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<City, Int>> { it.second }.thenBy { it.first.id })
            .map { it.first }
            .take(limit)
            .toList()
    }

    private fun score(city: City, q: String): Int {
        val name = fold(city.name)
        val region = fold(city.region)
        return when {
            name == q -> 100
            name.startsWith(q) -> 80
            name.contains(q) -> 60
            region.startsWith(q) -> 40
            region.contains(q) -> 20
            else -> 0
        }
    }

    /** Case/diacritic insensitive, treats "ё" as "е" so that "елец"/"ёлец" both match. */
    private fun fold(value: String): String =
        Normalizer.normalize(value.trim().lowercase(), Normalizer.Form.NFC)
            .replace('ё', 'е')
            .replace('-', ' ')

    /** Nearest known city to a GPS fix, used to resolve the time zone of a raw location. */
    fun nearest(coordinates: Coordinates): City = all.minByOrNull { city ->
        val dLat = abs(city.latitude - coordinates.latitude)
        val dLon = abs(city.longitude - coordinates.longitude) *
            cos(Math.toRadians((city.latitude + coordinates.latitude) / 2))
        dLat * dLat + dLon * dLon
    } ?: City.MOSCOW
}
