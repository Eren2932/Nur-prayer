package com.nur.prayer.data

import com.nur.prayer.core.astro.Coordinates
import java.time.ZoneId

data class City(
    val id: Int,
    val name: String,
    val region: String,
    val latitude: Double,
    val longitude: Double,
    val timeZoneId: String
) {
    val coordinates: Coordinates get() = Coordinates(latitude, longitude)
    val zone: ZoneId get() = ZoneId.of(timeZoneId)

    companion object {
        val MOSCOW = City(1, "Москва", "Москва", 55.7558, 37.6173, "Europe/Moscow")
    }
}
