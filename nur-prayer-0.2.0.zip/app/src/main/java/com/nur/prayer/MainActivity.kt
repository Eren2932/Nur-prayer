package com.nur.prayer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.lifecycle.lifecycleScope
import com.nur.prayer.notify.PrayerAlarmScheduler
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.AppViewModel
import com.nur.prayer.ui.NurRoot
import com.nur.prayer.ui.theme.NurTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { viewModel.onPermissionsChanged() }

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted.values.any { it }) viewModel.useDeviceLocation()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            NurTheme {
                val data by viewModel.data.collectAsState()
                val now by viewModel.now.collectAsState()
                val locating by viewModel.locating.collectAsState()
                // Re-checked once a minute (and therefore right after the user comes back from the
                // system dialog), instead of once per process launch.
                val exactAllowed = remember(now.minute) {
                    PrayerAlarmScheduler.canScheduleExact(this@MainActivity)
                }

                NurRoot(
                    data = data,
                    now = now,
                    locating = locating,
                    exactAlarmsAllowed = exactAllowed,
                    citySearch = { query -> viewModel.cities(query) },
                    onPickCity = { city -> viewModel.selectCity(city) },
                    actionsFactory = { openCityPicker ->
                        AppActions(
                            openCityPicker = openCityPicker,
                            requestLocation = { requestLocation() },
                            openExactAlarmSettings = { openExactAlarmSettings() },
                            openBatterySettings = { openBatterySettings() },
                            setMethod = { method ->
                                lifecycleScope.launch { viewModel.repository.setMethod(method) }
                            },
                            setMadhab = { madhab ->
                                lifecycleScope.launch { viewModel.repository.setMadhab(madhab) }
                            },
                            setHighLatitudeRule = { rule ->
                                lifecycleScope.launch { viewModel.repository.setHighLatitudeRule(rule) }
                            },
                            setNotification = { prayer, enabled ->
                                viewModel.setNotification(prayer, enabled)
                            },
                            setOffset = { prayer, minutes -> viewModel.setOffset(prayer, minutes) },
                            setPreAlert = { minutes ->
                                lifecycleScope.launch { viewModel.repository.setPreAlert(minutes) }
                            },
                            setSilent = { silent ->
                                lifecycleScope.launch { viewModel.repository.setSilent(silent) }
                            },
                            setHijriOffset = { days ->
                                lifecycleScope.launch { viewModel.repository.setHijriOffset(days) }
                            }
                        )
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Self-heal the alarm chain and the clock every time the user opens the app.
        viewModel.refresh()
        viewModel.onPermissionsChanged()
    }

    private fun requestLocation() {
        locationPermission.launch(
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        )
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            }
        }
    }

    private fun openBatterySettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }.onFailure {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
    }
}
