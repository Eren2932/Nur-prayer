package com.nur.prayer.ui.components

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.isUnspecified

/**
 * Text that shrinks itself until it fits instead of wrapping, clipping or pushing the layout apart.
 *
 * This is the second half of the font-scale defence (the first half is the clamp in `NurTheme`).
 * A user running a 1.8x system font still sees larger type than default, but a row with a title and
 * a time can no longer collapse: the title steps down in 6% increments until it fits its box, down
 * to [minFontSize]. The first frame is withheld while measuring, so nothing visibly jumps.
 */
@Composable
fun AutoSizeText(
    text: String,
    color: Color,
    fontSize: TextUnit,
    modifier: Modifier = Modifier,
    minFontSize: TextUnit = fontSize * 0.68f,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    lineHeight: TextUnit = TextUnit.Unspecified,
    maxLines: Int = 1,
    textAlign: TextAlign? = null,
    softWrap: Boolean = maxLines > 1
) {
    // Reset the search whenever the content or the target size changes.
    var current by remember(text, fontSize, maxLines) { mutableStateOf(fontSize) }
    var settled by remember(text, fontSize, maxLines) { mutableStateOf(false) }
    val steps = remember(text, fontSize, maxLines) { mutableIntStateOf(0) }

    Text(
        text = text,
        color = color,
        fontSize = current,
        fontWeight = fontWeight,
        fontFamily = fontFamily,
        letterSpacing = letterSpacing,
        lineHeight = lineHeight,
        maxLines = maxLines,
        softWrap = softWrap,
        textAlign = textAlign,
        overflow = TextOverflow.Clip,
        modifier = modifier.drawWithContent { if (settled) drawContent() },
        onTextLayout = { result ->
            if (settled) return@Text
            val overflow = result.hasVisualOverflow ||
                result.didOverflowWidth ||
                result.didOverflowHeight
            if (!overflow || steps.intValue >= MAX_STEPS) {
                settled = true
                return@Text
            }
            val next = current * 0.94f
            val floor = if (minFontSize.isUnspecified) fontSize * 0.68f else minFontSize
            if (next.value >= floor.value) {
                steps.intValue = steps.intValue + 1
                current = next
            } else {
                current = floor
                settled = true
            }
        }
    )
}

private const val MAX_STEPS = 12
