package com.nur.prayer.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale

enum class DockIcon { PRAYER, CALENDAR, QIBLA, SETTINGS }

data class DockItem(val key: String, val label: String, val icon: DockIcon)

/**
 * The dock.
 *
 * Deliberately not a Material `NavigationBar`: every pixel here is ours. Traits that make it read as
 * a serious control surface rather than a row of chips:
 *
 *  - a real substrate (near-black ink at 82% over a white 5% sheen) with a light top edge and a
 *    darker bottom edge, so it looks like a machined plate lying on the sky;
 *  - one indicator that *slides* between slots on a spring instead of four independent highlights,
 *    which is what makes the movement feel physical;
 *  - a 2 dp accent rail that lights up above the active slot;
 *  - hand-drawn icons (mihrab arch, calendar, compass rose, faders). No icon font dependency, so
 *    the stroke weight matches our type, and nothing can be missing on an OEM ROM;
 *  - fixed slot geometry with self-shrinking labels: the dock keeps its shape at any system font
 *    size, which is exactly where the previous version fell apart.
 */
@Composable
fun NurDock(
    items: List<DockItem>,
    selected: String,
    onSelect: (String) -> Unit,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val activeIndex = items.indexOfFirst { it.key == selected }.coerceAtLeast(0)
    val shape = RoundedCornerShape(ui.s(26f))
    val dockHeight = ui.s(66f)

    BoxWithConstraints(modifier = modifier.fillMaxWidth()) {
        val slotWidth = maxWidth / items.size
        val indicatorOffset by animateDpAsState(
            targetValue = slotWidth * activeIndex,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioLowBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "dockIndicator"
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(dockHeight)
                .clip(shape)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Ink.copy(alpha = 0.72f),
                            Ink.copy(alpha = 0.88f)
                        )
                    )
                )
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.07f),
                            Color.White.copy(alpha = 0.02f)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.18f),
                            Color.White.copy(alpha = 0.03f)
                        )
                    ),
                    shape = shape
                )
        ) {
            // Sliding indicator.
            Box(
                modifier = Modifier
                    .offset(x = indicatorOffset)
                    .width(slotWidth)
                    .fillMaxHeight()
                    .padding(horizontal = ui.s(6f), vertical = ui.s(7f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(ui.s(19f)))
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    accent.copy(alpha = 0.22f),
                                    accent.copy(alpha = 0.07f)
                                )
                            )
                        )
                        .border(1.dp, accent.copy(alpha = 0.30f), RoundedCornerShape(ui.s(19f)))
                )
                // Accent rail above the active slot.
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .width(ui.s(22f))
                        .height(2.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, accent, Color.Transparent)
                            )
                        )
                )
            }

            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start
            ) {
                items.forEach { item ->
                    val active = item.key == selected
                    val tint by animateColorAsState(
                        targetValue = if (active) accent else TextSecondary,
                        animationSpec = tween(260),
                        label = "dockTint"
                    )
                    val lift by animateFloatAsState(
                        targetValue = if (active) 1f else 0f,
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioMediumBouncy,
                            stiffness = Spring.StiffnessLow
                        ),
                        label = "dockLift"
                    )
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .width(slotWidth)
                            .fillMaxHeight()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                if (!active) {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onSelect(item.key)
                                }
                            }
                            .padding(horizontal = ui.s(4f))
                    ) {
                        Box(
                            modifier = Modifier
                                .offset(y = ui.s(-1.5f * lift))
                                .size(ui.s(23f))
                        ) {
                            androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                                drawDockIcon(item.icon, tint, active)
                            }
                        }
                        Spacer(Modifier.height(ui.s(4f)))
                        AutoSizeText(
                            text = item.label,
                            color = tint,
                            fontSize = ui.t(10.5f),
                            minFontSize = ui.t(8f),
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

/* ----------------------------------------------------------------------------------------------
 * Hand-drawn icons. Normalised to a unit box, so they scale with the dock, not with a font.
 * -------------------------------------------------------------------------------------------- */
private fun DrawScope.drawDockIcon(icon: DockIcon, color: Color, active: Boolean) {
    val s = size.minDimension
    val w = if (active) s * 0.10f else s * 0.085f
    val stroke = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(x * s, y * s)

    when (icon) {
        // A mihrab arch: the niche a prayer is directed at.
        DockIcon.PRAYER -> {
            val path = Path().apply {
                moveTo(0.16f * s, 0.92f * s)
                lineTo(0.16f * s, 0.46f * s)
                cubicTo(
                    0.16f * s, 0.14f * s,
                    0.84f * s, 0.14f * s,
                    0.84f * s, 0.46f * s
                )
                lineTo(0.84f * s, 0.92f * s)
            }
            drawPath(path, color = color, style = stroke)
            drawLine(
                color = color.copy(alpha = 0.75f),
                start = p(0.06f, 0.92f),
                end = p(0.94f, 0.92f),
                strokeWidth = w,
                cap = StrokeCap.Round
            )
            if (active) {
                drawCircle(color = color, radius = s * 0.075f, center = p(0.5f, 0.52f))
            }
        }
        // Calendar: plate, hangers, and a filled "today" cell.
        DockIcon.CALENDAR -> {
            drawRoundRect(
                color = color,
                topLeft = p(0.12f, 0.22f),
                size = androidx.compose.ui.geometry.Size(s * 0.76f, s * 0.68f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(s * 0.14f, s * 0.14f),
                style = stroke
            )
            drawLine(color, p(0.30f, 0.10f), p(0.30f, 0.28f), strokeWidth = w, cap = StrokeCap.Round)
            drawLine(color, p(0.70f, 0.10f), p(0.70f, 0.28f), strokeWidth = w, cap = StrokeCap.Round)
            drawLine(
                color.copy(alpha = 0.6f), p(0.12f, 0.44f), p(0.88f, 0.44f),
                strokeWidth = w * 0.8f
            )
            if (active) {
                drawRoundRect(
                    color = color,
                    topLeft = p(0.30f, 0.56f),
                    size = androidx.compose.ui.geometry.Size(s * 0.18f, s * 0.16f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(s * 0.05f, s * 0.05f)
                )
            }
        }
        // Compass rose with a needle pointing north-east.
        DockIcon.QIBLA -> {
            drawCircle(color = color, radius = s * 0.40f, center = p(0.5f, 0.5f), style = stroke)
            val needle = Path().apply {
                moveTo(0.70f * s, 0.30f * s)
                lineTo(0.44f * s, 0.44f * s)
                lineTo(0.30f * s, 0.70f * s)
                lineTo(0.56f * s, 0.56f * s)
                close()
            }
            if (active) drawPath(needle, color = color) else drawPath(needle, color = color, style = stroke)
        }
        // Faders: settings that are actually tuned, not a gear cliche.
        DockIcon.SETTINGS -> {
            val rows = floatArrayOf(0.28f, 0.5f, 0.72f)
            val knobs = floatArrayOf(0.68f, 0.36f, 0.58f)
            rows.forEachIndexed { i, y ->
                drawLine(
                    color = color.copy(alpha = 0.55f),
                    start = p(0.12f, y), end = p(0.88f, y),
                    strokeWidth = w * 0.85f, cap = StrokeCap.Round
                )
                val cx = knobs[i]
                if (active) {
                    drawCircle(color = color, radius = s * 0.105f, center = p(cx, y))
                } else {
                    drawCircle(color = color, radius = s * 0.10f, center = p(cx, y), style = Stroke(width = w * 0.9f))
                }
            }
        }
    }
}
