package com.nur.prayer.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.components.DockIcon
import com.nur.prayer.ui.components.DockItem
import com.nur.prayer.ui.components.NightSky
import com.nur.prayer.ui.components.NurDock
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.settings.SettingsScreen
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.paletteFor
import com.nur.prayer.ui.theme.uiScale

private const val TAB_HOME = "home"
private const val TAB_SCHEDULE = "schedule"
private const val TAB_QIBLA = "qibla"
private const val TAB_SETTINGS = "settings"
private const val ROUTE_CITY = "city"

@Composable
fun NurRoot(
    data: PrayerData?,
    now: java.time.ZonedDateTime,
    locating: Boolean,
    exactAlarmsAllowed: Boolean,
    citySearch: (String) -> List<com.nur.prayer.data.City>,
    onPickCity: (com.nur.prayer.data.City) -> Unit,
    actionsFactory: (openCityPicker: () -> Unit) -> AppActions
) {
    var tab by remember { mutableStateOf(TAB_HOME) }
    var route by remember { mutableStateOf<String?>(null) }

    val ui = uiScale()
    val palette = paletteFor(data?.window?.current ?: com.nur.prayer.core.astro.Prayer.ISHA)
    val actions = actionsFactory { route = ROUTE_CITY }

    // Every screen pads its own bottom by exactly what the dock occupies, so nothing ever hides
    // behind it — including on devices with a tall gesture bar.
    val systemBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val dockInset = ui.s(66f) + ui.s(26f) + systemBottom

    CompositionLocalProvider(LocalDockInset provides dockInset) {
        Box(modifier = Modifier.fillMaxSize()) {
            NightSky(palette = palette)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
            ) {
                AnimatedContent(
                    targetState = route ?: tab,
                    transitionSpec = {
                        (fadeIn(tween(320)) + slideInVertically(tween(320)) { it / 22 }) togetherWith
                            fadeOut(tween(180)) + slideOutVertically(tween(180)) { -it / 40 }
                    },
                    label = "screens",
                    modifier = Modifier.fillMaxSize()
                ) { target ->
                    if (data == null) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Считаем солнце…", color = TextSecondary, fontSize = ui.t(14f))
                        }
                    } else {
                        when (target) {
                            ROUTE_CITY -> CityPickerScreen(
                                palette = palette,
                                selectedCityId = data.settings.cityId,
                                search = citySearch,
                                onPick = { city ->
                                    onPickCity(city)
                                    route = null
                                },
                                onBack = { route = null },
                                onUseLocation = { actions.requestLocation() },
                                locating = locating
                            )
                            TAB_SCHEDULE -> ScheduleScreen(data = data, now = now, palette = palette)
                            TAB_QIBLA -> QiblaScreen(data = data, palette = palette)
                            TAB_SETTINGS -> SettingsScreen(
                                data = data,
                                palette = palette,
                                actions = actions,
                                exactAlarmsAllowed = exactAlarmsAllowed
                            )
                            else -> HomeScreen(
                                data = data,
                                now = now,
                                palette = palette,
                                onOpenCity = { route = ROUTE_CITY }
                            )
                        }
                    }
                }
            }

            if (route == null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(horizontal = ui.s(18f), vertical = ui.s(12f))
                ) {
                    NurDock(
                        items = listOf(
                            DockItem(TAB_HOME, "Намаз", DockIcon.PRAYER),
                            DockItem(TAB_SCHEDULE, "Календарь", DockIcon.CALENDAR),
                            DockItem(TAB_QIBLA, "Кыбла", DockIcon.QIBLA),
                            DockItem(TAB_SETTINGS, "Ещё", DockIcon.SETTINGS)
                        ),
                        selected = tab,
                        onSelect = { tab = it },
                        accent = palette.accent
                    )
                }
            }
        }
    }
}
