package com.nur.prayer

import android.app.Application
import com.nur.prayer.data.CityRepository
import com.nur.prayer.data.SettingsRepository
import com.nur.prayer.notify.NotificationHelper

class NurApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        instance = this
        NotificationHelper.createChannels(this)
    }

    companion object {
        lateinit var instance: NurApplication
            private set
    }
}

/** Tiny hand-rolled service locator: no DI framework, no build-time codegen, instant builds. */
object Graph {
    private var cityRepo: CityRepository? = null
    private var settingsRepo: SettingsRepository? = null

    fun cities(context: android.content.Context): CityRepository =
        cityRepo ?: CityRepository(context.applicationContext).also { cityRepo = it }

    fun settings(context: android.content.Context): SettingsRepository =
        settingsRepo ?: SettingsRepository(context.applicationContext).also { settingsRepo = it }
}
