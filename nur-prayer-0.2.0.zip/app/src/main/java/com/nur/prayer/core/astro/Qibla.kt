package com.nur.prayer.core.astro

import kotlin.math.atan2

/** Coordinates of the Kaaba, Masjid al-Haram, Makkah. */
val KAABA = Coordinates(21.4225241, 39.8261818)

/**
 * True (geodetic) bearing from [from] to the Kaaba, in degrees clockwise from true north.
 * Great-circle initial bearing formula.
 */
fun qiblaBearing(from: Coordinates): Double {
    val lonDelta = KAABA.longitude - from.longitude
    val term1 = lonDelta.dsin() * KAABA.latitude.dcos()
    val term2 = from.latitude.dsin() * KAABA.latitude.dcos() * lonDelta.dcos()
    val term3 = from.latitude.dcos() * KAABA.latitude.dsin()
    return unwindAngle(Math.toDegrees(atan2(term1, term3 - term2)))
}

/** Great-circle distance to the Kaaba in kilometres. */
fun distanceToKaabaKm(from: Coordinates): Double {
    val r = 6371.0088
    val dLat = KAABA.latitude - from.latitude
    val dLon = KAABA.longitude - from.longitude
    val a = (dLat / 2).dsin() * (dLat / 2).dsin() +
        from.latitude.dcos() * KAABA.latitude.dcos() * (dLon / 2).dsin() * (dLon / 2).dsin()
    return 2 * r * kotlin.math.asin(kotlin.math.sqrt(a.coerceIn(0.0, 1.0)))
}
