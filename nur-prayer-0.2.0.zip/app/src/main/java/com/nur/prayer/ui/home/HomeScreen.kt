package com.nur.prayer.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.CountdownRing
import com.nur.prayer.ui.components.GlassPanel
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.UiScale
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime

@Composable
fun HomeScreen(
    data: PrayerData,
    now: ZonedDateTime,
    palette: PhasePalette,
    onOpenCity: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val dockInset = LocalDockInset.current
    val window = data.window
    val remaining = window.remaining(now)
    val progress = window.progress(now)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = ui.s(20f))
    ) {
        Spacer(Modifier.height(ui.s(10f)))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .weight(1f, fill = false)
                    .clip(RoundedCornerShape(ui.s(20f)))
                    .background(Color.White.copy(alpha = 0.08f))
                    .clickable { onOpenCity() }
                    .padding(horizontal = ui.s(12f), vertical = ui.s(8f))
            ) {
                Icon(
                    Icons.Filled.LocationOn,
                    contentDescription = "Город",
                    tint = palette.accent,
                    modifier = Modifier.size(ui.s(15f))
                )
                Spacer(Modifier.width(ui.s(6f)))
                AutoSizeText(
                    text = data.place.label,
                    color = TextPrimary,
                    fontSize = ui.t(14f),
                    minFontSize = ui.t(11f),
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(Modifier.width(ui.s(10f)))
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.weight(1f)
            ) {
                AutoSizeText(
                    text = data.hijri,
                    color = palette.accentSoft,
                    fontSize = ui.t(13f),
                    minFontSize = ui.t(9.5f),
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
                AutoSizeText(
                    text = Format.dayMonth(now.toLocalDate()),
                    color = TextTertiary,
                    fontSize = ui.t(12f),
                    minFontSize = ui.t(9f),
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(Modifier.height(ui.s(14f)))

        // The ring is bounded by height as well as width: on a short screen it shrinks instead of
        // pushing the prayer list out of view.
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val ringSize = min(maxWidth - ui.s(16f), (ui.heightDp * 0.46f).dp)
            Box(
                modifier = Modifier
                    .width(ringSize)
                    .aspectRatio(1f)
                    .align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                CountdownRing(
                    progress = progress,
                    accent = palette.accent,
                    accentSoft = palette.accentSoft,
                    stroke = ui.s(13f),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.widthIn(max = ringSize * 0.66f)
                    ) {
                        AutoSizeText(
                            text = "ДО ${PrayerLabels.title(window.next).uppercase()}",
                            color = TextSecondary,
                            fontSize = ui.t(11.5f),
                            minFontSize = ui.t(9f),
                            letterSpacing = ui.t(2f),
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(ui.s(4f)))
                        AutoSizeText(
                            text = Format.countdown(remaining),
                            color = TextPrimary,
                            fontSize = ui.t(50f),
                            minFontSize = ui.t(26f),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Light,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(ui.s(2f)))
                        AutoSizeText(
                            text = "начало в ${Format.time(window.nextStart)}",
                            color = palette.accentSoft,
                            fontSize = ui.t(14.5f),
                            minFontSize = ui.t(11f),
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(Modifier.height(ui.s(10f)))
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.07f))
                                .padding(horizontal = ui.s(12f), vertical = ui.s(5f))
                        ) {
                            AutoSizeText(
                                text = "сейчас ${PrayerLabels.title(window.current)} · ${palette.name}",
                                color = TextSecondary,
                                fontSize = ui.t(11.5f),
                                minFontSize = ui.t(9f)
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(ui.s(14f)))

        GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = ui.s(8f), corner = ui.s(24f)) {
            Column {
                Prayer.entries.forEach { prayer ->
                    val time = data.today.times[prayer]
                    PrayerRow(
                        prayer = prayer,
                        timeText = time?.let { Format.time(it) } ?: "—",
                        isCurrent = prayer == window.current,
                        isNext = prayer == window.next,
                        accent = palette.accent,
                        enabled = data.settings.notifications[prayer] == true,
                        ui = ui
                    )
                }
            }
        }

        val note = data.today.note
        if (note != null) {
            Spacer(Modifier.height(ui.s(12f)))
            GlassPanel(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = ui.s(14f),
                corner = ui.s(20f),
                alpha = 0.05f
            ) {
                Text(
                    text = note,
                    color = TextSecondary,
                    fontSize = ui.t(12.5f),
                    lineHeight = ui.t(17f)
                )
            }
        }

        Spacer(Modifier.height(dockInset))
    }
}

@Composable
private fun PrayerRow(
    prayer: Prayer,
    timeText: String,
    isCurrent: Boolean,
    isNext: Boolean,
    accent: Color,
    enabled: Boolean,
    ui: UiScale
) {
    val highlight by animateColorAsState(
        targetValue = when {
            isNext -> accent.copy(alpha = 0.16f)
            isCurrent -> Color.White.copy(alpha = 0.06f)
            else -> Color.Transparent
        },
        animationSpec = tween(600),
        label = "rowBg"
    )
    val titleColor by animateColorAsState(
        targetValue = if (isNext) accent else TextPrimary,
        animationSpec = tween(600),
        label = "rowTitle"
    )
    val alpha by animateFloatAsState(
        targetValue = if (enabled || prayer == Prayer.SUNRISE) 1f else 0.55f,
        label = "rowAlpha"
    )
    // The Arabic column is the first thing to go when type gets large: it is decoration, the time
    // is not.
    val showArabic = !ui.largeFont && ui.widthDp >= 340f

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(3f))
            .clip(RoundedCornerShape(ui.s(18f)))
            .background(highlight)
            .padding(horizontal = ui.s(13f), vertical = ui.s(11f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(ui.s(8f))
                .clip(CircleShape)
                .background(
                    if (isNext) Brush.linearGradient(listOf(accent, Color.White))
                    else Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.22f), Color.White.copy(alpha = 0.10f))
                    )
                )
        )
        Spacer(Modifier.width(ui.s(11f)))
        Column(modifier = Modifier.weight(1f)) {
            AutoSizeText(
                text = PrayerLabels.title(prayer),
                color = titleColor.copy(alpha = alpha),
                fontSize = ui.t(15.5f),
                minFontSize = ui.t(12f),
                fontWeight = if (isNext) FontWeight.SemiBold else FontWeight.Medium,
                modifier = Modifier.fillMaxWidth()
            )
            AutoSizeText(
                text = PrayerLabels.hint(prayer),
                color = TextTertiary,
                fontSize = ui.t(10.5f),
                minFontSize = ui.t(8.5f),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (showArabic) {
            Spacer(Modifier.width(ui.s(8f)))
            Text(
                text = PrayerLabels.arabic(prayer),
                color = TextTertiary,
                fontSize = ui.t(14f)
            )
        }
        Spacer(Modifier.width(ui.s(12f)))
        AutoSizeText(
            text = timeText,
            color = titleColor.copy(alpha = alpha),
            fontSize = ui.t(18.5f),
            minFontSize = ui.t(14f),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium
        )
    }
}
