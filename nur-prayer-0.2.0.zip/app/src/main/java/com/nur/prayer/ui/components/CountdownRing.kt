package com.nur.prayer.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * The countdown ring, with a comet.
 *
 * The arc itself is information: it fills from the previous prayer to the next one, so the remaining
 * window is readable without looking at a single digit.
 *
 * On top of that a comet circles the ring every [ORBIT_SECONDS] seconds and drags a 28-particle
 * tail of sparks plus a handful of embers that break away and fade. The comet is bright while it
 * flies over the elapsed part of the arc and dims to a faint spark over the part that is still to
 * come — so even the decoration carries meaning. Minute ticks light up as it passes them.
 *
 * Everything is one Canvas driven by a single frame clock: no nested animations, no allocation per
 * frame, 120 Hz friendly. The animation stops itself when the screen is not composed.
 */
@Composable
fun CountdownRing(
    progress: Float,
    accent: Color,
    accentSoft: Color,
    modifier: Modifier = Modifier,
    stroke: Dp = 13.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(900),
        label = "ringProgress"
    )

    val clock = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var origin = 0L
        while (true) {
            withFrameNanos { now ->
                if (origin == 0L) origin = now
                clock.floatValue = (now - origin) / 1_000_000_000f
            }
        }
    }

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val t = clock.floatValue
            if (size.minDimension < 8f) return@Canvas
            // The stroke must never eat more than a quarter of the box, otherwise a small ring
            // (a future widget, a landscape phone) would collapse to a negative radius.
            val strokePx = stroke.toPx().coerceAtMost(size.minDimension * 0.11f)
            val inset = (strokePx * 2.2f).coerceAtMost(size.minDimension * 0.25f)
            val arcSize = Size(size.width - inset * 2f, size.height - inset * 2f)
            val topLeft = Offset(inset, inset)
            val radius = arcSize.minDimension / 2f
            val center = Offset(size.width / 2f, size.height / 2f)
            val sweep = 360f * animatedProgress

            // Ambient halo behind the ring.
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Transparent, accent.copy(alpha = 0.10f), Color.Transparent),
                    center = center,
                    radius = radius * 1.28f
                ),
                radius = radius * 1.28f,
                center = center
            )

            // Inner glass disc: gives the digits something to sit on.
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.05f),
                        Color.White.copy(alpha = 0.015f),
                        Color.Transparent
                    ),
                    center = Offset(center.x, center.y - radius * 0.25f),
                    radius = radius * 0.98f
                ),
                radius = radius - strokePx * 0.6f,
                center = center
            )

            // Track.
            drawArc(
                color = Color.White.copy(alpha = 0.09f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            // Sixty minute ticks; the ones the comet just passed glow.
            val cometOrbit = (t / ORBIT_SECONDS) % 1f
            val cometDeg = -90f + 360f * cometOrbit
            for (i in 0 until 60) {
                val tickDeg = i * 6f - 90f
                val a = (tickDeg * PI / 180f).toFloat()
                val major = i % 5 == 0
                val outer = radius + strokePx * 1.15f
                val inner = outer - if (major) strokePx * 0.62f else strokePx * 0.30f
                val distance = angularDistance(tickDeg, cometDeg)
                val heat = (1f - distance / 26f).coerceIn(0f, 1f).pow(2f)
                val baseAlpha = if (major) 0.20f else 0.08f
                drawLine(
                    color = accentSoft.copy(alpha = baseAlpha + 0.55f * heat),
                    start = Offset(center.x + outer * cos(a), center.y + outer * sin(a)),
                    end = Offset(center.x + inner * cos(a), center.y + inner * sin(a)),
                    strokeWidth = (if (major) 2.2f else 1.4f) * density,
                    cap = StrokeCap.Round
                )
            }

            // Elapsed arc.
            if (sweep > 0.4f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            accent.copy(alpha = 0.75f),
                            accentSoft,
                            accent,
                            accent.copy(alpha = 0.75f)
                        ),
                        center = center
                    ),
                    startAngle = -90f,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )
            }

            // ---- Comet -------------------------------------------------------------------------
            // Bright over the elapsed arc, a faint spark over the part still ahead.
            val overElapsed = ((cometOrbit * 360f) <= sweep)
            val cometPower = if (overElapsed) 1f else 0.32f

            // Tail: sparks left behind along the ring, drifting sideways as they die.
            for (i in 1..TAIL_PARTICLES) {
                val lag = i / TAIL_PARTICLES.toFloat()
                val deg = cometDeg - lag * TAIL_ARC_DEGREES
                val a = (deg * PI / 180f).toFloat()
                val flicker = 0.55f + 0.45f * sin(t * 11f + i * 1.7f)
                val jitter = sin(i * 2.3f + t * 6f) * strokePx * 0.42f * lag
                val r = radius + jitter
                val alpha = (1f - lag).pow(1.9f) * flicker * 0.75f * cometPower
                if (alpha <= 0.01f) continue
                drawCircle(
                    color = accentSoft.copy(alpha = alpha),
                    radius = strokePx * (0.34f - 0.22f * lag).coerceAtLeast(0.05f),
                    center = Offset(center.x + r * cos(a), center.y + r * sin(a))
                )
            }

            // Embers: a few particles break away from the tail and float outwards.
            for (k in 0 until EMBERS) {
                val phase = ((t * 0.9f) + k / EMBERS.toFloat()) % 1f
                val deg = cometDeg - phase * TAIL_ARC_DEGREES * 1.35f
                val a = (deg * PI / 180f).toFloat()
                val outward = strokePx * (0.4f + phase * 2.4f) * (if (k % 2 == 0) 1f else -1f)
                val r = radius + outward
                val alpha = (1f - phase).pow(2.2f) * 0.55f * cometPower
                if (alpha <= 0.01f) continue
                drawCircle(
                    color = accentSoft.copy(alpha = alpha),
                    radius = strokePx * 0.15f * (1f - phase * 0.5f),
                    center = Offset(center.x + r * cos(a), center.y + r * sin(a))
                )
            }

            // Comet nucleus.
            val cometRad = (cometDeg * PI / 180f).toFloat()
            val cometPoint = Offset(
                center.x + radius * cos(cometRad),
                center.y + radius * sin(cometRad)
            )
            val nucleusGlow = strokePx * (2.0f + 0.25f * sin(t * 5f)) * cometPower
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        accentSoft.copy(alpha = 0.85f * cometPower),
                        accent.copy(alpha = 0.28f * cometPower),
                        Color.Transparent
                    ),
                    center = cometPoint,
                    radius = nucleusGlow
                ),
                radius = nucleusGlow,
                center = cometPoint
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.55f + 0.45f * cometPower),
                radius = strokePx * (0.30f + 0.06f * sin(t * 7f)) * (0.6f + 0.4f * cometPower),
                center = cometPoint
            )

            // ---- Progress head: where the countdown actually stands ---------------------------
            if (sweep > 0.4f) {
                val headRad = ((-90f + sweep) * PI / 180f).toFloat()
                val head = Offset(
                    center.x + radius * cos(headRad),
                    center.y + radius * sin(headRad)
                )
                val pulse = 1f + 0.10f * sin(t * 2.4f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(accentSoft.copy(alpha = 0.9f), Color.Transparent),
                        center = head,
                        radius = strokePx * 2.1f * pulse
                    ),
                    radius = strokePx * 2.1f * pulse,
                    center = head
                )
                drawCircle(color = Color.White, radius = strokePx * 0.34f, center = head)
            }
        }
        content()
    }
}

/** Smallest absolute difference between two angles in degrees. */
private fun angularDistance(a: Float, b: Float): Float {
    val d = ((a - b + 540f) % 360f) - 180f
    return if (d < 0f) -d else d
}

private const val ORBIT_SECONDS = 6.5f
private const val TAIL_PARTICLES = 28
private const val TAIL_ARC_DEGREES = 62f
private const val EMBERS = 8

val RingStroke = 13.dp
