package com.nur.prayer.core.astro

import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import kotlin.math.roundToLong

/**
 * Prayer times for one calendar day at one location.
 *
 * Times are computed as instants; a value is null only in the extreme polar case where even
 * sunrise / sunset do not exist. Callers should prefer [com.nur.prayer.core.astro.PrayerEngine]
 * which resolves those cases.
 */
class PrayerTimes(
    val date: LocalDate,
    val coordinates: Coordinates,
    val params: PrayerParams
) {
    val times: Map<Prayer, Instant?>

    /** True when Fajr and/or Isha had to be derived from a night fraction. */
    val usedHighLatitudeRule: Boolean

    init {
        val solar = SolarTime(date, coordinates)
        val tomorrowSolar = SolarTime(date.plusDays(1), coordinates)
        val base = date.atStartOfDay(ZoneOffset.UTC).toInstant()
        val tomorrowBase = date.plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant()

        fun hoursToInstant(from: Instant, hours: Double): Instant? =
            if (hours.isNaN() || hours.isInfinite()) null
            else from.plusMillis((hours * 3600_000.0).roundToLong())

        val sunriseTime = hoursToInstant(base, solar.sunrise)
        val sunsetTime = hoursToInstant(base, solar.sunset)
        val transitTime = hoursToInstant(base, solar.transit)
        val tomorrowSunrise = hoursToInstant(tomorrowBase, tomorrowSolar.sunrise)

        val method = params.method
        var highLatUsed = false

        var fajrTime = hoursToInstant(base, solar.hourAngle(-method.fajrAngle, afterTransit = false))
        var asrTime = hoursToInstant(base, solar.afternoon(params.madhab.shadowLength))
        var maghribTime = if (method.maghribAngle > 0.0) {
            hoursToInstant(base, solar.hourAngle(-method.maghribAngle, afterTransit = true)) ?: sunsetTime
        } else {
            sunsetTime
        }
        var ishaTime: Instant? = if (method.ishaIntervalMinutes > 0) {
            sunsetTime?.plusSeconds(method.ishaIntervalMinutes * 60L)
        } else {
            hoursToInstant(base, solar.hourAngle(-method.ishaAngle, afterTransit = true))
        }

        // High latitude safety net: bound Fajr and Isha by a fraction of the night.
        if (sunriseTime != null && sunsetTime != null && tomorrowSunrise != null) {
            val night = Duration.between(sunsetTime, tomorrowSunrise)
            val rule = params.highLatitudeRule.resolve(coordinates.latitude)
            val fajrPortion: Double
            val ishaPortion: Double
            when (rule) {
                HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> {
                    fajrPortion = 1.0 / 7.0; ishaPortion = 1.0 / 7.0
                }
                HighLatitudeRule.TWILIGHT_ANGLE -> {
                    fajrPortion = method.fajrAngle / 60.0
                    ishaPortion = (if (method.ishaAngle > 0) method.ishaAngle else 17.0) / 60.0
                }
                else -> {
                    fajrPortion = 0.5; ishaPortion = 0.5
                }
            }
            val safeFajr = sunriseTime.minusSeconds((night.seconds * fajrPortion).roundToLong())
            val safeIsha = sunsetTime.plusSeconds((night.seconds * ishaPortion).roundToLong())

            if (fajrTime == null || fajrTime.isBefore(safeFajr)) {
                fajrTime = safeFajr
                highLatUsed = true
            }
            if (ishaTime == null || ishaTime.isAfter(safeIsha)) {
                ishaTime = safeIsha
                highLatUsed = true
            }
        }
        // Asr can be undefined at high latitudes in winter: the Sun never climbs high enough.
        if (asrTime == null) {
            asrTime = hoursToInstant(base, solar.afternoon(Madhab.STANDARD.shadowLength))
            if (asrTime != null) highLatUsed = true
        }
        if (asrTime == null && transitTime != null && maghribTime != null) {
            // Last resort: two thirds of the way from Dhuhr to Maghrib, the classic approximation.
            val span = Duration.between(transitTime, maghribTime).seconds
            asrTime = transitTime.plusSeconds((span * 2 / 3))
            highLatUsed = true
        }

        usedHighLatitudeRule = highLatUsed

        fun adjust(prayer: Prayer, value: Instant?): Instant? =
            value?.plusSeconds(params.adjustmentMinutes(prayer) * 60L)?.let { roundToMinute(it) }

        val raw = linkedMapOf(
            Prayer.FAJR to adjust(Prayer.FAJR, fajrTime),
            Prayer.SUNRISE to adjust(Prayer.SUNRISE, sunriseTime),
            Prayer.DHUHR to adjust(Prayer.DHUHR, transitTime),
            Prayer.ASR to adjust(Prayer.ASR, asrTime),
            Prayer.MAGHRIB to adjust(Prayer.MAGHRIB, maghribTime),
            Prayer.ISHA to adjust(Prayer.ISHA, ishaTime)
        )
        times = enforceOrder(raw)
    }

    /**
     * Guarantees a strictly increasing sequence with at least one minute between markers.
     * Needed on the few days a year when a short night makes two markers collapse into the same
     * minute after rounding: the UI and the alarm chain both rely on a strict order.
     */
    private fun enforceOrder(source: Map<Prayer, Instant?>): Map<Prayer, Instant?> {
        val result = LinkedHashMap<Prayer, Instant?>(source)
        val sunrise = result[Prayer.SUNRISE]
        val fajr = result[Prayer.FAJR]
        if (sunrise != null && fajr != null && !fajr.isBefore(sunrise)) {
            result[Prayer.FAJR] = sunrise.minusSeconds(60)
        }
        val order = listOf(Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)
        var previous: Instant? = null
        for (prayer in order) {
            val value = result[prayer] ?: continue
            val bound = previous
            if (bound != null && !value.isAfter(bound)) {
                result[prayer] = bound.plusSeconds(60)
            }
            previous = result[prayer]
        }
        return result
    }

    val isComplete: Boolean get() = times.values.none { it == null }

    private fun roundToMinute(instant: Instant): Instant {
        // Round up to the next full minute: never announce a prayer before its astronomical time.
        val seconds = instant.epochSecond
        val remainder = seconds % 60
        val rounded = if (remainder == 0L) seconds else seconds + (60 - remainder)
        return Instant.ofEpochSecond(rounded)
    }
}
