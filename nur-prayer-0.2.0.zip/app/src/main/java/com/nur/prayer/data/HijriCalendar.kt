package com.nur.prayer.data

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/**
 * Hijri date formatting. The platform Umm al-Qura implementation can be one day off compared
 * to a local moon sighting, so the user can shift it in Settings.
 */
object HijriCalendar {

    private val months = arrayOf(
        "мухаррам", "сафар", "раби аль-авваль", "раби ас-сани", "джумада аль-уля",
        "джумада ас-сани", "раджаб", "шаабан", "рамадан", "шавваль", "зуль-када", "зуль-хиджа"
    )

    fun format(date: LocalDate, offsetDays: Int = 0): String {
        val hijri = HijrahDate.from(date.plusDays(offsetDays.toLong()))
        val day = hijri.get(ChronoField.DAY_OF_MONTH)
        val month = hijri.get(ChronoField.MONTH_OF_YEAR)
        val year = hijri.get(ChronoField.YEAR)
        return "$day ${months[month - 1]} $year"
    }

    /** Just the day number, for calendar cells. */
    fun dayOfMonth(date: LocalDate, offsetDays: Int = 0): Int =
        HijrahDate.from(date.plusDays(offsetDays.toLong())).get(ChronoField.DAY_OF_MONTH)

    /** "12 раби аль-авваль", without the year: the year is shown once in the header. */
    fun dayAndMonth(date: LocalDate, offsetDays: Int = 0): String {
        val hijri = HijrahDate.from(date.plusDays(offsetDays.toLong()))
        return "${hijri.get(ChronoField.DAY_OF_MONTH)} ${months[hijri.get(ChronoField.MONTH_OF_YEAR) - 1]}"
    }

    /** "раби аль-авваль 1448" for the month header. */
    fun monthAndYear(date: LocalDate, offsetDays: Int = 0): String {
        val hijri = HijrahDate.from(date.plusDays(offsetDays.toLong()))
        return "${months[hijri.get(ChronoField.MONTH_OF_YEAR) - 1]} ${hijri.get(ChronoField.YEAR)}"
    }

    fun monthName(month: Int): String = months[(month - 1).coerceIn(0, 11)]
}
