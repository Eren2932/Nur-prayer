package com.nur.prayer.notify

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.nur.prayer.MainActivity
import com.nur.prayer.R
import com.nur.prayer.core.astro.Prayer

object NotificationHelper {

    const val CHANNEL_ADHAN = "nur.adhan"
    const val CHANNEL_SILENT = "nur.silent"
    const val CHANNEL_PRE = "nur.pre_alert"

    fun createChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val adhan = NotificationChannel(
            CHANNEL_ADHAN, "Азан — время намаза", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Уведомление в момент наступления времени намаза"
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 350, 250, 350)
            setBypassDnd(false)
            // Replace with an adhan file placed in res/raw/adhan.mp3 to play a real adhan.
            val sound = runCatching {
                val resId = context.resources.getIdentifier("adhan", "raw", context.packageName)
                if (resId != 0) {
                    android.net.Uri.parse("android.resource://${context.packageName}/$resId")
                } else {
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                }
            }.getOrNull()
            setSound(sound, audioAttributes)
        }

        val silent = NotificationChannel(
            CHANNEL_SILENT, "Тихие уведомления", NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Без звука, только вибрация"
            enableVibration(true)
            setSound(null, null)
        }

        val pre = NotificationChannel(
            CHANNEL_PRE, "Напоминание заранее", NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Предупреждение за несколько минут до намаза"
            enableVibration(true)
        }

        manager.createNotificationChannel(adhan)
        manager.createNotificationChannel(silent)
        manager.createNotificationChannel(pre)
    }

    fun canPost(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else true

    fun notifyPrayer(
        context: Context,
        prayer: Prayer,
        timeText: String,
        placeName: String,
        isPreAlert: Boolean,
        minutesBefore: Int,
        silent: Boolean
    ) {
        if (!canPost(context)) return

        val channel = when {
            isPreAlert -> CHANNEL_PRE
            silent -> CHANNEL_SILENT
            else -> CHANNEL_ADHAN
        }
        val title = if (isPreAlert) {
            "${PrayerLabels.title(prayer)} через $minutesBefore мин"
        } else {
            "${PrayerLabels.title(prayer)} · $timeText"
        }
        val text = if (isPreAlert) {
            "Начало в $timeText · $placeName"
        } else {
            "Наступило время намаза · $placeName"
        }

        val contentIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setSubText(PrayerLabels.arabic(prayer))
            .setStyle(NotificationCompat.BigTextStyle().bigText("$text\n${PrayerLabels.hint(prayer)}"))
            .setPriority(if (isPreAlert) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setContentIntent(contentIntent)
            .build()

        runCatching {
            NotificationManagerCompat.from(context)
                .notify(prayer.ordinal + if (isPreAlert) 100 else 0, notification)
        }
    }
}
