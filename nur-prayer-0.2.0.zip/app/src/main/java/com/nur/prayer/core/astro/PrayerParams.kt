package com.nur.prayer.core.astro

/** The six daily time markers the app shows. */
enum class Prayer {
    FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA;

    val isPrayer: Boolean get() = this != SUNRISE
}

/** Asr school: shadow length multiplier. */
enum class Madhab(val shadowLength: Double) {
    /** Shafi'i, Maliki, Hanbali: shadow = 1x object height. */
    STANDARD(1.0),

    /** Hanafi: shadow = 2x object height. */
    HANAFI(2.0)
}

/**
 * What to do when the Sun does not reach the Fajr / Isha depression angle
 * (short summer nights at high latitudes, which is most of Russia).
 */
enum class HighLatitudeRule {
    /** Pick automatically from the latitude. */
    AUTO,

    /** Night is split in half: Fajr and Isha cannot cross the middle of the night. */
    MIDDLE_OF_THE_NIGHT,

    /** Isha at 1/7 of the night after sunset, Fajr at 1/7 before sunrise. */
    SEVENTH_OF_THE_NIGHT,

    /** Night fraction proportional to the twilight angle of the method. */
    TWILIGHT_ANGLE;

    fun resolve(latitude: Double): HighLatitudeRule = when (this) {
        AUTO -> if (kotlin.math.abs(latitude) >= 48.0) SEVENTH_OF_THE_NIGHT else MIDDLE_OF_THE_NIGHT
        else -> this
    }
}

/**
 * Ready-made parameter sets. Angles are solar depression angles below the horizon.
 */
enum class CalculationMethod(
    val title: String,
    val fajrAngle: Double,
    val ishaAngle: Double,
    val ishaIntervalMinutes: Int = 0,
    val maghribAngle: Double = 0.0,
    val methodAdjustments: Map<Prayer, Int> = emptyMap()
) {
    RUSSIA_DUM(
        "ДУМ РФ (Совет муфтиев)", 16.0, 15.0
    ),
    SPIRITUAL_BOARD_TATARSTAN(
        "ДУМ Республики Татарстан", 15.0, 15.0
    ),
    MUSLIM_WORLD_LEAGUE(
        "Muslim World League", 18.0, 17.0,
        methodAdjustments = mapOf(Prayer.DHUHR to 1)
    ),
    EGYPTIAN(
        "Egyptian General Authority", 19.5, 17.5,
        methodAdjustments = mapOf(Prayer.DHUHR to 1)
    ),
    KARACHI(
        "University of Islamic Sciences, Karachi", 18.0, 18.0,
        methodAdjustments = mapOf(Prayer.DHUHR to 1)
    ),
    UMM_AL_QURA(
        "Umm al-Qura, Makkah", 18.5, 0.0, ishaIntervalMinutes = 90
    ),
    DUBAI(
        "Dubai", 18.2, 18.2,
        methodAdjustments = mapOf(Prayer.SUNRISE to -3, Prayer.DHUHR to 3, Prayer.ASR to 3, Prayer.MAGHRIB to 3)
    ),
    QATAR(
        "Qatar", 18.0, 0.0, ishaIntervalMinutes = 90
    ),
    KUWAIT(
        "Kuwait", 18.0, 17.5
    ),
    TURKEY(
        "Diyanet, Türkiye", 18.0, 17.0,
        methodAdjustments = mapOf(
            Prayer.SUNRISE to -7, Prayer.DHUHR to 5, Prayer.ASR to 4, Prayer.MAGHRIB to 7
        )
    ),
    TEHRAN(
        "Institute of Geophysics, Tehran", 17.7, 14.0, maghribAngle = 4.5
    ),
    NORTH_AMERICA(
        "ISNA, North America", 15.0, 15.0,
        methodAdjustments = mapOf(Prayer.DHUHR to 1)
    );
}

/** Full calculation configuration, method plus user overrides. */
data class PrayerParams(
    val method: CalculationMethod = CalculationMethod.RUSSIA_DUM,
    val madhab: Madhab = Madhab.HANAFI,
    val highLatitudeRule: HighLatitudeRule = HighLatitudeRule.AUTO,
    /** Manual per-prayer correction in minutes, applied on top of everything else. */
    val userAdjustments: Map<Prayer, Int> = emptyMap()
) {
    fun adjustmentMinutes(prayer: Prayer): Int =
        (method.methodAdjustments[prayer] ?: 0) + (userAdjustments[prayer] ?: 0)
}
