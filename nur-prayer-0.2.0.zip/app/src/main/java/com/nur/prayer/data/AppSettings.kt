package com.nur.prayer.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerParams
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("nur_settings")

/** Everything the user can tune. */
data class AppSettings(
    val cityId: Int = City.MOSCOW.id,
    val useDeviceLocation: Boolean = false,
    val manualLatitude: Double? = null,
    val manualLongitude: Double? = null,
    val method: CalculationMethod = CalculationMethod.RUSSIA_DUM,
    val madhab: Madhab = Madhab.HANAFI,
    val highLatitudeRule: HighLatitudeRule = HighLatitudeRule.AUTO,
    val offsets: Map<Prayer, Int> = emptyMap(),
    val notifications: Map<Prayer, Boolean> = Prayer.entries.associateWith { it.isPrayer },
    val preAlertMinutes: Int = 0,
    val silentNotifications: Boolean = false,
    val hijriOffset: Int = 0
) {
    val params: PrayerParams
        get() = PrayerParams(
            method = method,
            madhab = madhab,
            highLatitudeRule = highLatitudeRule,
            userAdjustments = offsets
        )
}

class SettingsRepository(private val context: Context) {

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs -> prefs.toSettings() }

    private fun Preferences.toSettings(): AppSettings = AppSettings(
        cityId = this[Keys.cityId] ?: City.MOSCOW.id,
        useDeviceLocation = this[Keys.useDeviceLocation] ?: false,
        manualLatitude = this[Keys.manualLat]?.toDoubleOrNull(),
        manualLongitude = this[Keys.manualLon]?.toDoubleOrNull(),
        method = this[Keys.method]?.let { runCatching { CalculationMethod.valueOf(it) }.getOrNull() }
            ?: CalculationMethod.RUSSIA_DUM,
        madhab = this[Keys.madhab]?.let { runCatching { Madhab.valueOf(it) }.getOrNull() } ?: Madhab.HANAFI,
        highLatitudeRule = this[Keys.highLat]?.let { runCatching { HighLatitudeRule.valueOf(it) }.getOrNull() }
            ?: HighLatitudeRule.AUTO,
        offsets = Prayer.entries.associateWith { (this[Keys.offset(it)] ?: 0) },
        notifications = Prayer.entries.associateWith { (this[Keys.notify(it)] ?: it.isPrayer) },
        preAlertMinutes = this[Keys.preAlert] ?: 0,
        silentNotifications = this[Keys.silent] ?: false,
        hijriOffset = this[Keys.hijriOffset] ?: 0
    )

    suspend fun setCity(city: City) = context.dataStore.edit {
        it[Keys.cityId] = city.id
        it[Keys.useDeviceLocation] = false
    }

    suspend fun setUseDeviceLocation(enabled: Boolean) = context.dataStore.edit {
        it[Keys.useDeviceLocation] = enabled
    }

    suspend fun setDeviceLocation(latitude: Double, longitude: Double, nearestCityId: Int) =
        context.dataStore.edit {
            it[Keys.manualLat] = latitude.toString()
            it[Keys.manualLon] = longitude.toString()
            it[Keys.cityId] = nearestCityId
            it[Keys.useDeviceLocation] = true
        }

    suspend fun setMethod(method: CalculationMethod) = context.dataStore.edit {
        it[Keys.method] = method.name
    }

    suspend fun setMadhab(madhab: Madhab) = context.dataStore.edit { it[Keys.madhab] = madhab.name }

    suspend fun setHighLatitudeRule(rule: HighLatitudeRule) = context.dataStore.edit {
        it[Keys.highLat] = rule.name
    }

    suspend fun setOffset(prayer: Prayer, minutes: Int) = context.dataStore.edit {
        it[Keys.offset(prayer)] = minutes.coerceIn(-60, 60)
    }

    suspend fun setNotification(prayer: Prayer, enabled: Boolean) = context.dataStore.edit {
        it[Keys.notify(prayer)] = enabled
    }

    suspend fun setPreAlert(minutes: Int) = context.dataStore.edit {
        it[Keys.preAlert] = minutes.coerceIn(0, 60)
    }

    suspend fun setSilent(silent: Boolean) = context.dataStore.edit { it[Keys.silent] = silent }

    suspend fun setHijriOffset(days: Int) = context.dataStore.edit {
        it[Keys.hijriOffset] = days.coerceIn(-2, 2)
    }

    private object Keys {
        val cityId = intPreferencesKey("city_id")
        val useDeviceLocation = booleanPreferencesKey("use_device_location")
        val manualLat = stringPreferencesKey("manual_lat")
        val manualLon = stringPreferencesKey("manual_lon")
        val method = stringPreferencesKey("method")
        val madhab = stringPreferencesKey("madhab")
        val highLat = stringPreferencesKey("high_lat")
        val preAlert = intPreferencesKey("pre_alert")
        val silent = booleanPreferencesKey("silent")
        val hijriOffset = intPreferencesKey("hijri_offset")
        fun offset(prayer: Prayer) = intPreferencesKey("offset_${prayer.name}")
        fun notify(prayer: Prayer) = booleanPreferencesKey("notify_${prayer.name}")
    }
}
