package com.nur.prayer.notify

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.nur.prayer.Graph
import com.nur.prayer.core.astro.Prayer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val prayer = runCatching {
            Prayer.valueOf(intent.getStringExtra(PrayerAlarmScheduler.EXTRA_PRAYER) ?: "")
        }.getOrNull()
        val timeText = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_TIME) ?: ""
        val place = intent.getStringExtra(PrayerAlarmScheduler.EXTRA_PLACE) ?: ""
        val isPre = intent.getBooleanExtra(PrayerAlarmScheduler.EXTRA_PRE, false)
        val preMinutes = intent.getIntExtra(PrayerAlarmScheduler.EXTRA_PRE_MINUTES, 0)

        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val settings = Graph.settings(appContext).settings.first()
                if (prayer != null) {
                    NotificationHelper.notifyPrayer(
                        context = appContext,
                        prayer = prayer,
                        timeText = timeText,
                        placeName = place,
                        isPreAlert = isPre,
                        minutesBefore = preMinutes,
                        silent = settings.silentNotifications
                    )
                }
                // Chain the next alarm.
                PrayerAlarmScheduler.reschedule(appContext, settings)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
