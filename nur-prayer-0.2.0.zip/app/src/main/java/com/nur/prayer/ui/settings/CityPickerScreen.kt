package com.nur.prayer.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.City
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

@Composable
fun CityPickerScreen(
    palette: PhasePalette,
    selectedCityId: Int,
    search: (String) -> List<City>,
    onPick: (City) -> Unit,
    onBack: () -> Unit,
    onUseLocation: () -> Unit,
    locating: Boolean,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    var query by remember { mutableStateOf("") }
    val results = remember(query) { search(query) }

    Column(modifier = modifier.fillMaxWidth().padding(horizontal = ui.s(20f))) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(ui.s(38f))
                    .clip(RoundedCornerShape(ui.s(14f)))
                    .background(Color.White.copy(alpha = 0.08f))
                    .clickable { onBack() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.ArrowBack,
                    "Назад",
                    tint = TextPrimary,
                    modifier = Modifier.size(ui.s(18f))
                )
            }
            Spacer(Modifier.width(ui.s(12f)))
            Column(modifier = Modifier.weight(1f)) {
                AutoSizeText(
                    text = "Город",
                    color = TextPrimary,
                    fontSize = ui.t(22f),
                    minFontSize = ui.t(16f),
                    fontWeight = FontWeight.SemiBold
                )
                AutoSizeText(
                    text = if (query.isEmpty()) "Найдено ${results.size} городов"
                    else "${results.size} совпадений",
                    color = TextTertiary,
                    fontSize = ui.t(11f),
                    minFontSize = ui.t(9f)
                )
            }
        }

        Spacer(Modifier.height(ui.s(14f)))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(ui.s(18f)))
                .background(Color.White.copy(alpha = 0.08f))
                .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(ui.s(18f)))
                .padding(horizontal = ui.s(14f), vertical = ui.s(12f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Filled.Search,
                null,
                tint = TextTertiary,
                modifier = Modifier.size(ui.s(18f))
            )
            Spacer(Modifier.width(ui.s(10f)))
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) {
                    AutoSizeText(
                        text = "Название города",
                        color = TextTertiary,
                        fontSize = ui.t(15f),
                        minFontSize = ui.t(12f)
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    textStyle = TextStyle(color = TextPrimary, fontSize = ui.t(15f)),
                    cursorBrush = SolidColor(palette.accent),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (query.isNotEmpty()) {
                Spacer(Modifier.width(ui.s(8f)))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(ui.s(10f)))
                        .background(Color.White.copy(alpha = 0.10f))
                        .clickable { query = "" }
                        .padding(horizontal = ui.s(8f), vertical = ui.s(3f))
                ) {
                    AutoSizeText(
                        text = "стереть",
                        color = TextSecondary,
                        fontSize = ui.t(10.5f),
                        minFontSize = ui.t(9f)
                    )
                }
            }
        }

        Spacer(Modifier.height(ui.s(10f)))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(ui.s(16f)))
                .background(palette.accent.copy(alpha = 0.16f))
                .border(1.dp, palette.accent.copy(alpha = 0.28f), RoundedCornerShape(ui.s(16f)))
                .clickable(enabled = !locating) { onUseLocation() }
                .padding(vertical = ui.s(12f), horizontal = ui.s(12f)),
            contentAlignment = Alignment.Center
        ) {
            AutoSizeText(
                text = if (locating) "Определяем координаты…" else "Определить по геолокации",
                color = TextPrimary,
                fontSize = ui.t(13f),
                minFontSize = ui.t(10.5f),
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(Modifier.height(ui.s(10f)))

        if (results.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = ui.s(30f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Ничего не нашли. Поиск не различает «е» и «ё», дефисы можно не ставить: " +
                        "попробуйте «улан удэ» или «наб челны».",
                    color = TextTertiary,
                    fontSize = ui.t(12.5f),
                    lineHeight = ui.t(18f)
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
            contentPadding = PaddingValues(bottom = ui.s(24f)),
            verticalArrangement = Arrangement.spacedBy(ui.s(4f))
        ) {
            items(results, key = { it.id }) { city ->
                val selected = city.id == selectedCityId
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(ui.s(16f)))
                        .background(
                            if (selected) palette.accent.copy(alpha = 0.16f)
                            else Color.White.copy(alpha = 0.04f)
                        )
                        .border(
                            1.dp,
                            if (selected) palette.accent.copy(alpha = 0.30f) else Color.Transparent,
                            RoundedCornerShape(ui.s(16f))
                        )
                        .clickable { onPick(city) }
                        .padding(horizontal = ui.s(14f), vertical = ui.s(12f)),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        AutoSizeText(
                            text = city.name,
                            color = TextPrimary,
                            fontSize = ui.t(15f),
                            minFontSize = ui.t(12f),
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.fillMaxWidth()
                        )
                        AutoSizeText(
                            text = city.region,
                            color = TextTertiary,
                            fontSize = ui.t(11f),
                            minFontSize = ui.t(9f),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(Modifier.width(ui.s(10f)))
                    AutoSizeText(
                        text = "UTC" + utcOffsetLabel(city.timeZoneId),
                        color = TextSecondary,
                        fontSize = ui.t(11f),
                        minFontSize = ui.t(9f),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

/**
 * "Europe/Moscow" told the user nothing. The UTC offset does: it is the number that has to match
 * their phone clock, and it is how people in Russia actually name their zone ("МСК+2").
 */
private fun utcOffsetLabel(zoneId: String): String = runCatching {
    val offset = java.time.ZoneId.of(zoneId)
        .rules
        .getOffset(java.time.Instant.now())
        .totalSeconds / 3600
    if (offset >= 0) "+$offset" else "$offset"
}.getOrDefault("?")
