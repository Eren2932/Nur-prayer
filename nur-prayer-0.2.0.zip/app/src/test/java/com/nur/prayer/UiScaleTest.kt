package com.nur.prayer

import com.nur.prayer.ui.theme.MAX_FONT_SCALE
import com.nur.prayer.ui.theme.MIN_FONT_SCALE
import com.nur.prayer.ui.theme.UiScale
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Guards the layout against the two things that broke it on real devices: a huge system font and a
 * small screen. The numbers here are the contract the screens are built against.
 */
class UiScaleTest {

    @Test
    fun `our own type never explodes with the system font`() {
        val huge = UiScale.of(360, 780, 2.0f)
        assertTrue("text multiplier too large: ${huge.text}", huge.text <= 1.0f)
        assertTrue(huge.largeFont)
        assertTrue(huge.compact)
    }

    @Test
    fun `tiny and huge screens both stay inside sane bounds`() {
        val tiny = UiScale.of(280, 480, 1f)
        val big = UiScale.of(600, 1024, 1f)
        listOf(tiny, big).forEach {
            assertTrue(it.space in 0.82f..1.18f)
            assertTrue(it.text in 0.80f..1.12f)
        }
        assertTrue(tiny.space < big.space)
    }

    @Test
    fun `the font scale clamp is a real range`() {
        assertTrue(MIN_FONT_SCALE < 1f && MAX_FONT_SCALE > 1f)
        assertTrue(2.0f.coerceIn(MIN_FONT_SCALE, MAX_FONT_SCALE) == MAX_FONT_SCALE)
    }

    @Test
    fun `scaled values grow with the multiplier`() {
        val small = UiScale.of(320, 640, 1f)
        val large = UiScale.of(430, 932, 1f)
        assertTrue(large.s(16f) > small.s(16f))
    }
}
