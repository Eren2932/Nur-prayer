package com.nur.prayer

import com.nur.prayer.ui.qibla.HeadingFilter
import com.nur.prayer.ui.qibla.angleDelta
import com.nur.prayer.ui.qibla.lerpAngle
import com.nur.prayer.ui.qibla.normalize
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/**
 * The compass bugs that survive in most apps are all here, as tests:
 * wrap-around at north, the shortest-path rule, and a filter that must not smear 359° into 180°.
 */
class HeadingMathTest {

    @Test
    fun `normalize maps any angle into 0 until 360`() {
        assertEquals(10f, normalize(370f), 0.001f)
        assertEquals(350f, normalize(-10f), 0.001f)
        assertEquals(0f, normalize(720f), 0.001f)
        assertEquals(359f, normalize(-361f), 0.001f)
    }

    @Test
    fun `angleDelta takes the short way round north`() {
        assertEquals(2f, angleDelta(359f, 1f), 0.001f)
        assertEquals(-2f, angleDelta(1f, 359f), 0.001f)
        assertEquals(90f, angleDelta(0f, 90f), 0.001f)
        assertTrue(abs(angleDelta(0f, 180f)) == 180f)
    }

    @Test
    fun `lerpAngle never travels the long way`() {
        val mid = lerpAngle(350f, 10f, 0.5f)
        assertEquals(0f, normalize(mid + 360f) % 360f, 0.5f)
    }

    @Test
    fun `filter converges to a steady bearing`() {
        val filter = HeadingFilter()
        var value = 0f
        repeat(80) { value = filter.push(123.4f) }
        assertEquals(123.4f, value, 0.5f)
    }

    @Test
    fun `filter crosses north without a 180 degree excursion`() {
        val filter = HeadingFilter()
        repeat(60) { filter.push(358f) }
        var worst = 0f
        repeat(40) {
            val out = filter.push(2f)
            // Anything between 358 and 2 is fine; 180 is the bug we are hunting.
            val distanceFromNorth = abs(angleDelta(0f, out))
            if (distanceFromNorth > worst) worst = distanceFromNorth
        }
        assertTrue("filter drifted to $worst degrees from north", worst <= 5f)
    }

    @Test
    fun `filter reacts fast to a large turn and slowly to noise`() {
        val fast = HeadingFilter()
        repeat(40) { fast.push(0f) }
        val afterBigTurn = (1..6).map { fast.push(90f) }.last()
        assertTrue("expected a quick move, got $afterBigTurn", afterBigTurn > 55f)

        val calm = HeadingFilter()
        repeat(40) { calm.push(45f) }
        val afterNoise = calm.push(46f)
        assertTrue("noise leaked through: $afterNoise", abs(angleDelta(45f, afterNoise)) < 0.4f)
    }
}
