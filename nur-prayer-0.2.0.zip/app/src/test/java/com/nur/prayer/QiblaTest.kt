package com.nur.prayer

import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The Qibla azimuth is the one number in this app that a user can check against an independent
 * source in five seconds, so it is pinned to reference values from the great-circle formula for
 * cities spread across the whole country, including one east of Makkah's meridian (Vladivostok,
 * where the direction turns north-west and a sloppy implementation flips the sign).
 */
class QiblaTest {

    private fun bearing(lat: Double, lon: Double) = qiblaBearing(Coordinates(lat, lon))

    @Test
    fun `bearings match reference values across Russia`() {
        assertEquals(176.4, bearing(55.7558, 37.6173), 0.2)   // Москва
        assertEquals(195.2, bearing(55.7963, 49.1088), 0.2)   // Казань
        assertEquals(148.6, bearing(54.7104, 20.4522), 0.2)   // Калининград
        assertEquals(199.0, bearing(42.9764, 47.5024), 0.2)   // Махачкала
        assertEquals(171.5, bearing(68.9585, 33.0827), 0.2)   // Мурманск
        assertEquals(287.3, bearing(43.1155, 131.8855), 0.2)  // Владивосток
    }

    @Test
    fun `bearing is always inside a single turn`() {
        val samples = listOf(
            Coordinates(0.0, 0.0),
            Coordinates(-33.8688, 151.2093),
            Coordinates(64.1466, -21.9426),
            Coordinates(89.0, 0.0)
        )
        samples.forEach {
            val b = qiblaBearing(it)
            assertTrue("bearing out of range: $b", b >= 0.0 && b < 360.0)
        }
    }

    @Test
    fun `distance to the Kaaba is sane`() {
        assertEquals(3822.0, distanceToKaabaKm(Coordinates(55.7558, 37.6173)), 25.0) // Москва
        assertEquals(0.0, distanceToKaabaKm(Coordinates(21.4225241, 39.8261818)), 0.5)
    }
}
