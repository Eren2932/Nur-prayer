package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.PrayerParams
import com.nur.prayer.core.astro.qiblaBearing
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs

class PrayerTimesTest {

    private val params = PrayerParams(
        method = CalculationMethod.RUSSIA_DUM,
        madhab = Madhab.HANAFI
    )

    @Test
    fun `order is always monotonic across a year in hard cities`() {
        val cities = listOf(
            Triple("Москва", Coordinates(55.7558, 37.6173), "Europe/Moscow"),
            Triple("Санкт-Петербург", Coordinates(59.9311, 30.3609), "Europe/Moscow"),
            Triple("Мурманск", Coordinates(68.9585, 33.0827), "Europe/Moscow"),
            Triple("Махачкала", Coordinates(42.9764, 47.5024), "Europe/Moscow"),
            Triple("Владивосток", Coordinates(43.1155, 131.8855), "Asia/Vladivostok")
        )
        for ((name, coordinates, zoneId) in cities) {
            val zone = ZoneId.of(zoneId)
            var date = LocalDate.of(2026, 1, 1)
            while (date.year == 2026) {
                val day = PrayerEngine.day(date, coordinates, zone, params)
                val ordered = Prayer.entries.map { day.at(it) }
                for (i in 1 until ordered.size) {
                    assertTrue(
                        "$name $date: ${Prayer.entries[i]} must be after ${Prayer.entries[i - 1]}",
                        ordered[i].isAfter(ordered[i - 1])
                    )
                }
                date = date.plusDays(7)
            }
        }
    }

    @Test
    fun `dhuhr in Moscow is close to solar noon`() {
        val zone = ZoneId.of("Europe/Moscow")
        val day = PrayerEngine.day(
            LocalDate.of(2026, 3, 21), Coordinates(55.7558, 37.6173), zone, params
        )
        val dhuhr = day.at(Prayer.DHUHR)
        // Solar noon in Moscow around the equinox is 12:39 local time (UTC+3, 37.6E).
        assertEquals(12, dhuhr.hour)
        assertTrue(abs(dhuhr.minute - 39) <= 3)
    }

    @Test
    fun `qibla bearings match published values`() {
        assertEquals(180.0, qiblaBearing(Coordinates(25.4225, 39.8262)), 1.0) // due north of Makkah
        assertEquals(176.0, qiblaBearing(Coordinates(55.7558, 37.6173)), 3.0) // Moscow, ~176 deg
        assertEquals(58.5, qiblaBearing(Coordinates(40.7128, -74.0060)), 2.0) // New York
    }

    @Test
    fun `polar summer still returns a full day`() {
        val zone = ZoneId.of("Europe/Moscow")
        val day = PrayerEngine.day(
            LocalDate.of(2026, 6, 21), Coordinates(68.9585, 33.0827), zone, params
        )
        assertEquals(6, day.times.size)
        assertTrue(day.note != null)
    }
}
