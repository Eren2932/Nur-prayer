# Compose + Kotlin metadata are handled by the AGP defaults.
-keepattributes *Annotation*
-keep class com.nur.prayer.notify.** { *; }
