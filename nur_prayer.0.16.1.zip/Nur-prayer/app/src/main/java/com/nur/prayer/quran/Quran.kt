package com.nur.prayer.quran

import android.content.Context
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * One surah of the mushaf. [start] is the global index (0-based) of its first ayah, so the 6236
 * ayat are numbered without gaps; it comes from the Tanzil metadata like everything else here.
 */
data class SurahMeta(
    val number: Int,
    val arabic: String,
    val latin: String,
    val ru: String,
    val meaningRu: String,
    val english: String,
    val ayat: Int,
    val medinan: Boolean,
    val start: Int
)

/** The translations shipped in assets/quran/NNN.tsv, each under its own column. */
enum class QuranTranslation(val code: String, val label: String, val author: String) {
    RU("ru", "Русский", "Эльмир Кулиев"),
    EN("en", "English", "Saheeh International"),
    TR("tr", "Türkçe", "Diyanet İşleri"),
    UZ("uz", "Oʻzbekcha", "Muhammad Sodiq Muhammad Yusuf");

    companion object {
        fun of(code: String?): QuranTranslation? = entries.firstOrNull { it.code == code }
    }
}

class QuranAyah(
    val surah: Int,
    val number: Int,
    val arabic: String,
    /** Russian scientific reading (ҳ, һ, ‘), the one the azkar and the course use. */
    val translit: String,
    /** The same reading in Latin letters (ḥ, h, ʿ) for the non-Cyrillic interfaces. */
    val latin: String,
    private val translations: Map<QuranTranslation, String>
) {
    fun translation(t: QuranTranslation?): String? = t?.let { translations[it] }
    val key: Int get() = surah * 1000 + number
}

/** Where a reader stopped. */
data class QuranMark(val surah: Int, val ayah: Int)

/** Pure functions over the index: no Android, unit-tested on the JVM. */
object QuranMath {
    private val CYRILLIC_UI = setOf("ru", "kk", "ky", "tt", "tg")

    fun surah(number: Int): SurahMeta = QuranIndex.SURAHS[(number.coerceIn(1, QuranIndex.SURAH_COUNT)) - 1]

    /** Juz 1..30 that contains [surah]:[ayah]. */
    fun juzOf(surah: Int, ayah: Int): Int {
        val key = surah * 1000 + ayah
        var juz = 1
        for (i in QuranIndex.JUZ.indices) if (QuranIndex.JUZ[i] <= key) juz = i + 1
        return juz
    }

    /** The juz that starts exactly at this ayah, or 0. */
    fun juzStartingAt(surah: Int, ayah: Int): Int = QuranIndex.JUZ.indexOf(surah * 1000 + ayah) + 1

    fun isSajda(surah: Int, ayah: Int): Boolean = (surah * 1000 + ayah) in QuranIndex.SAJDA

    /** Basmala is read before every surah except at-Tawba; in al-Fatiha it is the first ayah itself. */
    fun showsBasmala(surah: Int): Boolean = surah != 1 && surah != 9

    /** The translation a reader sees before choosing one: the interface language when we ship it. */
    fun defaultTranslation(uiLanguage: String): QuranTranslation? = when (uiLanguage) {
        "ar" -> null
        "en", "id" -> QuranTranslation.EN
        "tr", "az" -> QuranTranslation.TR
        "uz" -> QuranTranslation.UZ
        else -> QuranTranslation.RU
    }

    /** Cyrillic reading for the Cyrillic interfaces, Latin for the rest. */
    fun latinReading(uiLanguage: String): Boolean = uiLanguage !in CYRILLIC_UI

    /** Surah name as the interface language writes it. */
    fun title(s: SurahMeta, uiLanguage: String): String = when {
        uiLanguage == "ar" -> s.arabic
        uiLanguage in CYRILLIC_UI -> s.ru
        else -> s.latin
    }

    /** What the name means; empty for Arabic (the name says it) and when it equals the title. */
    fun meaning(s: SurahMeta, uiLanguage: String): String = when {
        uiLanguage == "ar" -> ""
        uiLanguage in CYRILLIC_UI -> if (s.meaningRu == s.ru) "" else s.meaningRu
        else -> if (s.english == s.latin) "" else s.english
    }

    /** "2:255", "2 255", "2.255" → that ayah, when it exists. */
    fun parseReference(query: String): QuranMark? {
        val m = Regex("""^\s*(\d{1,3})\s*[:.\s]\s*(\d{1,3})\s*$""").find(query) ?: return null
        val s = m.groupValues[1].toInt()
        val a = m.groupValues[2].toInt()
        if (s !in 1..QuranIndex.SURAH_COUNT || a !in 1..surah(s).ayat) return null
        return QuranMark(s, a)
    }

    /**
     * Lower case without apostrophes, hyphens, spaces, soft signs and ‘ayn marks, doubled letters
     * once: "ал ихлас", "ikhlas" and "Al-Ikhlaas" all fold to something "ихлас"/"ikhlas" is part of.
     */
    fun fold(text: String): String = buildString {
        for (raw in text.lowercase()) {
            val ch = when (raw) {
                'ё' -> 'е'
                '\'', '‘', '’', 'ʿ', 'ʾ', '`', '-', ' ', '_', 'ь', 'ъ' -> continue
                else -> raw
            }
            if (isNotEmpty() && last() == ch) continue
            append(ch)
        }
    }

    /** Surahs matching a number, any of their names, or what the name means. Mushaf order is kept. */
    fun search(query: String): List<SurahMeta> {
        val q = query.trim()
        if (q.isEmpty()) return QuranIndex.SURAHS
        parseReference(q)?.let { return listOf(surah(it.surah)) }
        q.toIntOrNull()?.let { n -> return QuranIndex.SURAHS.filter { it.number == n } }
        val f = fold(q)
        return QuranIndex.SURAHS.filter { s ->
            listOf(s.ru, s.meaningRu, s.latin, s.english, s.arabic).any { fold(it).contains(f) }
        }
    }

    /**
     * One surah file: a header naming the columns, then one ayah per line. Columns are found by
     * name, so adding a translation never shifts the others.
     */
    fun parse(surah: Int, tsv: String): List<QuranAyah> {
        val lines = tsv.lineSequence().filter { it.isNotEmpty() }.toList()
        if (lines.isEmpty()) return emptyList()
        val header = lines.first().split('\t')
        fun col(name: String) = header.indexOf(name)
        val iAyah = col("ayah"); val iAr = col("arabic"); val iTr = col("translit"); val iLat = col("latin")
        val iTrans = QuranTranslation.entries.associateWith { col(it.code) }.filterValues { it >= 0 }
        if (iAyah < 0 || iAr < 0) return emptyList()
        return lines.drop(1).mapNotNull { line ->
            val c = line.split('\t')
            val n = c.getOrNull(iAyah)?.toIntOrNull() ?: return@mapNotNull null
            val ar = c.getOrNull(iAr).orEmpty()
            if (ar.isEmpty()) return@mapNotNull null
            QuranAyah(
                surah, n, ar, c.getOrNull(iTr).orEmpty(), c.getOrNull(iLat).orEmpty(),
                iTrans.mapNotNull { (t, i) -> c.getOrNull(i)?.takeIf { it.isNotEmpty() }?.let { t to it } }.toMap()
            )
        }
    }

    fun asset(surah: Int): String = "quran/%03d.tsv".format(surah)

    /**
     * Splits a translation into the words of the translator and his remarks in parentheses, so the
     * remarks can be drawn quieter. Returns (text, isRemark) runs; unbalanced brackets end the remark.
     */
    fun remarks(text: String): List<Pair<String, Boolean>> {
        val out = ArrayList<Pair<String, Boolean>>()
        val sb = StringBuilder()
        var depth = 0
        for (ch in text) {
            if (ch == '(' && depth == 0) {
                if (sb.isNotEmpty()) { out += sb.toString() to false; sb.clear() }
                depth = 1; sb.append(ch)
            } else if (ch == '(') {
                depth++; sb.append(ch)
            } else if (ch == ')' && depth > 0) {
                sb.append(ch); depth--
                if (depth == 0) { out += sb.toString() to true; sb.clear() }
            } else sb.append(ch)
        }
        if (sb.isNotEmpty()) out += sb.toString() to (depth > 0)
        return out
    }
}

/** Reads one surah at a time from the APK; the last few stay in memory for swiping back and forth. */
class QuranRepository private constructor(private val context: Context) {
    private val cache = LruCache<Int, List<QuranAyah>>(8)

    fun cached(surah: Int): List<QuranAyah>? = cache.get(surah)

    suspend fun surah(surah: Int): List<QuranAyah> {
        cache.get(surah)?.let { return it }
        val ayat = withContext(Dispatchers.IO) {
            runCatching {
                context.assets.open(QuranMath.asset(surah)).bufferedReader().use { QuranMath.parse(surah, it.readText()) }
            }.getOrDefault(emptyList())
        }
        if (ayat.isNotEmpty()) cache.put(surah, ayat)
        return ayat
    }

    companion object {
        @Volatile private var instance: QuranRepository? = null
        fun get(context: Context): QuranRepository =
            instance ?: synchronized(this) { instance ?: QuranRepository(context.applicationContext).also { instance = it } }
    }
}

/**
 * Reader preferences and the bookmark: its own small SharedPreferences file. Values are Compose
 * state, so the today tile and the reader follow one another without a view model in between.
 */
class QuranStore private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("nur_quran", Context.MODE_PRIVATE)

    var showReading by mutableStateOf(prefs.getBoolean(K_READING, true))
        private set
    /** null: follow the interface language. */
    var translationCode by mutableStateOf(prefs.getString(K_TRANSLATION, null))
        private set
    var arabicSize by mutableStateOf(prefs.getInt(K_SIZE, 1).coerceIn(0, SIZES.lastIndex))
        private set
    var mark by mutableStateOf(readMark())
        private set

    private fun readMark(): QuranMark? {
        val s = prefs.getInt(K_SURAH, 0)
        val a = prefs.getInt(K_AYAH, 0)
        return if (s in 1..QuranIndex.SURAH_COUNT && a in 1..QuranMath.surah(s).ayat) QuranMark(s, a) else null
    }

    fun setReading(v: Boolean) { showReading = v; prefs.edit().putBoolean(K_READING, v).apply() }

    /** [NONE_CODE] hides the translation; null returns to the interface language. */
    fun setTranslation(code: String?) {
        translationCode = code
        prefs.edit().apply { if (code == null) remove(K_TRANSLATION) else putString(K_TRANSLATION, code) }.apply()
    }

    fun setSize(v: Int) { arabicSize = v.coerceIn(0, SIZES.lastIndex); prefs.edit().putInt(K_SIZE, arabicSize).apply() }

    fun saveMark(m: QuranMark) {
        if (m == mark) return
        mark = m
        prefs.edit().putInt(K_SURAH, m.surah).putInt(K_AYAH, m.ayah).apply()
    }

    fun translation(uiLanguage: String): QuranTranslation? = when (val c = translationCode) {
        null -> QuranMath.defaultTranslation(uiLanguage)
        NONE_CODE -> null
        else -> QuranTranslation.of(c) ?: QuranMath.defaultTranslation(uiLanguage)
    }

    companion object {
        const val NONE_CODE = "none"
        /** Arabic size steps, sp. */
        val SIZES = floatArrayOf(24f, 28f, 34f)
        private const val K_READING = "reading"
        private const val K_TRANSLATION = "translation"
        private const val K_SIZE = "arabic_size"
        private const val K_SURAH = "mark_surah"
        private const val K_AYAH = "mark_ayah"

        @Volatile private var instance: QuranStore? = null
        fun get(context: Context): QuranStore =
            instance ?: synchronized(this) { instance ?: QuranStore(context).also { instance = it } }
    }
}
