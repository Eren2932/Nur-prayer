package com.nur.prayer.ui.quran

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.QuranAyah
import com.nur.prayer.quran.QuranIndex
import com.nur.prayer.quran.QuranMark
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.quran.QuranRepository
import com.nur.prayer.quran.QuranStore
import com.nur.prayer.quran.QuranTranslation
import com.nur.prayer.quran.SurahMeta
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.components.ScreenHeader
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.daily.Chip
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.HGap
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Where the Quran page stands. Hoisted to the root so the today tile can open the reader on the
 * bookmark and the "Ещё" link on the table of contents; saved across process death by the root.
 */
class QuranNav(reading: Boolean = false, surah: Int = 1, jump: Int = 0, token: Int = 0) {
    var reading by mutableStateOf(reading)
    var surah by mutableStateOf(surah.coerceIn(1, QuranIndex.SURAH_COUNT))
    /** Ayah to scroll to once the surah is on screen; 0 when there is nothing to do. */
    var jump by mutableStateOf(jump)
    /**
     * Bumped by every explicit open. The reader is keyed on it, so a page restored from an earlier
     * visit never wins over the surah that was just asked for.
     */
    var token by mutableStateOf(token)
        private set

    fun read(surah: Int, ayah: Int = 0) {
        this.surah = surah.coerceIn(1, QuranIndex.SURAH_COUNT); jump = ayah; token++; reading = true
    }
    fun contents() { reading = false }

    companion object {
        val Saver = androidx.compose.runtime.saveable.listSaver<QuranNav, Int>(
            save = { listOf(if (it.reading) 1 else 0, it.surah, it.jump, it.token) },
            restore = { QuranNav(it.getOrElse(0) { 0 } == 1, it.getOrElse(1) { 1 }, it.getOrElse(2) { 0 }, it.getOrElse(3) { 0 }) }
        )
    }
}

/**
 * The whole Quran: 114 surahs in mushaf order. Two faces — the table of contents (search by name,
 * number or "2:255", surahs or juz) and the reader, a pager of surahs swiped like pages.
 */
@Composable
fun QuranScreen(nav: QuranNav, palette: PhasePalette, onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember { QuranStore.get(context) }
    BackHandler(nav.reading) { nav.contents() }
    AnimatedContent(
        targetState = nav.reading,
        transitionSpec = {
            val deeper = targetState
            (slideInHorizontally(NurMotion.gentle()) { w: Int -> if (deeper) w / 3 else -w / 3 } + fadeIn(tween(200))) togetherWith
                (slideOutHorizontally(NurMotion.gentle()) { w: Int -> if (deeper) -w / 6 else w / 6 } + fadeOut(tween(140)))
        },
        label = "quranFace", modifier = Modifier.fillMaxSize()
    ) { reading ->
        if (reading) key(nav.token) { QuranReader(nav, store, palette) }
        else QuranContents(store, palette, onBack, onOpen = { s, a -> nav.read(s, a) })
    }
}

// ── table of contents ────────────────────────────────────────────────────────────────────────────

@Composable
private fun QuranContents(store: QuranStore, palette: PhasePalette, onBack: () -> Unit, onOpen: (Int, Int) -> Unit) {
    val ui = uiScale()
    val lang = L10n.language.code
    val accent = palette.accent
    var query by rememberSaveable { mutableStateOf("") }
    var byJuz by rememberSaveable { mutableStateOf(false) }
    val results = remember(query) { QuranMath.search(query) }
    val reference = remember(query) { QuranMath.parseReference(query) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(tr("Коран"), onBack, Modifier.padding(horizontal = ui.s(16f)))
        Box(
            Modifier.padding(horizontal = ui.s(16f)).fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(SurfaceRaised).padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            if (query.isEmpty()) Text(tr("Сура, номер или 2:255"), color = TextTertiary, fontSize = ui.t(15f))
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = TextPrimary, fontSize = ui.t(16f)),
                cursorBrush = SolidColor(accent), modifier = Modifier.fillMaxWidth()
            )
        }
        Gap(10f)
        Row(Modifier.padding(horizontal = ui.s(16f)), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip(tr("Суры"), !byJuz, accent) { byJuz = false }
            Chip(tr("Джузы"), byJuz, accent) { byJuz = true }
        }
        Gap(10f)
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val mark = store.mark
            if (query.isEmpty() && mark != null) {
                item(key = "continue") {
                    val s = QuranMath.surah(mark.surah)
                    ContinueCard(QuranMath.title(s, lang), mark, accent) { onOpen(mark.surah, mark.ayah) }
                }
            }
            if (reference != null) {
                item(key = "ref") {
                    val s = QuranMath.surah(reference.surah)
                    GlassCard(Modifier.pressClick(shape = RoundedCornerShape(24.dp)) { onOpen(reference.surah, reference.ayah) }) {
                        Column(Modifier.padding(ui.s(16f))) {
                            Text(tr("Открыть аят {0}:{1}", reference.surah, reference.ayah), color = TextPrimary,
                                fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
                            Text(QuranMath.title(s, lang), color = TextTertiary, fontSize = ui.t(13f))
                        }
                    }
                }
            }
            if (byJuz && query.isEmpty()) {
                items(QuranIndex.JUZ.size, key = { "juz$it" }) { i ->
                    val key = QuranIndex.JUZ[i]
                    val s = QuranMath.surah(key / 1000)
                    JuzRow(i + 1, QuranMath.title(s, lang), key / 1000, key % 1000, accent) { onOpen(key / 1000, key % 1000) }
                }
            } else {
                if (results.isEmpty()) item(key = "empty") {
                    Text(tr("Ничего не нашлось"), color = TextSecondary, fontSize = ui.t(15f), textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 32.dp))
                }
                items(results, key = { it.number }) { s -> SurahRow(s, lang, accent, mark?.surah == s.number) { onOpen(s.number, 0) } }
            }
        }
    }
}

@Composable
private fun ContinueCard(title: String, mark: QuranMark, accent: Color, onClick: () -> Unit) {
    val ui = uiScale()
    GlassCard(Modifier.pressClick(shape = RoundedCornerShape(24.dp), onClick = onClick), color = accent.copy(alpha = 0.22f)) {
        Row(Modifier.padding(ui.s(16f)), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("Продолжить чтение"), color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Bold)
                Text(tr("{0} · аят {1}", title, mark.ayah), color = TextSecondary, fontSize = ui.t(14f))
            }
            Text("›", color = TextPrimary, fontSize = ui.t(26f))
        }
    }
}

@Composable
private fun NumberBadge(n: Int, accent: Color, highlighted: Boolean = false) {
    val ui = uiScale()
    Box(
        Modifier.size(ui.s(40f)).clip(CircleShape).background(if (highlighted) accent.copy(alpha = 0.45f) else SurfaceInset),
        contentAlignment = Alignment.Center
    ) {
        Text("$n", color = TextPrimary, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SurahRow(s: SurahMeta, lang: String, accent: Color, current: Boolean, onClick: () -> Unit) {
    val ui = uiScale()
    val meaning = QuranMath.meaning(s, lang)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceRaised)
            .pressClick(scaleTo = 0.98f, onClick = onClick).padding(horizontal = ui.s(12f), vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NumberBadge(s.number, accent, current)
        HGap(12f)
        Column(Modifier.weight(1f)) {
            Text(QuranMath.title(s, lang), color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
            val place = if (s.medinan) tr("Мединская") else tr("Мекканская")
            Text(
                (if (meaning.isNotEmpty()) "$meaning · " else "") + place + " · " + tr("аятов: {0}", s.ayat),
                color = TextTertiary, fontSize = ui.t(13f)
            )
        }
        HGap(8f)
        if (lang != "ar") ArabicText(s.arabic, 22f, align = TextAlign.End)
    }
}

@Composable
private fun JuzRow(juz: Int, title: String, surah: Int, ayah: Int, accent: Color, onClick: () -> Unit) {
    val ui = uiScale()
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(SurfaceRaised)
            .pressClick(scaleTo = 0.98f, onClick = onClick).padding(horizontal = ui.s(12f), vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NumberBadge(juz, accent)
        HGap(12f)
        Column(Modifier.weight(1f)) {
            Text(tr("Джуз {0}", juz), color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
            Text(tr("начало: {0}, {1}:{2}", title, surah, ayah), color = TextTertiary, fontSize = ui.t(13f))
        }
        Text("›", color = TextTertiary, fontSize = ui.t(22f))
    }
}

// ── reader ───────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun QuranReader(nav: QuranNav, store: QuranStore, palette: PhasePalette) {
    val ui = uiScale()
    val lang = L10n.language.code
    val accent = palette.accent
    val scope = rememberCoroutineScope()
    val pager = rememberPagerState(initialPage = nav.surah - 1) { QuranIndex.SURAH_COUNT }
    var settings by rememberSaveable { mutableStateOf(false) }
    // The pager is the truth while swiping; the root only hears where it settled.
    LaunchedEffect(pager) { snapshotFlow { pager.settledPage }.collect { nav.surah = it + 1 } }
    // A jump from outside (a juz, "2:255") while the reader is already open moves the pager too.
    LaunchedEffect(nav.surah) { if (pager.settledPage != nav.surah - 1 && !pager.isScrollInProgress) pager.scrollToPage(nav.surah - 1) }

    val shown = QuranMath.surah(pager.currentPage + 1)
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(QuranMath.title(shown, lang), { nav.contents() }, Modifier.padding(horizontal = ui.s(16f)), backLabel = tr("Оглавление")) {
            Chip(tr("Транслит"), store.showReading, accent) { store.setReading(!store.showReading) }
            HGap(8f)
            RoundIconButton(GlyphKind.SLIDERS, tr("Настройки чтения"), { settings = !settings })
        }
        AnimatedVisibility(
            visible = settings,
            enter = expandVertically(NurMotion.gentle()) + fadeIn(NurMotion.gentle()),
            exit = shrinkVertically(NurMotion.snappy()) + fadeOut(NurMotion.snappy())
        ) {
            ReaderSettings(store, lang, accent)
        }
        HorizontalPager(
            state = pager,
            key = { it + 1 },
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) { page ->
            val number = page + 1
            SurahPage(
                surah = QuranMath.surah(number),
                store = store,
                lang = lang,
                accent = accent,
                active = pager.settledPage == page,
                jumpTo = if (nav.surah == number) nav.jump else 0,
                onJumpDone = { if (nav.surah == number) nav.jump = 0 },
                onPrev = { if (page > 0) scope.launch { pager.animateScrollToPage(page - 1) } },
                onNext = { if (page < QuranIndex.SURAH_COUNT - 1) scope.launch { pager.animateScrollToPage(page + 1) } }
            )
        }
    }
}

@Composable
private fun ReaderSettings(store: QuranStore, lang: String, accent: Color) {
    val ui = uiScale()
    val current = store.translation(lang)
    Column(Modifier.fillMaxWidth().padding(horizontal = ui.s(16f)).padding(bottom = 10.dp)) {
        GlassCard {
            Column(Modifier.padding(ui.s(14f))) {
                Text(tr("Перевод смыслов"), color = TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
                Gap(6f)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(QuranTranslation.entries, key = { it.code }) { t ->
                        Chip(t.label, current == t, accent) { store.setTranslation(t.code) }
                    }
                    item(key = "none") { Chip(tr("Без перевода"), current == null, accent) { store.setTranslation(QuranStore.NONE_CODE) } }
                }
                if (current != null) {
                    Gap(4f)
                    Text(current.author, color = TextTertiary, fontSize = ui.t(12f))
                }
                Gap(10f)
                // Required by the Tanzil licence: name the source of the Arabic text and link to it.
                Text("Quran text: Tanzil Project · tanzil.net", color = TextTertiary, fontSize = ui.t(11f))
                Gap(12f)
                Text(tr("Размер арабского текста"), color = TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
                Gap(6f)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(tr("Мелкий"), tr("Обычный"), tr("Крупный")).forEachIndexed { i, label ->
                        Chip(label, store.arabicSize == i, accent) { store.setSize(i) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SurahPage(
    surah: SurahMeta,
    store: QuranStore,
    lang: String,
    accent: Color,
    active: Boolean,
    jumpTo: Int,
    onJumpDone: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    val ui = uiScale()
    val context = LocalContext.current
    val repo = remember { QuranRepository.get(context) }
    val ayat by produceState(repo.cached(surah.number), surah.number) { value = repo.surah(surah.number) }
    val list = rememberLazyListState()
    val translation = store.translation(lang)
    val latin = QuranMath.latinReading(lang)
    val arabicSize = QuranStore.SIZES[store.arabicSize]
    val clipboard = LocalClipboardManager.current
    val haptic = LocalHapticFeedback.current
    val copied = tr("Аят скопирован")

    // Jump: header is item 0, ayah n is item n.
    LaunchedEffect(ayat, jumpTo) {
        val loaded = ayat ?: return@LaunchedEffect
        if (jumpTo > 0 && loaded.isNotEmpty()) {
            list.scrollToItem(jumpTo.coerceIn(1, loaded.size))
            onJumpDone()
        }
    }
    // Bookmark: the ayah at the top of the page, once the reader stops on it.
    LaunchedEffect(active, ayat) {
        if (!active || ayat.isNullOrEmpty()) return@LaunchedEffect
        snapshotFlow { list.firstVisibleItemIndex }.collectLatest { i ->
            delay(700)
            store.saveMark(QuranMark(surah.number, i.coerceIn(1, surah.ayat)))
        }
    }

    val loaded = ayat
    if (loaded == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(tr("Загружаем…"), color = TextSecondary) }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        state = list,
        contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item(key = "head") { SurahHeader(surah, lang, store.showReading, latin, accent) }
        items(loaded, key = { it.key }) { a ->
            AyahItem(
                a, translation, store.showReading, latin, arabicSize, accent,
                Modifier.combinedClickable(
                    onClick = {},
                    onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        val text = buildString {
                            append(a.arabic)
                            a.translation(translation)?.let { append("\n\n").append(it) }
                            append("\n\n— ").append(QuranMath.title(surah, lang)).append(", ").append(a.surah).append(':').append(a.number)
                        }
                        clipboard.setText(AnnotatedString(text))
                        Toast.makeText(context, copied, Toast.LENGTH_SHORT).show()
                    }
                )
            )
        }
        item(key = "foot") { PageFooter(surah.number, lang, accent, onPrev, onNext) }
    }
}

@Composable
private fun SurahHeader(s: SurahMeta, lang: String, showReading: Boolean, latin: Boolean, accent: Color) {
    val ui = uiScale()
    GlassCard(Modifier.padding(bottom = 6.dp)) {
        Column(Modifier.fillMaxWidth().padding(ui.s(16f)), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(tr("Сура {0} из {1}", s.number, QuranIndex.SURAH_COUNT), color = TextTertiary, fontSize = ui.t(12f))
            ArabicText(s.arabic, 32f)
            val meaning = QuranMath.meaning(s, lang)
            if (meaning.isNotEmpty()) Text("«$meaning»", color = TextSecondary, fontSize = ui.t(14f), textAlign = TextAlign.Center)
            Gap(4f)
            Text(
                (if (s.medinan) tr("Мединская") else tr("Мекканская")) + " · " + tr("аятов: {0}", s.ayat) + " · " +
                    tr("джуз {0}", QuranMath.juzOf(s.number, 1)),
                color = TextTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center
            )
            if (QuranMath.showsBasmala(s.number)) {
                Gap(12f)
                ArabicText(BASMALA, 24f, color = accent.copy(alpha = 0.95f).compositeOverWhite())
                AnimatedVisibility(showReading) {
                    Text(if (latin) BASMALA_LATIN else BASMALA_CYR, color = TextTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center)
                }
            } else if (s.number == 9) {
                Gap(8f)
                Text(tr("Сура читается без басмалы"), color = TextTertiary, fontSize = ui.t(12f), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun AyahItem(
    a: QuranAyah,
    translation: QuranTranslation?,
    showReading: Boolean,
    latin: Boolean,
    arabicSize: Float,
    accent: Color,
    modifier: Modifier
) {
    val ui = uiScale()
    val juzStart = QuranMath.juzStartingAt(a.surah, a.number)
    Column(modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(SurfaceInset).padding(horizontal = 10.dp, vertical = 4.dp)
            ) { Text("${a.surah}:${a.number}", color = TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold) }
            if (juzStart > 1) {
                HGap(6f)
                Tagline(tr("джуз {0}", juzStart), accent)
            }
            if (QuranMath.isSajda(a.surah, a.number)) {
                HGap(6f)
                Tagline(if (a.key == QuranIndex.SAJDA_SHAFII_ONLY) tr("۩ земной поклон — кроме ханафитского мазхаба") else tr("۩ земной поклон"), Mint)
            }
        }
        Gap(6f)
        ArabicText(a.arabic, arabicSize, align = TextAlign.End, modifier = Modifier.fillMaxWidth())
        AnimatedVisibility(
            visible = showReading,
            enter = expandVertically(NurMotion.gentle()) + fadeIn(NurMotion.gentle()),
            exit = shrinkVertically(NurMotion.snappy()) + fadeOut(NurMotion.snappy())
        ) {
            Text(if (latin) a.latin else a.translit, color = TextTertiary, fontSize = ui.t(14f), lineHeight = ui.t(20f),
                modifier = Modifier.padding(top = 4.dp))
        }
        a.translation(translation)?.let { t ->
            Gap(6f)
            Text(translationText(t), color = TextPrimary, fontSize = ui.t(15f), lineHeight = ui.t(22f))
        }
        Gap(8f)
        Box(Modifier.fillMaxWidth().height(1.dp).background(SurfaceRaised))
    }
}

@Composable
private fun Tagline(text: String, color: Color) {
    val ui = uiScale()
    Box(Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.18f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Text(text, color = color.compositeOverWhite(), fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold)
    }
}

/** The translator's remarks in parentheses are kept, a step quieter than the meaning itself. */
private fun translationText(text: String): AnnotatedString = buildAnnotatedString {
    for ((run, remark) in QuranMath.remarks(text)) {
        if (remark) withStyle(SpanStyle(color = TextTertiary)) { append(run) } else append(run)
    }
}

@Composable
private fun PageFooter(number: Int, lang: String, accent: Color, onPrev: () -> Unit, onNext: () -> Unit) {
    val ui = uiScale()
    Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        if (number < QuranIndex.SURAH_COUNT) {
            val next = QuranMath.surah(number + 1)
            GlassCard(Modifier.pressClick(shape = RoundedCornerShape(24.dp), onClick = onNext), color = accent.copy(alpha = 0.22f)) {
                Row(Modifier.padding(ui.s(16f)), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("Следующая сура"), color = TextSecondary, fontSize = ui.t(13f))
                        Text("${next.number}. ${QuranMath.title(next, lang)}", color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Bold)
                    }
                    if (lang != "ar") ArabicText(next.arabic, 22f, align = TextAlign.End)
                    HGap(8f)
                    Text("›", color = TextPrimary, fontSize = ui.t(26f))
                }
            }
        } else {
            Text(tr("Это последняя сура Корана."), color = TextSecondary, fontSize = ui.t(14f),
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        }
        if (number > 1) {
            Gap(8f)
            val prev = QuranMath.surah(number - 1)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).pressClick(scaleTo = 0.98f, onClick = onPrev)
                    .padding(horizontal = ui.s(16f), vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("‹", color = TextTertiary, fontSize = ui.t(22f))
                HGap(10f)
                Text(tr("Предыдущая: {0}", "${prev.number}. ${QuranMath.title(prev, lang)}"), color = TextTertiary, fontSize = ui.t(14f))
            }
        }
        Gap(4f)
        Text(tr("Листайте вбок, чтобы перейти к соседней суре"), color = TextTertiary, fontSize = ui.t(12f),
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

/** Accent tints are drawn on the dark sky: lift them halfway to white so text stays readable. */
private fun Color.compositeOverWhite(): Color = Color(
    red = red + (1f - red) * 0.45f, green = green + (1f - green) * 0.45f, blue = blue + (1f - blue) * 0.45f, alpha = 1f
)

// Tanzil order (shadda before the vowel), the same code points as the ayat below it.
private const val BASMALA =
    "\u0628\u0650\u0633\u0652\u0645\u0650 \u0627\u0644\u0644\u0651\u064E\u0647\u0650 " +
        "\u0627\u0644\u0631\u0651\u064E\u062D\u0652\u0645\u064E\u0670\u0646\u0650 " +
        "\u0627\u0644\u0631\u0651\u064E\u062D\u0650\u064A\u0645\u0650"
private const val BASMALA_CYR = "бисми-ллаһи р-раҳмаани р-раҳиим"
private const val BASMALA_LATIN = "bismi-llahi r-raḥmāni r-raḥīm"
