package com.nur.prayer.ui.daily

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.DhikrPreset
import com.nur.prayer.daily.StorySlide
import com.nur.prayer.daily.TasbihMath
import com.nur.prayer.daily.Zikr
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.components.ScreenHeader
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.LessonBar
import com.nur.prayer.ui.learn.Tag
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.launch
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/** Warm dusk for the evening set, pale dawn for the morning one — the same cue as the sky. */
internal fun azkarBrush(set: AzkarSet): Brush = if (set == AzkarSet.EVENING)
    Brush.verticalGradient(listOf(Color(0xFFB89A72), Color(0xFFD0453F)))
else Brush.verticalGradient(listOf(Color(0xFF8FB8D8), Color(0xFFE2B97E)))

/** A progress ring: the track and an arc from twelve o'clock. */
@Composable
internal fun Ring(fraction: Float, color: Color, size: Dp, stroke: Dp, modifier: Modifier = Modifier, track: Color = color.copy(alpha = 0.22f)) {
    val shown by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(220), label = "ring")
    Canvas(modifier.size(size)) {
        val w = stroke.toPx()
        val d = this.size.minDimension - w
        val tl = Offset(w / 2, w / 2)
        drawArc(track, 0f, 360f, false, tl, Size(d, d), style = Stroke(w))
        if (shown > 0f) drawArc(color, -90f, 360f * shown, false, tl, Size(d, d), style = Stroke(w, cap = StrokeCap.Round))
    }
}

// ── azkar ──────────────────────────────────────────────────────────────────────────────────────

@Composable
fun AzkarScreen(
    vm: DailyViewModel,
    items: (AzkarSet) -> List<Zikr>,
    currentSet: AzkarSet,
    sessionOf: (AzkarSet) -> String,
    palette: PhasePalette,
    onBack: () -> Unit
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    var set by rememberSaveable { mutableStateOf(currentSet) }
    val sessions by vm.azkar.collectAsStateWithLifecycle()
    val translit by vm.translit.collectAsStateWithLifecycle()
    val list = remember(set, items) { items(set) }
    val session = sessionOf(set)
    val counts = sessions[session].orEmpty()
    val done = list.count { (counts[it.id] ?: 0L) >= it.count }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Азкары", onBack, Modifier.padding(horizontal = ui.s(16f)))
        Row(Modifier.padding(horizontal = ui.s(16f)), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AzkarSet.values().forEach { s ->
                Chip(s.title + if (s == currentSet) " · сейчас" else "", s == set, palette.accent) { set = s }
            }
        }
        Gap(10f)
        Column(Modifier.padding(horizontal = ui.s(16f))) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Прочитано $done из ${list.size}", color = TextSecondary, fontSize = ui.t(13f), modifier = Modifier.weight(1f))
                Text(if (translit) "скрыть транслит" else "показать транслит", color = TextTertiary, fontSize = ui.t(12f),
                    modifier = Modifier.clickable { vm.setTranslit(!translit) }.padding(4.dp))
                Text("заново", color = TextTertiary, fontSize = ui.t(12f), modifier = Modifier.clickable { vm.azkarReset(session) }.padding(4.dp))
            }
            Gap(6f)
            LessonBar(done.toFloat() / list.size.coerceAtLeast(1), if (done == list.size) Mint else palette.accent)
        }
        Gap(10f)
        LazyColumn(
            Modifier.fillMaxSize(), state = listState,
            contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (done == list.size && list.isNotEmpty()) item {
                GlassCard(color = Mint.copy(alpha = 0.18f)) {
                    Text("${set.title} прочитаны. Да примет Аллах.", color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(ui.s(16f)))
                }
            }
            itemsIndexed(list, key = { _, z -> z.id }) { _, z ->
                val n = counts[z.id] ?: 0L
                AzkarCard(z, n, translit, palette.accent) {
                    val now = vm.azkarTap(session, z.id, z.count)
                    if (now >= z.count) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        // Hand the reader the next unfinished one. The "all read" banner only appears
                        // when nothing is left, so list indices map to item indices one to one here.
                        val next = list.indexOfFirst { (counts[it.id] ?: 0L) < it.count && it.id != z.id }
                        if (next >= 0) scope.launch { listState.animateScrollToItem(next) }
                    } else haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
            }
        }
    }
}

@Composable
private fun AzkarCard(z: Zikr, count: Long, translit: Boolean, accent: Color, onTap: () -> Unit) {
    val ui = uiScale()
    val finished = count >= z.count
    var open by remember(z.id, finished) { mutableStateOf(!finished) }
    GlassCard(Modifier.animateContentSize(), color = if (finished) Mint.copy(alpha = 0.10f) else SurfaceRaised) {
        Row(Modifier.fillMaxWidth().clickable { open = !open }.padding(horizontal = ui.s(16f), vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(z.title, color = if (finished) TextSecondary else TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f))
            Tag(if (finished) "✓ ${z.count}" else "$count / ${z.count}", color = if (finished) Mint else TextSecondary)
        }
        if (open) {
            Column(Modifier.fillMaxWidth().padding(horizontal = ui.s(16f)).padding(bottom = 14.dp)) {
                ArabicText(z.arabic, if (z.arabic.length > 300) 21f else 24f, align = TextAlign.End, modifier = Modifier.fillMaxWidth())
                if (translit) { Gap(6f); Text(z.translit, color = TextTertiary, fontSize = ui.t(14f), lineHeight = ui.t(20f)) }
                Gap(6f)
                Text(z.ru, color = TextPrimary, fontSize = ui.t(15f), lineHeight = ui.t(21f))
                z.virtue?.let { Gap(6f); Text(it, color = accent, fontSize = ui.t(13f), lineHeight = ui.t(18f)) }
                Gap(4f)
                Text(z.source, color = TextTertiary, fontSize = ui.t(12f))
                if (!finished) {
                    Gap(10f)
                    NurButton(if (z.count == 1) "Прочитал" else "Прочитал · ${count + 1} из ${z.count}", accent, onTap, Modifier.fillMaxWidth(), primary = true)
                }
            }
        }
    }
}

// ── dhikr ──────────────────────────────────────────────────────────────────────────────────────

@Composable
fun DhikrScreen(vm: DailyViewModel, palette: PhasePalette, onBack: () -> Unit) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val selectedId by vm.selected.collectAsStateWithLifecycle()
    val today by vm.dhikrToday.collectAsStateWithLifecycle()
    val total by vm.dhikrTotal.collectAsStateWithLifecycle()
    val p = Dhikr.preset(selectedId)
    val count = (today[p.id] ?: 0L).toInt()
    val accent = palette.accent
    val sequence = p.id == Dhikr.AFTER_PRAYER
    val finishedSequence = sequence && count >= TasbihMath.TOTAL
    val rounds = if (sequence) 0 else count / p.target
    val inRound = if (sequence) count else count % p.target
    val fraction = if (sequence) count / TasbihMath.TOTAL.toFloat()
        else if (count > 0 && inRound == 0) 1f else inRound / p.target.toFloat()

    fun tap() {
        if (finishedSequence) return
        val n = vm.dhikrTap(p.id).toInt()
        val roundEnd = if (sequence) n == 33 || n == 66 || n == TasbihMath.TOTAL else n % p.target == 0
        haptic.performHapticFeedback(if (roundEnd) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Зикр", onBack, Modifier.padding(horizontal = ui.s(16f))) {
            Tag("сегодня ${today.values.sum()}")
        }
        LazyRow(contentPadding = PaddingValues(horizontal = ui.s(16f)), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(Dhikr.PRESETS, key = { it.id }) { d ->
                val c = today[d.id] ?: 0L
                Chip(if (c > 0) "${d.title} · $c" else d.title, d.id == p.id, accent) { vm.select(d.id) }
            }
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(20f)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Gap(14f)
            if (sequence) {
                val (phase, inPhase) = TasbihMath.phase(count)
                ArabicText(TasbihMath.arabic(phase), 34f)
                Text(TasbihMath.reading(phase), color = TextSecondary, fontSize = ui.t(15f))
                Gap(6f)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (0..2).forEach { i ->
                        val st = if (i < phase || finishedSequence) "✓" else if (i == phase) "$inPhase/${TasbihMath.size(i)}" else "${TasbihMath.size(i)}"
                        Tag(st, color = if (i < phase || finishedSequence) Mint else if (i == phase) TextPrimary else TextTertiary)
                    }
                }
            } else {
                ArabicText(p.arabic, if (p.arabic.length > 24) 26f else 34f)
                Text(p.translit, color = TextSecondary, fontSize = ui.t(15f), textAlign = TextAlign.Center)
                Text(p.ru, color = TextTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center)
            }
            Gap(18f)
            val interaction = remember { MutableInteractionSource() }
            Box(
                Modifier.size(260.dp).clip(CircleShape)
                    .clickable(interactionSource = interaction, indication = androidx.compose.material3.ripple(), enabled = !finishedSequence) { tap() },
                contentAlignment = Alignment.Center
            ) {
                Ring(fraction, if (finishedSequence) Mint else accent, 260.dp, 14.dp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (finishedSequence) "✓" else "${if (sequence) TasbihMath.phase(count).second else inRound}",
                        color = TextPrimary, fontSize = ui.t(64f), fontWeight = FontWeight.Bold)
                    Text(
                        when {
                            finishedSequence -> "100 из 100"
                            sequence -> "из ${TasbihMath.size(TasbihMath.phase(count).first)} · всего $count"
                            else -> "из ${p.target}" + if (rounds > 0) " · кругов $rounds" else ""
                        },
                        color = TextSecondary, fontSize = ui.t(13f)
                    )
                }
            }
            Gap(8f)
            Text("Нажимайте на круг", color = TextTertiary, fontSize = ui.t(12f))
            Gap(14f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Fact("сегодня", "$count", Modifier.weight(1f))
                Fact("за всё время", "${total[p.id] ?: 0L}", Modifier.weight(1f))
            }
            Gap(12f)
            GlassCard(corner = 18.dp) {
                Column(Modifier.fillMaxWidth().padding(ui.s(14f))) {
                    Text(p.virtue, color = TextPrimary, fontSize = ui.t(14f), lineHeight = ui.t(20f))
                    Gap(4f)
                    Text(p.source, color = TextTertiary, fontSize = ui.t(12f))
                }
            }
            Gap(10f)
            NurButton("Сбросить счёт за сегодня", accent, { vm.dhikrReset(p.id) }, Modifier.fillMaxWidth())
            Gap(10f)
            Box(Modifier.height(LocalDockInset.current))
        }
    }
}

@Composable
private fun Fact(label: String, value: String, modifier: Modifier) {
    val ui = uiScale()
    GlassCard(modifier, corner = 18.dp) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = TextPrimary, fontSize = ui.t(22f), fontWeight = FontWeight.Bold)
            Text(label, color = TextTertiary, fontSize = ui.t(12f))
        }
    }
}

@Composable
internal fun Chip(text: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val ui = uiScale()
    Text(
        text, color = if (selected) TextPrimary else TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (selected) accent.copy(alpha = 0.35f) else SurfaceRaised)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

// ── story of the day ───────────────────────────────────────────────────────────────────────────

private const val STORY_MILLIS = 9000

/**
 * Stories, the familiar way: segments on top fill with time, a tap on the right third goes on,
 * on the left goes back, a hold pauses. The last slide closes the viewer.
 */
@Composable
fun StoryScreen(slides: List<StorySlide>, start: Int, accent: Color, onSeen: () -> Unit, onClose: () -> Unit) {
    val ui = uiScale()
    if (slides.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    var index by rememberSaveable { mutableIntStateOf(start.coerceIn(0, slides.lastIndex)) }
    var paused by remember { mutableStateOf(false) }
    val progress = remember { Animatable(0f) }
    BackHandler { onClose() }
    LaunchedEffect(Unit) { onSeen() }
    val shown = remember { intArrayOf(-1) }
    LaunchedEffect(index, paused) {
        // A new slide starts from zero; a pause keeps the filled part and resumes from it.
        if (shown[0] != index) { progress.snapTo(0f); shown[0] = index }
        if (paused) return@LaunchedEffect
        val left = (1f - progress.value).coerceIn(0f, 1f)
        progress.animateTo(1f, tween((STORY_MILLIS * left).toInt().coerceAtLeast(1), easing = LinearEasing))
        if (index < slides.lastIndex) index++ else onClose()
    }
    val slide = slides[index]
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B1030), accent.copy(alpha = 0.45f), Color(0xFF0B1030))))
            .pointerInput(slides.size) {
                detectTapGestures(
                    onPress = { paused = true; tryAwaitRelease(); paused = false },
                    onTap = { o ->
                        if (o.x < size.width / 3f) { if (index > 0) index-- }
                        else if (index < slides.lastIndex) index++ else onClose()
                    }
                )
            }
    ) {
        Column(Modifier.fillMaxSize().navigationBarsPadding().padding(ui.s(16f))) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                slides.indices.forEach { i ->
                    val f = when { i < index -> 1f; i == index -> progress.value; else -> 0f }
                    Box(Modifier.weight(1f).height(3.dp).clip(RoundedCornerShape(50)).background(Color(0x55FFFFFF))) {
                        Box(Modifier.fillMaxWidth(f).height(3.dp).background(Color.White))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("История дня · " + slide.kind, color = TextPrimary, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                RoundIconButton(GlyphKind.CLOSE, "Закрыть", onClose, size = 40.dp)
            }
            Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(slide.kind.uppercase(), color = accent, fontSize = ui.t(13f), fontWeight = FontWeight.Bold)
                Gap(14f)
                slide.arabic?.let { ArabicText(it, if (it.length > 60) 26f else 34f) ; Gap(10f) }
                slide.translit?.let { Text(it, color = TextSecondary, fontSize = ui.t(15f), textAlign = TextAlign.Center, lineHeight = ui.t(21f)); Gap(10f) }
                Text(slide.ru, color = TextPrimary, fontSize = ui.t(if (slide.arabic == null) 24f else 19f), fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center, lineHeight = ui.t(if (slide.arabic == null) 32f else 26f))
                Gap(12f)
                Text(slide.source, color = TextTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center)
                slide.note?.let {
                    Gap(18f)
                    Text(it, color = TextSecondary, fontSize = ui.t(14f), textAlign = TextAlign.Center,
                        modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(SurfaceInset).padding(12.dp))
                }
            }
            Text(if (paused) "пауза" else "нажмите справа — дальше, слева — назад, удерживайте — пауза",
                color = TextTertiary, fontSize = ui.t(11f), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
    }
}
