package com.nur.prayer.daily

import android.content.Context

/** Plain text codecs for the daily counters; lenient: a damaged entry is dropped, never thrown. */
object DailyCodec {
    fun encodeCounts(map: Map<String, Long>): String =
        map.entries.filter { it.value > 0 }.joinToString(",") { "${it.key}=${it.value}" }

    fun decodeCounts(raw: String?): Map<String, Long> {
        if (raw.isNullOrBlank()) return emptyMap()
        return raw.split(',').mapNotNull { part ->
            val eq = part.indexOf('=')
            if (eq <= 0) return@mapNotNull null
            val v = part.substring(eq + 1).toLongOrNull() ?: return@mapNotNull null
            if (v <= 0) null else part.substring(0, eq) to v
        }.toMap()
    }

    /** Azkar sessions: one line per session key, newest last, at most [keep] lines. */
    fun encodeSessions(sessions: Map<String, Map<String, Long>>, keep: Int = 4): String =
        sessions.entries.toList().takeLast(keep).joinToString("\n") { (k, v) -> k + "|" + encodeCounts(v) }

    fun decodeSessions(raw: String?): LinkedHashMap<String, Map<String, Long>> {
        val out = LinkedHashMap<String, Map<String, Long>>()
        raw?.lineSequence()?.forEach { line ->
            val bar = line.indexOf('|')
            if (bar > 0) out[line.substring(0, bar)] = decodeCounts(line.substring(bar + 1))
        }
        return out
    }
}

/**
 * Daily counters: dhikr (today and all-time), azkar sessions, the story seen today. Its own
 * SharedPreferences file, apart from both the prayer settings and the course, so a counter tap
 * never rewrites anything larger than a few lines.
 */
class DailyStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("nur_daily", Context.MODE_PRIVATE)

    fun dhikrToday(today: Long): Map<String, Long> =
        if (prefs.getLong(K_DHIKR_DAY, Long.MIN_VALUE) == today) DailyCodec.decodeCounts(prefs.getString(K_DHIKR_TODAY, null)) else emptyMap()

    fun dhikrTotal(): Map<String, Long> = DailyCodec.decodeCounts(prefs.getString(K_DHIKR_TOTAL, null))

    fun saveDhikr(today: Long, todayCounts: Map<String, Long>, total: Map<String, Long>) {
        prefs.edit().putLong(K_DHIKR_DAY, today)
            .putString(K_DHIKR_TODAY, DailyCodec.encodeCounts(todayCounts))
            .putString(K_DHIKR_TOTAL, DailyCodec.encodeCounts(total)).apply()
    }

    fun selectedDhikr(): String? = prefs.getString(K_DHIKR_SELECTED, null)
    fun saveSelectedDhikr(id: String) = prefs.edit().putString(K_DHIKR_SELECTED, id).apply()

    fun azkar(): LinkedHashMap<String, Map<String, Long>> = DailyCodec.decodeSessions(prefs.getString(K_AZKAR, null))
    fun saveAzkar(sessions: Map<String, Map<String, Long>>) = prefs.edit().putString(K_AZKAR, DailyCodec.encodeSessions(sessions)).apply()

    fun storySeenDay(): Long = prefs.getLong(K_STORY_DAY, Long.MIN_VALUE)
    fun saveStorySeen(day: Long) = prefs.edit().putLong(K_STORY_DAY, day).apply()

    fun showTranslit(): Boolean = prefs.getBoolean(K_TRANSLIT, true)
    fun saveShowTranslit(v: Boolean) = prefs.edit().putBoolean(K_TRANSLIT, v).apply()

    private companion object {
        const val K_DHIKR_DAY = "dhikr_day"
        const val K_DHIKR_TODAY = "dhikr_today"
        const val K_DHIKR_TOTAL = "dhikr_total"
        const val K_DHIKR_SELECTED = "dhikr_selected"
        const val K_AZKAR = "azkar_sessions"
        const val K_STORY_DAY = "story_seen_day"
        const val K_TRANSLIT = "azkar_translit"
    }
}
