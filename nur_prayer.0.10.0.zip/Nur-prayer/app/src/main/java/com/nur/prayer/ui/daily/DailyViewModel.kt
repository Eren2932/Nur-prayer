package com.nur.prayer.ui.daily

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nur.prayer.daily.DailyStore
import com.nur.prayer.daily.Dhikr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

/**
 * Daily counters. Every tap updates memory first and writes in the background; the day rolls over
 * lazily on the first tap of a new day, so a counter left open overnight starts from zero.
 */
class DailyViewModel(application: Application) : AndroidViewModel(application) {
    private val store = DailyStore(application)

    private val _dhikrToday = MutableStateFlow<Map<String, Long>>(emptyMap())
    val dhikrToday: StateFlow<Map<String, Long>> = _dhikrToday.asStateFlow()
    private val _dhikrTotal = MutableStateFlow<Map<String, Long>>(emptyMap())
    val dhikrTotal: StateFlow<Map<String, Long>> = _dhikrTotal.asStateFlow()
    private val _selected = MutableStateFlow(Dhikr.PRESETS.first().id)
    val selected: StateFlow<String> = _selected.asStateFlow()
    private val _azkar = MutableStateFlow<Map<String, Map<String, Long>>>(emptyMap())
    val azkar: StateFlow<Map<String, Map<String, Long>>> = _azkar.asStateFlow()
    private val _storySeen = MutableStateFlow(Long.MIN_VALUE)
    val storySeen: StateFlow<Long> = _storySeen.asStateFlow()
    private val _translit = MutableStateFlow(true)
    val translit: StateFlow<Boolean> = _translit.asStateFlow()

    /** Which slide the story viewer opens on. */
    var storyStart: Int = 0

    private var dhikrDay = today()

    init {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                _dhikrToday.value = store.dhikrToday(dhikrDay)
                _dhikrTotal.value = store.dhikrTotal()
                store.selectedDhikr()?.let { id -> if (Dhikr.PRESETS.any { it.id == id }) _selected.value = id }
                _azkar.value = store.azkar()
                _storySeen.value = store.storySeenDay()
                _translit.value = store.showTranslit()
            }
        }
    }

    fun today(): Long = LocalDate.now().toEpochDay()

    private fun rollDay() {
        val t = today()
        if (t != dhikrDay) { dhikrDay = t; _dhikrToday.value = emptyMap() }
    }

    fun dhikrTap(id: String): Long {
        rollDay()
        val n = (_dhikrToday.value[id] ?: 0L) + 1
        _dhikrToday.value = _dhikrToday.value + (id to n)
        _dhikrTotal.value = _dhikrTotal.value + (id to ((_dhikrTotal.value[id] ?: 0L) + 1))
        saveDhikr()
        return n
    }

    /** Resets today's count only; the all-time total keeps what was said. */
    fun dhikrReset(id: String) {
        rollDay()
        _dhikrToday.value = _dhikrToday.value - id
        saveDhikr()
    }

    fun select(id: String) {
        _selected.value = id
        viewModelScope.launch(Dispatchers.IO) { store.saveSelectedDhikr(id) }
    }

    fun todayCount(id: String): Long {
        rollDay()
        return _dhikrToday.value[id] ?: 0L
    }

    private fun saveDhikr() {
        val day = dhikrDay
        val t = _dhikrToday.value
        val total = _dhikrTotal.value
        viewModelScope.launch(Dispatchers.IO) { store.saveDhikr(day, t, total) }
    }

    /** One more repetition of azkar [id] in [session], capped at [max]. Returns the new count. */
    fun azkarTap(session: String, id: String, max: Int): Long {
        val cur = _azkar.value[session].orEmpty()
        val n = ((cur[id] ?: 0L) + 1).coerceAtMost(max.toLong())
        val next = LinkedHashMap(_azkar.value)
        next.remove(session)
        next[session] = cur + (id to n)
        _azkar.value = next
        viewModelScope.launch(Dispatchers.IO) { store.saveAzkar(next) }
        return n
    }

    fun azkarReset(session: String) {
        val next = LinkedHashMap(_azkar.value)
        next.remove(session)
        _azkar.value = next
        viewModelScope.launch(Dispatchers.IO) { store.saveAzkar(next) }
    }

    fun markStorySeen() {
        val t = today()
        if (_storySeen.value == t) return
        _storySeen.value = t
        viewModelScope.launch(Dispatchers.IO) { store.saveStorySeen(t) }
    }

    fun setTranslit(v: Boolean) {
        _translit.value = v
        viewModelScope.launch(Dispatchers.IO) { store.saveShowTranslit(v) }
    }
}
