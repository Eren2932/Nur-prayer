package com.nur.prayer.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.City
import com.nur.prayer.ui.components.LocalBackdropPaused
import com.nur.prayer.ui.components.SkyBackdrop
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.learn.CourseScreen
import com.nur.prayer.ui.learn.DictionaryScreen
import com.nur.prayer.ui.learn.LearnViewModel
import com.nur.prayer.ui.learn.LessonScreen
import com.nur.prayer.ui.learn.SurahScreen
import com.nur.prayer.ui.today.TodayActions
import com.nur.prayer.ui.today.TodayScreen
import com.nur.prayer.ui.today.TodayState
import com.nur.prayer.ui.daily.AzkarScreen
import com.nur.prayer.ui.daily.DailyViewModel
import com.nur.prayer.ui.daily.DhikrScreen
import com.nur.prayer.ui.daily.StoryScreen
import com.nur.prayer.daily.Azkar
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.DailyStories
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.StorySlide
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nur.prayer.learn.Course
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.settings.SettingsScreen
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.animatedPhasePalette
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime

/**
 * 0.9.0: the pull-up from home raises «Сегодня» (learning, word of the day, tasks of the day); the
 * course, a lesson, the dictionary and the surah reader open inside that layer, so going deeper
 * never drops it. Календарь became an ordinary page opened from the right.
 *
 * 0.6.0 shell: no dock. Home is the root and owns the whole screen; Календарь, Кыбла and Настройки
 * open over it from the right and close back to it, Город opens one level deeper from wherever it
 * was called. The sky is drawn once, behind every route, so a transition never flashes black.
 */
@Composable
fun NurRoot(
    data: PrayerData?, now: State<ZonedDateTime>, locating: Boolean, locationStatus: String?,
    exactAlarmsAllowed: Boolean, notificationsAllowed: Boolean, citySearch: suspend (String) -> List<City>, onPickCity: (City) -> Unit,
    actionsFactory: (openCityPicker: () -> Unit) -> AppActions,
    locationButtonLabel: String = "Определить местоположение"
) {
    val nav = rememberSaveable(saver = NurNavigator.Saver) { NurNavigator() }
    val pages = rememberSaveableStateHolder()
    val backdropPaused = remember { mutableStateOf(false) }
    BackHandler(nav.canGoBack) { nav.back() }
    val targetPalette = remember(data?.window?.current) { paletteFor(data?.window?.current ?: Prayer.ISHA) }
    val palette = animatedPhasePalette(targetPalette)
    val actions = remember(nav) { actionsFactory { nav.go(ROUTE_CITY) } }
    // «Сегодня» is not a page that slides in from the side: it is a layer above home that rises
    // from the bottom, under the finger when pulled. A route change only tells it where to settle;
    // its position is one number (see Reveal). Learning pages live inside it.
    val learn: LearnViewModel = viewModel()
    val learnContent by learn.content.collectAsStateWithLifecycle()
    val learnProgress by learn.progress.collectAsStateWithLifecycle()
    val activeLesson by learn.active.collectAsStateWithLifecycle()
    val daily: DailyViewModel = viewModel()
    val azkarSessions by daily.azkar.collectAsStateWithLifecycle()
    val dhikrToday by daily.dhikrToday.collectAsStateWithLifecycle()
    val dhikrTotal by daily.dhikrTotal.collectAsStateWithLifecycle()
    val storySeenDay by daily.storySeen.collectAsStateWithLifecycle()
    val scheduleOpen = nav.layerOpen
    val calendar = remember { Reveal(initiallyOpen = scheduleOpen) }
    LaunchedEffect(scheduleOpen) { calendar.settle(scheduleOpen) }
    // A lesson does not survive process death (its exercises are random); a restored lesson route
    // without a running lesson steps back to the course instead of showing an empty page.
    LaunchedEffect(nav.current, activeLesson == null) {
        if (nav.current == ROUTE_LESSON && activeLesson == null) nav.back()
    }
    // The layer keeps drawing its last page while it falls back.
    val lastLayer = remember { arrayOf(ROUTE_TODAY) }
    if (nav.layerOpen) lastLayer[0] = nav.current
    // A lesson that cannot start (nothing due, still locked) opens the course map instead of doing nothing.
    val openLesson: (String) -> Unit = { id -> if (learn.start(id)) nav.go(ROUTE_LESSON) else nav.go(ROUTE_COURSE) }
    // Fully covered home is removed from the tree: nothing hidden ticks, draws or answers touches.
    // Going back flips scheduleOpen a frame before the layer starts to fall, so home is composed
    // in time and the first frames of the fall are not spent on it.
    val homeOnScreen by remember(scheduleOpen) { derivedStateOf { !scheduleOpen || calendar.progress < 1f } }
    val scheduleOnScreen by remember(scheduleOpen) { derivedStateOf { scheduleOpen || calendar.progress > 0f } }
    // Without a dock, the bottom inset of scrolling screens is just the system bar plus air.
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    CompositionLocalProvider(LocalDockInset provides (bottom + 28.dp), LocalBackdropPaused provides backdropPaused) {
        Box(Modifier.fillMaxSize()) {
            SkyBackdrop(
                palette,
                sky = data?.settings?.skyBackdrop ?: true,
                motionEnabled = data?.settings?.ambientBackdrop == true
            )
            Box(Modifier.fillMaxSize().statusBarsPadding()) {
              if (homeOnScreen) Box(
                Modifier.fillMaxSize().graphicsLayer {
                    val p = calendar.progress
                    alpha = RevealMath.homeAlpha(p)
                    translationY = -p * 40.dp.toPx()
                    scaleX = 1f - 0.04f * p
                    scaleY = 1f - 0.04f * p
                }
              ) {
                AnimatedContent(
                    targetState = if (scheduleOpen) TAB_HOME else nav.current,
                    transitionSpec = {
                        val deeper = routeDepth(targetState) > routeDepth(initialState)
                        val shallower = routeDepth(targetState) < routeDepth(initialState)
                        val enter = when {
                            deeper -> slideInHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS, easing = FastOutSlowInEasing)) { it } +
                                fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS))
                            shallower -> fadeIn(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) +
                                slideInHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) { -it / 10 }
                            else -> fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS))
                        }
                        val exit = when {
                            shallower -> slideOutHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS, easing = FastOutLinearInEasing)) { it } +
                                fadeOut(tween(NavigationMotion.DETAIL_EXIT_MILLIS))
                            deeper -> fadeOut(tween(NavigationMotion.EXIT_MILLIS)) +
                                slideOutHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS)) { -it / 10 }
                            else -> fadeOut(tween(NavigationMotion.EXIT_MILLIS))
                        }
                        (enter togetherWith exit).apply { targetContentZIndex = if (shallower) -1f else 1f }.using(null)
                    }, label = "nurRoute", modifier = Modifier.fillMaxSize()
                ) { route ->
                    pages.SaveableStateProvider(route) {
                        if (data == null) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Считаем солнце…", color = TextSecondary)
                            }
                        } else when (route) {
                            ROUTE_CITY -> CityPickerScreen(palette, data.settings.cityId, citySearch,
                                onPick = { city -> onPickCity(city); nav.back() }, onBack = { nav.back() },
                                onUseLocation = actions.requestLocation, locating = locating, locationStatus = locationStatus,
                                currentPlace = data.place, locationButtonLabel = locationButtonLabel,
                                onOpenLocationPermissions = actions.openLocationPermissions)
                            TAB_SETTINGS -> SettingsScreen(data, palette, actions, exactAlarmsAllowed, locating, locationStatus,
                                notificationsAllowed = notificationsAllowed, locationButtonLabel = locationButtonLabel,
                                onBack = { nav.back() })
                            TAB_QIBLA -> QiblaScreen(data, palette, onBack = { nav.back() })
                            TAB_SCHEDULE -> ScheduleScreen(data, now, palette, onBack = { nav.back() })
                            else -> HomeScreen(
                                data = data, now = now, palette = palette, actions = actions,
                                notificationsAllowed = notificationsAllowed, exactAlarmsAllowed = exactAlarmsAllowed,
                                onOpenCity = { nav.go(ROUTE_CITY) },
                                onOpenSchedule = { nav.go(TAB_SCHEDULE) },
                                onOpenToday = { nav.go(ROUTE_TODAY) },
                                onOpenQibla = { nav.go(TAB_QIBLA) },
                                onOpenSettings = { nav.go(TAB_SETTINGS) },
                                reveal = calendar
                            )
                        }
                    }
                }
              }
              if (data != null && scheduleOnScreen) {
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        val p = calendar.progress
                        translationY = (1f - p) * size.height
                        alpha = RevealMath.calendarAlpha(p)
                    }
                ) {
                    AnimatedContent(
                        targetState = lastLayer[0],
                        transitionSpec = {
                            val deeper = layerDepth(targetState) > layerDepth(initialState)
                            if (deeper) (slideInHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS, easing = FastOutSlowInEasing)) { it } +
                                fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS))) togetherWith
                                (fadeOut(tween(NavigationMotion.EXIT_MILLIS)) + slideOutHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS)) { -it / 10 })
                            else (fadeIn(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) + slideInHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) { -it / 10 }) togetherWith
                                (slideOutHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS, easing = FastOutLinearInEasing)) { it } +
                                    fadeOut(tween(NavigationMotion.DETAIL_EXIT_MILLIS)))
                        }, label = "layerRoute", modifier = Modifier.fillMaxSize()
                    ) { route ->
                        pages.SaveableStateProvider(route) {
                            when (route) {
                                ROUTE_COURSE -> CourseScreen(learn, learnContent?.course, learnProgress, palette,
                                    onBack = { nav.back() }, onOpenLesson = { nav.go(ROUTE_LESSON) },
                                    onOpenDictionary = { nav.go(ROUTE_DICTIONARY) })
                                ROUTE_LESSON -> LessonScreen(learn, activeLesson, palette, onClose = { nav.back() })
                                ROUTE_DICTIONARY -> DictionaryScreen(learnContent, learnProgress, palette, onBack = { nav.back() })
                                ROUTE_SURAH -> SurahScreen(learnContent, palette, onBack = { nav.back() },
                                    onPractice = { n -> if (learn.start("quran-surah-$n", force = true)) nav.go(ROUTE_LESSON) })
                                ROUTE_AZKAR -> AzkarScreen(
                                    daily, items = { set -> Azkar.of(set, learnContent?.quran) },
                                    currentSet = AzkarSet.at(data.window.current),
                                    sessionOf = { set -> azkarSession(set, data.window) },
                                    palette = palette, onBack = { nav.back() })
                                ROUTE_DHIKR -> DhikrScreen(daily, palette, onBack = { nav.back() })
                                ROUTE_STORY -> StoryScreen(
                                    storySlides(learn.today(), learnContent), daily.storyStart, palette.accent,
                                    onSeen = { daily.markStorySeen() }, onClose = { nav.back() })
                                else -> {
                                    val set = AzkarSet.at(data.window.current)
                                    val azkarList = Azkar.of(set, learnContent?.quran)
                                    val counts = azkarSessions[azkarSession(set, data.window)].orEmpty()
                                    val salawat = Dhikr.preset(Dhikr.SALAWAT)
                                    TodayScreen(
                                        TodayState(
                                            hijri = data.hijri, today = learn.today(), content = learnContent, progress = learnProgress,
                                            azkarSet = set, azkarDone = azkarList.count { (counts[it.id] ?: 0L) >= it.count },
                                            azkarTotal = azkarList.size,
                                            salawatToday = dhikrToday[salawat.id] ?: 0L, salawatTotal = dhikrTotal[salawat.id] ?: 0L,
                                            salawatTarget = salawat.target,
                                            dhikrToday = dhikrToday.values.sum(),
                                            storySeen = storySeenDay == daily.today()
                                        ),
                                        palette, calendar,
                                        TodayActions(
                                            close = { nav.back() },
                                            story = { i -> daily.storyStart = i; nav.go(ROUTE_STORY) },
                                            fatiha = { nav.go(ROUTE_SURAH) },
                                            azkar = { nav.go(ROUTE_AZKAR) },
                                            salawat = { daily.select(Dhikr.SALAWAT); nav.go(ROUTE_DHIKR) },
                                            dhikr = { nav.go(ROUTE_DHIKR) },
                                            continueLesson = {
                                                val next = learnContent?.course?.next(learnProgress)
                                                if (next != null) openLesson(next.id) else nav.go(ROUTE_COURSE)
                                            },
                                            course = { nav.go(ROUTE_COURSE) },
                                            review = { openLesson(Course.REVIEW_ID) },
                                            dictionary = { nav.go(ROUTE_DICTIONARY) },
                                            surahs = { nav.go(ROUTE_SURAH) },
                                            schedule = { nav.go(TAB_SCHEDULE) }
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
              }
            }
            // A light scrim under the system navigation bar: three-button navigation draws white
            // glyphs, and the horizon of a noon or sunset sky is light enough to swallow them.
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .windowInsetsBottomHeight(WindowInsets.navigationBars)
                    .background(Brush.verticalGradient(listOf(Color(0x14000000), Color(0x59000000))))
            )
        }
    }
}

/** Inside the pulled-up layer: today 0, course/dictionary/surahs 1, a lesson 2. */
internal fun layerDepth(route: String): Int = when (route) {
    ROUTE_TODAY -> 0
    ROUTE_LESSON, ROUTE_STORY -> 2
    else -> 1
}

/** Home 0, the three sections 1, the city picker 2: deeper slides in from the right. */
internal fun routeDepth(route: String): Int = when (route) {
    TAB_HOME -> 0
    ROUTE_CITY -> 2
    else -> 1
}

/** The azkar session the counters belong to: the set and the day its prayer window began. */
internal fun azkarSession(set: AzkarSet, window: com.nur.prayer.core.astro.PrayerWindow): String {
    val day = if (AzkarSet.at(window.current) == set) window.currentStart.toLocalDate() else java.time.LocalDate.now()
    return AzkarSet.sessionKey(set, day)
}

/** Ayah, hadith and dua of the day, then the word of the day from the course lexicon. */
internal fun storySlides(today: Long, content: com.nur.prayer.learn.LearnContent?): List<StorySlide> {
    val base = DailyStories.of(today)
    val w = content?.lexicon?.wordOfDay(today) ?: return base
    return base + StorySlide("Слово дня", w.arabic, w.translit, w.ru, "Словарь курса · " + w.letters.joinToString(" · ") { it.name })
}
