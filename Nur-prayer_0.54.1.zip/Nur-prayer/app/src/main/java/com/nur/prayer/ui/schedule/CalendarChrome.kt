package com.nur.prayer.ui.schedule

import com.nur.prayer.ui.schedule.print.CalendarPaper
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import com.nur.prayer.ui.components.ExitButtonSpec
import com.nur.prayer.i18n.L10n
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material3.LocalTextStyle
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.ui.Format
import java.time.YearMonth
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.foundation.pager.PagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.DockGlyphButton
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.uiScale
import kotlin.math.abs

private val GLYPHS = listOf(GlyphKind.VIEW_YEAR, GlyphKind.VIEW_MONTH, GlyphKind.VIEW_TABLE)

/** A separate rail above the page: controls can never cover a date, even with a large system font. */
@Composable
fun CalendarTopBar(tab: Int, onTab: (Int) -> Unit, tint: Color, modifier: Modifier = Modifier) {
    val labels = listOf(tr("Год"), tr("Месяц"), tr("Таблица"))
    Row(modifier.fillMaxWidth().padding(top = LocalIslandInset.current).testTag("calendar-tabs"),
        horizontalArrangement = Arrangement.Center) {
        GLYPHS.forEachIndexed { index, glyph ->
            val selected = index == tab
            DockGlyphButton(glyph, labels[index], if (selected && tint != Color.White) Color(CalendarPaper.BLUE) else tint,
                { onTab(index) }, Modifier.testTag("calendar-tab-$index"), selectedTab = selected)
        }
    }
}

/** One label for the whole gesture. Neither the title nor its height tracks the thumb. */
@Composable
internal fun SettledMonthBar(pager: PagerState, first: YearMonth, offset: Int, onPick: () -> Unit, ink: Color, subInk: Color) {
    val page = pager.settledPage
    val labels = remember(page, first, offset, L10n.language) {
        val m = PeriodPages.monthAt(first, page)
        "${Format.monthName(m.monthValue)} ${m.year}" to HijriCalendar.span(m.atDay(1), m.atEndOfMonth(), offset)
    }
    val ui = uiScale()
    val measurer = rememberTextMeasurer()
    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = ui.s(12f)).clip(RoundedCornerShape(16.dp))
        .pressClick(role = Role.Button, onClick = onPick).padding(vertical = 2.dp).testTag("calendar-period"),
        contentAlignment = Alignment.Center) {
        val width = constraints.maxWidth
        val reserved = with(LocalDensity.current) { 17.dp.roundToPx() }
        val titleStyle = LocalTextStyle.current.copy(fontSize = ui.t(24f), lineHeight = ui.t(30f), fontWeight = FontWeight.Bold)
        val subStyle = LocalTextStyle.current.copy(fontSize = ui.t(12.5f), lineHeight = ui.t(17f), fontWeight = FontWeight.SemiBold)
        val titleSize = fittedCaption(measurer, labels.first, titleStyle, width - reserved, ui.t(16f))
        val subSize = fittedCaption(measurer, labels.second, subStyle, width, ui.t(9.5f))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(labels.first, Modifier.weight(1f, fill = false).testTag("calendar-month-title"), color = ink,
                    style = titleStyle, fontSize = titleSize, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.width(6.dp))
                Glyph(GlyphKind.CHEVRON, ink.copy(alpha = .7f), Modifier.size(11.dp).graphicsLayer { rotationZ = 90f })
            }
            Text(labels.second, Modifier.padding(top = 2.dp).testTag("calendar-month-span"), color = subInk,
                style = subStyle, fontSize = subSize, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Fit synchronously at the new committed label, without hiding its first frame or onTextLayout retries. */
@Composable
private fun fittedCaption(measurer: TextMeasurer, text: String, style: TextStyle, width: Int, floor: TextUnit): TextUnit =
    remember(measurer, text, style, width, floor) {
        val natural = measurer.measure(AnnotatedString(text), style, softWrap = false, maxLines = 1).size.width.coerceAtLeast(1)
        val ratio = (width.toFloat() / natural).coerceIn(floor.value / style.fontSize.value, 1f)
        style.fontSize * ratio
    }

/**
 * The animated Hijri-year bar: the title ⌄ with the hijri span under it. A tap raises the drums.
 * [ink] and [subInk] follow the backdrop: dark on a light picture, light on a dark one.
 *
 * The bar follows [pager] frame by frame: while the pages move, the titles of the page that leaves and the
 * page that comes are both on screen, each fading and sliding by its distance from the thumb ([PeriodTitleMath]).
 * At rest only the title of the page itself is composed.
 */
@Composable
fun PeriodBar(
    pager: PagerState,
    title: (page: Int) -> String,
    subtitle: (page: Int) -> String,
    onPick: () -> Unit,
    ink: Color,
    subInk: Color,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val moving by remember(pager) { derivedStateOf { abs(pager.currentPageOffsetFraction) > PeriodTitleMath.REST_EPSILON } }
    val current = pager.currentPage
    val from = if (moving) (current - 1).coerceAtLeast(0) else current
    val to = if (moving) (current + 1).coerceAtMost(pager.pageCount - 1) else current
    Box(
        modifier.fillMaxWidth().padding(horizontal = ui.s(12f)).clip(RoundedCornerShape(16.dp))
            .pressClick(role = Role.Button, onClick = onPick).padding(vertical = 2.dp)
            .testTag("calendar-period"),
        contentAlignment = Alignment.Center
    ) {
        for (page in from..to) {
            key(page) {
                Column(
                    Modifier.graphicsLayer {
                        val distance = page - (pager.currentPage + pager.currentPageOffsetFraction)
                        alpha = PeriodTitleMath.alpha(distance)
                        translationX = PeriodTitleMath.shift(distance, size.width)
                    },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AutoSizeText(
                            title(page), color = ink, fontSize = ui.t(24f), minFontSize = ui.t(16f),
                            fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f, fill = false),
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.width(6.dp))
                        Glyph(GlyphKind.CHEVRON, ink.copy(alpha = 0.7f), Modifier.size(11.dp).graphicsLayer { rotationZ = 90f })
                    }
                    AutoSizeText(
                        subtitle(page), color = subInk, fontSize = ui.t(12.5f), minFontSize = ui.t(9.5f),
                        fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }
    }
}

/** The motion of a title in step with the pages, pure so it is unit-tested. [distance] is its page minus the thumb's position. */
object PeriodTitleMath {
    /** Below this the pager is at rest: no neighbour needs to be composed. */
    const val REST_EPSILON = 0.001f
    /** A title sliding by a third of its own width while it fades reads as moving *behind* the pages, not with them. */
    const val SHIFT = 0.33f

    /** 1 at rest, 0 one page away: the title of the page that leaves is gone exactly when the next one is whole. */
    fun alpha(distance: Float): Float = (1f - abs(distance)).coerceIn(0f, 1f)

    fun shift(distance: Float, width: Float): Float = distance.coerceIn(-1f, 1f) * width * SHIFT
}

/** "сегодня" on the selected today, "К сегодня" otherwise: one tag, one place to come back to. */
@Composable
fun CalendarTodayChip(atToday: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Text(
        text = if (atToday) tr("сегодня") else tr("К сегодня"),
        color = Paper.Accent, fontSize = ui.t(11f), fontWeight = FontWeight.SemiBold, maxLines = 1,
        modifier = modifier.clip(CircleShape).background(Paper.Accent.copy(alpha = 0.12f))
            .pressClick(role = Role.Button, onClick = onClick)
            .padding(horizontal = ui.s(11f), vertical = ui.s(5f))
            .testTag("calendar-today")
    )
}

/** Match the Stories action: 144 × 32 dp outline, in a 52 dp hit area. */
@Composable
internal fun CalendarShareButton(tint: Color, enabled: Boolean, onClick: () -> Unit) {
    val feedback = LocalHapticFeedback.current
    Box(Modifier.widthIn(max = 144.dp).fillMaxWidth().height(ExitButtonSpec.Hit).testTag("calendar-share")
        .graphicsLayer { alpha = if (enabled) 1f else .45f }
        .shareTapGuard().clickable(enabled = enabled, role = Role.Button) {
            feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }, contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxWidth().height(ExitButtonSpec.Diameter).background(Color.Black.copy(alpha=.12f), CircleShape)
            .border(1.dp, tint.copy(alpha=.5f), CircleShape).padding(horizontal=8.dp), contentAlignment = Alignment.Center) {
            AutoSizeText(tr("Поделиться").uppercase(L10n.language.locale), color=tint, fontSize=13.sp, fontWeight=FontWeight.Bold)
        }
    }
}
