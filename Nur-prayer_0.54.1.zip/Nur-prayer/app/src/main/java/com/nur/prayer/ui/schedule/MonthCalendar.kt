package com.nur.prayer.ui.schedule

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.theme.uiScale
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth

/** Ink for the open grid follows the wallpaper. The translucent detail card has its own contrast floor. */
internal class MonthInk(val main: Color, val minor: Color, val accent: Color, val event: Color,
                        val card: Color, val line: Color)
internal val MonthNight = MonthInk(Color(0xFFFAF8F4), Color(0xFFCAC9D0), Color(0xFF9EBEFF), Color(0xFFFFB3A6),
    Color(0xDB151620), Color(0x557D8292))
internal val MonthLight = MonthInk(Color(0xFF1A1D25), Color(0xFF465066), Color(0xFF1948BA), Color(0xFF903F36),
    Color(0xEDFAF8F3), Color(0x55747985))
internal val MonthSelection = Color(0xFF1B4BD1)

@Composable
internal fun MonthCalendar(
    month: YearMonth, selected: LocalDate, today: LocalDate, hijriOffset: Int,
    onSelect: (LocalDate) -> Unit, modifier: Modifier = Modifier,
    ink: MonthInk = MonthNight, minRow: Dp = 48.dp
) {
    val ui = uiScale()
    val weekdays = remember(L10n.language) { listOf(tr("Пн"), tr("Вт"), tr("Ср"), tr("Чт"), tr("Пт"), tr("Сб"), tr("Вс")) }
    val cells = remember(month) { CalendarMonthModel.cells(month) }
    val weeks = remember(cells) { cells.chunked(7) }
    // Match IslamicDays.on priority, including Qadr in Ramadan and Arafah in the ten days.
    val events = remember(month, hijriOffset) { CalendarMonthModel.eventPriority(month, hijriOffset) }
    val feedback = LocalHapticFeedback.current
    BoxWithConstraints(modifier.fillMaxWidth().testTag("calendar-grid")) {
        val cellWidth = maxWidth / 7
        val density = LocalDensity.current
        // Respect the system size, bounded only by the actual width of two numerals and their marker.
        val major = with(density) { minOf(ui.t(18f).toDp(), cellWidth * .65f).toSp() }
        val minor = with(density) { minOf(ui.t(11f).toDp(), cellWidth * .44f).toSp() }
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                weekdays.forEachIndexed { i, label -> Text(label, color = if (i == 4) ink.accent else ink.minor,
                    style = TextStyle(fontSize = ui.t(13f), lineHeight = ui.t(16f), fontWeight = FontWeight.SemiBold),
                    textAlign = TextAlign.Center, modifier = Modifier.weight(1f)) }
            }
            weeks.forEach { days ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    days.forEach { date ->
                        // Keep Monday-first positions, but don't repeat dates or expose inactive buttons.
                        if (date.month != month.month) Spacer(Modifier.weight(1f))
                        else DayCell(date, today == date, selected == date, hijriOffset, ink,
                            events.firstOrNull { it.contains(date) }, minRow, major, minor,
                            Modifier.weight(1f), onClick = {
                                feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onSelect(date)
                            })
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(date: LocalDate, isToday: Boolean, isSelected: Boolean, offset: Int, ink: MonthInk,
                    event: DayOccurrence?, minRow: Dp, major: TextUnit, minor: TextUnit, modifier: Modifier, onClick: () -> Unit) {
    val hijri = remember(date, offset) { IslamicDays.hijriOf(date, offset) }
    val fri = date.dayOfWeek == DayOfWeek.FRIDAY
    val shape = RoundedCornerShape(10.dp)
    val mark = if (event != null && event.kind != DayKind.SEASON) ink.event else ink.accent
    // No scale animation, per-cell graphics layer or pressed-state collector while the page is dragged.
    // Format the accessibility label when semantics are read, not when a neighbouring page is composed.
    Box(modifier.heightIn(min = minRow).semantics {
        contentDescription = listOfNotNull(Format.fullDate(date), "${hijri.day} ${HijriCalendar.monthName(hijri.month)} ${hijri.year}",
            if (isToday) tr("сегодня") else null, event?.let { IslamicDayText.title(it.day) }).joinToString(", ")
        selected = isSelected
    }.testTag("calendar-day-$date").clickable(role = Role.Button, onClick = onClick), contentAlignment = Alignment.Center) {
        // No fixed-height inner box and no inherited Material body line height: both baselines are measured.
        Column(Modifier.fillMaxWidth().padding(horizontal = 2.dp, vertical = 1.dp)
            .then(when {
                isSelected -> Modifier.background(MonthSelection, shape)
                isToday -> Modifier.border(1.dp, ink.accent, shape)
                event != null -> Modifier.background(mark.copy(alpha = .13f), shape)
                else -> Modifier
            }).padding(vertical = 3.dp).clearAndSetSemantics { },
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(date.dayOfMonth.toString(), color = if (isSelected) Color.White else ink.main,
                    style = TextStyle(fontSize = major, lineHeight = major * 1.18f, fontWeight = FontWeight.SemiBold), maxLines = 1)
            }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(hijri.day.toString(), color = if (isSelected) Color.White else ink.minor,
                    style = TextStyle(fontSize = minor, lineHeight = minor * 1.2f), maxLines = 1)
                if (fri) Box(Modifier.align(Alignment.CenterStart).padding(start = 2.dp).size(3.dp)
                    .background(if (isSelected) Color.White else ink.accent, CircleShape))
                if (event != null) Box(Modifier.align(Alignment.CenterEnd).padding(end = 2.dp).size(3.dp)
                    .background(if (isSelected) Color(0xFFFFD8CB) else mark, CircleShape))
            }
        }
    }
}
