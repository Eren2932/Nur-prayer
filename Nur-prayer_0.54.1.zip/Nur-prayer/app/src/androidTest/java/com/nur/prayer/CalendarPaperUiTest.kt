package com.nur.prayer

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.activity.result.ActivityResultRegistry
import androidx.activity.result.ActivityResultRegistryOwner
import androidx.activity.result.contract.ActivityResultContract
import androidx.core.app.ActivityOptionsCompat
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.getUnclippedBoundsInRoot
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.click
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeLeft
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.schedule.CalendarImageShare
import com.nur.prayer.ui.schedule.MonthTimes
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.schedule.calendarPage
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.time.YearMonth
import java.time.ZonedDateTime

@RunWith(AndroidJUnit4::class)
class CalendarPaperUiTest {
    @get:Rule val compose = createComposeRule()
    private val moment = ZonedDateTime.parse("2026-11-28T13:00:00+03:00[Europe/Moscow]")
    private fun fixture(moment: ZonedDateTime = this.moment): PrayerData {
        val c = City.MOSCOW
        val settings = AppSettings()
        val params = settings.paramsFor(c.country)
        val place = Place(c.name, c.subtitle, c.country, c.coordinates, c.zone, false)
        return PrayerData(place, PrayerEngine.days(moment.toLocalDate(), 3, c.coordinates, c.zone, params),
            PrayerEngine.window(moment, c.coordinates, c.zone, params), qiblaBearing(c.coordinates),
            distanceToKaabaKm(c.coordinates), HijriCalendar.format(moment.toLocalDate()), settings,
            settings.profileFor(c.country), params)
    }
    private fun awaitTag(tag: String) = compose.waitUntil(10_000) {
        compose.onAllNodesWithTag(tag).fetchSemanticsNodes().isNotEmpty()
    }

    private fun middleFebruary(heightDp: Int = 720): List<Intent> {
        val data = fixture(ZonedDateTime.parse("2027-02-28T13:00:00+03:00[Europe/Moscow]"))
        val sent = java.util.concurrent.CopyOnWriteArrayList<Intent>()
        val registry = object : ActivityResultRegistryOwner {
            override val activityResultRegistry = object : ActivityResultRegistry() {
                override fun <I,O> onLaunch(requestCode: Int, contract: ActivityResultContract<I,O>, input: I, options: ActivityOptionsCompat?) {
                    sent.add(input as Intent)
                    dispatchResult(requestCode, Activity.RESULT_CANCELED, null)
                }
            }
        }
        compose.setContent {
            NurTheme {
                CompositionLocalProvider(LocalActivityResultRegistryOwner provides registry) {
                    Box(Modifier.width(358.dp).height(heightDp.dp)) { ScheduleScreen(data, paletteFor(Prayer.ASR)) }
                }
            }
        }
        awaitTag("month-time-ISHA")
        return sent
    }

    @Test fun verticalMotionAndItsSidewaysTailLeaveMonthAndDockAlone() {
        val sent = middleFebruary()
        val pager = compose.onNodeWithTag("calendar-pager")
        val share = compose.onNodeWithTag("calendar-share")
        val bounds = share.getUnclippedBoundsInRoot()
        val title = compose.onNodeWithTag("calendar-month-title", useUnmergedTree = true)
        val header = title.getUnclippedBoundsInRoot()
        val original = "${Format.monthName(2)} 2027"
        pager.performTouchInput {
            down(Offset(width * .75f, height * .65f))
            moveTo(Offset(width * .74f, height * .45f), 80)
            moveTo(Offset(width * .73f, height * .35f), 80)
            moveTo(Offset(width * .17f, height * .33f), 80)
        }
        title.assertTextEquals(original)
        assertEquals(header, title.getUnclippedBoundsInRoot())
        assertEquals(bounds, share.assertIsEnabled().getUnclippedBoundsInRoot())
        pager.performTouchInput { up() }
        title.assertTextEquals(original)
        // Even a drag entirely inside the dock label is not a share tap.
        share.performTouchInput { down(Offset(width * .20f, center.y)); moveTo(Offset(width * .78f, center.y), 100); up() }
        compose.waitForIdle()
        share.assertIsEnabled()
        assertTrue(sent.isEmpty())
    }

    @Test fun verticalChildStillScrollsWhenMonthDoesNotFit() {
        middleFebruary(490)
        val row = compose.onNodeWithTag("month-time-ISHA")
        val start = row.getUnclippedBoundsInRoot().top
        compose.onNodeWithTag("calendar-pager").performTouchInput {
            down(Offset(center.x,height*.88f)); moveTo(Offset(center.x,height*.56f),75)
            moveTo(Offset(center.x,height*.16f),90); up()
        }
        assertTrue(row.getUnclippedBoundsInRoot().top < start)
        compose.onNodeWithTag("calendar-share").assertIsEnabled()
    }

    @Test fun horizontalHoldShowsOneTitleAndShareWaitsForLandingMonth() {
        val sent = middleFebruary()
        val pager = compose.onNodeWithTag("calendar-pager")
        val share = compose.onNodeWithTag("calendar-share")
        val title = compose.onNodeWithTag("calendar-month-title", useUnmergedTree = true)
        val header = title.getUnclippedBoundsInRoot()
        pager.performTouchInput {
            down(Offset(width*.90f, center.y)); moveTo(Offset(width*.68f, center.y),60)
            moveTo(Offset(width*.14f, center.y),100)
        }
        title.assertTextEquals("${Format.monthName(2)} 2027")
        assertEquals(header, title.getUnclippedBoundsInRoot())
        assertEquals(1, compose.onAllNodesWithTag("calendar-month-span", useUnmergedTree = true).fetchSemanticsNodes().size)
        // Accessibility can activate the dock even with a finger still holding the strip.
        share.assertIsEnabled().performClick()
        share.assertIsNotEnabled()
        assertTrue(sent.isEmpty())
        pager.performTouchInput { up() }
        compose.waitUntil(10_000) { sent.isNotEmpty() }
        title.assertTextEquals("${Format.monthName(3)} 2027")
        assertTrue(stream(sent.single()).lastPathSegment.orEmpty().startsWith("calendar-2027-03-"))
    }

    @Test fun abortedTurnDoesNotChangeTitleOrExport() {
        val sent = middleFebruary()
        val pager = compose.onNodeWithTag("calendar-pager")
        pager.performTouchInput {
            down(Offset(width*.80f, center.y)); moveTo(Offset(width*.54f, center.y),100)
            moveTo(Offset(width*.76f, center.y),100)
        }
        compose.onNodeWithTag("calendar-share").assertIsEnabled().performClick()
        pager.performTouchInput { advanceEventTime(200); up() }
        compose.waitUntil(10_000) { sent.isNotEmpty() }
        compose.onNodeWithTag("calendar-month-title", useUnmergedTree = true).assertTextEquals("${Format.monthName(2)} 2027")
        assertTrue(stream(sent.single()).lastPathSegment.orEmpty().startsWith("calendar-2027-02-"))
    }

    @Test fun middleViewShowsSelectedDaysActualTimesAboveDockAtLargeType() {
        val data = fixture()
        val date = moment.toLocalDate().withDayOfMonth(25)
        val actual = PrayerEngine.day(date, data.place.coordinates, data.place.zone, data.params)
        compose.setContent {
            NurTheme {
                CompositionLocalProvider(LocalDensity provides Density(LocalDensity.current.density, 2f)) {
                    Box(Modifier.width(320.dp).height(640.dp)) { ScheduleScreen(data, paletteFor(Prayer.ASR)) }
                }
            }
        }
        compose.onNodeWithTag("calendar-day-$date").performScrollTo().performClick().assertIsSelected()
        awaitTag("month-time-ISHA")
        val row = compose.onNodeWithTag("month-time-ISHA").performScrollTo().assertIsDisplayed()
        row.assertTextContains(Format.time(requireNotNull(actual.times[Prayer.ISHA])))
        assertTrue(row.getUnclippedBoundsInRoot().bottom <= compose.onNodeWithTag("calendar-share").getUnclippedBoundsInRoot().top)
        compose.onNodeWithTag("calendar-next-event").assertDoesNotExist()
        compose.onNodeWithTag("calendar-details").assertDoesNotExist()
        compose.onNodeWithTag("calendar-period").performClick()
        compose.onNodeWithTag("period-today").performClick()
        compose.onNodeWithTag("calendar-day-${moment.toLocalDate()}").performScrollTo().assertIsSelected()
    }

    @Test fun allDaysFitAndSwipingDoesNotToggleFocusOrOpenShare() {
        val data = fixture()
        var shellHidden = false
        val chooserIntents = java.util.concurrent.CopyOnWriteArrayList<Intent>()
        val testOwner = object : ActivityResultRegistryOwner {
            override val activityResultRegistry = object : ActivityResultRegistry() {
                override fun <I,O> onLaunch(requestCode: Int, contract: ActivityResultContract<I,O>, input: I, options: ActivityOptionsCompat?) {
                    chooserIntents.add(input as Intent)
                    dispatchResult(requestCode, Activity.RESULT_CANCELED, null)
                }
            }
        }
        compose.setContent {
            NurTheme {
                CompositionLocalProvider(LocalDensity provides Density(LocalDensity.current.density, 2f), LocalActivityResultRegistryOwner provides testOwner) {
                    Box(Modifier.width(320.dp).height(520.dp)) {
                        ScheduleScreen(data, paletteFor(Prayer.ASR),
                            onModalChange = { shellHidden = it })
                    }
                }
            }
        }
        compose.onNodeWithTag("calendar-tab-2").performClick()
        awaitTag("table-row-2026-11-30")
        compose.onNodeWithTag("table-row-2026-11-01").assertIsDisplayed()
        compose.onNodeWithTag("table-row-2026-11-30").assertIsDisplayed()
        val viewport = compose.onNodeWithTag("calendar-pager").getUnclippedBoundsInRoot()
        compose.onNodeWithTag("month-table").performTouchInput { click() }
        compose.onNodeWithTag("calendar-tabs").assertDoesNotExist()
        compose.onNodeWithTag("calendar-share").assertDoesNotExist()
        assertEquals(viewport, compose.onNodeWithTag("calendar-pager").getUnclippedBoundsInRoot())
        compose.runOnIdle { assertTrue(shellHidden) }
        compose.onNodeWithTag("calendar-pager").performTouchInput { swipeLeft() }
        awaitTag("table-row-2026-12-31")
        compose.onNodeWithTag("calendar-tabs").assertDoesNotExist()
        compose.onNodeWithTag("month-table").performTouchInput { click() }
        compose.onNodeWithTag("calendar-share").assertIsEnabled().performClick()
        compose.waitUntil(10_000) { chooserIntents.size == 1 }
        assertEquals(Intent.ACTION_CHOOSER, chooserIntents.single().action)
        compose.onNodeWithTag("calendar-export").assertDoesNotExist()
        // Canceling the system chooser leaves both the month and the current page intact.
        compose.onNodeWithTag("table-row-2026-12-31").assertIsDisplayed()
        compose.onNodeWithContentDescription("Выбрать период").performClick()
        compose.onNodeWithTag("period-prev").performClick()
        compose.onNodeWithTag("period-month-2").performScrollTo().performClick().assertIsSelected()
        compose.onNodeWithTag("period-done").performClick()
        awaitTag("table-row-2025-02-28")
        compose.onNodeWithTag("calendar-share").assertIsEnabled().performClick()
        compose.waitUntil(10_000) { chooserIntents.size == 2 }
        assertNotEquals(stream(chooserIntents[0]), stream(chooserIntents[1]))
    }

    @Suppress("DEPRECATION")
    private fun stream(chooser: Intent): Uri {
        val send = requireNotNull(chooser.getParcelableExtra<Intent>(Intent.EXTRA_INTENT))
        assertEquals(Intent.ACTION_SEND, send.action)
        assertEquals("image/png", send.type)
        val uri = requireNotNull(send.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))
        assertEquals(uri, send.clipData?.getItemAt(0)?.uri)
        assertTrue((send.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0)
        return uri
    }

    @Test fun freshFilesRemainReadableThroughChooserUris() {
        val data = fixture()
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        fun prepare(month: YearMonth): CalendarImageShare.Export {
            val days = PrayerEngine.days(month.atDay(1), month.lengthOfMonth(), data.place.coordinates, data.place.zone, data.params)
            val p = calendarPage(MonthTimes(month, days, Prayer.entries), 0, data.place.label, data.params.method, moment.toLocalDate())
            return runBlocking { CalendarImageShare.prepare(ctx, p) }
        }
        val month = YearMonth.from(moment)
        val a = prepare(month)
        val bytes = a.file.readBytes()
        val b = prepare(month.plusMonths(1))
        try {
            assertNotEquals(a.file, b.file)
            assertTrue(bytes.contentEquals(a.file.readBytes()))
            assertTrue(!bytes.contentEquals(b.file.readBytes()))
            val decoded = BitmapFactory.decodeFile(b.file.absolutePath)
            try {
                assertEquals(1440, decoded.width)
                assertEquals(2560, decoded.height)
                val uri = stream(CalendarImageShare.chooser(ctx,b))
                val shared = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                assertTrue(shared.contentEquals(b.file.readBytes()))
            } finally { decoded.recycle() }
        } finally { a.file.delete(); b.file.delete() }
    }
}
