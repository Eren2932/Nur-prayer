package com.nur.prayer.icon

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.nur.prayer.R
import com.nur.prayer.i18n.tr

/** Menu order is product-facing. The alias is an installed Android component: never rename it. */
enum class AppIcon(val id: String, val alias: String, val launcher: Int) {
    NUR("nur", "Nur", R.mipmap.ic_launcher_nur),
    DUNES("dunes", "Dunes", R.mipmap.ic_launcher_dunes),
    ZELLIJ("zellij", "Zellij", R.mipmap.ic_launcher_zellij),
    OLIVE("olive", "Olive", R.mipmap.ic_launcher_olive),
    IKAT("ikat", "Ikat", R.mipmap.ic_launcher_ikat),
    COBALT("cobalt", "Cobalt", R.mipmap.ic_launcher_cobalt),
    KISWA("kiswa", "Kiswa", R.mipmap.ic_launcher_kiswa),
    EBRU("ebru", "Ebru", R.mipmap.ic_launcher_ebru),
    ARCADE("arcade", "Arcade", R.mipmap.ic_launcher_arcade),
    POLE("pole", "Pole", R.mipmap.ic_launcher_pole);

    companion object {
        val DEFAULT = NUR
        internal val byAlias = entries.associateBy { it.alias }
        fun of(id: String?): AppIcon? = entries.firstOrNull { it.id == id }
    }
}

fun AppIcon.title(): String = when (this) {
    AppIcon.NUR -> tr("Нур")
    AppIcon.DUNES -> tr("Дюны")
    AppIcon.ZELLIJ -> tr("Зеллидж")
    AppIcon.OLIVE -> tr("Олива")
    AppIcon.IKAT -> tr("Икат")
    AppIcon.COBALT -> tr("Кобальт")
    AppIcon.KISWA -> tr("Кисва")
    AppIcon.EBRU -> tr("Эбру")
    AppIcon.ARCADE -> tr("Аркада")
    AppIcon.POLE -> tr("Полюс")
}

/** Retired artwork has no equivalent in the new catalog. Its upgrade destination is always Nur. */
internal val retiredLauncherAliases = listOf("Pearl", "Fajr", "Emerald", "Gold", "Midnight", "Lagoon",
    "Maghrib", "Garnet", "Aurora", "Sand", "Graphite")

internal fun currentArtwork(enabled: List<String>): AppIcon =
    enabled.firstNotNullOfOrNull { name -> AppIcon.byAlias[name]?.takeIf { it != AppIcon.DEFAULT } } ?: AppIcon.DEFAULT

/** On pre-33 systems the first operation must enable the new entry before disabling the old one. */
internal fun planAliasChange(enabled: List<String>, target: AppIcon): List<Pair<String, Boolean>> {
    if (enabled.size == 1 && enabled[0] == target.alias) return emptyList()
    val changes = mutableListOf<Pair<String, Boolean>>()
    if (target.alias !in enabled) changes.add(target.alias to true)
    for (alias in enabled) if (alias != target.alias) changes.add(alias to false)
    return changes
}

object AppIconSwitcher {
    private const val PREFS = "launcher_icon"
    private const val KEY_MIGRATED = "atlas_0520_migrated"
    private const val KEY_PENDING = "pending"
    private const val ALIAS_PACKAGE = "com.nur.prayer.launcher."

    fun selected(context: Context): AppIcon = pending(context) ?: applied(context)

    fun select(context: Context, icon: AppIcon) {
        prefs(context).edit().putString(KEY_PENDING, icon.id).apply()
    }

    /** Deferred until onStop. On old firmware change enable-first; on 33+ make one atomic change. */
    fun applyPending(context: Context) {
        val prefs = prefs(context)
        val raw = prefs.getString(KEY_PENDING, null)
        val migrated = prefs.getBoolean(KEY_MIGRATED, false)
        if (raw == null && migrated) return
        val pm = context.packageManager
        val enabled = enabledAliases(context, includeRetired = !migrated)
        val target = if (raw == null) currentArtwork(enabled) else AppIcon.of(raw) ?: AppIcon.DEFAULT
        val changes = planAliasChange(enabled, target).map { (alias, enable) ->
            val state = if (enable) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            component(context, alias) to state
        }
        if (changes.isNotEmpty()) {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.setComponentEnabledSettings(changes.map { (name, state) ->
                    PackageManager.ComponentEnabledSetting(name, state, PackageManager.DONT_KILL_APP)
                })
            } else {
                for ((name, state) in changes) pm.setComponentEnabledSetting(name, state, PackageManager.DONT_KILL_APP)
            }
        }
        // If a PM operation fails, do not erase the pending choice: onStop can retry.
        prefs.edit().remove(KEY_PENDING).putBoolean(KEY_MIGRATED, true).apply()
    }

    // The picker never enumerates or exposes retired names. A legacy-only state reads as default.
    private fun applied(context: Context): AppIcon = currentArtwork(enabledAliases(context, includeRetired = false))

    private fun enabledAliases(context: Context, includeRetired: Boolean): List<String> {
        val names = if (includeRetired) AppIcon.byAlias.keys + retiredLauncherAliases else AppIcon.byAlias.keys
        return names.filter { alias ->
            when (context.packageManager.getComponentEnabledSetting(component(context, alias))) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
                PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> alias == AppIcon.DEFAULT.alias
                else -> false
            }
        }
    }

    private fun component(context: Context, alias: String) = ComponentName(context.packageName, ALIAS_PACKAGE + alias)
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun pending(context: Context): AppIcon? = AppIcon.of(prefs(context).getString(KEY_PENDING, null))
}
