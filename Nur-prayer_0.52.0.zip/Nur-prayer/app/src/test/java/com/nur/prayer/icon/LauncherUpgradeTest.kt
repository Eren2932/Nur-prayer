package com.nur.prayer.icon

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LauncherUpgradeTest {
    @Test fun eachOldAliasAndPendingPreferenceStillWorks() {
        val frozen = listOf("Nur", "Pearl", "Fajr", "Emerald", "Gold", "Midnight", "Lagoon", "Maghrib", "Garnet", "Aurora", "Sand", "Graphite")
        assertEquals(frozen.toSet() - "Nur", retiredLauncherAliases.toSet())
        assertEquals(10, AppIcon.byAlias.size)
        for (alias in frozen) {
            val legacyId = alias.lowercase(java.util.Locale.ROOT)
            if (alias != "Nur") assertNull(AppIcon.of(legacyId))
            assertEquals(AppIcon.DEFAULT, currentArtwork(listOf(alias)))
            for (target in AppIcon.entries) verify(listOf(alias), target)
        }
        for (alias in AppIcon.byAlias.keys) {
            for (target in AppIcon.entries) verify(listOf(alias), target)
        }
    }

    @Test fun interruptedEnableFirstAndEmptyStateCanBeRepaired() {
        for (target in AppIcon.entries) {
            assertNotNull(AppIcon.of(target.id))
            verify(listOf("Nur", "Graphite"), target)
            verify(emptyList(), target)
        }
    }

    private fun verify(start: List<String>, target: AppIcon) {
        val active = start.toMutableSet()
        for ((alias, enable) in planAliasChange(start, target)) {
            if (enable) active.add(alias) else active.remove(alias)
            assertTrue("legacy sequential PM must not remove the last home entry", active.isNotEmpty())
        }
        assertEquals(target.alias, active.single())
    }
}
