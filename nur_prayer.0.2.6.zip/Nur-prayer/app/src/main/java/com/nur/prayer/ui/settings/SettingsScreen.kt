package com.nur.prayer.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.core.astro.TimeSource
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Caption
import com.nur.prayer.ui.components.ChoiceRow
import com.nur.prayer.ui.components.ExpandableSection
import com.nur.prayer.ui.components.FactRow
import com.nur.prayer.ui.components.GlassPanel
import com.nur.prayer.ui.components.HairRule
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.PanelLevel
import com.nur.prayer.ui.components.SectionLabel
import com.nur.prayer.ui.components.SegmentedControl
import com.nur.prayer.ui.components.StepperField
import com.nur.prayer.ui.components.SwitchRow
import com.nur.prayer.ui.components.nurPanel
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/**
 * Settings.
 *
 * ### The problem this screen had
 *
 * Every choice was rendered open: twelve calculation methods, five high-latitude rules, three rounding
 * modes, five notification switches, seven correction steppers. Around sixty rows, roughly four and a
 * half screens of scroll — and, the real damage, the current state of the app was invisible. To learn
 * which method was active you had to scroll a list of twelve looking for a tick.
 *
 * ### The layout now
 *
 * Every group is one row that *states its own answer* ("Метод расчёта — ДУМ РТ"), and opens only when
 * tapped. Exactly one group is open at a time, which is both a UI decision (you cannot lose yourself
 * in two long lists at once) and a performance one: the composition stays a fraction of its old size,
 * and `LazyColumn` only measures what is on screen.
 *
 * That collapses the screen to about one and a third viewports, and "what is this app currently doing"
 * becomes readable without a single tap.
 *
 * ### On the controls
 *
 * Short choices (madhab, rounding) became segmented controls: the whole choice space on one line beats
 * n rows of which n − 1 are noise. Long choices keep a list, but selection is marked with an accent
 * rail instead of a tinted rectangle — twelve tinted rectangles read as a heat map. Steppers are welded
 * into one −/value/+ group each. Nothing here is "liquid glass" any more; the reasoning is on
 * `GlassPanel`.
 */
@Composable
fun SettingsScreen(
    data: PrayerData,
    palette: PhasePalette,
    actions: AppActions,
    exactAlarmsAllowed: Boolean,
    locating: Boolean = false,
    locationStatus: String? = null,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val dockInset = LocalDockInset.current
    val settings = data.settings
    val accent = palette.accent

    // Survives rotation and process death, so coming back to the app does not silently collapse the
    // group the user was working in.
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    val toggle: (String) -> Unit = { key -> open = if (open == key) null else key }

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(
            start = ui.s(20f),
            end = ui.s(20f),
            top = ui.s(6f),
            bottom = dockInset
        ),
        verticalArrangement = Arrangement.spacedBy(ui.s(10f))
    ) {
        item(key = "title") {
            Column(modifier = Modifier.padding(bottom = ui.s(2f))) {
                AutoSizeText(
                    text = "Настройки",
                    color = TextPrimary,
                    fontSize = ui.t(26f),
                    minFontSize = ui.t(19f),
                    fontWeight = FontWeight.SemiBold
                )
                AutoSizeText(
                    text = "Всё считается офлайн, на устройстве",
                    color = TextTertiary,
                    fontSize = ui.t(12f),
                    minFontSize = ui.t(9.5f),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        /* -- Location -------------------------------------------------------------------------- */
        item(key = "place") {
            GlassPanel(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = ui.s(16f),
                corner = ui.s(20f)
            ) {
                Column {
                    SectionLabel("Местоположение")
                    Spacer(Modifier.height(ui.s(10f)))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(ui.s(14f)))
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { actions.openCityPicker() }
                            .padding(vertical = ui.s(8f)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(ui.s(8f))
                                .clip(CircleShape)
                                .background(accent)
                        )
                        Spacer(Modifier.width(ui.s(11f)))
                        Column(Modifier.weight(1f)) {
                            AutoSizeText(
                                text = data.place.label,
                                color = TextPrimary,
                                fontSize = ui.t(15.5f),
                                minFontSize = ui.t(12f),
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.fillMaxWidth()
                            )
                            AutoSizeText(
                                text = data.place.subtitle,
                                color = TextTertiary,
                                fontSize = ui.t(11f),
                                minFontSize = ui.t(9f),
                                maxLines = 2,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Spacer(Modifier.width(ui.s(8f)))
                        Text("изменить", color = palette.accentSoft, fontSize = ui.t(11.5f))
                    }
                    Spacer(Modifier.height(ui.s(10f)))
                    NurButton(
                        text = if (locating) "Ищем спутники…" else "Определить по местоположению",
                        accent = accent,
                        onClick = { actions.requestLocation() },
                        enabled = !locating
                    )
                    if (locationStatus != null) {
                        Spacer(Modifier.height(ui.s(8f)))
                        Caption(locationStatus)
                    }
                }
            }
        }

        /* -- Calculation method ---------------------------------------------------------------- */
        item(key = "method") {
            ExpandableSection(
                title = "Метод расчёта",
                value = settings.method.title,
                expanded = open == "method",
                accent = accent,
                onToggle = { toggle("method") }
            ) {
                Column {
                    CalculationMethod.entries.forEach { method ->
                        ChoiceRow(
                            title = method.title,
                            subtitle = subtitleFor(method),
                            selected = settings.method == method,
                            accent = accent,
                            onClick = { actions.setMethod(method) }
                        )
                    }
                    HairRule()
                    Caption(
                        "Углы указаны у каждого метода: это единственный честный способ увидеть, что " +
                            "переключатель меняет арифметику, а не подпись."
                    )
                }
            }
        }

        /* -- Madhab ---------------------------------------------------------------------------- */
        item(key = "madhab") {
            ExpandableSection(
                title = "Мазхаб · время Асра",
                value = if (settings.madhab == Madhab.HANAFI) "Ханафитский" else "Шафиитский",
                expanded = open == "madhab",
                accent = accent,
                onToggle = { toggle("madhab") }
            ) {
                Column {
                    SegmentedControl(
                        options = listOf("Ханафитский", "Шафиитский"),
                        selectedIndex = if (settings.madhab == Madhab.HANAFI) 0 else 1,
                        accent = accent,
                        onSelect = { index ->
                            actions.setMadhab(if (index == 0) Madhab.HANAFI else Madhab.STANDARD)
                        }
                    )
                    Spacer(Modifier.height(ui.s(10f)))
                    Caption(
                        "Ханафитский Аср наступает позже: тень предмета должна вырасти до двух его " +
                            "высот вместо одной."
                    )
                }
            }
        }

        /* -- High latitudes -------------------------------------------------------------------- */
        item(key = "highlat") {
            ExpandableSection(
                title = "Высокие широты",
                value = ruleTitle(settings.highLatitudeRule),
                expanded = open == "highlat",
                accent = accent,
                onToggle = { toggle("highlat") }
            ) {
                Column {
                    HighLatitudeRule.entries.forEach { rule ->
                        ChoiceRow(
                            title = ruleTitle(rule),
                            subtitle = ruleSubtitle(rule),
                            selected = settings.highLatitudeRule == rule,
                            accent = accent,
                            onClick = { actions.setHighLatitudeRule(rule) }
                        )
                    }
                    HairRule()
                    Caption(
                        "Правило из этого списка — запасной вариант, а не потолок: оно включается " +
                            "только в те дни, когда солнце физически не доходит до угла метода."
                    )
                }
            }
        }

        /* -- Rounding -------------------------------------------------------------------------- */
        item(key = "rounding") {
            ExpandableSection(
                title = "Округление секунд",
                value = settings.rounding.title,
                expanded = open == "rounding",
                accent = accent,
                onToggle = { toggle("rounding") }
            ) {
                Column {
                    SegmentedControl(
                        options = listOf("Ближайшая", "Вверх", "Вниз"),
                        selectedIndex = RoundingMode.entries.indexOf(settings.rounding),
                        accent = accent,
                        onSelect = { index -> actions.setRounding(RoundingMode.entries[index]) }
                    )
                    Spacer(Modifier.height(ui.s(10f)))
                    Caption(settings.rounding.explanation, color = TextSecondary)
                    Spacer(Modifier.height(ui.s(6f)))
                    Caption(
                        "Расхождение в одну минуту между двумя приложениями в одном городе почти " +
                            "всегда именно это: секунды упали по разные стороны границы минуты."
                    )
                }
            }
        }

        /* -- Notifications --------------------------------------------------------------------- */
        item(key = "notify") {
            val on = Prayer.entries.count { it.isPrayer && settings.notifications[it] == true }
            val total = Prayer.entries.count { it.isPrayer }
            val lead = if (settings.preAlertMinutes > 0) " · за ${settings.preAlertMinutes} мин" else ""
            ExpandableSection(
                title = "Уведомления",
                value = if (exactAlarmsAllowed) "$on из $total$lead"
                else "$on из $total$lead · нет точных будильников",
                expanded = open == "notify",
                accent = if (exactAlarmsAllowed) accent else Crimson,
                onToggle = { toggle("notify") }
            ) {
                Column {
                    if (!exactAlarmsAllowed) {
                        WarningBlock(
                            text = "Android запрещает приложению точные будильники. Без этого " +
                                "разрешения уведомление может опоздать на несколько минут.",
                            actionText = "Разрешить точные будильники",
                            onClick = { actions.openExactAlarmSettings() }
                        )
                        Spacer(Modifier.height(ui.s(12f)))
                    }
                    Prayer.entries.filter { it.isPrayer }.forEach { prayer ->
                        SwitchRow(
                            title = PrayerLabels.title(prayer),
                            subtitle = PrayerLabels.hint(prayer),
                            checked = settings.notifications[prayer] == true,
                            accent = accent,
                            onCheckedChange = { actions.setNotification(prayer, it) }
                        )
                    }
                    HairRule()
                    StepperField(
                        label = "Напомнить заранее",
                        value = "${settings.preAlertMinutes} мин",
                        accent = accent,
                        onMinus = { actions.setPreAlert(settings.preAlertMinutes - 5) },
                        onPlus = { actions.setPreAlert(settings.preAlertMinutes + 5) }
                    )
                    SwitchRow(
                        title = "Без звука",
                        subtitle = "Только вибрация и всплывающее уведомление",
                        checked = settings.silentNotifications,
                        accent = accent,
                        onCheckedChange = { actions.setSilent(it) }
                    )
                    Spacer(Modifier.height(ui.s(10f)))
                    NurButton(
                        text = "Отключить экономию батареи для Nur",
                        accent = accent,
                        onClick = { actions.openBatterySettings() }
                    )
                    Spacer(Modifier.height(ui.s(8f)))
                    Caption(
                        "Xiaomi, Huawei, Samsung и Oppo выгружают фоновые процессы: разрешите " +
                            "автозапуск и снимите ограничения батареи, иначе система задержит любое " +
                            "уведомление."
                    )
                }
            }
        }

        /* -- Manual corrections ---------------------------------------------------------------- */
        item(key = "offsets") {
            val edited = Prayer.entries.filter { (settings.offsets[it] ?: 0) != 0 }
            ExpandableSection(
                title = "Ручная коррекция",
                value = when {
                    edited.isEmpty() && settings.hijriOffset == 0 -> "без правок"
                    edited.isEmpty() -> "хиджра ${signed(settings.hijriOffset)} дн."
                    else -> edited.joinToString(", ") {
                        "${PrayerLabels.title(it)} ${signed(settings.offsets[it] ?: 0)}"
                    }
                },
                expanded = open == "offsets",
                accent = accent,
                onToggle = { toggle("offsets") }
            ) {
                Column {
                    Prayer.entries.forEach { prayer ->
                        val value = settings.offsets[prayer] ?: 0
                        StepperField(
                            label = PrayerLabels.title(prayer),
                            value = "${signed(value)} мин",
                            accent = accent,
                            onMinus = { actions.setOffset(prayer, value - 1) },
                            onPlus = { actions.setOffset(prayer, value + 1) }
                        )
                    }
                    HairRule()
                    StepperField(
                        label = "Сдвиг даты по хиджре",
                        value = "${signed(settings.hijriOffset)} дн.",
                        accent = accent,
                        onMinus = { actions.setHijriOffset(settings.hijriOffset - 1) },
                        onPlus = { actions.setHijriOffset(settings.hijriOffset + 1) }
                    )
                    Spacer(Modifier.height(ui.s(8f)))
                    Caption(
                        "Сверьте расписание со своей мечетью и выровняйте разницу здесь: коррекция " +
                            "применяется и к уведомлениям."
                    )
                }
            }
        }

        /* -- About the calculation ------------------------------------------------------------- */
        item(key = "about") {
            ExpandableSection(
                title = "О расчёте",
                value = "${settings.method.angleSummary} · ${data.place.zone.id}",
                expanded = open == "about",
                accent = accent,
                onToggle = { toggle("about") }
            ) {
                Column {
                    FactRow(
                        "Координаты",
                        format(data.place.coordinates.latitude) + ", " +
                            format(data.place.coordinates.longitude)
                    )
                    FactRow("Часовой пояс", data.place.zone.id)
                    FactRow("Пояс определён", zoneSourceLabel(data.place.zoneSource))
                    data.place.accuracyMeters?.let { FactRow("Точность точки", "±${it.toInt()} м") }
                    FactRow("Азимут кыблы", "${Math.round(data.qibla)}°")
                    FactRow("Углы метода", settings.method.angleSummary)
                    FactRow("Сухур сегодня", sourceLabel(data.today.saharSource))
                    FactRow("Фаджр сегодня", sourceLabel(data.today.fajrSource))
                    FactRow("Иша сегодня", sourceLabel(data.today.ishaSource))
                    data.place.zoneExplanation.takeIf { it.isNotEmpty() }?.let {
                        HairRule()
                        Caption(it, color = TextSecondary)
                    }
                    data.today.note?.let {
                        HairRule()
                        Caption(it, color = TextSecondary)
                    }
                    HairRule()
                    Caption(
                        "Алгоритм: астрономические формулы Жана Мееса (Astronomical Algorithms, 2-е " +
                            "изд.), точность солнечных событий — единицы секунд. Каждое пересечение " +
                            "проверяется по высоте солнца — и по смене знака остатка, поэтому " +
                            "касание угла в белую ночь больше не выдаётся за наступление времени. " +
                            "Nur 0.2.6"
                    )
                }
            }
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * Local pieces
 * ---------------------------------------------------------------------------------------------- */

/** A signed number states a direction, so the plus sign is never dropped. */
private fun signed(value: Int): String = if (value > 0) "+$value" else "$value"

private fun format(value: Double): String = String.format(java.util.Locale.US, "%.4f", value)

@Composable
private fun WarningBlock(text: String, actionText: String, onClick: () -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(ui.s(16f))
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .nurPanel(shape, PanelLevel.FLAT, Crimson)
            .padding(ui.s(13f))
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(ui.s(7f))
                    .clip(CircleShape)
                    .background(Crimson)
            )
            Spacer(Modifier.width(ui.s(8f)))
            Text(
                text = "Требуется разрешение",
                color = Crimson,
                fontSize = ui.t(11.5f),
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(Modifier.height(ui.s(7f)))
        Text(text = text, color = TextSecondary, fontSize = ui.t(12f), lineHeight = ui.t(16.5f))
        Spacer(Modifier.height(ui.s(11f)))
        NurButton(text = actionText, accent = Crimson, onClick = onClick, primary = true)
    }
}

private fun subtitleFor(method: CalculationMethod): String {
    val hint = when (method) {
        CalculationMethod.RUSSIA_DUM -> "Россия и СНГ"
        CalculationMethod.SPIRITUAL_BOARD_TATARSTAN -> "Сверено с календарём ДУМ РТ"
        CalculationMethod.UMM_AL_QURA -> "Саудовская Аравия"
        CalculationMethod.TURKEY -> "С поправками Diyanet"
        else -> null
    }
    return if (hint == null) method.angleSummary else "$hint · ${method.angleSummary}"
}

private fun ruleTitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> "Автоматически"
    HighLatitudeRule.FIXED_INTERVAL -> "Фиксированный интервал (ДУМ РФ)"
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> "Середина ночи"
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> "Одна седьмая ночи"
    HighLatitudeRule.TWILIGHT_ANGLE -> "Пропорция по углу сумерек"
}

private fun ruleSubtitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> "Выше 48° широты — фиксированный интервал, иначе середина ночи"
    HighLatitudeRule.FIXED_INTERVAL -> "Восход − 120 мин и закат + 90 мин, как печатает ДУМ РТ"
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> "Фаджр и Иша не переходят середину ночи"
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> "Классическая доля ночи 1/7"
    HighLatitudeRule.TWILIGHT_ANGLE -> "Доля ночи пропорциональна углу метода"
}

/**
 * Plain words for where today's Sahar / Fajr / Isha actually came from.
 *
 * Exhaustive on purpose, with no `else` branch: when a new [TimeSource] appears, this has to fail to
 * compile, so the explanation shown to the user cannot quietly fall behind the engine. That is exactly
 * what happened when CONGREGATION and DAWN_BOUND were added — and it is why `tools/kt_sanity.py` now
 * catches this class of error before Gradle does.
 */
/**
 * Which piece of evidence decided the time zone.
 *
 * Worth a row of its own: a zone taken from longitude means the app is guessing within an hour, and
 * the user is the only one who can tell it the truth by picking a city.
 */
private fun zoneSourceLabel(source: com.nur.prayer.location.ZoneSource): String = when (source) {
    com.nur.prayer.location.ZoneSource.DEVICE -> "по часам телефона"
    com.nur.prayer.location.ZoneSource.NEIGHBOURHOOD -> "по городам рядом"
    com.nur.prayer.location.ZoneSource.LONGITUDE -> "по долготе (приближённо)"
}

private fun sourceLabel(source: TimeSource): String = when (source) {
    TimeSource.ANGLE -> "по углу солнца"
    TimeSource.METHOD_INTERVAL -> "интервал метода"
    TimeSource.FIXED_INTERVAL -> "фикс. интервал (короткая ночь)"
    TimeSource.NIGHT_FRACTION -> "доля ночи (короткая ночь)"
    TimeSource.MIDNIGHT_BOUND -> "ограничено серединой ночи"
    TimeSource.CONGREGATION -> "как в мечети: восход − 90 мин"
    TimeSource.DAWN_BOUND -> "поднято до рассвета"
}
