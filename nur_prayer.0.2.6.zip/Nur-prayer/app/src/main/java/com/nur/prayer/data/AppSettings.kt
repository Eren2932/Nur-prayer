package com.nur.prayer.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.CalendarConvention
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerParams
import com.nur.prayer.core.astro.RoundingMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("nur_settings")

/** Everything the user can tune. */
@androidx.compose.runtime.Immutable
data class AppSettings(
    val cityId: Int = City.MOSCOW.id,
    val useDeviceLocation: Boolean = false,
    val manualLatitude: Double? = null,
    val manualLongitude: Double? = null,
    /**
     * Radius of the stored fix in metres, and when it was taken.
     *
     * Both are persisted because both are shown: a location the app cannot describe is a location
     * the user cannot judge. The timestamp also drives expiry — a fix older than
     * [STALE_FIX_MILLIS] is re-asked for on the next return to the app instead of being trusted
     * forever, which is what 0.2.5 did to anyone who travelled.
     */
    val locationAccuracyMeters: Double? = null,
    val locationFixedAtMillis: Long? = null,
    val method: CalculationMethod = CalculationMethod.RUSSIA_DUM,
    val madhab: Madhab = Madhab.HANAFI,
    val highLatitudeRule: HighLatitudeRule = HighLatitudeRule.AUTO,
    val rounding: RoundingMode = RoundingMode.NEAREST,
    val convention: CalendarConvention = CalendarConvention.DUM_RT,
    /** null = keep the method default gap between congregational Fajr and sunrise. */
    val congregationalFajrMinutes: Int? = null,
    val offsets: Map<Prayer, Int> = emptyMap(),
    val notifications: Map<Prayer, Boolean> = Prayer.entries.associateWith { it.isPrayer },
    val preAlertMinutes: Int = 0,
    val silentNotifications: Boolean = false,
    val hijriOffset: Int = 0
) {
    /** True when the stored fix is old enough that the user has plausibly moved. */
    val locationIsStale: Boolean
        get() = useDeviceLocation && (
            locationFixedAtMillis == null ||
                System.currentTimeMillis() - locationFixedAtMillis > STALE_FIX_MILLIS
            )

    val params: PrayerParams
        get() = PrayerParams(
            method = method,
            madhab = madhab,
            highLatitudeRule = highLatitudeRule,
            rounding = rounding,
            convention = convention,
            congregationalFajrMinutes = congregationalFajrMinutes,
            userAdjustments = offsets
        )

    companion object {
        /** Six hours: long enough for a day in one city, short enough to catch a flight. */
        const val STALE_FIX_MILLIS = 6 * 60 * 60 * 1000L
    }
}

class SettingsRepository(private val context: Context) {

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs -> prefs.toSettings() }

    private fun Preferences.toSettings(): AppSettings = AppSettings(
        cityId = this[Keys.cityId] ?: City.MOSCOW.id,
        useDeviceLocation = this[Keys.useDeviceLocation] ?: false,
        manualLatitude = this[Keys.manualLat]?.toDoubleOrNull(),
        manualLongitude = this[Keys.manualLon]?.toDoubleOrNull(),
        locationAccuracyMeters = this[Keys.locationAccuracy]?.toDoubleOrNull(),
        locationFixedAtMillis = this[Keys.locationFixedAt]?.takeIf { it > 0L },
        method = this[Keys.method]?.let { runCatching { CalculationMethod.valueOf(it) }.getOrNull() }
            ?: CalculationMethod.RUSSIA_DUM,
        madhab = this[Keys.madhab]?.let { runCatching { Madhab.valueOf(it) }.getOrNull() } ?: Madhab.HANAFI,
        highLatitudeRule = this[Keys.highLat]?.let { runCatching { HighLatitudeRule.valueOf(it) }.getOrNull() }
            ?: HighLatitudeRule.AUTO,
        rounding = this[Keys.rounding]?.let { runCatching { RoundingMode.valueOf(it) }.getOrNull() }
            ?: RoundingMode.NEAREST,
        convention = this[Keys.convention]?.let { runCatching { CalendarConvention.valueOf(it) }.getOrNull() }
            ?: CalendarConvention.DUM_RT,
        congregationalFajrMinutes = this[Keys.congregationalFajr]?.takeIf { it >= 0 },
        offsets = Prayer.entries.associateWith { (this[Keys.offset(it)] ?: 0) },
        notifications = Prayer.entries.associateWith { (this[Keys.notify(it)] ?: it.isPrayer) },
        preAlertMinutes = this[Keys.preAlert] ?: 0,
        silentNotifications = this[Keys.silent] ?: false,
        hijriOffset = this[Keys.hijriOffset] ?: 0
    )

    suspend fun setCity(city: City) = context.dataStore.edit {
        it[Keys.cityId] = city.id
        it[Keys.useDeviceLocation] = false
    }

    suspend fun setUseDeviceLocation(enabled: Boolean) = context.dataStore.edit {
        it[Keys.useDeviceLocation] = enabled
    }

    suspend fun setDeviceLocation(
        latitude: Double,
        longitude: Double,
        nearestCityId: Int,
        accuracyMeters: Double,
        fixedAtMillis: Long
    ) = context.dataStore.edit {
        it[Keys.manualLat] = latitude.toString()
        it[Keys.manualLon] = longitude.toString()
        it[Keys.cityId] = nearestCityId
        it[Keys.useDeviceLocation] = true
        it[Keys.locationAccuracy] = accuracyMeters.toString()
        it[Keys.locationFixedAt] = fixedAtMillis
    }

    suspend fun setMethod(method: CalculationMethod) = context.dataStore.edit {
        it[Keys.method] = method.name
    }

    suspend fun setMadhab(madhab: Madhab) = context.dataStore.edit { it[Keys.madhab] = madhab.name }

    suspend fun setHighLatitudeRule(rule: HighLatitudeRule) = context.dataStore.edit {
        it[Keys.highLat] = rule.name
    }

    suspend fun setRounding(mode: RoundingMode) = context.dataStore.edit {
        it[Keys.rounding] = mode.name
    }

    suspend fun setConvention(convention: CalendarConvention) = context.dataStore.edit {
        it[Keys.convention] = convention.name
    }

    /** Pass null to fall back to the gap the calculation method defines. */
    suspend fun setCongregationalFajrMinutes(minutes: Int?) = context.dataStore.edit {
        it[Keys.congregationalFajr] = minutes?.coerceIn(0, 240) ?: -1
    }

    suspend fun setOffset(prayer: Prayer, minutes: Int) = context.dataStore.edit {
        it[Keys.offset(prayer)] = minutes.coerceIn(-60, 60)
    }

    suspend fun setNotification(prayer: Prayer, enabled: Boolean) = context.dataStore.edit {
        it[Keys.notify(prayer)] = enabled
    }

    suspend fun setPreAlert(minutes: Int) = context.dataStore.edit {
        it[Keys.preAlert] = minutes.coerceIn(0, 60)
    }

    suspend fun setSilent(silent: Boolean) = context.dataStore.edit { it[Keys.silent] = silent }

    suspend fun setHijriOffset(days: Int) = context.dataStore.edit {
        it[Keys.hijriOffset] = days.coerceIn(-2, 2)
    }

    private object Keys {
        val cityId = intPreferencesKey("city_id")
        val useDeviceLocation = booleanPreferencesKey("use_device_location")
        val manualLat = stringPreferencesKey("manual_lat")
        val manualLon = stringPreferencesKey("manual_lon")
        val locationAccuracy = stringPreferencesKey("location_accuracy_m")
        val locationFixedAt = longPreferencesKey("location_fixed_at")
        val method = stringPreferencesKey("method")
        val madhab = stringPreferencesKey("madhab")
        val highLat = stringPreferencesKey("high_lat")
        val rounding = stringPreferencesKey("rounding")
        val convention = stringPreferencesKey("convention")
        val congregationalFajr = intPreferencesKey("congregational_fajr")
        val preAlert = intPreferencesKey("pre_alert")
        val silent = booleanPreferencesKey("silent")
        val hijriOffset = intPreferencesKey("hijri_offset")
        fun offset(prayer: Prayer) = intPreferencesKey("offset_${prayer.name}")
        fun notify(prayer: Prayer) = booleanPreferencesKey("notify_${prayer.name}")
    }
}
