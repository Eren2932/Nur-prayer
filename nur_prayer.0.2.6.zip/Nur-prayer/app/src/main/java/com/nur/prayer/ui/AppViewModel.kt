package com.nur.prayer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nur.prayer.Graph
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.PrayerWindow
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.data.PlaceResolver
import com.nur.prayer.location.LocationOutcome
import com.nur.prayer.location.LocationProvider
import com.nur.prayer.notify.PrayerAlarmScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZonedDateTime

/** Everything the screens need, computed once per settings change. */
@androidx.compose.runtime.Immutable
data class PrayerData(
    val place: Place,
    val days: List<PrayerDay>,
    val window: PrayerWindow,
    val qibla: Double,
    val kaabaDistanceKm: Double,
    val hijri: String,
    val settings: AppSettings
) {
    val today: PrayerDay get() = days.first()
}

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val app: Application = application
    private val settingsRepository = Graph.settings(application)
    private val cityRepository = Graph.cities(application)
    private val locationProvider = LocationProvider(application)

    private val refreshTrigger = MutableStateFlow(0)

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val data: StateFlow<PrayerData?> = combine(settingsRepository.settings, refreshTrigger) { s, _ -> s }
        .map { s -> withContext(Dispatchers.Default) { compute(s) } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _now = MutableStateFlow(ZonedDateTime.now())
    val now: StateFlow<ZonedDateTime> = _now.asStateFlow()

    private val _locating = MutableStateFlow(false)
    val locating: StateFlow<Boolean> = _locating.asStateFlow()

    /**
     * The last thing location has to say, or null when there is nothing to report.
     *
     * 0.2.5 had no such channel: a refusal from the system looked exactly like a success that had
     * not arrived yet, so the only feedback was the button becoming pressable again. Now every
     * branch produces a sentence — including the good one, which states the radius, because a fix
     * the user cannot judge is a fix the user has to trust blindly.
     */
    private val _locationStatus = MutableStateFlow<String?>(null)
    val locationStatus: StateFlow<String?> = _locationStatus.asStateFlow()

    init {
        // One-second heartbeat drives the countdown; it also rolls the prayer window over.
        //
        // Two details that matter for smoothness. First, the tick is aligned to the wall-clock
        // second instead of sleeping a flat 1000 ms: a flat delay drifts by the cost of the work
        // done in between, so the visible seconds occasionally skipped or repeated a digit.
        // Second, the value is only published when the displayed second actually changes, so a
        // resumed screen no longer recomposes the whole tree on a value identical to the last one.
        viewModelScope.launch {
            var lastSecond = Long.MIN_VALUE
            while (isActive) {
                val snapshot = data.value
                val zone = snapshot?.place?.zone
                val current = if (zone != null) ZonedDateTime.now(zone) else ZonedDateTime.now()
                val second = current.toEpochSecond()
                if (second != lastSecond) {
                    lastSecond = second
                    _now.value = current
                }
                if (snapshot != null && !current.isBefore(snapshot.window.nextStart)) {
                    refreshTrigger.value += 1
                }
                delay(1_000L - System.currentTimeMillis() % 1_000L)
            }
        }
        // Keep the alarm chain in sync with the settings at all times.
        viewModelScope.launch {
            settingsRepository.settings.collect { s ->
                withContext(Dispatchers.Default) {
                    PrayerAlarmScheduler.reschedule(app, s)
                }
            }
        }
    }

    private fun compute(settings: AppSettings): PrayerData {
        val place = PlaceResolver.resolve(app, settings)
        val today = LocalDate.now(place.zone)
        val days = PrayerEngine.days(today, DAYS_AHEAD, place.coordinates, place.zone, settings.params)
        val window = PrayerEngine.window(
            ZonedDateTime.now(place.zone), place.coordinates, place.zone, settings.params
        )
        return PrayerData(
            place = place,
            days = days,
            window = window,
            qibla = qiblaBearing(place.coordinates),
            kaabaDistanceKm = distanceToKaabaKm(place.coordinates),
            hijri = HijriCalendar.format(today, settings.hijriOffset),
            settings = settings
        )
    }

    fun cities(query: String): List<City> = cityRepository.search(query)

    fun selectCity(city: City) = viewModelScope.launch { settingsRepository.setCity(city) }

    fun useDeviceLocation() = viewModelScope.launch {
        if (_locating.value) return@launch
        _locating.value = true
        _locationStatus.value = null
        try {
            when (val outcome = withContext(Dispatchers.Default) { locationProvider.current() }) {
                is LocationOutcome.Fix -> {
                    // The nearest city gives the place its name. The coordinates stay exactly as the
                    // sensor reported them, and the zone is decided by ZoneResolver, not by the city.
                    val nearest = cityRepository.nearest(outcome.coordinates)
                    settingsRepository.setDeviceLocation(
                        latitude = outcome.coordinates.latitude,
                        longitude = outcome.coordinates.longitude,
                        nearestCityId = nearest.id,
                        accuracyMeters = outcome.accuracyMeters.toDouble(),
                        fixedAtMillis = outcome.timeMillis
                    )
                    _locationStatus.value = buildString {
                        append("Точка получена: ${nearest.name}, ±${outcome.accuracyMeters.toInt()} м")
                        append(" (${providerName(outcome.provider)}")
                        val ageMinutes = outcome.ageMillis / 60_000L
                        if (ageMinutes >= 1L) append(", фикс ${ageMinutes} мин назад")
                        append(").")
                    }
                }

                LocationOutcome.NoPermission -> {
                    settingsRepository.setUseDeviceLocation(false)
                    _locationStatus.value = "Нет доступа к местоположению. Разрешение можно выдать " +
                        "в настройках системы, а можно просто выбрать город в списке — " +
                        "расчёт от этого не пострадает."
                }

                LocationOutcome.LocationDisabled -> {
                    settingsRepository.setUseDeviceLocation(false)
                    _locationStatus.value = "Геолокация выключена в системе — включите её в " +
                        "быстрых настройках и нажмите ещё раз."
                }

                LocationOutcome.TimedOut -> {
                    settingsRepository.setUseDeviceLocation(false)
                    _locationStatus.value = "За ${LocationProvider.DEADLINE_MILLIS / 1000} с " +
                        "спутники не ответили — так бывает в помещении. Выйдите к окну и " +
                        "повторите или выберите город вручную."
                }

                LocationOutcome.Unavailable -> {
                    settingsRepository.setUseDeviceLocation(false)
                    _locationStatus.value = "Устройство не отдаёт координаты. Выберите город в списке."
                }
            }
        } finally {
            _locating.value = false
        }
    }

    private fun providerName(provider: String): String = when (provider) {
        "gps" -> "спутники"
        "network" -> "сеть"
        "fused" -> "система"
        "passive" -> "кэш системы"
        else -> provider
    }

    fun refresh() {
        refreshTrigger.value += 1
        // A fix is a statement about where the phone was six hours ago, not about where it is.
        // Coming back to the app is the natural moment to re-ask, and only if the user already
        // granted the permission - no dialog is ever raised from here.
        val current = settings.value
        if (current.locationIsStale && !_locating.value && locationProvider.hasPermission()) {
            useDeviceLocation()
        }
    }

    val repository get() = settingsRepository

    fun onPermissionsChanged() = viewModelScope.launch {
        PrayerAlarmScheduler.reschedule(app)
    }

    fun setNotification(prayer: Prayer, enabled: Boolean) =
        viewModelScope.launch { settingsRepository.setNotification(prayer, enabled) }

    fun setOffset(prayer: Prayer, minutes: Int) =
        viewModelScope.launch { settingsRepository.setOffset(prayer, minutes) }

    companion object {
        const val DAYS_AHEAD = 14
    }
}
