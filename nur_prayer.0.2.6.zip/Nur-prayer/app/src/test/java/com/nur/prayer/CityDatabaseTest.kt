package com.nur.prayer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * The city database is data, and data rots silently.
 *
 * Every other test in this module checks arithmetic; this one checks the table the arithmetic is
 * fed. A wrong coordinate never throws — the app keeps working and shows a wrong time all year,
 * which is the worst possible failure mode for this product. Nothing here can prove a coordinate
 * right, but each assertion kills a class of mistake that a hand-typed table actually makes:
 * duplicate ids, a settlement typed twice, a mistyped digit that throws a town out of its zone, or
 * a copy-pasted `Europe/Moscow` on a city three time zones east.
 *
 * The asset is read from disk rather than through `AssetManager`, so this stays a plain JVM test
 * with no Android runtime and no Robolectric — it runs in milliseconds on every build. The parser
 * is deliberately dumb: the point is to test the data, not to depend on a JSON library that the
 * unit-test classpath does not have.
 */
class CityDatabaseTest {

    private data class Entry(
        val id: Int,
        val name: String,
        val region: String,
        val lat: Double,
        val lon: Double,
        val tz: String
    )

    private val cities: List<Entry> by lazy { parse(locateAsset().readText()) }

    private fun locateAsset(): File {
        // Gradle runs unit tests with the module directory as the working directory; running them
        // from the repository root is common enough to be worth the second candidate.
        val candidates = listOf(
            File("src/main/assets/cities_ru.json"),
            File("app/src/main/assets/cities_ru.json")
        )
        return candidates.firstOrNull { it.isFile }
            ?: error("cities_ru.json не найден: искал ${candidates.joinToString()}")
    }

    private fun parse(text: String): List<Entry> {
        // Escaped plain strings on purpose: a raw string that has to end with a quote character
        // ("""...\"""") is the kind of clever that costs a build, and this project has paid for
        // one of those already.
        val objects = Regex("\\{[^{}]*\\}").findAll(text).map { it.value }.toList()
        assertTrue("не разобрал ни одного города", objects.isNotEmpty())
        return objects.map { blob ->
            fun str(field: String): String =
                Regex("\"" + field + "\"\\s*:\\s*\"([^\"]*)\"")
                    .find(blob)?.groupValues?.get(1)
                    ?: error("нет поля " + field + " в " + blob)

            fun num(field: String): Double =
                Regex("\"" + field + "\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?)")
                    .find(blob)?.groupValues?.get(1)
                    ?.toDouble() ?: error("нет поля " + field + " в " + blob)

            Entry(
                id = num("id").toInt(),
                name = str("name"),
                region = str("region"),
                lat = num("lat"),
                lon = num("lon"),
                tz = str("tz")
            )
        }
    }

    private fun distanceKm(a: Entry, b: Entry): Double {
        val f1 = Math.toRadians(a.lat)
        val f2 = Math.toRadians(b.lat)
        val df = Math.toRadians(b.lat - a.lat)
        val dl = Math.toRadians(b.lon - a.lon)
        val h = sin(df / 2) * sin(df / 2) + cos(f1) * cos(f2) * sin(dl / 2) * sin(dl / 2)
        return 2 * 6371.0088 * asin(sqrt(h))
    }

    @Test
    fun `ids and names are unique`() {
        val ids = cities.map { it.id }
        assertEquals("повторяющиеся id", ids.size, ids.distinct().size)
        val names = cities.map { it.name }
        val duplicates = names.groupingBy { it }.eachCount().filterValues { it > 1 }.keys
        assertTrue("названия повторяются: $duplicates", duplicates.isEmpty())
    }

    @Test
    fun `every time zone matches its longitude`() {
        // January is deliberate: standard time everywhere in this database, no DST to reason about.
        val january = LocalDate.of(2026, 1, 15).atTime(12, 0)
        cities.forEach { city ->
            val zone = ZoneId.of(city.tz) // throws if the identifier is not in the tz database
            val offsetHours = january.atZone(zone).offset.totalSeconds / 3600.0
            val solarHours = city.lon / 15.0
            assertTrue(
                "${city.name}: пояс ${city.tz} = UTC%+.0f, долгота ${city.lon} даёт %+.1f ч"
                    .format(offsetHours, solarHours),
                abs(solarHours - offsetHours) <= 2.5
            )
        }
    }

    @Test
    fun `coordinates stay inside the envelope of the database`() {
        cities.forEach { city ->
            // The southern edge is Mecca, the northern one Norilsk; anything outside is a typo.
            assertTrue("${city.name}: широта ${city.lat}", city.lat in 21.0..72.0)
            assertTrue("${city.name}: долгота ${city.lon}", city.lon in 19.0..180.0)
        }
    }

    @Test
    fun `no settlement is listed twice under two names`() {
        val sorted = cities.sortedBy { it.lat }
        sorted.forEachIndexed { i, a ->
            for (j in i + 1 until sorted.size) {
                val b = sorted[j]
                if (b.lat - a.lat > 0.05) break
                val km = distanceKm(a, b)
                assertTrue("${a.name} и ${b.name} разделяют %.0f м".format(km * 1000), km >= 2.0)
            }
        }
    }

    @Test
    fun `tatarstan is covered city by city`() {
        // Every city of the republic. This list is the reason the test exists: the picker is the
        // only way an offline app can reach a town, so a missing name is a user who cannot use it.
        val required = listOf(
            "Казань", "Набережные Челны", "Нижнекамск", "Альметьевск", "Зеленодольск",
            "Бугульма", "Елабуга", "Лениногорск", "Чистополь", "Заинск", "Азнакаево",
            "Нурлат", "Менделеевск", "Бавлы", "Буинск", "Агрыз", "Арск", "Мензелинск",
            "Мамадыш", "Болгар", "Тетюши", "Лаишево", "Иннополис", "Кукмор"
        )
        val present = cities.filter { it.region == "Татарстан" }.map { it.name }.toSet()
        val missing = required.filterNot { it in present }
        assertTrue("в базе нет городов Татарстана: $missing", missing.isEmpty())
    }

    @Test
    fun `neighbouring capitals are present`() {
        val required = listOf("Йошкар-Ола", "Чебоксары", "Ижевск", "Уфа", "Ульяновск", "Киров")
        val present = cities.map { it.name }.toSet()
        assertTrue(
            "нет городов: ${required.filterNot { it in present }}",
            required.all { it in present }
        )
    }

    @Test
    fun `every city names its country`() {
        val nameless = repository.all.filter { it.country.isBlank() }
        assertTrue("без страны: ${nameless.map { it.name }}", nameless.isEmpty())
    }

    @Test
    fun `uzbekistan is present in full`() {
        // Same contract as the Tatarstan list: a city cannot quietly disappear in a refactor.
        val expected = listOf(
            "Ташкент", "Нукус", "Муйнак", "Бухара", "Гиждуван", "Каган", "Самарканд", "Каттакурган",
            "Ургут", "Наманган", "Чуст", "Андижан", "Асака", "Фергана", "Маргилан", "Коканд",
            "Кувасай", "Карши", "Шахрисабз", "Термез", "Денау", "Джизак", "Гулистан", "Ургенч",
            "Хива", "Навои", "Зарафшан", "Учкудук", "Нурафшон", "Чирчик", "Ангрен", "Алмалык",
            "Бекабад", "Янгиюль"
        )
        val actual = repository.all.filter { it.country == "Узбекистан" }.map { it.name }
        assertEquals(expected.sorted(), actual.sorted())
    }

    @Test
    fun `search finds a whole country`() {
        val found = repository.search("узбекистан").map { it.name }
        assertTrue("поиск по стране должен возвращать все города: $found", found.size >= 30)
        assertTrue(found.contains("Бухара"))
    }

    @Test
    fun `no city drifts further from its own solar time than the zone resolver allows`() {
        // ZoneResolver.MAX_SOLAR_GAP_HOURS is calibrated on this database. If a new city ever sits
        // further from its solar time than the constant allows, the resolver would start distrusting
        // correct phone clocks there - so the database, not the resolver, must fail first.
        val instants = listOf(
            java.time.Instant.parse("2026-01-15T09:00:00Z"),
            java.time.Instant.parse("2026-07-15T09:00:00Z")
        )
        for (city in repository.all) {
            for (instant in instants) {
                val zoneHours = com.nur.prayer.location.ZoneResolver.offsetHours(city.zone, instant)
                val gap = kotlin.math.abs(zoneHours - city.longitude / 15.0)
                assertTrue(
                    "${city.name}: разрыв ${"%.2f".format(gap)} ч больше допустимого",
                    gap <= com.nur.prayer.location.ZoneResolver.MAX_SOLAR_GAP_HOURS
                )
            }
        }
    }
}
