package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.PrayerTimes
import com.nur.prayer.core.astro.TimeSource
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

/**
 * The evening twin of the 0.2.4 dawn fix.
 *
 * At the edge of the white-night season the Sun's altitude curve is almost flat at its lowest point.
 * A night that misses the Isha angle by four hundredths of a degree used to satisfy the old
 * "residual under 0.05" test, so Newton parked on the flat minimum and the engine published an
 * astronomical Isha that never happened - roughly an hour away from the honest answer.
 *
 * Volgograd, 14 June 2026: the Sun bottoms out at -17.9989 degrees, so an 18-degree Isha does not
 * exist and the interval must be used. Ust-Kamenogorsk, 10 June 2026, is the same shape.
 */
class EveningTwilightTest {

    private val method = CalculationMethod.MUSLIM_WORLD_LEAGUE

    private fun times(lat: Double, lon: Double, zone: String, date: LocalDate) = PrayerTimes.of(
        date = date,
        coordinates = Coordinates(lat, lon),
        zone = ZoneId.of(zone),
        params = method.params().copy(highLatitudeRule = HighLatitudeRule.SEVENTH_OF_NIGHT)
    )

    @Test
    fun `volgograd mid june has no astronomical isha`() {
        val result = times(48.7071, 44.5169, "Europe/Volgograd", LocalDate.of(2026, 6, 14))
        assertNotEquals(
            "касание угла -18 не должно выдаваться за наступление иши",
            TimeSource.ANGLE,
            result.ishaSource
        )
    }

    @Test
    fun `ust kamenogorsk mid june has no astronomical isha`() {
        val result = times(49.9787, 82.6014, "Asia/Almaty", LocalDate.of(2026, 6, 10))
        assertNotEquals(TimeSource.ANGLE, result.ishaSource)
    }

    @Test
    fun `an ordinary night still resolves from the angle`() {
        // Same city, five weeks later: the night is deep again and the angle must win.
        val result = times(48.7071, 44.5169, "Europe/Volgograd", LocalDate.of(2026, 8, 20))
        assertEquals(TimeSource.ANGLE, result.ishaSource)
    }
}
