package com.nur.prayer

import com.nur.prayer.ui.NavigationMotion
import org.junit.Assert.assertTrue
import org.junit.Test

class NavigationMotionTest {
    @Test fun routesUseShortNonBlockingAnimationDurations() {
        assertTrue(NavigationMotion.TAB_ENTER_MILLIS in 1..100)
        assertTrue(NavigationMotion.DETAIL_ENTER_MILLIS in 1..120)
        assertTrue(NavigationMotion.EDITOR_ENTER_MILLIS in 1..100)
        assertTrue(NavigationMotion.EXIT_MILLIS < NavigationMotion.TAB_ENTER_MILLIS)
        assertTrue(NavigationMotion.DOCK_MILLIS in 1..120)
    }
}
