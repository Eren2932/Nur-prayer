package com.nur.prayer.ui

/** Short, interruptible transitions; input and route state change immediately, never after a delay. */
object NavigationMotion {
    const val TAB_ENTER_MILLIS = 80
    const val DETAIL_ENTER_MILLIS = 100
    const val EXIT_MILLIS = 40
    const val EDITOR_ENTER_MILLIS = 80
    const val DOCK_MILLIS = 100
}
