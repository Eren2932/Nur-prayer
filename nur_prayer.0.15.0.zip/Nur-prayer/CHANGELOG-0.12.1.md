# Нур 0.12.1 — исправление сборки 0.12.0

Исходники, не APK. Компиляцию и unit-тесты подтверждает CI. versionName `0.12.1`, versionCode `28`.

## Что упало
Лог CI 0.12.0: единственная ошибка, `compileDebugKotlin` и `compileReleaseKotlin`:
`Motion.kt:19:35 Unresolved reference 'using'`. Ошибки типов пружин из 0.11.0 ушли.

Причина: `using` (привязка `SizeTransform` к `ContentTransform`) — член области
`AnimatedContent { transitionSpec }`, а не отдельная функция верхнего уровня, поэтому
`import androidx.compose.animation.using` не существует. Остальной код проекта вызывает его без импорта.

## Исправление
- Импорт удалён. В `RollingNumber` и `RollingText` вызов записан как `(...).using(SizeTransform(clip = false))`,
  как в `NurRoot`, `SettingsScreen` и `MonthCalendar`, которые собирались раньше.
- Остальные импорты, появившиеся после 0.10.0, пересмотрены по одному: других несуществующих нет.
- `VoiceManifestTest`: `map(::File)` заменён на лямбду (ссылка на конструктор с несколькими перегрузками).

## Защита
- `tools/check_compose_imports.py`: каждый импорт `androidx.compose.animation*` должен быть в списке
  известных символов. На исходниках 0.12.0 находит ровно эту строку. Подключена в `package_source.py` и в CI.

## Не проверялось в CI
Gradle остановился на первой задаче, поэтому компиляция unit-тестов и androidTest ещё не запускалась ни разу.
Новые тесты (`StoryMathTest`, `EntranceMathTest`, `VoiceManifestTest`) вычитаны вручную.
