# Nur 0.14.2 — исправление сборки 0.14.1

## Причина падения CI
`:app:compileDebugKotlin` / `:app:compileReleaseKotlin`:
`MainActivity.kt:165` и `:191` — **Conflicting overloads: fun onStop()**.
Страховка языка из 0.14.1 добавила в `MainActivity` второй `override fun onStop()` (с `L10n.confirm()`),
хотя `onStop()` уже был (снятие ресивера геолокации и `setForeground(false)`).

## Исправление
- Один `onStop()`: снимает ресивер, `viewModel.setForeground(false)`, затем `L10n.confirm()`, затем `super.onStop()`.
  Поведение обеих версий сохранено полностью.

## Чтобы не повторилось
- `tools/kt_sanity.py`, проверка 5 — **conflicting overloads**: две `fun` с одинаковыми именем, ресивером и
  типами параметров в одной области видимости. Имена параметров и тип возврата игнорируются, как у компилятора.
  Проверка идёт в шаге «Static and data checks», т. е. за ~1 с до Gradle, а не после 30 с компиляции.
- Регресс-тест `ConflictingOverloadRegressionTest` в `tools/test_build_regressions.py`
  (исходный сбой ловится, честные перегрузки и одноимённые локальные функции в разных блоках — нет).

- versionCode 33.
