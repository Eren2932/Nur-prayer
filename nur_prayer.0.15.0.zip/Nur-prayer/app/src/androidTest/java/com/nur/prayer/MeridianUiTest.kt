package com.nur.prayer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.SkyBackdrop
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MeridianUiTest {
    @get:Rule val compose = createComposeRule()

    /** A zero-size backdrop must not build a gradient shader with an empty rect. */
    @Test fun zeroSizeSkyDoesNotCreateAnInvalidShader() {
        compose.setContent {
            NurTheme {
                SkyBackdrop(paletteFor(Prayer.MAGHRIB), Modifier.size(0.dp), motionEnabled = false)
                Text("Экран доступен")
            }
        }
        compose.onNodeWithText("Экран доступен").assertIsDisplayed()
    }

    /** Every sky, with and without the colour, hosts the glass card. */
    @Test fun everySkyHostsTheCard() {
        // setContent may run once per test, so all seven skies share one small column.
        compose.setContent {
            NurTheme {
                Column {
                    Prayer.entries.forEach { prayer ->
                        Box(Modifier.size(width = 200.dp, height = 64.dp)) {
                            SkyBackdrop(paletteFor(prayer), sky = prayer != Prayer.ISHA, motionEnabled = false)
                            GlassCard { Text("Карточка ${prayer.name}") }
                        }
                    }
                }
            }
        }
        Prayer.entries.forEach { compose.onNodeWithText("Карточка ${it.name}").assertExists() }
    }
}
