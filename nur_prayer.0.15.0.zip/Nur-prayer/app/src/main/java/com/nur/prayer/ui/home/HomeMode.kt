package com.nur.prayer.ui.home

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

/**
 * The two faces of the home screen. A tap on the sky flips between them.
 *
 * [LIST] is the day at a glance: every time, the current window marked, the next prayer counting
 * down in the plate at the bottom. [CLOCK] is the same answer reduced to one number, for the phone
 * lying on the prayer mat or on the bedside table.
 */
enum class HomeMode { LIST, CLOCK }

/**
 * The chosen face survives restarts, but deliberately not through `AppSettings`: every write to
 * the settings DataStore re-runs the two-week prayer calculation and re-arms the alarm chain, and a
 * tap on the background must cost nothing. A private SharedPreferences file read once per process
 * is the cheapest durable store there is.
 */
internal object HomeModeStore {
    private const val FILE = "nur_ui"
    private const val KEY = "home_mode"

    fun read(context: Context): HomeMode {
        val raw = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, null)
        return HomeMode.entries.firstOrNull { it.name == raw } ?: HomeMode.LIST
    }

    fun write(context: Context, mode: HomeMode) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, mode.name).apply()
    }

    fun toggled(mode: HomeMode): HomeMode = if (mode == HomeMode.LIST) HomeMode.CLOCK else HomeMode.LIST
}

@Composable
internal fun rememberHomeMode(): MutableState<HomeMode> {
    val context = LocalContext.current.applicationContext
    return remember { mutableStateOf(HomeModeStore.read(context)) }
}
