package com.nur.prayer.learn

/**
 * One letter of the alphabet as the course teaches it.
 *
 * [sound] is the course transliteration: one symbol per consonant, so two letters never share a
 * reading and a "choose the transliteration" question can never have two right answers. The same
 * table lives in tools/learn_data.py, which derives every transliteration in the assets; the
 * verifier compares the two tables letter by letter.
 */
data class Letter(
    val char: String,
    val sound: String,
    val name: String,
    val nameArabic: String,
    val joinsNext: Boolean,
    val sun: Boolean,
    val hint: String
)

/** Position of a letter inside a written word, which decides its shape. */
enum class LetterForm(val title: String) {
    ISOLATED("отдельная"), INITIAL("начальная"), MEDIAL("средняя"), FINAL("конечная")
}

/** A vowel sign or reading mark taught in the course. */
data class Mark(val char: String, val name: String, val sound: String, val explain: String)

object Arabic {
    const val FATHA = "\u064E"
    const val KASRA = "\u0650"
    const val DAMMA = "\u064F"
    const val SUKUN = "\u0652"
    const val SHADDA = "\u0651"
    const val FATHATAN = "\u064B"
    const val KASRATAN = "\u064D"
    const val DAMMATAN = "\u064C"
    const val DAGGER_ALIF = "\u0670"
    /** Zero-width joiner: asks the shaper for the connected form of a lone letter. */
    private const val ZWJ = "\u200D"

    val LETTERS: List<Letter> = listOf(
        Letter("ا", "а", "алиф", "أَلِف", joinsNext = false, sun = false,
            hint = "Своего звука не имеет: продлевает «а» до «аа» или держит хамзу. Со следующей буквой не соединяется."),
        Letter("ب", "б", "ба", "بَاء", joinsNext = true, sun = false,
            hint = "Как русское «б». Одна точка снизу."),
        Letter("ت", "т", "та", "تَاء", joinsNext = true, sun = true,
            hint = "Как «т». Две точки сверху."),
        Letter("ث", "с̱", "са", "ثَاء", joinsNext = true, sun = true,
            hint = "Межзубный глухой: кончик языка между зубами, как th в английском think. Три точки сверху."),
        Letter("ج", "дж", "джим", "جِيم", joinsNext = true, sun = false,
            hint = "Слитное «дж». Точка внутри изгиба."),
        Letter("ح", "ҳ", "ха", "حَاء", joinsNext = true, sun = false,
            hint = "Глухой выдох из середины горла, без хрипа — как дыхание на стекло. Без точек."),
        Letter("خ", "х", "хо", "خَاء", joinsNext = true, sun = false,
            hint = "Как русское «х», но глубже, с лёгким хрипом. Точка сверху."),
        Letter("د", "д", "даль", "دَال", joinsNext = false, sun = true,
            hint = "Как «д». Со следующей буквой не соединяется."),
        Letter("ذ", "з̱", "заль", "ذَال", joinsNext = false, sun = true,
            hint = "Межзубный звонкий, как th в английском this. Даль с точкой."),
        Letter("ر", "р", "ра", "رَاء", joinsNext = false, sun = true,
            hint = "Раскатистое «р». Со следующей буквой не соединяется."),
        Letter("ز", "з", "зай", "زَاي", joinsNext = false, sun = true,
            hint = "Как «з». Ра с точкой."),
        Letter("س", "с", "син", "سِين", joinsNext = true, sun = true,
            hint = "Как «с». Три зубчика без точек."),
        Letter("ش", "ш", "шин", "شِين", joinsNext = true, sun = true,
            hint = "Как «ш». Три точки над зубчиками."),
        Letter("ص", "с̣", "сад", "صَاد", joinsNext = true, sun = true,
            hint = "Твёрдое «с»: корень языка поднят к нёбу, соседние гласные звучат глубже."),
        Letter("ض", "д̣", "дад", "ضَاد", joinsNext = true, sun = true,
            hint = "Твёрдое «д» — тот самый звук, из-за которого арабский зовут «языком дад». Сад с точкой."),
        Letter("ط", "т̣", "то", "طَاء", joinsNext = true, sun = true,
            hint = "Твёрдое «т» с поднятым корнем языка. Петля и высокая черта."),
        Letter("ظ", "з̣", "зо", "ظَاء", joinsNext = true, sun = true,
            hint = "Твёрдый межзубный звонкий: как заль, но «толще». То с точкой."),
        Letter("ع", "‘", "айн", "عَيْن", joinsNext = true, sun = false,
            hint = "Сжатие мышц горла с голосом, в транслите — знак ‘. В русском такого звука нет: слушайте и повторяйте."),
        Letter("غ", "ғ", "гайн", "غَيْن", joinsNext = true, sun = false,
            hint = "Картавое «г», как французское r. Айн с точкой."),
        Letter("ف", "ф", "фа", "فَاء", joinsNext = true, sun = false,
            hint = "Как «ф». Одна точка сверху."),
        Letter("ق", "қ", "каф", "قَاف", joinsNext = true, sun = false,
            hint = "Глубокое «к»: язык смыкается у маленького язычка. Две точки сверху."),
        Letter("ك", "к", "кяф", "كَاف", joinsNext = true, sun = false,
            hint = "Обычное «к»."),
        Letter("ل", "л", "лям", "لَام", joinsNext = true, sun = true,
            hint = "Как «л». Высокая черта с изгибом внизу."),
        Letter("م", "м", "мим", "مِيم", joinsNext = true, sun = false,
            hint = "Как «м». Маленькая петля."),
        Letter("ن", "н", "нун", "نُون", joinsNext = true, sun = true,
            hint = "Как «н». Одна точка сверху."),
        Letter("ه", "һ", "ха", "هَاء", joinsNext = true, sun = false,
            hint = "Лёгкий выдох, как h в английском hello. В слове сильно меняет вид."),
        Letter("و", "в", "вав", "وَاو", joinsNext = false, sun = false,
            hint = "Как w в английском; после даммы продлевает «у» до «уу». Со следующей не соединяется."),
        Letter("ي", "й", "йа", "يَاء", joinsNext = true, sun = false,
            hint = "Как «й»; после касры продлевает «и» до «ии». Две точки снизу.")
    )

    private val byChar: Map<String, Letter> = LETTERS.associateBy { it.char }

    /** Letters that look alike once the dots are gone: the hardest distractors. */
    private val SHAPE_FAMILIES = listOf("بتثني", "جحخ", "دذ", "رز", "سش", "صض", "طظ", "عغ", "فق", "كل", "مه", "او")
    /** Letters a Russian ear confuses: the next hardest. */
    private val SOUND_FAMILIES = listOf("سصث", "تط", "دض", "ذزظ", "هح", "كق", "اع", "خغ")

    /** The seven alphabet lessons, grouped by shape so a lesson teaches one skeleton and its dots. */
    val LESSON_GROUPS: List<String> = listOf("ابتث", "جحخ", "دذرز", "سشصض", "طظعغ", "فقكل", "منهوي")

    val VOWELS: List<Mark> = listOf(
        Mark(FATHA, "фатха", "а", "Чёрточка над буквой — короткое «а»."),
        Mark(KASRA, "касра", "и", "Чёрточка под буквой — короткое «и»."),
        Mark(DAMMA, "дамма", "у", "Маленькая вав над буквой — короткое «у».")
    )
    val SUKUN_MARK = Mark(SUKUN, "сукун", "", "Кружок над буквой: гласной нет, согласный закрывает слог.")
    val SHADDA_MARK = Mark(SHADDA, "шадда", "", "Зубчик над буквой: согласный удваивается.")
    val TANWEEN: List<Mark> = listOf(
        Mark(FATHATAN, "танвин фатха", "ан", "Две фатхи — «ан». Обычно пишется с алифом: ـًا."),
        Mark(KASRATAN, "танвин касра", "ин", "Две касры — «ин»."),
        Mark(DAMMATAN, "танвин дамма", "ун", "Две даммы — «ун».")
    )

    fun letter(char: String): Letter? = byChar[char]

    fun isMark(c: Char): Boolean = c in '\u064B'..'\u0652' || c == '\u0670'

    /** Base letter plus the marks written on it; a space is its own grapheme. */
    fun graphemes(text: String): List<String> {
        val out = ArrayList<StringBuilder>()
        for (c in text) {
            if (isMark(c) && out.isNotEmpty()) out.last().append(c) else out.add(StringBuilder().append(c))
        }
        return out.map { it.toString() }
    }

    fun stripMarks(text: String): String = text.filterNot { isMark(it) }

    /** Hamza seats, alif maqsura and ta marbuta, folded to the alphabet letter they are written with. */
    fun fold(base: Char): String = when (base) {
        'أ', 'إ', 'آ', 'ى' -> "ا"
        'ة' -> "ت"
        'ؤ' -> "و"
        'ئ' -> "ي"
        else -> base.toString()
    }

    /** Alphabet letters of a word, in writing order, seats folded. Spaces and stray hamza dropped. */
    fun lettersOf(word: String): List<Letter> =
        stripMarks(word).mapNotNull { if (it == ' ') null else byChar[fold(it)] }

    private fun joinsNext(base: Char): Boolean = when (base) {
        'ء', 'ة', 'ى', 'أ', 'إ', 'آ', 'ؤ' -> false
        'ئ' -> true
        else -> byChar[base.toString()]?.joinsNext ?: false
    }

    private fun joinsPrevious(base: Char): Boolean = base != 'ء' && base != ' '

    /**
     * The shape each grapheme takes in [word]. A letter connects backwards when the letter before it
     * joins forwards, and forwards when it joins forwards itself and something follows. Six letters
     * never join forwards, so they split a word into pieces — exactly how the word is printed.
     */
    fun formsIn(word: String): List<LetterForm> {
        val g = graphemes(word)
        return g.indices.map { i ->
            val base = g[i][0]
            if (base == ' ') return@map LetterForm.ISOLATED
            val prev = g.getOrNull(i - 1)?.get(0)
            val next = g.getOrNull(i + 1)?.get(0)
            val back = prev != null && prev != ' ' && joinsNext(prev) && joinsPrevious(base)
            val forward = next != null && next != ' ' && joinsNext(base) && joinsPrevious(next)
            when {
                back && forward -> LetterForm.MEDIAL
                back -> LetterForm.FINAL
                forward -> LetterForm.INITIAL
                else -> LetterForm.ISOLATED
            }
        }
    }

    /** The letter drawn in [form], via joiners, so the system Arabic font shapes it correctly. */
    fun shape(letter: Letter, form: LetterForm): String = when (form) {
        LetterForm.ISOLATED -> letter.char
        LetterForm.INITIAL -> if (letter.joinsNext) letter.char + ZWJ else letter.char
        LetterForm.MEDIAL -> if (letter.joinsNext) ZWJ + letter.char + ZWJ else ZWJ + letter.char
        LetterForm.FINAL -> ZWJ + letter.char
    }

    /** Distractor letters for [target], hardest first: same skeleton, then same sound, then the rest. */
    fun confusable(target: Letter): List<Letter> {
        val c = target.char
        val shape = SHAPE_FAMILIES.filter { c in it }.joinToString("")
        val sound = SOUND_FAMILIES.filter { c in it }.joinToString("")
        val ordered = LinkedHashSet<String>()
        shape.forEach { ordered += it.toString() }
        sound.forEach { ordered += it.toString() }
        ordered -= c
        return ordered.mapNotNull { byChar[it] }
    }

    /** A syllable written with [mark] on [letter]: the alif takes a hamza seat to carry a vowel. */
    fun syllable(letter: Letter, mark: Mark): String {
        val base = if (letter.char == "ا") (if (mark.char == KASRA || mark.char == KASRATAN) "إ" else "أ") else letter.char
        val tail = if (mark.char == FATHATAN && letter.char != "ا") "ا" else ""
        return base + mark.char + tail
    }

    /** Its reading in the course transliteration. */
    fun syllableSound(letter: Letter, mark: Mark): String {
        val consonant = if (letter.char == "ا") "" else letter.sound
        return consonant + mark.sound
    }

    /** A long vowel: fatha + alif, kasra + ya, damma + waw. */
    fun longSyllable(letter: Letter, vowel: Mark): Pair<String, String> {
        val carrier = when (vowel.char) { FATHA -> "ا"; KASRA -> "ي"; else -> "و" }
        val base = if (letter.char == "ا") (if (vowel.char == KASRA) "إ" else "أ") else letter.char
        val consonant = if (letter.char == "ا") "" else letter.sound
        return (base + vowel.char + carrier) to (consonant + vowel.sound + vowel.sound)
    }
}
