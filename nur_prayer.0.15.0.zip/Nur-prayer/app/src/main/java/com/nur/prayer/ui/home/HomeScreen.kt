package com.nur.prayer.ui.home

import com.nur.prayer.i18n.tr

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.PillButton
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import com.nur.prayer.ui.theme.Highlight
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.NextGreen
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime

/*
 * 0.6.0 home: one sky, one answer.
 *
 * Gestures, all of them on the sky itself:
 *  - tap anywhere outside the card  → switch between the list and the big clock;
 *  - tap a row (or the green plate) → the sheet of that prayer, swipeable between prayers;
 *  - pull up from anywhere          → the month calendar.
 * 0.13.0: one menu button bottom-left opens a capsule (Кыбла, Настройки); Календарь stays right. Back from the
 * sheet closes the sheet; back from home leaves the app, as on every launcher-level screen.
 */

/** Text drawn straight on the sky gets a soft shadow so it survives the light horizon of noon. */
private val OnSky = Shadow(Color(0x73000000), blurRadius = 10f)

@Composable
fun HomeScreen(
    data: PrayerData,
    now: State<ZonedDateTime>,
    palette: PhasePalette,
    actions: AppActions,
    notificationsAllowed: Boolean,
    exactAlarmsAllowed: Boolean,
    onOpenCity: () -> Unit,
    onOpenSchedule: () -> Unit,
    /** The pull-up gesture: raises «Сегодня». Defaults to the calendar for previews and old tests. */
    onOpenToday: () -> Unit = onOpenSchedule,
    /** The centre of the menu item that was tapped, in root coordinates: the page grows from it. */
    onOpenQibla: (Offset) -> Unit,
    onOpenSettings: (Offset) -> Unit,
    /** The calendar layer pulled up from here; NurRoot owns it so the layer can sit above home. */
    reveal: Reveal = remember { Reveal() },
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val context = LocalContext.current.applicationContext
    val haptic = LocalHapticFeedback.current
    var mode by rememberHomeMode()
    // The open sheet survives rotation and process death; stored by name, validated on read.
    var sheetName by rememberSaveable { mutableStateOf<String?>(null) }
    val sheetPrayer = sheetName?.let { name -> Prayer.entries.firstOrNull { it.name == name } }
    BackHandler(enabled = sheetPrayer != null) { sheetName = null }
    // Not saveable on purpose: a menu left open must not greet the user after a rotation or a return.
    var menuOpen by remember { mutableStateOf(false) }
    val menuDim = remember { Animatable(0f) }
    var barHeight by remember { mutableStateOf(0) }
    LaunchedEffect(menuOpen) { menuDim.animateTo(if (menuOpen) 1f else 0f, tween(if (menuOpen) 180 else 140)) }

    val toggle = {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        mode = HomeModeStore.toggled(mode)
        HomeModeStore.write(context, mode)
    }

    // The prayer sheet and the calendar are layers driven by a Reveal: a finger and an animation move
    // the same number, and only draw lambdas read it (see Reveal). Nothing here recomposes per frame.
    val sheet = remember { Reveal(initiallyOpen = sheetPrayer != null) }
    LaunchedEffect(sheetPrayer != null) {
        if (sheetPrayer != null) {
            // Let the heavy first composition of the sheet land before the clock of the slide starts;
            // otherwise its first frames are spent composing and the slide visibly skips ahead.
            withFrameNanos { }
            withFrameNanos { }
            sheet.settle(true)
        } else {
            sheet.settle(false)
        }
    }
    val sheetOnScreen by remember(sheetPrayer != null) {
        derivedStateOf { sheetPrayer != null || sheet.progress > 0f }
    }

    // Pull up from anywhere on the sky: «Сегодня» rises under the finger, then settles open or
    // falls back, by distance or by fling speed.
    val openSchedule by rememberUpdatedState(onOpenToday)
    val pullState = rememberDraggableState { delta -> reveal.drag(-delta * RevealMath.PULL_GAIN) }

    Box(
        modifier
            .fillMaxSize()
            .onSizeChanged { reveal.extentPx = it.height.toFloat() }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClickLabel = if (mode == HomeMode.LIST) tr("Показать крупные часы") else tr("Показать список намазов"),
                onClick = toggle
            )
            .draggable(
                state = pullState,
                orientation = Orientation.Vertical,
                enabled = sheetPrayer == null,
                onDragStarted = { reveal.grab() },
                onDragStopped = { velocity ->
                    if (reveal.release(-velocity * RevealMath.PULL_GAIN, RevealMath.PULL_OPEN_AT)) openSchedule()
                    else reveal.settle(false)
                }
            )
    ) {
        Column(Modifier.fillMaxSize()) {
            HomeHeader(data, onOpenCity)

            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                FaceSwitcher(
                    mode = mode,
                    list = { PrayerListCard(data, now, onOpen = { sheetName = it.name }) },
                    clock = { BigClock(data, now, palette) }
                )
            }

            // 0.13.0: the engine's note ("Фаджр: время мечети…") left home: it crowded the controls and
            // repeated what Настройки → О расчёте explains in full.

            PullHint(
                Modifier.graphicsLayer {
                    val p = reveal.progress
                    translationY = -p * 56.dp.toPx()
                    alpha = 1f - (p * 4f).coerceAtMost(1f)
                }
            )

            Row(
                Modifier
                    .fillMaxWidth()
                    .onSizeChanged { barHeight = it.height }
                    .navigationBarsPadding()
                    .padding(horizontal = ui.s(20f), vertical = ui.s(14f)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // The menu itself is drawn above the outside-tap layer (see below); this only keeps its place.
                Spacer(Modifier.weight(1f).height(48.dp))
                Box(Modifier.graphicsLayer { alpha = 1f - 0.65f * menuDim.value }, contentAlignment = Alignment.CenterEnd) {
                    PillButton(tr("КАЛЕНДАРЬ"), onOpenSchedule, background = Color.White, contentColor = Ink)
                }
            }
        }

        // Outside taps close the menu and are swallowed: the face does not flip, the pull does not start,
        // a prayer row does not open. One tap = one meaning.
        MenuScrim(menuOpen, dim = { menuDim.value }) { menuOpen = false }
        // Same box as the bottom row (same insets and padding), so the button sits exactly on its spot.
        // The capsule may grow to the right over the calendar button: it overlays, it never pushes.
        if (barHeight > 0) Box(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .height(with(LocalDensity.current) { barHeight.toDp() })
                .navigationBarsPadding()
                .padding(horizontal = ui.s(20f), vertical = ui.s(14f)),
            contentAlignment = Alignment.CenterStart
        ) {
            MenuCapsule(
                open = menuOpen,
                onOpenChange = { menuOpen = it },
                entries = listOf(
                    MenuEntry(GlyphKind.COMPASS, tr("Кыбла"), onOpenQibla),
                    MenuEntry(GlyphKind.SETTINGS, tr("Настройки"), onOpenSettings)
                )
            )
        }

        // The sheet keeps rendering the last prayer while it slides away.
        // A plain holder, not state: it only has to remember, never to trigger a recomposition.
        val lastSheet = remember { arrayOfNulls<Prayer>(1) }
        if (sheetPrayer != null) lastSheet[0] = sheetPrayer
        if (sheetOnScreen) {
            Box(Modifier.fillMaxSize().onSizeChanged { sheet.extentPx = it.height.toFloat() }) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .drawBehind { drawRect(SheetScrim, alpha = sheet.progress) }
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClickLabel = tr("Закрыть"),
                            onClick = { sheetName = null }
                        )
                )
                Box(Modifier.fillMaxSize().graphicsLayer { translationY = (1f - sheet.progress) * size.height }) {
                    PrayerSheet(
                        data = data,
                        initial = lastSheet[0] ?: Prayer.FAJR,
                        now = now,
                        actions = actions,
                        notificationsAllowed = notificationsAllowed,
                        exactAlarmsAllowed = exactAlarmsAllowed,
                        onDismiss = { sheetName = null },
                        onOpenSettings = { sheetName = null; onOpenSettings(Offset.Unspecified) },
                        motion = sheet
                    )
                }
            }
        }
    }
}

/**
 * The two faces of home in one fixed slot. A single 0→1 value drives both layers' alpha, scale and
 * lift in the draw phase, so nothing is re-measured while they swap. (0.6.0 used AnimatedContent
 * without a size transform: the container took the new face's size at once and the old face,
 * top-aligned in it, jumped up by half the height difference — the jerk in the screen recording.)
 * Each face is composed only while it is at least partly visible, so a hidden clock does not tick.
 */
@Composable
private fun FaceSwitcher(mode: HomeMode, list: @Composable () -> Unit, clock: @Composable () -> Unit) {
    val progress = remember { Animatable(if (mode == HomeMode.CLOCK) 1f else 0f) }
    LaunchedEffect(mode) {
        progress.animateTo(
            if (mode == HomeMode.CLOCK) 1f else 0f,
            tween(RevealMath.FACE_MILLIS, easing = FastOutSlowInEasing)
        )
    }
    val listComposed by remember { derivedStateOf { progress.value < 1f } }
    val clockComposed by remember { derivedStateOf { progress.value > 0f } }
    if (listComposed) {
        Box(
            Modifier.graphicsLayer {
                val t = progress.value
                alpha = RevealMath.listAlpha(t)
                scaleX = RevealMath.listScale(t)
                scaleY = RevealMath.listScale(t)
                translationY = RevealMath.listLiftDp(t).dp.toPx()
            }
        ) { list() }
    }
    if (clockComposed) {
        Box(
            Modifier.graphicsLayer {
                val t = progress.value
                alpha = RevealMath.clockAlpha(t)
                scaleX = RevealMath.clockScale(t)
                scaleY = RevealMath.clockScale(t)
                translationY = RevealMath.clockLiftDp(t).dp.toPx()
            }
        ) { clock() }
    }
}

private val SheetScrim = Color(0x8C000000)

@Composable
private fun HomeHeader(data: PrayerData, onOpenCity: () -> Unit) {
    val ui = uiScale()
    val sky = TextStyle(shadow = OnSky)
    Row(
        Modifier.fillMaxWidth().padding(start = ui.s(20f), end = ui.s(12f), top = 8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Column(Modifier.weight(1f).padding(top = 6.dp)) {
            Text(
                Format.weekday(data.today.date).replaceFirstChar { it.uppercase() },
                color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Bold, style = sky
            )
            Text(
                HijriCalendar.format(data.today.date, data.settings.hijriOffset),
                color = TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.Medium, style = sky,
                maxLines = 1
            )
        }
        Column(
            Modifier
                .weight(1f)
                .clip(RoundedCornerShape(14.dp))
                .clickable(role = Role.Button, onClickLabel = tr("Выбрать город"), onClick = onOpenCity)
                .heightIn(min = 48.dp)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.End
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (data.settings.useDeviceLocation) {
                    Glyph(GlyphKind.LOCATION, TextPrimary, Modifier.size(13.dp))
                    Spacer(Modifier.width(6.dp))
                }
                AutoSizeText(
                    data.place.label, color = TextPrimary, fontSize = ui.t(17f), minFontSize = ui.t(13f),
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.End
                )
            }
            Text(
                Format.dayMonth(data.today.date), color = TextSecondary, fontSize = ui.t(13f),
                fontWeight = FontWeight.Medium, style = sky
            )
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * Face 1: the list
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun PrayerListCard(data: PrayerData, now: State<ZonedDateTime>, onOpen: (Prayer) -> Unit) {
    val equal = data.fajrEqualsDawn
    val current = HomeTimeline.current(data.window, equal)
    val next = HomeTimeline.next(data.window, equal)
    BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val width = minOf(maxWidth * 0.74f, 340.dp)
        GlassCard(Modifier.width(width), corner = 22.dp) {
            Spacer(Modifier.height(6.dp))
            HomeTimeline.prayers(equal).forEach { prayer ->
                PrayerRow(
                    prayer = prayer,
                    time = data.today.times[prayer]?.let(Format::time) ?: "—",
                    current = prayer == current,
                    notify = data.settings.notifications[prayer] == true,
                    onClick = { onOpen(prayer) }
                )
            }
            Spacer(Modifier.height(6.dp))
            NextPlate(next, data, now, onClick = { onOpen(next) })
        }
    }
}

@Composable
private fun PrayerRow(prayer: Prayer, time: String, current: Boolean, notify: Boolean, onClick: () -> Unit) {
    val ui = uiScale()
    val title = PrayerLabels.title(prayer)
    val state = buildString {
        append("$title, $time")
        if (current) append(tr(", идёт сейчас"))
        if (prayer.isPrayer) append(if (notify) tr(", уведомление включено") else tr(", уведомление выключено"))
    }
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clickable(role = Role.Button, onClick = onClick)
            .clearAndSetSemantics {
                contentDescription = state
            }
            .padding(start = ui.s(18f), end = ui.s(12f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold,
            maxLines = 1, modifier = Modifier.weight(1f)
        )
        if (prayer.isPrayer) {
            Glyph(
                if (notify) GlyphKind.SOUND else GlyphKind.SOUND_OFF,
                if (notify) TextTertiary else TextTertiary.copy(alpha = 0.7f),
                Modifier.size(15.dp)
            )
            Spacer(Modifier.width(ui.s(10f)))
        }
        Box(
            Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (current) Highlight else Color.Transparent)
                .padding(horizontal = 7.dp, vertical = 3.dp)
        ) {
            Text(time, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

/** The green plate. The only part of the card that reads the clock, so only it recomposes per second. */
@Composable
private fun NextPlate(next: Prayer, data: PrayerData, now: State<ZonedDateTime>, onClick: () -> Unit) {
    val ui = uiScale()
    val left = Format.clock(data.window.remaining(now.value))
    val title = PrayerLabels.title(next)
    Row(
        Modifier
            .fillMaxWidth()
            .background(NextGreen)
            .clickable(role = Role.Button, onClick = onClick)
            .clearAndSetSemantics {
                contentDescription = tr("Следующий: {0}, через {1}", title, left)
            }
            .heightIn(min = 52.dp)
            .padding(horizontal = ui.s(18f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(left, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/* ------------------------------------------------------------------------------------------------
 * Face 2: the clock
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun BigClock(data: PrayerData, now: State<ZonedDateTime>, palette: PhasePalette) {
    val ui = uiScale()
    val sky = TextStyle(shadow = OnSky)
    val next = HomeTimeline.next(data.window, data.fajrEqualsDawn)
    val current = HomeTimeline.current(data.window, data.fajrEqualsDawn)
    Column(
        Modifier.fillMaxWidth().padding(horizontal = ui.s(20f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Следующий"), color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.SemiBold, style = sky)
            Spacer(Modifier.width(10.dp))
            Box(Modifier.size(16.dp).clip(CircleShape).background(palette.accentSoft.copy(alpha = 0.85f)))
            Spacer(Modifier.width(10.dp))
            Text(
                "${PrayerLabels.title(next)} · ${Format.time(data.window.nextStart)}",
                color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.SemiBold, style = sky
            )
        }
        Spacer(Modifier.height(6.dp))
        ClockDigits(data, now, next)
        Spacer(Modifier.height(14.dp))
        WindowProgress(data, now, current)
    }
}

@Composable
private fun ClockDigits(data: PrayerData, now: State<ZonedDateTime>, next: Prayer) {
    val ui = uiScale()
    val text = Format.clock(data.window.remaining(now.value))
    AutoSizeText(
        text, color = TextPrimary, fontSize = ui.t(84f), minFontSize = ui.t(48f),
        fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, letterSpacing = ui.t(-1.5f),
        resizeKey = text.length,
        modifier = Modifier.fillMaxWidth().clearAndSetSemantics {
            contentDescription = tr("До {0}: {1}", PrayerLabels.title(next), text)
        }
    )
}

/** "Сейчас Аср" with a hairline of how much of the window has passed. */
@Composable
private fun WindowProgress(data: PrayerData, now: State<ZonedDateTime>, current: Prayer) {
    val ui = uiScale()
    val progress = data.window.progress(now.value)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .width(ui.s(168f))
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0x40FFFFFF))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(progress)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(TextPrimary)
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            tr("Сейчас {0} · с {1}", PrayerLabels.title(current), Format.time(data.window.currentStart)),
            color = TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.Medium,
            style = TextStyle(shadow = OnSky),
            modifier = Modifier.semantics { contentDescription = tr("Сейчас {0}, прошло {1} процентов", PrayerLabels.title(current), (progress * 100).toInt()) }
        )
    }
}

@Composable
private fun PullHint(modifier: Modifier = Modifier) {
    val ui = uiScale()
    Column(
        modifier.fillMaxWidth().padding(top = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            tr("Потяните вверх — обучение и дела дня"), color = TextPrimary.copy(alpha = 0.92f), fontSize = ui.t(12f),
            fontWeight = FontWeight.Medium, style = TextStyle(shadow = OnSky)
        )
        Box(
            Modifier
                .width(36.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0xB3FFFFFF))
        )
    }
}
