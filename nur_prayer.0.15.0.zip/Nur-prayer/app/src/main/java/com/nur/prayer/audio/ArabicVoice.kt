package com.nur.prayer.audio

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Arabic pronunciation for the course: recorded clips first (assets/audio, see [VoiceText.parseClips]),
 * the system synthesiser otherwise. One per process; every call is made on the main thread and the
 * engine callbacks are posted back to it.
 *
 * The synthesiser is used only for letters, words and short phrases of the course. The Quran and
 * the azkar are never read by it: a machine voice does not know tajweed, and those texts are not
 * the place for its mistakes. They wait for real recitation files.
 */
class ArabicVoice private constructor(context: Context) {
    enum class Status { IDLE, LOADING, READY, NO_VOICE, NO_ENGINE }

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val prefs = app.getSharedPreferences("nur_voice", Context.MODE_PRIVATE)

    private val _status = MutableStateFlow(Status.IDLE)
    val status: StateFlow<Status> = _status.asStateFlow()

    /** The key ([VoiceText.key]) of what is sounding now, null in silence. */
    private val _speaking = MutableStateFlow<String?>(null)
    val speaking: StateFlow<String?> = _speaking.asStateFlow()

    private val _autoplay = MutableStateFlow(prefs.getBoolean(K_AUTOPLAY, true))
    /** New letters and words are voiced as they appear, answers once checked. */
    val autoplay: StateFlow<Boolean> = _autoplay.asStateFlow()

    private val _slow = MutableStateFlow(prefs.getBoolean(K_SLOW, false))
    val slow: StateFlow<Boolean> = _slow.asStateFlow()

    /** Screens that may speak right now; see [attach]. Main thread only. */
    private var holders = 0

    private var tts: TextToSpeech? = null
    private var player: MediaPlayer? = null
    private val clips: Map<String, String> by lazy {
        VoiceText.parseClips(runCatching { app.assets.open("audio/clips.tsv").bufferedReader().use { it.readText() } }.getOrNull())
    }

    /** Connects to the engine once; cheap to call from every screen that may speak. */
    fun warmUp() {
        if (_status.value != Status.IDLE) return
        _status.value = Status.LOADING
        // Google's engine has the best Arabic voices; the platform falls back to the default
        // engine on its own when it is not installed.
        tts = runCatching { TextToSpeech(app, { code -> main.post { onInit(code) } }, GOOGLE_TTS) }
            .getOrElse { _status.value = Status.NO_ENGINE; null }
    }

    /**
     * A screen that may speak came on. Screens overlap during a navigation transition: the old
     * one is disposed ~280 ms after the new one appeared, which is exactly when the new one's
     * autoplay starts. Silencing on every dispose cut that first word, so the voice is stopped
     * only when the last speaking screen leaves.
     */
    fun attach() {
        holders++
        warmUp()
    }

    fun detach() {
        holders = (holders - 1).coerceAtLeast(0)
        if (holders == 0) stop()
    }

    /** After the user came back from installing a voice: look again. */
    fun recheck() {
        val t = tts
        when {
            t == null || _status.value == Status.NO_ENGINE -> { release(); _status.value = Status.IDLE; warmUp() }
            _status.value == Status.NO_VOICE -> configure(t)
        }
    }

    /** True when [text] can be voiced right now, by a clip or by the engine. */
    fun canSay(text: String, status: Status = _status.value): Boolean =
        status == Status.READY || clips.containsKey(VoiceText.key(text))

    fun say(text: String, slow: Boolean = _slow.value) {
        val key = VoiceText.key(text)
        if (key.isEmpty()) return
        stop()
        clips[key]?.let { file -> if (playClip(key, file, slow)) return }
        val t = tts ?: return
        if (_status.value != Status.READY) return
        t.setSpeechRate(VoiceText.rate(slow))
        _speaking.value = key
        if (t.speak(key, TextToSpeech.QUEUE_FLUSH, null, key) != TextToSpeech.SUCCESS) _speaking.value = null
    }

    fun stop() {
        runCatching { tts?.stop() }
        player?.let { p -> runCatching { p.stop() }; p.release() }
        player = null
        _speaking.value = null
    }

    fun setAutoplay(v: Boolean) { _autoplay.value = v; prefs.edit().putBoolean(K_AUTOPLAY, v).apply() }
    fun setSlow(v: Boolean) { _slow.value = v; prefs.edit().putBoolean(K_SLOW, v).apply() }

    /** Opens the engine's "install voice data" screen, or the system TTS settings. */
    fun openInstall(context: Context) {
        val intents = listOf(
            Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA),
            Intent("com.android.settings.TTS_SETTINGS")
        )
        for (i in intents) {
            try {
                context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: ActivityNotFoundException) {
            } catch (_: Exception) {
                // Some vendor settings activities are not exported (SecurityException): try the next one.
            }
        }
    }

    private fun onInit(code: Int) {
        val t = tts ?: return
        if (code != TextToSpeech.SUCCESS) {
            release()
            _status.value = Status.NO_ENGINE
            return
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { main.post { _speaking.value = utteranceId } }
            override fun onDone(utteranceId: String?) { main.post { if (_speaking.value == utteranceId) _speaking.value = null } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { main.post { if (_speaking.value == utteranceId) _speaking.value = null } }
            override fun onError(utteranceId: String?, errorCode: Int) { onDone(utteranceId) }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { onDone(utteranceId) }
        })
        // Media, not ASSISTANCE_ACCESSIBILITY (0.11.0): the accessibility stream has its own volume
        // that the volume keys do not touch, so on many phones the lesson was silent or faint.
        t.setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
        )
        configure(t)
    }

    private fun configure(t: TextToSpeech) {
        val result = runCatching { t.setLanguage(ARABIC) }.getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            _status.value = Status.NO_VOICE
            return
        }
        // The best installed Arabic voice: offline first (no lag, works on the metro), then quality.
        runCatching {
            val best = t.voices.orEmpty()
                .filter { v -> v.locale.language == "ar" && !v.features.orEmpty().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) }
                .sortedWith(compareBy<Voice>({ it.isNetworkConnectionRequired }, { -it.quality }))
                .firstOrNull()
            if (best != null) t.voice = best
        }
        _status.value = Status.READY
    }

    /** A recording; for the slow button it is time-stretched (pitch kept), so one clip serves both. */
    private fun playClip(key: String, file: String, slow: Boolean): Boolean {
        var p: MediaPlayer? = null
        return try {
            val mp = MediaPlayer().also { p = it }
            app.assets.openFd("audio/$file").use { fd -> mp.setDataSource(fd.fileDescriptor, fd.startOffset, fd.length) }
            mp.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            mp.setOnCompletionListener { done ->
                if (player === done) { player = null; _speaking.value = null }
                done.release()
            }
            mp.prepare()
            player = mp
            _speaking.value = key
            if (slow) runCatching { mp.playbackParams = mp.playbackParams.setSpeed(VoiceText.CLIP_SLOW_SPEED) }
            mp.start()
            true
        } catch (_: Exception) {
            // A compressed or missing clip falls through to the synthesiser.
            p?.release()
            if (player === p) player = null
            false
        }
    }

    private fun release() {
        runCatching { tts?.shutdown() }
        tts = null
    }

    companion object {
        private const val GOOGLE_TTS = "com.google.android.tts"
        private const val K_AUTOPLAY = "autoplay"
        private const val K_SLOW = "slow"
        private val ARABIC: Locale = Locale.forLanguageTag("ar")

        @Volatile private var instance: ArabicVoice? = null

        fun get(context: Context): ArabicVoice =
            instance ?: synchronized(this) { instance ?: ArabicVoice(context).also { instance = it } }
    }
}
