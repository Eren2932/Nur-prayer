package com.nur.prayer.ui.settings

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.res.ResourcesCompat
import com.nur.prayer.i18n.tr
import com.nur.prayer.icon.AppIcon
import com.nur.prayer.icon.title
import com.nur.prayer.ui.components.Caption
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/**
 * 0.15.0 launcher icon grid, four to a row.
 *
 * The tile is the real launcher resource drawn through [android.graphics.drawable.AdaptiveIconDrawable],
 * so it carries the phone's own icon mask (circle on Pixel, squircle on Samsung, ...) and the
 * preview cannot drift from what the home screen will show. The selection is a rounded frame in
 * the accent colour plus a small check that draws itself in, as in the language list.
 */
@Composable
internal fun ColumnScope.AppIconPicker(selected: AppIcon, accent: Color, onSelect: (AppIcon) -> Unit) {
    val ui = uiScale()
    Text(
        tr("Иконка приложения").uppercase(),
        color = TextTertiary, fontSize = ui.t(11.5f), fontWeight = FontWeight.SemiBold,
        letterSpacing = ui.t(0.8f),
        modifier = Modifier.padding(start = ui.s(2f), bottom = ui.s(12f))
    )
    AppIcon.entries.chunked(COLUMNS).forEachIndexed { rowIndex, row ->
        if (rowIndex > 0) Spacer(Modifier.height(ui.s(14f)))
        Row(Modifier.fillMaxWidth()) {
            row.forEach { icon ->
                IconTile(icon, icon == selected, accent, Modifier.weight(1f)) { if (icon != selected) onSelect(icon) }
            }
            // A short last row keeps the column width instead of stretching its tiles.
            repeat(COLUMNS - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
    Spacer(Modifier.height(ui.s(14f)))
    Caption(tr("Иконка сменится, когда вы выйдете из Nur на главный экран. На некоторых лаунчерах ярлык с рабочего стола придётся вернуть из списка приложений."))
}

private const val COLUMNS = 4

@Composable
private fun IconTile(icon: AppIcon, selected: Boolean, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    val ui = uiScale()
    val haptics = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 0.9f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium), label = "iconPress")
    val check by animateFloatAsState(if (selected) 1f else 0f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow), label = "iconCheck")
    val frame by animateColorAsState(if (selected) accent else Color.Transparent, tween(200), label = "iconFrame")
    val label by animateColorAsState(if (selected) TextPrimary else TextSecondary, tween(200), label = "iconLabel")
    val name = icon.title()
    val shape = RoundedCornerShape(ui.s(20f))

    Column(
        modifier
            .testTag("app-icon-${icon.id}")
            .selectable(selected = selected, interactionSource = interaction, indication = null, role = Role.RadioButton) {
                haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .semantics { contentDescription = tr("Иконка «{0}»", name) }
            .padding(horizontal = ui.s(3f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .graphicsLayer { scaleX = press; scaleY = press }
                .border(2.dp, frame, shape)
                .padding(ui.s(6f))
        ) {
            LauncherIcon(icon, Modifier.fillMaxWidth().aspectRatio(1f))
            if (check > 0.01f) {
                CheckMark(accent, check, Modifier.align(Alignment.TopEnd).offset(x = ui.s(9f), y = -ui.s(9f)).size(ui.s(20f)))
            }
        }
        Spacer(Modifier.height(ui.s(6f)))
        Text(name, color = label, fontSize = ui.t(12f),
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth())
    }
}

/** The actual mipmap, drawn by the platform with the device's icon mask. */
@Composable
private fun LauncherIcon(icon: AppIcon, modifier: Modifier) {
    val context = LocalContext.current
    val drawable = remember(icon) { ResourcesCompat.getDrawable(context.resources, icon.launcher, null) }
    Canvas(modifier) {
        val d = drawable ?: return@Canvas
        drawIntoCanvas { canvas ->
            d.setBounds(0, 0, size.width.toInt(), size.height.toInt())
            d.draw(canvas.nativeCanvas)
        }
    }
}
