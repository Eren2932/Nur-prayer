package com.nur.prayer.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import kotlin.math.roundToInt

/*
 * 0.13.0 home menu: one round button bottom-left that opens into a capsule to the right.
 *
 *  - The capsule is one surface whose width is a single 0→1 spring value, read only in the layout
 *    phase: opening re-lays out one small node per frame and never recomposes the home screen.
 *  - While open, a transparent layer over the sky closes it on any tap outside and the system Back
 *    closes it before leaving home. The layer also swallows the sky's own tap (list ⇄ clock), so
 *    dismissing the menu never flips the home face by accident.
 *  - Choosing an item reports the item's centre in root coordinates: the page then grows out of
 *    that exact point (see MenuReveal in NurRoot).
 *
 * 0.14.2:
 *  - FIX "the button sticks". Collapsed items were parked *on top of the toggle* (translated over it,
 *    alpha 0, scale 0.5) and were later siblings in the Row, so hit testing reached them first. A
 *    disabled `clickable` is still a pointer-input node: the tap landed on an invisible item and
 *    the toggle never saw it — only taps on the toggle's rim got through. Now the toggle is drawn
 *    and hit-tested above the items (zIndex) and a closed item has no pointer input and no
 *    semantics at all.
 *  - New motion: the items *roll* out. The capsule's right edge carries them like a tape: each one
 *    rides the edge until it reaches its own slot and stays there, turning by exactly
 *    distance / radius, so it rolls without slipping. The last one rides all the way and follows
 *    the spring's overshoot a little, then rolls back. The knob itself is unscrewed: the dots turn
 *    half a revolution into the cross. Closing gathers them back under the knob in reverse.
 */

class MenuEntry(val glyph: GlyphKind, val label: String, val onClick: (Offset) -> Unit)

private val BUTTON = 48.dp
private val ITEM = 44.dp
private val GAP = 6.dp

/**
 * The outside-tap layer. Drawn under the capsule, over everything else on home.
 *
 * [dim] is read only in the draw phase, so fading the shade costs no recomposition. The layer stays
 * composed while it fades out but stops intercepting at once: a tap right after closing is a normal
 * tap again.
 */
@Composable
fun MenuScrim(open: Boolean, dim: () -> Float, onDismiss: () -> Unit) {
    val dismiss by rememberUpdatedState(onDismiss)
    Box(
        Modifier
            .fillMaxSize()
            .drawBehind { val a = dim(); if (a > 0f) drawRect(Color.Black, alpha = 0.22f * a) }
            .then(
                if (!open) Modifier else Modifier
                    .pointerInput(Unit) {
                        // Consume the whole gesture, down to the last move: the sky under it must not
                        // see a tap (face switch) nor a drag (the pull-up layer).
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false).consume()
                            dismiss()
                            do {
                                val event = awaitPointerEvent()
                                event.changes.forEach { it.consume() }
                            } while (event.changes.any { it.pressed })
                        }
                    }
                    .semantics { contentDescription = tr("Закрыть меню") }
            )
    )
}

@Composable
fun MenuCapsule(
    open: Boolean,
    onOpenChange: (Boolean) -> Unit,
    entries: List<MenuEntry>,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val expand = remember { Animatable(if (open) 1f else 0f) }
    // "Remove animations" in Android scales these to zero by itself (MotionDurationScale).
    LaunchedEffect(open) {
        // Fast and a touch springy on the way out, critically damped and faster still on the way in:
        // opening should feel alive, closing should feel like a release.
        if (open) expand.animateTo(1f, spring(dampingRatio = 0.68f, stiffness = 420f))
        else expand.animateTo(0f, spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 900f))
    }
    BackHandler(enabled = open) { onOpenChange(false) }

    val items = entries.size
    val direction = if (LocalLayoutDirection.current == LayoutDirection.Rtl) -1f else 1f
    // Order matters: clip + background sit outside the layout modifier, so they take the animated
    // width and crop the full-width row placed inside it. The other way round the pill would be
    // drawn at full width from the first frame and only the icons would animate.
    Box(
        modifier
            .clip(CircleShape)
            .background(SurfaceRaised)
            .layout { measurable, constraints ->
                val p = measurable.measure(constraints.copy(minWidth = 0, maxWidth = Constraints.Infinity))
                val collapsed = BUTTON.roundToPx()
                // The spring may overshoot 1 a little: let the capsule breathe past its width too.
                val w = (collapsed + (p.width - collapsed) * expand.value).roundToInt().coerceAtLeast(collapsed)
                layout(w, p.height) { p.placeRelative(0, 0) }
            }
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Above the items: while collapsed they sit under the knob and must never catch its tap.
            ToggleButton(open, expand, Modifier.zIndex(1f)) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onOpenChange(!open)
            }
            entries.forEachIndexed { i, entry ->
                MenuItemButton(entry, i, items, expand, direction, enabled = open) { origin ->
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onOpenChange(false)
                    entry.onClick(origin)
                }
                if (i < items - 1) Spacer(Modifier.width(GAP))
            }
            Spacer(Modifier.width(GAP))
        }
    }
}

@Composable
private fun ToggleButton(open: Boolean, expand: Animatable<Float, *>, modifier: Modifier, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box(
        modifier
            .size(BUTTON)
            .clip(CircleShape)
            .semantics {
                contentDescription = tr("Меню")
                stateDescription = if (open) tr("Открыто") else tr("Закрыто")
            }
            .clickable(interactionSource = interaction, indication = ripple(), role = Role.Button, onClick = onClick)
            .graphicsLayer { val k = if (pressed) 0.92f else 1f; scaleX = k; scaleY = k },
        contentAlignment = Alignment.Center
    ) {
        // The knob is unscrewed: dots and cross share the spot and turn half a revolution together.
        // The overshoot of the spring is kept in the turn (not in the alpha), so the cross settles.
        Glyph(GlyphKind.MORE, TextPrimary, Modifier.size(BUTTON * 0.42f).graphicsLayer {
            val e = expand.value
            alpha = 1f - (e * 1.6f).coerceIn(0f, 1f)
            rotationZ = e * 180f
            val k = 1f - 0.35f * e.coerceIn(0f, 1f); scaleX = k; scaleY = k
        })
        Glyph(GlyphKind.CLOSE, TextPrimary, Modifier.size(BUTTON * 0.42f).graphicsLayer {
            val e = expand.value
            alpha = ((e - 0.25f) / 0.75f).coerceIn(0f, 1f)
            rotationZ = (e - 1f) * 180f
            val k = 0.6f + 0.4f * e.coerceIn(0f, 1f); scaleX = k; scaleY = k
        })
    }
}

@Composable
private fun MenuItemButton(
    entry: MenuEntry, index: Int, count: Int, expand: Animatable<Float, *>, direction: Float, enabled: Boolean,
    onClick: (Offset) -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val coords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    Box(
        Modifier
            .size(ITEM)
            .onGloballyPositioned { coords[0] = it }
            .graphicsLayer {
                val roll = MenuRoll.at(
                    expand = expand.value, index = index, count = count,
                    button = BUTTON.toPx(), item = ITEM.toPx(), gap = GAP.toPx()
                )
                translationX = direction * roll.shift
                rotationZ = direction * roll.degrees
                alpha = roll.alpha
                val k = roll.scale * (if (pressed) 0.9f else 1f)
                scaleX = k; scaleY = k
            }
            .clip(CircleShape)
            .then(
                // Closed: no pointer input, no semantics. Not merely disabled — a disabled clickable
                // still takes part in hit testing (the 0.14.1 "sticky button").
                if (!enabled) Modifier.clearAndSetSemantics { }
                else Modifier
                    .semantics { contentDescription = entry.label }
                    .clickable(interactionSource = interaction, indication = ripple(), role = Role.Button) {
                        val c = coords[0]
                        val origin = if (c != null && c.isAttached) c.positionInRoot() + Offset(c.size.width / 2f, c.size.height / 2f)
                        else Offset.Unspecified
                        onClick(origin)
                    }
            )
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        Glyph(entry.glyph, TextPrimary, Modifier.size(ITEM * 0.46f))
    }
}

/**
 * Geometry of the rolling items, pure arithmetic so it is unit-tested (MenuRollTest).
 *
 * Row layout: knob, then `count` items with [gap] after each. The visible capsule width at spring
 * value `e` is `button + (full - button) * e`. An item rides the inner right edge (`width - gap`)
 * until it reaches its slot; before that it is shifted left by the missing distance, never further
 * than fully under the knob. Rotation = shift / radius: rolling without slipping.
 */
internal object MenuRoll {
    class State(val shift: Float, val degrees: Float, val alpha: Float, val scale: Float)

    fun at(expand: Float, index: Int, count: Int, button: Float, item: Float, gap: Float): State {
        val n = count.coerceAtLeast(1)
        val full = button + n * (item + gap)
        val width = button + (full - button) * expand
        val slotLeft = button + index * (item + gap)
        val slotRight = slotLeft + item
        var shift = (width - gap) - slotRight
        // Only the last item stays on the edge past its slot (the spring's overshoot), a little.
        shift = if (index == n - 1) shift.coerceAtMost(gap * 2f) else shift.coerceAtMost(0f)
        shift = shift.coerceAtLeast(-slotLeft)
        val out = (1f + shift.coerceAtMost(0f) / slotLeft).coerceIn(0f, 1f) // 0 under the knob, 1 in its slot
        val degrees = Math.toDegrees((shift / (item / 2f)).toDouble()).toFloat()
        val alpha = ((out - 0.12f) / 0.45f).coerceIn(0f, 1f)
        val eased = 1f - (1f - out) * (1f - out)
        return State(shift, degrees, alpha, 0.55f + 0.45f * eased)
    }
}
