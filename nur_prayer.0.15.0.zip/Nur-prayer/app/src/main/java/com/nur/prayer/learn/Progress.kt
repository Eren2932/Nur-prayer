package com.nur.prayer.learn

/** Best result of a lesson: 1–3 stars, accuracy in percent. */
data class LessonResult(val stars: Int, val accuracy: Int)

/**
 * A Leitner card: [box] grows with every spaced correct answer, [due] is the epoch day it comes
 * back. Box 0 means "seen, not yet remembered"; from [LEARNED_BOX] on the item counts as learned.
 */
data class Card(val box: Int, val due: Long)

/** Immutable learning state. Every transition returns a new value; LearnStore persists it. */
data class LearnProgress(
    val lessons: Map<String, LessonResult> = emptyMap(),
    val cards: Map<String, Card> = emptyMap(),
    val xp: Int = 0,
    val streak: Int = 0,
    val lastDay: Long = Long.MIN_VALUE
) {
    fun isDone(lessonId: String): Boolean = (lessons[lessonId]?.stars ?: 0) > 0

    fun stars(lessonId: String): Int = lessons[lessonId]?.stars ?: 0

    /** The streak as the user sees it today: a missed day shows 0 before the next lesson is done. */
    fun streakOn(today: Long): Int = if (lastDay == today || lastDay == today - 1) streak else 0

    fun due(today: Long): List<String> = cards.filter { it.value.due <= today }
        .entries.sortedWith(compareBy({ it.value.due }, { it.value.box })).map { it.key }

    fun learnedWords(): Int = cards.count { it.key.startsWith(WORD) && it.value.box >= LEARNED_BOX }
    fun seenWords(): Int = cards.count { it.key.startsWith(WORD) }
    fun learnedLetters(): Int = cards.count { it.key.startsWith(LETTER) && it.value.box >= LEARNED_BOX }

    /** Registers newly introduced cards without disturbing ones already in the system. */
    fun introduce(keys: Collection<String>, today: Long): LearnProgress {
        val fresh = keys.filter { it !in cards }
        if (fresh.isEmpty()) return this
        return copy(cards = cards + fresh.associateWith { Card(0, today) })
    }

    /**
     * One graded answer. Correct moves the card one box up and pushes it out by that box's interval,
     * but only if the card was due — drilling the same word twice in a day does not inflate its box.
     * A mistake sends the card back to box 0, due today.
     */
    fun answer(keys: Collection<String>, correct: Boolean, today: Long): LearnProgress {
        if (keys.isEmpty()) return this
        val updated = cards.toMutableMap()
        for (key in keys) {
            val card = updated[key] ?: Card(0, today)
            updated[key] = when {
                !correct -> Card(0, today)
                card.due > today -> card
                else -> {
                    val box = (card.box + 1).coerceAtMost(INTERVALS.lastIndex)
                    Card(box, today + INTERVALS[box])
                }
            }
        }
        return copy(cards = updated)
    }

    /** A finished lesson: keeps the best result, adds XP, advances the daily streak. */
    fun complete(lessonId: String, accuracy: Double, correct: Int, today: Long): LearnProgress {
        val stars = starsFor(accuracy)
        val percent = (accuracy * 100).toInt().coerceIn(0, 100)
        val old = lessons[lessonId]
        val best = if (old == null || stars > old.stars || (stars == old.stars && percent > old.accuracy))
            LessonResult(stars, percent) else old
        val nextLessons = if (stars > 0 || old != null) lessons + (lessonId to best) else lessons
        val newStreak = when (lastDay) {
            today -> streak
            today - 1 -> streak + 1
            else -> 1
        }
        return copy(lessons = nextLessons, xp = xp + LESSON_XP + correct, streak = newStreak, lastDay = today)
    }

    /** Test-out: completes the given lessons that are not completed yet, with one star. */
    fun pass(lessonIds: Collection<String>): LearnProgress =
        copy(lessons = lessons + lessonIds.filter { !isDone(it) }.associateWith { LessonResult(1, 80) })

    fun encode(): String = buildString {
        append(FORMAT).append('\n')
        append(xp).append('\t').append(streak).append('\t').append(lastDay).append('\n')
        lessons.forEach { (id, r) -> append("L\t").append(id).append('\t').append(r.stars).append('\t').append(r.accuracy).append('\n') }
        cards.forEach { (key, c) -> append("C\t").append(key).append('\t').append(c.box).append('\t').append(c.due).append('\n') }
    }

    companion object {
        const val WORD = "W:"
        const val LETTER = "L:"
        const val LEARNED_BOX = 3
        const val LESSON_XP = 10
        private const val FORMAT = "nur-learn-1"
        /** Days until the next showing, per box. */
        val INTERVALS = intArrayOf(0, 1, 2, 4, 8, 16, 32)

        fun starsFor(accuracy: Double): Int = when {
            accuracy >= 0.95 -> 3
            accuracy >= 0.8 -> 2
            accuracy >= 0.6 -> 1
            else -> 0
        }

        fun wordKey(word: Word) = WORD + word.id
        fun letterKey(letter: Letter) = LETTER + letter.char

        /** Lenient: an unknown or damaged line is skipped, an unknown format starts fresh. */
        fun decode(text: String?): LearnProgress {
            if (text.isNullOrBlank()) return LearnProgress()
            val lines = text.lines()
            if (lines.first() != FORMAT) return LearnProgress()
            val head = lines.getOrNull(1)?.split('\t')
            val lessons = HashMap<String, LessonResult>()
            val cards = HashMap<String, Card>()
            for (line in lines.drop(2)) {
                val c = line.split('\t')
                if (c.size != 4) continue
                val a = c[2].toIntOrNull() ?: continue
                when (c[0]) {
                    "L" -> c[3].toIntOrNull()?.let { lessons[c[1]] = LessonResult(a.coerceIn(0, 3), it.coerceIn(0, 100)) }
                    "C" -> c[3].toLongOrNull()?.let { cards[c[1]] = Card(a.coerceIn(0, INTERVALS.lastIndex), it) }
                }
            }
            return LearnProgress(lessons, cards,
                xp = head?.getOrNull(0)?.toIntOrNull() ?: 0,
                streak = head?.getOrNull(1)?.toIntOrNull() ?: 0,
                lastDay = head?.getOrNull(2)?.toLongOrNull() ?: Long.MIN_VALUE)
        }
    }
}

/**
 * The running lesson. A wrongly answered exercise is queued once more at the end, so a lesson is
 * never finished on a mistake; accuracy counts first attempts only, so the retry cannot pad it.
 */
data class LessonSession(
    val queue: List<Exercise>,
    val position: Int = 0,
    val graded: Int = 0,
    val firstTryCorrect: Int = 0,
    val retried: Set<Int> = emptySet(),
    val originalCount: Int = queue.size,
    val mistakes: List<Exercise> = emptyList()
) {
    val current: Exercise? get() = queue.getOrNull(position)
    val finished: Boolean get() = position >= queue.size
    val fraction: Float get() = if (queue.isEmpty()) 1f else position.toFloat() / queue.size
    val accuracy: Double get() = if (graded == 0) 1.0 else firstTryCorrect.toDouble() / graded

    /** Moves past an intro card, which is not graded. */
    fun skip(): LessonSession = copy(position = position + 1)

    fun answer(correct: Boolean): LessonSession {
        val exercise = current ?: return this
        val isRetry = position >= originalCount
        val requeue = !correct && position !in retried && !isRetry
        return copy(
            queue = if (requeue) queue + exercise else queue,
            retried = if (requeue) retried + position else retried,
            position = position + 1,
            graded = if (isRetry) graded else graded + 1,
            firstTryCorrect = if (correct && !isRetry) firstTryCorrect + 1 else firstTryCorrect,
            mistakes = if (!correct && !isRetry) mistakes + exercise else mistakes
        )
    }
}
