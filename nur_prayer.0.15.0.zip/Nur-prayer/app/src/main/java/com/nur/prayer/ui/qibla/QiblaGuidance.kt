package com.nur.prayer.ui.qibla

import com.nur.prayer.i18n.tr

import kotlin.math.abs
import kotlin.math.roundToInt

/** Pure presentation policy: never give a turn instruction from an untrusted sensor reading. */
object QiblaGuidance {
    const val ALIGN_TOLERANCE = 2.5f

    fun aligned(delta: Float, available: Boolean, trustworthy: Boolean, flat: Boolean): Boolean =
        delta.isFinite() && available && trustworthy && flat && abs(delta) <= ALIGN_TOLERANCE

    fun instruction(delta: Float, available: Boolean, trustworthy: Boolean, flat: Boolean): String = when {
        !available -> tr("Компас недоступен")
        !delta.isFinite() || !trustworthy -> tr("Проверьте калибровку и помехи")
        !flat -> tr("Положите телефон горизонтально")
        abs(delta) <= ALIGN_TOLERANCE -> tr("Направление на Каабу")
        delta > 0f -> tr("Поверните вправо на {0}°", abs(delta).roundToInt())
        else -> tr("Поверните влево на {0}°", abs(delta).roundToInt())
    }

    fun degrees(value: Float): String = if (value.isFinite()) "${normalize(value).roundToInt() % 360}°" else "—"
}
