package com.nur.prayer.ui.daily

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nur.prayer.daily.DailyStore
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.StoryMath
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

/**
 * Daily counters. Every tap updates memory first and writes in the background; the day rolls over
 * lazily on the first tap of a new day, so a counter left open overnight starts from zero.
 *
 * 0.11.0: all writes go through one queue drained by one coroutine. In 0.10.0 every tap launched
 * its own IO job; fast dhikr taps could land out of order and leave an older count on disk.
 */
class DailyViewModel(application: Application) : AndroidViewModel(application) {
    private val store = DailyStore(application)

    private val _dhikrToday = MutableStateFlow<Map<String, Long>>(emptyMap())
    val dhikrToday: StateFlow<Map<String, Long>> = _dhikrToday.asStateFlow()
    private val _dhikrTotal = MutableStateFlow<Map<String, Long>>(emptyMap())
    val dhikrTotal: StateFlow<Map<String, Long>> = _dhikrTotal.asStateFlow()
    private val _selected = MutableStateFlow(Dhikr.PRESETS.first().id)
    val selected: StateFlow<String> = _selected.asStateFlow()
    private val _azkar = MutableStateFlow<Map<String, Map<String, Long>>>(emptyMap())
    val azkar: StateFlow<Map<String, Map<String, Long>>> = _azkar.asStateFlow()
    /** Slides seen today, one bit per slide (see [StoryMath]). */
    private val _storyMask = MutableStateFlow(0)
    val storyMask: StateFlow<Int> = _storyMask.asStateFlow()
    private val _translit = MutableStateFlow(true)
    val translit: StateFlow<Boolean> = _translit.asStateFlow()

    /** Which slide the story viewer opens on. */
    var storyStart: Int = 0
        private set
    /** Bumped on every opening, so the viewer starts fresh instead of restoring the last slide. */
    var storyOpening: Int = 0
        private set

    @Volatile private var dhikrDay = today()
    @Volatile private var storyDay = today()

    private val writes = Channel<() -> Unit>(Channel.UNLIMITED)

    init {
        // One coroutine reads the disk first and only then starts draining writes. 0.11.0 ran the
        // two in parallel: a tap before the load finished wrote its early snapshot ({id: 1}) over
        // the stored count, and the load could then read that back and add the tap a second time.
        // Writes now read the live state when they run, so queued ones save the merged result.
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { load() }
            for (w in writes) runCatching { w() }
        }
    }

    private fun load() {
        // A tap made before the disk answered is kept on top of what was stored. update {} is a
        // compare-and-set loop: a tap landing during the merge is retried, not lost.
        val storedToday = store.dhikrToday(dhikrDay)
        val storedTotal = store.dhikrTotal()
        _dhikrToday.update { early -> merge(storedToday, early) }
        _dhikrTotal.update { early -> merge(storedTotal, early) }
        store.selectedDhikr()?.let { id -> if (Dhikr.PRESETS.any { it.id == id }) _selected.value = id }
        val storedAzkar = store.azkar()
        _azkar.update { early -> mergeAzkar(storedAzkar, early) }
        val storedMask = store.storySeenMask(storyDay)
        _storyMask.update { it or storedMask }
        _translit.value = store.showTranslit()
    }

    /** Early azkar taps on top of the stored sessions: per item the larger count wins (both are capped). */
    private fun mergeAzkar(stored: Map<String, Map<String, Long>>, early: Map<String, Map<String, Long>>): Map<String, Map<String, Long>> {
        if (early.isEmpty()) return stored
        val out = LinkedHashMap(stored)
        early.forEach { (session, counts) ->
            val cur = LinkedHashMap(out[session].orEmpty())
            counts.forEach { (id, n) -> cur[id] = maxOf(cur[id] ?: 0L, n) }
            out[session] = cur
        }
        return out
    }

    private fun merge(a: Map<String, Long>, b: Map<String, Long>): Map<String, Long> {
        if (b.isEmpty()) return a
        val out = LinkedHashMap(a)
        b.forEach { (k, v) -> out[k] = (out[k] ?: 0L) + v }
        return out
    }

    private fun write(block: () -> Unit) { writes.trySend(block) }

    fun today(): Long = LocalDate.now().toEpochDay()

    private fun rollDay() {
        val t = today()
        if (t != dhikrDay) { dhikrDay = t; _dhikrToday.value = emptyMap() }
        if (t != storyDay) { storyDay = t; _storyMask.value = 0 }
    }

    fun dhikrTap(id: String): Long {
        rollDay()
        val n = (_dhikrToday.value[id] ?: 0L) + 1
        _dhikrToday.value = _dhikrToday.value + (id to n)
        _dhikrTotal.value = _dhikrTotal.value + (id to ((_dhikrTotal.value[id] ?: 0L) + 1))
        saveDhikr()
        return n
    }

    /** Takes back the last tap (a slip of the finger). Today and the all-time total both lose one. */
    fun dhikrUndo(id: String): Long {
        rollDay()
        val cur = _dhikrToday.value[id] ?: 0L
        if (cur <= 0L) return 0L
        _dhikrToday.value = _dhikrToday.value + (id to (cur - 1))
        val tot = _dhikrTotal.value[id] ?: 0L
        if (tot > 0L) _dhikrTotal.value = _dhikrTotal.value + (id to (tot - 1))
        saveDhikr()
        return cur - 1
    }

    /** Resets today's count only; the all-time total keeps what was said. */
    fun dhikrReset(id: String) {
        rollDay()
        _dhikrToday.value = _dhikrToday.value - id
        saveDhikr()
    }

    fun select(id: String) {
        _selected.value = id
        write { store.saveSelectedDhikr(id) }
    }

    fun todayCount(id: String): Long {
        rollDay()
        return _dhikrToday.value[id] ?: 0L
    }

    private fun saveDhikr() {
        write { store.saveDhikr(dhikrDay, _dhikrToday.value, _dhikrTotal.value) }
    }

    /** One more repetition of azkar [id] in [session], capped at [max]. Returns the new count. */
    fun azkarTap(session: String, id: String, max: Int): Long {
        val cur = _azkar.value[session].orEmpty()
        val n = ((cur[id] ?: 0L) + 1).coerceAtMost(max.toLong())
        val next = LinkedHashMap(_azkar.value)
        next.remove(session)
        next[session] = cur + (id to n)
        _azkar.value = next
        write { store.saveAzkar(_azkar.value) }
        return n
    }

    fun azkarReset(session: String) {
        val next = LinkedHashMap(_azkar.value)
        next.remove(session)
        _azkar.value = next
        write { store.saveAzkar(_azkar.value) }
    }

    fun openStory(start: Int) {
        storyStart = start.coerceAtLeast(0)
        storyOpening++
    }

    fun markStorySeen(index: Int) {
        rollDay()
        val mask = StoryMath.withSeen(_storyMask.value, index)
        if (mask == _storyMask.value) return
        _storyMask.value = mask
        write { store.saveStorySeen(storyDay, _storyMask.value) }
    }

    fun setTranslit(v: Boolean) {
        _translit.value = v
        write { store.saveShowTranslit(v) }
    }
}
