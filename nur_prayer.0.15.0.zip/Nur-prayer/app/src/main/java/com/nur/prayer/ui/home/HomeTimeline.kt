package com.nur.prayer.ui.home

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.core.astro.PrayerWindow
import java.time.ZonedDateTime

/**
 * What the home screen lists and marks. Pure, so the edge cases are unit-tested rather than eyeballed.
 *
 * The one subtle case is a tradition without a separate congregational Fajr: there Сухур and Фаджр
 * are the same instant, the list shows only Фаджр, and the engine may still report SAHAR as the
 * current or next window (stable sort puts it first). Every lookup goes through [visible] so such a
 * window lands on the Фаджр row instead of on nothing.
 */
object HomeTimeline {

    fun prayers(fajrEqualsDawn: Boolean): List<Prayer> =
        if (fajrEqualsDawn) Prayer.entries.filter { it != Prayer.SAHAR } else Prayer.entries.toList()

    fun visible(prayer: Prayer, fajrEqualsDawn: Boolean): Prayer =
        if (fajrEqualsDawn && prayer == Prayer.SAHAR) Prayer.FAJR else prayer

    /** Row marked as "now". */
    fun current(window: PrayerWindow, fajrEqualsDawn: Boolean): Prayer = visible(window.current, fajrEqualsDawn)

    /** Prayer in the green plate. */
    fun next(window: PrayerWindow, fajrEqualsDawn: Boolean): Prayer = visible(window.next, fajrEqualsDawn)

    /**
     * When the window opened by [prayer] closes: the first later time of the day, or the first time
     * of the following day for Иша. Null when the engine could not produce either (polar edge).
     */
    fun endOf(prayer: Prayer, today: PrayerDay, tomorrow: PrayerDay?, fajrEqualsDawn: Boolean): Pair<Prayer, ZonedDateTime>? {
        val order = prayers(fajrEqualsDawn)
        val start = today.times[prayer] ?: return null
        order.forEach { candidate ->
            val time = today.times[candidate]
            if (time != null && time.isAfter(start)) return candidate to time
        }
        if (tomorrow == null) return null
        order.forEach { candidate ->
            val time = tomorrow.times[candidate]
            if (time != null && time.isAfter(start)) return candidate to time
        }
        return null
    }

    /** Page dots: the sheet pages follow the list, so the index is the row index. */
    fun pageOf(prayer: Prayer, fajrEqualsDawn: Boolean): Int =
        prayers(fajrEqualsDawn).indexOf(visible(prayer, fajrEqualsDawn)).coerceAtLeast(0)
}
