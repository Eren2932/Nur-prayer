package com.nur.prayer.ui.components

import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Shape

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit

/**
 * One motion language for the learning and daily screens: springs, not fixed durations, so a
 * touch that interrupts an animation picks it up from where it is instead of jumping. Springs
 * also ignore nothing: with Android's "remove animations" they settle at once, which is the
 * behaviour the user asked for.
 */
object NurMotion {
    // FiniteAnimationSpec, not AnimationSpec: enter/exit transitions (slideIn, fadeIn, scaleIn,
    // expandVertically…) accept only finite specs. 0.11.0 declared AnimationSpec here and every
    // transition that used these springs failed to compile. A spring is finite, so this is exact.

    /** Presses, toggles, small state changes: fast and without overshoot. */
    fun <T> snappy(): FiniteAnimationSpec<T> = spring(dampingRatio = 0.8f, stiffness = 900f)
    /** Things that "land": a star, a counter, a correct answer. A little overshoot. */
    fun <T> bouncy(): FiniteAnimationSpec<T> = spring(dampingRatio = 0.5f, stiffness = 520f)
    /** Large surfaces: sheets, story drag-back, expanding cards. */
    fun <T> gentle(): FiniteAnimationSpec<T> = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 420f)

    const val PRESS_SCALE = 0.95f
}

/**
 * A clickable that gives way under the finger and springs back: scale on press, ripple, light
 * haptic. The caller clips; this does not, so it composes with any shape.
 */
fun Modifier.pressClick(
    enabled: Boolean = true,
    scaleTo: Float = NurMotion.PRESS_SCALE,
    haptic: Boolean = true,
    role: Role = Role.Button,
    shape: Shape? = null,
    onClick: () -> Unit
): Modifier = composed {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed && enabled) scaleTo else 1f, NurMotion.snappy(), label = "pressClick")
    val feedback = LocalHapticFeedback.current
    this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .then(if (shape != null) Modifier.clip(shape) else Modifier)
        .clickable(interactionSource = interaction, indication = ripple(), enabled = enabled, role = role) {
            if (haptic) feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }
}

/**
 * The moment a screen appeared, shared by its staggered blocks. In a lazy list an item scrolled
 * away and back is composed anew; with a clock it sees that its turn is long past and shows at
 * once instead of replaying the entrance on every scroll.
 */
class EntranceClock internal constructor(internal val startNanos: Long) {
    internal fun elapsedMillis(): Long = (System.nanoTime() - startNanos) / 1_000_000
}

/** A fresh clock per screen; pass [key] to restart the cascade (another surah, another topic). */
@Composable
fun rememberEntranceClock(key: Any? = Unit): EntranceClock = remember(key) { EntranceClock(System.nanoTime()) }

/** Pure timing of [entrance], unit-tested: when the [order]-th block starts, and if it is too late to animate. */
object EntranceMath {
    const val STEP_MILLIS = 45
    const val MAX_DELAY_MILLIS = 360
    const val DURATION_MILLIS = 380

    fun delayOf(order: Int): Int = (order.coerceAtLeast(0) * STEP_MILLIS).coerceAtMost(MAX_DELAY_MILLIS)

    /** Delay still to wait, or null when the block should simply be shown (its animation would be over). */
    fun remainingDelay(order: Int, elapsedMillis: Long): Int? {
        val delay = delayOf(order)
        if (elapsedMillis >= delay + DURATION_MILLIS) return null
        return (delay - elapsedMillis).coerceAtLeast(0L).toInt()
    }
}

/**
 * Staggered entrance: the [order]-th block rises and fades in [order] × 45 ms after the screen
 * appears. Pure graphicsLayer, no relayout. Without a [clock] it runs once per composition of the
 * block (fine for a plain scrolling Column); inside a LazyColumn pass the screen's clock.
 */
fun Modifier.entrance(order: Int, distance: Float = 36f, clock: EntranceClock? = null): Modifier = composed {
    val wait = remember { if (clock == null) EntranceMath.delayOf(order) else EntranceMath.remainingDelay(order, clock.elapsedMillis()) }
    val progress = remember { Animatable(if (wait == null) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (wait != null) progress.animateTo(1f, tween(durationMillis = EntranceMath.DURATION_MILLIS, delayMillis = wait))
    }
    this.graphicsLayer {
        val p = progress.value
        alpha = p
        translationY = (1f - p) * distance * density
    }
}

/**
 * A number that rolls up when it grows and down when it shrinks, instead of blinking. The size
 * change (9 → 10) is not clipped, so the digits never get cut mid-roll.
 */
@Composable
fun RollingNumber(
    value: Long,
    color: Color,
    fontSize: TextUnit,
    modifier: Modifier = Modifier,
    fontWeight: FontWeight = FontWeight.Bold,
    prefix: String = "",
    suffix: String = "",
    contentAlignment: Alignment = Alignment.Center
) {
    AnimatedContent(
        targetState = value,
        transitionSpec = {
            val up = targetState > initialState
            ((slideInVertically(NurMotion.snappy()) { h: Int -> if (up) h / 2 else -h / 2 } + fadeIn(tween(120))) togetherWith
                (slideOutVertically(NurMotion.snappy()) { h: Int -> if (up) -h / 2 else h / 2 } + fadeOut(tween(90))))
                .using(SizeTransform(clip = false))
        },
        contentAlignment = contentAlignment,
        label = "rollingNumber",
        modifier = modifier
    ) { v ->
        Text(prefix + v + suffix, color = color, fontSize = fontSize, fontWeight = fontWeight)
    }
}

/** [RollingNumber] for an Int. */
@Composable
fun RollingNumber(
    value: Int,
    color: Color,
    fontSize: TextUnit,
    modifier: Modifier = Modifier,
    fontWeight: FontWeight = FontWeight.Bold,
    prefix: String = "",
    suffix: String = "",
    contentAlignment: Alignment = Alignment.Center
) = RollingNumber(value.toLong(), color, fontSize, modifier, fontWeight, prefix, suffix, contentAlignment)

/**
 * A short line whose content changes in place ("12 / 33" → "13 / 33"): the new text rolls up
 * over the old one. For tiles whose subtitle carries a counter.
 */
@Composable
fun RollingText(
    text: String,
    color: Color,
    fontSize: TextUnit,
    modifier: Modifier = Modifier,
    fontWeight: FontWeight = FontWeight.Normal,
    maxLines: Int = 1
) {
    AnimatedContent(
        targetState = text,
        transitionSpec = {
            ((slideInVertically(NurMotion.snappy()) { h: Int -> h / 2 } + fadeIn(tween(120))) togetherWith
                (slideOutVertically(NurMotion.snappy()) { h: Int -> -h / 2 } + fadeOut(tween(90))))
                .using(SizeTransform(clip = false))
        },
        contentAlignment = Alignment.CenterStart,
        label = "rollingText",
        modifier = modifier
    ) { t ->
        Text(t, color = color, fontSize = fontSize, fontWeight = fontWeight, maxLines = maxLines,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
    }
}
