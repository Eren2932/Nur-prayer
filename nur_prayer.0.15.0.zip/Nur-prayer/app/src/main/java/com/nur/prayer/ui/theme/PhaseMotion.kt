package com.nur.prayer.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue

/** Sky change at a prayer boundary: slow enough to feel like weather, not like a page switch. */
const val PHASE_BLEND_MILLIS = 1600

/**
 * The palette, cross-faded when the prayer window changes.
 *
 * This runs a few times a day, for 1.6 s; the rest of the time every animation here is idle and
 * returns its target without scheduling frames.
 */
@Composable
fun animatedPhasePalette(target: PhasePalette): PhasePalette {
    val spec = tween<androidx.compose.ui.graphics.Color>(PHASE_BLEND_MILLIS)
    val zenith by animateColorAsState(target.zenith, spec, label = "skyZenith")
    val mid by animateColorAsState(target.mid, spec, label = "skyMid")
    val horizon by animateColorAsState(target.horizon, spec, label = "skyHorizon")
    val glow by animateColorAsState(target.glow, spec, label = "skyGlow")
    val accent by animateColorAsState(target.accent, spec, label = "skyAccent")
    val stars by animateFloatAsState(target.starIntensity, tween(PHASE_BLEND_MILLIS), label = "skyStars")
    return target.copy(
        zenith = zenith, mid = mid, horizon = horizon, glow = glow,
        accent = accent, starIntensity = stars
    )
}
