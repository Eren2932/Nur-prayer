package com.nur.prayer.notify

import com.nur.prayer.i18n.tr

import com.nur.prayer.core.astro.Prayer

object PrayerLabels {
    fun title(prayer: Prayer): String = when (prayer) {
        Prayer.SAHAR -> tr("Сухур")
        Prayer.FAJR -> tr("Фаджр")
        Prayer.SUNRISE -> tr("Восход")
        Prayer.DHUHR -> tr("Зухр")
        Prayer.ASR -> tr("Аср")
        Prayer.MAGHRIB -> tr("Магриб")
        Prayer.ISHA -> tr("Иша")
    }

    fun arabic(prayer: Prayer): String = when (prayer) {
        Prayer.SAHAR -> "السحور"
        Prayer.FAJR -> "الفجر"
        Prayer.SUNRISE -> "الشروق"
        Prayer.DHUHR -> "الظهر"
        Prayer.ASR -> "العصر"
        Prayer.MAGHRIB -> "المغرب"
        Prayer.ISHA -> "العشاء"
    }

    fun hint(prayer: Prayer): String = when (prayer) {
        Prayer.SAHAR -> tr("Конец сухура, начало поста")
        Prayer.FAJR -> tr("Утренний намаз, читают в мечетях")
        Prayer.SUNRISE -> tr("Конец времени Фаджра")
        Prayer.DHUHR -> tr("Полуденный намаз")
        Prayer.ASR -> tr("Послеполуденный намаз")
        Prayer.MAGHRIB -> tr("Вечерний намаз, ифтар")
        Prayer.ISHA -> tr("Ночной намаз")
    }
}
