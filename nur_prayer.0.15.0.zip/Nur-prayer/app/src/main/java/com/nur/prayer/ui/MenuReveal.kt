package com.nur.prayer.ui

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.dp

/*
 * 0.14.1: pages opened from the home menu rise out of the button that was tapped and settle back
 * into it on the way home.
 *
 * 0.13.0 clipped the page with a growing circle. That is a non-rectangular clip on a full-screen
 * layer, rebuilt every frame: on most phones it runs in software and the frame time doubles, which
 * is the jerk you could see. This version only ever touches the layer's transform:
 *
 *  - scale, alpha and the corner radius of a plain rounded rectangle: all hardware-composited, the
 *    page is composed once and then only transformed;
 *  - the scale grows from the tapped button (transformOrigin), so the page still visibly comes
 *    from it;
 *  - the page is invisible for the first frames, so the unavoidable long first frame (the page is
 *    composed there) happens while nothing is on screen and the motion does not appear to skip;
 *  - two clocks: a decelerating one for the shape and a linear one for the veil, so the veil and
 *    the fade of home stay in step whatever the easing does;
 *  - the same wrapper stays around the page for its whole life (only `active` changes), so going on
 *    to «Город» and back never rebuilds the page and never loses its scroll position.
 */
internal object MenuRevealMotion {
    const val OPEN_MILLIS = 380
    const val CLOSE_MILLIS = 260
    /** Home starts to fade once the page has covered most of it. */
    const val HOME_FADE_DELAY = 110
    /** Home sinks a little under the page and comes back up when the page leaves. */
    const val HOME_SCALE = 0.95f

    /** Fast out of the button, long soft landing. */
    val Rise = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)
    /** Slow first step, quick finish into the button. */
    val Sink = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f)

    const val FROM_SCALE = 0.84f
    const val CORNER_DP = 44f
}

internal object RevealGeometry {
    /** The page fades in over the first 45 % of the shape's progress. */
    fun contentAlpha(progress: Float): Float = (progress / 0.45f).coerceIn(0f, 1f)

    /** 1 while the page rises, melting to 0 over the last 40 % of the clock. */
    fun veilAlpha(clock: Float): Float = 1f - ((clock - 0.6f) / 0.4f).coerceIn(0f, 1f)
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
internal fun AnimatedVisibilityScope.MenuRevealBox(
    active: () -> Boolean,
    originInRoot: () -> Offset,
    veil: () -> Brush,
    content: @Composable () -> Unit
) {
    val progress = transition.animateFloat(
        transitionSpec = {
            if (targetState == EnterExitState.Visible) tween(MenuRevealMotion.OPEN_MILLIS, easing = MenuRevealMotion.Rise)
            else tween(MenuRevealMotion.CLOSE_MILLIS, easing = MenuRevealMotion.Sink)
        },
        label = "menuReveal"
    ) { state -> if (state == EnterExitState.Visible) 1f else 0f }
    val clock = transition.animateFloat(
        transitionSpec = {
            if (targetState == EnterExitState.Visible) tween(MenuRevealMotion.OPEN_MILLIS, easing = LinearEasing)
            else tween(MenuRevealMotion.CLOSE_MILLIS, easing = LinearEasing)
        },
        label = "menuRevealClock"
    ) { state -> if (state == EnterExitState.Visible) 1f else 0f }
    val topLeft = remember { arrayOf(Offset.Zero) }
    Box(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { topLeft[0] = it.positionInRoot() }
            .graphicsLayer {
                val p = progress.value
                val origin = originInRoot()
                if (active() && origin.isSpecified && p < 1f) {
                    val local = origin - topLeft[0]
                    transformOrigin = TransformOrigin(
                        (local.x / size.width).coerceIn(0f, 1f),
                        (local.y / size.height).coerceIn(0f, 1f)
                    )
                    val s = MenuRevealMotion.FROM_SCALE + (1f - MenuRevealMotion.FROM_SCALE) * p
                    scaleX = s
                    scaleY = s
                    alpha = RevealGeometry.contentAlpha(p)
                    clip = true
                    shape = RoundedCornerShape(((1f - p) * MenuRevealMotion.CORNER_DP).dp)
                } else {
                    scaleX = 1f
                    scaleY = 1f
                    alpha = 1f
                    clip = false
                    shape = RectangleShape
                }
            }
            .drawBehind {
                if (active() && originInRoot().isSpecified) {
                    val a = RevealGeometry.veilAlpha(clock.value)
                    if (a > 0f) drawRect(veil(), alpha = a)
                }
            }
    ) { content() }
}
