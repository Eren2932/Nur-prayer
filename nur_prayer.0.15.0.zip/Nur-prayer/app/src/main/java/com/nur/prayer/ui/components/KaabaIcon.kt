package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * 0.14.2: the Kaaba as a filled glyph — black cube, gold band of the kiswa, gold door — instead of
 * an outline. [edge] is the accent (white while searching, mint on lock); [glow] 0..1 draws a soft
 * halo of that accent around it and is read in the draw phase only.
 */
@Composable
fun KaabaIcon(edge: Color, modifier: Modifier = Modifier, glow: () -> Float = { 0f }) {
    Canvas(modifier) {
        val s = size.minDimension
        if (s < 4f) return@Canvas
        val g = glow().coerceIn(0f, 1f)
        if (g > 0f) {
            drawCircle(edge.copy(alpha = 0.16f * g), s * 0.78f, center)
            drawCircle(edge.copy(alpha = 0.22f * g), s * 0.62f, center)
        }
        val left = s * 0.12f
        val top = s * 0.14f
        val side = s * 0.76f
        val corner = CornerRadius(s * 0.09f, s * 0.09f)
        drawRoundRect(KaabaBody, Offset(left, top), Size(side, side), corner)
        drawRoundRect(edge.copy(alpha = 0.55f + 0.45f * g), Offset(left, top), Size(side, side), corner,
            style = Stroke(s * 0.05f))
        // Kiswa band, a third of the way down.
        drawRect(KaabaGold, Offset(left + s * 0.025f, top + side * 0.24f), Size(side - s * 0.05f, side * 0.12f))
        // Door, lower right as seen from the Hijr side.
        drawRoundRect(KaabaGold, Offset(left + side * 0.58f, top + side * 0.52f), Size(side * 0.17f, side * 0.34f),
            CornerRadius(s * 0.02f, s * 0.02f))
    }
}

private val KaabaBody = Color(0xFF09090F)
private val KaabaGold = Color(0xFFD8B25C)
