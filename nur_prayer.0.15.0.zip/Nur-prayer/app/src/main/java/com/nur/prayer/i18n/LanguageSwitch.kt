package com.nur.prayer.i18n

import androidx.compose.runtime.staticCompositionLocalOf

/**
 * How a screen asks for another language. The root provides a version that dims the content, swaps
 * the words while nothing is readable and brings the content back, so the switch reads as one calm
 * breath instead of a flash of half-translated text. Outside the root it simply switches.
 */
val LocalLanguageSwitcher = staticCompositionLocalOf<(AppLanguage) -> Unit> { { L10n.set(it) } }
