package com.nur.prayer.ui.theme

import androidx.compose.ui.graphics.Color
import com.nur.prayer.core.astro.Prayer

/*
 * 0.6.0 — "Небо".
 *
 * The app stops being a black instrument panel and becomes a window: the backdrop is the colour of
 * the sky in the current prayer window, and everything readable sits on dark glass in front of it.
 * Two rules keep that honest:
 *  - text never sits on bare sky unless it is large and bold (place, countdown); everything small
 *    lives on [Glass] or deeper, and tools/design_contract.py checks the composited contrast of
 *    every text tone over the lightest stop of every palette;
 *  - [Ink] stays a true black: it is the AMOLED fallback (Settings → Экран) and the colour of type
 *    on a light accent plate.
 */

val Ink = Color(0xFF000000)

/** The main card (prayer list, settings groups). Dark indigo glass, 86 % opaque. */
val Glass = Color(0xDB0E0C22)
/** Controls placed directly on the sky or on a card: buttons, steppers, chips. */
val SurfaceRaised = Color(0xB8161433)
/** Recessed tracks: search field, segmented control, stepper body. */
val SurfaceInset = Color(0x8C05040F)
/** Hairlines and inactive tracks. Translucent white, so it reads on any sky. */
val SurfaceEdge = Color(0x2EFFFFFF)
/** Row highlight inside a card (current prayer, selected row). */
val Highlight = Color(0x24FFFFFF)

/** Kept as an alias: older call sites mean "the card colour". */
val InkSoft = Glass

val Mint = Color(0xFF9DD6B5)
/** "Next prayer" plate. Deep enough that white type on it passes AA at body size. */
val NextGreen = Color(0xFF13703F)
val Amber = Color(0xFFF2C077)
val AmberPlate = Color(0xFF4A3410)
val Crimson = Color(0xFFFF9AA2)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFD2D0E2)
val TextTertiary = Color(0xFFA9A6C2)

/** Navigation bar: transparent, the sky runs under it. */
val SystemBar = Color(0x00000000)

/**
 * One sky per prayer window.
 *
 * [zenith] → [mid] → [horizon] is the vertical gradient of the backdrop, [glow] a soft radial bloom
 * at the horizon (sunrise/sunset only). [sheet] is the opaque tint of the per-prayer bottom sheet:
 * it is derived from the same sky, so opening Фаджр feels violet and Зухр feels like noon.
 */
@androidx.compose.runtime.Immutable
data class PhasePalette(
    val zenith: Color,
    val mid: Color,
    val horizon: Color,
    val glow: Color,
    val accent: Color,
    val accentSoft: Color,
    val sheet: Color,
    val starIntensity: Float,
    val name: String
)

private val Sahar = PhasePalette(
    zenith = Color(0xFF04050E), mid = Color(0xFF0B0F2C), horizon = Color(0xFF1B1E4A),
    glow = Color.Transparent, accent = Color(0xFFB9C3FF), accentSoft = Color(0xFFD9DEFF),
    sheet = Color(0xFF111433), starIntensity = 1f, name = "Сухур"
)
private val Fajr = PhasePalette(
    zenith = Color(0xFF0D0F33), mid = Color(0xFF3A2D6C), horizon = Color(0xFF9E5F86),
    glow = Color(0x55FF9DB0), accent = Color(0xFFD5BCFF), accentSoft = Color(0xFFE9DCFF),
    sheet = Color(0xFF2A1F55), starIntensity = 0.55f, name = "Фаджр"
)
private val Sunrise = PhasePalette(
    zenith = Color(0xFF26457F), mid = Color(0xFF6474AD), horizon = Color(0xFFD99276),
    glow = Color(0x66FFC28A), accent = Color(0xFFFFCDA0), accentSoft = Color(0xFFFFE3C9),
    sheet = Color(0xFF3B2E55), starIntensity = 0f, name = "Восход"
)
private val Dhuhr = PhasePalette(
    zenith = Color(0xFF1A5297), mid = Color(0xFF3F7DBE), horizon = Color(0xFF86B4DA),
    glow = Color.Transparent, accent = Color(0xFFA6D6FF), accentSoft = Color(0xFFD3EBFF),
    sheet = Color(0xFF173E6C), starIntensity = 0f, name = "Зухр"
)
private val Asr = PhasePalette(
    zenith = Color(0xFF2E4289), mid = Color(0xFF6E63A8), horizon = Color(0xFFD27C93),
    glow = Color(0x40FFB3A8), accent = Color(0xFFFFB8C6), accentSoft = Color(0xFFFFDAE2),
    sheet = Color(0xFF332B66), starIntensity = 0f, name = "Аср"
)
private val Maghrib = PhasePalette(
    zenith = Color(0xFF1B1947), mid = Color(0xFF633672), horizon = Color(0xFFCB6650),
    glow = Color(0x66FF8A5C), accent = Color(0xFFFFBC93), accentSoft = Color(0xFFFFDCC6),
    sheet = Color(0xFF41213F), starIntensity = 0.25f, name = "Магриб"
)
private val Isha = PhasePalette(
    zenith = Color(0xFF03061A), mid = Color(0xFF0A1137), horizon = Color(0xFF1A2456),
    glow = Color.Transparent, accent = Color(0xFFB7C4FF), accentSoft = Color(0xFFDAE0FF),
    sheet = Color(0xFF111A42), starIntensity = 1f, name = "Иша"
)

/** Every palette, in prayer order. Exposed for tests and the design audit. */
val AllPalettes: List<PhasePalette> = listOf(Sahar, Fajr, Sunrise, Dhuhr, Asr, Maghrib, Isha)

fun paletteFor(prayer: Prayer): PhasePalette = when (prayer) {
    Prayer.SAHAR -> Sahar
    Prayer.FAJR -> Fajr
    Prayer.SUNRISE -> Sunrise
    Prayer.DHUHR -> Dhuhr
    Prayer.ASR -> Asr
    Prayer.MAGHRIB -> Maghrib
    Prayer.ISHA -> Isha
}

/** An opaque mix of the card glass and an accent, for selected fills. */
fun solidTone(accent: Color, amount: Float = 0.16f): Color =
    androidx.compose.ui.graphics.lerp(Glass, accent.copy(alpha = 1f), amount.coerceIn(0f, 1f))
