package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableFloatState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette
import kotlinx.coroutines.delay

/**
 * The backdrop: the sky of the current prayer window (0.6.0).
 *
 * Layers, cheapest first:
 *  1. [Ink] — always. It is also the whole backdrop when the user picks the AMOLED style.
 *  2. A three-stop vertical gradient, zenith → mid → horizon, plus a soft radial bloom at the
 *     horizon on the sunrise/sunset palettes. Drawn in one `drawBehind`, i.e. once per
 *     invalidation, never per frame: the sky only changes at a prayer boundary.
 *  3. Stars, only on night palettes ([PhasePalette.starIntensity] > 0) and only when the user
 *     keeps «Звёзды ночью» on. Otherwise the star composable is not in the tree at all, so a
 *     daytime screen pays for exactly one gradient.
 *
 * The star field keeps every guarantee of 0.5.1: it animates only when [motionEnabled] (the
 * user's switch), [rememberAmbientMotionAllowed] (resumed, no battery saver, animations on) and
 * not [LocalBackdropPaused]; it steps at most 20 times a second; it allocates nothing per frame.
 */
@Composable
fun SkyBackdrop(
    palette: PhasePalette,
    modifier: Modifier = Modifier,
    sky: Boolean = true,
    motionEnabled: Boolean = false
) {
    Box(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(Ink)
                if (!sky || size.width < 1f || size.height < 1f) return@drawBehind
                drawRect(
                    Brush.verticalGradient(
                        0f to palette.zenith,
                        0.55f to palette.mid,
                        1f to palette.horizon
                    )
                )
                if (palette.glow.alpha > 0.01f) {
                    val radius = size.width * 0.95f
                    drawRect(
                        Brush.radialGradient(
                            colors = listOf(palette.glow, Color.Transparent),
                            center = Offset(size.width * 0.5f, size.height * 1.02f),
                            radius = radius
                        )
                    )
                }
                // Legibility floor for the dock, the pull hint and the day note, which sit on the
                // brightest band of noon. Both constants are read by the contrast contract in tools/.
                drawRect(
                    Brush.verticalGradient(
                        HORIZON_SCRIM_START to Color.Transparent,
                        1f to Ink.copy(alpha = HORIZON_SCRIM_ALPHA)
                    )
                )
            }
    ) {
        // The «Звёзды ночью» switch removes the layer outright; daytime palettes never compose it.
        if (motionEnabled && palette.starIntensity > 0.01f) {
            StarLayer(palette, motionEnabled, if (sky) palette.starIntensity else 0.6f)
        }
    }
}

/** Darkening at the very bottom edge; keep in sync with `tools/test_amoled_source.py`. */
const val HORIZON_SCRIM_ALPHA = 0.45f
const val HORIZON_SCRIM_START = 0.5f

@Composable
private fun StarLayer(palette: PhasePalette, motionEnabled: Boolean, intensity: Float) {
    // Gated on the switch, so a disabled backdrop registers no broadcast receiver and no settings
    // observer at all — and Compose previews, which have no real system services, stay renderable.
    val systemAllows = if (motionEnabled) rememberAmbientMotionAllowed() else false
    val paused = LocalBackdropPaused.current.value
    val animating = systemAllows && !paused
    val clock = remember { mutableFloatStateOf(0f) }
    val stars = remember { AmbientSky.stars() }

    LaunchedEffect(animating) {
        if (!animating) return@LaunchedEffect
        var previous = 0L
        while (true) {
            withFrameNanos { now ->
                // Clamped so a long pause cannot teleport the field on the first frame back.
                if (previous != 0L) clock.floatValue += ((now - previous) / 1_000_000_000f).coerceAtMost(0.15f)
                previous = now
            }
            delay(AmbientSky.FRAME_INTERVAL_MILLIS)
        }
    }
    StarField(clock, stars, palette.accentSoft, intensity, meteors = animating)
}

@Composable
private fun StarField(
    clock: MutableFloatState,
    stars: Array<AmbientSky.Star>,
    tint: Color,
    intensity: Float,
    meteors: Boolean
) {
    Canvas(Modifier.fillMaxSize()) {
        val t = clock.floatValue
        val w = size.width
        // Stars belong to the upper sky; below 70 % the horizon glow would swallow them anyway.
        val h = size.height * 0.7f
        if (w < 1f || h < 1f) return@Canvas
        val k = intensity.coerceIn(0f, 1f)

        for (i in stars.indices) {
            val star = stars[i]
            val x = AmbientSky.driftX(star, t) * w
            val y = star.y * h
            val alpha = AmbientSky.alpha(star, t) * k
            if (alpha <= AmbientSky.MIN_VISIBLE_ALPHA) continue
            val color = if (star.accented) tint else Color.White
            drawCircle(color.copy(alpha = alpha), star.radius * density, Offset(x, y))
        }

        if (meteors) drawMeteor(t, k)
    }
}

/** One meteor per [AmbientSky.METEOR_PERIOD] seconds, deterministic: no particle bookkeeping. */
private fun DrawScope.drawMeteor(t: Float, intensity: Float) {
    val index = (t / AmbientSky.METEOR_PERIOD).toInt()
    val local = t - index * AmbientSky.METEOR_PERIOD
    if (local > AmbientSky.METEOR_LIFE) return

    val w = size.width
    val h = size.height
    val rnd = AmbientSky.hash(index)
    val startX = (0.12f + 0.7f * rnd) * w
    val startY = (0.04f + 0.22f * AmbientSky.hash(index * 31 + 7)) * h
    val angle = 0.62f + 0.22f * AmbientSky.hash(index * 17 + 3)
    val travel = w * 0.38f
    val p = local / AmbientSky.METEOR_LIFE
    val eased = p * p * (3f - 2f * p)
    val hx = startX + kotlin.math.cos(angle) * travel * eased
    val hy = startY + kotlin.math.sin(angle) * travel * eased
    val tail = travel * 0.20f
    val tx = hx - kotlin.math.cos(angle) * tail
    val ty = hy - kotlin.math.sin(angle) * tail
    val fade = (1f - kotlin.math.abs(p * 2f - 1f)).coerceIn(0f, 1f) * AmbientSky.METEOR_ALPHA * intensity

    drawLine(
        brush = Brush.linearGradient(
            colors = listOf(Color.Transparent, Color.White.copy(alpha = fade)),
            start = Offset(tx, ty), end = Offset(hx, hy)
        ),
        start = Offset(tx, ty), end = Offset(hx, hy),
        strokeWidth = 1.6f * density, cap = StrokeCap.Round
    )
}

/**
 * The backdrop's arithmetic, kept free of Compose so it can be unit-tested.
 *
 * The ceilings here are the design contract, not tuning knobs: [MAX_ALPHA] is what keeps the field
 * below the text it sits behind, and [STAR_COUNT] is what keeps the lit area negligible on OLED.
 */
object AmbientSky {
    const val STAR_COUNT = 54
    /** No star may ever be brighter than this: the backdrop must lose to the foreground. */
    const val MAX_ALPHA = 0.34f
    const val MIN_VISIBLE_ALPHA = 0.012f
    /** 20 updates per second, deliberately below display rate. */
    const val FRAME_INTERVAL_MILLIS = 50L
    const val METEOR_PERIOD = 40f
    const val METEOR_LIFE = 1.1f
    const val METEOR_ALPHA = 0.55f

    class Star(
        val x: Float,
        val y: Float,
        val radius: Float,
        val brightness: Float,
        val phase: Float,
        val speed: Float,
        val parallax: Float,
        val accented: Boolean
    )

    /** Deterministic field: the same sky every launch, so nothing "moves" between sessions. */
    fun stars(): Array<Star> {
        val random = kotlin.random.Random(1445)
        return Array(STAR_COUNT) { i ->
            val near = i % 9 == 0
            Star(
                x = random.nextFloat(),
                y = random.nextFloat(),
                radius = if (near) 1.0f + random.nextFloat() * 0.5f else 0.6f + random.nextFloat() * 0.4f,
                brightness = if (near) 0.62f + random.nextFloat() * 0.30f else 0.20f + random.nextFloat() * 0.28f,
                phase = random.nextFloat(),
                speed = 0.05f + random.nextFloat() * 0.09f,
                parallax = if (near) 1.4f else 0.5f,
                accented = near
            )
        }
    }

    /** Horizontal drift, wrapped into 0..1 so a star leaving the right edge returns on the left. */
    fun driftX(star: Star, t: Float): Float {
        val drift = star.x + t * star.parallax * 0.0025f
        return drift - kotlin.math.floor(drift)
    }

    /** Twinkle, clamped by [MAX_ALPHA]. Never negative, never above the ceiling. */
    fun alpha(star: Star, t: Float): Float {
        val twinkle = 0.60f + 0.40f * kotlin.math.sin(2f * Math.PI.toFloat() * (t * star.speed + star.phase))
        return (star.brightness * twinkle).coerceIn(0f, MAX_ALPHA)
    }

    fun hash(seed: Int): Float {
        var x = seed * 374761393 + 668265263
        x = (x xor (x shr 13)) * 1274126177
        return ((x xor (x shr 16)) and 0x7FFFFFFF) / 2147483647f
    }
}
