package com.nur.prayer.ui.learn

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.learn.Arabic
import com.nur.prayer.learn.Face
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/** Tatweel: keeps the neighbours of a blanked letter joined, as textbooks print a gap. */
internal const val TATWEEL = "\u0640"

/**
 * Arabic text with grapheme-level accents. A hidden grapheme is drawn as a tatweel stretch so the
 * word keeps its joined shape. Colour spans never split a grapheme from its vowel marks, which is
 * what keeps the shaper from falling back to isolated forms.
 */
internal fun arabicAnnotated(text: String, highlight: Set<Int>, hidden: Set<Int>, accent: Color): AnnotatedString {
    if (highlight.isEmpty() && hidden.isEmpty()) return AnnotatedString(text)
    val g = Arabic.graphemes(text)
    return buildAnnotatedString {
        g.forEachIndexed { i, s ->
            when {
                i in hidden -> withStyle(SpanStyle(color = accent)) { append(TATWEEL.repeat(3)) }
                i in highlight -> withStyle(SpanStyle(color = accent)) { append(s) }
                else -> append(s)
            }
        }
    }
}

@Composable
internal fun ArabicText(
    text: AnnotatedString,
    size: Float,
    modifier: Modifier = Modifier,
    color: Color = TextPrimary,
    align: TextAlign = TextAlign.Center
) {
    val ui = uiScale()
    Text(
        text = text,
        color = color,
        fontSize = ui.t(size),
        lineHeight = ui.t(size * 1.65f),
        textAlign = align,
        style = TextStyle(textDirection = TextDirection.Rtl),
        modifier = modifier
    )
}

@Composable
internal fun ArabicText(text: String, size: Float, modifier: Modifier = Modifier, color: Color = TextPrimary, align: TextAlign = TextAlign.Center) =
    ArabicText(AnnotatedString(text), size, modifier, color, align)

/** A prompt or an answer face. [big] is the prompt size, otherwise the tile size. */
@Composable
internal fun FaceView(face: Face, big: Boolean, accent: Color, modifier: Modifier = Modifier, color: Color = TextPrimary) {
    val ui = uiScale()
    when (face) {
        is Face.Ar -> {
            val size = when {
                face.text.length <= 2 -> if (big) 72f else 38f
                face.text.length <= 12 -> if (big) 44f else 28f
                else -> if (big) 28f else 22f
            }
            ArabicText(arabicAnnotated(face.text, face.highlight, face.hidden, accent), size, modifier.fillMaxWidth(), color)
        }
        is Face.Tr -> Text(face.text, color = color, fontSize = ui.t(if (big) 32f else 20f), fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center, modifier = modifier.fillMaxWidth())
        is Face.Txt -> Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(face.text, color = color, fontSize = ui.t(if (big) 26f else 17f), fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center, lineHeight = ui.t(if (big) 32f else 22f))
            face.caption?.let { Text(it, color = TextTertiary, fontSize = ui.t(if (big) 16f else 13f), textAlign = TextAlign.Center) }
        }
    }
}

/** Visual state of an answer tile. */
internal enum class TileState { IDLE, SELECTED, RIGHT, WRONG, DIMMED }

@Composable
internal fun AnswerTile(
    state: TileState,
    accent: Color,
    onClick: (() -> Unit)?,
    modifier: Modifier = Modifier,
    minHeight: Dp = 64.dp,
    content: @Composable () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, tween(90), label = "tilePress")
    val (bg, edge) = when (state) {
        TileState.IDLE -> SurfaceRaised to SurfaceEdge
        TileState.SELECTED -> accent.copy(alpha = 0.22f) to accent
        TileState.RIGHT -> Mint.copy(alpha = 0.22f) to Mint
        TileState.WRONG -> Crimson.copy(alpha = 0.20f) to Crimson
        TileState.DIMMED -> SurfaceInset to Color.Transparent
    }
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier
            .heightIn(min = minHeight)
            .graphicsLayer { scaleX = scale; scaleY = scale; alpha = if (state == TileState.DIMMED) 0.5f else 1f }
            .clip(shape)
            .background(bg)
            .border(1.dp, edge, shape)
            .then(
                if (onClick != null) Modifier.clickable(interactionSource = interaction, indication = ripple(), role = Role.Button) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                } else Modifier
            )
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) { content() }
}

/** Thin lesson progress bar. */
@Composable
internal fun LessonBar(fraction: Float, accent: Color, modifier: Modifier = Modifier) {
    val shown by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(320), label = "lessonBar")
    Box(modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)).background(SurfaceInset)) {
        Box(Modifier.fillMaxWidth(shown).height(10.dp).clip(RoundedCornerShape(50)).background(accent))
    }
}

@Composable
internal fun Stars(count: Int, modifier: Modifier = Modifier, size: Float = 16f, of: Int = 3) {
    val ui = uiScale()
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        repeat(of) { i ->
            Text(if (i < count) "★" else "☆", color = if (i < count) Color(0xFFF2C077) else TextTertiary, fontSize = ui.t(size))
        }
    }
}

/** A small rounded tag: "3 / 8", "повторить 12". */
@Composable
internal fun Tag(text: String, color: Color = TextSecondary, background: Color = SurfaceInset) {
    val ui = uiScale()
    Text(
        text, color = color, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(background).padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
internal fun Gap(h: Float) = Spacer(Modifier.height(uiScale().s(h)))

@Composable
internal fun HGap(w: Float) = Spacer(Modifier.width(uiScale().s(w)))
