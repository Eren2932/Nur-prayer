package com.nur.prayer.ui.learn

import com.nur.prayer.i18n.tr

import com.nur.prayer.audio.ArabicVoice
import com.nur.prayer.audio.VoiceText
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.RollingNumber

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import kotlinx.coroutines.delay
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.learn.Arabic
import com.nur.prayer.learn.Exercise
import com.nur.prayer.learn.Face
import com.nur.prayer.learn.LetterForm
import com.nur.prayer.learn.Word
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.Glass
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/**
 * One lesson, start to result. The exercise is keyed on [ActiveLesson.step], so every step starts
 * with a clean selection; the verdict panel slides up from the bottom and holds the only button.
 */
@Composable
fun LessonScreen(vm: LearnViewModel, active: ActiveLesson?, palette: PhasePalette, onClose: () -> Unit) {
    val accent = palette.accent
    if (active == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(tr("Урок закрыт"), color = TextSecondary)
        }
        return
    }
    var confirmQuit by remember(active.lesson.id) { mutableStateOf(false) }
    // One voice connection for the whole lesson: steps come and go, the engine stays.
    val voiceStatus = rememberVoiceStatus()
    BackHandler(active.result == null) { confirmQuit = true }

    val result = active.result
    if (result != null) {
        LessonResultScreen(active, result, accent,
            onAgain = { vm.start(active.lesson.id) },
            onClose = { vm.quit(); onClose() })
        return
    }

    val ui = uiScale()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = ui.s(16f), vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(GlyphKind.CLOSE, tr("Выйти из урока"), { confirmQuit = true }, size = 40.dp)
            HGap(12f)
            LessonBar(active.session.fraction, accent, Modifier.weight(1f))
            HGap(12f)
            Text("${minOf(active.session.position + 1, active.session.queue.size)}/${active.session.queue.size}",
                color = TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AnimatedContent(
                targetState = active,
                contentKey = { it.step },
                transitionSpec = {
                    // Springs: a fast "Дальше" interrupts the slide mid-way without a jump.
                    (slideInHorizontally(NurMotion.gentle()) { it / 3 } + fadeIn(tween(200))) togetherWith
                        (slideOutHorizontally(NurMotion.gentle()) { -it / 4 } + fadeOut(tween(140)))
                }, label = "exercise"
            ) { shown ->
                // The leaving step keeps drawing its own exercise while it slides out.
                val ex = shown.session.current
                if (ex != null) ExerciseBody(ex, shown.verdict != null, accent, voiceStatus,
                    onAcknowledge = vm::acknowledge, onCheck = vm::check)
            }
        }
        AnimatedVisibility(
            visible = active.verdict != null,
            enter = slideInVertically(NurMotion.snappy()) { it } + fadeIn(tween(140)),
            exit = slideOutVertically(tween(160)) { it } + fadeOut(tween(120))
        ) {
            active.verdict?.let { VerdictPanel(it, active.combo, accent, vm::next) }
        }
    }

    if (confirmQuit) QuitDialog(accent, onStay = { confirmQuit = false }, onQuit = { confirmQuit = false; vm.quit(); onClose() })
}

@Composable
private fun QuitDialog(accent: Color, onStay: () -> Unit, onQuit: () -> Unit) {
    val ui = uiScale()
    Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.Center) {
        GlassCard(Modifier.padding(ui.s(28f))) {
            Column(Modifier.padding(ui.s(22f))) {
                Text(tr("Выйти из урока?"), color = TextPrimary, fontSize = ui.t(20f), fontWeight = FontWeight.Bold)
                Gap(8f)
                Text(tr("Ответы уже попали в повторение, но звёзды за урок не засчитаются."), color = TextSecondary, fontSize = ui.t(14f))
                Gap(18f)
                NurButton(tr("Продолжить урок"), accent, onStay, Modifier.fillMaxWidth(), primary = true)
                Gap(8f)
                NurButton(tr("Выйти"), accent, onQuit, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun VerdictPanel(v: Verdict, combo: Int, accent: Color, onNext: () -> Unit) {
    val ui = uiScale()
    val tone = if (v.correct) Mint else Crimson
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)).background(Glass)
            .navigationBarsPadding().padding(ui.s(20f))
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(if (v.correct) tr("Верно") else tr("Неверно"), color = tone, fontSize = ui.t(20f), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            // A streak of right answers is shown from three on: enough to notice, rare enough to matter.
            if (v.correct && combo >= 3) {
                Text(tr("серия {0}", combo), color = accent, fontSize = ui.t(13f), fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(accent.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 4.dp))
            }
        }
        v.explain?.let { Gap(4f); Text(it, color = TextSecondary, fontSize = ui.t(14f), lineHeight = ui.t(19f)) }
        if (!v.correct) { Gap(2f); Text(tr("Это задание вернётся в конце урока."), color = TextTertiary, fontSize = ui.t(12f)) }
        Gap(14f)
        NurButton(tr("Дальше"), tone, onNext, Modifier.fillMaxWidth(), primary = true)
    }
}

@Composable
private fun ExerciseBody(ex: Exercise, locked: Boolean, accent: Color, voice: ArabicVoice.Status, onAcknowledge: () -> Unit, onCheck: (Boolean) -> Unit) {
    val ui = uiScale()
    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(20f)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            when (ex) {
                is Exercise.LetterIntro -> LetterIntroBody(ex, accent, voice)
                is Exercise.WordIntro -> WordIntroBody(ex, voice)
                is Exercise.Info -> InfoBody(ex, voice)
                is Exercise.Choice -> ChoiceBody(ex, locked, accent, onCheck)
                is Exercise.Missing -> MissingBody(ex, locked, accent, onCheck)
                is Exercise.Assemble -> AssembleBody(ex, locked, accent, onCheck)
                is Exercise.Pairs -> PairsBody(ex, locked, accent, onCheck)
            }
            Gap(24f)
        }
        if (ex.isIntro) {
            Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(ui.s(20f))) {
                NurButton(if (ex is Exercise.Info) tr("Понятно") else tr("Запомнил"), accent, onAcknowledge, Modifier.fillMaxWidth(), primary = true)
            }
        }
    }
}

@Composable
private fun Question(text: String) {
    val ui = uiScale()
    Gap(8f)
    Text(text, color = TextPrimary, fontSize = ui.t(19f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth())
    Gap(14f)
}

// ── intro cards ────────────────────────────────────────────────────────────────────────────────

@Composable
private fun LetterIntroBody(ex: Exercise.LetterIntro, accent: Color, voice: ArabicVoice.Status) {
    val ui = uiScale()
    val l = ex.letter
    AutoSay(VoiceText.letterSound(l), ex, voice)
    Gap(6f)
    Text(tr("НОВАЯ БУКВА"), color = accent, fontSize = ui.t(12f), fontWeight = FontWeight.Bold, letterSpacing = ui.t(1f))
    GlassCard(Modifier.padding(top = 10.dp)) {
        Column(Modifier.fillMaxWidth().padding(ui.s(18f)), horizontalAlignment = Alignment.CenterHorizontally) {
            ArabicText(l.char, 96f)
            Text("${l.name} · ${l.sound}", color = TextPrimary, fontSize = ui.t(24f), fontWeight = FontWeight.Bold)
            ArabicText(l.nameArabic, 22f, color = TextSecondary)
            Gap(10f)
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    SpeakButton(VoiceText.letterSound(l), voice, label = tr("Звук буквы"))
                    Text(tr("звук"), color = TextTertiary, fontSize = ui.t(11f))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    SpeakButton(VoiceText.letterName(l), voice, label = tr("Название буквы"))
                    Text(tr("название"), color = TextTertiary, fontSize = ui.t(11f))
                }
            }
            Gap(12f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                // Read right to left, as the word is written: end ← middle ← start ← alone.
                listOf(LetterForm.FINAL, LetterForm.MEDIAL, LetterForm.INITIAL, LetterForm.ISOLATED).forEach { f ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        ArabicText(Arabic.shape(l, f), 34f)
                        Text(f.title, color = TextTertiary, fontSize = ui.t(11f))
                    }
                }
            }
            if (!l.joinsNext) {
                Gap(6f)
                Text(tr("Не соединяется со следующей буквой"), color = Color(0xFFF2C077), fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold)
            }
        }
    }
    Gap(12f)
    Text(l.hint, color = TextSecondary, fontSize = ui.t(15f), lineHeight = ui.t(21f), textAlign = TextAlign.Center)
    ex.example?.let { w ->
        Gap(14f)
        GlassCard {
            Column(Modifier.fillMaxWidth().padding(ui.s(14f)), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(tr("Пример"), color = TextTertiary, fontSize = ui.t(12f))
                val g = Arabic.graphemes(w.arabic)
                val marks = g.indices.filter { g[it].startsWith(l.char) }.toSet()
                ArabicText(arabicAnnotated(w.arabic, marks, emptySet(), accent), 34f)
                Text("${w.translit} — ${w.ru}", color = TextSecondary, fontSize = ui.t(14f))
                if (voiceAllowed(w)) { Gap(6f); SpeakButton(w.arabic, voice, size = 38.dp) }
            }
        }
    }
    VoiceHint(voice, accent, Modifier.padding(top = 12.dp))
}

/** The machine voice does not read Quran words (see ArabicVoice): no tajweed, no place for its mistakes. */
internal fun voiceAllowed(w: Word): Boolean = w.machineVoiceAllowed

@Composable
private fun WordIntroBody(ex: Exercise.WordIntro, voice: ArabicVoice.Status) {
    val ui = uiScale()
    val w = ex.word
    val speak = voiceAllowed(w)
    AutoSay(w.arabic, ex, voice, enabled = speak)
    Gap(6f)
    Text(tr("НОВОЕ СЛОВО"), color = TextTertiary, fontSize = ui.t(12f), fontWeight = FontWeight.Bold, letterSpacing = ui.t(1f))
    GlassCard(Modifier.padding(top = 10.dp)) {
        Column(Modifier.fillMaxWidth().padding(ui.s(22f)), horizontalAlignment = Alignment.CenterHorizontally) {
            ArabicText(w.arabic, if (w.isPhrase) 34f else 52f)
            Gap(6f)
            Text(w.translit, color = TextSecondary, fontSize = ui.t(20f), fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            Gap(4f)
            Text(w.ru, color = TextPrimary, fontSize = ui.t(24f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            if (speak) { Gap(10f); SpeakButton(w.arabic, voice) }
        }
    }
    Gap(12f)
    Text(tr("Буквы: ") + w.letters.joinToString(" · ") { it.name }, color = TextTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center)
}

@Composable
private fun InfoBody(ex: Exercise.Info, voice: ArabicVoice.Status) {
    val ui = uiScale()
    Gap(6f)
    Text(ex.title, color = TextPrimary, fontSize = ui.t(24f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    Gap(10f)
    Text(ex.body, color = TextSecondary, fontSize = ui.t(15f), lineHeight = ui.t(22f), textAlign = TextAlign.Center)
    Gap(14f)
    ex.samples.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { (ar, tr) ->
                GlassCard(Modifier.weight(1f), corner = 18.dp) {
                    Column(Modifier.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        ArabicText(ar, 32f)
                        Text(tr, color = TextSecondary, fontSize = ui.t(14f), textAlign = TextAlign.Center)
                        // Vowels, sukun, shadda, tanween: the rule is heard, not only read.
                        if (ex.voiced) { Gap(4f); SpeakButton(ar, voice, size = 34.dp) }
                    }
                }
            }
            if (row.size == 1) Box(Modifier.weight(1f))
        }
    }
}

// ── graded exercises ───────────────────────────────────────────────────────────────────────────

private fun tileState(i: Int, selected: Int, answer: Int, locked: Boolean): TileState = when {
    !locked -> if (i == selected) TileState.SELECTED else TileState.IDLE
    i == answer -> TileState.RIGHT
    i == selected -> TileState.WRONG
    else -> TileState.DIMMED
}

@Composable
private fun CheckButton(enabled: Boolean, locked: Boolean, accent: Color, onClick: () -> Unit) {
    if (locked) return
    Gap(18f)
    NurButton(tr("Проверить"), accent, onClick, Modifier.fillMaxWidth(), primary = true, enabled = enabled)
}

@Composable
private fun ChoiceBody(ex: Exercise.Choice, locked: Boolean, accent: Color, onCheck: (Boolean) -> Unit) {
    var selected by remember(ex) { mutableIntStateOf(-1) }
    Question(ex.question)
    GlassCard {
        Box(Modifier.fillMaxWidth().padding(vertical = 18.dp, horizontal = 12.dp), contentAlignment = Alignment.Center) {
            FaceView(ex.prompt, big = true, accent = accent)
        }
    }
    Gap(16f)
    // Short faces (a letter, a sound) sit two by two; sentences and meanings get full rows.
    val compact = ex.options.all { f -> (f is Face.Ar && f.text.length <= 8) || (f is Face.Tr && f.text.length <= 8) }
    val rows = if (compact) ex.options.withIndex().chunked(2) else ex.options.withIndex().map { listOf(it) }
    rows.forEach { row ->
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { (i, face) ->
                AnswerTile(tileState(i, selected, ex.answer, locked), accent,
                    onClick = if (locked) null else ({ selected = i }), modifier = Modifier.weight(1f)) {
                    FaceView(face, big = false, accent = accent)
                }
            }
        }
    }
    CheckButton(selected >= 0, locked, accent) { onCheck(selected == ex.answer) }
}

@Composable
private fun MissingBody(ex: Exercise.Missing, locked: Boolean, accent: Color, onCheck: (Boolean) -> Unit) {
    val ui = uiScale()
    var selected by remember(ex) { mutableIntStateOf(-1) }
    Question(tr("Какой буквы не хватает?"))
    GlassCard {
        Column(Modifier.fillMaxWidth().padding(vertical = 18.dp, horizontal = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            val text = when {
                locked -> arabicAnnotated(ex.shown, setOf(ex.index), emptySet(), if (selected == ex.answer) Mint else accent)
                selected >= 0 -> arabicAnnotated(swap(ex.shown, ex.index, ex.options[selected].char), setOf(ex.index), emptySet(), accent)
                else -> arabicAnnotated(ex.shown, emptySet(), setOf(ex.index), accent)
            }
            ArabicText(text, 52f)
            Gap(4f)
            Text(ex.word.ru, color = TextSecondary, fontSize = ui.t(16f))
            if (locked) Text(ex.word.translit, color = TextTertiary, fontSize = ui.t(14f))
        }
    }
    Gap(16f)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ex.options.forEachIndexed { i, l ->
            AnswerTile(tileState(i, selected, ex.answer, locked), accent, if (locked) null else ({ selected = i }),
                Modifier.weight(1f), minHeight = 76.dp) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    ArabicText(l.char, 34f)
                    Text(l.name, color = TextTertiary, fontSize = ui.t(11f))
                }
            }
        }
    }
    CheckButton(selected >= 0, locked, accent) { onCheck(selected == ex.answer) }
}

/** Puts [letter] in grapheme [index], keeping that grapheme's vowel marks. */
private fun swap(word: String, index: Int, letter: String): String {
    val g = Arabic.graphemes(word).toMutableList()
    if (index !in g.indices) return word
    g[index] = letter + g[index].drop(1)
    return g.joinToString("")
}

@Composable
private fun AssembleBody(ex: Exercise.Assemble, locked: Boolean, accent: Color, onCheck: (Boolean) -> Unit) {
    val ui = uiScale()
    val picked = remember(ex) { mutableStateListOf<Int>() }
    val built = picked.map { ex.tiles[it] }
    val right = built == ex.target
    Question(tr("Соберите слово «{0}»", ex.word.ru))
    Text(ex.word.translit, color = TextSecondary, fontSize = ui.t(16f))
    Gap(12f)
    GlassCard {
        Box(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 12.dp), contentAlignment = Alignment.Center) {
            if (built.isEmpty()) Text(tr("нажимайте буквы по порядку — справа налево"), color = TextTertiary, fontSize = ui.t(13f))
            else ArabicText(built.joinToString(""), 52f, color = if (locked) (if (right) Mint else Crimson) else TextPrimary)
        }
    }
    if (locked && !right) {
        Gap(8f)
        ArabicText(ex.target.joinToString(""), 34f, color = Mint)
    }
    Gap(14f)
    // Tiles are laid out right to left, the way the word is read.
    ex.tiles.indices.reversed().toList().chunked(4).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { i ->
                val used = i in picked
                AnswerTile(if (used) TileState.DIMMED else TileState.IDLE, accent,
                    onClick = if (locked) null else ({ if (used) picked.remove(i) else picked.add(i); Unit }),
                    modifier = Modifier.weight(1f), minHeight = 64.dp) {
                    ArabicText(ex.tiles[i], 32f)
                }
            }
            repeat(4 - row.size) { Box(Modifier.weight(1f)) }
        }
    }
    if (!locked && picked.isNotEmpty()) {
        Gap(6f)
        NurButton(tr("Стереть последнюю"), accent, { picked.removeAt(picked.lastIndex) }, Modifier.fillMaxWidth())
    }
    CheckButton(picked.size == ex.target.size, locked, accent) { onCheck(right) }
}

@Composable
private fun PairsBody(ex: Exercise.Pairs, locked: Boolean, accent: Color, onCheck: (Boolean) -> Unit) {
    val order = remember(ex) { ex.right.indices.shuffled() }
    var left by remember(ex) { mutableIntStateOf(-1) }
    var wrongFlash by remember(ex) { mutableStateOf<Pair<Int, Int>?>(null) }
    var errors by remember(ex) { mutableIntStateOf(0) }
    val matched = remember(ex) { mutableStateListOf<Int>() }
    Question(tr("Соедините пары"))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ex.left.forEachIndexed { i, face ->
                val state = when {
                    i in matched -> TileState.RIGHT
                    wrongFlash?.first == i -> TileState.WRONG
                    i == left -> TileState.SELECTED
                    else -> TileState.IDLE
                }
                AnswerTile(state, accent, if (locked || i in matched) null else ({ left = i; wrongFlash = null }), Modifier.fillMaxWidth(), minHeight = 72.dp) {
                    FaceView(face, big = false, accent = accent)
                }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            order.forEach { j ->
                val state = when {
                    j in matched -> TileState.RIGHT
                    wrongFlash?.second == j -> TileState.WRONG
                    else -> TileState.IDLE
                }
                AnswerTile(state, accent, if (locked || j in matched || left < 0) null else ({
                    if (left == j) {
                        matched.add(j); left = -1; wrongFlash = null
                        if (matched.size == ex.left.size) onCheck(errors == 0)
                    } else {
                        errors++; wrongFlash = left to j; left = -1
                    }
                }), Modifier.fillMaxWidth(), minHeight = 72.dp) {
                    FaceView(ex.right[j], big = false, accent = accent)
                }
            }
        }
    }
}

// ── result ─────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun LessonResultScreen(active: ActiveLesson, r: LessonOutcome, accent: Color, onAgain: () -> Unit, onClose: () -> Unit) {
    val ui = uiScale()
    BackHandler { onClose() }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(ui.s(20f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Gap(24f)
        Text(
            when (r.stars) { 3 -> tr("Отлично!"); 2 -> tr("Хорошо"); 1 -> tr("Пройдено"); else -> tr("Попробуйте ещё раз") },
            color = TextPrimary, fontSize = ui.t(30f), fontWeight = FontWeight.Bold
        )
        Gap(6f)
        Text(active.lesson.title, color = TextSecondary, fontSize = ui.t(15f), textAlign = TextAlign.Center)
        Gap(18f)
        Stars(r.stars, size = 44f)
        Gap(18f)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ResultFact(tr("Точность"), "${r.accuracy}%", Modifier.weight(1f))
            XpFact(r.xpGained, Modifier.weight(1f))
            ResultFact(tr("Ошибки"), "${r.mistakes.size}", Modifier.weight(1f))
        }
        if (r.bestCombo >= 3) {
            Gap(12f)
            Text(tr("Лучшая серия: {0} верных подряд", r.bestCombo), color = accent, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
        }
        if (r.stars == 0) {
            Gap(12f)
            Text(tr("Для зачёта нужно от 60% верных с первой попытки."), color = TextSecondary, fontSize = ui.t(14f), textAlign = TextAlign.Center)
        }
        if (r.unlocked > 0) {
            Gap(12f)
            Text(tr("Экзамен сдан: открыто уроков — {0}.", r.unlocked), color = Mint, fontSize = ui.t(15f), fontWeight = FontWeight.SemiBold)
        }
        if (r.mistakes.isNotEmpty()) {
            Gap(20f)
            Text(tr("Над чем поработать"), color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
            Gap(8f)
            r.mistakes.distinct().take(8).forEach { m ->
                GlassCard(Modifier.padding(vertical = 4.dp), corner = 16.dp) {
                    Text(mistakeLine(m), color = TextSecondary, fontSize = ui.t(14f), modifier = Modifier.padding(12.dp))
                }
            }
        }
        Gap(24f)
        NurButton(if (r.stars == 0) tr("Пройти снова") else tr("Дальше"), accent, if (r.stars == 0) onAgain else onClose, Modifier.fillMaxWidth(), primary = true)
        Gap(8f)
        NurButton(if (r.stars == 0) tr("К курсу") else tr("Повторить урок"), accent, if (r.stars == 0) onClose else onAgain, Modifier.fillMaxWidth())
    }
}

@Composable
private fun XpFact(xp: Int, modifier: Modifier) {
    val ui = uiScale()
    // Counts up once the result has landed: the reward is seen arriving, not just printed.
    var shown by remember { mutableIntStateOf(0) }
    LaunchedEffect(xp) { delay(320); shown = xp }
    GlassCard(modifier, corner = 18.dp) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            RollingNumber(shown, TextPrimary, ui.t(22f), prefix = "+")
            Text(tr("Опыт"), color = TextTertiary, fontSize = ui.t(12f))
        }
    }
}

@Composable
private fun ResultFact(label: String, value: String, modifier: Modifier) {
    val ui = uiScale()
    GlassCard(modifier, corner = 18.dp) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = TextPrimary, fontSize = ui.t(22f), fontWeight = FontWeight.Bold)
            Text(label, color = TextTertiary, fontSize = ui.t(12f))
        }
    }
}

private fun faceText(f: Face): String = when (f) {
    is Face.Ar -> f.text
    is Face.Tr -> f.text
    is Face.Txt -> f.text + (f.caption?.let { " ($it)" } ?: "")
}

private fun mistakeLine(m: Exercise): String = when (m) {
    is Exercise.Choice -> "${faceText(m.prompt)} → ${faceText(m.options[m.answer])}"
    is Exercise.Missing -> tr("{0} — {1}: буква «{2}»", m.word.arabic, m.word.ru, m.options[m.answer].name)
    is Exercise.Assemble -> "${m.word.arabic} — ${m.word.translit}, «${m.word.ru}»"
    is Exercise.Pairs -> m.left.indices.joinToString(", ") { "${faceText(m.left[it])} = ${faceText(m.right[it])}" }
    else -> ""
}
