package com.nur.prayer.i18n

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * 0.13.0 localisation.
 *
 * Source language is Russian and the Russian sentence itself is the key (gettext style): the code
 * stays readable, and a string nobody has translated yet falls back to the original instead of a
 * blank. Catalogs live in `assets/i18n/<code>.tsv` as `<id>\t<text>`, where id is the hex
 * [String.hashCode] of the Russian key — the JVM defines that hash exactly, so `tools/i18n.py`
 * computes the same id and checks every catalog against every literal in the sources.
 *
 * The current language is Compose state: every composable that calls [tr] re-reads it and is
 * recomposed when the language changes, in place, without recreating the activity (scroll
 * positions, the open page and half-typed search survive). Non-UI callers (notifications, the view
 * model) read the same value.
 */
enum class AppLanguage(
    val code: String,
    /** Always in its own language: a user lost in a foreign UI must still find his own. */
    val nativeName: String,
    /** Regional-indicator emoji; null when Unicode has none (Tatarstan) — drawn by hand then. */
    val flag: String?,
    val rtl: Boolean = false
) {
    RU("ru", "Русский", "\uD83C\uDDF7\uD83C\uDDFA"),
    EN("en", "English", "\uD83C\uDDEC\uD83C\uDDE7"),
    TR("tr", "Türkçe", "\uD83C\uDDF9\uD83C\uDDF7"),
    UZ("uz", "Oʻzbekcha", "\uD83C\uDDFA\uD83C\uDDFF"),
    KK("kk", "Қазақша", "\uD83C\uDDF0\uD83C\uDDFF"),
    KY("ky", "Кыргызча", "\uD83C\uDDF0\uD83C\uDDEC"),
    TT("tt", "Татарча", null),
    TG("tg", "Тоҷикӣ", "\uD83C\uDDF9\uD83C\uDDEF"),
    AZ("az", "Azərbaycanca", "\uD83C\uDDE6\uD83C\uDDFF"),
    ID("id", "Bahasa Indonesia", "\uD83C\uDDEE\uD83C\uDDE9"),
    AR("ar", "العربية", "\uD83C\uDDF8\uD83C\uDDE6", rtl = true);

    val locale: Locale get() = Locale.forLanguageTag(code)

    companion object {
        fun of(code: String?): AppLanguage? = entries.firstOrNull { it.code == code }

        /** First launch: the phone's language when we speak it, Russian otherwise (the original audience). */
        fun fromSystem(locale: Locale = Locale.getDefault()): AppLanguage = of(locale.language) ?: RU
    }
}

object L10n {
    private const val PREFS = "nur_language"
    private const val KEY = "language"
    private const val PENDING = "pending"

    private val state = mutableStateOf(AppLanguage.RU)
    private val _flow = MutableStateFlow(AppLanguage.RU)

    /** For coroutines: the view model recomputes its prepared sentences on every change. */
    val flow: StateFlow<AppLanguage> = _flow.asStateFlow()

    /** Reading this inside composition subscribes the caller to language changes. */
    val language: AppLanguage get() = state.value

    @Volatile private var catalog: Map<Int, String> = emptyMap()
    private var source: ((String) -> String?)? = null
    private var prefs: android.content.SharedPreferences? = null
    private val listeners = mutableListOf<(AppLanguage) -> Unit>()

    /**
     * Called once from Application.onCreate, synchronously: the very first frame and an alarm
     * fired from a cold process must both already speak the user's language.
     */
    fun install(context: Context) {
        val app = context.applicationContext
        val assets = app.assets
        source = { name -> runCatching { assets.open(name).bufferedReader().use { it.readText() } }.getOrNull() }
        shipped = setOf(AppLanguage.RU.code) + (runCatching { assets.list("i18n") }.getOrNull().orEmpty()
            .filter { it.endsWith(".tsv") }.map { it.removeSuffix(".tsv") })
        val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        val saved = AppLanguage.of(p.getString(KEY, null)) ?: AppLanguage.fromSystem()
        var chosen = if (saved.code in shipped) saved else AppLanguage.RU
        // A non-Russian language that never reached confirm() means the process died while it was
        // on screen. Fall back to Russian once instead of crashing on every launch.
        val pending = p.getString(PENDING, null)
        if (pending != null) {
            p.edit().remove(PENDING).putString(KEY, AppLanguage.RU.code).commit()
            failedLanguage = pending
            chosen = AppLanguage.RU
        }
        if (chosen != AppLanguage.RU) p.edit().putString(PENDING, chosen.code).commit()
        apply(chosen)
    }

    /** Code of a language that was switched away from after the process died on it, or null. */
    @Volatile var failedLanguage: String? = null
        private set

    /** The current language has been on screen long enough to be trusted: drops the crash marker. */
    fun confirm() { prefs?.edit()?.remove(PENDING)?.apply() }

    @Volatile private var shipped: Set<String> = setOf(AppLanguage.RU.code)

    /**
     * Languages that actually have a catalog in the APK, in [AppLanguage] order. The picker shows
     * only these: a language without its catalog would silently stay Russian.
     */
    val available: List<AppLanguage> get() = AppLanguage.entries.filter { it.code in shipped }

    /** Switches and persists. Safe to call from the main thread: a catalog is a few kilobytes. */
    fun set(language: AppLanguage) {
        if (language == state.value && (language == AppLanguage.RU || catalog.isNotEmpty())) return
        prefs?.edit()?.let { e ->
            e.putString(KEY, language.code)
            if (language == AppLanguage.RU) e.remove(PENDING) else e.putString(PENDING, language.code)
            e.commit()
        }
        apply(language)
        listeners.toList().forEach { runCatching { it(language) } }
    }

    /** Side effects outside Compose (notification channel names) subscribe here. */
    fun onChange(listener: (AppLanguage) -> Unit) { listeners += listener }

    private fun apply(language: AppLanguage) {
        // Catalog first, state second: a recomposition triggered by the state must find the words.
        catalog = if (language == AppLanguage.RU) emptyMap() else parse(source?.invoke("i18n/${language.code}.tsv"))
        state.value = language
        _flow.value = language
    }

    /** The translation of a Russian key, or the key itself. */
    fun lookup(key: String): String {
        if (state.value == AppLanguage.RU) return key
        return catalog[key.hashCode()] ?: key
    }

    internal fun parse(text: String?): Map<Int, String> {
        if (text.isNullOrEmpty()) return emptyMap()
        val out = HashMap<Int, String>(1024)
        text.lineSequence().forEach { line ->
            if (line.isEmpty() || line[0] == '#') return@forEach
            val tab = line.indexOf('\t')
            if (tab <= 0) return@forEach
            val id = line.substring(0, tab).toLongOrNull(16)?.toInt() ?: return@forEach
            out[id] = unescape(line.substring(tab + 1))
        }
        return out
    }

    private fun unescape(s: String): String {
        if ('\\' !in s) return s
        val b = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) {
                    'n' -> b.append('\n')
                    't' -> b.append('\t')
                    '\\' -> b.append('\\')
                    else -> b.append(c).append(s[i + 1])
                }
                i += 2
            } else { b.append(c); i++ }
        }
        return b.toString()
    }

    /** `{0}`, `{1}`… — positional, so a translation may reorder them ("31 октября" → "October 31"). */
    fun format(pattern: String, args: Array<out Any?>): String {
        if (args.isEmpty() || '{' !in pattern) return pattern
        val b = StringBuilder(pattern.length + 16)
        var i = 0
        while (i < pattern.length) {
            val c = pattern[i]
            if (c == '{') {
                val close = pattern.indexOf('}', i + 1)
                val index = if (close > i) pattern.substring(i + 1, close).toIntOrNull() else null
                if (index != null && index in args.indices) {
                    b.append(args[index]); i = close + 1; continue
                }
            }
            b.append(c); i++
        }
        return b.toString()
    }

    /*
     * Sentences assembled by the calculation core (protected, hash-locked files) arrive already
     * filled in: "Фаджр: время мечети, восход − 90 мин". They are translated at display time by
     * matching the source templates, which tools/i18n.py extracts into the catalogs as patterns.
     */
    private val patternCache = HashMap<String, Regex>()

    fun lookupDynamic(text: String): String =
        // A sentence that cannot be translated is shown in Russian; it must never take the screen down.
        runCatching { lookupDynamicUnsafe(text) }.getOrDefault(text)

    private fun lookupDynamicUnsafe(text: String): String {
        if (state.value == AppLanguage.RU || text.isEmpty()) return text
        catalog[text.hashCode()]?.let { return it }
        matchPattern(text)?.let { return it }
        // The engine joins its reasons with " · "; each part is a sentence of its own.
        if (" · " in text) return text.split(" · ").joinToString(" · ") { part ->
            catalog[part.hashCode()] ?: matchPattern(part) ?: part
        }
        return text
    }

    private fun matchPattern(text: String): String? {
        for (pattern in Patterns.ALL) {
            val regex = synchronized(patternCache) { patternCache.getOrPut(pattern) { Patterns.regex(pattern) } }
            val m = regex.matchEntire(text) ?: continue
            val translated = catalog[pattern.hashCode()] ?: continue
            val groups = m.groupValues.drop(1).map { g -> catalog[g.hashCode()] ?: g }
            return format(translated, groups.toTypedArray())
        }
        return null
    }
}

/** Translate a Russian UI string. Read inside composition, it follows language changes live. */
fun tr(ru: String): String = L10n.lookup(ru)

/** Translate a Russian template with `{0}`-style placeholders and fill it. */
fun tr(ru: String, vararg args: Any?): String = L10n.format(L10n.lookup(ru), args)

/**
 * The same Russian text can need different words elsewhere ("{0} {1}" as a date and as anything
 * else), so a context is mixed into the key exactly like gettext's msgctxt.
 */
fun trc(context: String, ru: String, vararg args: Any?): String {
    val key = context + "\u0004" + ru
    val found = L10n.lookup(key)
    return L10n.format(if (found === key || found == key) ru else found, args)
}

/** For finished sentences produced by the calculation core; see [L10n.lookupDynamic]. */
fun trDynamic(text: String): String = L10n.lookupDynamic(text)
