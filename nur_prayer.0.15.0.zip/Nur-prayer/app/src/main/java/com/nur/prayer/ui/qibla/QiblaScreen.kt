package com.nur.prayer.ui.qibla

import com.nur.prayer.i18n.tr

import android.os.SystemClock
import com.nur.prayer.ui.components.ScreenHeader
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.KaabaIcon
import com.nur.prayer.ui.theme.Amber
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Qibla, 0.14.2: one filled instrument, no numbers on it.
 *
 *  - Accuracy is untouched: the heading still comes from [rememberHeading] (true north via WMM,
 *    display-rotation remap, unit-vector filter) and [QiblaGuidance] still alone decides "aligned".
 *    The dial only paints. Tracking is a near-critically damped spring: no lag you can see, and at
 *    rest it sits exactly on the reading.
 *  - Search runs by itself. While the sensors have nothing trustworthy yet, the dial spins slowly
 *    and a light sweeps the bezel. The first trustworthy reading does not snap: the spin carries on
 *    in the same direction and decelerates onto the true bearing with one soft overshoot
 *    ([lockDialRotation]) — the compass *finds* the Kaaba. A minimum search time keeps that moment
 *    visible on phones whose sensors are ready in a few milliseconds.
 *  - Then the user turns the phone. The Kaaba rides the rim, a thin needle points at it and brightens
 *    as it nears the top. Green appears only when both the policy says "aligned" *and* the dial,
 *    as drawn, really has the Kaaba under the top index: a green line from the centre to the index.
 *  - No text on the instrument. One short status line under it, only when something needs the user
 *    (no sensor, calibration, tilt) or to confirm the lock.
 */
@Composable
fun QiblaScreen(
    data: PrayerData,
    palette: PhasePalette,
    modifier: Modifier = Modifier,
    headingOverride: Heading? = null,
    onBack: (() -> Unit)? = null
) {
    val ui = uiScale()
    var showDetails by rememberSaveable { mutableStateOf(false) }
    val heading = headingOverride
        ?: rememberHeading(data.place.coordinates.latitude, data.place.coordinates.longitude)
    val qibla = data.qibla.toFloat()
    val delta = angleDelta(heading.azimuth, qibla)
    val usable = heading.available && heading.trustworthy && heading.heldFlat && delta.isFinite()
    val aligned = QiblaGuidance.aligned(delta, heading.available, heading.trustworthy, heading.heldFlat)

    val motion = rememberDialMotion(heading.azimuth, usable, heading.available)
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(aligned && motion.locked) {
        if (aligned && motion.locked) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }
    // Draw-phase values only: none of these recomposes the screen per frame.
    val lock = animateFloatAsState(if (aligned) 1f else 0f, tween(240), label = "qiblaLock")
    val live = animateFloatAsState(if (usable && motion.locked) 1f else 0f, tween(320), label = "qiblaLive")
    val rotation: () -> Float = { motion.rotation() }
    /** Screen angle of the Kaaba from the top index, 0..180, as actually drawn. */
    val offTop: () -> Float = { abs(angleDelta(0f, normalize(qibla + rotation()))) }
    val green: () -> Float = {
        val visual = 1f - ((offTop() - QiblaGuidance.ALIGN_TOLERANCE) / 3f).coerceIn(0f, 1f)
        lock.value * visual
    }
    val near: () -> Float = { live.value * (1f - (offTop() / 40f).coerceIn(0f, 1f)) }

    val status = if (usable && !aligned) null
        else QiblaGuidance.instruction(delta, heading.available, heading.trustworthy, heading.heldFlat)
    val hint = when {
        !heading.available -> tr("На устройстве нет доступного датчика направления. Используйте азимут кыблы по карте или другому компасу.")
        heading.interference -> tr("Отойдите от металла, магнитного чехла и динамиков.")
        !heading.trustworthy -> tr("Проведите телефоном «восьмёркой» для калибровки.")
        else -> null
    }

    Column(
        modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(24f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ScreenHeader(tr("Кыбла"), onBack) {
            AutoSizeText(data.place.label, color = TextSecondary, fontSize = ui.t(13f), maxLines = 2,
                textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
        }
        Spacer(Modifier.height(if (ui.compact) 18.dp else 40.dp))

        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val dialSize = min(maxWidth, min((ui.heightDp * 0.46f).dp, if (ui.compact) 300.dp else 360.dp))
            Box(
                Modifier
                    .width(dialSize)
                    .aspectRatio(1f)
                    .align(Alignment.Center)
                    .testTag("qibla-instrument")
                    .semantics {
                        stateDescription = when {
                            aligned -> tr("Направление найдено")
                            usable -> tr("Поиск направления")
                            else -> tr("Нет достоверного направления")
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                // 1. The body: filled disc, bezel, search sweep. Fixed to the screen.
                Canvas(Modifier.fillMaxSize()) {
                    val r = size.minDimension / 2f * QiblaDial.RADIUS
                    if (r < 4f) return@Canvas
                    val c = center
                    drawCircle(Color.Black.copy(alpha = 0.28f), r * 1.05f, c)
                    drawCircle(
                        Brush.radialGradient(listOf(DialCore, DialEdge), center = c, radius = r),
                        r, c
                    )
                    drawCircle(SurfaceEdge, r, c, style = Stroke(1.2f * density))
                    drawCircle(SurfaceEdge.copy(alpha = 0.10f), r * 0.80f, c, style = Stroke(1f * density))
                    val sweep = motion.sweep()
                    if (sweep != null) {
                        rotate(sweep, c) {
                            drawCircle(
                                Brush.sweepGradient(
                                    0f to Color.Transparent,
                                    0.70f to Color.Transparent,
                                    1f to TextPrimary.copy(alpha = 0.55f),
                                    center = c
                                ),
                                r - 1.5f * density, c, style = Stroke(3f * density)
                            )
                        }
                    }
                }

                // 2. The world: graduations, north, the needle to the Kaaba. Turns with the heading.
                Box(Modifier.fillMaxSize().graphicsLayer {
                    rotationZ = rotation()
                    alpha = if (heading.available) 0.55f + 0.45f * live.value else 0.45f
                }) {
                    Canvas(Modifier.fillMaxSize()) {
                        val r = size.minDimension / 2f * QiblaDial.RADIUS
                        if (r < 4f) return@Canvas
                        val c = center
                        for (i in 0 until 72) {
                            val a = Math.toRadians(i * 5.0 - 90.0)
                            val major = i % 18 == 0
                            val mid = i % 6 == 0
                            val outer = r * 0.95f
                            val inner = outer - r * (if (major) 0.075f else if (mid) 0.05f else 0.028f)
                            drawLine(
                                color = TextPrimary.copy(alpha = if (major) 0.70f else if (mid) 0.38f else 0.16f),
                                start = Offset(c.x + outer * cos(a).toFloat(), c.y + outer * sin(a).toFloat()),
                                end = Offset(c.x + inner * cos(a).toFloat(), c.y + inner * sin(a).toFloat()),
                                strokeWidth = (if (major) 2f else 1.2f) * density,
                                cap = StrokeCap.Round
                            )
                        }
                        // North: a small filled red wedge inside the graduations.
                        val nTip = r * 0.83f
                        val north = Path().apply {
                            moveTo(c.x, c.y - nTip - r * 0.055f)
                            lineTo(c.x - r * 0.04f, c.y - nTip + r * 0.02f)
                            lineTo(c.x + r * 0.04f, c.y - nTip + r * 0.02f)
                            close()
                        }
                        drawPath(north, Crimson)

                        // Needle from the centre toward the Kaaba, stopping short of the icon.
                        val qa = Math.toRadians(qibla - 90.0)
                        val g = green()
                        val color = lerp(TextPrimary.copy(alpha = 0.30f + 0.50f * near()), Mint, g)
                        val end = r * QiblaDial.KAABA_ORBIT - size.minDimension * QiblaDial.KAABA_SIZE * 0.72f
                        drawLine(
                            color = color,
                            start = Offset(c.x + r * 0.10f * cos(qa).toFloat(), c.y + r * 0.10f * sin(qa).toFloat()),
                            end = Offset(c.x + end * cos(qa).toFloat(), c.y + end * sin(qa).toFloat()),
                            strokeWidth = (2f + 1f * near()) * density,
                            cap = StrokeCap.Round
                        )
                    }
                    // The Kaaba rides the rim at the bearing and stays upright for the reader.
                    Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = qibla }) {
                        val kaaba = dialSize * QiblaDial.KAABA_SIZE
                        val top = dialSize * (0.5f - QiblaDial.RADIUS / 2f * QiblaDial.KAABA_ORBIT) - kaaba / 2
                        KaabaIcon(
                            edge = if (usable) lerp(TextPrimary, Mint, lock.value) else TextTertiary,
                            glow = green,
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = top)
                                .size(kaaba)
                                .graphicsLayer { rotationZ = -rotation() - qibla }
                                .semantics { contentDescription = tr("Кааба — направление кыблы") }
                        )
                    }
                }

                // 3. The phone: top index, the green line on lock, the level at the hub. Fixed.
                Canvas(Modifier.fillMaxSize()) {
                    val r = size.minDimension / 2f * QiblaDial.RADIUS
                    if (r < 4f) return@Canvas
                    val c = center
                    val g = green()
                    if (g > 0f) {
                        val top = Offset(c.x, c.y - r * 0.97f)
                        drawLine(Mint.copy(alpha = 0.22f * g), c, top, strokeWidth = 10f * density, cap = StrokeCap.Round)
                        drawLine(Mint.copy(alpha = g), c, top, strokeWidth = 3f * density, cap = StrokeCap.Round)
                    }
                    val index = Path().apply {
                        moveTo(c.x, c.y - r * 0.90f)
                        lineTo(c.x - r * 0.05f, c.y - r * 1.02f)
                        lineTo(c.x + r * 0.05f, c.y - r * 1.02f)
                        close()
                    }
                    drawPath(index, lerp(TextPrimary, Mint, g))

                    // Hub doubles as the level: centred and white when flat, drifting and amber when not.
                    val tilt = if (heading.available && heading.tiltDegrees.isFinite()) heading.tiltDegrees else 0f
                    val flat = !heading.available || heading.heldFlat
                    val drift = (tilt / 45f).coerceIn(0f, 1f) * r * 0.16f
                    drawCircle(DialEdge, r * 0.075f, c)
                    drawCircle(SurfaceEdge, r * 0.075f, c, style = Stroke(1f * density))
                    drawCircle(
                        if (!flat) Amber else lerp(TextPrimary.copy(alpha = 0.85f), Mint, g),
                        r * 0.036f,
                        Offset(c.x, c.y + drift)
                    )
                }
            }
        }

        Spacer(Modifier.height(22.dp))
        // One short line, only when it matters; the slot keeps its height so the dial never moves.
        Box(Modifier.fillMaxWidth().heightIn(min = 24.dp), contentAlignment = Alignment.Center) {
            if (status != null) {
                AutoSizeText(status, color = if (aligned) Mint else TextSecondary, fontSize = ui.t(15f),
                    maxLines = 2, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
        }
        if (hint != null) {
            Text(hint, color = Amber, fontSize = ui.t(12f), lineHeight = ui.t(18f),
                textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
        }

        Spacer(Modifier.height(28.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(SurfaceEdge))
        Row(
            Modifier.fillMaxWidth().heightIn(min = 56.dp)
                .clickable(role = Role.Button, onClick = { showDetails = !showDetails })
                .semantics { stateDescription = if (showDetails) tr("Развёрнуто") else tr("Свёрнуто") },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(tr("Точность и датчики"), color = TextSecondary, fontSize = ui.t(14f), modifier = Modifier.weight(1f))
            Text(if (showDetails) "−" else "+", color = palette.accent, fontSize = ui.t(22f))
        }
        AnimatedVisibility(showDetails) {
            Column {
                InfoRow(tr("Азимут кыблы"), QiblaGuidance.degrees(qibla))
                InfoRow(tr("До Каабы"), tr("{0} км", data.kaabaDistanceKm.roundToInt()))
                InfoRow(tr("Курс устройства"), if (heading.available) QiblaGuidance.degrees(heading.azimuth) else "—")
                InfoRow(tr("Магнитный курс"), if (heading.available) QiblaGuidance.degrees(heading.magneticAzimuth) else "—")
                InfoRow(tr("Магнитная поправка"), "${heading.declination.roundToInt()}°")
                InfoRow(tr("Наклон"), if (heading.available) "${heading.tiltDegrees.roundToInt()}°" else "—")
                InfoRow(tr("Магнитное поле"), if (heading.fieldStrength > 0f) tr("{0} мкТл", heading.fieldStrength.roundToInt()) else "—")
                InfoRow(tr("Калибровка"), when (heading.accuracy) {
                    3 -> tr("Высокая")
                    2 -> tr("Средняя")
                    1 -> tr("Низкая")
                    else -> tr("Не определена")
                })
                InfoRow(tr("Датчики"), when (heading.source) {
                    HeadingSource.FUSED -> tr("Гироскоп, магнитометр")
                    HeadingSource.GEOMAGNETIC -> tr("Магнитометр, акселерометр")
                    HeadingSource.RAW -> tr("Сырые показания")
                    HeadingSource.NONE -> tr("Недоступны")
                })
                Text(tr("Азимут отсчитывается от истинного севера. Магнитная поправка учтена. Зелёный указатель — отклонение не более 2,5° по показаниям датчика, а не гарантия его точности."),
                    color = TextTertiary, fontSize = ui.t(12f), lineHeight = ui.t(18f), modifier = Modifier.padding(top = 12.dp))
            }
        }
        Spacer(Modifier.height(LocalDockInset.current))
    }
}

internal object QiblaDial {
    /** Disc radius as a share of half the instrument box (room left for the index and shadow). */
    const val RADIUS = 0.90f
    /** Kaaba centre, as a share of the disc radius. */
    const val KAABA_ORBIT = 0.66f
    /** Kaaba edge, as a share of the instrument box. */
    const val KAABA_SIZE = 0.115f

    /** One slow revolution of the dial while searching; the sweep on the bezel runs faster. */
    const val SPIN_MILLIS = 2600
    const val SWEEP_MILLIS = 1300
    /** The search is shown at least this long, even when the sensors are ready at once. */
    const val SEARCH_MIN_MILLIS = 900L
    /** Retargets during this window keep the soft lock spring instead of the tracking one. */
    const val LOCK_MILLIS = 1300L
    const val LOCK_MIN_TRAVEL = 120f

    /** Degrees per second of the search spin (negative: counter-clockwise). */
    const val SPIN_VELOCITY = -360f * 1000f / SPIN_MILLIS
}

private val DialCore = Color(0xFF26224F)
private val DialEdge = Color(0xFF0F0D26)

/**
 * The dial's motion: auto-search spin → lock → tracking, and back to search whenever trust is lost.
 * All values are read in draw lambdas. Pure policy (where to stop) lives in [lockDialRotation] and
 * [nearestDialRotation].
 *
 * Without a trustworthy reading the dial never holds a bearing — not even the last good one, which
 * would look like a valid direction. It spins: unmistakably "searching", and green is impossible
 * because green needs [QiblaGuidance.aligned].
 */
internal class DialMotion {
    val tracked = Animatable(0f)
    var target by mutableFloatStateOf(0f)
    /** True only while tracking a trustworthy reading. */
    var locked by mutableStateOf(false)
    var lockUntil = 0L
    var launchVelocity = 0f
    /** The search spin continues from wherever the dial was, without a jump. */
    var spinBase = 0f
    var wasSearching = false
    /** Present only while composed in the search phase. */
    var spin: State<Float>? = null
    var sweepState: State<Float>? = null
    var sweeping = false

    fun searchAngle(): Float = spinBase + (spin?.value ?: 0f)
    fun rotation(): Float = if (locked) tracked.value else if (sweeping) searchAngle() else 0f
    fun sweep(): Float? = if (sweeping) sweepState?.value else null
}

@Composable
private fun rememberDialMotion(azimuth: Float, usable: Boolean, available: Boolean): DialMotion {
    val motion = remember { DialMotion() }
    var searchShown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(QiblaDial.SEARCH_MIN_MILLIS)
        searchShown = true
    }
    val ready = usable && searchShown
    val searching = available && !ready

    if (searching && !motion.wasSearching) motion.spinBase = if (motion.locked) motion.tracked.value else 0f
    motion.wasSearching = searching
    motion.sweeping = searching
    if (searching) {
        val transition = rememberInfiniteTransition(label = "qiblaSearch")
        motion.sweepState = transition.animateFloat(
            0f, 360f, infiniteRepeatable(tween(QiblaDial.SWEEP_MILLIS, easing = LinearEasing)), label = "qiblaSweep"
        )
        motion.spin = transition.animateFloat(
            0f, -360f, infiniteRepeatable(tween(QiblaDial.SPIN_MILLIS, easing = LinearEasing)), label = "qiblaSpin"
        )
    }

    // Lock on every trustworthy reading that follows a search; drop the lock the moment trust goes.
    LaunchedEffect(ready) {
        if (!ready) {
            motion.locked = false
            return@LaunchedEffect
        }
        val spun = motion.spin != null
        val from = if (spun) motion.searchAngle() else 0f
        motion.launchVelocity = if (spun) QiblaDial.SPIN_VELOCITY else 0f
        motion.tracked.snapTo(from)
        motion.target = lockDialRotation(from, azimuth, QiblaDial.LOCK_MIN_TRAVEL)
        motion.lockUntil = SystemClock.uptimeMillis() + QiblaDial.LOCK_MILLIS
        motion.locked = true
    }
    // Tracking: every fresh reading moves the unwrapped target by the short way round.
    LaunchedEffect(azimuth, ready) {
        if (ready && motion.locked) motion.target = nearestDialRotation(motion.target, azimuth)
    }
    // One driver for both phases. A new target retargets the running spring and keeps its velocity.
    LaunchedEffect(motion) {
        snapshotFlow { motion.target to motion.locked }.collectLatest { (target, locked) ->
            if (!locked) return@collectLatest
            val locking = SystemClock.uptimeMillis() < motion.lockUntil
            val velocity = if (motion.launchVelocity != 0f) motion.launchVelocity else motion.tracked.velocity
            motion.launchVelocity = 0f
            motion.tracked.animateTo(
                target,
                if (locking) spring(dampingRatio = 0.62f, stiffness = 40f)
                else spring(dampingRatio = 0.92f, stiffness = 260f),
                initialVelocity = velocity
            )
        }
    }
    return motion
}

@Composable
private fun InfoRow(label: String, value: String) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextSecondary, fontSize = ui.t(13f), modifier = Modifier.weight(1f))
        Spacer(Modifier.width(16.dp))
        AutoSizeText(value, color = TextPrimary, fontSize = ui.t(14f), maxLines = 2,
            textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}
