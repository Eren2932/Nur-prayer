package com.nur.prayer

import android.content.Context
import android.os.Build
import android.util.Log
import com.nur.prayer.i18n.L10n
import java.io.File

/**
 * Writes the stack trace of an uncaught exception to a private file before the process dies, and
 * hands it back on the next launch so the app can show it. No network, no third-party SDK: the
 * report only ever leaves the phone if the user copies it out.
 */
object CrashReport {
    private const val FILE = "last_crash.txt"
    private const val MAX_CHARS = 7000

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                val text = buildString {
                    append("Nur crash report\n")
                    append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                        .append(", Android ").append(Build.VERSION.RELEASE)
                        .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
                    append("Language: ").append(L10n.language.code).append('\n')
                    append("Thread: ").append(thread.name).append("\n\n")
                    append(Log.getStackTraceString(error))
                }
                File(app.filesDir, FILE).writeText(text.take(MAX_CHARS))
            }
            previous?.uncaughtException(thread, error)
        }
    }

    /** The report from the previous run, once: reading it deletes it. */
    fun take(context: Context): String? {
        val file = File(context.applicationContext.filesDir, FILE)
        if (!file.exists()) return null
        val text = runCatching { file.readText() }.getOrNull()
        runCatching { file.delete() }
        val failed = L10n.failedLanguage
        return if (text.isNullOrBlank()) null
        else if (failed != null) "Language '$failed' was switched off after this crash.\n\n$text" else text
    }
}
