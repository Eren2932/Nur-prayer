package com.nur.prayer.daily

import kotlin.math.abs

/**
 * The rules of the story viewer, kept pure so they are unit-tested.
 *
 * 0.10.0 bug: the viewer used detectTapGestures with onPress for the pause and onTap for the
 * navigation. Without onLongPress, detectTapGestures fires onTap on release however long the
 * finger was held, so "hold to pause, let go" jumped to the next slide. Here a release is a tap
 * only when it was short and did not travel; anything longer is a pause and changes nothing.
 */
object StoryMath {
    /** A press up to this long is a tap; longer is a hold (pause). */
    const val TAP_MAX_MILLIS = 220L

    /** Left part of the screen that steps back; the rest goes on. */
    const val BACK_ZONE = 0.3f

    enum class Gesture { PREV, NEXT, CLOSE, NONE }

    /**
     * What a finished touch means. [dx]/[dy] are the total travel, [x] where it went down,
     * [swipePx] the horizontal swipe threshold, [closePx] the pull-down needed to close.
     */
    fun classify(heldMillis: Long, dx: Float, dy: Float, x: Float, width: Float, swipePx: Float, closePx: Float): Gesture {
        val ax = abs(dx)
        val ay = abs(dy)
        return when {
            dy > closePx && dy > ax -> Gesture.CLOSE
            ax > swipePx && ax > ay -> if (dx < 0) Gesture.NEXT else Gesture.PREV
            heldMillis <= TAP_MAX_MILLIS && ax < swipePx / 2 && ay < swipePx / 2 ->
                if (width > 0f && x < width * BACK_ZONE) Gesture.PREV else Gesture.NEXT
            else -> Gesture.NONE
        }
    }

    /** Time on a slide grows with its text: a long hadith is not cut off mid-sentence. */
    fun durationMillis(slide: StorySlide): Int {
        val chars = slide.ru.length + (slide.translit?.length ?: 0) / 2 + (slide.arabic?.length ?: 0) / 3 + (slide.note?.length ?: 0) / 2
        return (4500 + chars * 42).coerceIn(MIN_MILLIS, MAX_MILLIS)
    }

    const val MIN_MILLIS = 6000
    const val MAX_MILLIS = 18000

    fun isSeen(mask: Int, i: Int): Boolean = i in 0..30 && (mask shr i) and 1 == 1
    fun withSeen(mask: Int, i: Int): Int = if (i in 0..30) mask or (1 shl i) else mask
    fun allSeen(mask: Int, count: Int): Boolean = (0 until count).all { isSeen(mask, it) }

    /** Where "watch" starts: the first slide not seen today, or the beginning when all are. */
    fun firstUnseen(mask: Int, count: Int): Int = (0 until count).firstOrNull { !isSeen(mask, it) } ?: 0
}
