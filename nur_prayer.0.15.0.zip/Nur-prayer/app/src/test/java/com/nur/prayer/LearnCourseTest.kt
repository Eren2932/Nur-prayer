package com.nur.prayer

import com.nur.prayer.learn.Arabic
import com.nur.prayer.learn.Course
import com.nur.prayer.learn.Exercise
import com.nur.prayer.learn.ExerciseFactory
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.learn.LearnProgress
import com.nur.prayer.learn.LessonPlan
import com.nur.prayer.learn.LessonSession
import com.nur.prayer.ui.NurNavigator
import com.nur.prayer.ui.ROUTE_COURSE
import com.nur.prayer.ui.ROUTE_LESSON
import com.nur.prayer.ui.ROUTE_TODAY
import com.nur.prayer.ui.TAB_SCHEDULE
import com.nur.prayer.daily.TasbihMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** The course as the app builds it from the bundled assets: every lesson, many seeds. */
class LearnCourseTest {
    private fun asset(name: String): String =
        listOf(File("src/main/assets/$name"), File("app/src/main/assets/$name")).first { it.exists() }.readText()

    private val content by lazy { LearnContent.parse(asset(LearnContent.WORDS_ASSET), asset(LearnContent.QURAN_ASSET)) }

    private fun checkExercise(where: String, ex: Exercise) {
        when (ex) {
            is Exercise.Choice -> {
                assertTrue("$where: answer index", ex.answer in ex.options.indices)
                assertTrue("$where: at least two options", ex.options.size >= 2)
                assertEquals("$where: options must be distinct", ex.options.size, ex.options.distinct().size)
            }
            is Exercise.Missing -> {
                assertTrue("$where: answer index", ex.answer in ex.options.indices)
                assertEquals("$where: distinct letters", ex.options.size, ex.options.distinct().size)
                val g = Arabic.graphemes(ex.shown)
                assertTrue("$where: index inside word", ex.index in g.indices)
                assertTrue("$where: right letter", g[ex.index].startsWith(ex.options[ex.answer].char))
            }
            is Exercise.Assemble -> {
                val pool = ex.tiles.toMutableList()
                ex.target.forEach { assertTrue("$where: tile $it missing", pool.remove(it)) }
                assertEquals("$where: target spells the word", ex.word.arabic, ex.target.joinToString(""))
            }
            is Exercise.Pairs -> {
                assertEquals(where, ex.left.size, ex.right.size)
                assertEquals("$where: distinct meanings", ex.right.size, ex.right.distinct().size)
            }
            else -> {}
        }
    }

    @Test fun everyLessonBuildsValidExercisesOnManySeeds() {
        val c = content
        assertTrue("course has stages", c.course.stages.size >= 6)
        for (lesson in c.course.lessons) {
            for (seed in 1..12) {
                val list = ExerciseFactory(c.lexicon, c.quran, seed).build(lesson.plan, c.course, LearnProgress(), 0)
                assertTrue("${lesson.id} seed $seed is empty", list.isNotEmpty())
                if (lesson.plan !is LessonPlan.Surah) assertTrue("${lesson.id} has graded work", list.any { !it.isIntro })
                list.forEachIndexed { i, ex -> checkExercise("${lesson.id}#$seed[$i]", ex) }
            }
        }
    }

    @Test fun checkpointsAndReviewBuild() {
        val c = content
        for (i in 1 until c.course.stages.size) {
            val lesson = c.course.lesson(Course.checkpointId(i))
            assertNotNull("checkpoint $i", lesson)
            val list = ExerciseFactory(c.lexicon, c.quran, 7).build(lesson!!.plan, c.course, LearnProgress(), 0)
            assertTrue("checkpoint $i has questions", list.size >= 6)
        }
        val word = c.lexicon.words.first()
        val p = LearnProgress().introduce(listOf(LearnProgress.wordKey(word)), 10)
        val review = c.course.lesson(Course.REVIEW_ID)!!
        assertTrue(ExerciseFactory(c.lexicon, c.quran, 3).build(review.plan, c.course, p, 10).isNotEmpty())
    }

    @Test fun perfectRunOpensTheWholeCourseInOrder() {
        val c = content
        var p = LearnProgress()
        var day = 20_000L
        var steps = 0
        while (true) {
            val next = c.course.next(p) ?: break
            assertTrue("${next.id} must be open when proposed", c.course.isUnlocked(next.id, p))
            val list = ExerciseFactory(c.lexicon, c.quran, steps).build(next.plan, c.course, p, day)
            var s = LessonSession(list)
            while (!s.finished) s = if (s.current!!.isIntro) s.skip() else s.answer(true)
            p = p.complete(next.id, s.accuracy, s.firstTryCorrect, day)
            assertEquals("${next.id} perfect run earns three stars", 3, p.stars(next.id))
            day++
            steps++
            assertTrue("course never loops", steps <= c.course.lessons.size)
        }
        assertNull(c.course.next(p))
        assertTrue("streak counted", p.streakOn(day - 1) >= steps.coerceAtMost(2))
    }

    @Test fun progressSurvivesEncoding() {
        val c = content
        val w = c.lexicon.words[3]
        val p = LearnProgress().introduce(listOf(LearnProgress.wordKey(w)), 5).answer(listOf(LearnProgress.wordKey(w)), true, 5)
            .complete(c.course.lessons.first().id, 0.9, 9, 5)
        assertEquals(p, LearnProgress.decode(p.encode()))
        assertEquals(LearnProgress(), LearnProgress.decode("garbage\nmore garbage"))
    }

    @Test fun tasbihIs33_33_34() {
        assertEquals(0 to 0, TasbihMath.phase(0))
        assertEquals(0 to 32, TasbihMath.phase(32))
        assertEquals(1 to 0, TasbihMath.phase(33))
        assertEquals(2 to 0, TasbihMath.phase(66))
        assertEquals(2 to 33, TasbihMath.phase(99))
        assertEquals(2 to 34, TasbihMath.phase(100))
        assertEquals(2 to 34, TasbihMath.phase(150))
    }

    @Test fun learningPagesStayInsideTheLayer() {
        val nav = NurNavigator()
        nav.go(ROUTE_TODAY)
        assertTrue(nav.layerOpen)
        nav.go(ROUTE_COURSE)
        nav.go(ROUTE_LESSON)
        assertTrue("a lesson keeps the layer up", nav.layerOpen)
        assertTrue(nav.back()); assertEquals(ROUTE_COURSE, nav.current)
        assertTrue(nav.back()); assertEquals(ROUTE_TODAY, nav.current)
        nav.go(TAB_SCHEDULE)
        assertFalse("the calendar is a page, not the layer", nav.layerOpen)
        assertTrue(nav.back()); assertEquals(ROUTE_TODAY, nav.current)
        assertTrue(nav.back()); assertEquals("home", nav.current)
        val restored = NurNavigator(ROUTE_LESSON, listOf(ROUTE_COURSE, ROUTE_TODAY))
        assertEquals(ROUTE_LESSON, restored.current)
    }
}
