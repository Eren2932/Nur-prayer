package com.nur.prayer

import com.nur.prayer.ui.components.EntranceMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Timing of the staggered entrance: when a block starts, and when it is too late to animate. */
class EntranceMathTest {
    @Test
    fun delayGrowsByStepAndCaps() {
        assertEquals(0, EntranceMath.delayOf(0))
        assertEquals(45, EntranceMath.delayOf(1))
        assertEquals(360, EntranceMath.delayOf(8))
        assertEquals(360, EntranceMath.delayOf(40))
        assertEquals(0, EntranceMath.delayOf(-3))
    }

    @Test
    fun onFirstFrameTheWholeDelayRemains() {
        assertEquals(135, EntranceMath.remainingDelay(3, 0L))
    }

    @Test
    fun midCascadeOnlyTheRestIsWaited() {
        assertEquals(35, EntranceMath.remainingDelay(3, 100L))
        // Its start is past but the animation would still be running: start now, no wait.
        assertEquals(0, EntranceMath.remainingDelay(3, 300L))
    }

    @Test
    fun scrolledBackLaterShowsAtOnce() {
        // delay 135 + duration 380 = 515 ms: from then on the block is simply shown.
        assertEquals(0, EntranceMath.remainingDelay(3, 514L))
        assertNull(EntranceMath.remainingDelay(3, 515L))
        assertNull(EntranceMath.remainingDelay(0, 60_000L))
    }
}
