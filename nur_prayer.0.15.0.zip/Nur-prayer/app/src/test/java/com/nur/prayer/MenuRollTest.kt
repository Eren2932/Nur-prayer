package com.nur.prayer

import com.nur.prayer.ui.home.MenuRoll
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs

/** 0.14.2: geometry of the rolling menu items (MenuCapsule). */
class MenuRollTest {
    private val button = 48f
    private val item = 44f
    private val gap = 6f

    private fun at(e: Float, i: Int) = MenuRoll.at(e, i, 2, button, item, gap)

    @Test fun collapsedItemsSitUnderTheKnobAndAreInvisible() {
        for (i in 0..1) {
            val s = at(0f, i)
            val left = button + i * (item + gap) + s.shift
            assertEquals(0f, left, 0.001f)
            assertEquals(0f, s.alpha, 0.0001f)
        }
    }

    @Test fun openItemsRestInTheirSlotsUpright() {
        for (i in 0..1) {
            val s = at(1f, i)
            assertEquals(0f, s.shift, 0.001f)
            assertEquals(0f, s.degrees, 0.001f)
            assertEquals(1f, s.alpha, 0.0001f)
            assertEquals(1f, s.scale, 0.0001f)
        }
    }

    @Test fun rollsWithoutSlipping() {
        for (step in 0..100) {
            val s = at(step / 100f, 1)
            val arc = (s.degrees / 180f * PI.toFloat()) * (item / 2f)
            assertEquals(s.shift, arc, 0.01f)
        }
    }

    @Test fun motionIsMonotonicWhileOpening() {
        for (i in 0..1) {
            var previous = at(0f, i).shift
            for (step in 1..100) {
                val shift = at(step / 100f, i).shift
                assertTrue(shift >= previous - 0.0001f)
                previous = shift
            }
        }
    }

    @Test fun onlyTheLastItemFollowsTheOvershootAndOnlyALittle() {
        assertEquals(0f, at(1.08f, 0).shift, 0.001f)
        val last = at(1.08f, 1).shift
        assertTrue(last > 0f && last <= gap * 2f + 0.001f)
    }

    @Test fun firstItemLandsBeforeTheLast() {
        val e = 0.55f
        assertTrue(abs(at(e, 0).shift) < abs(at(e, 1).shift))
    }
}
