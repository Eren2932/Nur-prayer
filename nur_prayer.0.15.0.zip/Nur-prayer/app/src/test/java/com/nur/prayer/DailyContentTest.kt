package com.nur.prayer

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.daily.Azkar
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.DailyCodec
import com.nur.prayer.daily.DailyStories
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.StorySlide
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.ui.NurNavigator
import com.nur.prayer.ui.ROUTE_AZKAR
import com.nur.prayer.ui.ROUTE_DHIKR
import com.nur.prayer.ui.ROUTE_STORY
import com.nur.prayer.ui.ROUTE_TODAY
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.time.LocalDate

/** Azkar, stories and dhikr: text hygiene, set logic, codecs. */
class DailyContentTest {
    private val quran by lazy {
        fun asset(n: String) = listOf(File("src/main/assets/$n"), File("app/src/main/assets/$n")).first { it.exists() }.readText()
        LearnContent.parse(asset(LearnContent.WORDS_ASSET), asset(LearnContent.QURAN_ASSET)).quran
    }

    /** Arabic text holds only Arabic script, spaces and punctuation; no stray Latin or Cyrillic. */
    private fun assertArabic(where: String, s: String) {
        assertTrue("$where: empty", s.isNotBlank())
        val bad = s.filter { c ->
            !(c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' || c in '\u08A0'..'\u08FF' || c in '\uFB50'..'\uFDFF' ||
                c in '\uFE70'..'\uFEFF' || c.isWhitespace() || c.isDigit() || c in "،.()")
        }
        assertTrue("$where: non-Arabic characters «$bad»", bad.isEmpty())
    }

    /** Transliteration and translations are Cyrillic: a Latin or Armenian look-alike is a typo. */
    private fun assertCyrillic(where: String, s: String) {
        assertTrue("$where: empty", s.isNotBlank())
        val bad = s.filter { c -> c.isLetter() && c !in '\u0400'..'\u04FF' && c != '\uFDFA' }
        assertTrue("$where: non-Cyrillic letters «$bad»", bad.isEmpty())
    }

    @Test fun azkarTextsAreCleanAndComplete() {
        for (set in AzkarSet.values()) {
            val list = Azkar.of(set, quran)
            assertEquals("$set: every item resolved", Azkar.ALL.count { it.time.name == "BOTH" || it.time.name == set.name }, list.size)
            assertEquals("$set: unique ids", list.size, list.map { it.id }.distinct().size)
            list.forEach { z ->
                assertArabic("${set}/${z.id}", z.arabic)
                assertCyrillic("${set}/${z.id} translit", z.translit)
                assertCyrillic("${set}/${z.id} ru", z.ru)
                assertTrue("${z.id}: count", z.count >= 1)
                assertTrue("${z.id}: source", z.source.isNotBlank())
            }
        }
        val morning = Azkar.of(AzkarSet.MORNING, quran).first { it.id == "asbahna" }
        val evening = Azkar.of(AzkarSet.EVENING, quran).first { it.id == "asbahna" }
        assertTrue(morning.arabic.startsWith("أَصْبَحْنَا"))
        assertTrue(evening.arabic.startsWith("أَمْسَيْنَا"))
        assertTrue("evening-only item", Azkar.of(AzkarSet.EVENING, quran).any { it.id == "kalimat" })
        assertTrue("morning-only item", Azkar.of(AzkarSet.MORNING, quran).none { it.id == "kalimat" })
        assertTrue("without the Quran asset surah items drop, not show empty", Azkar.of(AzkarSet.MORNING, null).none { it.surah != null })
    }

    @Test fun azkarSetFollowsThePrayerWindow() {
        assertEquals(AzkarSet.MORNING, AzkarSet.at(Prayer.SAHAR))
        assertEquals(AzkarSet.MORNING, AzkarSet.at(Prayer.DHUHR))
        assertEquals(AzkarSet.EVENING, AzkarSet.at(Prayer.ASR))
        assertEquals(AzkarSet.EVENING, AzkarSet.at(Prayer.ISHA))
        val d = LocalDate.of(2026, 10, 31)
        assertTrue(AzkarSet.sessionKey(AzkarSet.MORNING, d) != AzkarSet.sessionKey(AzkarSet.EVENING, d))
    }

    private fun checkSlide(s: StorySlide) {
        s.arabic?.let { assertArabic(s.source, it) }
        s.translit?.let { assertCyrillic(s.source, it) }
        assertCyrillic(s.source, s.ru)
        assertTrue(s.source.isNotBlank())
    }

    @Test fun storiesAreCleanAndRotate() {
        (DailyStories.AYAT + DailyStories.HADITH + DailyStories.DUAS).forEach(::checkSlide)
        DailyStories.AYAT.forEach { assertTrue("ayah has Arabic", it.arabic != null) }
        DailyStories.DUAS.forEach { assertTrue("dua has transliteration", it.translit != null) }
        val week = (20_000L until 20_007L).map { DailyStories.of(it) }
        week.forEach { assertEquals(3, it.size) }
        assertTrue("consecutive days differ", week.zipWithNext().all { (a, b) -> a != b })
        assertEquals("deterministic by date", DailyStories.of(20_391L), DailyStories.of(20_391L))
        assertEquals("negative days are safe", 3, DailyStories.of(-5L).size)
    }

    @Test fun dhikrPresetsAreClean() {
        assertEquals(Dhikr.PRESETS.size, Dhikr.PRESETS.map { it.id }.distinct().size)
        Dhikr.PRESETS.forEach { p ->
            assertArabic(p.id, p.arabic.replace("·", " "))
            assertCyrillic(p.id, p.translit)
            assertTrue(p.target > 0)
        }
        assertEquals(Dhikr.SALAWAT, Dhikr.preset(Dhikr.SALAWAT).id)
        assertEquals("unknown id falls back", Dhikr.PRESETS.first(), Dhikr.preset("nope"))
    }

    @Test fun codecsAreLenient() {
        val m = mapOf("a" to 3L, "b" to 100L)
        assertEquals(m, DailyCodec.decodeCounts(DailyCodec.encodeCounts(m)))
        assertEquals(mapOf("a" to 3L), DailyCodec.decodeCounts("a=3,=5,b=x,c=-1,junk"))
        val sessions = linkedMapOf("M:2026-10-30" to mapOf("kursi" to 1L), "E:2026-10-30" to mapOf("nas" to 3L))
        assertEquals(sessions, DailyCodec.decodeSessions(DailyCodec.encodeSessions(sessions)))
        val many = (1..9).associate { "M:2026-10-0$it" to mapOf("x" to it.toLong()) }
        assertEquals("keeps the newest sessions only", 4, DailyCodec.decodeSessions(DailyCodec.encodeSessions(many)).size)
    }

    @Test fun dailyPagesStayInsideTheLayer() {
        val nav = NurNavigator()
        nav.go(ROUTE_TODAY)
        listOf(ROUTE_AZKAR, ROUTE_DHIKR, ROUTE_STORY).forEach { r ->
            nav.go(r)
            assertTrue("$r keeps the layer up", nav.layerOpen)
            assertTrue(nav.back())
            assertEquals(ROUTE_TODAY, nav.current)
        }
    }
}
