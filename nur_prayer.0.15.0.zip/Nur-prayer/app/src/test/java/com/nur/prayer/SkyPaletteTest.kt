package com.nur.prayer

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.ui.theme.AllPalettes
import com.nur.prayer.ui.theme.Amber
import com.nur.prayer.ui.theme.Glass
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.NextGreen
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.paletteFor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * The 0.6.0 sky is colour, so the promises worth asserting are about legibility: whatever the
 * prayer window, text on the glass card, on the sheet and on the green plate stays readable.
 */
class SkyPaletteTest {
    @Test fun everyPrayerHasItsOwnSky() {
        assertEquals(Prayer.entries.size, AllPalettes.size)
        Prayer.entries.forEachIndexed { i, prayer -> assertEquals(AllPalettes[i], paletteFor(prayer)) }
        assertEquals(AllPalettes.size, AllPalettes.map { it.sheet }.distinct().size)
        assertEquals(Color.Black, Ink)
    }

    @Test fun onlyNightSkiesCarryStars() {
        listOf(Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR).forEach {
            assertEquals(0f, paletteFor(it).starIntensity, 0f)
        }
        listOf(Prayer.SAHAR, Prayer.ISHA).forEach { assertTrue(paletteFor(it).starIntensity > 0.5f) }
    }

    @Test fun glassCardTextIsReadableOverTheLightestSky() {
        AllPalettes.forEach { palette ->
            // The worst case is the card over the brightest stop of the gradient.
            listOf(palette.zenith, palette.mid, palette.horizon).forEach { sky ->
                val card = Glass.compositeOver(sky)
                assertTrue("Primary on card over ${palette.name}", contrast(TextPrimary, card) >= 7.0)
                assertTrue("Secondary on card over ${palette.name}", contrast(TextSecondary, card) >= 4.5)
                assertTrue("Tertiary on card over ${palette.name}", contrast(TextTertiary, card) >= 4.5)
            }
        }
    }

    @Test fun sheetsAndPlatesAreReadable() {
        AllPalettes.forEach { palette ->
            assertTrue("Sheet ${palette.name}", contrast(TextPrimary, palette.sheet) >= 7.0)
            assertTrue("Sheet secondary ${palette.name}", contrast(TextSecondary, palette.sheet) >= 4.5)
        }
        assertTrue(contrast(TextPrimary, NextGreen) >= 4.5)
        assertTrue(contrast(Ink, Amber) >= 7.0)
    }

    private fun contrast(a: Color, b: Color): Double {
        fun luminance(c: Color): Double {
            fun linear(value: Float): Double = if (value <= 0.04045f) value / 12.92 else ((value + 0.055) / 1.055).pow(2.4)
            return 0.2126 * linear(c.red) + 0.7152 * linear(c.green) + 0.0722 * linear(c.blue)
        }
        val x = luminance(a)
        val y = luminance(b)
        return (max(x, y) + 0.05) / (min(x, y) + 0.05)
    }
}
