package com.nur.prayer

import com.nur.prayer.ui.qibla.lockDialRotation
import com.nur.prayer.ui.qibla.nearestDialRotation
import com.nur.prayer.ui.qibla.normalize
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class DialRotationTest {
    @Test fun northCrossingIsTwoDegreesNotFullTurn() {
        assertEquals(-361f, nearestDialRotation(-359f, 1f), 0.001f)
        assertEquals(1f, nearestDialRotation(-1f, 359f), 0.001f)
    }
    @Test fun repeatedRevolutionsKeepShortPath() {
        var rotation = 0f
        for (heading in 0..10000) {
            val next = nearestDialRotation(rotation, (heading % 360).toFloat())
            assertTrue(abs(next - rotation) <= 1.01f)
            rotation = next
        }
    }

    /** 0.14.2: the auto-search lock keeps spinning the same way and ends exactly on −heading. */
    @Test fun lockContinuesTheSpinAndEndsOnTheHeading() {
        for (spin in listOf(0f, -17f, -200f, -359.5f, -720f)) {
            for (heading in listOf(0f, 0.4f, 90f, 197.3f, 359.9f)) {
                val r = lockDialRotation(spin, heading, 120f)
                assertTrue("never reverses", r <= spin)
                assertTrue("visible deceleration", spin - r >= 120f - 0.001f)
                assertTrue("at most one extra turn", spin - r < 480f)
                assertEquals(0f, abs(((normalize(-r) - normalize(heading)) + 540f) % 360f - 180f), 0.01f)
                // Tracking takes over without a jump.
                assertEquals(r, nearestDialRotation(r, heading), 0.01f)
            }
        }
    }
}
