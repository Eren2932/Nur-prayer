package com.nur.prayer

import com.nur.prayer.audio.VoiceText
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.daily.StorySlide
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The story viewer's touch rules and timing; the voice text helpers. */
class StoryMathTest {
    private val w = 1000f
    private val swipe = 150f
    private val close = 320f

    private fun g(held: Long, dx: Float = 0f, dy: Float = 0f, x: Float = 800f) =
        StoryMath.classify(held, dx, dy, x, w, swipe, close)

    @Test fun holdAndReleaseDoesNotSkip() {
        // The 0.10.0 bug: a long press on the right half used to fire "next" on release.
        assertEquals(StoryMath.Gesture.NONE, g(held = 900))
        assertEquals(StoryMath.Gesture.NONE, g(held = 900, x = 100f))
        assertEquals(StoryMath.Gesture.NONE, g(held = StoryMath.TAP_MAX_MILLIS + 1))
    }

    @Test fun shortTapNavigates() {
        assertEquals(StoryMath.Gesture.NEXT, g(held = 80, x = 800f))
        assertEquals(StoryMath.Gesture.PREV, g(held = 80, x = 100f))
        assertEquals(StoryMath.Gesture.NEXT, g(held = StoryMath.TAP_MAX_MILLIS, x = 500f))
    }

    @Test fun swipesAndPull() {
        assertEquals(StoryMath.Gesture.NEXT, g(held = 300, dx = -400f))
        assertEquals(StoryMath.Gesture.PREV, g(held = 300, dx = 400f))
        assertEquals(StoryMath.Gesture.CLOSE, g(held = 300, dy = 500f))
        // A small pull that springs back is neither a close nor a tap.
        assertEquals(StoryMath.Gesture.NONE, g(held = 300, dy = 200f))
        // A jittery tap that travelled a bit is no longer a tap.
        assertEquals(StoryMath.Gesture.NONE, g(held = 80, dx = 100f))
    }

    @Test fun durationGrowsWithTextAndIsBounded() {
        val short = StorySlide("Аят", null, null, "Коротко", "—")
        val long = StorySlide("Хадис", "ب".repeat(300), "т".repeat(300), "р".repeat(400), "—")
        assertEquals(StoryMath.MIN_MILLIS, StoryMath.durationMillis(short))
        assertEquals(StoryMath.MAX_MILLIS, StoryMath.durationMillis(long))
    }

    @Test fun seenMask() {
        var m = 0
        assertEquals(0, StoryMath.firstUnseen(m, 4))
        m = StoryMath.withSeen(m, 0)
        m = StoryMath.withSeen(m, 2)
        assertTrue(StoryMath.isSeen(m, 2))
        assertFalse(StoryMath.isSeen(m, 1))
        assertEquals(1, StoryMath.firstUnseen(m, 4))
        m = StoryMath.withSeen(StoryMath.withSeen(m, 1), 3)
        assertTrue(StoryMath.allSeen(m, 4))
        assertEquals(0, StoryMath.firstUnseen(m, 4))
        // A pre-0.11 record ("seen today", no mask) reads as all seen.
        assertTrue(StoryMath.allSeen(0x7fffffff, 4))
    }

    @Test fun voiceKeysAndClips() {
        assertEquals("كِتَاب جَمِيل", VoiceText.key("  كِتَاب   جَمِيل "))
        val clips = VoiceText.parseClips("# comment\nبَ\tba.ogg\n\nبِ\tbi.ogg\n")
        assertEquals("ba.ogg", clips["بَ"])
        assertEquals(2, clips.size)
        assertTrue(VoiceText.rate(true) < VoiceText.rate(false))
    }
}
