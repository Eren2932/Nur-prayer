package com.nur.prayer

import com.nur.prayer.ui.components.RevealMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The numbers behind the home transitions: where a release lands, how long a settle takes, how faces overlap. */
class RevealMathTest {
    @Test fun aSlowReleaseDecidesByDistance() {
        assertTrue(RevealMath.opens(progress = 0.14f, velocity = 0f, openAt = RevealMath.PULL_OPEN_AT))
        assertFalse(RevealMath.opens(progress = 0.13f, velocity = 0f, openAt = RevealMath.PULL_OPEN_AT))
        assertTrue(RevealMath.opens(progress = 0.88f, velocity = 0f, openAt = RevealMath.SHEET_KEEP_AT))
        assertFalse(RevealMath.opens(progress = 0.87f, velocity = 0f, openAt = RevealMath.SHEET_KEEP_AT))
    }

    @Test fun aFlingDecidesRegardlessOfDistance() {
        assertTrue(RevealMath.opens(0.01f, RevealMath.FLING, RevealMath.PULL_OPEN_AT))
        assertFalse(RevealMath.opens(0.99f, -RevealMath.FLING, RevealMath.SHEET_KEEP_AT))
        // Just under the fling speed distance still decides.
        assertFalse(RevealMath.opens(0.05f, RevealMath.FLING - 0.01f, RevealMath.PULL_OPEN_AT))
    }

    @Test fun settleTimeShrinksWithTheDistanceLeftButNeverVanishes() {
        assertEquals(RevealMath.OPEN_MILLIS, RevealMath.openMillis(0f))
        assertEquals(RevealMath.MIN_MILLIS, RevealMath.openMillis(0.99f))
        assertEquals(RevealMath.CLOSE_MILLIS, RevealMath.closeMillis(1f))
        assertEquals(RevealMath.MIN_MILLIS, RevealMath.closeMillis(0.01f))
        var previous = Int.MAX_VALUE
        for (i in 0..20) {
            val ms = RevealMath.openMillis(i / 20f)
            assertTrue(ms in RevealMath.MIN_MILLIS..RevealMath.OPEN_MILLIS)
            assertTrue("open time must not grow as the layer gets closer", ms <= previous)
            previous = ms
        }
    }

    @Test fun faceEndpointsAreExactAndTheFacesOverlapInBetween() {
        assertEquals(1f, RevealMath.listAlpha(0f), 0f)
        assertEquals(0f, RevealMath.clockAlpha(0f), 0f)
        assertEquals(0f, RevealMath.listAlpha(1f), 0f)
        assertEquals(1f, RevealMath.clockAlpha(1f), 0f)
        assertEquals(1f, RevealMath.listScale(0f), 0f)
        assertEquals(1f, RevealMath.clockScale(1f), 0f)
        assertEquals(0f, RevealMath.listLiftDp(0f), 0f)
        assertEquals(0f, RevealMath.clockLiftDp(1f), 0f)
        for (i in 0..100) {
            val t = i / 100f
            // The card never thins out to an empty sky while the faces swap.
            assertTrue("t=$t", RevealMath.listAlpha(t) + RevealMath.clockAlpha(t) >= 0.6f)
            assertTrue(RevealMath.listAlpha(t) in 0f..1f && RevealMath.clockAlpha(t) in 0f..1f)
        }
    }

    @Test fun facesMoveTheSameWayTheyCameFromSoTheSwapHasNoJump() {
        // The list leaves upwards by exactly what the clock arrives from, scale likewise.
        assertEquals(-RevealMath.listLiftDp(1f), RevealMath.clockLiftDp(0f), 0f)
        assertEquals(RevealMath.listScale(1f), RevealMath.clockScale(0f), 1e-6f)
    }

    @Test fun calendarLayerAndHomeCrossFadeWithoutBothBeingOpaque() {
        assertEquals(1f, RevealMath.homeAlpha(0f), 0f)
        assertEquals(0f, RevealMath.calendarAlpha(0f), 0f)
        assertEquals(0f, RevealMath.homeAlpha(1f), 0f)
        assertEquals(1f, RevealMath.calendarAlpha(1f), 0f)
        for (i in 0..100) {
            val p = i / 100f
            assertTrue("p=$p", RevealMath.homeAlpha(p) + RevealMath.calendarAlpha(p) <= 1.35f)
            assertTrue("p=$p", RevealMath.homeAlpha(p) + RevealMath.calendarAlpha(p) >= 0.5f)
        }
    }

    @Test fun pullNeedsRoughlySeventyFiveDpOfFingerTravelOnATypicalScreen() {
        val screenDp = 800f
        val fingerDp = RevealMath.PULL_OPEN_AT * screenDp / RevealMath.PULL_GAIN
        assertTrue("$fingerDp dp", fingerDp in 60f..90f)
        // And the sheet is released from about 96 dp of drag.
        val sheetDp = (1f - RevealMath.SHEET_KEEP_AT) * screenDp
        assertTrue("$sheetDp dp", sheetDp in 80f..110f)
    }
}
