#!/usr/bin/env python3
"""0.15.0 launcher icons: the manifest aliases, AppIcon and the resources must agree.

Catches the mistakes that compile fine and break on phones:
  * an alias renamed/removed (users get a second icon or lose it after the update);
  * more than one alias enabled in the manifest (two icons on a fresh install);
  * the enabled alias is not AppIcon.DEFAULT (store icon != installed icon);
  * an AppIcon without its adaptive XML, foreground, background colour or monochrome layer.
"""
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / 'app/src/main'
ANDROID = '{http://schemas.android.com/apk/res/android}'
# Frozen forever: Android keeps enabled state per component name. Only append to this list.
FROZEN = ['Nur', 'Pearl', 'Fajr', 'Emerald', 'Gold', 'Midnight', 'Lagoon', 'Maghrib', 'Garnet',
          'Aurora', 'Sand', 'Graphite']
DENSITIES = ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']


def main():
    import xml.etree.ElementTree as ET
    errors = []
    app = ET.parse(MAIN / 'AndroidManifest.xml').getroot().find('application')
    aliases = []
    for a in app.findall('activity-alias'):
        name = a.get(ANDROID + 'name')
        if not name.startswith('.launcher.'):
            continue
        aliases.append((name[len('.launcher.'):], a.get(ANDROID + 'enabled'), a.get(ANDROID + 'icon'),
                        a.get(ANDROID + 'targetActivity')))
    for act in app.findall('activity'):
        for f in act.findall('intent-filter'):
            if any(c.get(ANDROID + 'name') == 'android.intent.category.LAUNCHER' for c in f.findall('category')):
                errors.append(f'{act.get(ANDROID + "name")} has its own LAUNCHER filter: two icons on the home screen')

    kt = (MAIN / 'java/com/nur/prayer/icon/AppIcon.kt').read_text(encoding='utf-8')
    enum = re.findall(r'^\s*([A-Z_]+)\("([a-z_]+)",\s*"([A-Za-z]+)",\s*R\.mipmap\.(\w+)\)', kt, re.M)
    default = re.search(r'val DEFAULT = ([A-Z_]+)', kt).group(1)

    names = [a[0] for a in aliases]
    missing = [n for n in FROZEN if n not in names]
    if missing:
        errors.append(f'aliases removed or renamed (never do this): {missing}')
    if names[:len(FROZEN)] != [n for n in FROZEN if n in names]:
        errors.append('frozen aliases changed order; append new ones at the end')
    if [e[2] for e in enum] != names:
        errors.append(f'AppIcon order/aliases {[e[2] for e in enum]} != manifest {names}')
    enabled = [a[0] for a in aliases if a[1] == 'true']
    if len(enabled) != 1:
        errors.append(f'exactly one alias must be enabled in the manifest, got {enabled}')
    elif enabled[0] != next((e[2] for e in enum if e[0] == default), None):
        errors.append(f'manifest enables {enabled[0]} but AppIcon.DEFAULT is {default}')
    for name, _, icon, target in aliases:
        if target != '.MainActivity':
            errors.append(f'alias {name} targets {target}')
        res = next((e[3] for e in enum if e[2] == name), None)
        if icon != f'@mipmap/{res}':
            errors.append(f'alias {name} icon {icon} != AppIcon resource {res}')

    colors = (MAIN / 'res/values/launcher_icons.xml').read_text(encoding='utf-8')
    for _, iid, _, res in enum:
        xml = MAIN / f'res/mipmap-anydpi-v26/{res}.xml'
        if not xml.exists():
            errors.append(f'missing {xml.relative_to(ROOT)}'); continue
        body = xml.read_text(encoding='utf-8')
        for layer in re.findall(r'@(color|mipmap)/(\w+)', body):
            kind, ref = layer
            if kind == 'color' and f'name="{ref}"' not in colors:
                errors.append(f'{res}: colour {ref} not defined')
            if kind == 'mipmap':
                for d in DENSITIES:
                    if not (MAIN / f'res/mipmap-{d}/{ref}.webp').exists():
                        errors.append(f'{res}: missing mipmap-{d}/{ref}.webp')
        if '<monochrome' not in body:
            errors.append(f'{res}: no monochrome layer (themed icons on Android 13+)')
    for f in ('ic_launcher.xml', 'ic_launcher_round.xml'):
        if not (MAIN / 'res/mipmap-anydpi-v26' / f).exists():
            errors.append(f'missing mipmap-anydpi-v26/{f} (application icon)')

    for e in errors:
        print('launcher_icons:', e)
    if not errors:
        print(f'launcher_icons: OK, {len(enum)} icons, default {default}')
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
