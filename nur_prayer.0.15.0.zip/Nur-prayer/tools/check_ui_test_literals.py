#!/usr/bin/env python3
"""Preflight: every text, description and tag an Android UI test looks for must exist in the app.

0.6.0 redesigned every screen but three UI tests still asserted the old strings; that only fails
on an emulator, after a full build. This reads each literal passed to onNodeWithText,
onNodeWithTag, onNodeWithContentDescription and friends (and `described("…")`) and requires it to
be (a) in the main sources, (b) the static start of a template there ("city-row-${id}"), or
(c) text the test itself puts on screen. Literals asserted with assertDoesNotExist() are skipped:
they are meant to be absent. Source preflight only: it cannot tell whether a node is on screen at
that moment.
"""
from pathlib import Path
import re

FINDER = (r'(?:onNodeWithText|onAllNodesWithText|onNodeWithTag|onAllNodesWithTag|'
          r'onNodeWithContentDescription|onAllNodesWithContentDescription|hasTestTag|described)')
CALL = re.compile(r'\b' + FINDER + r'\s*\(\s*"((?:[^"\\]|\\.)*)"')
TEMPLATE = re.compile(r'\$\{[^}]*\}|\$\w+')
APP_TEMPLATE_HEAD = re.compile(r'"([^"$\\\n]{3,})(?:\$|\{\d+\})')
# Month captions such as "октябрь 2026" come from a locale formatter, not from a literal.
FORMATTED = re.compile(r'^[а-яё]+ \d{4}$')


def checked_literals(source):
    """Yield (line, static head) for literals that are expected to be present."""
    for match in CALL.finditer(source):
        tail = source[match.end():match.end() + 200]
        statement = tail.split('\n')[0]
        if 'assertDoesNotExist' in statement or 'assertCountEquals(0)' in statement:
            continue
        head = TEMPLATE.split(match[1])[0].strip()
        if len(head) >= 2:
            yield source.count('\n', 0, match.start()) + 1, head, match[1]


def main():
    root = Path(__file__).resolve().parents[1]
    app = ''.join(p.read_text() for p in sorted((root / 'app/src/main').rglob('*.kt')))
    heads = set(APP_TEMPLATE_HEAD.findall(app))
    failures, checked = [], 0
    for path in sorted((root / 'app/src/androidTest').rglob('*.kt')):
        source = path.read_text()
        for line, head, full in checked_literals(source):
            checked += 1
            local = source.count(f'"{head}') > len(re.findall(r'"' + re.escape(head), ''.join(
                m.group(0) for m in CALL.finditer(source))))
            if (head in app or local or FORMATTED.match(full)
                    or any(full.startswith(h) for h in heads)):
                continue
            failures.append(f'{path.relative_to(root)}:{line}: "{full}" is not found in app/src/main')
    if failures:
        raise SystemExit('\n'.join(failures))
    print(f'PASS: {checked} UI-test literals found in the app sources (source preflight only).')


if __name__ == '__main__':
    main()
