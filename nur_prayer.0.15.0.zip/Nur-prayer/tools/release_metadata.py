"""Validate literal release metadata without pinning the audit to a release.

This is a source preflight for this project's literal Gradle declarations and
Russian UI labels, not a Gradle/Kotlin parser or a substitute for compilation.
"""
import re

VERSION = r"(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)"


def without_comments(source):
    # Preserve strings (including // in text); ignore commented-out declarations.
    token = r'"""[\s\S]*?"""|"(?:\\.|[^"\\])*"|//[^\n]*|/\*[\s\S]*?\*/'
    return re.sub(token, lambda m: re.sub(r"[^\n]", " ", m[0])
                  if m[0].startswith(("//", "/*")) else m[0], source)


def validate_release_metadata(gradle_source, settings_source):
    gradle = without_comments(gradle_source)
    names = re.findall(r'^\s*versionName\s*=\s*"([^"\n]*)"\s*;?\s*$', gradle, re.M)
    if len(names) != 1 or not re.fullmatch(VERSION, names[0]):
        raise AssertionError('Version: expected exactly one literal numeric X.Y.Z versionName')
    codes = re.findall(r'^\s*versionCode\s*=\s*([0-9]+)\s*;?\s*$', gradle, re.M)
    if len(codes) != 1 or not 1 <= int(codes[0]) <= 2100000000:
        raise AssertionError('Version: expected one positive Android versionCode <= 2100000000')
    # Check every label, not merely whether the expected number occurs somewhere.
    settings = without_comments(settings_source)
    labels = re.findall(r'Нур\s+([0-9][0-9A-Za-z.+-]*)', settings)
    # 0.13.0: the localized screen keeps the version in one constant and formats it into
    # tr("Нур {0}", APP_VERSION); the constant then counts as both labels.
    constant = re.findall(r'\bAPP_VERSION\s*=\s*"([^"\n]*)"', settings)
    if len(constant) == 1 and re.search(r'"Нур \{0\}"\s*,\s*APP_VERSION\b', settings):
        labels = labels + constant * (2 - len(labels)) if len(labels) < 2 else labels
    if len(labels) != 2:
        raise AssertionError('Settings version: expected both About and footer release labels')
    if any(label != names[0] for label in labels):
        raise AssertionError(f'Settings version mismatch: Gradle={names[0]}, UI={labels}')
    return names[0]
