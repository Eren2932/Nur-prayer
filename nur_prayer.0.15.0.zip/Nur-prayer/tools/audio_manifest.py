#!/usr/bin/env python3
"""What the app may say aloud, and whether assets/audio/clips.tsv matches it.

A recorded clip is found by exact text: `VoiceText.key` trims and collapses spaces, nothing else.
A clip typed with marks in another order (fatha+shadda instead of shadda+fatha), with a
different alif, or for a word the app never voices is silently never played. This tool closes
that gap:

  python3 tools/audio_manifest.py           check (CI, package_source.py)
  python3 tools/audio_manifest.py --write   regenerate docs/audio/recording_list.tsv

The list mirrors the speakers in the code (LessonScreen, DictionaryScreen, story of the day):
  - letters: sound (open syllable with fatha; alif says its name) and name;
  - rule cards with `voiced` samples: vowels, sukun, long vowels, shadda, tanween, joining, article;
  - every word of assets/learn/words.tsv that the machine voice may read (no Quran topics).
VoiceManifestTest recomputes the same set from the Kotlin course and fails CI if they drift.
"""
from __future__ import annotations

import re
import sys
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARABIC_KT = ROOT / 'app/src/main/java/com/nur/prayer/learn/Arabic.kt'
EXERCISES_KT = ROOT / 'app/src/main/java/com/nur/prayer/learn/Exercises.kt'
WORDS = ROOT / 'app/src/main/assets/learn/words.tsv'
AUDIO = ROOT / 'app/src/main/assets/audio'
CLIPS = AUDIO / 'clips.tsv'
LIST = ROOT / 'docs/audio/recording_list.tsv'

FATHA, KASRA, DAMMA, SUKUN = '\u064E', '\u0650', '\u064F', '\u0652'
FATHATAN, KASRATAN, DAMMATAN = '\u064B', '\u064D', '\u064C'
MARKS = set('\u064B\u064C\u064D\u064E\u064F\u0650\u0651\u0652\u0670')
# Same as VoiceText.SAFE_FILE. .wav is accepted by the app but refused here: ~10x the APK size.
SAFE_FILE = re.compile(r'[A-Za-z0-9_\-]+\.(ogg|mp3|m4a|wav)')
SHIP_EXT = ('.ogg', '.mp3', '.m4a')
JAVA_SPACE = re.compile(r'[ \t\n\x0b\f\r]+')  # Kotlin Regex("\\s+") is ASCII-only


def key(text: str) -> str:
    """VoiceText.key."""
    return ' '.join(p for p in JAVA_SPACE.split(text.strip()) if p)


def letters():
    """(char, conventional name, Arabic name) in course order, read from Arabic.LETTERS."""
    out = re.findall(r'Letter\("([^"]+)",\s*"[^"]*",\s*"([^"]+)",\s*"([^"]+)"', ARABIC_KT.read_text())
    if len(out) != 28:
        raise SystemExit(f'Arabic.kt: expected 28 letters, parsed {len(out)}')
    return out


def syllable(ch: str, mark: str) -> str:
    """Arabic.syllable."""
    base = ('إ' if mark in (KASRA, KASRATAN) else 'أ') if ch == 'ا' else ch
    return base + mark + ('ا' if mark == FATHATAN and ch != 'ا' else '')


def long_syllable(ch: str, mark: str) -> str:
    """Arabic.longSyllable (Arabic part)."""
    carrier = {FATHA: 'ا', KASRA: 'ي'}.get(mark, 'و')
    base = ('إ' if mark == KASRA else 'أ') if ch == 'ا' else ch
    return base + mark + carrier


def rule_samples():
    """The `voiced` Info cards of ExerciseFactory, in lesson order, as (arabic, reading)."""
    src = EXERCISES_KT.read_text()
    literal = dict(re.findall(r'"([\u0600-\u06FF]+)" to "([^"]+)"', src))
    for needed in ('دَرَس', 'كَتَبَ', 'رَبّ', 'سُكَّر', 'جَدَّة', 'الشَّمْس', 'الْقَمَر'):
        if needed not in literal:
            raise SystemExit(f'Exercises.kt: rule sample {needed} not found; update audio_manifest.py')
    b = 'ب'
    out = [('دَرَس', literal['دَرَس']), ('كَتَبَ', literal['كَتَبَ'])]
    out += [(syllable(b, v), r) for v, r in ((FATHA, 'ба'), (KASRA, 'би'), (DAMMA, 'бу'))]
    out += [(syllable(b, FATHA) + 'ل' + SUKUN, 'бал'), (syllable('م', DAMMA) + 'ن' + SUKUN, 'мун')]
    out += [(long_syllable(b, v), r) for v, r in ((FATHA, 'баа'), (KASRA, 'бии'), (DAMMA, 'буу'))]
    out += [(a, literal[a]) for a in ('رَبّ', 'سُكَّر', 'جَدَّة')]
    out += [(syllable(b, t), r) for t, r in ((FATHATAN, 'бан'), (KASRATAN, 'бин'), (DAMMATAN, 'бун'))]
    out += [(a, literal[a]) for a in ('الشَّمْس', 'الْقَمَر')]
    return out


def words():
    rows = []
    for i, line in enumerate(WORDS.read_text(encoding='utf-8').splitlines()):
        if i == 0 or not line.strip():
            continue
        wid, topic, arabic, translit, ru = line.split('\t')
        if topic == 'fatiha' or topic.startswith('quran'):
            continue  # Word.machineVoiceAllowed
        rows.append((wid, topic, arabic, translit, ru))
    return rows


def manifest():
    """[(key, file, group, hint)], one row per distinct key; the first use names the file."""
    out, seen = [], set()

    def add(text, file, group, hint):
        k = key(text)
        if k and k not in seen:
            seen.add(k)
            out.append((k, file, group, hint))

    for n, (ch, name, name_ar) in enumerate(letters(), 1):
        slug = f'letter_{n:02d}'
        if ch == 'ا':
            add(name_ar, f'{slug}_name.ogg', 'letter', f'{name}: название (звука у алифа нет)')
        else:
            add(syllable(ch, FATHA), f'{slug}_sound.ogg', 'letter', f'{name}: звук, слог с фатхой')
            add(name_ar, f'{slug}_name.ogg', 'letter', f'{name}: название буквы')
    for n, (ar, reading) in enumerate(rule_samples(), 1):
        add(ar, f'rule_{n:02d}.ogg', 'rule', reading)
    for wid, topic, ar, translit, ru in words():
        add(ar, f'word_{wid}.ogg', f'word:{topic}', f'{translit} — {ru}')
    return out


HEADER = (
    '# Что записать для озвучки. Сгенерировано tools/audio_manifest.py --write, руками не править.\n'
    '# Колонки: арабский текст (ровно как в курсе) TAB имя файла TAB группа TAB чтение и перевод.\n'
    '# Готовую запись положите в app/src/main/assets/audio/ и перенесите первые две колонки\n'
    '# строки в app/src/main/assets/audio/clips.tsv. Формат: .ogg (Opus/Vorbis) или .mp3, моно,\n'
    '# 0.2 с тишины по краям, громкость выровнена. Кнопка «медленно» замедляет запись сама (0.7x).\n'
)


def render(rows) -> str:
    return HEADER + ''.join(f'{k}\t{f}\t{g}\t{h}\n' for k, f, g, h in rows)


def skeleton(text: str) -> str:
    """Letters only, alif variants folded: two texts with the same skeleton are the same word."""
    t = unicodedata.normalize('NFD', text)
    t = ''.join(c for c in t if c not in MARKS and not unicodedata.combining(c))
    return t.translate(str.maketrans('أإآٱ', 'اااا')).replace(' ', '')


def check() -> list[str]:
    rows = manifest()
    errors = []
    if not LIST.exists() or LIST.read_text(encoding='utf-8') != render(rows):
        errors.append(f'{LIST.relative_to(ROOT)} is stale: run python3 tools/audio_manifest.py --write')
    known = {k for k, *_ in rows}
    by_skeleton = {}
    for k in known:
        by_skeleton.setdefault(skeleton(k), []).append(k)
    used, keys = set(), {}
    for n, raw in enumerate(CLIPS.read_text(encoding='utf-8').splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        where = f'clips.tsv:{n}'
        tab = line.find('\t')
        if tab <= 0:
            errors.append(f'{where}: no TAB between text and file (the app skips this line)')
            continue
        text, file = key(line[:tab]), line[tab + 1:].strip()
        if not SAFE_FILE.fullmatch(file):
            errors.append(f'{where}: file name {file!r} is refused by the app (letters, digits, _ and - only)')
            continue
        if not file.endswith(SHIP_EXT):
            errors.append(f'{where}: {file}: use .ogg or .mp3, not .wav')
        if not (AUDIO / file).is_file():
            errors.append(f'{where}: {file} is not in app/src/main/assets/audio/')
        used.add(file)
        if text in keys:
            errors.append(f'{where}: {text} already listed on line {keys[text]}; the later line wins in the app')
        keys[text] = n
        if text not in known:
            near = by_skeleton.get(skeleton(text), [])
            hint = f' — did you mean {" / ".join(near)}? (marks differ)' if near else ''
            errors.append(f'{where}: {text} is never voiced by the app, the clip would never play{hint}')
    for f in sorted(AUDIO.iterdir()):
        if f.name != 'clips.tsv' and f.name not in used:
            errors.append(f'assets/audio/{f.name}: not listed in clips.tsv (dead weight in the APK)')
    return errors


def main():
    if '--write' in sys.argv[1:]:
        LIST.parent.mkdir(parents=True, exist_ok=True)
        rows = manifest()
        LIST.write_text(render(rows), encoding='utf-8')
        groups = {}
        for _, _, g, _ in rows:
            groups[g.split(':')[0]] = groups.get(g.split(':')[0], 0) + 1
        print(f'wrote {LIST.relative_to(ROOT)}: {len(rows)} clips ' + str(groups))
        return
    errors = check()
    if errors:
        print('\n'.join(errors))
        raise SystemExit(f'audio_manifest: {len(errors)} problem(s)')
    recorded = sum(1 for l in CLIPS.read_text(encoding='utf-8').splitlines() if l.strip() and not l.startswith('#'))
    print(f'audio_manifest: OK, {len(manifest())} voiced texts, {recorded} recorded')


if __name__ == '__main__':
    main()
