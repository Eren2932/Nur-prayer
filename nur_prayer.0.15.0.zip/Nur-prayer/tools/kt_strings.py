#!/usr/bin/env python3
"""Minimal Kotlin string-literal scanner shared by the i18n tools.

Understands nested block comments, char literals, raw strings and `${}` templates that contain
strings of their own. Not a Kotlin parser: it only has to find literals and their parts exactly.
"""
import re

CYR = re.compile(r"[А-Яа-яЁё]")


class Lit:
    __slots__ = ("start", "end", "parts", "raw")

    def __init__(self, start, end, parts, raw):
        self.start, self.end, self.parts, self.raw = start, end, parts, raw

    @property
    def templated(self):
        return any(k != "t" for k, _ in self.parts)

    def text_raw(self):
        return "".join(v for k, v in self.parts if k == "t")

    def has_cyrillic(self):
        return bool(CYR.search(self.text_raw()))


def _skip_code(s, i, stop_at_brace, out):
    """Scan code from i; collect top-level literals into out; return index after closing brace."""
    depth = 0
    n = len(s)
    while i < n:
        c = s[i]
        if s.startswith("//", i):
            j = s.find("\n", i)
            i = n if j < 0 else j
            continue
        if s.startswith("/*", i):
            d, i = 1, i + 2
            while i < n and d:
                if s.startswith("/*", i): d, i = d + 1, i + 2
                elif s.startswith("*/", i): d, i = d - 1, i + 2
                else: i += 1
            continue
        if c == "'":
            m = re.match(r"'(\\u[0-9a-fA-F]{4}|\\.|[^'\\])'", s[i:])
            i += len(m.group(0)) if m else 1
            continue
        if s.startswith('"""', i):
            j = s.find('"""', i + 3)
            j = n if j < 0 else j + 3
            while j < n and s[j] == '"': j += 1
            out.append(Lit(i, j, [("t", s[i + 3:j - 3])], True))
            i = j
            continue
        if c == '"':
            i = _string(s, i, out)
            continue
        if stop_at_brace:
            if c == "{": depth += 1
            elif c == "}":
                if depth == 0: return i + 1
                depth -= 1
        i += 1
    return i


def _string(s, i, out):
    start = i
    i += 1
    parts, buf = [], []
    n = len(s)
    while i < n:
        c = s[i]
        if c == "\\":
            buf.append(s[i:i + 2]); i += 2; continue
        if c == '"':
            i += 1; break
        if c == "$" and i + 1 < n and s[i + 1] == "{":
            if buf: parts.append(("t", "".join(buf))); buf = []
            inner = []
            j = _skip_code(s, i + 2, True, inner)
            parts.append(("e", s[i + 2:j - 1]))
            i = j
            continue
        if c == "$" and i + 1 < n and (s[i + 1].isalpha() or s[i + 1] == "_"):
            m = re.match(r"[A-Za-z_][A-Za-z0-9_]*", s[i + 1:])
            if buf: parts.append(("t", "".join(buf))); buf = []
            parts.append(("r", m.group(0)))
            i += 1 + len(m.group(0))
            continue
        buf.append(c); i += 1
    if buf: parts.append(("t", "".join(buf)))
    out.append(Lit(start, i, parts, False))
    return i


def literals(source):
    out = []
    _skip_code(source, 0, False, out)
    return out


def unescape(raw):
    """Kotlin escape semantics -> the runtime string."""
    out, i = [], 0
    while i < len(raw):
        c = raw[i]
        if c == "\\" and i + 1 < len(raw):
            e = raw[i + 1]
            if e == "u":
                out.append(chr(int(raw[i + 2:i + 6], 16))); i += 6; continue
            out.append({"t": "\t", "b": "\b", "n": "\n", "r": "\r", "'": "'", '"': '"', "\\": "\\", "$": "$"}.get(e, e))
            i += 2; continue
        out.append(c); i += 1
    return "".join(out)


def java_hash(text):
    h = 0
    data = text.encode("utf-16-le")
    for k in range(0, len(data), 2):
        h = (31 * h + (data[k] | data[k + 1] << 8)) & 0xFFFFFFFF
    return "%08x" % h


def chains(source, lits):
    """Group literals joined only by `+` and whitespace into concatenation chains."""
    groups, cur = [], []
    for lit in lits:
        if lit.raw:
            if cur: groups.append(cur); cur = []
            groups.append([lit]); continue
        if cur and re.fullmatch(r"\s*\+\s*", source[cur[-1].end:lit.start]):
            cur.append(lit)
        else:
            if cur: groups.append(cur)
            cur = [lit]
    if cur: groups.append(cur)
    return groups


def template_of(chain):
    """Join a chain into one pattern: text kept raw, every expression replaced by {n}."""
    text, args = [], []
    for lit in chain:
        for k, v in lit.parts:
            if k == "t": text.append(v)
            else:
                text.append("{%d}" % len(args)); args.append(v)
    return "".join(text), args
