#!/usr/bin/env python3
"""Checks the bundled Arabic course data. Run from anywhere: python3 tools/verify_learn.py

  * every transliteration in words.tsv and quran_short.tsv equals the one learn_data derives from
    the vowelled Arabic (a typo in a vowel mark changes the reading, so it fails here);
  * ids are unique, topics are exactly the ones Lexicon.kt declares, no topic repeats a spelling;
  * the alphabet in Arabic.kt and in learn_data agree letter by letter (char, sound, joining, sun);
  * each letter is seen in enough words for the exercises that hunt for it;
  * the short surahs have the canonical number of ayat, numbered without gaps.

Write mode (--write) regenerates the translit columns after an intentional rule change.
"""
from __future__ import annotations
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from learn_data import LETTERS, DataError, letters_of, transliterate  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app/src/main/assets/learn"
SRC = ROOT / "app/src/main/java/com/nur/prayer/learn"
AYAT = {1: 7, 108: 3, 112: 4, 113: 5, 114: 6}
MIN_WORDS_PER_LETTER = 3


def read_tsv(path: Path, columns: list[str]):
    lines = path.read_text(encoding="utf-8").splitlines()
    assert lines and lines[0].split("\t") == columns, f"{path.name}: header must be {columns}"
    rows = []
    for number, line in enumerate(lines[1:], start=2):
        cells = line.split("\t")
        assert len(cells) == len(columns), f"{path.name}:{number}: {len(cells)} cells"
        assert all(c.strip() == c and c for c in cells), f"{path.name}:{number}: empty or padded cell"
        rows.append(dict(zip(columns, cells), line=number))
    return lines[0], rows


def check(write: bool = False) -> list[str]:
    problems: list[str] = []
    word_cols = ["id", "topic", "arabic", "translit", "ru"]
    header, words = read_tsv(ASSETS / "words.tsv", word_cols)
    lexicon_kt = (SRC / "Lexicon.kt").read_text(encoding="utf-8")
    topics = re.findall(r'Topic\("([a-z]+)",', lexicon_kt)
    assert topics, "Lexicon.kt declares no Topic(...)"
    ids = Counter(w["id"] for w in words)
    problems += [f"duplicate id {i}" for i, c in ids.items() if c > 1]
    spelled = defaultdict(set)
    regenerated = []
    for w in words:
        where = f"words.tsv:{w['line']} {w['arabic']}"
        if w["topic"] not in topics:
            problems.append(f"{where}: topic {w['topic']} is not declared in Lexicon.kt")
        if w["arabic"] in spelled[w["topic"]]:
            problems.append(f"{where}: repeated in {w['topic']}")
        spelled[w["topic"]].add(w["arabic"])
        try:
            expected = transliterate(w["arabic"])
        except DataError as error:
            problems.append(f"{where}: {error}")
            continue
        if expected != w["translit"]:
            problems.append(f"{where}: translit {w['translit']!r}, rules give {expected!r}")
        regenerated.append("\t".join([w["id"], w["topic"], w["arabic"], expected, w["ru"]]))
    unused = [t for t in topics if t not in spelled]
    problems += [f"topic {t} has no words" for t in unused]

    # Alphabet: Kotlin and Python must describe the same 28 letters.
    arabic_kt = (SRC / "Arabic.kt").read_text(encoding="utf-8")
    declared = re.findall(r'Letter\("(.)", "([^"]+)", "[^"]+", "[^"]+", joinsNext = (true|false), sun = (true|false)', arabic_kt)
    expected_letters = [(c, t, str(j).lower(), str(s).lower()) for c, t, _, j, s in LETTERS]
    if declared != expected_letters:
        problems.append(f"Arabic.kt alphabet differs from learn_data.LETTERS: {declared[:3]}…")

    seen = Counter()
    for w in words:
        if w["topic"] in ("phrases",):
            continue
        for letter in set(letters_of(w["arabic"])):
            seen[letter] += 1
    for c, *_ in LETTERS:
        if seen[c] < MIN_WORDS_PER_LETTER:
            problems.append(f"letter {c} occurs in {seen[c]} words, exercises need {MIN_WORDS_PER_LETTER}")

    quran_cols = ["surah", "ayah", "arabic", "translit", "ru"]
    q_header, ayat = read_tsv(ASSETS / "quran_short.tsv", quran_cols)
    by_surah = defaultdict(list)
    q_regenerated = []
    for a in ayat:
        by_surah[int(a["surah"])].append(int(a["ayah"]))
        try:
            expected = transliterate(a["arabic"], stop=True)
        except DataError as error:
            problems.append(f"quran_short.tsv:{a['line']}: {error}")
            continue
        if expected != a["translit"]:
            problems.append(f"quran_short.tsv:{a['line']}: translit {a['translit']!r}, rules give {expected!r}")
        q_regenerated.append("\t".join([a["surah"], a["ayah"], a["arabic"], expected, a["ru"]]))
    for surah, count in AYAT.items():
        if by_surah.get(surah) != list(range(1, count + 1)):
            problems.append(f"surah {surah}: ayat {by_surah.get(surah)}, expected 1..{count}")
    problems += [f"surah {s} is not one of the bundled short surahs" for s in by_surah if s not in AYAT]
    surah_kt = re.findall(r'Surah\((\d+), "[^"]+", "[^"]+", (\d+)\)', (SRC / "Quran.kt").read_text(encoding="utf-8"))
    if {int(s): int(c) for s, c in surah_kt} != AYAT:
        problems.append(f"Quran.kt surah table {surah_kt} differs from {AYAT}")

    if write:
        (ASSETS / "words.tsv").write_text("\n".join([header] + regenerated) + "\n", encoding="utf-8")
        (ASSETS / "quran_short.tsv").write_text("\n".join([q_header] + q_regenerated) + "\n", encoding="utf-8")
    else:
        print(f"words: {len(words)} in {len(topics)} topics; letters covered: "
              f"min {min(seen[c] for c, *_ in LETTERS)} words per letter; ayat: {len(ayat)}")
    return problems


if __name__ == "__main__":
    found = check(write="--write" in sys.argv)
    if found:
        print("\n".join(found))
        raise SystemExit(1)
    print("PASS: course data consistent with the transliteration rules")
