#!/usr/bin/env python3
"""Source preflight for the 0.11.0 compile failure; NOT a Kotlin compiler.

Compose enter/exit transitions (fadeIn, slideInVertically, scaleIn, expandVertically, ...) take a
FiniteAnimationSpec. 0.11.0 declared the shared NurMotion springs as AnimationSpec<T>, so every
`slideInVertically(NurMotion.snappy())` failed with "Argument type mismatch" in compileDebugKotlin.

Checks:
  1. every spec factory in object NurMotion returns FiniteAnimationSpec<T>;
  2. every transition call in app sources whose first argument is NurMotion.x() names a factory
     that exists and is finite;
  3. a pointerInput handler keyed without the slide index must not read a frozen `safeIndex`
     through the story's go() helper (0.11.0: taps always moved relative to the first slide).
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src/main/java'
TRANSITIONS = ('fadeIn', 'fadeOut', 'scaleIn', 'scaleOut', 'slideIn', 'slideOut',
               'slideInVertically', 'slideOutVertically', 'slideInHorizontally', 'slideOutHorizontally',
               'expandIn', 'shrinkOut', 'expandVertically', 'shrinkVertically',
               'expandHorizontally', 'shrinkHorizontally')
CALL = re.compile(r'\b(' + '|'.join(TRANSITIONS) + r')\s*\(\s*(?:animationSpec\s*=\s*)?NurMotion\.(\w+)\s*(?:<[^>]*>)?\s*\(')


def factories(motion_source):
    body = motion_source[motion_source.index('object NurMotion'):]
    body = body[:body.index('\n}\n')]
    return dict(re.findall(r'fun\s*<T>\s*(\w+)\s*\(\s*\)\s*:\s*(\w+)<T>', body))


def main():
    motion = (SRC / 'com/nur/prayer/ui/components/Motion.kt').read_text()
    specs = factories(motion)
    failures = []
    if not specs:
        failures.append('Motion.kt: no NurMotion spec factories found')
    for name, kind in specs.items():
        if kind != 'FiniteAnimationSpec':
            failures.append(f'Motion.kt: NurMotion.{name}() returns {kind}<T>; transitions need FiniteAnimationSpec<T>')
    files = sorted(SRC.rglob('*.kt'))
    calls = 0
    for path in files:
        text = path.read_text()
        for m in CALL.finditer(text):
            calls += 1
            line = text.count('\n', 0, m.start()) + 1
            if m[2] not in specs:
                failures.append(f'{path.relative_to(ROOT)}:{line}: NurMotion.{m[2]} does not exist')
            elif specs[m[2]] != 'FiniteAnimationSpec':
                failures.append(f'{path.relative_to(ROOT)}:{line}: {m[1]}(NurMotion.{m[2]}()) needs a finite spec')
        if 'fun go(delta: Int)' in text:
            go = text[text.index('fun go(delta: Int)'):]
            go = go[:go.index('\n    }\n')]
            if re.search(r'\bsafeIndex\s*\+\s*delta', go):
                failures.append(f'{path.relative_to(ROOT)}: go() uses safeIndex, frozen inside pointerInput; read the index state')
    if failures:
        raise SystemExit('\n'.join(failures))
    print(f'PASS: {len(specs)} NurMotion specs finite, {calls} transition calls checked in {len(files)} files (source preflight only).')


if __name__ == '__main__':
    main()
