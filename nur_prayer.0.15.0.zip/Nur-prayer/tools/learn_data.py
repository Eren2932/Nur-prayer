#!/usr/bin/env python3
"""Arabic course data: one transliteration rule set and the invariants of the bundled assets.

The app never transliterates at run time: assets/learn/words.tsv carries a `translit` column and
this module is the single place that column is derived from. verify_learn.py recomputes every
cell, so a hand-edited word whose vowels and transliteration disagree fails CI before it can teach
a wrong reading. Scheme (Russian, one symbol per Arabic consonant, so no two letters collide):

  ث с̱  ح ҳ  خ х  ذ з̱  ص с̣  ض д̣  ط т̣  ظ з̣  ع ‘  ء ’  غ ғ  ق қ  ه һ  و в  ي й
  long vowels doubled (аа, ии, уу), shadda doubles the consonant, tanween ан/ин/ун,
  the article is аль- before a moon letter and assimilates before a sun letter (аш-шамс).
"""
from __future__ import annotations

LETTERS = [
    # char, translit, conventional name, joins the next letter, sun letter
    ("ا", "а", "алиф", False, False), ("ب", "б", "ба", True, False), ("ت", "т", "та", True, True),
    ("ث", "с̱", "са", True, True), ("ج", "дж", "джим", True, False), ("ح", "ҳ", "ха", True, False),
    ("خ", "х", "хо", True, False), ("د", "д", "даль", False, True), ("ذ", "з̱", "заль", False, True),
    ("ر", "р", "ра", False, True), ("ز", "з", "зай", False, True), ("س", "с", "син", True, True),
    ("ش", "ш", "шин", True, True), ("ص", "с̣", "сад", True, True), ("ض", "д̣", "дад", True, True),
    ("ط", "т̣", "то", True, True), ("ظ", "з̣", "зо", True, True), ("ع", "‘", "айн", True, False),
    ("غ", "ғ", "гайн", True, False), ("ف", "ф", "фа", True, False), ("ق", "қ", "каф", True, False),
    ("ك", "к", "кяф", True, False), ("ل", "л", "лям", True, True), ("م", "м", "мим", True, False),
    ("ن", "н", "нун", True, True), ("ه", "һ", "ха", True, False),
    ("و", "в", "вав", False, False), ("ي", "й", "йа", True, False),
]
ALPHABET = [l[0] for l in LETTERS]
CONS = {l[0]: l[1] for l in LETTERS}
SUN = {l[0] for l in LETTERS if l[4]}
HAMZA = {"ء": None, "أ": "а", "إ": "и", "ؤ": None, "ئ": None}
FATHA, KASRA, DAMMA, SUKUN, SHADDA = "\u064E", "\u0650", "\u064F", "\u0652", "\u0651"
FATHATAN, KASRATAN, DAMMATAN, DAGGER = "\u064B", "\u064D", "\u064C", "\u0670"
MARKS = {FATHA, KASRA, DAMMA, SUKUN, SHADDA, FATHATAN, KASRATAN, DAMMATAN, DAGGER}
VOWEL = {FATHA: "а", KASRA: "и", DAMMA: "у", FATHATAN: "ан", KASRATAN: "ин", DAMMATAN: "ун"}
BASES = set(ALPHABET) | set(HAMZA) | {"آ", "ة", "ى"}
RU_VOWELS = set("аеиоуыэюя")


class DataError(ValueError):
    pass


def graphemes(word: str):
    """[(base, marks)] — a base letter and the combining marks written over or under it."""
    out = []
    for ch in word:
        if ch in MARKS:
            if not out:
                raise DataError(f"mark without a letter in {word!r}")
            out[-1][1].append(ch)
        elif ch in BASES:
            out.append((ch, []))
        else:
            raise DataError(f"unexpected character U+{ord(ch):04X} in {word!r}")
    return [(b, "".join(m)) for b, m in out]


def _double(t: str) -> str:
    return "дд" + t[1:] if t == "дж" else t + t


def _word(word: str) -> str:
    g = graphemes(word)
    out: list[str] = []
    i = 0
    n = len(g)

    def vowel_of(marks):
        for m in marks:
            if m in VOWEL:
                return VOWEL[m]
        return None

    # Allah: the one word whose lam is heavy and whose spelling hides the long a.
    plain = "".join(b for b, _ in g)
    if plain == "الله":
        tail = vowel_of(g[-1][1]) or ""
        return "Аллаһ" + tail
    while i < n:
        base, marks = g[i]
        prev = g[i - 1] if i else None
        nxt = g[i + 1] if i + 1 < n else None
        v = vowel_of(marks)
        if i == 0 and base == "ا" and not marks:
            # Article or a connecting alif (hamzat al-wasl).
            if nxt and nxt[0] == "ل" and n > 2:
                lam_marks = nxt[1]
                after = g[2]
                if SHADDA in lam_marks:
                    out.append("а")
                    i = 1
                    continue
                if SHADDA in after[1] and after[0] in SUN and after[0] != "ل":
                    out.append("а" + CONS[after[0]] + "-")
                    marks2 = after[1].replace(SHADDA, "")
                    g[2] = (after[0], marks2)
                    i = 2
                    continue
                out.append("аль-")
                i = 2
                continue
            # Imperative / ism-type wasla: i, or u when the third consonant has damma.
            third = g[2][1] if n > 2 else ""
            out.append("у" if DAMMA in third else "и")
            i += 1
            continue
        if (base == "ا" and i == 1 and not marks and prev[0] in "وفبكل" and vowel_of(prev[1])
                and FATHATAN not in prev[1] and nxt is not None
                and (nxt[1] == SUKUN or (nxt[0] == "ل" and not nxt[1] and i + 2 < n))):
            # A one-letter prefix (و ف ب) before a connecting alif: the alif is silent.
            if nxt and nxt[0] == "ل" and i + 2 < n:
                after = g[i + 2]
                if SHADDA in after[1] and after[0] in SUN and after[0] != "ل":
                    out.append(CONS[after[0]] + "-")
                    g[i + 2] = (after[0], after[1].replace(SHADDA, ""))
                else:
                    out.append("ль-")
                i += 2
                continue
            i += 1
            continue
        if base == "ا":
            if prev is None:
                raise DataError(f"bare alif in {word!r}")
            if FATHATAN in prev[1]:
                i += 1
                continue  # the silent seat of -an
            if marks:
                raise DataError(f"marked alif in {word!r}")
            out.append("а")
            i += 1
            continue
        if base == "ى":
            out.append("а")
            i += 1
            continue
        if base == "آ":
            out.append(("’" if out else "") + "аа")
            i += 1
            continue
        if base == "ة":
            if v:
                out.append("т" + v)
            i += 1
            continue
        if base in HAMZA:
            seat_vowel = v or ("" if SUKUN in marks else HAMZA[base])
            if seat_vowel is None and SUKUN not in marks and i != n - 1:
                raise DataError(f"hamza without a vowel in {word!r}")
            out.append(("’" if out else "") + (seat_vowel or ""))
            if DAGGER in marks:
                out.append("а")
            i += 1
            continue
        if base in ("و", "ي") and not marks and prev is not None:
            pv = vowel_of(prev[1])
            if base == "و" and pv == "у":
                out.append("у"); i += 1; continue
            if base == "ي" and pv == "и":
                out.append("и"); i += 1; continue
        # A consonant.
        t = CONS[base]
        if SHADDA in marks:
            last = i == n - 1 and not v
            t = ("й" if base == "ي" else _double(t)) if last else _double(t)
        out.append(t)
        if v:
            out.append(v)
        elif SUKUN in marks or i == n - 1 or SHADDA in marks:
            pass
        elif DAGGER in marks:
            pass
        else:
            raise DataError(f"consonant {base} without a vowel in {word!r}")
        if DAGGER in marks:
            out.append("а")
        i += 1
    return "".join(out)


def pausal(phrase: str) -> str:
    """The form read at a stop: the last short vowel falls silent, -an becomes a long a."""
    s = phrase.rstrip()
    if s.endswith("\u064Bا"):
        return s[:-2] + FATHA + "ا"
    if s and s[-1] in (FATHA, KASRA, DAMMA, KASRATAN, DAMMATAN):
        return s[:-1]
    return s


def transliterate(phrase: str, stop: bool = False) -> str:
    """Words joined as they are read: a connecting alif is silent after a vowel (бисми-ллаһ)."""
    if stop:
        phrase = pausal(phrase)
    words = []
    for w in phrase.split(" "):
        t = _word(w)
        if words and words[-1][-1] in RU_VOWELS:
            if t.startswith("Аллаһ"):
                words[-1] += "-ллаһ" + t[5:]
                continue
            if w[0] == "ا":
                t = t[1:]
        words.append(t)
    return " ".join(words)


def letters_of(word: str):
    """Alphabet letters a word is written with (hamza seats folded to their seat, ة to ت)."""
    fold = {"أ": "ا", "إ": "ا", "آ": "ا", "ى": "ا", "ة": "ت", "ؤ": "و", "ئ": "ي"}
    return [fold.get(b, b) for b, _ in graphemes(word.replace(" ", "")) if fold.get(b, b) in CONS]
