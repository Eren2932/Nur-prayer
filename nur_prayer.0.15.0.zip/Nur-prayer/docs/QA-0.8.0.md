# QA 0.8.0 — 2026-10-31

Версия 0.8.0, versionCode 23. Основа — 0.7.0.

## Выполненные проверки (the Computer, статический этап)

| Команда | Результат |
|---|---|
| check_compose_actions.py | PASS: 4 Android test files |
| check_ui_test_literals.py | PASS: 63 литерала UI-тестов найдены в приложении |
| test_compose_actions.py | PASS: 6 Python tests |
| kt_sanity.py | PASS: 99 Kotlin files |
| kt_symbols.py | PASS: 99 Kotlin files, 462 functions |
| source_audit.py | PASS: 637 source invariants; 28 baseline files unchanged |
| test_amoled_source.py | PASS: 7 Python tests |
| test_source_archive.py | PASS: 6 Python tests |
| test_kt_symbols.py | PASS: 4 Python tests |
| verify_cities.py | PASS: 424 города, 22 страны |
| verify_uz_table.py | PASS |
| test_build_regressions.py | PASS: 22 Python tests |

## Не выполнялось

Компиляция Kotlin, JVM-тесты (`RevealMathTest`, `SkyPaletteTest`, `HomeTimelineTest`), lint,
instrumentation и замеры кадров — в CI и на устройстве. См. `docs/DEVICE-CHECK-0.8.0.md`.
