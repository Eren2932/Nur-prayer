# QA 0.6.0 — 2026-10-31

Версия 0.6.0, versionCode 21. Основа — 0.5.2.

## Выполненные проверки (the Computer, статический этап)

| Команда | Результат |
|---|---|
| check_compose_actions.py | PASS: 4 Android test source files |
| test_compose_actions.py | PASS: 6 Python tests |
| kt_sanity.py | PASS: 97 Kotlin files, 15 enums, 629 declarations |
| kt_symbols.py | PASS: 97 Kotlin files, 431 functions |
| source_audit.py | PASS: 623 source invariants; 28 baseline files unchanged |
| test_amoled_source.py | PASS: 7 Python tests (контракт контраста неба по 7 палитрам) |
| test_source_archive.py | PASS: 6 Python tests |
| test_kt_symbols.py | PASS: 4 Python tests |
| verify_cities.py | PASS: 424 города, 22 страны |
| verify_uz_table.py | PASS |
| test_build_regressions.py | PASS: 22 Python tests |

## Не выполнялось

Gradle и Android SDK в окружении отсутствуют: компиляция Kotlin, JVM-тесты
(`SkyPaletteTest`, `HomeTimelineTest`), рендер Preview, instrumentation (`MeridianUiTest`)
и замеры кадров не запускались. Первый прогон CI — обязательная проверка.

См. `docs/DEVICE-CHECK-0.6.0.md`.
