package com.nur.prayer.ui.daily

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nur.prayer.daily.AzkarPages
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.Zikr
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.theme.ArabicFont
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.launch

// Cool reference paper. ~95% pigment (names: ~89%); the foot is darker, not a second overlay.
private val AzkarPaper = Brush.verticalGradient(
    0f to Color(0xF2DBDEEE), .44f to Color(0xF2DBDFF0),
    .85f to Color(0xF2D4DAEC), 1f to Color(0xF2B3BFD5)
)
private val AzkarRuleInk = Color(0x380E1524)
private val AzkarMint = Color(0xFFA7DDB9)
private val AzkarRail = Color(0xFF627078)
private const val TURN_MS = 260

@Composable
internal fun AzkarScreen(vm: DailyViewModel, list: List<Zikr>, set: AzkarSet, session: String) {
    val loaded by vm.dailyLoaded.collectAsStateWithLifecycle()
    val sessions by vm.azkar.collectAsStateWithLifecycle()
    val translit by vm.translit.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    key(session) {
        AzkarReader(if (loaded) list else emptyList(), set, sessions[session].orEmpty(), translit,
            onRepeat = { z ->
                val n = vm.azkarTap(session, z.id, z.count)
                haptic.performHapticFeedback(if (n >= z.count) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove)
            }, onTranslit = vm::setTranslit, onReset = { vm.azkarReset(session) })
    }
}

/** The paper and footer never move. The only horizontal input is a discrete arrow press. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun AzkarReader(list: List<Zikr>, set: AzkarSet, counts: Map<String, Long>, translit: Boolean,
    onRepeat: (Zikr) -> Unit, onTranslit: (Boolean) -> Unit, onReset: () -> Unit) {
    val ui = uiScale()
    Column(Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = ui.s(17f)).padding(bottom = ui.s(8f))) {
        Text(tr(set.title), Modifier.padding(start = ui.s(8f), end = ui.s(8f),
            top = ui.s(if (ui.compact) 8f else 34f), bottom = ui.s(if (ui.compact) 8f else 14f)).semantics { heading() },
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = ui.t(27f), lineHeight = ui.t(33f))
        Column(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(ui.s(20f))).background(AzkarPaper)) paper@{
            if (list.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(tr("Загрузка…"), color = Color.Black) }
                return@paper
            }
            val pager = rememberPagerState(initialPage = AzkarPages.opening(list, counts)) { list.size }
            val scope = rememberCoroutineScope()
            var turning by remember { mutableStateOf(false) }
            var confirmReset by rememberSaveable { mutableStateOf(false) }
            val page = pager.settledPage.coerceIn(list.indices)
            val read = remember(list, counts) { list.count { (counts[it.id] ?: 0L) >= it.count } }
            fun turn(step: Int) {
                if (turning) return
                val to = AzkarPages.neighbour(pager.settledPage, step, list.size) ?: return
                turning = true // Reject a second tap even before the first animation frame.
                scope.launch {
                    try { pager.animateScrollToPage(to, animationSpec = tween(TURN_MS, easing = FastOutSlowInEasing)) }
                    finally { turning = false }
                }
            }
            HorizontalPager(state = pager, key = { list[it].id }, userScrollEnabled = false,
                beyondViewportPageCount = 1,
                modifier = Modifier.fillMaxWidth().weight(1f)) { index ->
                val z = list[index]
                AzkarLeaf(z, index + 1, counts[z.id] ?: 0L, translit, onRepeat = { if (!turning) onRepeat(z) },
                    onTranslit = { onTranslit(!translit) }, onReset = if (counts.isEmpty()) null else ({ confirmReset = true }),
                    summary = if (read == list.size) tr("{0} прочитаны. Да примет Аллах.", tr(set.title)) else tr("прочитано {0} из {1}", read, list.size))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = ui.s(4f), vertical = ui.s(2f)),
                horizontalArrangement = Arrangement.spacedBy(ui.s(16f)), verticalAlignment = Alignment.CenterVertically) {
                PageArrow(false, page > 0) { turn(-1) }
                Text(tr("{0} из {1}", page + 1, list.size), Modifier.semantics { liveRegion = LiveRegionMode.Polite },
                    fontSize = ui.t(13f), color = Color.Black, fontWeight = FontWeight.Medium)
                // Read the fractional position only while drawing, not while laying out the Arabic text.
                Canvas(Modifier.weight(1f).height(4.dp)) {
                    val width = size.width * AzkarPages.fraction(pager.currentPage + pager.currentPageOffsetFraction, list.size)
                    val radius = CornerRadius(size.height / 2f, size.height / 2f)
                    drawRoundRect(AzkarRail, cornerRadius = radius)
                    drawRoundRect(AzkarMint, Offset(if (layoutDirection == LayoutDirection.Rtl) size.width - width else 0f, 0f),
                        Size(width, size.height), radius)
                }
                PageArrow(true, page < list.lastIndex) { turn(1) }
            }
            if (confirmReset) AlertDialog(onDismissRequest = { confirmReset = false },
                title = { Text(tr("Сбросить счёт за сегодня")) },
                confirmButton = { TextButton(onClick = { confirmReset = false; onReset() }) { Text(tr("заново")) } },
                dismissButton = { TextButton(onClick = { confirmReset = false }) { Text(tr("Отмена")) } })
        }
    }
}

@Composable
private fun PageArrow(next: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val label = if (next) tr("Следующее") else tr("Предыдущее")
    Box(Modifier.size(48.dp).clip(CircleShape).clickable(enabled = enabled, role = Role.Button, onClick = onClick)
        .semantics { contentDescription = label }, contentAlignment = Alignment.Center) {
        Glyph(if (next) GlyphKind.CHEVRON else GlyphKind.BACK,
            Color.Black.copy(alpha = if (enabled) 1f else .32f), Modifier.size(18.dp))
    }
}

@Composable
private fun AzkarLeaf(z: Zikr, number: Int, count: Long, translit: Boolean, onRepeat: () -> Unit,
    onTranslit: () -> Unit, onReset: (() -> Unit)?, summary: String) {
    val ui = uiScale()
    val arabic = remember(z.arabic) { ArabicFont.mushaf(z.arabic) }
    Column(Modifier.fillMaxSize().testTag("azkar-leaf-${z.id}").verticalScroll(rememberScrollState())
        .padding(vertical = ui.s(14f))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = ui.s(17f)), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(ui.s(12f))) {
            Box(Modifier.size(ui.s(37f)).background(Color(0x1F1D2440), CircleShape), contentAlignment = Alignment.Center) {
                Text("$number", color = Color.Black, fontSize = ui.t(17f), fontWeight = FontWeight.Bold)
            }
            Text(z.title, Modifier.weight(1f).semantics { heading() }, color = Color.Black,
                fontSize = ui.t(18f), lineHeight = ui.t(22f), fontWeight = FontWeight.Bold)
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = ui.s(24f))) {
            ReadingRule()
            ArabicText(arabic, 28f, Modifier.fillMaxWidth(), color = Color.Black)
            if (translit) {
                ReadingRule()
                Text(z.translit, color = Color.Black, fontWeight = FontWeight.SemiBold,
                    fontSize = ui.t(17.5f), lineHeight = ui.t(22.5f))
            }
            ReadingRule()
            Text(z.ru, color = Color.Black, fontSize = ui.t(17.5f), lineHeight = ui.t(23f))
            ReadingRule()
            z.virtue?.let { Text(it, color = Color.Black, fontSize = ui.t(15f), lineHeight = ui.t(21f)); Spacer(Modifier.height(6.dp)) }
            Text(z.source, color = Color.Black, fontSize = ui.t(14f), lineHeight = ui.t(19f))
            Spacer(Modifier.height(12.dp))
            val finished = count >= z.count
            val label = if (finished) "✓ " + tr("{0} из {1}", z.count, z.count)
                else if (z.count == 1) tr("Прочитал") else tr("Прочитал · {0} из {1}", count, z.count)
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(AzkarMint).testTag("azkar-repeat-${z.id}")
                .clickable(enabled = !finished, role = Role.Button, onClick = onRepeat)
                .heightIn(min = 48.dp).padding(8.dp), contentAlignment = Alignment.Center) {
                Text(label, color = Color.Black, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(8.dp))
            Text(summary, color = Color.Black, fontSize = ui.t(14f))
            ReaderAction(if (translit) tr("Скрыть транслит") else tr("Показать транслит"), onTranslit)
            if (onReset != null) ReaderAction(tr("Сбросить счёт за сегодня"), onReset)
        }
    }
}

@Composable
private fun ReadingRule() {
    Spacer(Modifier.padding(vertical = uiScale().s(10f)).fillMaxWidth().height(1.dp).background(AzkarRuleInk))
}

@Composable
private fun ReaderAction(label: String, onClick: () -> Unit) {
    Box(Modifier.widthIn(min = 48.dp).clip(RoundedCornerShape(8.dp)).clickable(role = Role.Button, onClick = onClick)
        .heightIn(min = 48.dp).padding(horizontal = 4.dp), contentAlignment = Alignment.CenterStart) {
        Text(label, color = Color.Black, fontSize = uiScale().t(14f), fontWeight = FontWeight.Medium)
    }
}
