package com.nur.prayer.ui.settings

import android.graphics.Bitmap
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.res.ResourcesCompat
import com.nur.prayer.i18n.tr
import com.nur.prayer.icon.AppIcon
import com.nur.prayer.icon.title
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
internal fun AppIconPicker(selected: AppIcon, onSelect: (AppIcon) -> Unit) {
    val ui = uiScale()
    val side = ui.s(EditorStyle.SIDE)
    EditorLabel(tr("Иконка"), Modifier.padding(horizontal = side))
    Spacer(Modifier.height(ui.s(12f)))
    val list = rememberLazyListState(initialFirstVisibleItemIndex = selected.ordinal)
    val size = ui.s(49f)
    val px = with(LocalDensity.current) { size.roundToPx().coerceAtLeast(1) }
    val context = LocalContext.current
    val cache = remember(context, px) { LruCache<AppIcon, ImageBitmap>(AppIcon.entries.size) }
    LazyRow(Modifier.fillMaxWidth().selectableGroup().testTag("icon-strip"), state = list,
        contentPadding = PaddingValues(horizontal = side), horizontalArrangement = Arrangement.spacedBy(ui.s(12f))) {
        items(AppIcon.entries, key = { it.id }) { icon ->
            val active = selected == icon
            val shape = RoundedCornerShape(ui.s(16f))
            var image by remember(cache, icon) { mutableStateOf<ImageBitmap?>(cache.get(icon)) }
            LaunchedEffect(cache, icon) {
                if (image == null) image = withContext(Dispatchers.Default) {
                    val art = ResourcesCompat.getDrawable(context.resources, icon.launcher, null)?.mutate() ?: return@withContext null
                    val bitmap = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
                    art.setBounds(0, 0, px, px)
                    art.draw(android.graphics.Canvas(bitmap))
                    bitmap.prepareToDraw()
                    bitmap.asImageBitmap().also { cache.put(icon, it) }
                }
            }
            Column(Modifier.width(ui.s(66f)).testTag("app-icon-${icon.id}").selectable(active, role = Role.RadioButton) {
                if (!active) onSelect(icon)
            }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.fillMaxWidth().height(ui.s(60f)).clip(shape).background(Color.White.copy(alpha = 0.035f))
                    .then(if (active) Modifier.border(2.dp, EditorStyle.Paper, shape) else Modifier), contentAlignment = Alignment.Center) {
                    image?.let { Image(it, contentDescription = null, modifier = Modifier.size(size)) }
                }
                Spacer(Modifier.height(ui.s(6f)))
                Text(icon.title(), color = if (active) Color.White else EditorStyle.Muted, fontSize = ui.t(12f),
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
