package com.nur.prayer.ui.settings

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.nur.prayer.i18n.tr
import com.nur.prayer.i18n.trDynamic
import com.nur.prayer.notify.AzanSound
import com.nur.prayer.ui.theme.uiScale

@Composable
internal fun AzanEditor(selected: AzanSound, onSelect: (AzanSound) -> Unit) {
    val context = LocalContext.current.applicationContext
    val owner = LocalLifecycleOwner.current
    val audition = remember(context) { SoundAudition(context) }
    DisposableEffect(audition, owner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_STOP) audition.stop() }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); audition.stop() }
    }
    SoundChoices(selected, audition.current, onSelect = { audition.stop(); onSelect(it) }, onPreview = audition::toggle)
}

@Composable
internal fun SoundChoices(selected: AzanSound, playing: AzanSound?, onSelect: (AzanSound) -> Unit, onPreview: (AzanSound) -> Unit) {
    val ui = uiScale()
    Column(Modifier.fillMaxWidth().selectableGroup()) {
        AzanSound.entries.forEach { sound ->
            val title = trDynamic(sound.title)
            val detail = when (sound) {
                AzanSound.AZAN_FULL -> tr("Полная запись · 3:35")
                AzanSound.AZAN_SHORT -> tr("25 сек · затухание")
                AzanSound.SYSTEM -> tr("Звук телефона")
                AzanSound.SILENT -> tr("Только вибрация")
            }
            EditorRule()
            EditorChoice(title, detail, selected == sound, { onSelect(sound) }, Modifier.testTag("sound-choice-${sound.name}")) {
                if (sound != AzanSound.SILENT) {
                    val active = selected == sound
                    val stop = playing == sound
                    val label = (if (stop) tr("Остановить") else tr("Прослушать")) + ": " + title
                    // The visible 32 dp ring ends at the page margin; its 48 dp input area extends inward.
                    Box(Modifier.size(48.dp).testTag("sound-preview-${sound.name}").clickable(role = Role.Button) { onPreview(sound) }
                        .semantics { contentDescription = label }, contentAlignment = Alignment.CenterEnd) {
                        val ink = if (active) EditorStyle.Track else EditorStyle.Paper
                        Box(Modifier.size(ui.s(32f)).clip(CircleShape).background(if (active) EditorStyle.Paper else Color.Transparent)
                            .border(1.dp, EditorStyle.Paper, CircleShape), contentAlignment = Alignment.Center) {
                            Canvas(Modifier.size(ui.s(13f))) {
                                if (stop) drawRect(ink, Offset(size.width * 0.14f, size.height * 0.14f), Size(size.width * 0.72f, size.height * 0.72f))
                                else drawPath(Path().apply {
                                    moveTo(size.width * 0.22f, size.height * 0.05f)
                                    lineTo(size.width * 0.96f, size.height * 0.5f)
                                    lineTo(size.width * 0.22f, size.height * 0.95f); close()
                                }, ink)
                            }
                        }
                    }
                }
            }
        }
    }
}
