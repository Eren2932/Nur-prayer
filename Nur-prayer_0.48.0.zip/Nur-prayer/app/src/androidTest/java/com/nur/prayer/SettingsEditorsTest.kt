package com.nur.prayer

import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.click
import androidx.compose.ui.test.getBoundsInRoot
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTouchInput
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.icon.AppIcon
import com.nur.prayer.notify.AzanSound
import com.nur.prayer.ui.settings.AppIconPicker
import com.nur.prayer.ui.settings.SoundChoices
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import com.nur.prayer.ui.wallpaper.WallpaperCatalog
import com.nur.prayer.ui.wallpaper.WallpaperRow
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

class SettingsEditorsTest {
    @get:Rule val compose = createComposeRule()

    @Test fun pickingNeverAuditionsAndAuditioningNeverPicks() {
        val selection = mutableStateOf(AzanSound.SYSTEM)
        val previews = mutableListOf<AzanSound>()
        compose.setContent { NurTheme {
            SoundChoices(selection.value, null, onSelect = { selection.value = it }, onPreview = { previews.add(it) })
        } }
        // Real touch dispatch, not just invoking an accessibility callback.
        compose.onNodeWithTag("sound-choice-AZAN_SHORT").performTouchInput { click() }
        compose.onNodeWithTag("sound-choice-AZAN_SHORT").assertIsSelected()
        compose.runOnIdle { assertEquals(emptyList<AzanSound>(), previews) }
        compose.onNodeWithTag("sound-preview-SYSTEM").performTouchInput { click() }
        compose.onNodeWithTag("sound-preview-AZAN_FULL").performTouchInput { click() }
        compose.onNodeWithTag("sound-choice-AZAN_SHORT").assertIsSelected()
        compose.onNodeWithTag("sound-preview-SILENT").assertDoesNotExist()
        compose.runOnIdle { assertEquals(listOf(AzanSound.SYSTEM, AzanSound.AZAN_FULL), previews) }
    }

    @Test fun lastIconIsReachableWithinTheStrip() {
        val selection = mutableStateOf(AppIcon.NUR)
        compose.setContent { NurTheme { Column { AppIconPicker(selection.value) { selection.value = it } } } }
        compose.onNodeWithTag("icon-strip").performScrollToNode(hasTestTag("app-icon-graphite"))
        compose.onNodeWithTag("app-icon-graphite").performClick()
        compose.onNodeWithTag("app-icon-graphite").assertIsSelected()
    }

    @Test fun selectingAWallpaperDoesNotResizeItsTile() {
        val selection = mutableStateOf(WallpaperCatalog.Sky)
        compose.setContent { NurTheme { Column {
            WallpaperRow(selection.value, emptyList(), paletteFor(Prayer.ISHA), onPick = { selection.value = it }, onOpenAll = {})
        } } }
        val first = compose.onNodeWithTag("wall-tile-sky").getBoundsInRoot()
        val photo = compose.onNodeWithTag("wall-tile-kaaba_day")
        photo.assertIsDisplayed()
        val before = photo.getBoundsInRoot()
        assertEquals(first.width, before.width)
        assertEquals(first.height, before.height)
        photo.performClick()
        photo.assertIsSelected()
        assertEquals(first.width, photo.getBoundsInRoot().width)
        assertEquals(first.height, photo.getBoundsInRoot().height)
    }
}
