"""Source preflight for the 0.6.0 sky design; not runtime/performance validation."""
import re
from release_metadata import without_comments


def expect(source, pattern, message):
    if not re.search(pattern, source, re.S):
        raise AssertionError(message)


def validate_ambient(sky_source, policy_source):
    sky, policy = map(without_comments, (sky_source, policy_source))
    expect(sky, r'\.drawBehind\s*\{\s*drawRect\(Ink\)',
           'Backdrop: paint the opaque Ink substrate before any sky gradient')
    expect(sky, r'if\s*\(!sky\s*\|\|[^\n]*return@drawBehind',
           'Backdrop: AMOLED mode must stop at pure Ink')
    for token in ('StarLayer(', 'AmbientSky', 'withFrameNanos', 'rememberInfiniteTransition', 'LaunchedEffect('):
        if token in sky:
            raise AssertionError('Static sky must not install a frame clock or star renderer: ' + token)
    expect(policy, r'allowed\s*=\s*owner.lifecycle.currentState.isAtLeast\(Lifecycle.State.RESUMED\)\s*&&\s*!saver\s*&&\s*scale\s*>\s*0f',
           'Backdrop policy: require resumed lifecycle, no saver and enabled OS animation')
    for token in ('isPowerSaveMode', 'Settings.Global.ANIMATOR_DURATION_SCALE',
                  'owner.lifecycle.addObserver(lifecycle)', 'owner.lifecycle.removeObserver(lifecycle)',
                  'context.unregisterReceiver(receiver)', 'unregisterContentObserver(observer)'):
        if token not in policy:
            raise AssertionError('Backdrop policy: missing ' + token)


def validate_compass(source):
    """0.23.0 instrument: any hold (flat, tilted, upright), auto-search -> lock -> tracking.
    Invariants: no bearing without a usable reading, a short grace before the lock drops,
    gold only from the calibrated trust policy, Kaaba drawn locally."""
    source = without_comments(source)
    expect(source, r'val usable\s*=\s*heading.available\s*&&\s*heading.usable\s*&&\s*delta.isFinite\(\)',
           'Compass: require an available, usable, finite heading')
    expect(source, r'val ready\s*=\s*steady\s*&&\s*\(usable\s*\|\|\s*motion.locked\)\s*&&\s*searchShown',
           'Compass: tracking is gated on the usable heading')
    expect(source, r'if\s*\(motion.locked\)\s*delay\(QiblaDial.DROP_MILLIS\)\s*steady\s*=\s*false',
           'Compass: an unusable reading releases the lock after the grace period')
    m = re.search(r'const val DROP_MILLIS\s*=\s*(\d+)L', source)
    if not m or not 0 < int(m[1]) <= 3000:
        raise AssertionError('Compass: DROP_MILLIS must be a short grace (<= 3 s)')
    expect(source, r'if\s*\(ready\s*&&\s*usable\s*&&\s*motion.locked\)\s*motion.target\s*=\s*nearestDialRotation\(',
           'Compass: only track usable headings')
    expect(source, r'if\s*\(!ready\)\s*\{\s*motion.locked\s*=\s*false',
           'Compass: drop the lock the moment trust is lost')
    expect(source, r'fun rotation\(\):\s*Float\s*=\s*if\s*\(locked\)\s*tracked.value\s*else\s*searchAngle\(\)',
           'Compass: without a lock the dial searches, never holds a bearing')
    expect(source, r'val lock\s*=\s*animateFloatAsState\(if\s*\(aligned\)\s*1f\s*else\s*0f',
           'Compass: gold lock requires confirmed alignment')
    expect(source, r'lock.value\s*\*\s*visual',
           'Compass: the gold index is scaled by the confirmed alignment')
    expect(source, r'KaabaIcon\(\s*frame\s*=\s*Color.White,\s*glow\s*=\s*gold',
           'Compass: keep the local Kaaba vector, lit only by confirmed alignment')
    expect(source, r'val aligned\s*=\s*QiblaGuidance.aligned\(delta, heading.available, heading.trustworthy, wasAligned\)',
           'Compass: alignment must come from the trust policy')
    expect(source, r'QiblaGuidance.instruction\(delta, heading.available, usable, heading.trustworthy\)',
           'Compass: instructions must come from the trust policy')
    expect(source, r'LaunchedEffect\(aligned\s*&&\s*motion.locked\)',
           'Compass: confirmation haptic only on a settled, aligned dial')
