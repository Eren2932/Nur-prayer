package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.CalendarConvention
import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.PrayerParams
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.core.astro.TimeSource
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import kotlin.math.abs

/**
 * Locks the engine against the printed calendar of the Spiritual Board of Tatarstan,
 * "Ике атнага намаз уку тәртибе", Казань, август 2026, transcribed from a photograph.
 *
 * The poster has seven columns and the engine must reproduce all seven:
 * Сәхәр тәмам, Мәчетләрдә укыла, Кояш чыга, Зәвәл, Икенде, Ахшам, Ястү.
 *
 * The regression this file exists for: the app published dawn (01:11) as Fajr while the mosques
 * called Fajr at 02:45, an hour and a half later. Those are two different rows of the poster and
 * are now two different markers, [Prayer.SAHAR] and [Prayer.FAJR].
 */
class KazanCalendarTest {

    private val kazan = Coordinates(55.7963, 49.1088)
    private val zone: ZoneId = ZoneId.of("Europe/Moscow")
    private val params = PrayerParams(
        method = CalculationMethod.SPIRITUAL_BOARD_TATARSTAN,
        madhab = Madhab.HANAFI,
        highLatitudeRule = HighLatitudeRule.AUTO,
        rounding = RoundingMode.NEAREST,
        convention = CalendarConvention.DUM_RT
    )

    private val order = listOf(
        Prayer.SAHAR, Prayer.FAJR, Prayer.SUNRISE,
        Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA
    )

    /** Day of August 2026 -> the seven printed columns, in [order]. */
    private val published = mapOf(
        15 to listOf("1:11", "2:45", "4:15", "11:47", "16:53", "19:19", "21:34"),
        16 to listOf("1:17", "2:47", "4:17", "11:47", "16:52", "19:17", "21:30"),
        17 to listOf("1:22", "2:49", "4:19", "11:47", "16:50", "19:14", "21:26"),
        18 to listOf("1:27", "2:50", "4:20", "11:47", "16:48", "19:12", "21:22")
    )

    @Test
    fun `reproduces every printed column within one minute`() {
        val misses = mutableListOf<String>()
        for ((dayOfMonth, expected) in published) {
            val date = LocalDate.of(2026, 8, dayOfMonth)
            val day = PrayerEngine.day(date, kazan, zone, params)
            order.forEachIndexed { index, prayer ->
                val actual = day.at(prayer).toLocalTime()
                val target = LocalTime.parse(padded(expected[index]))
                val delta = minuteDistance(actual, target)
                assertTrue(
                    "$date ${prayer.name}: календарь ${expected[index]}, движок $actual, расхождение $delta мин",
                    delta <= 1
                )
                if (delta != 0L) misses += "$dayOfMonth.08 ${prayer.name}"
            }
        }
        // The poster carries about a minute of its own noise: across these four days its printed
        // sunrise advances 2, 2 and 1 minutes where the true rate is a uniform 1.93. Four misses of
        // exactly one minute out of twenty-eight values is the calibrated floor; anything worse
        // means the convention drifted.
        assertTrue("Слишком много расхождений: $misses", misses.size <= 4)
    }

    @Test
    fun `congregational Fajr is the published sunrise minus ninety minutes`() {
        for (dayOfMonth in published.keys) {
            val day = PrayerEngine.day(LocalDate.of(2026, 8, dayOfMonth), kazan, zone, params)
            assertEquals(
                "Фаджр обязан быть ровно за 90 минут до опубликованного восхода",
                90L,
                Duration.between(day.at(Prayer.FAJR), day.at(Prayer.SUNRISE)).toMinutes()
            )
            assertEquals(TimeSource.CONGREGATION, day.fajrSource)
        }
    }

    @Test
    fun `Sahar stays well before congregational Fajr in the short night season`() {
        val day = PrayerEngine.day(LocalDate.of(2026, 8, 15), kazan, zone, params)
        assertEquals(LocalTime.of(1, 11), day.at(Prayer.SAHAR).toLocalTime())
        assertEquals(LocalTime.of(2, 45), day.at(Prayer.FAJR).toLocalTime())
        assertTrue(day.at(Prayer.SAHAR).isBefore(day.at(Prayer.FAJR)))
    }

    @Test
    fun `Isha on 15 August is astronomical, not a seventh of the night`() {
        val day = PrayerEngine.day(LocalDate.of(2026, 8, 15), kazan, zone, params)
        val isha = day.at(Prayer.ISHA).toLocalTime()
        // The Sun reaches -20.3 degrees that night, so the 15 degree angle is perfectly defined.
        assertEquals(TimeSource.ANGLE, day.ishaSource)
        assertEquals(LocalTime.of(21, 34), isha)
        // The exact wrong answer the released build produced. Never again.
        assertTrue("Иша снова зажата в 1/7 ночи", minuteDistance(isha, LocalTime.of(20, 37)) > 30)
    }

    @Test
    fun `short summer nights fall back to the intervals the board actually prints`() {
        val day = PrayerEngine.day(LocalDate.of(2026, 8, 1), kazan, zone, params)
        assertEquals(TimeSource.FIXED_INTERVAL, day.saharSource)
        assertEquals(TimeSource.FIXED_INTERVAL, day.ishaSource)
        // Sahar = sunrise - 120 min, Isha = sunset + 90 min, verified on the poster.
        assertEquals(120L, Duration.between(day.at(Prayer.SAHAR), day.at(Prayer.SUNRISE)).toMinutes())
        assertEquals(90L, Duration.between(day.at(Prayer.MAGHRIB), day.at(Prayer.ISHA)).toMinutes())
    }

    @Test
    fun `calculation method actually changes Sahar and Isha`() {
        val date = LocalDate.of(2026, 8, 15)
        val reference = PrayerEngine.day(date, kazan, zone, params)

        val laterIsha = PrayerEngine.day(
            date, kazan, zone, params.copy(method = CalculationMethod.MUSLIM_WORLD_LEAGUE)
        )
        assertNotEquals(
            "Иша при 17° обязана отличаться от Иши при 15°",
            reference.at(Prayer.ISHA), laterIsha.at(Prayer.ISHA)
        )
        assertTrue(laterIsha.at(Prayer.ISHA).isAfter(reference.at(Prayer.ISHA)))

        val laterSahar = PrayerEngine.day(
            date, kazan, zone, params.copy(method = CalculationMethod.NORTH_AMERICA)
        )
        assertTrue(
            "Сухур при 15° обязан быть позже, чем при 18°",
            laterSahar.at(Prayer.SAHAR).isAfter(reference.at(Prayer.SAHAR))
        )
    }

    @Test
    fun `turning off the congregational gap collapses Fajr onto dawn`() {
        val date = LocalDate.of(2026, 8, 15)
        val day = PrayerEngine.day(date, kazan, zone, params.copy(congregationalFajrMinutes = 0))
        assertEquals(day.at(Prayer.SAHAR), day.at(Prayer.FAJR))
    }

    @Test
    fun `the day stays strictly ordered everywhere and all year`() {
        var date = LocalDate.of(2026, 1, 1)
        while (date.year == 2026) {
            for (place in listOf(
                Coordinates(55.7963, 49.1088),   // Казань
                Coordinates(55.7558, 37.6173),   // Москва
                Coordinates(59.9311, 30.3609),   // Санкт-Петербург, белые ночи
                Coordinates(69.3558, 88.1893),   // Норильск, полярная ночь
                Coordinates(43.0241, 44.6814)    // Владикавказ
            )) {
                val day = PrayerEngine.day(date, place, ZoneId.of("Europe/Moscow"), params)
                var previous = day.at(order.first())
                for (prayer in order.drop(1)) {
                    val value = day.at(prayer)
                    assertTrue(
                        "$date $place ${prayer.name} нарушил порядок: $previous -> $value",
                        !value.isBefore(previous)
                    )
                    previous = value
                }
            }
            date = date.plusDays(1)
        }
    }

    private fun padded(value: String): String = if (value.length == 4) "0$value" else value

    /** Distance in whole minutes on a 24 hour circle, so 23:59 and 00:01 are two apart. */
    private fun minuteDistance(a: LocalTime, b: LocalTime): Long {
        val direct = abs(a.toSecondOfDay() - b.toSecondOfDay()) / 60L
        return minOf(direct, 1440L - direct)
    }
}
