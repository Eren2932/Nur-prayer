package com.nur.prayer.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.core.astro.TimeSource
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.GlassPanel
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

@Composable
fun SettingsScreen(
    data: PrayerData,
    palette: PhasePalette,
    actions: AppActions,
    exactAlarmsAllowed: Boolean,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val dockInset = LocalDockInset.current
    val settings = data.settings

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(
            start = ui.s(20f),
            end = ui.s(20f),
            top = ui.s(6f),
            bottom = dockInset
        ),
        verticalArrangement = Arrangement.spacedBy(ui.s(12f))
    ) {
        item {
            Column {
                AutoSizeText(
                    text = "Настройки",
                    color = TextPrimary,
                    fontSize = ui.t(26f),
                    minFontSize = ui.t(19f),
                    fontWeight = FontWeight.SemiBold
                )
                AutoSizeText(
                    text = "Всё считается офлайн на устройстве",
                    color = TextTertiary,
                    fontSize = ui.t(12f),
                    minFontSize = ui.t(9.5f),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item {
            SectionCard("Местоположение") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { actions.openCityPicker() }
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.LocationOn, null, tint = palette.accent, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        AutoSizeText(
                            text = data.place.label,
                            color = TextPrimary,
                            fontSize = ui.t(15f),
                            minFontSize = ui.t(12f),
                            modifier = Modifier.fillMaxWidth()
                        )
                        AutoSizeText(
                            text = data.place.subtitle,
                            color = TextTertiary,
                            fontSize = ui.t(11f),
                            minFontSize = ui.t(9f),
                            maxLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Text("изменить", color = palette.accentSoft, fontSize = ui.t(12f))
                }
                PillButton(
                    text = "Определить по геолокации",
                    accent = palette.accent,
                    onClick = { actions.requestLocation() }
                )
            }
        }

        item {
            SectionCard("Метод расчёта") {
                CalculationMethod.entries.forEach { method ->
                    SelectableRow(
                        title = method.title,
                        subtitle = subtitleFor(method),
                        selected = settings.method == method,
                        accent = palette.accent,
                        onClick = { actions.setMethod(method) }
                    )
                }
            }
        }

        item {
            SectionCard("Мазхаб (время Асра)") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillToggle(
                        text = "Ханафитский",
                        selected = settings.madhab == Madhab.HANAFI,
                        accent = palette.accent,
                        modifier = Modifier.weight(1f)
                    ) { actions.setMadhab(Madhab.HANAFI) }
                    PillToggle(
                        text = "Шафиитский",
                        selected = settings.madhab == Madhab.STANDARD,
                        accent = palette.accent,
                        modifier = Modifier.weight(1f)
                    ) { actions.setMadhab(Madhab.STANDARD) }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Ханафитский Аср наступает позже: тень объекта равна двум его высотам.",
                    color = TextTertiary, fontSize = ui.t(11f)
                )
            }
        }

        item {
            SectionCard("Высокие широты") {
                HighLatitudeRule.entries.forEach { rule ->
                    SelectableRow(
                        title = ruleTitle(rule),
                        subtitle = ruleSubtitle(rule),
                        selected = settings.highLatitudeRule == rule,
                        accent = palette.accent,
                        onClick = { actions.setHighLatitudeRule(rule) }
                    )
                }
            }
        }

        item {
            SectionCard("Округление секунд") {
                RoundingMode.entries.forEach { mode ->
                    SelectableRow(
                        title = mode.title,
                        subtitle = mode.explanation,
                        selected = settings.rounding == mode,
                        accent = palette.accent,
                        onClick = { actions.setRounding(mode) }
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Расхождение на одну минуту между двумя приложениями в одном городе — почти " +
                        "всегда именно это: секунды упали по разные стороны границы минуты.",
                    color = TextTertiary, fontSize = ui.t(11f)
                )
            }
        }

        item {
            SectionCard("Уведомления") {
                if (!exactAlarmsAllowed) {
                    WarningBlock(
                        text = "Android запрещает приложению точные будильники. Без этого разрешения " +
                            "уведомления могут опаздывать на несколько минут.",
                        actionText = "Разрешить точные будильники",
                        accent = palette.accent,
                        onClick = { actions.openExactAlarmSettings() }
                    )
                    Spacer(Modifier.height(10.dp))
                }
                Prayer.entries.filter { it.isPrayer }.forEach { prayer ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            AutoSizeText(
                                text = PrayerLabels.title(prayer),
                                color = TextPrimary,
                                fontSize = ui.t(15f),
                                minFontSize = ui.t(12f),
                                modifier = Modifier.fillMaxWidth()
                            )
                            AutoSizeText(
                                text = PrayerLabels.hint(prayer),
                                color = TextTertiary,
                                fontSize = ui.t(11f),
                                minFontSize = ui.t(9f),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Switch(
                            checked = settings.notifications[prayer] == true,
                            onCheckedChange = { actions.setNotification(prayer, it) },
                            colors = SwitchDefaults.colors(
                                checkedTrackColor = palette.accent.copy(alpha = 0.55f),
                                checkedThumbColor = Color.White
                            )
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Stepper(
                    label = "Напомнить заранее",
                    value = "${settings.preAlertMinutes} мин",
                    accent = palette.accent,
                    onMinus = { actions.setPreAlert(settings.preAlertMinutes - 5) },
                    onPlus = { actions.setPreAlert(settings.preAlertMinutes + 5) }
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        AutoSizeText(
                            text = "Без звука",
                            color = TextPrimary,
                            fontSize = ui.t(15f),
                            minFontSize = ui.t(12f),
                            modifier = Modifier.fillMaxWidth()
                        )
                        AutoSizeText(
                            text = "Только вибрация и всплывающее уведомление",
                            color = TextTertiary,
                            fontSize = ui.t(11f),
                            minFontSize = ui.t(9f),
                            maxLines = 2,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Switch(
                        checked = settings.silentNotifications,
                        onCheckedChange = { actions.setSilent(it) },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor = palette.accent.copy(alpha = 0.55f),
                            checkedThumbColor = Color.White
                        )
                    )
                }
                Spacer(Modifier.height(8.dp))
                PillButton(
                    text = "Отключить экономию батареи для Nur",
                    accent = palette.accent,
                    onClick = { actions.openBatterySettings() }
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Xiaomi, Huawei, Samsung и Oppo убивают фоновые процессы: разрешите автозапуск " +
                        "и снимите ограничения батареи, иначе система задержит любое уведомление.",
                    color = TextTertiary, fontSize = ui.t(11f)
                )
            }
        }

        item {
            SectionCard("Ручная коррекция, минуты") {
                Prayer.entries.forEach { prayer ->
                    val value = settings.offsets[prayer] ?: 0
                    Stepper(
                        label = PrayerLabels.title(prayer),
                        value = (if (value > 0) "+$value" else "$value"),
                        accent = palette.accent,
                        onMinus = { actions.setOffset(prayer, value - 1) },
                        onPlus = { actions.setOffset(prayer, value + 1) }
                    )
                }
                Spacer(Modifier.height(6.dp))
                Stepper(
                    label = "Сдвиг даты по хиджре",
                    value = "${settings.hijriOffset} дн.",
                    accent = palette.accent,
                    onMinus = { actions.setHijriOffset(settings.hijriOffset - 1) },
                    onPlus = { actions.setHijriOffset(settings.hijriOffset + 1) }
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Сверьте расписание с вашей мечетью и выровняйте разницу здесь: коррекция " +
                        "применяется и к уведомлениям.",
                    color = TextTertiary, fontSize = ui.t(11f)
                )
            }
        }

        item {
            SectionCard("О расчёте") {
                InfoLine("Координаты", format(data.place.coordinates.latitude) + ", " + format(data.place.coordinates.longitude))
                InfoLine("Часовой пояс", data.place.zone.id)
                InfoLine("Азимут кыблы", "${Math.round(data.qibla)}°")
                InfoLine("Углы метода", settings.method.angleSummary)
                InfoLine("Фаджр сегодня", sourceLabel(data.today.fajrSource))
                InfoLine("Иша сегодня", sourceLabel(data.today.ishaSource))
                data.today.note?.let {
                    Spacer(Modifier.height(6.dp))
                    Text(it, color = TextTertiary, fontSize = ui.t(11f))
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Алгоритм: астрономические формулы Жана Мееса (Astronomical Algorithms, 2-е изд.), " +
                        "точность солнечных событий — единицы секунд. Правило высоких широт " +
                        "включается только в те дни, когда солнце физически не опускается до угла " +
                        "метода. Nur 0.2.1",
                    color = TextTertiary, fontSize = ui.t(11f)
                )
            }
        }
    }
}

private fun format(value: Double): String = String.format(java.util.Locale.US, "%.4f", value)

private fun subtitleFor(method: CalculationMethod): String {
    val hint = when (method) {
        CalculationMethod.RUSSIA_DUM -> "Россия и СНГ"
        CalculationMethod.SPIRITUAL_BOARD_TATARSTAN -> "Сверено с календарём ДУМ РТ"
        CalculationMethod.UMM_AL_QURA -> "Саудовская Аравия"
        CalculationMethod.TURKEY -> "С поправками Diyanet"
        else -> null
    }
    // The angles are always shown: it is the only honest way to make it obvious that switching
    // the method really does change the arithmetic.
    return if (hint == null) method.angleSummary else "$hint · ${method.angleSummary}"
}

private fun ruleTitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> "Автоматически"
    HighLatitudeRule.FIXED_INTERVAL -> "Фиксированный интервал (ДУМ РФ)"
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> "Середина ночи"
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> "Одна седьмая ночи"
    HighLatitudeRule.TWILIGHT_ANGLE -> "Пропорция по углу сумерек"
}

private fun ruleSubtitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> "Выше 48° широты — фиксированный интервал, иначе середина ночи"
    HighLatitudeRule.FIXED_INTERVAL -> "Восход − 120 мин и закат + 90 мин, как печатает ДУМ РТ"
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> "Фаджр и Иша не переходят середину ночи"
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> "Классическая доля ночи 1/7"
    HighLatitudeRule.TWILIGHT_ANGLE -> "Доля ночи пропорциональна углу метода"
}

/** Plain words for where today's Fajr / Isha actually came from. */
private fun sourceLabel(source: TimeSource): String = when (source) {
    TimeSource.ANGLE -> "по углу солнца"
    TimeSource.METHOD_INTERVAL -> "интервал метода"
    TimeSource.FIXED_INTERVAL -> "фикс. интервал (короткая ночь)"
    TimeSource.NIGHT_FRACTION -> "доля ночи (короткая ночь)"
    TimeSource.MIDNIGHT_BOUND -> "ограничено серединой ночи"
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    val ui = uiScale()
    GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = 16.dp) {
        Column {
            AutoSizeText(
                text = title.uppercase(),
                color = TextSecondary,
                fontSize = ui.t(11f),
                minFontSize = ui.t(9f),
                letterSpacing = ui.t(1.5f),
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SelectableRow(
    title: String,
    subtitle: String,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    val ui = uiScale()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) accent.copy(alpha = 0.14f) else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            AutoSizeText(
                text = title,
                color = TextPrimary,
                fontSize = ui.t(14f),
                minFontSize = ui.t(11f),
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
            AutoSizeText(
                text = subtitle,
                color = TextTertiary,
                fontSize = ui.t(11f),
                minFontSize = ui.t(9f),
                maxLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (selected) {
            Icon(Icons.Filled.Check, null, tint = accent, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun PillToggle(
    text: String,
    selected: Boolean,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val ui = uiScale()
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) accent.copy(alpha = 0.20f) else Color.White.copy(alpha = 0.05f))
            .border(
                1.dp,
                if (selected) accent.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.10f),
                RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        AutoSizeText(
            text = text,
            color = if (selected) TextPrimary else TextSecondary,
            fontSize = ui.t(13f),
            minFontSize = ui.t(10f)
        )
    }
}

@Composable
private fun PillButton(text: String, accent: Color, onClick: () -> Unit) {
    val ui = uiScale()
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(accent.copy(alpha = 0.16f))
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        AutoSizeText(
            text = text,
            color = TextPrimary,
            fontSize = ui.t(13f),
            minFontSize = ui.t(10f),
            fontWeight = FontWeight.Medium,
            maxLines = 2,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(horizontal = ui.s(10f))
        )
    }
}

@Composable
private fun WarningBlock(
    text: String,
    actionText: String,
    accent: Color,
    onClick: () -> Unit
) {
    val ui = uiScale()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x33FF6B6B))
            .padding(12.dp)
    ) {
        Text(text, color = TextPrimary, fontSize = ui.t(12f))
        Spacer(Modifier.height(8.dp))
        PillButton(actionText, accent, onClick)
    }
}

@Composable
private fun Stepper(
    label: String,
    value: String,
    accent: Color,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    val ui = uiScale()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AutoSizeText(
            text = label,
            color = TextPrimary,
            fontSize = ui.t(14f),
            minFontSize = ui.t(10.5f),
            maxLines = 2,
            modifier = Modifier.weight(1f)
        )
        StepperButton("−", accent, onMinus)
        Box(
            modifier = Modifier
                .width(ui.s(66f))
                .padding(horizontal = ui.s(6f)),
            contentAlignment = Alignment.Center
        ) {
            AutoSizeText(
                text = value,
                color = TextPrimary,
                fontSize = ui.t(14f),
                minFontSize = ui.t(10f),
                fontFamily = FontFamily.Monospace
            )
        }
        StepperButton("+", accent, onPlus)
    }
}

@Composable
private fun StepperButton(text: String, accent: Color, onClick: () -> Unit) {
    val ui = uiScale()
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(accent.copy(alpha = 0.18f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    val ui = uiScale()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        AutoSizeText(
            text = label,
            color = TextTertiary,
            fontSize = ui.t(12f),
            minFontSize = ui.t(9.5f),
            maxLines = 2,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(ui.s(10f)))
        AutoSizeText(
            text = value,
            color = TextPrimary,
            fontSize = ui.t(12f),
            minFontSize = ui.t(9.5f),
            fontFamily = FontFamily.Monospace
        )
    }
}
