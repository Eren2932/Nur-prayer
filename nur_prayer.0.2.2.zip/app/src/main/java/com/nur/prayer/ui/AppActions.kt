package com.nur.prayer.ui

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.RoundingMode

/** Everything the screens can ask the host activity / view model to do. */
data class AppActions(
    val openCityPicker: () -> Unit,
    val requestLocation: () -> Unit,
    val openExactAlarmSettings: () -> Unit,
    val openBatterySettings: () -> Unit,
    val setMethod: (CalculationMethod) -> Unit,
    val setMadhab: (Madhab) -> Unit,
    val setHighLatitudeRule: (HighLatitudeRule) -> Unit,
    val setRounding: (RoundingMode) -> Unit,
    val setNotification: (Prayer, Boolean) -> Unit,
    val setOffset: (Prayer, Int) -> Unit,
    val setPreAlert: (Int) -> Unit,
    val setSilent: (Boolean) -> Unit,
    val setHijriOffset: (Int) -> Unit
)
