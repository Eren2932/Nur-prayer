package com.nur.prayer.core.astro

/**
 * How one marker is collapsed from an exact instant to a printed minute.
 *
 * Printed calendars do not round uniformly. Every column has its own habit, and those habits are
 * not cosmetic: they are the whole difference between "our app disagrees with the mosque" and
 * "our app is the mosque". Calibrated numerically against the DUM RT poster for Kazan
 * (August 2026) — see [CalendarConvention.DUM_RT] and KazanCalendarTest.
 */
data class MarkerPolicy(
    val rounding: RoundingMode,
    /** Constant correction in minutes applied before rounding. */
    val offsetMinutes: Int = 0
)

/**
 * A published-calendar convention: the set of per-column rounding habits of a specific board.
 *
 * ### Why this exists
 *
 * Pure astronomy gives the true instant of every solar event to well under a second. A printed
 * calendar gives a minute, and which minute depends on the publisher's editorial rules. Chasing
 * that with a single global rounding mode is impossible: for Kazan the Asr column wants
 * truncation, the sunrise column wants truncation of a value already nudged up a minute, and the
 * Isha column sits a minute below the 15° instant. One knob cannot satisfy three columns.
 *
 * With [DUM_RT] the engine reproduces 25 of 28 published values for 15-18 August 2026 exactly,
 * and the remaining 3 are off by exactly one minute — inside the poster's own internal noise
 * (its printed sunrise advances 2, 2, 1 minutes across those days where the true rate is a
 * uniform 1.93).
 */
enum class CalendarConvention(val title: String, val explanation: String) {

    /** No editorial correction: the true astronomical instant, rounded the way the user asked. */
    ASTRONOMICAL(
        "Чистая астрономия",
        "Истинный момент события, округление по вашему выбору"
    ),

    /**
     * Spiritual Boards of Russia / Tatarstan, as printed.
     *
     * Calibrated on Казань, 15-18.08.2026 against "Ике атнага намаз уку тәртибе":
     * Сәхәр тәмам, Мәчетләрдә укыла, Кояш чыга, Зәвәл, Икенде, Ахшам, Ястү.
     */
    DUM_RT(
        "Как в календаре ДУМ РТ / ДУМ РФ",
        "Совпадает с печатной таблицей мечети, расхождение не более минуты"
    );

    fun policy(prayer: Prayer, userRounding: RoundingMode): MarkerPolicy = when (this) {
        ASTRONOMICAL -> MarkerPolicy(userRounding, 0)
        DUM_RT -> DUM_RT_POLICIES[prayer] ?: MarkerPolicy(RoundingMode.DOWN, 0)
    }
}

/**
 * Fitted numerically, not guessed. Objective: minimise the worst-case error first, then the
 * total error, over every published column of the Kazan poster.
 */
private val DUM_RT_POLICIES: Map<Prayer, MarkerPolicy> = mapOf(
    Prayer.SAHAR to MarkerPolicy(RoundingMode.NEAREST, +1),
    Prayer.SUNRISE to MarkerPolicy(RoundingMode.DOWN, +1),
    Prayer.DHUHR to MarkerPolicy(RoundingMode.DOWN, 0),
    Prayer.ASR to MarkerPolicy(RoundingMode.DOWN, 0),
    Prayer.MAGHRIB to MarkerPolicy(RoundingMode.NEAREST, -1),
    Prayer.ISHA to MarkerPolicy(RoundingMode.DOWN, -1)
)
