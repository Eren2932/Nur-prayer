package com.nur.prayer.notify

import com.nur.prayer.core.astro.Prayer

object PrayerLabels {
    fun title(prayer: Prayer): String = when (prayer) {
        Prayer.SAHAR -> "Сухур"
        Prayer.FAJR -> "Фаджр"
        Prayer.SUNRISE -> "Восход"
        Prayer.DHUHR -> "Зухр"
        Prayer.ASR -> "Аср"
        Prayer.MAGHRIB -> "Магриб"
        Prayer.ISHA -> "Иша"
    }

    fun arabic(prayer: Prayer): String = when (prayer) {
        Prayer.SAHAR -> "السحور"
        Prayer.FAJR -> "الفجر"
        Prayer.SUNRISE -> "الشروق"
        Prayer.DHUHR -> "الظهر"
        Prayer.ASR -> "العصر"
        Prayer.MAGHRIB -> "المغرب"
        Prayer.ISHA -> "العشاء"
    }

    fun hint(prayer: Prayer): String = when (prayer) {
        Prayer.SAHAR -> "Конец сухура, начало поста"
        Prayer.FAJR -> "Утренний намаз, читают в мечетях"
        Prayer.SUNRISE -> "Конец времени Фаджра"
        Prayer.DHUHR -> "Полуденный намаз"
        Prayer.ASR -> "Послеполуденный намаз"
        Prayer.MAGHRIB -> "Вечерний намаз, ифтар"
        Prayer.ISHA -> "Ночной намаз"
    }
}
