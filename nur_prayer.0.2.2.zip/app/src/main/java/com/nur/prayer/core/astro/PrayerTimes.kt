package com.nur.prayer.core.astro

import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import kotlin.math.roundToLong

/**
 * Where a value ultimately came from. Surfaced in the UI so that a printed minute is never magic.
 */
enum class TimeSource {
    /** True solar depression angle. The normal, correct case. */
    ANGLE,

    /** The method itself defines Isha as a fixed interval after sunset (Umm al-Qura, Qatar). */
    METHOD_INTERVAL,

    /** Angle unreachable: fixed interval around sunrise / sunset, the way DUM RF and DUM RT print it. */
    FIXED_INTERVAL,

    /** Angle unreachable: a fraction of the night. */
    NIGHT_FRACTION,

    /** Pulled back to the middle of the night so the daily order stays sane. */
    MIDNIGHT_BOUND,

    /** Congregational time derived from the published sunrise minus a fixed gap. */
    CONGREGATION,

    /** Congregational gap would fall before dawn, so dawn itself was used. */
    DAWN_BOUND
}

/**
 * Prayer times for one calendar day at one location.
 *
 * ### Pipeline, in order, and why the order is load-bearing
 *
 * 1. **Astronomy.** Every solar marker is computed as an exact instant. Nothing is rounded,
 *    nothing is clamped.
 * 2. **High-latitude fallback.** Consulted *only* for a marker that came back undefined, i.e. on
 *    a night when the Sun never sinks to the requested depression angle. It is a fallback, never a
 *    cap. Applying it as a cap was the bug that put Isha in Kazan at 20:37 instead of 21:36 and
 *    silently made every calculation method produce identical output.
 * 3. **Publication.** Method correction, user correction and the [CalendarConvention] offset are
 *    added, then the value is rounded with that column's own rounding mode.
 * 4. **Derived markers.** Congregational [Prayer.FAJR] is computed from the *published* sunrise,
 *    not from the raw instant. This matters: the mosque column of the printed calendar is exactly
 *    the printed sunrise minus 90 minutes, so deriving it from the unrounded value would drift a
 *    minute away on half the days of the year.
 * 5. **Order.** A strictly increasing sequence is enforced last.
 */
class PrayerTimes(
    val date: LocalDate,
    val coordinates: Coordinates,
    val params: PrayerParams
) {
    val times: Map<Prayer, Instant?>

    /** True when Sahar and/or Isha had to be derived from something other than the angle. */
    val usedHighLatitudeRule: Boolean

    /** Provenance of the markers that can need help. */
    val saharSource: TimeSource
    val ishaSource: TimeSource
    val fajrSource: TimeSource

    /** Length of the night following [date], null in the polar case. */
    val night: Duration?

    init {
        val solar = SolarTime.of(date, coordinates)
        val tomorrowSolar = SolarTime.of(date.plusDays(1), coordinates)
        val base = date.atStartOfDay(ZoneOffset.UTC).toInstant()
        val tomorrowBase = date.plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant()

        fun hoursToInstant(from: Instant, hours: Double): Instant? =
            if (hours.isNaN() || hours.isInfinite()) null
            else from.plusMillis((hours * 3600_000.0).roundToLong())

        val sunriseTime = hoursToInstant(base, solar.sunrise)
        val sunsetTime = hoursToInstant(base, solar.sunset)
        val transitTime = hoursToInstant(base, solar.transit)
        val tomorrowSunrise = hoursToInstant(tomorrowBase, tomorrowSolar.sunrise)

        val method = params.method

        // ---- Step 1: pure astronomy -------------------------------------------------------
        var saharTime = hoursToInstant(base, solar.hourAngle(-method.fajrAngle, afterTransit = false))
        var saharFrom = TimeSource.ANGLE

        var asrTime = hoursToInstant(base, solar.afternoon(params.madhab.shadowLength))

        val maghribTime = if (method.maghribAngle > 0.0) {
            hoursToInstant(base, solar.hourAngle(-method.maghribAngle, afterTransit = true)) ?: sunsetTime
        } else {
            sunsetTime
        }

        var ishaTime: Instant?
        var ishaFrom: TimeSource
        // Interval-defined markers are recomputed from the published anchor in step 4; the raw
        // value here only exists so the fallback logic and the ordering pass have something real
        // to compare against.
        var saharBeforeSunrise: Int? = null
        var ishaAfterSunset: Int? = null
        if (method.ishaIntervalMinutes > 0) {
            ishaTime = sunsetTime?.plusSeconds(method.ishaIntervalMinutes * 60L)
            ishaAfterSunset = method.ishaIntervalMinutes
            ishaFrom = TimeSource.METHOD_INTERVAL
        } else {
            ishaTime = hoursToInstant(base, solar.hourAngle(-method.ishaAngle, afterTransit = true))
            ishaFrom = TimeSource.ANGLE
        }

        // ---- Step 2: help only where astronomy came back empty -----------------------------
        var nightLength: Duration? = null
        if (sunriseTime != null && sunsetTime != null && tomorrowSunrise != null) {
            val nightSpan = Duration.between(sunsetTime, tomorrowSunrise)
            nightLength = nightSpan
            val nightSeconds = nightSpan.seconds
            val rule = params.highLatitudeRule.resolve(coordinates.latitude)

            fun fraction(): Pair<Double, Double> = when (rule) {
                HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> 1.0 / 7.0 to 1.0 / 7.0
                HighLatitudeRule.TWILIGHT_ANGLE ->
                    method.fajrAngle / 60.0 to (if (method.ishaAngle > 0) method.ishaAngle else 17.0) / 60.0
                else -> 0.5 to 0.5
            }

            // The Russian boards treat the short-night season as one regime: the printed calendar
            // carries a single banner, "МЕНЯЕТСЯ ВРЕМЯ СУХУРА И ИША", and moves both markers
            // together rather than letting each one leave on its own day. The season is judged by
            // the Sahar angle — the stricter of the two — over *this* night and the *next* one.
            // That second look reproduces the calendar's own asymmetry: on the last day of the
            // season Isha is already astronomical while Sahar is still an interval, because the
            // night that follows is finally long enough. Verified on 7 August 2026 in Kazan.
            val saharAngleTomorrow = hoursToInstant(
                tomorrowBase,
                tomorrowSolar.hourAngle(-method.fajrAngle, afterTransit = false)
            )
            val shortNightSeason = rule == HighLatitudeRule.FIXED_INTERVAL &&
                saharTime == null && saharAngleTomorrow == null

            if (saharTime == null) {
                if (rule == HighLatitudeRule.FIXED_INTERVAL) {
                    saharTime = sunriseTime.minusSeconds(method.nightFajrMinutes * 60L)
                    saharBeforeSunrise = method.nightFajrMinutes
                    saharFrom = TimeSource.FIXED_INTERVAL
                } else {
                    saharTime = sunriseTime.minusSeconds((nightSeconds * fraction().first).roundToLong())
                    saharFrom = TimeSource.NIGHT_FRACTION
                }
            }
            if (ishaTime == null || (shortNightSeason && ishaFrom == TimeSource.ANGLE)) {
                if (rule == HighLatitudeRule.FIXED_INTERVAL) {
                    ishaTime = sunsetTime.plusSeconds(method.nightIshaMinutes * 60L)
                    ishaAfterSunset = method.nightIshaMinutes
                    ishaFrom = TimeSource.FIXED_INTERVAL
                } else {
                    ishaTime = sunsetTime.plusSeconds((nightSeconds * fraction().second).roundToLong())
                    ishaFrom = TimeSource.NIGHT_FRACTION
                }
            }

            // Absolute bound, always on: neither marker may cross the middle of the night.
            val saharFloor = sunriseTime.minusSeconds(nightSeconds / 2)
            val ishaCeiling = sunsetTime.plusSeconds(nightSeconds / 2)
            saharTime?.let {
                if (it.isBefore(saharFloor)) {
                    saharTime = saharFloor; saharFrom = TimeSource.MIDNIGHT_BOUND; saharBeforeSunrise = null
                }
            }
            ishaTime?.let {
                if (it.isAfter(ishaCeiling)) {
                    ishaTime = ishaCeiling; ishaFrom = TimeSource.MIDNIGHT_BOUND; ishaAfterSunset = null
                }
            }
        }

        // Asr can be undefined at high latitudes in winter: the Sun never climbs high enough.
        var asrDegraded = false
        if (asrTime == null) {
            asrTime = hoursToInstant(base, solar.afternoon(Madhab.STANDARD.shadowLength))
            if (asrTime != null) asrDegraded = true
        }
        if (asrTime == null && transitTime != null && maghribTime != null) {
            val span = Duration.between(transitTime, maghribTime).seconds
            asrTime = transitTime.plusSeconds(span * 2 / 3)
            asrDegraded = true
        }

        // ---- Step 3: publication ----------------------------------------------------------
        fun publish(prayer: Prayer, value: Instant?): Instant? {
            if (value == null) return null
            val policy = params.policy(prayer)
            val shifted = value.plusSeconds(
                (params.adjustmentMinutes(prayer) + policy.offsetMinutes) * 60L
            )
            return roundToMinute(shifted, policy.rounding)
        }

        val publishedSunrise = publish(Prayer.SUNRISE, sunriseTime)
        val publishedMaghrib = publish(Prayer.MAGHRIB, maghribTime)

        // An interval marker keeps its exact relationship to the *printed* anchor. The poster says
        // Sahar is sunrise minus 120 minutes and Isha is sunset plus 90; if we derived them from the
        // raw instant, each anchor's own rounding would leak in a second time and the printed gap
        // would come out as 119 or 121 on about half the days of the season.
        val saharGap = saharBeforeSunrise
        val publishedSahar = if (saharGap != null && publishedSunrise != null) {
            publishedSunrise.minusSeconds(saharGap * 60L)
                .plusSeconds(params.adjustmentMinutes(Prayer.SAHAR) * 60L)
        } else {
            publish(Prayer.SAHAR, saharTime)
        }
        val ishaGap = ishaAfterSunset
        val publishedIsha = if (ishaGap != null && publishedMaghrib != null) {
            publishedMaghrib.plusSeconds(ishaGap * 60L)
                .plusSeconds(params.adjustmentMinutes(Prayer.ISHA) * 60L)
        } else {
            publish(Prayer.ISHA, ishaTime)
        }

        // ---- Step 4: congregational Fajr, derived from the published sunrise ---------------
        val gap = params.fajrBeforeSunriseMinutes
        var fajrFrom: TimeSource
        val publishedFajr: Instant? = when {
            publishedSunrise == null || gap == 0 -> {
                fajrFrom = if (gap == 0) TimeSource.ANGLE else saharFrom
                publishedSahar
            }
            else -> {
                val candidate = publishedSunrise.minusSeconds(gap * 60L)
                // Fajr may never precede dawn: at low latitudes the 90 minute gap would do exactly
                // that, and praying before dawn is invalid regardless of what any table says.
                if (publishedSahar != null && candidate.isBefore(publishedSahar)) {
                    fajrFrom = TimeSource.DAWN_BOUND
                    publishedSahar
                } else {
                    fajrFrom = TimeSource.CONGREGATION
                    candidate.plusSeconds(params.adjustmentMinutes(Prayer.FAJR) * 60L)
                }
            }
        }

        saharSource = saharFrom
        ishaSource = ishaFrom
        fajrSource = fajrFrom
        night = nightLength
        usedHighLatitudeRule = asrDegraded ||
            saharFrom != TimeSource.ANGLE ||
            (ishaFrom != TimeSource.ANGLE && ishaFrom != TimeSource.METHOD_INTERVAL)

        val raw = linkedMapOf(
            Prayer.SAHAR to publishedSahar,
            Prayer.FAJR to publishedFajr,
            Prayer.SUNRISE to publishedSunrise,
            Prayer.DHUHR to publish(Prayer.DHUHR, transitTime),
            Prayer.ASR to publish(Prayer.ASR, asrTime),
            Prayer.MAGHRIB to publishedMaghrib,
            Prayer.ISHA to publishedIsha
        )
        times = enforceOrder(raw)
    }

    /** Kept for source compatibility with callers written before Sahar existed. */
    @Deprecated("Use saharSource for dawn or fajrSource for the congregational time")
    val legacyFajrSource: TimeSource get() = saharSource

    /**
     * Guarantees a strictly increasing sequence with at least one minute between markers.
     * The UI and the alarm chain both rely on a strict order.
     */
    private fun enforceOrder(source: Map<Prayer, Instant?>): Map<Prayer, Instant?> {
        val result = LinkedHashMap<Prayer, Instant?>(source)
        val order = listOf(
            Prayer.SAHAR, Prayer.FAJR, Prayer.SUNRISE,
            Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA
        )
        // Sunrise is the hard anchor of the morning: pull Fajr and Sahar back under it if a
        // pathological correction pushed them past it.
        val sunrise = result[Prayer.SUNRISE]
        if (sunrise != null) {
            result[Prayer.FAJR]?.let { if (!it.isBefore(sunrise)) result[Prayer.FAJR] = sunrise.minusSeconds(60) }
            val fajr = result[Prayer.FAJR] ?: sunrise
            result[Prayer.SAHAR]?.let { if (it.isAfter(fajr)) result[Prayer.SAHAR] = fajr }
        }
        var previous: Instant? = null
        for (prayer in order) {
            val value = result[prayer] ?: continue
            val bound = previous
            // Sahar and Fajr are allowed to share a minute: in traditions without a separate
            // congregational time they are genuinely the same instant.
            val mustBeStrictlyAfter = !(prayer == Prayer.FAJR && bound == result[Prayer.SAHAR])
            if (bound != null && mustBeStrictlyAfter && !value.isAfter(bound)) {
                result[prayer] = bound.plusSeconds(60)
            } else if (bound != null && value.isBefore(bound)) {
                result[prayer] = bound
            }
            previous = result[prayer]
        }
        return result
    }

    val isComplete: Boolean get() = times.values.none { it == null }

    private fun roundToMinute(instant: Instant, mode: RoundingMode): Instant {
        val seconds = instant.epochSecond
        val remainder = ((seconds % 60) + 60) % 60
        val floor = seconds - remainder
        val result = when (mode) {
            RoundingMode.DOWN -> floor
            RoundingMode.UP -> if (remainder == 0L) floor else floor + 60
            RoundingMode.NEAREST -> if (remainder >= 30L) floor + 60 else floor
        }
        return Instant.ofEpochSecond(result)
    }
}
