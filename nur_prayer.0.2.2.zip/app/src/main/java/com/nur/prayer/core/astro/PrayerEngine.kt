package com.nur.prayer.core.astro

import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Resolved prayer times for one local day. */
data class PrayerDay(
    val date: LocalDate,
    val times: Map<Prayer, ZonedDateTime>,
    /** Explanation shown to the user when the day needed a special rule. */
    val note: String? = null,
    /** Where the end of suhoor came from: real angle, or a high-latitude substitute. */
    val saharSource: TimeSource = TimeSource.ANGLE,
    /** Where congregational Fajr came from. */
    val fajrSource: TimeSource = TimeSource.ANGLE,
    /** Where Isha came from. */
    val ishaSource: TimeSource = TimeSource.ANGLE
) {
    fun at(prayer: Prayer): ZonedDateTime = times.getValue(prayer)
}

/** The prayer that is running now, and the one coming next. */
data class PrayerWindow(
    val current: Prayer,
    val currentStart: ZonedDateTime,
    val next: Prayer,
    val nextStart: ZonedDateTime
) {
    fun progress(now: ZonedDateTime): Float {
        val total = Duration.between(currentStart, nextStart).seconds.toDouble()
        if (total <= 0) return 0f
        val done = Duration.between(currentStart, now).seconds.toDouble()
        return (done / total).coerceIn(0.0, 1.0).toFloat()
    }

    fun remaining(now: ZonedDateTime): Duration {
        val d = Duration.between(now, nextStart)
        return if (d.isNegative) Duration.ZERO else d
    }
}

/**
 * Public entry point for everything time related.
 * Handles polar day / polar night by falling back to the nearest day of the year where a real
 * night exists ("Aqrab al-Ayyam", the closest-days method).
 */
object PrayerEngine {

    private data class DayKey(
        val date: LocalDate,
        val coordinates: Coordinates,
        val zone: ZoneId,
        val params: PrayerParams
    )

    /**
     * One [PrayerDay] costs six full solar-coordinate evaluations, and the screens ask for the
     * same day over and over: the home card, the countdown, the fourteen-day schedule and the
     * alarm scheduler all walk overlapping ranges, and [window] alone re-reads three days on every
     * settings change. Without this cache the app recomputed the same trigonometry dozens of times
     * per interaction, which is what made the lists stutter.
     *
     * Bounded LRU, guarded by its own lock. Anything keyed on [PrayerParams] invalidates itself the
     * moment the user changes a setting, because the key is a data class.
     */
    private const val CACHE_LIMIT = 256
    private val cache = object : LinkedHashMap<DayKey, PrayerDay>(CACHE_LIMIT, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<DayKey, PrayerDay>): Boolean =
            size > CACHE_LIMIT
    }
    private val cacheLock = Any()

    fun day(
        date: LocalDate,
        coordinates: Coordinates,
        zone: ZoneId,
        params: PrayerParams
    ): PrayerDay {
        val key = DayKey(date, coordinates, zone, params)
        synchronized(cacheLock) { cache[key] }?.let { return it }
        val computed = computeDay(date, coordinates, zone, params)
        synchronized(cacheLock) { cache[key] = computed }
        return computed
    }

    private fun computeDay(
        date: LocalDate,
        coordinates: Coordinates,
        zone: ZoneId,
        params: PrayerParams
    ): PrayerDay {
        val direct = PrayerTimes(date, coordinates, params)
        if (direct.isComplete) {
            val times = direct.times.mapValues { (_, instant) ->
                instant!!.atZone(zone)
            }
            return PrayerDay(
                date = date,
                times = times,
                note = noteFor(direct),
                saharSource = direct.saharSource,
                fajrSource = direct.fajrSource,
                ishaSource = direct.ishaSource
            )
        }

        // Polar day or polar night: borrow the daily rhythm of the nearest valid day.
        for (offset in 1..183) {
            for (signed in listOf(-offset, offset)) {
                val candidateDate = date.plusDays(signed.toLong())
                val candidate = PrayerTimes(candidateDate, coordinates, params)
                if (candidate.isComplete) {
                    val times = candidate.times.mapValues { (_, instant) ->
                        val localTime = instant!!.atZone(zone).toLocalTime()
                        date.atTime(localTime).atZone(zone)
                    }
                    return PrayerDay(
                        date,
                        normalizeOrder(date, zone, times),
                        "Полярный день/ночь: расчёт по методу «Акраб аль-Айям» (ближайший день с ночью — " +
                            "${candidateDate.dayOfMonth}.${candidateDate.monthValue})"
                    )
                }
            }
        }
        error("Unable to compute prayer times for $date at $coordinates")
    }

    /** Plain-language explanation of any day that needed help, null on an ordinary day. */
    private fun noteFor(times: PrayerTimes): String? {
        val reasons = mutableListOf<String>()
        when (times.saharSource) {
            TimeSource.FIXED_INTERVAL ->
                reasons += "Сухур: солнце не опускается до ${times.params.method.fajrAngle}°, " +
                    "взят интервал восход − ${times.params.method.nightFajrMinutes} мин"
            TimeSource.NIGHT_FRACTION -> reasons += "Сухур: по доле ночи (короткая ночь)"
            TimeSource.MIDNIGHT_BOUND -> reasons += "Сухур: ограничен серединой ночи"
            else -> Unit
        }
        when (times.fajrSource) {
            TimeSource.CONGREGATION ->
                reasons += "Фаджр: время мечети, восход − ${times.params.fajrBeforeSunriseMinutes} мин"
            TimeSource.DAWN_BOUND -> reasons += "Фаджр: совпал с рассветом (интервал мечети раньше рассвета)"
            else -> Unit
        }
        when (times.ishaSource) {
            TimeSource.FIXED_INTERVAL ->
                reasons += "Иша: солнце не опускается до ${times.params.method.ishaAngle}°, " +
                    "взят интервал закат + ${times.params.method.nightIshaMinutes} мин"
            TimeSource.NIGHT_FRACTION -> reasons += "Иша: по доле ночи (короткая ночь)"
            TimeSource.MIDNIGHT_BOUND -> reasons += "Иша: ограничена серединой ночи"
            else -> Unit
        }
        if (reasons.isEmpty()) return null
        return reasons.joinToString(" · ")
    }

    private fun normalizeOrder(
        date: LocalDate,
        zone: ZoneId,
        times: Map<Prayer, ZonedDateTime>
    ): Map<Prayer, ZonedDateTime> {
        // Keep the sequence monotonic, pushing wrapped values (e.g. Isha after midnight) to next day.
        val result = LinkedHashMap<Prayer, ZonedDateTime>()
        var previous: ZonedDateTime? = null
        for (prayer in Prayer.entries) {
            var value = times.getValue(prayer)
            val p = previous
            if (p != null && value.isBefore(p)) value = value.plusDays(1)
            result[prayer] = value
            previous = value
        }
        if (result.getValue(Prayer.FAJR).toLocalDate() != date) {
            // Nothing sensible to do, keep as computed.
        }
        return result
    }

    fun days(
        from: LocalDate,
        count: Int,
        coordinates: Coordinates,
        zone: ZoneId,
        params: PrayerParams
    ): List<PrayerDay> = (0 until count).map { day(from.plusDays(it.toLong()), coordinates, zone, params) }

    /** Chronological list of prayer moments from [from] over [days] days. */
    fun schedule(
        from: LocalDate,
        days: Int,
        coordinates: Coordinates,
        zone: ZoneId,
        params: PrayerParams
    ): List<Pair<Prayer, ZonedDateTime>> =
        days(from, days, coordinates, zone, params)
            .flatMap { d -> d.times.map { (prayer, time) -> prayer to time } }
            .sortedBy { it.second }

    /** Which prayer is running right now, and what comes next. */
    fun window(
        now: ZonedDateTime,
        coordinates: Coordinates,
        zone: ZoneId,
        params: PrayerParams
    ): PrayerWindow {
        val moments = schedule(now.toLocalDate().minusDays(1), 3, coordinates, zone, params)
        val nextIndex = moments.indexOfFirst { it.second.isAfter(now) }
        val index = if (nextIndex <= 0) 1 else nextIndex
        val (currentPrayer, currentStart) = moments[index - 1]
        val (nextPrayer, nextStart) = moments[index]
        return PrayerWindow(currentPrayer, currentStart, nextPrayer, nextStart)
    }

    /** Upcoming prayer moments after [now], used by the alarm scheduler. */
    fun upcoming(
        now: ZonedDateTime,
        coordinates: Coordinates,
        zone: ZoneId,
        params: PrayerParams,
        limit: Int = 24
    ): List<Pair<Prayer, ZonedDateTime>> =
        schedule(now.toLocalDate(), 3, coordinates, zone, params)
            .filter { it.second.isAfter(now) }
            .take(limit)
}
