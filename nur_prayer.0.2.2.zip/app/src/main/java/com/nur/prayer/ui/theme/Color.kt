package com.nur.prayer.ui.theme

import androidx.compose.ui.graphics.Color
import com.nur.prayer.core.astro.Prayer

val Ink = Color(0xFF04060F)
val InkSoft = Color(0xFF0A0E1C)
val Gold = Color(0xFFE9C46A)
val GoldSoft = Color(0xFFF7E6B8)
val Mint = Color(0xFF6FE3C0)
val Violet = Color(0xFF8C7BF5)
val Azure = Color(0xFF4FA8F5)
val Amber = Color(0xFFF2A65A)
val Rose = Color(0xFFF07C8C)
val Crimson = Color(0xFFD9536B)

val TextPrimary = Color(0xFFF3F5FF)
val TextSecondary = Color(0xFFA7AECB)
val TextTertiary = Color(0xFF737B99)

/**
 * The sky of the app. It is a real atmospheric stack, not two glowing circles:
 * zenith -> mid air -> horizon haze, an aurora built from two ribbon colours, and a star budget.
 * Every prayer phase re-paints all of it.
 */
data class PhasePalette(
    /** Top of the sky, the darkest band. */
    val zenith: Color,
    /** Middle air. */
    val mid: Color,
    /** Horizon haze at the very bottom. */
    val horizon: Color,
    /** Wide, shallow atmospheric glow sitting on the horizon. */
    val glow: Color,
    val ribbonA: Color,
    val ribbonB: Color,
    val accent: Color,
    val accentSoft: Color,
    /** 0 = daylight, no stars; 1 = deep night. */
    val starIntensity: Float,
    /** How strong the aurora ribbons are, 0..1. */
    val auroraIntensity: Float,
    val name: String
)

fun paletteFor(prayer: Prayer): PhasePalette = when (prayer) {
    // Pre-dawn: deep indigo with the first violet lift on the horizon.
    Prayer.SAHAR, Prayer.FAJR -> PhasePalette(
        zenith = Color(0xFF04050F),
        mid = Color(0xFF0B0F2A),
        horizon = Color(0xFF241A45),
        glow = Color(0xFF7A5CE0),
        ribbonA = Color(0xFF6C5CE7),
        ribbonB = Color(0xFF3B7BD8),
        accent = Violet,
        accentSoft = Color(0xFFC9C1FF),
        starIntensity = 0.85f,
        auroraIntensity = 0.85f,
        name = "Рассвет"
    )
    // Sunrise: warm amber flooding the horizon, stars gone.
    Prayer.SUNRISE -> PhasePalette(
        zenith = Color(0xFF091634),
        mid = Color(0xFF1B2B52),
        horizon = Color(0xFF6B3A3C),
        glow = Color(0xFFF2A65A),
        ribbonA = Color(0xFFF2A65A),
        ribbonB = Color(0xFFEE7B93),
        accent = Amber,
        accentSoft = Color(0xFFFFD8A8),
        starIntensity = 0.18f,
        auroraIntensity = 0.35f,
        name = "Восход"
    )
    // Noon: clean high-altitude blue.
    Prayer.DHUHR -> PhasePalette(
        zenith = Color(0xFF061A3A),
        mid = Color(0xFF0E2E58),
        horizon = Color(0xFF1E5C86),
        glow = Color(0xFF6FC6FF),
        ribbonA = Color(0xFF4FA8F5),
        ribbonB = Color(0xFF6FE3C0),
        accent = Azure,
        accentSoft = Color(0xFFB6DCFF),
        starIntensity = 0f,
        auroraIntensity = 0.28f,
        name = "Полдень"
    )
    // Afternoon: the light turns golden and the air gets dusty.
    Prayer.ASR -> PhasePalette(
        zenith = Color(0xFF091830),
        mid = Color(0xFF16294A),
        horizon = Color(0xFF4A4363),
        glow = Color(0xFFE9C46A),
        ribbonA = Color(0xFF7FB2F0),
        ribbonB = Color(0xFFE9C46A),
        accent = Gold,
        accentSoft = GoldSoft,
        starIntensity = 0.05f,
        auroraIntensity = 0.32f,
        name = "Предвечерье"
    )
    // Sunset: crimson horizon under a night that is already arriving at the zenith.
    Prayer.MAGHRIB -> PhasePalette(
        zenith = Color(0xFF0A0A1E),
        mid = Color(0xFF251434),
        horizon = Color(0xFF6E2338),
        glow = Color(0xFFFF8A5C),
        ribbonA = Color(0xFFD9536B),
        ribbonB = Color(0xFFF2A65A),
        accent = Crimson,
        accentSoft = Color(0xFFFFC0A8),
        starIntensity = 0.55f,
        auroraIntensity = 0.7f,
        name = "Закат"
    )
    // Night: near-black with a cold teal aurora and a full star field.
    Prayer.ISHA -> PhasePalette(
        zenith = Color(0xFF02030A),
        mid = Color(0xFF070C1C),
        horizon = Color(0xFF10203A),
        glow = Color(0xFF2E6E7E),
        ribbonA = Color(0xFF3D4CB8),
        ribbonB = Color(0xFF1D8F8F),
        accent = Mint,
        accentSoft = Color(0xFFB9FFEA),
        starIntensity = 1f,
        auroraIntensity = 1f,
        name = "Ночь"
    )
}
