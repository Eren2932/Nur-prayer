package com.nur.prayer

import com.nur.prayer.ui.home.HomeSection
import com.nur.prayer.ui.shell.ShellMath
import com.nur.prayer.ui.shell.ShellRoutes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.27.0 «Капсула»: the arithmetic of the morph and which page shows the capsule and the island. */
class ShellMathTest {
    @Test fun capsuleContentLeavesBeforeThePanelArrives() {
        assertEquals(1f, ShellMath.capsuleAlpha(0f), 0f)
        assertEquals(0f, ShellMath.capsuleAlpha(0.3f), 1e-6f)
        assertEquals(0f, ShellMath.panelAlpha(0.28f), 1e-6f)
        assertEquals(1f, ShellMath.panelAlpha(0.8f), 1e-6f)
        // Never both at full strength: no frame shows two layers of text on top of each other.
        var p = 0f
        while (p <= 1.03f) {
            assertTrue(ShellMath.capsuleAlpha(p) + ShellMath.panelAlpha(p) <= 1.0001f)
            p += 0.01f
        }
    }

    @Test fun springOvershootIsBounded() {
        assertEquals(1.03f, ShellMath.clampProgress(1.4f), 0f)
        assertEquals(0f, ShellMath.clampProgress(-0.2f), 0f)
    }

    @Test fun capsuleWidthIsTwoThirdsWithinBounds() {
        assertEquals(0.68f * 1080f, ShellMath.capsuleWidth(1080f, 600f, 1200f, 40f), 1e-3f)
        assertEquals(600f, ShellMath.capsuleWidth(500f, 600f, 1200f, 40f), 0f)
        assertEquals(1200f, ShellMath.capsuleWidth(4000f, 600f, 1200f, 40f), 0f)
    }

    @Test fun clockLiftsOnlyAsFarAsNeededAndNeverIntoTheHeader() {
        // Fits already: no lift.
        assertEquals(0f, ShellMath.clockLift(300f, 500f, 900f, 20f, 100f), 0f)
        // Overlaps by 120 (bottom 800, panel top 700 - gap 20 = 680).
        assertEquals(120f, ShellMath.clockLift(400f, 800f, 700f, 20f, 100f), 0f)
        // Would need 500 but only 300 of room under the header.
        assertEquals(300f, ShellMath.clockLift(400f, 1200f, 700f, 20f, 100f), 0f)
        // Panel not measured yet.
        assertEquals(0f, ShellMath.clockLift(400f, 800f, Float.NaN, 20f, 100f), 0f)
    }

    @Test fun everyGridSectionOpensAPageAndThatPageNamesItsSection() {
        HomeSection.GRID.forEach { section ->
            val route = ShellRoutes.routeOf(section)!!
            assertEquals(section, ShellRoutes.sectionOf(route))
            assertTrue(ShellRoutes.capsuleOn(route))
        }
        assertNull(ShellRoutes.routeOf(HomeSection.SETTINGS))
        assertEquals(6, HomeSection.GRID.size)
    }

    @Test fun capsuleAndIslandPlacement() {
        assertTrue(ShellRoutes.capsuleOn("home"))
        assertFalse(ShellRoutes.islandOn("home"))
        assertTrue(ShellRoutes.islandOn("qibla"))
        // Paper pages keep the capsule but not the island over their own header.
        assertTrue(ShellRoutes.capsuleOn("quran"))
        assertFalse(ShellRoutes.islandOn("quran"))
        // Pages with their own way out: neither.
        listOf("settings", "city", "lesson", "story").forEach {
            assertFalse(ShellRoutes.capsuleOn(it))
            assertFalse(ShellRoutes.islandOn(it))
        }
    }
}
