package com.nur.prayer.ui.shell

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.home.PrayerSheet
import java.time.ZonedDateTime

/*
 * 0.27.0: the sheet of one prayer (its window, azan, sound) lives above every page, not inside
 * home: a time on the wallpaper and a time card in the panel open the same sheet, also from inside
 * a section. [prayer] is hoisted (saveable) in NurRoot; null closes the sheet.
 *
 * Driven by a Reveal as before: a finger and an animation move the same number, only draw reads it.
 */
private val SheetScrim = Color(0x8C000000)

@Composable
fun PrayerSheetHost(
    prayer: Prayer?,
    data: PrayerData,
    now: State<ZonedDateTime>,
    actions: AppActions,
    notificationsAllowed: Boolean,
    exactAlarmsAllowed: Boolean,
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val sheet = remember { Reveal(initiallyOpen = prayer != null) }
    BackHandler(enabled = prayer != null) { onDismiss() }
    LaunchedEffect(prayer != null) {
        if (prayer != null) {
            // Let the heavy first composition of the sheet land before the clock of the slide starts.
            withFrameNanos { }
            withFrameNanos { }
            sheet.settle(true)
        } else {
            sheet.settle(false)
        }
    }
    val onScreen by remember(prayer != null) { derivedStateOf { prayer != null || sheet.progress > 0f } }
    // The sheet keeps rendering the last prayer while it slides away; a plain holder, not state.
    val last = remember { arrayOfNulls<Prayer>(1) }
    if (prayer != null) last[0] = prayer
    if (!onScreen) return
    Box(Modifier.fillMaxSize().onSizeChanged { sheet.extentPx = it.height.toFloat() }) {
        Box(
            Modifier
                .fillMaxSize()
                .drawBehind { drawRect(SheetScrim, alpha = sheet.progress) }
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClickLabel = tr("Закрыть"),
                    onClick = onDismiss
                )
        )
        Box(Modifier.fillMaxSize().graphicsLayer { translationY = (1f - sheet.progress) * size.height }) {
            PrayerSheet(
                data = data,
                initial = last[0] ?: Prayer.FAJR,
                now = now,
                actions = actions,
                notificationsAllowed = notificationsAllowed,
                exactAlarmsAllowed = exactAlarmsAllowed,
                onDismiss = onDismiss,
                onOpenSettings = onOpenSettings,
                motion = sheet
            )
        }
    }
}
