package com.nur.prayer.ui.shell

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.Amber
import com.nur.prayer.ui.wallpaper.PAGE_DIM
import com.nur.prayer.ui.wallpaper.Wallpaper
import com.nur.prayer.ui.wallpaper.WallpaperImages
import com.nur.prayer.ui.wallpaper.WallpaperScreen
import com.nur.prayer.ui.wallpaper.drawWallpaperIn

/*
 * 0.27.0 «Капсула»: the matte glass of the capsule, the panel and the island.
 *
 * Under the glass lies the wallpaper itself, blurred (WallpaperImages.frost) and drawn exactly where
 * the sharp picture is on screen, darkened as much as the page darkens it; over it a deep navy tint
 * that is a little lighter at the top, a hairline edge that catches light at the top and fades
 * towards the bottom, and a soft shadow. On «Живое небо» and «Чёрный» there is no picture to blur:
 * the tint alone, nearly opaque.
 */

/** What the glass shows through: the wallpaper on screen and how much the current page darkens it. */
@Stable
class FrostSource(val wallpaper: () -> Wallpaper, val dim: () -> Float)

val LocalFrost = staticCompositionLocalOf<FrostSource?> { null }

/** The colours of the mock, measured: glass, cards, wells, the gold of «now». */
object ShellColors {
    val TintTop = Color(0xFF161B29)
    val TintBottom = Color(0xFF0E101C)
    const val TINT_TOP_ALPHA = 0.72f
    const val TINT_BOTTOM_ALPHA = 0.82f
    const val TINT_PLAIN_ALPHA = 0.90f
    val EdgeTop = Color(0x3DFFFFFF)
    val EdgeBottom = Color(0x14FFFFFF)
    val Card = Color(0x17FFFFFF)
    val CardPressed = Color(0x29FFFFFF)
    val Well = Color(0x21FFFFFF)
    val Divider = Color(0x24FFFFFF)
    val Gold = Amber
    val GoldCard = Color(0xFFE2B572)
    val OnGold = Color(0xFF261A09)
    val Secondary = Color(0xFFC9CAD6)
}

/** One handle per glass surface: the blurred picture and where on screen the surface is. */
@Stable
class FrostHandle internal constructor(internal val source: FrostSource?) {
    internal var bitmap by mutableStateOf<ImageBitmap?>(null)
    internal var wallpaper by mutableStateOf<Wallpaper?>(null)
    internal var originInRoot by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberFrost(): FrostHandle {
    val source = LocalFrost.current
    val handle = remember(source) { FrostHandle(source) }
    val context = LocalContext.current
    val wallpaper = source?.wallpaper?.invoke()
    val screen by WallpaperScreen.size
    LaunchedEffect(handle, wallpaper?.id, screen) {
        handle.wallpaper = wallpaper
        if (wallpaper == null || !wallpaper.isImage) {
            handle.bitmap = null
            return@LaunchedEffect
        }
        handle.bitmap = WallpaperImages.peekFrost(wallpaper, screen.width, screen.height)
            ?: WallpaperImages.frost(context, wallpaper, screen.width, screen.height)
    }
    return handle
}

/**
 * Paints the glass behind the content of this element. Read only while drawing: a panel that
 * changes size every frame redraws, it does not recompose.
 */
fun Modifier.frostGlass(
    frost: FrostHandle,
    shape: Shape,
    elevation: Dp = 18.dp,
    edge: Boolean = true
): Modifier = this
    .shadow(elevation, shape, clip = false, ambientColor = Color.Black, spotColor = Color.Black)
    .onGloballyPositioned { frost.originInRoot = it.positionInRoot() }
    .drawBehind {
        val outline = shape.createOutline(size, layoutDirection, this)
        val path = outlinePath(outline)
        val bitmap = frost.bitmap
        val wallpaper = frost.wallpaper
        val screen = WallpaperScreen.size.value
        val picture = bitmap != null && wallpaper != null && screen.width > 0
        if (picture) {
            clipPath(path) {
                val o = frost.originInRoot
                translate(-o.x, -o.y) {
                    drawWallpaperIn(bitmap!!, wallpaper!!, screen.width.toFloat(), screen.height.toFloat(), FilterQuality.Low)
                }
                val dim = (frost.source?.dim?.invoke() ?: 0f).coerceIn(0f, 1f) * PAGE_DIM
                if (dim > 0.001f) drawRect(Color.Black.copy(alpha = dim))
            }
        }
        val top = if (picture) ShellColors.TINT_TOP_ALPHA else ShellColors.TINT_PLAIN_ALPHA
        val bottom = if (picture) ShellColors.TINT_BOTTOM_ALPHA else ShellColors.TINT_PLAIN_ALPHA
        drawOutline(
            outline,
            Brush.verticalGradient(
                0f to ShellColors.TintTop.copy(alpha = top),
                1f to ShellColors.TintBottom.copy(alpha = bottom)
            )
        )
        if (edge) {
            val w = 1.dp.toPx()
            // A hairline that catches the light at the top and fades towards the bottom.
            drawOutline(
                outline,
                Brush.verticalGradient(0f to ShellColors.EdgeTop, 0.55f to ShellColors.EdgeBottom, 1f to ShellColors.EdgeBottom),
                style = Stroke(width = w)
            )
        }
    }

private fun outlinePath(outline: Outline): Path = when (outline) {
    is Outline.Generic -> outline.path
    is Outline.Rounded -> Path().apply { addRoundRect(outline.roundRect) }
    is Outline.Rectangle -> Path().apply { addRect(outline.rect) }
}
