package com.nur.prayer.ui.shell

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf

/*
 * 0.27.0 «Капсула»: the one object all navigation lives in.
 *
 * Closed, it is a capsule in reach of the thumb; open, the same glass is the panel (the times of
 * the day and the sections). Not two views swapping: one surface whose bounds move between the two
 * (shared bounds), driven by one number, [progress]: 0 is the capsule, 1 the panel. Only layout and
 * draw read it, so the morph never recomposes. A spring, so a tap mid-way turns it around smoothly.
 *
 * Not saveable on purpose: an open panel must not greet the user after a return.
 */
@Stable
class ShellState {
    var open by mutableStateOf(false)
        private set
    private val morph = Animatable(0f)
    val progress: Float get() = morph.value

    /** Bottom edge of the glass in root px: the capsule and the panel share it (the panel grows upwards). */
    var glassBottomInRoot by mutableFloatStateOf(Float.NaN)
    /** Height of the open panel in px, measured on the first frame of opening (NaN before). */
    var panelHeightPx by mutableFloatStateOf(Float.NaN)

    /** Where the top of the fully open panel will be, known from the first frame: home lifts its clock above it. */
    val panelTopInRoot: Float get() = glassBottomInRoot - panelHeightPx

    fun show() { open = true }
    fun hide() { open = false }

    suspend fun settle() {
        if (open) morph.animateTo(1f, spring(dampingRatio = ShellMath.OPEN_DAMPING, stiffness = ShellMath.OPEN_STIFFNESS))
        else morph.animateTo(0f, spring(dampingRatio = 1f, stiffness = ShellMath.CLOSE_STIFFNESS))
    }

    suspend fun snap() { morph.snapTo(if (open) 1f else 0f) }
}

val LocalShell = staticCompositionLocalOf<ShellState?> { null }

/** The arithmetic of the morph, kept pure for ShellMathTest. */
object ShellMath {
    const val OPEN_DAMPING = 0.84f
    const val OPEN_STIFFNESS = 380f
    const val CLOSE_STIFFNESS = 520f

    /** The spring may overshoot a little; the glass may grow a hair past the panel, never further. */
    fun clampProgress(p: Float): Float = p.coerceIn(0f, 1.03f)

    fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    /** The capsule's own content leaves in the first third of the way. */
    fun capsuleAlpha(p: Float): Float = (1f - p / 0.3f).coerceIn(0f, 1f)

    /** The panel's content arrives once the glass has room for it. */
    fun panelAlpha(p: Float): Float = ((p - 0.28f) / 0.52f).coerceIn(0f, 1f)

    /** Width of the closed capsule: about two thirds of the screen, as in the mock, within reason. */
    fun capsuleWidth(screen: Float, min: Float, max: Float, margin: Float): Float =
        (screen * 0.68f).coerceIn(min, maxOf(min, minOf(max, screen - 2 * margin)))

    /**
     * How far home lifts its clock when the panel opens: just enough that the shrunken digits end
     * [gap] above the panel, never above [ceiling] (the header). 0 when it already fits.
     */
    fun clockLift(clockTop: Float, clockBottomScaled: Float, panelTop: Float, gap: Float, ceiling: Float): Float {
        if (panelTop.isNaN()) return 0f
        val need = clockBottomScaled - (panelTop - gap)
        val room = (clockTop - ceiling).coerceAtLeast(0f)
        return need.coerceIn(0f, room)
    }
}
