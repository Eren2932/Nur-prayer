#!/usr/bin/env python3
"""0.27.0 «Капсула»: a mirror of ShellMath.kt, checked in CI without a JVM.

The Kotlin numbers are read from the source, so the mirror cannot silently drift from it.
"""
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'app/src/main/java/com/nur/prayer/ui/shell/ShellState.kt').read_text()

def num(pattern, what):
    m = re.search(pattern, SRC)
    if not m: sys.exit('check_shell: %s not found in ShellState.kt' % what)
    return float(m.group(1))

CAP_END = num(r'capsuleAlpha\(p: Float\): Float = \(1f - p / ([0-9.]+)f\)', 'capsuleAlpha')
PAN_START = num(r'panelAlpha\(p: Float\): Float = \(\(p - ([0-9.]+)f\)', 'panelAlpha start')
PAN_SPAN = num(r'panelAlpha\(p: Float\): Float = \(\(p - [0-9.]+f\) / ([0-9.]+)f\)', 'panelAlpha span')
OVER = num(r'coerceIn\(0f, ([0-9.]+)f\)', 'clampProgress')
DAMP = num(r'OPEN_DAMPING = ([0-9.]+)f', 'OPEN_DAMPING')

clamp = lambda v: min(max(v, 0.0), 1.0)
cap = lambda p: clamp(1 - p / CAP_END)
pan = lambda p: clamp((p - PAN_START) / PAN_SPAN)

errors = []
# Never two layers of text at once: the capsule is (almost) gone before the panel shows.
worst = max(cap(i / 1000) + pan(i / 1000) for i in range(0, int(OVER * 1000) + 1))
if worst > 1.0001: errors.append('capsule and panel text overlap: %.3f' % worst)
if not (0.2 <= CAP_END <= 0.4): errors.append('capsule text must leave in the first third, got %.2f' % CAP_END)
if not (PAN_START + PAN_SPAN <= 0.9): errors.append('panel text must be fully in before the spring settles')
if not (1.0 < OVER <= 1.05): errors.append('overshoot bound must be small, got %.2f' % OVER)
if not (0.7 <= DAMP < 1.0): errors.append('open spring: a hint of bounce, not a wobble (damping %.2f)' % DAMP)

if errors:
    print('\n'.join('check_shell: ' + e for e in errors)); sys.exit(1)
print('check_shell: ok (overlap %.3f, capsule out by %.2f, panel in by %.2f)' % (worst, CAP_END, PAN_START + PAN_SPAN))
