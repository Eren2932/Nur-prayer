package com.nur.prayer.ui.wallpaper

import kotlin.math.floor
import kotlin.math.hypot

/** Encoded sRGB brightness (not WCAG linear luminance). Sample centres are in viewport space. */
internal data class WallpaperTone(
    val topLuminance: Float, val centerLuminance: Float, val bottomLuminance: Float,
    val overallLuminance: Float, val brightCenterShare: Float
)

/** Single tuning file for compact home. Nothing here depends on Android, the clock or reveal state. */
internal object WallpaperTonePolicy {
    const val WIDTH = 32
    const val HEIGHT = 64
    const val LIGHT_OVERALL = .72f
    const val LIGHT_CENTER = .70f
    const val DARK = .30f
    const val BRIGHT_PIXEL = .78f
    const val TOP_MAX = .34f
    const val CENTER_MAX = .32f
    const val BOTTOM_MAX = .48f
    const val OPEN_MIN = .15f
    const val OPEN_MAX = .24f
    const val OPEN_WHITE = .22f
    const val SHADOW_START = .28f
    const val SHADOW_MAX = .42f
    const val SHADOW_Y = 1.5f
    const val SHADOW_BLUR = 10f
    const val TRANSITION_MS = 240
    const val GRAPHITE = 0xFF1E1B18
    val Night = WallpaperTone(0f, 0f, 0f, 0f, 0f)
    val Paper = WallpaperTone(1f, 1f, 1f, 1f, 1f)

    // Even on a dark photo an isolated white patch can land behind a caption. In sRGB,
    // 72% black bounds that patch at #474747 (Muted #BBBABD >= 4.8:1). The brightest
    // viewport band controls the extra dim, not a photo's filename or whole-image mean.
    const val EDITOR_DIM_MIN = .72f
    const val EDITOR_DIM_MAX = .77f
    fun editorDim(tone: WallpaperTone): Float {
        val peakBand = maxOf(tone.topLuminance, tone.centerLuminance, tone.bottomLuminance)
        return EDITOR_DIM_MIN + (EDITOR_DIM_MAX - EDITOR_DIM_MIN) * strength(peakBand)
    }

    fun isPaper(tone: WallpaperTone) = tone.overallLuminance >= LIGHT_OVERALL && tone.centerLuminance >= LIGHT_CENTER
    fun strength(luma: Float) = ((luma - DARK) / (LIGHT_OVERALL - DARK)).coerceIn(0f, 1f)
    fun openBlack(center: Float) = OPEN_MIN + (OPEN_MAX - OPEN_MIN) * strength(center)
    fun shadow(luma: Float, brightShare: Float = 0f): Float {
        val t = strength(luma)
        if (t == 0f) return 0f
        // Fade in at the threshold; specular highlights strengthen the shadow, not the whole photo.
        val highlights = (brightShare / .20f).coerceIn(0f, 1f)
        return (t / .32f).coerceAtMost(1f) * (SHADOW_START + (SHADOW_MAX - SHADOW_START) * maxOf(t, highlights))
    }
    fun luma(argb: Int): Float = (.299f * (argb ushr 16 and 255) + .587f * (argb ushr 8 and 255) + .114f * (argb and 255)) / 255f

    fun measure(sample: (x: Float, y: Float) -> Float): WallpaperTone {
        var total = 0.0; var top = 0.0; var center = 0.0; var bottom = 0.0
        var nt = 0; var nc = 0; var nb = 0; var bright = 0
        for (j in 0 until HEIGHT) {
            val y = (j + .5f) / HEIGHT
            for (i in 0 until WIDTH) {
                val v = sample((i + .5f) / WIDTH, y).coerceIn(0f, 1f)
                total += v
                when {
                    y < .20f -> { top += v; nt++ }
                    y in .28f.. .75f -> { center += v; nc++; if (v > BRIGHT_PIXEL) bright++ }
                    y >= .80f -> { bottom += v; nb++ }
                }
            }
        }
        return WallpaperTone((top/nt).toFloat(), (center/nc).toFloat(), (bottom/nb).toFloat(),
            (total/(WIDTH*HEIGHT)).toFloat(), bright.toFloat()/nc)
    }

    /** Same sRGB stops (.00/.55/1.00) and radial glow as SkyBackdrop. No bitmap or per-frame readback. */
    fun gradient(zenith: Int, mid: Int, horizon: Int, glow: Int, aspect: Float): WallpaperTone {
        val z = luma(zenith); val m = luma(mid); val h = luma(horizon); val g = luma(glow)
        val ga = (glow ushr 24) / 255f
        return measure { x, y ->
            val base = if (y < .55f) z + (m-z) * (y/.55f) else m + (h-m) * ((y-.55f)/.45f)
            val a = if (ga == 0f) 0f else ga * (1f - hypot(x-.5f, (y-1.02f)/aspect) / .95f).coerceIn(0f, 1f)
            base + (g - base) * a
        }
    }

    /** The thumbnail keeps the source proportions. Map through the real focus crop, including
     * the shaded mirrored fill on tablets; do not sample the portions cropped off a phone. */
    fun picture(pixels: IntArray, w: Int, h: Int, sourceW: Int, sourceH: Int, screenW: Int, screenH: Int,
        focusX: Float, focusY: Float, fill: IntArray? = null, fw: Int = 0, fh: Int = 0): WallpaperTone {
        val sw = screenW.toFloat(); val sh = screenH.toFloat()
        val iw = sourceW.toFloat(); val ih = sourceH.toFloat()
        val fit = WallpaperFit.fit(iw, ih, sw, sh, focusX, focusY)
        return measure { x, y ->
            val sx = x*sw; val sy = y*sh
            val u = (sx-fit.dx) / (iw*fit.scale); val v = (sy-fit.dy) / (ih*fit.scale)
            val pixel = pixels[(v*h).toInt().coerceIn(0,h-1)*w + (u*w).toInt().coerceIn(0,w-1)]
            val direct = luma(pixel) * ((pixel ushr 24) / 255f)
            val mask = if (fill == null) 1f else WallpaperFill.mask(sx, sy, fit, iw, ih, sw, sh)
            if (fill == null || mask >= 1f) direct else {
                val fx = WallpaperFill.mirror(floor(u*fw).toInt(),fw)
                val fy = WallpaperFill.mirror(floor((sy-fit.dy)/(fit.scale*iw/fw)).toInt(),fh)
                val side = luma(fill[fy*fw+fx]) * WallpaperFill.SHADE
                direct * mask + side * (1f-mask)
            }
        }
    }
}
