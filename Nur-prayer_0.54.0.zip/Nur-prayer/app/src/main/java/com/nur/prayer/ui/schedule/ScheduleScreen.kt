package com.nur.prayer.ui.schedule

import com.nur.prayer.ui.schedule.print.CalendarPaper
import com.nur.prayer.ui.components.pageContentInsets
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.background
import com.nur.prayer.i18n.L10n
import com.nur.prayer.core.astro.CalculationMethod
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.systemBarsIgnoringVisibility
import androidx.compose.foundation.layout.union
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.daily.StoryBars
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.ExitDock
import com.nur.prayer.ui.components.ExitButtonSpec
import com.nur.prayer.ui.components.rememberSystemBack
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.home.HomeTimeline
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SystemBarsTone
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.findActivity
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import kotlin.math.abs

/** One settled Gregorian period drives both month views and the share action.
 * The grid and year retain their own detail UI; the table is a full-sheet reader. */
private class CalendarSend(val times: MonthTimes, val city: String, val offset: Int, val method: CalculationMethod, val stamp: LocalDate)

internal object CalendarTabs {
    const val YEAR = 0
    const val MONTH = 1
    const val TABLE = 2
}

/** The colours of the text that stands on the backdrop itself (the period title, the weekday letters). */
private class BackdropInk(val title: Color, val subtitle: Color)

private fun backdropInk(light: Boolean, palette: PhasePalette): BackdropInk =
    if (light) BackdropInk(Paper.Ink, Paper.Accent)
    else BackdropInk(TextPrimary, palette.accentSoft)

/**
 * The timetables of the months the pager has seen. A page asks for its month, the cache computes it once off the
 * main thread and keeps only the months near the one just added: swiping through ten years must not keep ten years.
 */
@Stable
internal class MonthTimesCache(private val compute: suspend (YearMonth) -> MonthTimes?) {
    private val months = mutableStateMapOf<YearMonth, MonthTimes?>()
    fun failed(month: YearMonth): Boolean = months.containsKey(month) && months[month] == null
    private val gate = Mutex()

    operator fun get(month: YearMonth): MonthTimes? = months[month]

    suspend fun ensure(month: YearMonth) {
        gate.withLock {
            if (months[month] != null) return
            val times = compute(month)
            months[month] = times
            if (months.size > KEEP) {
                months.keys.filter { abs(ChronoUnit.MONTHS.between(it, month)) > NEAR }.forEach { months.remove(it) }
            }
        }
    }

    private companion object {
        const val KEEP = 7
        const val NEAR = 3L
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScheduleScreen(
    data: PrayerData, palette: PhasePalette,
    modifier: Modifier = Modifier,
    /** True while the wallpaper under the page is a light picture: the text on it is dark, the bars' icons too. */
    lightBackdrop: Boolean = false,
    onModalChange: (Boolean) -> Unit = {}
) {
    val today = data.today.date
    val hijriOffset = data.settings.hijriOffset

    var tab by rememberSaveable { mutableIntStateOf(CalendarTabs.MONTH) }
    var monthText by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(YearMonth.from(today).toString()) }
    var selectedEpoch by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(today.toEpochDay()) }
    var hijriYear by rememberSaveable(today.toEpochDay(), hijriOffset) { mutableIntStateOf(IslamicDays.hijriOf(today, hijriOffset).year) }
    var picker by rememberSaveable { mutableStateOf(false) }
    // A DayOccurrence is not Parcelable: the sheet is closed after a rotation, which is the honest state.
    var topic by remember { mutableStateOf<SheetTopic?>(null) }
    val tableTab = tab == CalendarTabs.TABLE
    var focus by rememberSaveable(tab) { mutableStateOf(false) }
    val reading = tableTab && focus
    val toggleFocus: () -> Unit = remember(tab) { { focus = !focus } }
    val paperTone = tableTab || lightBackdrop
    StoryBars(reading)
    BackHandler(enabled = reading) { focus = false }
    val month = YearMonth.parse(monthText)
    val selectedDate = LocalDate.ofEpochDay(selectedEpoch)
    fun goMonth(target: YearMonth) {
        if (target == month) return
        monthText = target.toString()
        selectedEpoch = CalendarMonthModel.moveSelection(selectedDate, target).toEpochDay()
    }

    // On a light picture the status-bar icons turn dark, or the clock and battery vanish into the cream.
    val view = LocalView.current
    // The holder is released the moment the page stops being light (the route changes), not when its exit
    // animation ends, so the next screen's own tone is never overwritten.
    val barsOwner = remember { Any() }
    DisposableEffect(paperTone) {
        val window = view.context.findActivity()?.window
        if (paperTone) SystemBarsTone.hold(window, barsOwner)
        onDispose { SystemBarsTone.release(window, barsOwner) }
    }

    // The timetables: a table page shows its month, the share button sends the one in front. 31 solar days are cheap.
    val columns = remember(data.fajrEqualsDawn) { HomeTimeline.prayers(data.fajrEqualsDawn) }
    val timesCache = remember(data.place, data.params, columns) {
        MonthTimesCache { m ->
            try {
                withContext(Dispatchers.Default) {
                    MonthTimes(m, PrayerEngine.days(m.atDay(1), m.lengthOfMonth(), data.place.coordinates, data.place.zone, data.params), columns)
                }
            } catch (cancel: CancellationException) { throw cancel } catch (_: Exception) { null }
        }
    }
    LaunchedEffect(month, timesCache) { timesCache.ensure(month) }
    val monthTimes = timesCache[month]
    val language = L10n.language
    var pendingSend by remember(month, timesCache, tab, hijriOffset, today, language) {
        mutableStateOf<CalendarSend?>(null)
    }
    BackHandler(enabled = pendingSend != null) { pendingSend = null }
    if (picker || topic != null || reading) DisposableEffect(onModalChange) {
        onModalChange(true)
        onDispose { onModalChange(false) }
    }

    // The pages. The state above stays the one truth; each pager reports a settled page and follows a changed period.
    val yearTab = tab == CalendarTabs.YEAR
    val gregorian = remember(today) { PeriodRange.gregorianYears(today) }
    val firstMonth = YearMonth.of(gregorian.first, 1)
    val monthCount = PeriodPages.monthCount(firstMonth, YearMonth.of(gregorian.last, 12))
    val hijriYears = remember(today, hijriOffset) { PeriodRange.hijriYears(today, hijriOffset) }
    val yearCount = hijriYears.last - hijriYears.first + 1
    val monthPager = rememberPeriodPager(PeriodPages.monthPage(firstMonth, month, monthCount), monthCount) { page ->
        goMonth(PeriodPages.monthAt(firstMonth, page))
    }
    val yearPager = rememberPeriodPager(PeriodPages.yearPage(hijriYears.first, hijriYear, yearCount), yearCount) { page ->
        hijriYear = hijriYears.first + page
    }
    // The grid views are Месяц and Таблица. Going to Год keeps the one that was in front, so the page that is
    // leaving does not swap its view while it fades out.
    val lastGrid = remember { IntArray(1) { CalendarTabs.MONTH } }
    if (tab != CalendarTabs.YEAR) lastGrid[0] = tab
    val gridTab = lastGrid[0]
    val ink = backdropInk(lightBackdrop, palette)
    // The cards end above the system bar with a normal margin: the capsule is not there to be run behind.
    val cutout = WindowInsets.displayCutout
    val safe = WindowInsets.systemBarsIgnoringVisibility.union(cutout)
    val stable = safe.asPaddingValues()
    val cut = cutout.asPaddingValues()
    val bottom = if (tableTab) stable.calculateBottomPadding() else WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val bottomInset = ExitButtonSpec.contentFloor(bottom)
    val normalTop = stable.calculateTopPadding() - cut.calculateTopPadding() + LocalIslandInset.current + ExitButtonSpec.Hit
    val normalBottom = (bottomInset - cut.calculateBottomPadding()).coerceAtLeast(0.dp)
    val progress = rememberPaperFocus(reading)
    val back = rememberSystemBack()

    val tint = if (paperTone) Paper.Ink else Color.White
    val canShare = !yearTab && monthTimes != null && !monthPager.isScrollInProgress &&
        month == PeriodPages.monthAt(firstMonth, monthPager.currentPage)
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val failed = tr("Не удалось подготовить картинку")
    var chooserOpen by rememberSaveable { mutableStateOf(false) }
    val chooser = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { chooserOpen = false }
    val request = pendingSend
    LaunchedEffect(request, canShare, picker, reading) {
        if (request == null) return@LaunchedEffect
        try {
            if (!canShare || picker || reading) return@LaunchedEffect
            val page = withContext(Dispatchers.Default) {
                calendarPage(request.times, request.offset, request.city, request.method, request.stamp)
            }
            val image = CalendarImageShare.prepare(context, page)
            if (owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) && !monthPager.isScrollInProgress) {
                chooserOpen = true
                chooser.launch(CalendarImageShare.chooser(context, image))
            }
        } catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { chooserOpen = false; Toast.makeText(context, failed, Toast.LENGTH_SHORT).show() }
        finally { if (pendingSend === request) pendingSend = null }
    }
    val focusLabel = if (reading) tr("Показать управление") else tr("Скрыть управление")
    val tap = tableTab && !picker && topic == null && pendingSend == null
    Box(modifier.fillMaxSize().then(if (tableTab) Modifier.background(Color(CalendarPaper.PAPER)) else Modifier)
        .then(if (tap) Modifier.calendarPaperTap(toggleFocus) else Modifier)) {
        // Fixed viewport: transient OS insets never resize the pager. Overlay rails own no layout space.
        Column(Modifier.fillMaxSize().then(if (tableTab) Modifier
            .windowInsetsPadding(safe.only(WindowInsetsSides.Horizontal))
            .windowInsetsPadding(cutout.only(WindowInsetsSides.Vertical)) else Modifier.pageContentInsets())) {
            if (!tableTab) CalendarTopBar(tab, { tab = it }, tint)
            if (!tableTab) {
                Spacer(Modifier.height(10.dp))
                PeriodBar(
                    pager = if (yearTab) yearPager else monthPager,
                    title = { page ->
                        if (yearTab) tr("{0} год хиджры", hijriYears.first + page)
                        else PeriodPages.monthAt(firstMonth, page).let { "${Format.monthName(it.monthValue)} ${it.year}" }
                    },
                    subtitle = { page ->
                        if (yearTab) yearSpan(hijriYears.first + page, hijriOffset)
                        else PeriodPages.monthAt(firstMonth, page).let { HijriCalendar.span(it.atDay(1), it.atEndOfMonth(), hijriOffset) }
                    },
                    onPick = { picker = true },
                    ink = ink.title, subInk = ink.subtitle
                )
                Spacer(Modifier.height(8.dp))
            }
            AnimatedContent(
                targetState = yearTab,
                transitionSpec = {
                    val forward = !targetState
                    (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { w -> if (forward) w / 6 else -w / 6 } +
                        fadeIn(tween(260, delayMillis = 40))) togetherWith
                        (slideOutHorizontally(tween(240)) { w -> if (forward) -w / 8 else w / 8 } + fadeOut(tween(160)))
                },
                label = "calendarTab",
                modifier = Modifier.weight(1f).fillMaxSize()
            ) { year ->
                if (year) PeriodPager(yearPager, Modifier.testTag("year-pager")) { page ->
                    YearView(
                        hijriYears.first + page, today, hijriOffset,
                        bottomInset = bottomInset,
                        onOpen = { topic = it }
                    )
                } else MonthStrip(monthPager, gridTab == CalendarTabs.TABLE, lightBackdrop, bottomInset) { page, edge ->
                    val pageMonth = PeriodPages.monthAt(firstMonth, page)
                    // A neighbour page shows the day that will be selected when the page arrives, so the leaf is
                    // whole while it turns, and landing on it changes nothing under the thumb.
                    val pageSelected = if (pageMonth == month) selectedDate else CalendarMonthModel.moveSelection(selectedDate, pageMonth)
                    AnimatedContent(
                        targetState = gridTab,
                        transitionSpec = {
                            val forward = targetState > initialState
                            (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { w -> if (forward) w / 6 else -w / 6 } +
                                fadeIn(tween(260, delayMillis = 40))) togetherWith
                                (slideOutHorizontally(tween(240)) { w -> if (forward) -w / 8 else w / 8 } + fadeOut(tween(160)))
                        },
                        label = "calendarView",
                        modifier = Modifier.fillMaxSize()
                    ) { gridView ->
                        if (gridView == CalendarTabs.TABLE) TablePage(
                            pageMonth, timesCache, today, hijriOffset, data.place.label, data.params.method,
                            normalTop = normalTop, normalBottom = normalBottom, progress = progress, edge = edge, reading = reading,
                            focusLabel = focusLabel, onToggle = toggleFocus
                        ) else MonthPage(
                            data, timesCache, pageMonth, pageSelected, columns, if (lightBackdrop) MonthLight else MonthNight,
                            onSelect = { selectedEpoch = it.toEpochDay() },
                            onOpen = { topic = it }
                        )
                    }
                }
            }
        }
        if (tableTab) AnimatedVisibility(!reading, modifier = Modifier.align(Alignment.TopCenter), enter = fadeIn(tween(110)), exit = fadeOut(tween(90))) {
            CalendarTopBar(tab, { if (!reading) tab = it }, tint,
                Modifier.windowInsetsPadding(safe.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal)))
        }
        PeriodPicker(
            visible = picker,
            mode = if (yearTab) PickerMode.HIJRI_YEAR else PickerMode.MONTH,
            month = month, hijriYear = hijriYear, today = today, hijriOffset = hijriOffset,
            onMonth = { goMonth(it) }, onHijriYear = { hijriYear = it },
            onToday = {
                if (yearTab) hijriYear = IslamicDays.hijriOf(today, hijriOffset).year
                else { monthText = YearMonth.from(today).toString(); selectedEpoch = today.toEpochDay() }
            }, onDismiss = { picker = false }
        )
        DaySheet(topic, today, hijriOffset, onDismiss = { topic = null })
        // One dock serves both the calendar and its sheets. Close the overlay, never its parent.
        val modal = picker || topic != null
        AnimatedVisibility(!reading && !picker, modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(110)), exit = fadeOut(tween(90))) {
            ExitDock(onClose = { if (!reading) when { topic != null -> topic = null; picker -> picker = false; else -> back() } },
            bottom = bottom, modifier = if (tableTab) Modifier.windowInsetsPadding(safe.only(WindowInsetsSides.Horizontal)) else Modifier.pageContentInsets(),
            description = if (modal) tr("Закрыть") else tr("Назад"),
            tint = if (topic != null || paperTone && !picker) Paper.Ink else Color.White,
            onMenu = if (!yearTab && !modal) ({ if (!reading) picker = true }) else null,
            menuDescription = tr("Выбрать период"),
            centerAction = if (!yearTab && !modal) ({
                CalendarShareButton(tint, canShare && !reading && !chooserOpen && request == null) {
                    if (monthTimes != null && canShare && !reading && !chooserOpen && pendingSend == null) {
                        pendingSend = CalendarSend(monthTimes, data.place.label, hijriOffset, data.params.method, LocalDate.now(data.place.zone))
                    }
                }
            }) else null)
        }
    }
}

/** "16 июня 2026 — 4 июня 2027": the Gregorian bounds of a hijri year. */
private fun yearSpan(year: Int, offset: Int): String {
    val first = IslamicDays.monthRange(year, 1, offset)?.first
    val last = IslamicDays.monthRange(year, 12, offset)?.second
    return if (first != null && last != null) "${Format.dayMonth(first)} ${first.year} — ${Format.dayMonth(last)} ${last.year}" else ""
}

/** One stationary gutter at each side of the viewport. Content has no repeated page margin. */
@Composable
internal fun MonthStrip(pager: PagerState, paper: Boolean, light: Boolean, floor: Dp,
                       content: @Composable (Int, Dp) -> Unit) {
    val wash = if (light) Color(0xDCFAF8F3) else Color(0xD010111A)
    BoxWithConstraints(Modifier.fillMaxSize().then(if (paper) Modifier else Modifier.padding(bottom = floor).background(wash))) {
        val panels = if (maxWidth > maxHeight * 1.22f) 2 else 1
        val edge = if (paper) minOf(maxWidth / panels, maxHeight * 1.75f) * .031f else uiScale().s(10f)
        PeriodPager(pager, Modifier.fillMaxSize().padding(horizontal = edge).clipToBounds().testTag("calendar-pager"),
            motion = PageMotion.STRIP) { page -> content(page, edge) }
    }
}

@Composable
private fun MonthPage(data: PrayerData, cache: MonthTimesCache, month: YearMonth, selectedDate: LocalDate,
                      columns: List<Prayer>, ink: MonthInk, onSelect: (LocalDate) -> Unit, onOpen: (SheetTopic) -> Unit) {
    val offset = data.settings.hijriOffset
    LaunchedEffect(month, cache) { cache.ensure(month) }
    val times = cache[month]
    val day = times?.days?.getOrNull(selectedDate.dayOfMonth - 1) ?: data.days.firstOrNull { it.date == selectedDate }
    val events = remember(selectedDate, offset) { IslamicDays.on(selectedDate, offset) }
    val next = HomeTimeline.visible(data.window.next, data.fajrEqualsDawn)
        .takeIf { data.window.nextStart.toLocalDate() == selectedDate }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val weeks = remember(month) { (month.atDay(1).dayOfWeek.value - 1 + month.lengthOfMonth() + 6) / 7 }
        val wide = maxWidth >= 540.dp
        val rows = if (wide) (columns.size + 1) / 2 else columns.size
        val minRow = ((maxHeight - (88 + 27 * rows).dp) / weeks).coerceIn(48.dp, 60.dp)
        // Only small windows or extra-long translations scroll. The dock never overlaps the scroll viewport.
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            MonthCalendar(month, selectedDate, data.today.date, offset, onSelect = onSelect, ink = ink, minRow = minRow)
            Spacer(Modifier.height(6.dp))
            DayCard(selectedDate, data.place.label, offset, day, !cache.failed(month), columns, next, events, ink, wide, onOpen)
            Spacer(Modifier.height(6.dp))
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * Таблица: the month as a timetable
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun TablePage(
    month: YearMonth, cache: MonthTimesCache, today: LocalDate, hijriOffset: Int,
    city: String, method: CalculationMethod, normalTop: Dp, normalBottom: Dp, progress: State<Float>,
    edge: Dp, reading: Boolean, focusLabel: String, onToggle: () -> Unit
) {
    LaunchedEffect(month, cache) { cache.ensure(month) }
    val times = cache[month]
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (times == null) Text(if (cache.failed(month)) tr("Не удалось рассчитать день") else tr("Рассчитываем время…"), color = Paper.Ink)
        else {
            val page = remember(times, hijriOffset, city, method, today, L10n.language) {
                calendarPage(times, hijriOffset, city, method, today)
            }
            MonthTable(page, focusLabel, onToggle, progress, normalTop, normalBottom, edge, reading)
        }
    }
}
