package com.nur.prayer.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Adaptive metrics.
 *
 * Two independent problems are solved here.
 *
 * 1. **System font size.** Android lets the user pick a font scale up to 2.0x (and OEM skins such as
 *    MIUI go further). A layout that simply multiplies every sp by 2 explodes. We clamp the *engine*
 *    scale to [MIN_FONT_SCALE]..[MAX_FONT_SCALE] in [NurTheme] and, on top of that, every important
 *    label is drawn with `AutoSizeText`, which shrinks to fit instead of wrapping or clipping.
 *    The user still gets bigger type, but never a broken screen.
 *
 * 2. **Screen size.** A 5" 320dp phone and a 7" 480dp phone need different rhythm. [UiScale.text]
 *    and [UiScale.space] are multipliers derived from the real viewport, so paddings and type shrink
 *    or grow together instead of being hard-coded for one reference device.
 */
const val MIN_FONT_SCALE = 0.85f
const val MAX_FONT_SCALE = 1.15f

/** Reference device the design was drawn on (Pixel-class, 393 x 851 dp). */
private const val REF_WIDTH_DP = 393f
private const val REF_HEIGHT_DP = 851f

@androidx.compose.runtime.Immutable
data class UiScale(
    /** Multiplier for our own sp literals. */
    val text: Float,
    /** Multiplier for our own dp literals (paddings, gaps, icon sizes). */
    val space: Float,
    /** True on short screens: sections drop optional decoration. */
    val compact: Boolean,
    /** Font scale the user actually asked for, before clamping. */
    val systemFontScale: Float,
    val widthDp: Float,
    val heightDp: Float
) {
    /** Scaled text size. */
    fun t(value: Float): TextUnit = (value * text).sp

    /** Scaled spacing / size in dp. */
    fun s(value: Float): Dp = (value * space).dp

    /** True when the user runs a noticeably enlarged system font. */
    val largeFont: Boolean get() = systemFontScale > 1.15f

    companion object {
        fun of(widthDp: Int, heightDp: Int, systemFontScale: Float): UiScale {
            val w = widthDp.toFloat().coerceAtLeast(240f)
            val h = heightDp.toFloat().coerceAtLeast(400f)

            // Width drives the rhythm, height keeps tall content from overflowing on stubby screens.
            val byWidth = w / REF_WIDTH_DP
            val byHeight = h / REF_HEIGHT_DP
            val space = (byWidth * 0.75f + byHeight * 0.25f).coerceIn(0.82f, 1.18f)

            // When the system font is already enlarged, we give back a little of our own size so
            // that the enlarged glyphs have room to breathe instead of fighting the layout.
            val fontRelief = when {
                systemFontScale >= 1.45f -> 0.88f
                systemFontScale >= 1.25f -> 0.93f
                systemFontScale >= 1.10f -> 0.97f
                else -> 1f
            }
            val text = (byWidth.coerceIn(0.88f, 1.12f) * fontRelief).coerceIn(0.80f, 1.12f)

            return UiScale(
                text = text,
                space = space,
                compact = h < 720f || systemFontScale >= 1.3f,
                systemFontScale = systemFontScale,
                widthDp = w,
                heightDp = h
            )
        }
    }
}

val LocalUiScale = compositionLocalOf { UiScale.of(393, 851, 1f) }

/** Bottom inset taken by the floating dock, published so every screen pads itself correctly. */
val LocalDockInset = compositionLocalOf { 96.dp }

@Composable
fun uiScale(): UiScale = LocalUiScale.current
