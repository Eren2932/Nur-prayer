package com.nur.prayer.ui.qibla

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.GlassPanel
import com.nur.prayer.ui.theme.Amber
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private const val ALIGN_TOLERANCE = 2.5f

/**
 * The colour of an instrument that has not found anything yet.
 *
 * Green on this screen means exactly one thing — *you are pointing at the Kaaba* — and it may
 * therefore never appear before that is true.
 */
private val DialSteel = Color(0xFFC6CEE4)

/** North is a fact about the dial, not a status, so it gets brightness rather than colour. */
private val NorthLabel = Color(0xFFE6EBFA)

@Composable
fun QiblaScreen(
    data: PrayerData,
    palette: PhasePalette,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val dockInset = LocalDockInset.current
    val heading = rememberHeading(data.place.coordinates.latitude, data.place.coordinates.longitude)
    val qibla = data.qibla.toFloat()
    val delta = angleDelta(heading.azimuth, qibla)
    val aligned = abs(delta) <= ALIGN_TOLERANCE && heading.available
    val haptic = LocalHapticFeedback.current

    // Fires once per entry into the aligned state, not on every frame inside it.
    LaunchedEffect(aligned) {
        if (aligned) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    // Two separate colours, because they answer two separate questions.
    //
    // `markColor` — "am I on the Kaaba?" Steel until the answer is yes, then mint. Nothing else is
    // allowed to turn it green. The old code used `palette.accent` here, and at night that accent
    // *is* mint: the compass looked solved the moment it opened, so the one signal that matters
    // carried no information.
    // `deviceColor` — "can the sensors be trusted?" It reports interference and tilt, and it stays
    // steel while everything is fine, so a healthy compass is visually silent.
    val markColor by animateColorAsState(
        targetValue = if (aligned) Mint else DialSteel,
        animationSpec = tween(280),
        label = "qiblaMark"
    )
    val deviceColor by animateColorAsState(
        targetValue = when {
            aligned -> Mint
            heading.interference -> Crimson
            !heading.heldFlat -> Amber
            else -> DialSteel
        },
        animationSpec = tween(400),
        label = "qiblaDevice"
    )
    // Width of the lock-on bloom: 0 while searching, 1 when locked.
    val lock by animateFloatAsState(
        targetValue = if (aligned) 1f else 0f,
        animationSpec = tween(320),
        label = "qiblaLock"
    )
    val dialRotation by animateFloatAsState(
        targetValue = -heading.azimuth,
        animationSpec = tween(90),
        label = "dial"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = ui.s(20f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AutoSizeText(
            text = "Кыбла",
            color = TextPrimary,
            fontSize = ui.t(26f),
            fontWeight = FontWeight.SemiBold
        )
        AutoSizeText(
            text = "${data.place.label} · ${data.kaabaDistanceKm.roundToInt()} км до Каабы",
            color = TextTertiary,
            fontSize = ui.t(12f),
            maxLines = 2,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(ui.s(12f)))

        // The dial never grows past what the viewport can host, whatever the font scale is.
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val dialSize = min(maxWidth, (ui.heightDp * 0.44f).dp)
            Box(
                modifier = Modifier
                    .width(dialSize)
                    .aspectRatio(1f)
                    .align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                // The world rotates, the phone stays still.
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { rotationZ = dialRotation }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        if (size.minDimension < 8f) return@Canvas
                        val center = Offset(size.width / 2f, size.height / 2f)
                        val radius = size.minDimension / 2f * 0.86f

                        // Glass plate.
                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(
                                    Color.White.copy(alpha = 0.06f),
                                    Color.White.copy(alpha = 0.015f),
                                    Color.Transparent
                                ),
                                center = Offset(center.x, center.y - radius * 0.3f),
                                radius = radius
                            ),
                            radius = radius,
                            center = center
                        )
                        drawCircle(
                            color = Color.White.copy(alpha = 0.14f),
                            radius = radius,
                            center = center,
                            style = Stroke(width = 1.2f * density)
                        )
                        drawCircle(
                            color = Color.White.copy(alpha = 0.07f),
                            radius = radius * 0.62f,
                            center = center,
                            style = Stroke(width = 1f * density)
                        )

                        // 72 graduations, every 30° major.
                        for (i in 0 until 72) {
                            val a = Math.toRadians(i * 5.0 - 90.0)
                            val major = i % 6 == 0
                            val outer = radius
                            val inner = radius - radius * (if (major) 0.10f else 0.045f)
                            drawLine(
                                color = Color.White.copy(alpha = if (major) 0.38f else 0.15f),
                                start = Offset(
                                    center.x + outer * cos(a).toFloat(),
                                    center.y + outer * sin(a).toFloat()
                                ),
                                end = Offset(
                                    center.x + inner * cos(a).toFloat(),
                                    center.y + inner * sin(a).toFloat()
                                ),
                                strokeWidth = (if (major) 2.4f else 1.2f) * density,
                                cap = StrokeCap.Round
                            )
                        }

                        // Qibla ray with a soft cone: the tolerance you are allowed.
                        val qa = Math.toRadians(qibla - 90.0)
                        val coneHalf = Math.toRadians(6.0)
                        val conePath = Path().apply {
                            moveTo(center.x, center.y)
                            lineTo(
                                center.x + radius * cos(qa - coneHalf).toFloat(),
                                center.y + radius * sin(qa - coneHalf).toFloat()
                            )
                            lineTo(
                                center.x + radius * cos(qa + coneHalf).toFloat(),
                                center.y + radius * sin(qa + coneHalf).toFloat()
                            )
                            close()
                        }
                        // The tolerance cone is a hairline hint while searching and fills in on
                        // lock, so the transition is felt rather than read.
                        drawPath(conePath, color = markColor.copy(alpha = 0.05f + 0.13f * lock))
                        drawLine(
                            brush = Brush.linearGradient(
                                listOf(
                                    markColor.copy(alpha = 0.10f),
                                    markColor.copy(alpha = 0.50f + 0.50f * lock)
                                )
                            ),
                            start = center,
                            end = Offset(
                                center.x + radius * 0.94f * cos(qa).toFloat(),
                                center.y + radius * 0.94f * sin(qa).toFloat()
                            ),
                            strokeWidth = (2.6f + 1.2f * lock) * density,
                            cap = StrokeCap.Round
                        )
                    }

                    CardinalLabel("С", 0f, NorthLabel, ui.t(13f))
                    CardinalLabel("В", 90f, TextSecondary, ui.t(12f))
                    CardinalLabel("Ю", 180f, TextSecondary, ui.t(12f))
                    CardinalLabel("З", 270f, TextSecondary, ui.t(12f))

                    // Kaaba marker: rides the dial, stays upright.
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { rotationZ = qibla }
                    ) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .size(ui.s(42f))
                                .graphicsLayer { rotationZ = -dialRotation - qibla }
                                .clip(CircleShape)
                                // A hairline ring around the Kaaba while searching: no fill, no
                                // colour, no promise. On lock it fills mint.
                                .background(
                                    if (aligned) Mint.copy(alpha = 0.18f)
                                    else Color.White.copy(alpha = 0.04f)
                                )
                                .border(
                                    1.dp,
                                    markColor.copy(alpha = 0.22f + 0.53f * lock),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🕋", fontSize = ui.t(19f))
                        }
                    }
                }

                // Fixed device pointer, drawn on top of the rotating dial.
                Canvas(modifier = Modifier.fillMaxSize()) {
                    if (size.minDimension < 8f) return@Canvas
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val radius = size.minDimension / 2f * 0.86f
                    val tip = radius * 1.11f
                    val path = Path().apply {
                        moveTo(center.x, center.y - tip)
                        lineTo(center.x - radius * 0.045f, center.y - radius * 0.98f)
                        lineTo(center.x + radius * 0.045f, center.y - radius * 0.98f)
                        close()
                    }
                    drawPath(path, color = deviceColor)
                    drawCircle(color = Color.White.copy(alpha = 0.85f), radius = 2.4f * density, center = center)
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .widthIn(max = dialSize * 0.56f)
                        .padding(top = ui.s(18f))
                ) {
                    AutoSizeText(
                        text = "${qibla.roundToInt()}°",
                        color = TextPrimary,
                        fontSize = ui.t(40f),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Light
                    )
                    AutoSizeText(
                        text = when {
                            !heading.available -> "нет магнитометра"
                            aligned -> "точно на Каабу"
                            delta > 0 -> "вправо ${abs(delta).roundToInt()}°"
                            else -> "влево ${abs(delta).roundToInt()}°"
                        },
                        color = if (aligned) Mint else TextSecondary,
                        fontSize = ui.t(13f),
                        maxLines = 2,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(ui.s(6f)))
                    BubbleLevel(tiltDegrees = heading.tiltDegrees, size = ui.s(34f), accent = deviceColor)
                }
            }
        }

        Spacer(Modifier.height(ui.s(10f)))

        // Honest status line: what the sensors are actually doing right now.
        StatusStrip(heading = heading, accent = palette.accent, ui = ui)

        Spacer(Modifier.height(ui.s(10f)))

        GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = ui.s(16f)) {
            Column {
                InfoRow("Азимут кыблы (истинный север)", "${qibla.roundToInt()}°", ui)
                InfoRow("Курс устройства", "${heading.azimuth.roundToInt()}°", ui)
                InfoRow("Компас (магнитный север)", "${heading.magneticAzimuth.roundToInt()}°", ui)
                InfoRow(
                    "Магнитная поправка (WMM)",
                    (if (heading.declination >= 0) "+" else "") + "${heading.declination.roundToInt()}°",
                    ui
                )
                InfoRow("Наклон телефона", "${heading.tiltDegrees.roundToInt()}°", ui)
                InfoRow(
                    "Поле",
                    if (heading.fieldStrength > 0f) "${heading.fieldStrength.roundToInt()} мкТл" else "—",
                    ui
                )
                InfoRow(
                    "Датчики",
                    when (heading.source) {
                        HeadingSource.FUSED -> "гиро + магнит + акселерометр"
                        HeadingSource.GEOMAGNETIC -> "магнит + акселерометр"
                        HeadingSource.RAW -> "магнит + акселерометр (сырые)"
                        HeadingSource.NONE -> "недоступны"
                    },
                    ui
                )

                val hint = when {
                    !heading.available ->
                        "На этом устройстве нет магнитометра — компас недоступен, но азимут кыблы выше рассчитан точно: " +
                            "выставьте его по любому другому компасу или по карте."
                    heading.interference ->
                        "Поле ${heading.fieldStrength.roundToInt()} мкТл вместо обычных 25–65: рядом магнит, металл или " +
                            "динамик. Отойдите от техники и стола с металлом."
                    heading.accuracy in 0..1 ->
                        "Магнитометр не откалиброван. Проведите телефоном «восьмёркой» в воздухе 3–4 секунды."
                    !heading.heldFlat ->
                        "Держите телефон горизонтально, экраном вверх — пузырёк должен встать в центр. " +
                            "Сейчас читаем направление «от задней камеры», это менее точно."
                    else ->
                        "Датчики в норме: поправка на магнитное склонение применена, точность порядка ±2°."
                }
                Spacer(Modifier.height(ui.s(8f)))
                Text(
                    text = hint,
                    color = TextTertiary,
                    fontSize = ui.t(11.5f),
                    lineHeight = ui.t(16f)
                )
            }
        }

        Spacer(Modifier.height(dockInset))
    }
}

/** Real bubble level: the dot walks off centre as the phone tilts away from horizontal. */
@Composable
private fun BubbleLevel(tiltDegrees: Float, size: androidx.compose.ui.unit.Dp, accent: Color) {
    val normalized = (tiltDegrees / 45f).coerceIn(0f, 1f)
    val flat = tiltDegrees <= 12f
    Canvas(modifier = Modifier.size(size)) {
        if (this.size.minDimension < 4f) return@Canvas
        val r = this.size.minDimension / 2f
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        drawCircle(
            color = Color.White.copy(alpha = 0.10f),
            radius = r,
            center = center,
            style = Stroke(width = 1.2f * density)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.16f),
            radius = r * 0.30f,
            center = center,
            style = Stroke(width = 1f * density)
        )
        drawCircle(
            color = if (flat) Mint.copy(alpha = 0.9f) else accent.copy(alpha = 0.85f),
            radius = r * 0.22f,
            center = Offset(center.x, center.y + normalized * r * 0.72f)
        )
    }
}

@Composable
private fun StatusStrip(
    heading: Heading,
    accent: Color,
    ui: com.nur.prayer.ui.theme.UiScale
) {
    val items = buildList {
        add(
            when (heading.accuracy) {
                3 -> "калибровка: высокая" to Mint
                2 -> "калибровка: средняя" to accent
                1 -> "калибровка: низкая" to Amber
                0 -> "не калиброван" to Crimson
                else -> "калибровка: проверяем" to TextTertiary
            }
        )
        if (heading.interference) add("помеха магнита" to Crimson)
        if (!heading.heldFlat && heading.available) add("наклон ${heading.tiltDegrees.roundToInt()}°" to Amber)
        if (heading.trustworthy && heading.heldFlat) add("готов" to Mint)
    }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(ui.s(6f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { (label, color) ->
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(ui.s(12f)))
                    .background(color.copy(alpha = 0.13f))
                    .border(1.dp, color.copy(alpha = 0.24f), RoundedCornerShape(ui.s(12f)))
                    .padding(horizontal = ui.s(9f), vertical = ui.s(5f)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(ui.s(6f))
                        .clip(CircleShape)
                        .background(color)
                )
                Spacer(Modifier.width(ui.s(6f)))
                AutoSizeText(
                    text = label,
                    color = TextSecondary,
                    fontSize = ui.t(10.5f),
                    minFontSize = ui.t(8.5f)
                )
            }
        }
    }
}

@Composable
private fun CardinalLabel(
    text: String,
    angle: Float,
    color: Color,
    fontSize: androidx.compose.ui.unit.TextUnit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { rotationZ = angle }
    ) {
        Text(
            text = text,
            color = color,
            fontSize = fontSize,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .graphicsLayer { rotationZ = -angle }
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String, ui: com.nur.prayer.ui.theme.UiScale) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(5f)),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AutoSizeText(
            text = label,
            color = TextTertiary,
            fontSize = ui.t(11.5f),
            maxLines = 2,
            modifier = Modifier.weight(1f, fill = true)
        )
        Spacer(Modifier.width(ui.s(10f)))
        AutoSizeText(
            text = value,
            color = TextPrimary,
            fontSize = ui.t(12.5f),
            fontFamily = FontFamily.Monospace
        )
    }
}
