package com.nur.prayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.Ink

/**
 * Surfaces.
 *
 * The old panel was "liquid glass": a diagonal white gradient with a bright top edge. Two problems
 * with it, and neither of them is taste.
 *
 * 1. **It fought the sky.** The background is a live gradient with aurora curtains, so a translucent
 *    white sheet inherited whatever was behind it: the same card read light over the horizon glow
 *    and nearly invisible at the zenith, and small type lost contrast exactly where the glow is
 *    brightest. A panel that cannot guarantee its own contrast is not a panel.
 * 2. **The highlight lied.** A gloss band implies a light source; ours pointed a different way from
 *    the horizon glow it was sitting on, and that mismatch is the detail that makes an interface
 *    feel like a downloaded template.
 *
 * What replaced it: a matte plate. Deep ink at a fixed alpha, so contrast is a constant instead of a
 * function of the pixel underneath; one hairline border; and — only on the raised level — a
 * one-pixel top light line aimed the same way as the sky's own light. No gloss, no blur, no runtime
 * cost beyond a single rounded rect. It reads as an instrument panel rather than decoration, and the
 * type on it is legible over every phase of the sky.
 */
enum class PanelLevel {
    /** Content plate: the default surface for a section of the app. */
    RAISED,

    /** Quiet plate for grouped rows inside a [RAISED] panel. */
    FLAT,

    /** Pressed-in well: inputs, steppers, segmented tracks. */
    INSET
}

/** The panel look as a modifier, so it can dress a Row/Column/LazyColumn item without nesting. */
fun Modifier.nurPanel(
    shape: Shape,
    level: PanelLevel = PanelLevel.RAISED,
    accent: Color? = null
): Modifier {
    val fill: Color
    val edge: Color
    when (level) {
        PanelLevel.RAISED -> {
            fill = Ink.copy(alpha = 0.55f)
            edge = Color.White.copy(alpha = 0.10f)
        }
        PanelLevel.FLAT -> {
            fill = Color.White.copy(alpha = 0.035f)
            edge = Color.White.copy(alpha = 0.06f)
        }
        PanelLevel.INSET -> {
            fill = Ink.copy(alpha = 0.62f)
            edge = Color.White.copy(alpha = 0.08f)
        }
    }
    return this
        .clip(shape)
        .background(fill)
        .then(
            if (level == PanelLevel.RAISED) {
                Modifier.background(
                    Brush.verticalGradient(
                        0f to Color.White.copy(alpha = 0.045f),
                        0.06f to Color.White.copy(alpha = 0.012f),
                        1f to Color.Transparent
                    )
                )
            } else Modifier
        )
        .border(width = 1.dp, color = accent?.copy(alpha = 0.34f) ?: edge, shape = shape)
}

/**
 * The app's content plate.
 *
 * Kept under its old name on purpose: every screen already calls it, and a rename would have been a
 * diff with no user-visible value. The signature is unchanged, the look is not.
 */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    corner: Dp = 22.dp,
    tint: Color = Color.White,
    alpha: Float = 0.07f,
    contentPadding: Dp = 16.dp,
    level: PanelLevel = PanelLevel.RAISED,
    accent: Color? = null,
    content: @Composable BoxScope.() -> Unit
) {
    // `tint` and `alpha` survive as no-ops so every existing call site keeps compiling: contrast on a
    // live gradient is not something an individual screen should be able to weaken by hand.
    Box(
        modifier = modifier
            .nurPanel(RoundedCornerShape(corner), level, accent)
            .padding(contentPadding),
        content = content
    )
}

val GlassCornerRadius = 22.dp
