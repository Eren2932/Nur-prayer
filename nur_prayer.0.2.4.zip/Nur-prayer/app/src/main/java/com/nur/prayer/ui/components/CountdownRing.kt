package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * The countdown ring: one comet, and it *is* the hand of the clock.
 *
 * ### What was wrong before
 *
 * There were two moving things on this ring. A progress head that crept forward with real time, and a
 * comet that flew a full lap every 6.5 seconds regardless of anything at all. So the most eye-catching
 * object on the main screen carried no information — it just spun, forever, next to the number it was
 * supposed to illustrate. That is decoration pretending to be a feature.
 *
 * ### What it is now
 *
 * The comet is the head of the elapsed arc. It leaves the top of the ring when a prayer begins and
 * arrives back at the top exactly when the next one starts, so its position *is* the remaining time
 * and its speed *is* the length of the window: the forty minutes between Maghrib and Isha move it
 * visibly, the nine-hour night creeps. Behind it lies the arc it has already burned, and immediately
 * behind the nucleus a tail of sparks fades out along that arc with embers breaking away sideways.
 * The sixty minute ticks flare as the nucleus passes and cool over the next thirty degrees, which is
 * what makes the motion legible even when it is far too slow to perceive directly.
 *
 * At the very start of a window the tail is clipped to the elapsed arc, so the comet is bare: the ring
 * never draws a trail it has not travelled.
 *
 * ### Why it costs nothing
 *
 * The position is neither animated state nor a recomposition: the window arrives as two epoch
 * timestamps and the phase is computed inside the draw scope from the wall clock. Compose therefore
 * never re-composes and never re-lays-out this ring while it advances — it only redraws, one Canvas,
 * no allocation per frame, three gradients. The old version recomposed on every progress change *and*
 * ran a second infinite animation on top of it.
 *
 * Reading the wall clock rather than an accumulated animation value also means the comet is correct
 * after the screen has been off for two hours, and correct on the first frame after process death.
 */
@Composable
fun CountdownRing(
    /** Epoch millis when the current window opened. */
    startMillis: Long,
    /** Epoch millis when the next prayer begins. */
    endMillis: Long,
    accent: Color,
    accentSoft: Color,
    modifier: Modifier = Modifier,
    stroke: Dp = 13.dp,
    /** Freezes the sparkle (battery saver, screenshots, tests). The comet keeps its true position. */
    reduceMotion: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    // Two clocks, and the split matters. `flicker` is the fast one and drives nothing but sparkle
    // brightness; where the comet *is* comes from the wall clock, so it survives a frame-rate change,
    // a doze, or a restart.
    val flicker = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(reduceMotion) {
        if (reduceMotion) return@LaunchedEffect
        var origin = 0L
        while (true) {
            withFrameNanos { now ->
                if (origin == 0L) origin = now
                flicker.floatValue = (now - origin) / 1_000_000_000f
            }
        }
    }

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            if (size.minDimension < 8f) return@Canvas
            val t = flicker.floatValue

            // ---- Where the comet is, from the wall clock -------------------------------------
            val span = (endMillis - startMillis).toFloat()
            val phase = if (span <= 0f) 0f else {
                ((System.currentTimeMillis() - startMillis) / span).coerceIn(0f, 1f)
            }
            val sweep = 360f * phase

            // Geometry is clamped so the ring cannot invert on a small box (a future widget, a
            // landscape phone, a large font scale).
            val strokePx = stroke.toPx().coerceAtMost(size.minDimension * 0.11f)
            val inset = (strokePx * 2.2f).coerceAtMost(size.minDimension * 0.25f)
            val arcSize = Size(size.width - inset * 2f, size.height - inset * 2f)
            val topLeft = Offset(inset, inset)
            val radius = arcSize.minDimension / 2f
            val center = Offset(size.width / 2f, size.height / 2f)
            val headDeg = -90f + sweep

            // ---- Ambient halo ----------------------------------------------------------------
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Transparent, accent.copy(alpha = 0.09f), Color.Transparent),
                    center = center,
                    radius = radius * 1.28f
                ),
                radius = radius * 1.28f,
                center = center
            )

            // ---- Plate under the digits ------------------------------------------------------
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.045f),
                        Color.White.copy(alpha = 0.012f),
                        Color.Transparent
                    ),
                    center = Offset(center.x, center.y - radius * 0.25f),
                    radius = radius * 0.98f
                ),
                radius = radius - strokePx * 0.6f,
                center = center
            )

            // ---- Track -----------------------------------------------------------------------
            drawArc(
                color = Color.White.copy(alpha = 0.08f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            // ---- Sixty minute ticks; the ones just passed are still hot ----------------------
            for (i in 0 until 60) {
                val tickDeg = i * 6f - 90f
                val a = (tickDeg * PI / 180f).toFloat()
                val major = i % 5 == 0
                val outer = radius + strokePx * 1.15f
                val inner = outer - if (major) strokePx * 0.62f else strokePx * 0.30f
                // Behind the head only, cooling over 30 degrees. This is the part that makes very
                // slow motion visible: you cannot see the comet move, but you can see a tick fade.
                val behind = (headDeg - tickDeg + 360f) % 360f
                val heat = if (behind <= TICK_COOLDOWN_DEGREES) {
                    (1f - behind / TICK_COOLDOWN_DEGREES).pow(2f)
                } else 0f
                val baseAlpha = if (major) 0.18f else 0.07f
                drawLine(
                    color = accentSoft.copy(alpha = baseAlpha + 0.55f * heat),
                    start = Offset(center.x + outer * cos(a), center.y + outer * sin(a)),
                    end = Offset(center.x + inner * cos(a), center.y + inner * sin(a)),
                    strokeWidth = (if (major) 2.2f else 1.4f) * density,
                    cap = StrokeCap.Round
                )
            }

            // ---- The burnt arc ---------------------------------------------------------------
            // Faint where the window began, full strength at the comet: it reads as a trail that has
            // had time to cool, not as a filled progress bar.
            if (sweep > 0.4f) {
                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            accent.copy(alpha = 0.34f),
                            accent.copy(alpha = 0.62f),
                            accentSoft,
                            accent.copy(alpha = 0.34f)
                        ),
                        center = center
                    ),
                    startAngle = -90f,
                    sweepAngle = sweep,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )
            }

            // ---- Tail: sparks along the arc already covered ----------------------------------
            val tailArc = TAIL_ARC_DEGREES.coerceAtMost(sweep)
            if (tailArc > 1f) {
                for (i in 1..TAIL_PARTICLES) {
                    val lag = i / TAIL_PARTICLES.toFloat()
                    val deg = headDeg - lag * tailArc
                    val a = (deg * PI / 180f).toFloat()
                    val flick = 0.55f + 0.45f * sin(t * 9f + i * 1.7f)
                    val jitter = sin(i * 2.3f + t * 5f) * strokePx * 0.40f * lag
                    val r = radius + jitter
                    val alpha = (1f - lag).pow(1.9f) * flick * 0.7f
                    if (alpha <= 0.01f) continue
                    drawCircle(
                        color = accentSoft.copy(alpha = alpha),
                        radius = strokePx * (0.32f - 0.21f * lag).coerceAtLeast(0.05f),
                        center = Offset(center.x + r * cos(a), center.y + r * sin(a))
                    )
                }

                // Embers breaking away outwards, alternating sides.
                for (k in 0 until EMBERS) {
                    val p = ((t * 0.75f) + k / EMBERS.toFloat()) % 1f
                    val deg = headDeg - p * tailArc * 1.25f
                    val a = (deg * PI / 180f).toFloat()
                    val outward = strokePx * (0.4f + p * 2.2f) * (if (k % 2 == 0) 1f else -1f)
                    val r = radius + outward
                    val alpha = (1f - p).pow(2.2f) * 0.5f
                    if (alpha <= 0.01f) continue
                    drawCircle(
                        color = accentSoft.copy(alpha = alpha),
                        radius = strokePx * 0.14f * (1f - p * 0.5f),
                        center = Offset(center.x + r * cos(a), center.y + r * sin(a))
                    )
                }
            }

            // ---- Nucleus ---------------------------------------------------------------------
            val headRad = (headDeg * PI / 180f).toFloat()
            val head = Offset(
                center.x + radius * cos(headRad),
                center.y + radius * sin(headRad)
            )
            val breath = 1f + 0.08f * sin(t * 2.2f)
            val glow = strokePx * 2.15f * breath
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        accentSoft.copy(alpha = 0.85f),
                        accent.copy(alpha = 0.26f),
                        Color.Transparent
                    ),
                    center = head,
                    radius = glow
                ),
                radius = glow,
                center = head
            )
            // A short forward flare, so the comet has a direction of travel.
            val flareRad = ((headDeg + 3.2f) * PI / 180f).toFloat()
            val flareEnd = Offset(
                center.x + radius * cos(flareRad),
                center.y + radius * sin(flareRad)
            )
            drawLine(
                brush = Brush.linearGradient(
                    listOf(accentSoft.copy(alpha = 0.55f), Color.Transparent),
                    start = head,
                    end = flareEnd
                ),
                start = head,
                end = flareEnd,
                strokeWidth = strokePx * 0.34f,
                cap = StrokeCap.Round
            )
            drawCircle(
                color = Color.White,
                radius = strokePx * (0.30f + 0.05f * sin(t * 6f)),
                center = head
            )
        }
        content()
    }
}

private const val TAIL_PARTICLES = 26
private const val TAIL_ARC_DEGREES = 54f
private const val EMBERS = 8
private const val TICK_COOLDOWN_DEGREES = 30f

val RingStroke = 13.dp
