package com.nur.prayer.data

import android.content.Context
import com.nur.prayer.Graph
import com.nur.prayer.core.astro.Coordinates
import java.time.ZoneId

/** Where the user is, according to the current settings. */
@androidx.compose.runtime.Immutable
data class Place(
    val label: String,
    val subtitle: String,
    val coordinates: Coordinates,
    val zone: ZoneId,
    val fromDeviceLocation: Boolean
)

object PlaceResolver {

    fun resolve(context: Context, settings: AppSettings): Place {
        val repo = Graph.cities(context)
        val city = repo.byId(settings.cityId) ?: City.MOSCOW
        val lat = settings.manualLatitude
        val lon = settings.manualLongitude
        return if (settings.useDeviceLocation && lat != null && lon != null) {
            val nearest = repo.nearest(Coordinates(lat, lon))
            Place(
                label = nearest.name,
                subtitle = "по геолокации · ${format(lat)}, ${format(lon)}",
                coordinates = Coordinates(lat, lon),
                zone = nearest.zone,
                fromDeviceLocation = true
            )
        } else {
            Place(
                label = city.name,
                subtitle = city.region,
                coordinates = city.coordinates,
                zone = city.zone,
                fromDeviceLocation = false
            )
        }
    }

    private fun format(value: Double): String = String.format(java.util.Locale.US, "%.3f", value)
}
