package com.nur.prayer.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerWindow
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.CountdownRing
import com.nur.prayer.ui.components.GlassPanel
import com.nur.prayer.ui.components.PanelLevel
import com.nur.prayer.ui.components.nurPanel
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.UiScale
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate
import java.time.ZonedDateTime

/**
 * The main screen.
 *
 * ### The one structural rule here
 *
 * The clock ticks once a second, and exactly two things on this screen depend on the second: the
 * countdown digits and the position of the comet. So the current time arrives as a [State] and is
 * *read* in only those two places — the digits in `CountdownReadout`, the comet inside a draw scope.
 * Everything else (the city chip, the Hijri line, the six prayer rows, the note) reads either nothing
 * time-related or a date derived through [derivedStateOf], which changes once a day.
 *
 * Before, `now` was a plain `ZonedDateTime` parameter of the whole screen. Compose has no way to know
 * that only the digits care, so every tick invalidated this entire composable, all six rows, the panel,
 * the ring and its content — sixty times a minute, forever. That is what the shivering was.
 */
@Composable
fun HomeScreen(
    data: PrayerData,
    now: State<ZonedDateTime>,
    palette: PhasePalette,
    onOpenCity: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val dockInset = LocalDockInset.current
    val window = data.window
    // Changes once a day, not once a second.
    val today by remember(now) { derivedStateOf { now.value.toLocalDate() } }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = ui.s(20f))
    ) {
        Spacer(Modifier.height(ui.s(10f)))

        HomeHeader(
            place = data.place.label,
            hijri = data.hijri,
            date = today,
            palette = palette,
            onOpenCity = onOpenCity,
            ui = ui
        )

        Spacer(Modifier.height(ui.s(14f)))

        // The ring is bounded by height as well as width: on a short screen it shrinks instead of
        // pushing the prayer list out of view.
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val ringSize = min(maxWidth - ui.s(16f), (ui.heightDp * 0.46f).dp)
            Box(
                modifier = Modifier
                    .width(ringSize)
                    .aspectRatio(1f)
                    .align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                CountdownRing(
                    startMillis = window.currentStart.toInstant().toEpochMilli(),
                    endMillis = window.nextStart.toInstant().toEpochMilli(),
                    accent = palette.accent,
                    accentSoft = palette.accentSoft,
                    stroke = ui.s(13f),
                    modifier = Modifier.fillMaxSize()
                ) {
                    CountdownReadout(
                        window = window,
                        now = now,
                        palette = palette,
                        ui = ui,
                        maxWidth = ringSize * 0.66f
                    )
                }
            }
        }

        Spacer(Modifier.height(ui.s(14f)))

        GlassPanel(modifier = Modifier.fillMaxWidth(), contentPadding = ui.s(8f), corner = ui.s(24f)) {
            Column {
                Prayer.entries.forEachIndexed { index, prayer ->
                    if (index > 0) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = ui.s(14f))
                                .height(1.dp)
                                .background(Color.White.copy(alpha = 0.05f))
                        )
                    }
                    val time = data.today.times[prayer]
                    PrayerRow(
                        prayer = prayer,
                        timeText = time?.let { Format.time(it) } ?: "—",
                        isCurrent = prayer == window.current,
                        isNext = prayer == window.next,
                        accent = palette.accent,
                        enabled = data.settings.notifications[prayer] == true,
                        ui = ui
                    )
                }
            }
        }

        val note = data.today.note
        if (note != null) {
            Spacer(Modifier.height(ui.s(12f)))
            GlassPanel(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = ui.s(14f),
                corner = ui.s(20f),
                level = PanelLevel.FLAT
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height(ui.s(34f))
                            .clip(RoundedCornerShape(2.dp))
                            .background(palette.accent.copy(alpha = 0.7f))
                    )
                    Spacer(Modifier.width(ui.s(11f)))
                    Text(
                        text = note,
                        color = TextSecondary,
                        fontSize = ui.t(12.5f),
                        lineHeight = ui.t(17f)
                    )
                }
            }
        }

        Spacer(Modifier.height(dockInset))
    }
}

/* ------------------------------------------------------------------------------------------------
 * Header
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun HomeHeader(
    place: String,
    hijri: String,
    date: LocalDate,
    palette: PhasePalette,
    onOpenCity: () -> Unit,
    ui: UiScale
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // City chip: a hairline outline instead of a filled blob. It is a control, but the least
        // important one on the screen, and it has no business competing with the countdown.
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .weight(1f, fill = false)
                .height(ui.s(38f))
                .nurPanel(RoundedCornerShape(ui.s(13f)), PanelLevel.FLAT)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onOpenCity() }
                .padding(horizontal = ui.s(12f))
        ) {
            Box(
                modifier = Modifier
                    .size(ui.s(7f))
                    .clip(CircleShape)
                    .background(palette.accent)
            )
            Spacer(Modifier.width(ui.s(8f)))
            AutoSizeText(
                text = place,
                color = TextPrimary,
                fontSize = ui.t(14f),
                minFontSize = ui.t(11f),
                fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.width(ui.s(8f)))
            AutoSizeText(
                text = "сменить",
                color = TextTertiary,
                fontSize = ui.t(10.5f),
                minFontSize = ui.t(8.5f)
            )
        }
        Spacer(Modifier.width(ui.s(10f)))
        Column(
            horizontalAlignment = Alignment.End,
            modifier = Modifier.weight(1f)
        ) {
            AutoSizeText(
                text = hijri,
                color = palette.accentSoft,
                fontSize = ui.t(13f),
                minFontSize = ui.t(9.5f),
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth()
            )
            AutoSizeText(
                text = Format.dayMonth(date),
                color = TextTertiary,
                fontSize = ui.t(12f),
                minFontSize = ui.t(9f),
                textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * The digits inside the ring
 * ---------------------------------------------------------------------------------------------- */

/**
 * The only composable in the app that is allowed to recompose once a second.
 *
 * It reads `now.value` here and nowhere above, so the invalidation stops at this Column: six text
 * nodes, and nothing above them re-measured. The countdown passes `resizeKey` to [AutoSizeText] so the
 * auto-fit search does not restart on every tick — that search is what made the digits flicker,
 * because the first frames of a new search are deliberately withheld while it measures.
 */
@Composable
private fun CountdownReadout(
    window: PrayerWindow,
    now: State<ZonedDateTime>,
    palette: PhasePalette,
    ui: UiScale,
    maxWidth: Dp
) {
    val remaining = window.remaining(now.value)
    val text = Format.countdown(remaining)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.widthIn(max = maxWidth)
    ) {
        AutoSizeText(
            text = "ДО ${PrayerLabels.title(window.next).uppercase()}",
            color = TextSecondary,
            fontSize = ui.t(11.5f),
            minFontSize = ui.t(9f),
            letterSpacing = ui.t(2f),
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(ui.s(4f)))
        AutoSizeText(
            text = text,
            color = TextPrimary,
            fontSize = ui.t(50f),
            minFontSize = ui.t(26f),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Light,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            // Monospaced digits: the fitted size can only change when the length does.
            resizeKey = text.length
        )
        Spacer(Modifier.height(ui.s(2f)))
        AutoSizeText(
            text = "начало в ${Format.time(window.nextStart)}",
            color = palette.accentSoft,
            fontSize = ui.t(14.5f),
            minFontSize = ui.t(11f),
            fontWeight = FontWeight.Medium
        )
        Spacer(Modifier.height(ui.s(10f)))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(ui.s(11f)))
                .background(Color.White.copy(alpha = 0.06f))
                .padding(horizontal = ui.s(11f), vertical = ui.s(5f))
        ) {
            AutoSizeText(
                text = "сейчас ${PrayerLabels.title(window.current)} · ${palette.name}",
                color = TextSecondary,
                fontSize = ui.t(11.5f),
                minFontSize = ui.t(9f)
            )
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * Prayer row
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun PrayerRow(
    prayer: Prayer,
    timeText: String,
    isCurrent: Boolean,
    isNext: Boolean,
    accent: Color,
    enabled: Boolean,
    ui: UiScale
) {
    val highlight by animateColorAsState(
        targetValue = when {
            isNext -> accent.copy(alpha = 0.13f)
            isCurrent -> Color.White.copy(alpha = 0.05f)
            else -> Color.Transparent
        },
        animationSpec = tween(600),
        label = "rowBg"
    )
    val titleColor by animateColorAsState(
        targetValue = if (isNext) accent else TextPrimary,
        animationSpec = tween(600),
        label = "rowTitle"
    )
    val alpha by animateFloatAsState(
        targetValue = if (enabled || prayer == Prayer.SUNRISE) 1f else 0.55f,
        label = "rowAlpha"
    )
    // The Arabic column is the first thing to go when type gets large: it is decoration, the time is
    // not.
    val showArabic = !ui.largeFont && ui.widthDp >= 340f

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(2f))
            .clip(RoundedCornerShape(ui.s(16f)))
            .background(highlight)
            .padding(horizontal = ui.s(13f), vertical = ui.s(11f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Marker column: a filled rail for what is next, a dim dot for everything else. One shape,
        // one meaning, so the eye answers "what is next" without reading a word.
        Box(
            modifier = Modifier
                .width(if (isNext) 3.dp else ui.s(7f))
                .height(if (isNext) ui.s(24f) else ui.s(7f))
                .clip(if (isNext) RoundedCornerShape(2.dp) else CircleShape)
                .background(
                    if (isNext) Brush.verticalGradient(listOf(accent, accent.copy(alpha = 0.35f)))
                    else Brush.linearGradient(
                        listOf(Color.White.copy(alpha = 0.20f), Color.White.copy(alpha = 0.09f))
                    )
                )
        )
        Spacer(Modifier.width(ui.s(11f)))
        Column(modifier = Modifier.weight(1f)) {
            AutoSizeText(
                text = PrayerLabels.title(prayer),
                color = titleColor.copy(alpha = alpha),
                fontSize = ui.t(15.5f),
                minFontSize = ui.t(12f),
                fontWeight = if (isNext) FontWeight.SemiBold else FontWeight.Medium,
                modifier = Modifier.fillMaxWidth()
            )
            AutoSizeText(
                text = PrayerLabels.hint(prayer),
                color = TextTertiary,
                fontSize = ui.t(10.5f),
                minFontSize = ui.t(8.5f),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (showArabic) {
            Spacer(Modifier.width(ui.s(8f)))
            Text(
                text = PrayerLabels.arabic(prayer),
                color = TextTertiary,
                fontSize = ui.t(14f)
            )
        }
        Spacer(Modifier.width(ui.s(12f)))
        AutoSizeText(
            text = timeText,
            color = titleColor.copy(alpha = alpha),
            fontSize = ui.t(18.5f),
            minFontSize = ui.t(14f),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium,
            resizeKey = timeText.length
        )
    }
}
