#!/usr/bin/env python3
"""
Independent check of the twilight root finder (correctedHourAngle / corrected_hour_angle).

The engine solves altitude(t) = angle with Newton iteration. This script does not trust that: it
walks the Sun's altitude minute by minute across the local day, brackets every crossing by hand,
refines it by bisection to the second, and compares. A root the engine reports must exist in the
scan; a crossing the scan finds must not be missing from the engine unless it is a genuine tangency.

Usage: python3 tools/verify_roots.py [--tolerance-seconds 30] [--cities 24] [--days 12]
"""
import argparse, json, math, os, random, sys
from datetime import date, datetime, time, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prayer_port import (Coordinates, SolarTime, SolarCoordinates, anchor_hours, julian_day,
                         altitude_of_celestial_body, unwind_angle, interpolate,
                         interpolate_angles)

ASSET = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     "..", "app", "src", "main", "assets", "cities_ru.json")


def altitude_at(d, coords, hours):
    """Sun altitude, degrees, `hours` after 00:00 UTC of `d`, from first principles."""
    # Solar coordinates *at that instant*: apparent sidereal time is valid for a fractional Julian
    # Day, so no separate rotation term is needed. Deliberately different from the engine, which
    # takes sidereal time at 0h UT and rotates it - two roads to the same place.
    jd = julian_day(d.year, d.month, d.day) + hours / 24.0
    sc = SolarCoordinates(jd)
    hour_angle = unwind_angle(sc.apparent_sidereal_time) + coords.longitude - sc.right_ascension
    return altitude_of_celestial_body(coords.latitude, sc.declination, hour_angle)


def scan_crossings(d, coords, angle, step_minutes=1.0):
    """All times (hours from 00:00 UTC of d, over a 48 h window centred on it) where altitude=angle."""
    out = []
    h = -12.0
    prev_h, prev_v = h, altitude_at(d, coords, h) - angle
    while h < 36.0:
        h += step_minutes / 60.0
        v = altitude_at(d, coords, h) - angle
        if prev_v == 0.0 or (prev_v < 0) != (v < 0):
            lo, hi = prev_h, h
            for _ in range(40):
                mid = (lo + hi) / 2.0
                if (altitude_at(d, coords, lo) - angle < 0) != (altitude_at(d, coords, mid) - angle < 0):
                    hi = mid
                else:
                    lo = mid
            out.append((lo + hi) / 2.0)
        prev_h, prev_v = h, v
    return out


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tolerance-seconds", type=float, default=30.0)
    parser.add_argument("--cities", type=int, default=24)
    parser.add_argument("--days", type=int, default=12)
    parser.add_argument("--seed", type=int, default=20260815)
    args = parser.parse_args()

    with open(ASSET, encoding="utf-8") as handle:
        cities = json.load(handle)
    rng = random.Random(args.seed)
    picked = rng.sample(cities, min(args.cities, len(cities)))
    # Always include the awkward ones.
    forced = {"Казань", "Анадырь", "Мурманск", "Великий Новгород", "Норильск"}
    picked += [c for c in cities if c["name"] in forced and c not in picked]

    angles = [(-0.8333, "восход/закат"), (-18.0, "рассвет 18°"), (-15.0, "иша 15°"), (-17.0, "иша 17°")]
    checked = mismatches = ghosts = 0
    report = []
    for city in picked:
        coords = Coordinates(city["lat"], city["lon"])
        from zoneinfo import ZoneInfo
        zone = ZoneInfo(city["tz"])
        for _ in range(args.days):
            d = date(2026, 1, 1) + timedelta(days=rng.randrange(365))
            offset = datetime.combine(d, time(12), zone).utcoffset().total_seconds() / 3600.0
            solar = SolarTime.of(d, coords, anchor_hours(d, offset))
            for angle, label in angles:
                for after in (False, True):
                    engine = solar.hour_angle(angle, after)
                    scan = scan_crossings(d, coords, angle)
                    checked += 1
                    if engine is None or math.isnan(engine):
                        continue
                    nearest = min(scan, key=lambda h: abs(h - engine)) if scan else None
                    if nearest is None:
                        ghosts += 1
                        report.append(f"{city['name']} {d} {label} {'вечер' if after else 'утро'}: "
                                      f"движок дал корень, скан не нашёл ни одного")
                        continue
                    delta = abs(nearest - engine) * 3600.0
                    if delta > args.tolerance_seconds:
                        mismatches += 1
                        report.append(f"{city['name']} {d} {label} {'вечер' if after else 'утро'}: "
                                      f"движок {engine:.5f} ч, скан {nearest:.5f} ч, "
                                      f"расхождение {delta:.0f} с")
    print(f"Проверено {checked} корней в {len(picked)} городах, допуск {args.tolerance_seconds:.0f} с")
    if report:
        print(f"РАСХОЖДЕНИЙ: {len(report)}")
        for line in report[:40]:
            print("  " + line)
        return 1
    print("Все корни движка подтверждены сканом высоты Солнца.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
