"""
Line-by-line port of the Nur Kotlin prayer engine to Python.

Why this file exists
--------------------
The Android SDK cannot run in every environment where the calculation has to be trusted, and
"trust me, the math is right" is not a review artefact. This module is a deliberate duplicate of
`core/astro/*.kt`: same Meeus chain, same publication pipeline, same clamps, same order pass.
It lets any change to prayer times be validated over every city and every day of the year in
seconds, and it makes the calibration of `CalendarConvention` reproducible instead of anecdotal.

If you change the Kotlin, change this too, then run `tools/validate_times.py`.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date as Date, datetime, timedelta, timezone
from typing import Dict, Optional, Tuple

# ---------------------------------------------------------------- AstroMath.kt

def dsin(d: float) -> float: return math.sin(math.radians(d))
def dcos(d: float) -> float: return math.cos(math.radians(d))
def dtan(d: float) -> float: return math.tan(math.radians(d))
def dasin(x: float) -> float: return math.degrees(math.asin(x))
def dacos(x: float) -> float: return math.degrees(math.acos(x))
def datan2(y: float, x: float) -> float: return math.degrees(math.atan2(y, x))

def normalize_with_bound(value: float, maximum: float) -> float:
    return value - maximum * math.floor(value / maximum)

def unwind_angle(angle: float) -> float:
    return normalize_with_bound(angle, 360.0)

def quadrant_shift_angle(angle: float) -> float:
    if -180.0 <= angle <= 180.0:
        return angle
    # Kotlin Math.round: half-up, matters only at exact .5 which never occurs here.
    return angle - 360.0 * math.floor(angle / 360.0 + 0.5)

def julian_day(year: int, month: int, day: int, hours: float = 0.0) -> float:
    y = year if month > 2 else year - 1
    m = month if month > 2 else month + 12
    d = day + hours / 24.0
    a = math.floor(y / 100.0)
    b = 2 - a + math.floor(a / 4.0)
    return math.floor(365.25 * (y + 4716)) + math.floor(30.6001 * (m + 1)) + d + b - 1524.5

def julian_century(jd: float) -> float: return (jd - 2451545.0) / 36525.0

def mean_solar_longitude(t: float) -> float:
    return unwind_angle(280.4664567 + t * (36000.76983 + t * 0.0003032))

def mean_lunar_longitude(t: float) -> float:
    return unwind_angle(218.3165 + 481267.8813 * t)

def ascending_lunar_node_longitude(t: float) -> float:
    return unwind_angle(125.04452 - 1934.136261 * t + 0.0020708 * t * t + (t ** 3) / 450000.0)

def mean_solar_anomaly(t: float) -> float:
    return unwind_angle(357.52911 + t * (35999.05029 - 0.0001537 * t))

def solar_equation_of_the_center(t: float, m: float) -> float:
    return (dsin(m) * (1.914602 - t * (0.004817 + 0.000014 * t))
            + dsin(2 * m) * (0.019993 - t * 0.000101)
            + dsin(3 * m) * 0.000289)

def apparent_solar_longitude(t: float, mean_longitude: float) -> float:
    true_longitude = mean_longitude + solar_equation_of_the_center(t, mean_solar_anomaly(t))
    omega = 125.04 - 1934.136 * t
    return unwind_angle(true_longitude - 0.00569 - 0.00478 * dsin(omega))

def mean_obliquity_of_the_ecliptic(t: float) -> float:
    return 23.439291 - t * (0.013004167 + t * (0.0000001639 - t * 0.0000005036))

def apparent_obliquity_of_the_ecliptic(t: float, mean_obliquity: float) -> float:
    return mean_obliquity + 0.00256 * dcos(125.04 - 1934.136 * t)

def mean_sidereal_time(t: float) -> float:
    jd = t * 36525.0 + 2451545.0
    theta = (280.46061837 + 360.98564736629 * (jd - 2451545.0)
             + 0.000387933 * t * t - (t ** 3) / 38710000.0)
    return unwind_angle(theta)

def nutation_in_longitude(l0: float, lp: float, omega: float) -> float:
    return ((-17.2 / 3600) * dsin(omega)
            - (-1.32 / 3600) * dsin(2 * l0)
            - (0.23 / 3600) * dsin(2 * lp)
            + (0.21 / 3600) * dsin(2 * omega))

def nutation_in_obliquity(l0: float, lp: float, omega: float) -> float:
    return ((9.2 / 3600) * dcos(omega)
            + (0.57 / 3600) * dcos(2 * l0)
            + (0.10 / 3600) * dcos(2 * lp)
            - (0.09 / 3600) * dcos(2 * omega))

def altitude_of_celestial_body(latitude: float, declination: float, local_hour_angle: float) -> float:
    return dasin(dsin(latitude) * dsin(declination)
                 + dcos(latitude) * dcos(declination) * dcos(local_hour_angle))

def approximate_transit(longitude: float, sidereal_time: float, right_ascension: float) -> float:
    lw = longitude * -1
    return normalize_with_bound((right_ascension + lw - sidereal_time) / 360.0, 1.0)

def interpolate(y2: float, y1: float, y3: float, factor: float) -> float:
    a, b = y2 - y1, y3 - y2
    c = b - a
    return y2 + ((factor / 2) * (a + b + factor * c))

def interpolate_angles(y2: float, y1: float, y3: float, factor: float) -> float:
    a, b = unwind_angle(y2 - y1), unwind_angle(y3 - y2)
    c = b - a
    return y2 + ((factor / 2) * (a + b + factor * c))

def corrected_transit(approx: float, longitude: float, sidereal_time: float, ra: float,
                      prev_ra: float, next_ra: float) -> float:
    lw = longitude * -1
    theta = unwind_angle(sidereal_time + 360.985647 * approx)
    alpha = unwind_angle(interpolate_angles(ra, prev_ra, next_ra, approx))
    hour_angle = quadrant_shift_angle(theta - lw - alpha)
    return (approx + hour_angle / -360.0) * 24

def corrected_hour_angle(approx: float, angle: float, latitude: float, longitude: float,
                         after_transit: bool, sidereal_time: float, ra: float, prev_ra: float,
                         next_ra: float, declination: float, prev_dec: float,
                         next_dec: float) -> float:
    """Iterated, verified root of altitude(t) = angle - mirrors correctedHourAngle in AstroMath.kt."""
    lw = longitude * -1
    term1 = dsin(angle) - dsin(latitude) * dsin(declination)
    term2 = dcos(latitude) * dcos(declination)
    ratio = term1 / term2
    if ratio > 1.0 or ratio < -1.0 or math.isnan(ratio):
        return math.nan
    h0 = dacos(ratio)
    m = approx + (h0 / 360.0) if after_transit else approx - (h0 / 360.0)

    def residual(x):
        theta = unwind_angle(sidereal_time + 360.985647 * x)
        alpha = unwind_angle(interpolate_angles(ra, prev_ra, next_ra, x))
        delta = interpolate(declination, prev_dec, next_dec, x)
        hour_angle = theta - lw - alpha
        altitude = altitude_of_celestial_body(latitude, delta, hour_angle)
        slope = 360.0 * dcos(delta) * dcos(latitude) * dsin(hour_angle)
        return altitude - angle, slope

    max_step = 0.5 / 24.0
    value = math.nan
    for _ in range(8):
        value, slope = residual(m)
        if abs(value) < 1e-7:
            break
        if abs(slope) < 1e-9:
            return math.nan
        m += max(-max_step, min(max_step, value / slope))
    if abs(value) > 0.05:
        return math.nan
    offset = m - approx
    if after_transit and offset <= 0.0:
        return math.nan
    if not after_transit and offset >= 0.0:
        return math.nan
    if abs(offset) > 0.5:
        return math.nan
    return m * 24

# --------------------------------------------------------------- SolarTime.kt

@dataclass(frozen=True)
class Coordinates:
    latitude: float
    longitude: float

class SolarCoordinates:
    __slots__ = ("declination", "right_ascension", "apparent_sidereal_time")

    def __init__(self, jd: float):
        t = julian_century(jd)
        l0 = mean_solar_longitude(t)
        lp = mean_lunar_longitude(t)
        omega = ascending_lunar_node_longitude(t)
        lam = apparent_solar_longitude(t, l0)
        theta0 = mean_sidereal_time(t)
        d_psi = nutation_in_longitude(l0, lp, omega)
        d_eps = nutation_in_obliquity(l0, lp, omega)
        eps0 = mean_obliquity_of_the_ecliptic(t)
        eps_app = apparent_obliquity_of_the_ecliptic(t, eps0)
        self.declination = dasin(dsin(eps_app) * dsin(lam))
        self.right_ascension = unwind_angle(datan2(dcos(eps_app) * dsin(lam), dcos(lam)))
        self.apparent_sidereal_time = theta0 + (d_psi * 3600 * dcos(eps0 + d_eps)) / 3600

_SOLAR_CACHE: Dict[Tuple[Date, Coordinates, float], "SolarTime"] = {}

class SolarTime:
    """
    Solar events for one day, expressed in hours from 00:00 UTC of that date.

    `anchor` is where local noon sits in that frame, in hours (12 - utcOffset). It exists because
    `approximate_transit` returns a fraction of the *UTC* day, which is ambiguous by exactly one
    day when a place's solar noon sits near the UTC day boundary. Anadyr, longitude 177.5 in UTC+12,
    has its noon within a minute of it: the fraction came back as 0.9997 on 1-4 December 2026 and
    0.0003 from the 5th, so the whole frame - transit, sunrise, dawn, Isha - silently jumped a day
    back and forth. Picking the transit nearest to local noon pins the frame to the day the user is
    actually looking at, and every event is then computed from the Sun's position on that day.
    """
    __slots__ = ("coordinates", "_prev", "_solar", "_next", "_approx", "transit", "sunrise", "sunset")

    def __init__(self, d: Date, coordinates: Coordinates, anchor: float = 12.0):
        self.coordinates = coordinates
        jd = julian_day(d.year, d.month, d.day)
        self._prev = SolarCoordinates(jd - 1)
        self._solar = SolarCoordinates(jd)
        self._next = SolarCoordinates(jd + 1)
        approx = approximate_transit(coordinates.longitude,
                                     self._solar.apparent_sidereal_time,
                                     self._solar.right_ascension)
        # Shift by whole days so the transit is the one closest to local noon.
        self._approx = approx + math.floor((anchor / 24.0) - approx + 0.5)
        solar_altitude = -50.0 / 60.0
        self.transit = corrected_transit(self._approx, coordinates.longitude,
                                         self._solar.apparent_sidereal_time,
                                         self._solar.right_ascension,
                                         self._prev.right_ascension, self._next.right_ascension)
        self.sunrise = self.hour_angle(solar_altitude, False)
        self.sunset = self.hour_angle(solar_altitude, True)

    @staticmethod
    def of(d: Date, coordinates: Coordinates, anchor: float = 12.0) -> "SolarTime":
        key = (d, coordinates, anchor)
        cached = _SOLAR_CACHE.get(key)
        if cached is None:
            cached = SolarTime(d, coordinates, anchor)
            if len(_SOLAR_CACHE) > 4096:
                _SOLAR_CACHE.clear()
            _SOLAR_CACHE[key] = cached
        return cached

    def hour_angle(self, angle: float, after_transit: bool) -> float:
        return corrected_hour_angle(
            self._approx, angle, self.coordinates.latitude, self.coordinates.longitude,
            after_transit, self._solar.apparent_sidereal_time, self._solar.right_ascension,
            self._prev.right_ascension, self._next.right_ascension,
            self._solar.declination, self._prev.declination, self._next.declination)

    def afternoon(self, shadow_length: float) -> float:
        tangent = abs(self.coordinates.latitude - self._solar.declination)
        inverse = shadow_length + dtan(tangent)
        angle = math.degrees(math.atan(1.0 / inverse))
        return self.hour_angle(angle, True)

# ------------------------------------------------------------- PrayerParams.kt

SAHAR, FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA = "SAHAR", "FAJR", "SUNRISE", "DHUHR", "ASR", "MAGHRIB", "ISHA"
ORDER = [SAHAR, FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA]

NEAREST, UP, DOWN = "NEAREST", "UP", "DOWN"
ANGLE, METHOD_INTERVAL, FIXED_INTERVAL, NIGHT_FRACTION, MIDNIGHT_BOUND, CONGREGATION, DAWN_BOUND = (
    "ANGLE", "METHOD_INTERVAL", "FIXED_INTERVAL", "NIGHT_FRACTION", "MIDNIGHT_BOUND",
    "CONGREGATION", "DAWN_BOUND")

# A root within this distance of solar midnight is a tangency, not an event. Ten minutes: wide
# enough that no genuine dawn in the city list is ever inside it (the closest is +31 min, Kazan on
# 9 August), narrow enough not to swallow a real season boundary.
TANGENCY_MARGIN_SECONDS = 600
# Shortest night that can still carry a printed suhoor window - see the Kotlin comment.
MIN_USABLE_NIGHT_SECONDS = 154 * 60


@dataclass(frozen=True)
class MarkerPolicy:
    rounding: str
    offset_seconds: int = 0

# Second-level, because a printed calendar disagrees with astronomy by seconds, not minutes.
# Fitted by tools/calibrate_convention.py; the interval is the full admissible set and the value
# taken is its centre.
DUM_RT_POLICIES: Dict[str, MarkerPolicy] = {
    SAHAR:   MarkerPolicy(DOWN, +103),
    SUNRISE: MarkerPolicy(DOWN, +18),
    DHUHR:   MarkerPolicy(DOWN, -17),
    ASR:     MarkerPolicy(DOWN, -5),
    MAGHRIB: MarkerPolicy(DOWN, -29),
    ISHA:    MarkerPolicy(DOWN, -62),
}

@dataclass(frozen=True)
class Method:
    title: str
    fajr_angle: float
    isha_angle: float
    isha_interval_minutes: int = 0
    maghrib_angle: float = 0.0
    night_fajr_minutes: int = 120
    night_isha_minutes: int = 90
    congregational_fajr_before_sunrise: int = 0
    method_adjustments: Dict[str, int] = field(default_factory=dict)

METHODS = {
    "RUSSIA_DUM": Method("ДУМ РФ", 18.0, 15.0, congregational_fajr_before_sunrise=90),
    "SPIRITUAL_BOARD_TATARSTAN": Method("ДУМ РТ", 18.0, 15.0, congregational_fajr_before_sunrise=90),
    "MUSLIM_WORLD_LEAGUE": Method("MWL", 18.0, 17.0, method_adjustments={DHUHR: 1}),
    "EGYPTIAN": Method("Egyptian", 19.5, 17.5, method_adjustments={DHUHR: 1}),
    "KARACHI": Method("Karachi", 18.0, 18.0, method_adjustments={DHUHR: 1}),
    "UMM_AL_QURA": Method("Umm al-Qura", 18.5, 0.0, isha_interval_minutes=90),
    "DUBAI": Method("Dubai", 18.2, 18.2,
                    method_adjustments={SUNRISE: -3, DHUHR: 3, ASR: 3, MAGHRIB: 3}),
    "QATAR": Method("Qatar", 18.0, 0.0, isha_interval_minutes=90),
    "KUWAIT": Method("Kuwait", 18.0, 17.5),
    "TURKEY": Method("Diyanet", 18.0, 17.0,
                     method_adjustments={SUNRISE: -7, DHUHR: 5, ASR: 4, MAGHRIB: 7}),
    "TEHRAN": Method("Tehran", 17.7, 14.0, maghrib_angle=4.5),
    "NORTH_AMERICA": Method("ISNA", 15.0, 15.0, method_adjustments={DHUHR: 1}),
}

AUTO, RULE_FIXED_INTERVAL, MIDDLE_OF_THE_NIGHT, SEVENTH_OF_THE_NIGHT, TWILIGHT_ANGLE = (
    "AUTO", "FIXED_INTERVAL", "MIDDLE_OF_THE_NIGHT", "SEVENTH_OF_THE_NIGHT", "TWILIGHT_ANGLE")

def resolve_rule(rule: str, latitude: float) -> str:
    if rule == AUTO:
        return RULE_FIXED_INTERVAL if abs(latitude) >= 48.0 else MIDDLE_OF_THE_NIGHT
    return rule

@dataclass(frozen=True)
class Params:
    method: str = "RUSSIA_DUM"
    shadow_length: float = 2.0            # HANAFI
    high_latitude_rule: str = AUTO
    rounding: str = NEAREST
    convention: str = "DUM_RT"            # or ASTRONOMICAL
    congregational_fajr_minutes: Optional[int] = None
    user_adjustments: Dict[str, int] = field(default_factory=dict)

    @property
    def m(self) -> Method:
        return METHODS[self.method]

    def adjustment_minutes(self, prayer: str) -> int:
        return self.m.method_adjustments.get(prayer, 0) + self.user_adjustments.get(prayer, 0)

    @property
    def fajr_before_sunrise_minutes(self) -> int:
        raw = self.congregational_fajr_minutes
        if raw is None:
            raw = self.m.congregational_fajr_before_sunrise
        return max(0, min(240, raw))

    def policy(self, prayer: str) -> MarkerPolicy:
        if self.convention == "ASTRONOMICAL":
            return MarkerPolicy(self.rounding, 0)
        return DUM_RT_POLICIES.get(prayer, MarkerPolicy(DOWN, 0))

# -------------------------------------------------------------- PrayerTimes.kt

EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)


def anchor_hours(d: Date, utc_offset_hours: float) -> float:
    """Hours from 00:00 UTC of `d` to local noon of `d`."""
    return 12.0 - utc_offset_hours



def _round_to_minute(dt: datetime, mode: str) -> datetime:
    seconds = int((dt - EPOCH).total_seconds())
    remainder = ((seconds % 60) + 60) % 60
    floor = seconds - remainder
    if mode == DOWN:
        result = floor
    elif mode == UP:
        result = floor if remainder == 0 else floor + 60
    else:
        result = floor + 60 if remainder >= 30 else floor
    return EPOCH + timedelta(seconds=result)

class PrayerTimes:
    """Same five steps as the Kotlin class, in the same order."""

    def __init__(self, d: Date, coordinates: Coordinates, params: Params,
                 utc_offset_hours: float = 0.0):
        self.date = d
        anchor = anchor_hours(d, utc_offset_hours)
        solar = SolarTime.of(d, coordinates, anchor)
        tomorrow = d + timedelta(days=1)
        tomorrow_solar = SolarTime.of(tomorrow, coordinates, anchor)
        # Sahar belongs to the night that ends at this morning's sunrise - see the Kotlin comment.
        yesterday_solar = SolarTime.of(d - timedelta(days=1), coordinates, anchor)
        base = datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
        tomorrow_base = base + timedelta(days=1)

        def to_instant(origin: datetime, hours: float) -> Optional[datetime]:
            if hours is None or math.isnan(hours) or math.isinf(hours):
                return None
            return origin + timedelta(milliseconds=math.floor(hours * 3600_000.0 + 0.5))

        m = params.m
        # No re-normalisation here: SolarTime is already pinned to this local day, and every root
        # is within +-12 h of its transit by construction. Re-anchoring events individually would
        # push a tangency dawn - which legitimately sits almost exactly 12 h from noon - into the
        # next day.
        transit_h = solar.transit
        sunrise_h = solar.sunrise
        sunset_h = solar.sunset
        tomorrow_transit_h = tomorrow_solar.transit
        tomorrow_sunrise_h = tomorrow_solar.sunrise

        sunrise_time = to_instant(base, sunrise_h)
        sunset_time = to_instant(base, sunset_h)
        transit_time = to_instant(base, transit_h)
        tomorrow_sunrise = to_instant(tomorrow_base, tomorrow_sunrise_h)
        yesterday_sunset = to_instant(base - timedelta(days=1), yesterday_solar.sunset)

        # ---- Step 1: pure astronomy
        sahar_time = to_instant(base, solar.hour_angle(-m.fajr_angle, False))
        sahar_from = ANGLE
        self.sahar_raw = sahar_time
        asr_time = to_instant(base, solar.afternoon(params.shadow_length))
        if m.maghrib_angle > 0.0:
            maghrib_time = to_instant(
                base, solar.hour_angle(-m.maghrib_angle, True)) or sunset_time
        else:
            maghrib_time = sunset_time

        sahar_before_sunrise: Optional[int] = None
        isha_after_sunset: Optional[int] = None
        if m.isha_interval_minutes > 0:
            isha_time = sunset_time + timedelta(minutes=m.isha_interval_minutes) if sunset_time else None
            isha_after_sunset = m.isha_interval_minutes
            isha_from = METHOD_INTERVAL
        else:
            isha_time = to_instant(base, solar.hour_angle(-m.isha_angle, True))
            isha_from = ANGLE
        self.isha_raw = isha_time

        # ---- Step 2: fallback only where astronomy came back empty
        #
        # "Came back empty" is not the same as "returned a number". The Meeus root finder decides
        # reachability from the declination at transit, so on a tangency night it happily returns a
        # root on the *descending* branch - an evening crossing dressed up as a dawn. Kazan,
        # 8 August 2026: the Sun bottoms out at -17.976 deg, never reaching the 18 deg dawn angle,
        # and the raw root comes back as 23:46:30 the previous evening. That is what printed a
        # 23:49 suhoor next to a 02:31 Fajr.
        #
        # A morning root is only a dawn if it happens after solar midnight; an evening root is only
        # Isha if it happens before it. The margin also discards a root that merely grazes the angle
        # around solar midnight: there twilight never really ends and the interval the board prints
        # is the honest answer.
        nadir_before = to_instant(base, transit_h - 12.0)
        nadir_after = to_instant(base, transit_h + 12.0)
        tangency = timedelta(seconds=TANGENCY_MARGIN_SECONDS)

        if sahar_time is not None and nadir_before is not None and sahar_time < nadir_before + tangency:
            sahar_time = None
        if (isha_from == ANGLE and isha_time is not None and nadir_after is not None
                and isha_time > nadir_after - tangency):
            isha_time = None

        night_length = None
        morning_night_length = None
        if sunrise_time and sunset_time and tomorrow_sunrise:
            night_span = tomorrow_sunrise - sunset_time
            night_length = night_span
            night_seconds = int(night_span.total_seconds())
            morning_night_seconds = (int((sunrise_time - yesterday_sunset).total_seconds())
                                     if yesterday_sunset is not None else night_seconds)
            morning_night_length = timedelta(seconds=morning_night_seconds)
            rule = resolve_rule(params.high_latitude_rule, coordinates.latitude)

            if rule == SEVENTH_OF_THE_NIGHT:
                frac = (1 / 7, 1 / 7)
            elif rule == TWILIGHT_ANGLE:
                frac = (m.fajr_angle / 60.0, (m.isha_angle if m.isha_angle > 0 else 17.0) / 60.0)
            else:
                frac = (0.5, 0.5)

            # The Russian boards treat the short-night season as one regime: the poster carries a
            # single banner, "МЕНЯЕТСЯ ВРЕМЯ СУХУРА И ИША", and moves both markers together instead
            # of letting each leave on its own day. The season is judged by the dawn angle - the
            # stricter of the two - over this night and the next, with the same tangency test. That
            # is what reproduces the calendar's asymmetry on the closing day: Isha is already
            # astronomical while Sahar is still an interval.
            tomorrow_nadir = to_instant(tomorrow_base, tomorrow_transit_h - 12.0)
            tomorrow_sahar = to_instant(
                tomorrow_base, tomorrow_solar.hour_angle(-m.fajr_angle, False))
            tomorrow_usable = (tomorrow_sahar is not None and tomorrow_nadir is not None
                               and tomorrow_sahar >= tomorrow_nadir + tangency)
            short_night_season = (rule == RULE_FIXED_INTERVAL and sahar_time is None
                                  and not tomorrow_usable)

            # A printed interval assumes a night long enough to hold it; in the white-night season
            # it is not. Keep the interval exactly as printed while it fits, otherwise scale both by
            # the same factor into the night that exists - see the Kotlin comment.
            breathing_room = 15 * 60
            wanted_sahar = m.night_fajr_minutes * 60
            wanted_isha = m.night_isha_minutes * 60
            tightest_night = min(night_seconds, morning_night_seconds)
            intervals_fit = wanted_sahar + wanted_isha + breathing_room <= tightest_night
            squeeze = (1.0 if intervals_fit
                       else (tightest_night - breathing_room) / (wanted_sahar + wanted_isha))

            if sahar_time is None:
                if rule == RULE_FIXED_INTERVAL:
                    if intervals_fit:
                        sahar_time = sunrise_time - timedelta(seconds=wanted_sahar)
                        sahar_before_sunrise = m.night_fajr_minutes
                        sahar_from = FIXED_INTERVAL
                    else:
                        sahar_time = sunrise_time - timedelta(
                            seconds=math.floor(wanted_sahar * squeeze + 0.5))
                        sahar_from = NIGHT_FRACTION
                else:
                    sahar_time = sunrise_time - timedelta(
                        seconds=math.floor(night_seconds * frac[0] + 0.5))
                    sahar_from = NIGHT_FRACTION
            if isha_time is None or (short_night_season and isha_from == ANGLE):
                if rule == RULE_FIXED_INTERVAL:
                    if intervals_fit:
                        isha_time = sunset_time + timedelta(seconds=wanted_isha)
                        isha_after_sunset = m.night_isha_minutes
                        isha_from = FIXED_INTERVAL
                    else:
                        isha_time = sunset_time + timedelta(
                            seconds=math.floor(wanted_isha * squeeze + 0.5))
                        isha_from = NIGHT_FRACTION
                else:
                    isha_time = sunset_time + timedelta(
                        seconds=math.floor(night_seconds * frac[1] + 0.5))
                    isha_from = NIGHT_FRACTION

            # Last-resort guard. With the tangency test and the local-noon anchor above this should
            # never fire; it stays so that a future method with an exotic angle cannot publish a
            # marker outside its own night.
            sahar_floor = sunrise_time - timedelta(seconds=night_seconds // 2)
            isha_ceiling = sunset_time + timedelta(seconds=night_seconds // 2)
            if sahar_time is not None and sahar_time < sahar_floor and sahar_before_sunrise is None:
                sahar_time = sahar_floor
                sahar_from = MIDNIGHT_BOUND
            if isha_time is not None and isha_time > isha_ceiling and isha_after_sunset is None:
                isha_time = isha_ceiling
                isha_from = MIDNIGHT_BOUND

        asr_degraded = False
        if asr_time is None:
            asr_time = to_instant(base, solar.afternoon(1.0))
            if asr_time is not None:
                asr_degraded = True
        if asr_time is None and transit_time and maghrib_time:
            span = int((maghrib_time - transit_time).total_seconds())
            asr_time = transit_time + timedelta(seconds=span * 2 // 3)
            asr_degraded = True

        # ---- Step 3: publication
        def publish(prayer: str, value: Optional[datetime]) -> Optional[datetime]:
            if value is None:
                return None
            policy = params.policy(prayer)
            shifted = value + timedelta(
                seconds=params.adjustment_minutes(prayer) * 60 + policy.offset_seconds)
            return _round_to_minute(shifted, policy.rounding)

        published_sunrise = publish(SUNRISE, sunrise_time)
        published_maghrib = publish(MAGHRIB, maghrib_time)

        if sahar_before_sunrise is not None and published_sunrise is not None:
            published_sahar = (published_sunrise - timedelta(minutes=sahar_before_sunrise)
                               + timedelta(minutes=params.adjustment_minutes(SAHAR)))
        else:
            published_sahar = publish(SAHAR, sahar_time)
        if isha_after_sunset is not None and published_maghrib is not None:
            published_isha = (published_maghrib + timedelta(minutes=isha_after_sunset)
                              + timedelta(minutes=params.adjustment_minutes(ISHA)))
        else:
            published_isha = publish(ISHA, isha_time)

        # ---- Step 4: congregational Fajr from the published sunrise
        gap = params.fajr_before_sunrise_minutes
        if published_sunrise is None or gap == 0:
            fajr_from = ANGLE if gap == 0 else sahar_from
            published_fajr = published_sahar
        else:
            candidate = published_sunrise - timedelta(minutes=gap)
            if published_sahar is not None and candidate < published_sahar:
                fajr_from = DAWN_BOUND
                published_fajr = published_sahar
            else:
                fajr_from = CONGREGATION
                published_fajr = candidate + timedelta(minutes=params.adjustment_minutes(FAJR))

        self.sahar_source = sahar_from
        self.isha_source = isha_from
        self.fajr_source = fajr_from
        self.night = night_length
        self.morning_night = morning_night_length
        shortest = min((x for x in (night_length, morning_night_length) if x is not None),
                       default=None)
        self.night_unusable = (shortest is not None
                               and shortest.total_seconds() < MIN_USABLE_NIGHT_SECONDS)
        self.used_high_latitude_rule = (
            asr_degraded or sahar_from != ANGLE
            or (isha_from not in (ANGLE, METHOD_INTERVAL)))

        raw = {
            SAHAR: published_sahar, FAJR: published_fajr, SUNRISE: published_sunrise,
            DHUHR: publish(DHUHR, transit_time), ASR: publish(ASR, asr_time),
            MAGHRIB: published_maghrib, ISHA: published_isha,
        }
        self.times = self._enforce_order(raw)

    @staticmethod
    def _enforce_order(source: Dict[str, Optional[datetime]]) -> Dict[str, Optional[datetime]]:
        result = dict(source)
        sunrise = result[SUNRISE]
        if sunrise is not None:
            if result[FAJR] is not None and result[FAJR] >= sunrise:
                result[FAJR] = sunrise - timedelta(minutes=1)
            fajr = result[FAJR] or sunrise
            if result[SAHAR] is not None and result[SAHAR] > fajr:
                result[SAHAR] = fajr
        previous = None
        for prayer in ORDER:
            value = result.get(prayer)
            if value is None:
                continue
            bound = previous
            must_be_strictly_after = not (prayer == FAJR and bound == result[SAHAR])
            if bound is not None and must_be_strictly_after and value <= bound:
                result[prayer] = bound + timedelta(minutes=1)
            elif bound is not None and value < bound:
                result[prayer] = bound
            previous = result[prayer]
        return result

    @property
    def is_complete(self) -> bool:
        return all(v is not None for v in self.times.values())

    @property
    def is_publishable(self) -> bool:
        """Complete and with a night long enough to hold the markers - see MIN_USABLE_NIGHT_SECONDS."""
        return self.is_complete and not self.night_unusable
