#!/usr/bin/env python3
"""
Audits the prayer engine over every city in the app and every day of a year.

Runs on the Python port (tools/prayer_port.py), so it needs neither the Android SDK nor a network,
and it catches the class of bug that unit tests on four days cannot: an order violation or an
absurd interval that only appears on one day of one season in one city.

Checks per city-day:
  * strictly non-decreasing order across all seven markers;
  * Sahar strictly inside the night, never landing in the previous evening;
  * plausible intervals: dawn->sunrise and sunset->Isha inside sane bounds;
  * no null value outside a genuine polar day / polar night.

Usage:  python3 tools/validate_times.py [--year 2026] [--step 1] [--city Казань]
"""
import argparse, json, os, sys
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prayer_port import (Coordinates, Params, PrayerTimes, ORDER, SAHAR, FAJR, SUNRISE, DHUHR,
                         ASR, MAGHRIB, ISHA)

ASSET = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     "..", "app", "src", "main", "assets", "cities_ru.json")


def load_cities():
    with open(ASSET, encoding="utf-8") as handle:
        return json.load(handle)


def audit(cities, year, step, params):
    problems, polar = [], {}
    day_count = 0
    for city in cities:
        coords = Coordinates(city["lat"], city["lon"])
        zone = ZoneInfo(city["tz"])
        d = date(year, 1, 1)
        last_maghrib = None
        while d.year == year:
            offset_hours = datetime.combine(d, time(12, 0), zone).utcoffset().total_seconds() / 3600.0
            times = PrayerTimes(d, coords, params, offset_hours)
            day_count += 1
            local = {k: (v.astimezone(zone) if v else None) for k, v in times.times.items()}

            if not times.is_publishable:
                # Polar day/night, or a white night too short to publish: the app resolves these
                # through Aqrab al-Ayyam, so there is no marker to check here.
                polar[city["name"]] = polar.get(city["name"], 0) + 1
                d += timedelta(days=step)
                continue

            previous = None
            for prayer in ORDER:
                value = local[prayer]
                if previous is not None and value < previous:
                    problems.append(f"{city['name']} {d} {prayer}: порядок нарушен")
                previous = value

            previous_sunset = last_maghrib or (local[SAHAR] - timedelta(hours=1))

            dawn_gap = (local[SUNRISE] - local[SAHAR]).total_seconds() / 60
            isha_gap = (local[ISHA] - local[MAGHRIB]).total_seconds() / 60
            if not 20 <= dawn_gap <= 420:
                problems.append(f"{city['name']} {d}: сухур→восход {dawn_gap:.0f} мин")
            if not 20 <= isha_gap <= 330:
                problems.append(f"{city['name']} {d}: магриб→иша {isha_gap:.0f} мин")
            # Sahar may legitimately land before local midnight: north of ~55 deg in May-July
            # astronomical dawn starts before 00:00, and the fixed-interval fallback (sunrise - 120)
            # does the same. What must never happen is Sahar drifting into the previous *evening*,
            # i.e. before that evening's sunset, or landing after Fajr.
            if local[SAHAR] > local[FAJR]:
                problems.append(f"{city['name']} {d}: сухур {local[SAHAR]:%H:%M} не раньше фаджра")
            if local[SAHAR] <= previous_sunset:
                problems.append(
                    f"{city['name']} {d}: сухур уехал в вечер {local[SAHAR]:%d.%m %H:%M}")
            last_maghrib = local[MAGHRIB] if step == 1 else None
            d += timedelta(days=step)
    return problems, polar, day_count


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--year", type=int, default=2026)
    parser.add_argument("--step", type=int, default=1)
    parser.add_argument("--city")
    parser.add_argument("--method", default="RUSSIA_DUM")
    args = parser.parse_args()

    cities = load_cities()
    if args.city:
        cities = [c for c in cities if args.city.lower() in c["name"].lower()]
    params = Params(method=args.method)

    problems, polar, day_count = audit(cities, args.year, args.step, params)

    print(f"Метод {args.method}: проверено {len(cities)} городов × {args.year} год (шаг {args.step}) = "
          f"{day_count} городо-дней")
    if polar:
        print("\nПолярные дни/ночи (маркер по углу отсутствует, ожидаемо):")
        for name, count in sorted(polar.items(), key=lambda kv: -kv[1]):
            print(f"  {name}: {count} дней")
    if problems:
        print(f"\nНАРУШЕНИЙ: {len(problems)}")
        for line in problems[:60]:
            print("  " + line)
        if len(problems) > 60:
            print(f"  ... и ещё {len(problems) - 60}")
        return 1
    print("\nНарушений порядка и неправдоподобных интервалов: 0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
