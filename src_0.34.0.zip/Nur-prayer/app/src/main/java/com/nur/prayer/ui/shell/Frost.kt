package com.nur.prayer.ui.shell

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.isSpecified
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.wallpaper.PAGE_DIM
import com.nur.prayer.ui.wallpaper.Wallpaper
import com.nur.prayer.ui.wallpaper.WallpaperImages
import com.nur.prayer.ui.wallpaper.WallpaperScreen
import com.nur.prayer.ui.wallpaper.drawWallpaperIn

/*
 * 0.27.1: the matte glass of the capsule, the panel, the island and the sheets: re-measured on the mock.
 *
 * 0.27.0 read the mock by eye and got it wrong: a glass at 72–82 % over a *lighter* blurred picture came
 * out grey (#545358 on the Kaaba wallpaper, the mock is #121522), a vertical gradient with a bright top
 * edge and a deep shadow made the capsule look puffed up. The mock is the opposite: almost opaque deep
 * navy, flat, with one even 1 dp hairline and no visible shadow. So now, layer by layer:
 *
 *  1. the wallpaper blurred (WallpaperImages.frost), drawn exactly where the sharp picture is on screen;
 *  2. black over it, [SheetGlass.PICTURE_DIM] at least (more where a page darkens the picture): the glass
 *     is the same dark over a white wallpaper as over a black one;
 *  3. the tint, #12141F → #0F111B at 90 %: a 3-level gradient, not a bulge;
 *  4. a 1 dp hairline of the same 14 % white all the way round;
 *  5. outside: a very faint halo, three flat low-alpha plates (no elevation shadow: its mesh is rebuilt
 *     every frame while the shape morphs and that was a part of the lag).
 *
 * Layers 1–4 are drawn inside the clip of the shape (a rounded rectangle, hardware-clipped), so there is
 * no per-frame Path and no stencil. On «Живое небо» and «Чёрный» there is no picture to blur: the tint
 * alone, nearly opaque.
 */

/*
 * 0.33.0 «Минарет»: the capsule, the island and the panel are no longer the deep navy glass. The new mock is a
 * warm cream: an opaque body #EEDBCC with a lighter band (#F2E0D2) along its top, a 1 dp warm hairline
 * (#FFE8D2) all round, dark-brown ink. Opaque, so the colour is the same over every wallpaper and there is no
 * picture to blur (the light glass does not touch the frost bitmap at all). The prayer sheet keeps the old
 * dark glass ([GlassStyle.DARK], [SheetGlass]).
 */

/** Which glass a surface is made of. */
enum class GlassStyle { LIGHT, DARK }

/** What the glass shows through: the wallpaper on screen and how much the current page darkens it. */
@Stable
class FrostSource(val wallpaper: () -> Wallpaper, val dim: () -> Float)

val LocalFrost = staticCompositionLocalOf<FrostSource?> { null }

/**
 * The colours of the 0.33.0 mock, measured from its pixels (glass, rim, cards, wells, the gold of «now», the
 * browns of the ink). Everything the capsule, the panel, the island and the compass button are drawn with.
 */
object ShellColors {
    /** The lighter band along the top of the glass (#F1DFD1…#F2E0D2 in the mock) and the body below it. */
    val GlassTop = Color(0xFFF2E0D2)
    val Glass = Color(0xFFEEDBCC)
    /** Where the band ends, as a share of the glass height (the capsule gets a thin one, the panel a 20 dp one). */
    const val GLASS_BAND = 0.07f
    /** Measured rim: #FFE7CE on #F1DFD1, one dp, warm. */
    val Edge = Color(0xE6FFE8D2)
    /** The roof of the panel: #EFDAC8 in the mock, a hair darker than the band under it. */
    val Roof = Color(0xFFEFDAC9)
    val Card = Color(0xFFF4E5D8)
    val CardPressed = Color(0xFFEBD8C9)
    /** The faint shadow under a card or a well (#EDDACB on #F0DDCF in the mock). */
    val Shade = Color(0x1F8C4F2E)
    val Well = Color(0xFFF1DFD1)
    val WellPressed = Color(0xFFE9D5C5)
    /** The gear's well is a hair darker than the glass; the section wells are a hair lighter. */
    val GearWell = Color(0xFFECD9CA)
    val Rim = Color(0xFFFFF1E4)
    val Divider = Color(0xFFDFC9B7)
    /** The ornaments: the dome by the header and the arch on the divider (#E6CDB6 in the mock). */
    val Ornament = Color(0xFFE2C8B0)
    /** Text and icons: dark espresso for what is read, browns for what is around it. */
    val Ink = Color(0xFF2E1A0E)
    val Secondary = Color(0xFF6E4E3A)
    val Label = Color(0xFF5F4230)
    val Icon = Color(0xFF5C3A28)
    val Speaker = Color(0xFF6A4E3F)
    /** The speaker of a time without a call (sunrise, or a prayer whose azan is off): the same brown at 70 %, still 3:1 on the card. */
    val SpeakerMuted = Color(0xB36A4E3F)
    /** The gold of «now» (#F2C896), the dark brown on it, and the accent a small gold dot needs on cream. */
    val Gold = Color(0xFFF2C896)
    val GoldCard = Color(0xFFF2C896)
    val OnGold = Color(0xFF3A1D06)
    val OnGoldSoft = Color(0xFF653D17)
    val OnGoldMuted = Color(0xB3653D17)
    val Accent = Color(0xFFE0993F)
}

/** The dark glass of the sheets, unchanged since 0.27.1. */
internal object SheetGlass {
    val TintTop = Color(0xFF12141F)
    val TintBottom = Color(0xFF0F111B)
    const val TINT_ALPHA = 0.90f
    const val TINT_PLAIN_ALPHA = 0.96f
    /** Black over the blurred picture before the tint: a light wallpaper must not lift the glass. */
    const val PICTURE_DIM = ShellMath.PICTURE_DIM
    val Edge = Color(0x24FFFFFF)
}

/** One handle per glass surface: the blurred picture and where on screen the surface is. */
@Stable
class FrostHandle internal constructor(internal val source: FrostSource?) {
    internal var bitmap by mutableStateOf<ImageBitmap?>(null)
    internal var wallpaper by mutableStateOf<Wallpaper?>(null)
    internal var originInRoot by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberFrost(): FrostHandle {
    val source = LocalFrost.current
    val handle = remember(source) { FrostHandle(source) }
    val context = LocalContext.current
    val wallpaper = source?.wallpaper?.invoke()
    val screen by WallpaperScreen.size
    LaunchedEffect(handle, wallpaper?.id, screen) {
        handle.wallpaper = wallpaper
        if (wallpaper == null || !wallpaper.isImage) {
            handle.bitmap = null
            return@LaunchedEffect
        }
        handle.bitmap = WallpaperImages.peekFrost(wallpaper, screen.width, screen.height)
            ?: WallpaperImages.frost(context, wallpaper, screen.width, screen.height)
    }
    return handle
}

/**
 * Paints the glass of [shape] behind the content of this element and clips the content to it. Read
 * only while drawing: a panel that changes size every frame redraws, it does not recompose.
 *
 *  - [halo]: the faint plates outside the shape. Off for a sheet that touches the screen edges.
 *  - [track]: the glass follows where it is on screen by itself (onGloballyPositioned). A surface that
 *    is moved by a layer transform (a sheet sliding up) sets it off and sets [FrostHandle.originInRoot] itself.
 *  - [wash]: a colour laid very lightly over the tint (the prayer sheet carries the colour of its sky).
 */
fun Modifier.frostGlass(
    frost: FrostHandle,
    shape: Shape,
    halo: Boolean = true,
    track: Boolean = true,
    edge: Boolean = true,
    wash: Color = Color.Unspecified,
    style: GlassStyle = GlassStyle.LIGHT
): Modifier = this
    .then(if (halo) Modifier.glassHalo(shape, if (style == GlassStyle.LIGHT) LIGHT_HALO else 1f) else Modifier)
    .then(if (track && style == GlassStyle.DARK) Modifier.onGloballyPositioned { frost.originInRoot = it.positionInRoot() } else Modifier)
    .clip(shape)
    .drawBehind {
        if (style == GlassStyle.LIGHT) {
            // Opaque cream: no picture, no dim; a lighter band at the top, then the flat body.
            drawRect(
                Brush.verticalGradient(
                    0f to ShellColors.GlassTop,
                    ShellColors.GLASS_BAND to ShellColors.Glass,
                    1f to ShellColors.Glass
                )
            )
            if (edge) {
                drawOutline(
                    shape.createOutline(size, layoutDirection, this),
                    ShellColors.Edge,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        } else {
            val bitmap = frost.bitmap
            val wallpaper = frost.wallpaper
            val screen = WallpaperScreen.size.value
            val picture = bitmap != null && wallpaper != null && screen.width > 0 && screen.height > 0
            if (picture) {
                val o = frost.originInRoot
                translate(-o.x, -o.y) {
                    drawWallpaperIn(bitmap!!, wallpaper!!, screen.width.toFloat(), screen.height.toFloat(), FilterQuality.Low)
                }
                drawRect(Color.Black.copy(alpha = ShellMath.pictureDim(frost.source?.dim?.invoke() ?: 0f, PAGE_DIM)))
            }
            val a = if (picture) SheetGlass.TINT_ALPHA else SheetGlass.TINT_PLAIN_ALPHA
            drawRect(Brush.verticalGradient(listOf(SheetGlass.TintTop.copy(alpha = a), SheetGlass.TintBottom.copy(alpha = a))))
            if (wash.isSpecified) drawRect(wash.copy(alpha = WASH_ALPHA))
            if (edge) {
                // Twice the hairline, centred on the outline: the half outside the clip is cut, 1 dp stays.
                drawOutline(
                    shape.createOutline(size, layoutDirection, this),
                    SheetGlass.Edge,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }

private const val WASH_ALPHA = 0.20f

/** The light glass needs less of a halo than the dark one: a cream body already reads on any picture. */
private const val LIGHT_HALO = 0.7f

/** Three flat, very faint plates around a rounded shape: enough to lift it off the picture, nothing more. */
private fun Modifier.glassHalo(shape: Shape, strength: Float): Modifier = drawBehind {
    val outline = shape.createOutline(size, layoutDirection, this)
    if (outline !is Outline.Rounded) return@drawBehind
    val box = outline.roundRect
    val r = box.topLeftCornerRadius.x
    HALO.forEach { plate ->
        val grow = plate.grow.dp.toPx()
        drawRoundRect(
            Color.Black.copy(alpha = plate.alpha * strength),
            topLeft = Offset(box.left - grow, box.top - grow + plate.drop.dp.toPx()),
            size = Size(box.width + 2f * grow, box.height + 2f * grow),
            cornerRadius = CornerRadius(r + grow)
        )
    }
}

private class Plate(val grow: Float, val drop: Float, val alpha: Float)

private val HALO = listOf(Plate(2f, 3f, 0.10f), Plate(6f, 6f, 0.06f), Plate(11f, 9f, 0.035f))
