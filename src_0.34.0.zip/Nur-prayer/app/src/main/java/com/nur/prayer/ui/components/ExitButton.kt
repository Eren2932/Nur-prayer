package com.nur.prayer.ui.components

import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr

/*
 * 0.34.0: the one way out of every page. Measured from the reference: a ring 30 dp across with a 2 dp white stroke,
 * a 2 dp ✕ in it, no fill, a faint dark halo so it reads over any card or picture; 18 dp from the right edge of the
 * screen and about 20 dp above the bottom (above the navigation bar when there is one).
 *
 * The finger gets a 52 dp square around the ring. Whoever places it (NurRoot for the pages, the gallery for itself)
 * uses [ExitButtonSpec] so the ring is in the very same place on every screen.
 */
object ExitButtonSpec {
    /** Touch square around the ring. */
    val Hit = 52.dp
    /** Distance of the touch square from the right edge: the ring ends 18 dp from it. */
    val EndPad = 7.dp
    /** Distance of the touch square from the bottom (above the navigation bar): the ring starts 20 dp above it. */
    val BottomPad = 9.dp
    /** What a scrolling page keeps free above the bottom dock so its last card is never under the ring. */
    val ExtraRoom = 32.dp
    /**
     * How far the ring stands above its usual place on a page that has the capsule: the ring's lower edge then
     * clears the capsule's top edge by 10 dp (capsule 13 dp above the bar + 64 dp tall; the ring starts 20 dp up).
     */
    val CapsuleLift = 67.dp
    /** The ring fades in and out in this time: quick, never a motion of its own. */
    const val FADE_MILLIS = 140
}

/**
 * What the ring does: the system's back, exactly as the gesture would. Every page already answers it (its own
 * [androidx.activity.compose.BackHandler] first, the navigator last), so one ring serves all of them and an editor
 * inside a page closes itself before the page does. The keyboard goes first, or it would hang over the page below.
 */
@Composable
fun rememberSystemBack(): () -> Unit {
    val dispatcher = LocalOnBackPressedDispatcherOwner.current?.onBackPressedDispatcher
    val keyboard = LocalSoftwareKeyboardController.current
    return remember(dispatcher, keyboard) {
        val action: () -> Unit = {
            keyboard?.hide()
            dispatcher?.onBackPressed()
        }
        action
    }
}

@Composable
fun ExitButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    description: String = tr("Назад"),
    tint: Color = Color.White
) {
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.9f else 1f, tween(90), label = "exitPress")
    Box(
        modifier = modifier
            .size(ExitButtonSpec.Hit)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .semantics { contentDescription = description }
            .clickable(interactionSource = interaction, indication = null, role = Role.Button) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(30.dp)) {
            val ring = 2.dp.toPx()
            val r = size.minDimension / 2f
            val c = Offset(size.width / 2f, size.height / 2f)
            // A faint halo first: two widening dark rings under the white one.
            drawCircle(Color(0x1F000000), radius = r - ring / 2f, center = c, style = Stroke(width = ring + 5.dp.toPx()))
            drawCircle(Color(0x24000000), radius = r - ring / 2f, center = c, style = Stroke(width = ring + 2.5.dp.toPx()))
            drawCircle(tint, radius = r - ring / 2f, center = c, style = Stroke(width = ring))
            val d = 5.2.dp.toPx()
            val cross = 2.dp.toPx()
            drawLine(tint, Offset(c.x - d, c.y - d), Offset(c.x + d, c.y + d), strokeWidth = cross, cap = StrokeCap.Round)
            drawLine(tint, Offset(c.x + d, c.y - d), Offset(c.x - d, c.y + d), strokeWidth = cross, cap = StrokeCap.Round)
        }
    }
}
