package com.nur.prayer.ui.shell

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.paddingFromBaseline
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.toRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.home.HomeSection
import com.nur.prayer.ui.home.HomeTimeline
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/*
 * 0.27.0 «Капсула» (variant D of the redesign).
 *
 *  - Home: the times are printed on the wallpaper; at the bottom one floating capsule says what fits
 *    this moment («Вечерние азкары · сейчас · 0 из 12»). A tap on its text starts that; a tap on the
 *    dots opens the panel.
 *  - The panel is the same glass grown in place (shared bounds): today's six times (a tap opens the
 *    prayer's sheet, the speaker marks the azan) and the six sections, each one tap away. A tap
 *    beside it, or back, folds it back into the capsule.
 *  - In a section the capsule says where you are («Кыбла · тап — другие разделы») and opens the same
 *    panel; the moon leads home; the countdown lives in the island at the top.
 *
 * No swipes and no hidden gestures: everything is visible and tappable, TalkBack reads it as is.
 * Every sizes and colours here are taken from the mock (see ShellColors).
 *
 * 0.33.0 «Минарет»: a new mock. The glass is a warm cream with dark-brown ink (see ShellColors); the open panel
 * is rebuilt to it (header with an ornament, taller cards with the speaker in the corner, a divider with an
 * arch, wells with the designer's glyphs) and carries a minaret roof on top, which the clock of home gives
 * way to (Minaret.kt). Every size below is a measurement of the mock at 2.763 px per dp (1086 px = 393 dp):
 * the comments give the pixels they come from.
 *
 * 0.27.1, the motion:
 *  - the capsule and the panel stay composed for as long as the capsule is on a route. Opening used to
 *    compose ~60 nodes of the panel on the first frame of the morph (and the capsule's content again on
 *    the last frame of the fold): that was the stutter. Now only a float moves;
 *  - layers fade per draw call ([CompositingStrategy.ModulateAlpha]): no offscreen buffer the size of the
 *    panel in every frame of the fade;
 *  - the glass has no elevation shadow and no path clip (see Frost.kt);
 *  - a capsule that comes or goes slides by a layout offset, not a layer translation, so the glass keeps
 *    knowing where on screen it is and the blurred picture inside it never lags behind;
 *  - [ShellState.capsuleHidden]: a page can send the capsule away (the Quran reader while one reads) and
 *    call it back with one float.
 */

/** What the capsule says on home: the thing that fits this moment, and what a tap on it does. */
@Immutable
class CapsuleNow(
    val title: String,
    val subtitle: String,
    val glyph: ShellGlyph,
    val onClick: () -> Unit
)

private val CAPSULE_HEIGHT = 64.dp
private val CAPSULE_MIN_WIDTH = 288.dp
private val CAPSULE_MAX_WIDTH = 400.dp
private val PANEL_MAX_WIDTH = 460.dp
/** 0.33.0: 55 px of 1086 in the mock: 20 dp on both sides. */
private val PANEL_SIDE = 20.dp
private val PANEL_CORNER = 32.dp
/** What the home and the pages reserve under their content for the capsule. Unchanged since 0.27.0. */
private val BOTTOM_GAP = 14.dp

/** 0.30.2: where the capsule really stands above the navigation bar: 1 dp lower than the room it has reserved. */
private val CAPSULE_BOTTOM = 13.dp

/** Bottom room the capsule takes above the navigation bar; pages under it pad their lists by it. */
val CapsuleRoom = CAPSULE_HEIGHT + BOTTOM_GAP + 12.dp

/** Room the island takes under the status bar; page headers step down by it. */
val IslandRoom = 50.dp

@Composable
fun ShellLayer(
    shell: ShellState,
    route: String,
    data: PrayerData,
    now: State<ZonedDateTime>,
    home: CapsuleNow,
    onOpenSection: (HomeSection, Offset) -> Unit,
    onHome: (Offset) -> Unit,
    onOpenPrayer: (Prayer) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val capsuleOn = ShellRoutes.capsuleOn(route)
    val islandOn = ShellRoutes.islandOn(route)
    // The page under the capsule keeps being named while the capsule slides away with it.
    val lastSection = remember { arrayOfNulls<HomeSection>(1) }
    val liveSection = ShellRoutes.sectionOf(route)
    if (capsuleOn) lastSection[0] = liveSection
    val section = if (capsuleOn) liveSection else lastSection[0]

    // A hidden capsule is not a capsule the panel can grow out of.
    val capsuleVisible = ShellMath.capsuleVisible(capsuleOn, shell.capsuleHidden)
    LaunchedEffect(capsuleVisible) { if (!capsuleVisible) shell.hide() }
    LaunchedEffect(shell.open) {
        coroutineScope {
            // 0.30.2: the vibrator call goes after the first frame of the morph, not in front of it: on a
            // phone where it takes a few milliseconds that used to be a hitch right at the tap.
            if (shell.open) launch {
                withFrameNanos { }
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            }
            shell.settle()
        }
    }
    BackHandler(enabled = shell.open) { shell.hide() }

    val panelOnScreen by remember(shell) { derivedStateOf { shell.open || shell.progress > 0.001f } }
    val capsuleShown = animateFloatAsState(
        if (capsuleVisible) 1f else 0f,
        tween(if (capsuleVisible) 320 else 200, easing = FastOutSlowInEasing),
        label = "capsuleShown"
    )
    val islandShown = animateFloatAsState(
        if (islandOn) 1f else 0f,
        tween(if (islandOn) 320 else 180, easing = FastOutSlowInEasing),
        label = "islandShown"
    )
    val capsuleComposed by remember { derivedStateOf { capsuleOn || capsuleShown.value > 0f } }
    val islandComposed by remember { derivedStateOf { islandOn || islandShown.value > 0f } }

    Box(modifier.fillMaxSize()) {
        if (panelOnScreen) {
            // A tap anywhere beside the panel folds it; the page under it stays where it was.
            Box(
                Modifier
                    .fillMaxSize()
                    .drawBehind { drawRect(Color.Black, alpha = SCRIM_ALPHA * shell.progress.coerceIn(0f, 1f)) }
                    .pointerInput(shell) { detectTapGestures { shell.hide() } }
            )
        }
        if (islandComposed) {
            TopIsland(
                data, now, onTap = onHome,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 6.dp)
                    .offset { IntOffset(0, (-(1f - islandShown.value) * 20.dp.toPx()).roundToInt()) }
                    .graphicsLayer {
                        val k = islandShown.value
                        alpha = k
                        compositingStrategy = CompositingStrategy.ModulateAlpha
                        val s = 0.92f + 0.08f * k
                        scaleX = s
                        scaleY = s
                    }
            )
        }
        if (capsuleComposed) {
            CapsuleMorph(
                shell = shell,
                visible = capsuleVisible,
                section = section,
                home = home,
                data = data,
                onOpenSection = { s, origin ->
                    shell.hide()
                    // The page the section opens on is already showing: folding the panel is the answer.
                    if (route != ShellRoutes.routeOf(s)) onOpenSection(s, origin)
                },
                onHome = { origin -> shell.hide(); onHome(origin) },
                onOpenPrayer = { p -> shell.hide(); onOpenPrayer(p) },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = CAPSULE_BOTTOM)
                    .offset { IntOffset(0, ((1f - capsuleShown.value) * ShellMath.SLIDE_DP.dp.toPx()).roundToInt()) }
                    .graphicsLayer {
                        alpha = capsuleShown.value
                        compositingStrategy = CompositingStrategy.ModulateAlpha
                    }
            )
        }
    }
}

private const val SCRIM_ALPHA = 0.30f

/** The rounded rectangle of the glass: a pill while closed, the panel's corners once open. */
private class MorphShape(private val shell: ShellState) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val p = shell.progress.coerceIn(0f, 1f)
        val r = with(density) { ShellMath.lerp(CAPSULE_HEIGHT.toPx() / 2f, PANEL_CORNER.toPx(), p) }
            .coerceAtMost(size.minDimension / 2f)
        return Outline.Rounded(RoundRect(size.toRect(), CornerRadius(r)))
    }
}

@Composable
private fun CapsuleMorph(
    shell: ShellState,
    visible: Boolean,
    section: HomeSection?,
    home: CapsuleNow,
    data: PrayerData,
    onOpenSection: (HomeSection, Offset) -> Unit,
    onHome: (Offset) -> Unit,
    onOpenPrayer: (Prayer) -> Unit,
    modifier: Modifier = Modifier
) {
    val frost = rememberFrost()
    val shape = remember(shell) { MorphShape(shell) }
    val open = shell.open

    // 0.33.0: the glass is one child and the roof another: the roof stands above the glass's top edge, outside
    // its clip. The box is exactly as big as the glass (the roof is narrower and hangs over the edge).
    Box(modifier) {
        Layout(
            content = {
                // Both faces stay composed; only the one that is up answers touches and TalkBack.
                Box(if (open || !visible) Modifier.clearAndSetSemantics { } else Modifier) {
                    CapsuleContent(
                        section = section, home = home, enabled = visible && !open,
                        onExpand = { shell.show() }, onHome = onHome
                    )
                }
                Box(if (open) Modifier else Modifier.clearAndSetSemantics { }) {
                    PanelContent(
                        data = data, current = section, enabled = open,
                        onOpenPrayer = onOpenPrayer, onOpenSection = onOpenSection
                    )
                }
            },
            modifier = Modifier
                .frostGlass(frost, shape)
                .onGloballyPositioned { c -> shell.glassBottomInRoot = c.boundsInRoot().bottom }
        ) { measurables, constraints ->
            val p = ShellMath.clampProgress(shell.progress)
            val maxW = constraints.maxWidth
            val capW = ShellMath.capsuleWidth(
                maxW.toFloat(), CAPSULE_MIN_WIDTH.toPx(), CAPSULE_MAX_WIDTH.toPx(), PANEL_SIDE.toPx()
            ).roundToInt().coerceAtMost(maxW)
            val capH = CAPSULE_HEIGHT.roundToPx()
            val panelW = minOf(maxW - 2 * PANEL_SIDE.roundToPx(), PANEL_MAX_WIDTH.roundToPx()).coerceAtLeast(capW)
            val capsule = measurables[0].measure(Constraints.fixed(capW, capH))
            val panel = measurables[1].measure(
                Constraints(minWidth = panelW, maxWidth = panelW, minHeight = 0, maxHeight = constraints.maxHeight)
            )
            val panelH = if (panel.height > 0) panel.height else capH
            val w = ShellMath.lerp(capW.toFloat(), panelW.toFloat(), ShellMath.widthProgress(p)).roundToInt().coerceIn(0, maxW)
            val h = ShellMath.lerp(capH.toFloat(), panelH.toFloat(), p).roundToInt().coerceIn(0, constraints.maxHeight)
            if (panel.height > 0) shell.panelHeightPx = panel.height.toFloat()
            shell.roofHeightPx = ShellMath.ROOF_DP.dp.toPx()
            layout(w, h) {
                capsule.placeWithLayer((w - capW) / 2, h - capH) {
                    alpha = ShellMath.capsuleAlpha(p)
                    compositingStrategy = CompositingStrategy.ModulateAlpha
                }
                panel.placeWithLayer((w - panelW) / 2, 0) {
                    alpha = ShellMath.panelAlpha(p)
                    compositingStrategy = CompositingStrategy.ModulateAlpha
                    translationY = (1f - p.coerceAtMost(1f)) * 14.dp.toPx()
                }
            }
        }
        MinaretRoof(shell, Modifier.align(Alignment.TopCenter).offset(y = -ShellMath.ROOF_DP.dp))
    }
}

@Composable
private fun CapsuleContent(
    section: HomeSection?,
    home: CapsuleNow,
    enabled: Boolean,
    onExpand: () -> Unit,
    onHome: (Offset) -> Unit
) {
    Crossfade(targetState = section, animationSpec = tween(220), label = "capsuleSection") { here ->
        val ui = uiScale()
        val title = here?.label() ?: home.title
        val subtitle = if (here == null) home.subtitle else tr("тап — другие разделы")
        val glyph = here?.glyph ?: home.glyph
        val endCenter = remember { arrayOf(Offset.Unspecified) }
        Row(
            Modifier.fillMaxSize().padding(start = 11.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(50))
                    .clickable(
                        enabled = enabled,
                        role = Role.Button,
                        onClickLabel = if (here == null) title else tr("Разделы"),
                        onClick = { if (here == null) home.onClick() else onExpand() }
                    )
                    .padding(end = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(42.dp).clip(CircleShape).background(ShellColors.GoldCard),
                    contentAlignment = Alignment.Center
                ) { ShellIcon(glyph, ShellColors.OnGold, Modifier.size(22.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    // Fits instead of cutting: «Вечерние азкары» is «азка…» on a narrow phone or a large font.
                    AutoSizeText(
                        title, color = ShellColors.Ink, fontSize = ui.t(16f), minFontSize = ui.t(12.5f),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        subtitle, color = ShellColors.Secondary, fontSize = ui.t(12.5f),
                        fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Box(Modifier.width(1.dp).height(30.dp).background(ShellColors.Divider))
            val endLabel = if (here == null) tr("Разделы") else tr("На главную")
            Box(
                Modifier
                    .padding(start = 6.dp)
                    .size(48.dp)
                    .onGloballyPositioned { endCenter[0] = it.boundsInRoot().center }
                    .clip(CircleShape)
                    .clickable(enabled = enabled, role = Role.Button, onClickLabel = endLabel) {
                        if (here == null) onExpand() else onHome(endCenter[0])
                    }
                    .semantics { contentDescription = endLabel },
                contentAlignment = Alignment.Center
            ) {
                if (here == null) ShellIcon(ShellGlyph.DOTS, ShellColors.Icon, Modifier.size(19.dp))
                else ShellIcon(ShellGlyph.MOON, ShellColors.Icon, Modifier.size(25.dp))
            }
        }
    }
}

/*
 * The open panel, top to bottom, with the mock's pixels (1086 px wide = 393 dp, 2.763 px per dp; y is counted
 * from the panel's top edge at 521 px, the roof stands above it):
 *
 *   header      11 dp over a 34 dp row (the gear's well is 92 px = 33 dp); the title starts 79 px = 28 dp in,
 *               the well ends 37 px = 13 dp from the right edge; 6 dp under it
 *   cards       two rows of three, 54 dp high (150 px), 14 dp corners, 12 dp from the edges (33 px), 9 dp
 *               between columns (25 px), 7 dp between rows (19 px). The label's baseline is 21.4 dp (59 px)
 *               under the card's top, the time's 43.4 dp (120 px); text starts 14 dp in; the speaker is a
 *               24 x 22 px glyph, 13 dp from the right and 14 dp from the top
 *   divider     6 dp under the cards, the line 6.6 dp into its 8 dp box, the arch on it; 12.4 dp below
 *   sections    wells of 40 dp (111 px), a row is 65.9 dp (182 px): the label's baseline 12.7 dp (35 px)
 *               under the well, 13.2 dp over the next one; 2.4 dp under the last row (panel: 327 dp = 903 px,
 *               the mock's is 901)
 */
private val PANEL_TOP = 11.dp
private val PANEL_BOTTOM = 2.4.dp
private val HEADER_HEIGHT = 34.dp
private val CARD_HEIGHT = 54.dp
private val CARD_CORNER = 14.dp
private val CARD_PAD = 12.dp
private val CARD_GAP = 9.dp
private val ROW_GAP = 7.dp
private val WELL = 40.dp

@Composable
private fun PanelContent(
    data: PrayerData,
    current: HomeSection?,
    enabled: Boolean,
    onOpenPrayer: (Prayer) -> Unit,
    onOpenSection: (HomeSection, Offset) -> Unit
) {
    val ui = uiScale()
    val date = data.today.date
    val nowPrayer = HomeTimeline.current(data.window, data.fajrEqualsDawn)
    val times = PanelTimes.PRAYERS
    var titleRight by remember { mutableFloatStateOf(0f) }
    Column(Modifier.fillMaxWidth().padding(top = PANEL_TOP, bottom = PANEL_BOTTOM)) {
        Box(Modifier.fillMaxWidth().height(HEADER_HEIGHT)) {
            HeaderOrnament(titleRight = { titleRight }, modifier = Modifier.fillMaxSize())
            Row(
                Modifier.fillMaxSize().padding(start = 28.dp, end = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${tr("Сегодня")} · ${Format.weekday(date)}",
                    color = ShellColors.Ink, fontSize = ui.t(13f), fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    onTextLayout = { titleRight = it.getLineRight(0) },
                    modifier = Modifier.weight(1f).offset(y = (-1.5).dp)
                )
                Text(
                    Format.dayMonth(date), color = ShellColors.Secondary, fontSize = ui.t(12.5f),
                    fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.offset(y = (-1).dp)
                )
                Spacer(Modifier.width(23.dp))
                SettingsGear(enabled = enabled, onOpen = { origin -> onOpenSection(HomeSection.SETTINGS, origin) })
            }
        }
        Spacer(Modifier.height(6.dp))
        Column(Modifier.fillMaxWidth().padding(horizontal = CARD_PAD), verticalArrangement = Arrangement.spacedBy(ROW_GAP)) {
            times.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CARD_GAP)) {
                    row.forEach { prayer ->
                        TimeCard(
                            prayer = prayer,
                            time = data.today.times[prayer]?.let(Format::time) ?: "—",
                            now = prayer == nowPrayer,
                            azan = PanelTimes.callOn(prayer, data.settings.notifications),
                            enabled = enabled,
                            onClick = { onOpenPrayer(prayer) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        PanelDivider(Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.4.dp))
        HomeSection.GRID.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = CARD_PAD)) {
                row.forEach { s ->
                    SectionCell(s, current = s == current, enabled = enabled, onOpen = onOpenSection, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

/** The soft shade a card or a well casts on the glass: the mock's #EDDACB under #F0DDCF, one dp below it. */
private fun Modifier.softShade(shape: Shape): Modifier = drawBehind {
    val outline = shape.createOutline(size, layoutDirection, this)
    translate(top = 1.2.dp.toPx()) { drawOutline(outline, ShellColors.Shade) }
}

/** The light that catches the upper-left rim of a well, as in the mock: a hairline that fades across it. */
private fun Modifier.rimLight(shape: Shape): Modifier =
    border(
        0.8.dp,
        Brush.linearGradient(listOf(ShellColors.Rim.copy(alpha = 0.95f), ShellColors.Rim.copy(alpha = 0f))),
        shape
    )

/**
 * 0.29.0: settings used to be an avatar in the corner of home. The corner is empty now; the way in is this
 * small button at the end of the panel's header, reachable from home and from every section alike.
 * 0.33.0: the mock's: a round well a hair darker than the glass with sliders on it.
 */
@Composable
private fun SettingsGear(enabled: Boolean, onOpen: (Offset) -> Unit) {
    val center = remember { arrayOf(Offset.Unspecified) }
    val label = tr("Настройки")
    Box(
        Modifier
            .size(34.dp)
            .onGloballyPositioned { center[0] = it.boundsInRoot().center }
            .softShade(CircleShape)
            .clip(CircleShape)
            .background(ShellColors.GearWell)
            .rimLight(CircleShape)
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) { onOpen(center[0]) }
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) { ShellIcon(ShellGlyph.TUNE, ShellColors.Icon, Modifier.size(16.dp)) }
}

/** The six times of the panel: the five prayers and sunrise, as in the mock. */
internal object PanelTimes {
    val PRAYERS: List<Prayer> = listOf(Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)

    /**
     * Whether the card of [prayer] has a call to hear: the azan is switched on for it. Sunrise never has one,
     * whatever the settings hold: it is the end of fajr, not a prayer. The card wears the speaker when this is
     * true and the crossed one when it is not.
     */
    fun callOn(prayer: Prayer, notifications: Map<Prayer, Boolean>): Boolean =
        prayer.isPrayer && notifications[prayer] == true
}

@Composable
private fun TimeCard(
    prayer: Prayer,
    time: String,
    now: Boolean,
    azan: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val ink = if (now) ShellColors.OnGold else ShellColors.Ink
    val label = PrayerLabels.title(prayer)
    val shape = RoundedCornerShape(CARD_CORNER)
    Box(
        modifier
            .height(CARD_HEIGHT)
            .softShade(shape)
            .clip(shape)
            .background(if (now) ShellColors.GoldCard else ShellColors.Card)
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = tr("Подробнее"), onClick = onClick)
            .semantics { contentDescription = "$label $time" }
    ) {
        // The baselines are the mock's: the label's 21.4 dp under the card's top, the time's 22 dp under that.
        Column(Modifier.padding(start = 14.dp)) {
            Text(
                label, color = if (now) ShellColors.OnGold.copy(alpha = 0.88f) else ShellColors.Label,
                fontSize = ui.t(11f), fontWeight = FontWeight.Medium, maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(end = 26.dp).paddingFromBaseline(top = 21.4.dp, bottom = 0.dp)
            )
            Text(
                time, color = ink, fontSize = ui.t(17f), fontWeight = FontWeight.Bold, maxLines = 1,
                style = TextStyle(fontFeatureSettings = "tnum"),
                modifier = Modifier.paddingFromBaseline(top = 22.dp, bottom = 0.dp)
            )
        }
        // Every card wears one, as in the mock: the speaker when the call is on, the crossed one when there is
        // none to hear (sunrise is the end of fajr, not a prayer; or the prayer's azan is switched off).
        ShellIcon(
            if (azan) ShellGlyph.SPEAKER else ShellGlyph.SPEAKER_OFF,
            when {
                azan -> if (now) ShellColors.OnGoldSoft else ShellColors.Speaker
                else -> if (now) ShellColors.OnGoldMuted else ShellColors.SpeakerMuted
            },
            Modifier.align(Alignment.TopEnd).padding(top = 12.4.dp, end = 11.dp).size(10.5.dp)
        )
    }
}

@Composable
private fun SectionCell(
    section: HomeSection,
    current: Boolean,
    enabled: Boolean,
    onOpen: (HomeSection, Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val center = remember { arrayOf(Offset.Unspecified) }
    val label = section.label()
    val art = sectionArt(section.glyph)
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) { onOpen(section, center[0]) }
            .semantics { contentDescription = label },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(WELL)
                .onGloballyPositioned { center[0] = it.boundsInRoot().center }
                .softShade(CircleShape)
                .clip(CircleShape)
                .background(ShellColors.Well)
                .rimLight(CircleShape)
                .then(if (current) Modifier.border(1.5.dp, ShellColors.Accent, CircleShape) else Modifier),
            contentAlignment = Alignment.Center
        ) {
            // The glyph keeps the size and the place it has in its circle on the designer's sheet.
            if (art != null) {
                ShellIcon(
                    section.glyph, ShellColors.Icon,
                    Modifier.offset(WELL * art.dx, WELL * art.dy).size(WELL * art.share)
                )
            } else {
                ShellIcon(section.glyph, ShellColors.Icon, Modifier.size(22.dp))
            }
        }
        Text(
            label, color = ShellColors.Ink, fontSize = ui.t(10.5f), fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.paddingFromBaseline(top = 12.7.dp, bottom = 13.2.dp)
        )
    }
}

/** The countdown inside a section: a small cream island under the status bar. A tap leads home. */
@Composable
private fun TopIsland(data: PrayerData, now: State<ZonedDateTime>, onTap: (Offset) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val frost = rememberFrost()
    val pill = RoundedCornerShape(50)
    val center = remember { arrayOf(Offset.Unspecified) }
    val next = HomeTimeline.next(data.window, data.fajrEqualsDawn)
    Row(
        modifier
            .height(38.dp)
            .frostGlass(frost, pill)
            .onGloballyPositioned { center[0] = it.boundsInRoot().center }
            .clickable(role = Role.Button, onClickLabel = tr("На главную")) { onTap(center[0]) }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(ShellColors.Accent))
        Spacer(Modifier.width(9.dp))
        Text(PrayerLabels.title(next), color = ShellColors.Ink, fontSize = ui.t(14f), fontWeight = FontWeight.Medium, maxLines = 1)
        Spacer(Modifier.width(5.dp))
        IslandCountdown(data, now)
    }
}

/** The only part of the island that changes every second. */
@Composable
private fun IslandCountdown(data: PrayerData, now: State<ZonedDateTime>) {
    val ui = uiScale()
    Text(
        Format.countdown(data.window.remaining(now.value)),
        color = ShellColors.Ink, fontSize = ui.t(14f), fontWeight = FontWeight.Bold, maxLines = 1,
        style = TextStyle(fontFeatureSettings = "tnum")
    )
}
