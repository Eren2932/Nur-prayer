package com.nur.prayer.ui.shell

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import com.nur.prayer.ui.home.GlyphIcon
import com.nur.prayer.ui.theme.ArabicFont
import kotlin.math.cos
import kotlin.math.sin

/*
 * 0.27.0: the icons of the capsule and its panel.
 *
 * 0.33.0: five section glyphs (Quran, dhikr, qibla, to-do, month) are the designer's own, taken from his sheet
 * (art/shell_icons/section_icons.png) and vectorised into [ShellIconData] by tools/shell_icons.py, the same way
 * as the glyphs of the cards. «Учёба» keeps its letter ع (the sheet's graduation cap did not belong under an
 * eastern arch): it is set in the mushaf face, but sized and weighted like the drawn five, see [drawAin].
 * What is still drawn here: the dots, the moon, the avatar, the navigation arrow and the small icons of the
 * new panel, the sliders of its header and the speaker of its cards, with the call on or off (24-unit grid).
 */
enum class ShellGlyph { BOOK, TASBIH, KAABA, CHECKLIST, AIN, CALENDAR, DOTS, MOON, PERSON, LOCATE, TUNE, SPEAKER, SPEAKER_OFF }

/** The sheet's art of a section glyph, or null for a glyph that is drawn by hand. */
internal fun sectionArt(glyph: ShellGlyph): ShellIconArt? = when (glyph) {
    ShellGlyph.BOOK -> ShellIconData.QURAN
    ShellGlyph.TASBIH -> ShellIconData.DHIKR
    ShellGlyph.KAABA -> ShellIconData.QIBLA
    ShellGlyph.CHECKLIST -> ShellIconData.TODO
    ShellGlyph.CALENDAR -> ShellIconData.MONTH
    else -> null
}

/** The glyph fills its box (the vector glyphs are cut to their own ink box, so they fill it edge to edge). */
@Composable
fun ShellIcon(glyph: ShellGlyph, tint: Color, modifier: Modifier = Modifier) {
    val art = sectionArt(glyph)
    if (art != null) {
        GlyphIcon(art.art, tint, modifier)
        return
    }
    Canvas(modifier) { drawShellGlyph(glyph, tint) }
}

internal fun DrawScope.drawShellGlyph(glyph: ShellGlyph, tint: Color) {
    val u = size.minDimension / 24f
    val ox = (size.width - 24f * u) / 2f
    val oy = (size.height - 24f * u) / 2f
    fun p(x: Float, y: Float) = Offset(ox + x * u, oy + y * u)
    when (glyph) {
        ShellGlyph.DOTS -> {
            val r = 2.7f * u
            drawCircle(tint, r, p(7.6f, 7.6f))
            drawCircle(tint, r, p(16.4f, 7.6f))
            drawCircle(tint, r, p(7.6f, 16.4f))
            drawCircle(tint, r, p(16.4f, 16.4f))
        }
        ShellGlyph.MOON -> {
            drawCircle(tint, radius = 10f * u, center = p(12f, 12f), style = Stroke(width = 1.6f * u))
            val disc = Path().apply { addOval(Rect(p(12f, 12f), 5.6f * u)) }
            val bite = Path().apply { addOval(Rect(p(14.6f, 10.2f), 4.9f * u)) }
            val crescent = Path().apply { op(disc, bite, PathOperation.Difference) }
            drawPath(crescent, tint, style = Fill)
        }
        ShellGlyph.PERSON -> {
            // The avatar of the mock: a filled head and shoulders, cut by the circle that holds them.
            drawCircle(tint, radius = 4.3f * u, center = p(12f, 8.6f))
            val body = Path().apply {
                moveTo(p(3.2f, 22f).x, p(3.2f, 22f).y)
                cubicTo(p(3.6f, 16.6f).x, p(3.6f, 16.6f).y, p(7.4f, 14.4f).x, p(7.4f, 14.4f).y, p(12f, 14.4f).x, p(12f, 14.4f).y)
                cubicTo(p(16.6f, 14.4f).x, p(16.6f, 14.4f).y, p(20.4f, 16.6f).x, p(20.4f, 16.6f).y, p(20.8f, 22f).x, p(20.8f, 22f).y)
                close()
            }
            drawPath(body, tint, style = Fill)
        }
        ShellGlyph.LOCATE -> {
            // The navigation arrow next to the city: a filled dart pointing up and to the right.
            val dart = Path().apply {
                moveTo(p(20.5f, 3.5f).x, p(20.5f, 3.5f).y)
                lineTo(p(13.6f, 20.6f).x, p(13.6f, 20.6f).y)
                lineTo(p(11.4f, 12.6f).x, p(11.4f, 12.6f).y)
                lineTo(p(3.4f, 10.4f).x, p(3.4f, 10.4f).y)
                close()
            }
            drawPath(dart, tint, style = Fill)
            drawPath(dart, tint, style = Stroke(width = 1.2f * u, join = StrokeJoin.Round))
        }
        ShellGlyph.TUNE -> drawTune(tint)
        ShellGlyph.AIN -> drawAin(tint)
        ShellGlyph.SPEAKER, ShellGlyph.SPEAKER_OFF -> {
            // A solid speaker with one wave, as the card of the mock wears it; without the call, a cross instead.
            val body = Path().apply {
                moveTo(p(1.6f, 9.2f).x, p(1.6f, 9.2f).y)
                lineTo(p(5.6f, 9.2f).x, p(5.6f, 9.2f).y)
                lineTo(p(10.6f, 4.6f).x, p(10.6f, 4.6f).y)
                lineTo(p(10.6f, 19.4f).x, p(10.6f, 19.4f).y)
                lineTo(p(5.6f, 14.8f).x, p(5.6f, 14.8f).y)
                lineTo(p(1.6f, 14.8f).x, p(1.6f, 14.8f).y)
                close()
            }
            drawPath(body, tint, style = Fill)
            drawPath(body, tint, style = Stroke(width = 1.4f * u, join = StrokeJoin.Round))
            if (glyph == ShellGlyph.SPEAKER_OFF) {
                drawLine(tint, p(13.4f, 8.9f), p(19.6f, 15.1f), strokeWidth = 1.9f * u, cap = StrokeCap.Round)
                drawLine(tint, p(19.6f, 8.9f), p(13.4f, 15.1f), strokeWidth = 1.9f * u, cap = StrokeCap.Round)
                return
            }
            val r = 9.2f
            val a = Math.toRadians(38.0).toFloat()
            val wave = Path().apply {
                moveTo(p(10.6f + r * cos(a), 12f - r * sin(a)).x, p(10.6f + r * cos(a), 12f - r * sin(a)).y)
                arcTo(Rect(p(10.6f - r, 12f - r), p(10.6f + r, 12f + r)), -38f, 76f, false)
            }
            drawPath(wave, tint, style = Stroke(width = 1.9f * u, cap = StrokeCap.Round))
        }
        else -> Unit
    }
}

/**
 * The arithmetic of the letter ع of «Учёба», pure so that ShellGlyphsTest can pin it. The letter's ink (and the
 * faux weight on it) is exactly the box tall. The mushaf face is a hairline next to the heavy sheet glyphs, so it
 * is thickened by [WEIGHT] of the box (1.1 dp at 22 dp, which is the stroke of the drawn five); the box is 22 dp,
 * the height of the tallest of them (the beads), where the 0.32 letter was 16 dp.
 */
internal object AinFit {
    const val WEIGHT = 0.05f

    fun weight(box: Float): Float = WEIGHT * box

    /** The text size at which [refInk], the ink height measured at [refSize], plus the weight is exactly [box] tall. */
    fun textSize(box: Float, refInk: Float, refSize: Float = 100f): Float = refSize * (box - weight(box)) / refInk
}

/** Centred in the box by its own bounds, not by the font's line box, so it sits in its well like the drawn glyphs. */
private fun DrawScope.drawAin(tint: Color) {
    val h = size.height
    val ink = android.graphics.Rect()
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        typeface = ArabicFont.paintTypeface()
        color = tint.toArgb()
        textSize = 100f
    }
    // Measure at a reference size, scale so that glyph + weight is h tall, measure again at that size.
    paint.getTextBounds(AIN_TEXT, 0, AIN_TEXT.length, ink)
    val refHeight = ink.bottom - ink.top
    if (refHeight <= 0) return
    paint.textSize = AinFit.textSize(h, refHeight.toFloat())
    paint.getTextBounds(AIN_TEXT, 0, AIN_TEXT.length, ink)
    paint.style = android.graphics.Paint.Style.FILL_AND_STROKE
    paint.strokeJoin = android.graphics.Paint.Join.ROUND
    paint.strokeWidth = AinFit.weight(h)
    val x = size.width / 2f - (ink.left + ink.right) / 2f
    val y = size.height / 2f - (ink.top + ink.bottom) / 2f
    drawIntoCanvas { it.nativeCanvas.drawText(AIN_TEXT, x, y, paint) }
}

private const val AIN_TEXT = "ع"

/**
 * The sliders of the panel's header, measured on the mock: three lines, a ring on each (right, left, right),
 * the line stopping at the ring. The icon is 16 units wide in a box of that many dp, so a 16 dp box draws it
 * at the mock's size (13.3 dp of line, 4.6 dp rings, 1.3 dp stroke).
 */
private fun DrawScope.drawTune(tint: Color) {
    val u = size.minDimension / 16f
    val ox = (size.width - 16f * u) / 2f
    val oy = (size.height - 16f * u) / 2f
    val x0 = 1.35f
    val x1 = 14.65f
    val outer = 2.3f
    val stroke = 1.3f
    val rows = floatArrayOf(3.05f, 8f, 12.95f)
    val knobs = floatArrayOf(9.75f, 4.75f, 9.75f)
    for (i in rows.indices) {
        val y = oy + rows[i] * u
        val k = ox + knobs[i] * u
        val gap = (outer - 0.2f) * u
        drawLine(tint, Offset(ox + x0 * u, y), Offset(k - gap, y), strokeWidth = stroke * u, cap = StrokeCap.Round)
        drawLine(tint, Offset(k + gap, y), Offset(ox + x1 * u, y), strokeWidth = stroke * u, cap = StrokeCap.Round)
        drawCircle(tint, radius = (outer - stroke / 2f) * u, center = Offset(k, y), style = Stroke(width = stroke * u))
    }
}
