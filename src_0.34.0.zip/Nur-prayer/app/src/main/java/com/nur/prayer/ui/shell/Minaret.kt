package com.nur.prayer.ui.shell

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.dp

/*
 * 0.33.0 «Минарет»: the roof of the panel and the two small ornaments built on its curve.
 *
 * The roof is the ogee silhouette on top of the open panel in the mock: a point, a flare that gets shallow
 * through the middle and turns steep again at the foot. It is measured, not drawn by eye: the mock's roof
 * was read row by row (sub-pixel crossings of the glass against the wallpaper, 81 rows from the tip to the
 * panel's top edge), and three cubic Béziers were fitted to the right-hand half with a worst error of 0.35 px
 * of the mock (0.13 dp). The left half is its mirror. All numbers are dp on a 393 dp screen (the mock is 1086 px
 * wide, 2.763 px per dp), measured from the tip.
 *
 * It is a plain fill laid over the glass, not part of the glass's clip: the glass stays a rounded rectangle
 * (hardware clip, no per-frame Path, see Frost.kt) and the roof is one static path that only slides.
 */
internal object Minaret {
    /** Half the width of the roof at its foot, and its height: where the curve meets the top edge. */
    const val HALF = 49.24f
    const val HEIGHT = ShellMath.ROOF_DP

    /** How far the roof reaches into the glass: it covers the glass's hairline under its foot. */
    const val COVER = 2f

    /** The right-hand half, tip (0, 0) to foot (HALF, HEIGHT): three cubics, `c1x c1y c2x c2y x y` each. */
    val RIGHT = floatArrayOf(
        1.59f, 1.83f, 3.15f, 3.6f, 5.06f, 5.1f,
        9.17f, 8.33f, 14.07f, 10.39f, 18.87f, 12.34f,
        30.91f, 17.23f, 39.58f, 19.95f, 49.24f, 28.99f
    )

    /** The open curve from the left foot over the tip to the right foot, in dp from the tip. */
    fun curve(): Path {
        val segs = RIGHT.size / 6
        val p = Path()
        p.moveTo(-RIGHT[RIGHT.size - 2], RIGHT[RIGHT.size - 1])
        for (i in segs - 1 downTo 0) {
            val sx = if (i == 0) 0f else RIGHT[(i - 1) * 6 + 4]
            val sy = if (i == 0) 0f else RIGHT[(i - 1) * 6 + 5]
            val o = i * 6
            p.cubicTo(-RIGHT[o + 2], RIGHT[o + 3], -RIGHT[o], RIGHT[o + 1], -sx, sy)
        }
        for (i in 0 until segs) {
            val o = i * 6
            p.cubicTo(RIGHT[o], RIGHT[o + 1], RIGHT[o + 2], RIGHT[o + 3], RIGHT[o + 4], RIGHT[o + 5])
        }
        return p
    }

    /** The roof as a solid: the curve closed along its foot. */
    fun body(): Path = curve().also { it.close() }

    /** The half-width of the roof at [y] dp below the tip (0 at the tip, [HALF] at the foot), by the curve itself. */
    fun halfWidthAt(y: Float): Float {
        require(y in 0f..HEIGHT) { "y $y is outside the roof" }
        var x0 = 0f
        var y0 = 0f
        for (i in 0 until RIGHT.size / 6) {
            val o = i * 6
            val ex = RIGHT[o + 4]
            val ey = RIGHT[o + 5]
            if (y <= ey) {
                // Bisect the parameter: y(t) of a cubic is monotonic here (the roof only widens downwards).
                var lo = 0f
                var hi = 1f
                repeat(40) {
                    val t = (lo + hi) / 2f
                    if (bez(y0, RIGHT[o + 1], RIGHT[o + 3], ey, t) < y) lo = t else hi = t
                }
                val t = (lo + hi) / 2f
                return bez(x0, RIGHT[o], RIGHT[o + 2], ex, t)
            }
            x0 = ex
            y0 = ey
        }
        return HALF
    }

    private fun bez(a: Float, b: Float, c: Float, d: Float, t: Float): Float {
        val u = 1f - t
        return u * u * u * a + 3f * u * u * t * b + 3f * u * t * t * c + t * t * t * d
    }
}

private val roofBody: Path by lazy { Minaret.body() }
private val roofCurve: Path by lazy { Minaret.curve() }

/**
 * The roof on the open panel. It sits on the glass's top edge (its box is the roof's height plus the cover)
 * and rises out of the glass as the panel opens ([ShellMath.roofRise]); the box clips what is still inside.
 */
@Composable
internal fun MinaretRoof(shell: ShellState, modifier: Modifier = Modifier) {
    Canvas(
        modifier
            .width((2f * Minaret.HALF + 2f).dp)
            .height((Minaret.HEIGHT + Minaret.COVER).dp)
            .clipToBounds()
    ) {
        val k = ShellMath.roofRise(shell.progress)
        if (k > 0f) {
            val d = density
            withTransform({
                translate(left = size.width / 2f, top = (1f - k) * size.height)
                scale(scaleX = d, scaleY = d, pivot = Offset.Zero)
            }) {
                drawPath(roofBody, ShellColors.Roof, style = Fill)
                // The band of the glass under the foot: it hides the glass's hairline where the roof stands.
                drawRect(
                    ShellColors.GlassTop,
                    topLeft = Offset(-Minaret.HALF, Minaret.HEIGHT - 0.3f),
                    size = androidx.compose.ui.geometry.Size(2f * Minaret.HALF, Minaret.COVER + 0.3f)
                )
                drawPath(
                    roofCurve, ShellColors.Edge,
                    style = Stroke(width = 1f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
    }
}

/**
 * The little roof in the middle of the header, on a hairline that fades out both ways: the same curve, 0.158 of
 * its size (15.6 dp wide, as in the mock) with a needle on its tip. [titleRight] is where the title ends (px,
 * from the left edge of the header's text); when the title is long the hairline gives way, and the whole
 * ornament goes when there is no room for the roof itself.
 */
@Composable
internal fun HeaderOrnament(titleRight: () -> Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val d = density
        val cx = size.width / 2f
        val baseY = 18.3f * d
        val room = cx - (28f * d + titleRight()) - 6f * d
        val half = minOf(HEADER_LINE_HALF * d, room)
        if (half >= 11f * d) {
            val ink = ShellColors.Ornament
            val dome = 7.8f * d
            val stroke = 0.6f * d
            drawLine(
                Brush.horizontalGradient(listOf(Color.Transparent, ink), startX = cx - half, endX = cx - dome),
                Offset(cx - half, baseY), Offset(cx - dome, baseY), strokeWidth = stroke
            )
            drawLine(
                Brush.horizontalGradient(listOf(ink, Color.Transparent), startX = cx + dome, endX = cx + half),
                Offset(cx + dome, baseY), Offset(cx + half, baseY), strokeWidth = stroke
            )
            val f = HEADER_DOME_SCALE
            val tipY = baseY - Minaret.HEIGHT * f * d
            withTransform({
                translate(left = cx, top = tipY)
                scale(scaleX = f * d, scaleY = f * d, pivot = Offset.Zero)
            }) {
                drawPath(roofBody, ink, style = Fill)
            }
            drawLine(ink, Offset(cx, tipY - 3.2f * d), Offset(cx, tipY + 0.6f * d), strokeWidth = 0.5f * d, cap = StrokeCap.Round)
        }
    }
}

private const val HEADER_LINE_HALF = 25f
private const val HEADER_DOME_SCALE = 0.158f

/**
 * The divider between the times and the sections: a hairline with a thin arch in the middle where it breaks.
 * The line sits [LINE_Y] dp from the top of the box; the arch stands on it.
 */
@Composable
internal fun PanelDivider(modifier: Modifier = Modifier) {
    Canvas(modifier.height(DIVIDER_HEIGHT.dp)) {
        val d = density
        val cx = size.width / 2f
        val y = LINE_Y * d
        val inset = 18f * d
        val fade = 30f * d
        val gap = 13f * d
        val thin = 0.75f * d
        val line = ShellColors.Divider
        drawLine(
            Brush.horizontalGradient(listOf(line.copy(alpha = 0f), line), startX = inset, endX = inset + fade),
            Offset(inset, y), Offset(cx - gap, y), strokeWidth = thin
        )
        drawLine(
            Brush.horizontalGradient(listOf(line, line.copy(alpha = 0f)), startX = size.width - inset - fade, endX = size.width - inset),
            Offset(cx + gap, y), Offset(size.width - inset, y), strokeWidth = thin
        )
        // The light under the line, as in the mock: a second, fainter hairline half a dp below.
        val light = ShellColors.Rim.copy(alpha = 0.5f)
        drawLine(light, Offset(inset + fade, y + 0.75f * d), Offset(cx - gap, y + 0.75f * d), strokeWidth = 0.5f * d)
        drawLine(light, Offset(cx + gap, y + 0.75f * d), Offset(size.width - inset - fade, y + 0.75f * d), strokeWidth = 0.5f * d)
        val arch = Path().apply {
            moveTo(cx - 7.4f * d, y)
            cubicTo(cx - 5.6f * d, y - 2.7f * d, cx - 2.4f * d, y - 3.1f * d, cx, y - 6.3f * d)
            cubicTo(cx + 2.4f * d, y - 3.1f * d, cx + 5.6f * d, y - 2.7f * d, cx + 7.4f * d, y)
        }
        drawPath(arch, ShellColors.Ornament, style = Stroke(width = 0.7f * d, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Height of the divider's box and where its line runs in it (dp). */
internal const val DIVIDER_HEIGHT = 8f
private const val LINE_Y = 6.6f
