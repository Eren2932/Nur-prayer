package com.nur.prayer.ui.today

import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.KhatmPlan
import com.nur.prayer.quran.QuranMark
import com.nur.prayer.quran.QuranMath

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import com.nur.prayer.daily.StoryMath
import androidx.compose.runtime.getValue
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.components.RollingText

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.DhikrPreset
import com.nur.prayer.daily.Vird
import com.nur.prayer.learn.QuranShort
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.RollingNumber
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.learn.LearnProgress
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.daily.Ring
import com.nur.prayer.ui.daily.azkarBrush
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.HGap
import com.nur.prayer.ui.learn.LessonBar
import com.nur.prayer.ui.learn.Tag
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import com.nur.prayer.ui.components.DoneSeal
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.StreakLamp
import com.nur.prayer.ui.learn.textDp

/** What the today layer shows; computed by the root from the view models. */
data class TodayState(
    val hijri: String,
    val today: Long,
    val content: LearnContent?,
    val progress: LearnProgress,
    val azkarSet: AzkarSet,
    val azkarDone: Int,
    val azkarTotal: Int,
    /** 0.18.5: the vird of the day in its order, and today's count of every dhikr. */
    val vird: List<String>,
    val dhikrToday: Map<String, Long>,
    /** Story slides seen today, one bit each (StoryMath). */
    val storyMask: Int,
    /** Where the Quran reader stopped; null before the first reading. */
    val quranMark: QuranMark? = null,
    /** The khatm plan, null when there is none: the Quran tile then shows today's share of it. */
    val quranKhatm: KhatmPlan? = null
)

/** Everything the today layer can open. */
class TodayActions(
    val close: () -> Unit,
    val story: (Int) -> Unit,
    /** The reader, on the bookmark (al-Fatiha the first time); its back arrow leads to the contents. */
    val quran: () -> Unit,
    val azkar: () -> Unit,
    /** The one counter: on the given dhikr, or (null) on the first of the vird still open. */
    val dhikr: (String?) -> Unit,
    val continueLesson: () -> Unit,
    val course: () -> Unit,
    val review: () -> Unit,
    /** The dictionary opened on the given word (the word of the day), its card unfolded. */
    val word: (String) -> Unit,
    val dictionary: () -> Unit,
    val surahs: () -> Unit,
    val schedule: () -> Unit,
    val qibla: () -> Unit
)

/**
 * The layer pulled up from home, in four blocks read top to bottom: the story of the day, the
 * tasks of the day (Quran and azkar, then the vird of the day across the width), learning, and
 * the tools. It shares one [Reveal] with home: a drag down on its header drives the same number back.
 *
 * 0.18.5: every entry leads somewhere of its own. «Салават» and «Зикр» opened the same counter —
 * now one tile with a ring per dhikr of the vird. «Ещё» listed the Quran (the tile above already
 * opens it) and the dictionary (the word of the day did too): it is a grid of tools now, with the
 * qibla that the layer could not reach before; the word of the day opens its own card.
 */
@Composable
fun TodayScreen(state: TodayState, palette: PhasePalette, reveal: Reveal, on: TodayActions) {
    val ui = uiScale()
    val accent = palette.accent
    val pullDown = rememberDraggableState { delta -> reveal.drag(-delta) }
    Column(Modifier.fillMaxSize().onSizeChanged { reveal.extentPx = it.height.toFloat() }) {
        Column(
            Modifier.fillMaxWidth().padding(top = LocalIslandInset.current).draggable(
                state = pullDown,
                orientation = Orientation.Vertical,
                onDragStarted = { reveal.grab() },
                onDragStopped = { v -> if (reveal.release(-v, RevealMath.SHEET_KEEP_AT)) reveal.settle(true) else on.close() }
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.padding(top = 8.dp).width(40.dp).height(5.dp).clip(RoundedCornerShape(50)).background(SurfaceEdge))
            Row(Modifier.fillMaxWidth().padding(horizontal = ui.s(16f), vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("Сегодня"), color = TextPrimary, fontSize = ui.t(28f), fontWeight = FontWeight.Bold)
                    Text(state.hijri, color = TextSecondary, fontSize = ui.t(13f))
                }
            }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = ui.s(16f)).padding(bottom = LocalDockInset.current + 16.dp)
        ) {
            StoriesRow(state.storyMask, accent, on.story, Modifier.entrance(0))

            Section(tr("Дела дня"), Modifier.entrance(1))
            Row(Modifier.fillMaxWidth().entrance(2), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val mark = state.quranMark
                val khatm = state.quranKhatm
                val lang = L10n.language.code
                // With a khatm the tile is its day: pages read of today's share, a ring that closes at the norm.
                val khatmDone = khatm != null && khatm.doneToday(state.today)
                TaskTile(tr("Коран"),
                    when {
                        khatm != null && khatm.finished -> tr("хатм завершён")
                        khatm != null && khatmDone -> tr("норма дня выполнена")
                        khatm != null -> tr("сегодня {0} из {1} стр.", khatm.readToday(state.today), khatm.goalToday(state.today))
                        mark == null -> tr("Аль-Фатиха и все 114 сур")
                        else -> tr("{0} · аят {1}", QuranMath.title(QuranMath.surah(mark.surah), lang), mark.ayah)
                    },
                    Modifier.weight(1f), onClick = on.quran) {
                    if (khatm != null) Ring(khatm.todayFraction(state.today), if (khatmDone) Mint else TextPrimary, 46.dp, 5.dp)
                    else ArabicText(if (mark == null) "الفاتحة" else QuranMath.surah(mark.surah).arabic, 26f, align = TextAlign.Start)
                }
                val azkarFull = state.azkarTotal > 0 && state.azkarDone >= state.azkarTotal
                TaskTile(state.azkarSet.title, if (azkarFull) tr("прочитаны") else "${state.azkarDone} / ${state.azkarTotal}",
                    Modifier.weight(1f), brush = azkarBrush(state.azkarSet), onClick = on.azkar) {
                    Ring(if (state.azkarTotal == 0) 0f else state.azkarDone / state.azkarTotal.toFloat(), Color.White, 46.dp, 5.dp)
                }
            }
            Gap(10f)
            VirdTile(state.vird, state.dhikrToday, Modifier.entrance(3), on.dhikr)

            Section(tr("Обучение"), Modifier.entrance(4))
            Box(Modifier.entrance(5)) { LearnCard(state, accent, on.continueLesson, on.course) }
            Gap(10f)
            Row(Modifier.fillMaxWidth().entrance(6), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                state.content?.let { c ->
                    val w = c.lexicon.wordOfDay(state.today)
                    TaskTile(tr("Слово дня"), "${w.ru} · ${w.translit}", Modifier.weight(1f), onClick = { on.word(w.id) }) {
                        ArabicText(w.arabic, 26f, align = TextAlign.Start)
                    }
                } ?: Spacer(Modifier.weight(1f))
                val due = state.progress.due(state.today).size
                TaskTile(tr("Повторение"), if (due > 0) tr("{0} карточек ждут", due) else tr("на сегодня всё"), Modifier.weight(1f), onClick = on.review) {
                    if (due > 0) Text("$due", color = TextPrimary, fontSize = ui.t(30f), fontWeight = FontWeight.Bold)
                    else DoneSeal(Mint, textDp(34f))
                }
            }

            Section(tr("Ещё"), Modifier.entrance(7))
            Row(Modifier.fillMaxWidth().entrance(8), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ToolTile(tr("Кибла"), tr("направление на Каабу"), Modifier.weight(1f), on.qibla) {
                    Glyph(GlyphKind.COMPASS, TextPrimary, Modifier.size(textDp(20f)))
                }
                ToolTile(tr("Календарь намазов"), tr("месяц, время, хиджра"), Modifier.weight(1f), on.schedule) {
                    Glyph(GlyphKind.CALENDAR, TextPrimary, Modifier.size(textDp(20f)))
                }
            }
            Gap(10f)
            Row(Modifier.fillMaxWidth().entrance(9), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val checked = QuranShort.SURAHS.count { state.progress.isDone(QuranShort.lessonId(it.number)) }
                ToolTile(tr("Короткие суры"),
                    if (checked == 0) tr("заучивание и проверка себя") else tr("проверено {0} из {1}", checked, QuranShort.SURAHS.size),
                    Modifier.weight(1f), on.surahs) {
                    ArabicText("سُورَة", 17f)
                }
                ToolTile(tr("Словарь"), tr("{0} слов и фраз, поиск", state.content?.lexicon?.words?.size ?: 0), Modifier.weight(1f), on.dictionary) {
                    ArabicText("قَامُوس", 15f)
                }
            }
        }
    }
}

@Composable
private fun Section(title: String, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Text(title, color = TextPrimary, fontSize = ui.t(20f), fontWeight = FontWeight.Bold,
        modifier = modifier.padding(start = 4.dp, top = 22.dp, bottom = 10.dp))
}

private val STORY_LABELS = listOf("Аят", "Хадис", "Дуа", "Слово")
private val STORY_GLYPHS = listOf("ﷻ", "ﷺ", "دعاء", "ك")

@Composable
private fun StoriesRow(mask: Int, accent: Color, onOpen: (Int) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val count = STORY_LABELS.size
    val all = StoryMath.allSeen(mask, count)
    Column(modifier) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 6.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("История дня"), color = TextPrimary, fontSize = ui.t(20f), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            // One tap to watch from the first slide not yet seen, like the "play" of a story tray.
            Text(if (all) tr("смотреть снова") else tr("смотреть"), color = if (all) TextTertiary else accent, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold,
                modifier = Modifier.pressClick(shape = RoundedCornerShape(50)) { onOpen(StoryMath.firstUnseen(mask, count)) }
                    .padding(horizontal = 10.dp, vertical = 6.dp))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            STORY_LABELS.forEachIndexed { i, label ->
                val seen = StoryMath.isSeen(mask, i)
                val ringAlpha by animateFloatAsState(if (seen) 0f else 1f, tween(400), label = "storyRing")
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.pressClick(shape = RoundedCornerShape(16.dp)) { onOpen(i) }.padding(4.dp)) {
                    Box(Modifier.size(68.dp), contentAlignment = Alignment.Center) {
                        Box(Modifier.matchParentSize().clip(CircleShape).border(3.dp, SurfaceEdge, CircleShape))
                        Box(Modifier.matchParentSize().graphicsLayer { alpha = ringAlpha }.clip(CircleShape)
                            .border(3.dp, Brush.linearGradient(listOf(Color(0xFFF2C077), accent, Color(0xFFD0453F))), CircleShape))
                        Box(Modifier.matchParentSize().padding(6.dp).clip(CircleShape).background(SurfaceInset), contentAlignment = Alignment.Center) {
                            ArabicText(STORY_GLYPHS[i], if (STORY_GLYPHS[i].length > 2) 16f else 24f)
                        }
                    }
                    Gap(4f)
                    Text(tr(label), color = if (seen) TextTertiary else TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** A square-ish tile of the 2×2 grid: an icon area on top, title and status below. */
@Composable
private fun TaskTile(
    title: String,
    subtitle: String,
    modifier: Modifier,
    brush: Brush? = null,
    onClick: () -> Unit,
    icon: @Composable () -> Unit
) {
    val ui = uiScale()
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.heightIn(min = 150.dp).pressClick(shape = shape, onClick = onClick)
            .then(if (brush != null) Modifier.background(brush) else Modifier.background(SurfaceInset))
            .padding(ui.s(16f)),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(Modifier.height(52.dp), contentAlignment = Alignment.CenterStart) { icon() }
        Column {
            Text(title, color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            // Salawat and dhikr counts change while you watch (back from the counter): roll, not blink.
            RollingText(subtitle, if (brush != null) Color(0xDDFFFFFF) else TextTertiary, ui.t(13f))
        }
    }
}

@Composable
private fun LearnCard(state: TodayState, accent: Color, onContinue: () -> Unit, onCourse: () -> Unit) {
    val ui = uiScale()
    GlassCard(color = accent.copy(alpha = 0.22f)) {
        Column(Modifier.padding(ui.s(18f))) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("АРАБСКИЙ ЯЗЫК"), color = TextPrimary, fontSize = ui.t(12f), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                state.progress.streakOn(state.today).let { streak ->
                    // No streak: an unlit lamp alone, not a reproachful «0».
                    Tag(if (streak > 0) "$streak" else "") { StreakLamp(streak > 0, TextPrimary, textDp(15f)) }
                }
            }
            Gap(8f)
            val course = state.content?.course
            if (course == null) {
                Text(tr("Готовим уроки…"), color = TextSecondary, fontSize = ui.t(14f))
                return@Column
            }
            val next = course.next(state.progress)
            val done = course.completedCount(state.progress)
            Text(next?.title ?: tr("Курс пройден"), color = TextPrimary, fontSize = ui.t(22f), fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(next?.let { course.stages[course.stageIndex(it.id)].title + " · " + it.subtitle } ?: tr("повторяйте карточки"),
                color = TextSecondary, fontSize = ui.t(14f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Gap(10f)
            LessonBar(done.toFloat() / course.lessons.size.coerceAtLeast(1), accent)
            Gap(4f)
            Text(tr("{0} из {1} уроков · {2} слов · {3} из 28 букв", done, course.lessons.size, state.progress.learnedWords(), state.progress.learnedLetters()),
                color = TextTertiary, fontSize = ui.t(12f))
            Gap(12f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (next != null) NurButton(if (done == 0) tr("Начать") else tr("Продолжить"), accent, onContinue, Modifier.weight(1f), primary = true)
                NurButton(tr("Весь курс"), accent, onCourse, Modifier.weight(1f))
            }
        }
    }
}

/**
 * The vird of the day: a ring per starred dhikr, filled by today's count towards one round. A tap
 * on a ring opens the counter on that dhikr; anywhere else, on the first one still open.
 */
@Composable
private fun VirdTile(vird: List<String>, today: Map<String, Long>, modifier: Modifier, onOpen: (String?) -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(24.dp)
    val done = Vird.doneCount(vird, today)
    val all = Vird.allDone(vird, today)
    val said = today.values.sum()
    Column(
        modifier.fillMaxWidth().pressClick(scaleTo = 0.98f, shape = shape) { onOpen(null) }
            .background(SurfaceInset).padding(ui.s(16f)).animateContentSize(NurMotion.gentle())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("Зикр"), color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Bold)
                RollingText(
                    when {
                        vird.isEmpty() && said > 0 -> tr("сегодня {0}", said)
                        vird.isEmpty() -> tr("тасбих, салават, истигфар…")
                        all -> tr("вирд дня выполнен")
                        else -> tr("вирд дня · {0} из {1}", done, vird.size)
                    },
                    if (all) Mint else TextTertiary, ui.t(13f)
                )
            }
            // The word «ذِكْر» gives way to the seal once the whole vird is said.
            AnimatedContent(
                targetState = all,
                transitionSpec = { (scaleIn(NurMotion.bouncy(), initialScale = 0.6f) + fadeIn(tween(160))) togetherWith fadeOut(tween(100)) },
                contentAlignment = Alignment.Center,
                label = "virdSeal"
            ) { full ->
                if (full) DoneSeal(Mint, textDp(30f)) else ArabicText("ذِكْر", 24f)
            }
        }
        if (vird.isNotEmpty()) {
            Gap(12f)
            Row(Modifier.fillMaxWidth()) {
                vird.forEach { id -> VirdRing(Dhikr.preset(id), today[id] ?: 0L, Modifier.weight(1f)) { onOpen(id) } }
            }
        } else {
            Gap(6f)
            Text(tr("Отметьте зикры звёздочкой в счётчике — они встанут сюда кольцами"), color = TextTertiary, fontSize = ui.t(12f))
        }
    }
}

@Composable
private fun VirdRing(d: DhikrPreset, count: Long, modifier: Modifier, onClick: () -> Unit) {
    val ui = uiScale()
    val done = count >= d.target
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.pressClick(scaleTo = 0.92f, shape = shape, onClick = onClick).padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
            Ring(count / d.target.toFloat(), if (done) Mint else TextPrimary, 56.dp, 5.dp)
            AnimatedContent(
                targetState = done,
                transitionSpec = { (scaleIn(NurMotion.bouncy(), initialScale = 0.5f) + fadeIn(tween(140))) togetherWith fadeOut(tween(90)) },
                contentAlignment = Alignment.Center,
                label = "virdRing"
            ) { full ->
                if (full) DoneSeal(Mint, textDp(22f)) else RollingNumber(count, TextPrimary, ui.t(15f))
            }
        }
        Gap(6f)
        Text(d.title, color = if (done) Mint else TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

/** A half-width tool: an icon in a round plate, title and a line under it. */
@Composable
private fun ToolTile(title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit, icon: @Composable () -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(22.dp)
    Row(
        modifier.heightIn(min = 84.dp).pressClick(scaleTo = 0.97f, shape = shape, onClick = onClick)
            .background(SurfaceInset).padding(horizontal = ui.s(12f), vertical = ui.s(12f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(TextPrimary.copy(alpha = 0.08f)), contentAlignment = Alignment.Center) { icon() }
        HGap(10f)
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = ui.t(15f), fontWeight = FontWeight.SemiBold, maxLines = 2,
                overflow = TextOverflow.Ellipsis, lineHeight = ui.t(18f))
            Gap(2f)
            Text(subtitle, color = TextTertiary, fontSize = ui.t(12f), maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = ui.t(15f))
        }
    }
}
