package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.uiScale

/*
 * 0.34.0 «Стекло настроек»: the card of the settings menu, measured from the reference screenshot (841 × 1870 px of a
 * 393 dp phone, 2.14 px per dp), not drawn by eye.
 *
 *  - Fill. Over the page's own darkened wallpaper the card is #102030 at 68 %. Fitted on three places of the shot
 *    (dark sky, dark kiswah, lit tower): inside = 0.32 · wallpaper + 0.68 · (16, 32, 48) per channel, so the picture
 *    shows through a little (a lit tower makes the left of the bottom card lighter) and a dark sky is a flat navy.
 *  - Rim. One dp of white at 8 % (the shot's rim pixels sit 6–8 % above the fill).
 *  - Corner. Fitted on the arc of the first card: 40 px = 19 dp.
 *  - Cards are 17 dp from the screen edge and 28 dp from each other; rows have no dividers inside a card, the card
 *    is one surface and its rows are told apart by their icons and by the air between them.
 *  - Text. The title is white bold 16 sp (stem 2.5 dp), the line under it #929DB1 14 sp, a soft dark shadow under
 *    both. The chevron is a white 1.6 dp stroke, 5.6 × 9.8 dp.
 */
object MenuGlass {
    /** #102030 at 68 %. */
    val Fill = Color(0xAD102030)
    /** White at 8 %: the 1 dp rim. */
    val Edge = Color(0x14FFFFFF)
    /** The grey of the line under a title and of the overline above it. */
    val Subtitle = Color(0xFF929DB1)
    val Title = Color.White
    /** The soft shadow the reference puts under its text (blur in px). */
    val TextShadow = Shadow(Color(0x66000000), Offset(0f, 2f), 5f)

    /** Design numbers, in dp of a 393 dp screen (pass them through `uiScale().s`). */
    const val CORNER = 19f
    const val GAP = 28f
    const val SIDE = 17f

    /** On a tablet or a landscape phone the cards keep a phone-like column in the middle instead of stretching. */
    val MaxWidth: Dp = 560.dp
}

/** The glass of a menu card: clip, fill and the 1 dp rim. */
fun Modifier.menuGlass(corner: Dp): Modifier {
    val shape = RoundedCornerShape(corner)
    return this.clip(shape).background(MenuGlass.Fill).border(1.dp, MenuGlass.Edge, shape)
}

/** The thin white `›` at the end of a row; it mirrors in right-to-left layouts. */
@Composable
fun MenuChevron(modifier: Modifier = Modifier, color: Color = Color.White) {
    val ui = uiScale()
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Canvas(modifier.size(width = ui.s(7f), height = ui.s(11f))) {
        val w = size.width
        val h = size.height
        val stroke = 1.6.dp.toPx()
        val pad = stroke / 2f + 0.4.dp.toPx()
        fun x(v: Float): Float = if (rtl) w - v else v
        val path = Path().apply {
            moveTo(x(pad), pad)
            lineTo(x(w - pad), h / 2f)
            lineTo(x(pad), h - pad)
        }
        drawPath(path, color, style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
