package com.nur.prayer.ui.settings

import com.nur.prayer.ui.wallpaper.Wallpaper
import com.nur.prayer.ui.wallpaper.WallpaperCatalog
import com.nur.prayer.ui.wallpaper.WallpaperRow
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Calibration
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.RegionalProfiles
import com.nur.prayer.data.HomeLayout
import com.nur.prayer.data.PlaceProfiles
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.core.astro.TimeSource
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.i18n.trDynamic
import com.nur.prayer.icon.AppIconSwitcher
import com.nur.prayer.icon.title
import com.nur.prayer.notify.AzanSound
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.NavigationMotion
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.Caption
import com.nur.prayer.ui.components.ChoiceRow
import com.nur.prayer.ui.components.FactRow
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.HairRule
import com.nur.prayer.ui.components.MenuChevron
import com.nur.prayer.ui.components.MenuGlass
import com.nur.prayer.ui.components.menuGlass
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.ScreenHeader
import com.nur.prayer.ui.components.SegmentedControl
import com.nur.prayer.ui.components.StepperField
import com.nur.prayer.ui.components.SwitchRow
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/**
 * Settings. 0.13.0: rows grouped by meaning, each showing its current value; one tap opens one focused editor;
 * language switches the whole app live. 0.34.0: glass instead of a solid page.
 *
 *  - The page draws no background: the wallpaper lies under it, sharp and darkened by the backdrop, and every card
 *    is glass measured from the reference (MenuGlass), so the picture shows through them a little.
 *  - Rows are grouped into a few cards by meaning — where and in what language; method and madhab; high latitudes,
 *    rounding and corrections; notifications, azan and looks; the account of the calculation — with no dividers
 *    and no headings: each row already says what it is and shows its value.
 *  - The index has no title and no back arrow. The way out is the ring at the bottom right, placed once by NurRoot;
 *    it asks for the system back, which closes an open editor first ([BackHandler] below).
 */
@Composable
fun SettingsScreen(
    data: PrayerData,
    palette: PhasePalette,
    actions: AppActions,
    exactAlarmsAllowed: Boolean,
    locating: Boolean = false,
    locationStatus: String? = null,
    notificationsAllowed: Boolean = true,
    modifier: Modifier = Modifier,
    locationButtonLabel: String = "",
    onBack: (() -> Unit)? = null,
    onOpenWallpapers: () -> Unit = {}
) {
    val ui = uiScale()
    val dockInset = LocalDockInset.current
    val settings = data.settings
    val accent = palette.accent
    val effectiveMethod = data.params.method
    // The launcher alias lives in PackageManager, not in DataStore: read once, then follow the taps.
    val context = LocalContext.current
    var appIcon by remember { mutableStateOf(AppIconSwitcher.selected(context)) }

    // Survives rotation and process death, so coming back to the app does not silently collapse the
    // editor the user was working in.
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    val pages = rememberSaveableStateHolder()
    BackHandler(enabled = open != null) { open = null }

    // Leaving the screen must never leave the adhan playing: the preview is the one place in the app
    // where sound starts without a prayer time behind it.
    val editingAzan = open == "azan"
    DisposableEffect(editingAzan) { onDispose { if (editingAzan) actions.stopAzan() } }

    val methodTitle = trDynamic(effectiveMethod.title)
    val specs = buildList {
        add(SettingsTile("language", tr("Язык"), L10n.language.nativeName, GlyphKind.GLOBE) {
            LanguagePicker(accent)
        })
        run {
            // 0.18.6: the automatic profile follows the region where it has its own muftiate (Казань → ДУМ РТ).
            val placeDefault = PlaceProfiles.forPlace(data.place.country, data.place.region)
            val byRegion = placeDefault != RegionalProfiles.forCountry(data.place.country)
            add(SettingsTile(
                id = "method",
                title = tr("Метод расчёта"),
                value = if (settings.methodIsAutomatic) tr("Автоматически · {0}", methodTitle)
                    else tr("Вручную · {0}", methodTitle),
                glyph = GlyphKind.SETTINGS
            ) {
                ChoiceRow(
                    title = tr("Автоматически"),
                    subtitle = "${if (byRegion) data.place.region else trDynamic(data.place.country)} → ${trDynamic(placeDefault.method.title)}",
                    selected = settings.methodIsAutomatic,
                    accent = accent,
                    onClick = { actions.setMethod(null) }
                )
                HairRule()
                /*
                 * Only the methods that mean something here, plus whatever the user has already
                 * chosen by hand — a selected row must never disappear from the list it lives in.
                 */
                val methods = remember(data.place.country, data.place.region, effectiveMethod, settings.methodIsAutomatic) {
                    val offered = PlaceProfiles.methodsFor(data.place.country, data.place.region)
                    if (settings.methodIsAutomatic || effectiveMethod in offered) offered else offered + effectiveMethod
                }
                methods.forEach { method ->
                    ChoiceRow(
                        title = trDynamic(method.title),
                        subtitle = subtitleFor(method),
                        selected = !settings.methodIsAutomatic && effectiveMethod == method,
                        accent = accent,
                        onClick = { actions.setMethod(method) }
                    )
                }
                HairRule()
                Caption(calibrationLine(data), color = TextSecondary)
                Spacer(Modifier.height(ui.s(6f)))
                Caption(tr("Углы солнца и правила местного муфтията"))
            })
        }
        add(SettingsTile(
            id = "madhab",
            title = tr("Мазхаб · время Асра"),
            value = if (settings.madhab == Madhab.HANAFI) tr("Ханафитский") else tr("Шафиитский"),
            glyph = GlyphKind.MOON
        ) {
            SegmentedControl(
                options = listOf(tr("Ханафитский"), tr("Шафиитский")),
                selectedIndex = if (settings.madhab == Madhab.HANAFI) 0 else 1,
                accent = accent,
                onSelect = { index -> actions.setMadhab(if (index == 0) Madhab.HANAFI else Madhab.STANDARD) }
            )
            Spacer(Modifier.height(ui.s(10f)))
            Caption(tr("Ханафитский Аср позже: тень — две высоты предмета, а не одна"))
        })
        run {
            val on = Prayer.entries.count { it.isPrayer && settings.notifications[it] == true }
            val total = Prayer.entries.count { it.isPrayer }
            val base = if (settings.preAlertMinutes > 0) tr("{0} из {1} · за {2} мин", on, total, settings.preAlertMinutes)
                else tr("{0} из {1}", on, total)
            add(SettingsTile(
                id = "notify",
                title = tr("Уведомления"),
                value = when {
                    !notificationsAllowed -> tr("Выключены в Android")
                    !exactAlarmsAllowed -> tr("{0} · нет точных будильников", base)
                    else -> base
                },
                glyph = GlyphKind.BELL
            ) {
                if (!notificationsAllowed) {
                    WarningBlock(
                        text = tr("Уведомления запрещены в Android — разрешите их в системе"),
                        actionText = tr("Открыть настройки уведомлений"),
                        onClick = actions.openNotificationSettings
                    )
                    Spacer(Modifier.height(ui.s(12f)))
                }
                if (!exactAlarmsAllowed) {
                    WarningBlock(
                        text = tr("Без точных будильников уведомление может опоздать на пару минут"),
                        actionText = tr("Разрешить точные будильники"),
                        onClick = { actions.openExactAlarmSettings() }
                    )
                    Spacer(Modifier.height(ui.s(12f)))
                }
                Prayer.entries.filter { it.isPrayer }.forEach { prayer ->
                    SwitchRow(
                        title = PrayerLabels.title(prayer),
                        subtitle = PrayerLabels.hint(prayer),
                        checked = settings.notifications[prayer] == true,
                        accent = accent,
                        onCheckedChange = { actions.setNotification(prayer, it) }
                    )
                }
                HairRule()
                StepperField(
                    label = tr("Напомнить заранее"),
                    value = tr("{0} мин", settings.preAlertMinutes),
                    accent = accent,
                    onMinus = { actions.setPreAlert(settings.preAlertMinutes - 5) },
                    onPlus = { actions.setPreAlert(settings.preAlertMinutes + 5) }
                )
                Spacer(Modifier.height(ui.s(10f)))
                NurButton(text = tr("Отключить экономию батареи для Nur"), accent = accent, onClick = { actions.openBatterySettings() })
                Spacer(Modifier.height(ui.s(8f)))
                Caption(tr("Xiaomi, Huawei, Samsung, Oppo: разрешите автозапуск и снимите ограничения батареи, иначе уведомления опоздают"))
            })
        }
        add(SettingsTile(
            id = "azan",
            title = tr("Звук азана"),
            value = trDynamic(settings.azanSound.title),
            glyph = GlyphKind.SOUND
        ) {
            AzanSound.entries.forEach { sound ->
                ChoiceRow(
                    title = trDynamic(sound.title),
                    subtitle = trDynamic(sound.explanation),
                    selected = settings.azanSound == sound,
                    accent = accent,
                    onClick = {
                        actions.setAzanSound(sound)
                        // Choosing is the only moment the choice can be judged, and the
                        // alternative is judging it at four in the morning.
                        if (sound.playsAzan) actions.previewAzan(sound) else actions.stopAzan()
                    }
                )
            }
            HairRule()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    NurButton(text = tr("Прослушать"), accent = accent,
                        onClick = { actions.previewAzan(settings.azanSound) }, enabled = settings.azanSound.playsAzan)
                }
                Spacer(Modifier.width(ui.s(10f)))
                Box(Modifier.weight(1f)) {
                    NurButton(text = tr("Остановить"), accent = accent, onClick = { actions.stopAzan() })
                }
            }
            Spacer(Modifier.height(ui.s(8f)))
            Caption(tr("Без интернета. Звучит как будильник и ставит музыку на паузу; в беззвучном режиме — только уведомление"))
        })
        add(SettingsTile(
            id = "highlat",
            title = tr("Высокие широты"),
            value = ruleTitle(settings.highLatitudeRule),
            glyph = GlyphKind.SUN
        ) {
            HighLatitudeRule.entries.forEach { rule ->
                ChoiceRow(
                    title = ruleTitle(rule),
                    subtitle = ruleSubtitle(rule),
                    selected = settings.highLatitudeRule == rule,
                    accent = accent,
                    onClick = { actions.setHighLatitudeRule(rule) }
                )
            }
            HairRule()
            Caption(tr("Только в дни, когда солнце не доходит до угла метода"))
        })
        add(SettingsTile(
            id = "rounding",
            title = tr("Округление секунд"),
            value = trDynamic(settings.rounding.title),
            glyph = GlyphKind.CLOCK
        ) {
            SegmentedControl(
                options = listOf(tr("Ближайшая"), tr("Вверх"), tr("Вниз")),
                selectedIndex = RoundingMode.entries.indexOf(settings.rounding),
                accent = accent,
                onSelect = { index -> actions.setRounding(RoundingMode.entries[index]) }
            )
            Spacer(Modifier.height(ui.s(10f)))
            Caption(trDynamic(settings.rounding.explanation), color = TextSecondary)
            Spacer(Modifier.height(ui.s(6f)))
            Caption(tr("Минута разницы с другими приложениями обычно отсюда"))
        })
        run {
            val edited = Prayer.entries.filter { (settings.offsets[it] ?: 0) != 0 }
            add(SettingsTile(
                id = "offsets",
                title = tr("Ручная коррекция"),
                value = when {
                    edited.isEmpty() && settings.hijriOffset == 0 -> tr("без правок")
                    edited.isEmpty() -> tr("хиджра {0} дн.", signed(settings.hijriOffset))
                    else -> edited.joinToString(", ") { "${PrayerLabels.title(it)} ${signed(settings.offsets[it] ?: 0)}" }
                },
                glyph = GlyphKind.SLIDERS
            ) {
                Prayer.entries.forEach { prayer ->
                    val value = settings.offsets[prayer] ?: 0
                    StepperField(
                        label = PrayerLabels.title(prayer),
                        value = tr("{0} мин", signed(value)),
                        accent = accent,
                        onMinus = { actions.setOffset(prayer, value - 1) },
                        onPlus = { actions.setOffset(prayer, value + 1) }
                    )
                }
                HairRule()
                StepperField(
                    label = tr("Сдвиг даты по хиджре"),
                    value = tr("{0} дн.", signed(settings.hijriOffset)),
                    accent = accent,
                    onMinus = { actions.setHijriOffset(settings.hijriOffset - 1) },
                    onPlus = { actions.setHijriOffset(settings.hijriOffset + 1) }
                )
                Spacer(Modifier.height(ui.s(8f)))
                Caption(tr("Сверьте с мечетью и выровняйте разницу — действует и на уведомления"))
            })
        }
        // 0.22.0: wallpapers first (what the eye sees most), then the icon, then the quiet switches.
        // «Цвет неба» left: the live sky and black AMOLED are two wallpapers of the row now.
        val wallpaper = WallpaperCatalog.resolve(settings.wallpaperId, settings.skyBackdrop)
        val liveSky = wallpaper.kind == Wallpaper.Kind.SKY
        add(SettingsTile(
            id = "display",
            title = tr("Оформление"),
            // 0.18.6: the row says what is on, in three words, not a sentence.
            value = listOfNotNull(
                wallpaper.title(),
                if (liveSky && settings.ambientBackdrop) tr("звёзды") else null,
                appIcon.title()
            ).joinToString(" · "),
            glyph = GlyphKind.SPARKLE
        ) {
            // 0.30.0: the two home screens. The choice is stored at once and the home behind the
            // settings changes on the next frame.
            SettingsSectionLabel(tr("Главный экран"))
            Spacer(Modifier.height(ui.s(8f)))
            SegmentedControl(
                options = listOf(tr("Карточки"), tr("Крупный намаз")),
                selectedIndex = settings.homeLayout.ordinal,
                accent = accent,
                onSelect = { index -> actions.setHomeLayout(HomeLayout.entries[index]) }
            )
            Spacer(Modifier.height(ui.s(10f)))
            Caption(
                if (settings.homeLayout == HomeLayout.CARDS) tr("Обратный отсчёт и шесть времён карточками")
                else tr("Название следующего намаза крупно и шкала дня")
            )
            HairRule(Modifier.padding(vertical = ui.s(8f)))
            WallpaperRow(
                current = wallpaper,
                recent = settings.recentWallpapers,
                palette = palette,
                accent = accent,
                bleed = ui.s(16f),
                onPick = { actions.setWallpaper(it.id) },
                onOpenAll = onOpenWallpapers
            )
            HairRule(Modifier.padding(vertical = ui.s(8f)))
            AppIconPicker(appIcon, accent) { icon ->
                AppIconSwitcher.select(context, icon)
                appIcon = icon
            }
            HairRule(Modifier.padding(vertical = ui.s(6f)))
            SettingsSectionLabel(tr("Фон"), Modifier.padding(top = ui.s(4f)))
            SwitchRow(
                title = tr("Звёзды ночью"),
                subtitle = if (liveSky) tr("Тихое мерцание на ночном небе") else tr("Для обоев «Живое небо»"),
                checked = settings.ambientBackdrop,
                accent = accent,
                onCheckedChange = { actions.setAmbientBackdrop(it) }
            )
        })
        add(SettingsTile(
            id = "about",
            title = tr("О расчёте"),
            value = "${trDynamic(effectiveMethod.angleSummary)} · ${data.place.zone.id}",
            glyph = GlyphKind.INFO
        ) {
            FactRow(tr("Страна профиля"), data.place.country)
            FactRow(tr("Метод"), methodTitle)
            FactRow(tr("Углы метода"), trDynamic(effectiveMethod.angleSummary))
            FactRow(tr("Сверка"), trDynamic(data.profile.calibration.label))
            FactRow(tr("Координаты"), format(data.place.coordinates.latitude) + ", " + format(data.place.coordinates.longitude))
            FactRow(tr("Часовой пояс"), data.place.zone.id)
            FactRow(tr("Пояс определён"), zoneSourceLabel(data.place.zoneSource))
            data.place.accuracyMeters?.let { FactRow(tr("Точность точки"), tr("±{0} м", it.toInt())) }
            if (data.place.fromDeviceLocation) {
                settings.locationAddress?.let { FactRow(tr("Адрес точки"), it) }
                settings.locationPostalCode?.let { FactRow(tr("Почтовый индекс"), it) }
            }
            FactRow(tr("Азимут кыблы"), "${Math.round(data.qibla)}°")
            FactRow(tr("Сухур сегодня"), sourceLabel(data.today.saharSource))
            FactRow(tr("Фаджр сегодня"), sourceLabel(data.today.fajrSource))
            FactRow(tr("Иша сегодня"), sourceLabel(data.today.ishaSource))
            HairRule()
            Caption(trDynamic(data.profile.note), color = TextSecondary)
            data.place.zoneExplanation.takeIf { it.isNotEmpty() }?.let {
                HairRule()
                Caption(trDynamic(it), color = TextSecondary)
            }
            data.today.note?.let {
                HairRule()
                Caption(trDynamic(it), color = TextSecondary)
            }
            HairRule()
            Caption(tr("Алгоритм: астрономические формулы Жана Мееса (Astronomical Algorithms, 2-е изд.), точность солнечных событий — единицы секунд. Каждое пересечение проверяется по высоте солнца, поэтому касание угла в белую ночь не выдаётся за наступление времени."))
        })
    }

    /*
     * 0.34.0 «Стекло»: the page is transparent. The wallpaper lies under it sharp and darkened (the backdrop's
     * `shade`), the rows are glass cards measured from the reference (see MenuGlass), and there is no title on the
     * index: the reference has none, and the way out is the ring at the bottom right (NurRoot), which asks for the
     * system back, so an editor closes into the index before the page leaves.
     *
     * An editor swaps with the index by a short shared-axis move; nothing in it is opaque, so the outgoing page
     * fades out in ~100 ms while the new one comes in behind it.
     */
    AnimatedContent(targetState = open ?: "index", transitionSpec = {
        val opening = targetState != "index"
        val move = tween<IntOffset>(NavigationMotion.EDITOR_ENTER_MILLIS, easing = FastOutSlowInEasing)
        val fadeInSpec = tween<Float>(NavigationMotion.TAB_ENTER_MILLIS, delayMillis = 40, easing = LinearOutSlowInEasing)
        val fadeOutSpec = tween<Float>(NavigationMotion.EXIT_MILLIS / 2 + 30, easing = FastOutLinearInEasing)
        val enter = slideInHorizontally(move) { w -> if (opening) w / 6 else -w / 12 } + fadeIn(fadeInSpec)
        val exit = slideOutHorizontally(move) { w -> if (opening) -w / 12 else w / 6 } + fadeOut(fadeOutSpec)
        (enter togetherWith exit).apply { targetContentZIndex = if (opening) 1f else -1f }.using(null)
    }, label = "settingsEditor", modifier = modifier.fillMaxSize()) { page ->
        pages.SaveableStateProvider(page) {
            val spec = specs.firstOrNull { it.id == page }
            // A tablet or a landscape phone keeps a phone-like column in the middle instead of stretched cards.
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxHeight()
                        .widthIn(max = MenuGlass.MaxWidth)
                        .fillMaxWidth()
                        .testTag("settings-$page"),
                    contentPadding = PaddingValues(
                        start = ui.s(MenuGlass.SIDE), end = ui.s(MenuGlass.SIDE), top = ui.s(20f), bottom = dockInset
                    ),
                    verticalArrangement = Arrangement.spacedBy(ui.s(if (spec == null) MenuGlass.GAP else 16f))
                ) {
                    if (spec != null) {
                        item(key = "heading") {
                            ScreenHeader(
                                title = spec.title,
                                onBack = null,
                                modifier = Modifier.padding(start = ui.s(4f))
                            )
                        }
                        item(key = "editor-${spec.id}") {
                            SettingsCard(Modifier.padding(ui.s(16f))) { spec.content(this) }
                        }
                    } else {
                        if (!notificationsAllowed || !exactAlarmsAllowed) item(key = "permission") {
                            SettingsCard(Modifier) {
                                SettingsRow(
                                    glyph = GlyphKind.BELL,
                                    title = if (!notificationsAllowed) tr("Разрешите уведомления") else tr("Разрешите точные напоминания"),
                                    value = tr("Без этого азан может не прийти вовремя"),
                                    tint = Crimson,
                                    tag = "setting-permission",
                                    onClick = { open = "notify" }
                                )
                            }
                        }
                        item(key = "where") {
                            Column(Modifier.fillMaxWidth()) {
                                SettingsCard(Modifier) {
                                    SettingsRow(
                                        glyph = GlyphKind.LOCATION,
                                        overline = if (data.place.fromDeviceLocation) tr("Текущее местоположение (авто)") else tr("Местоположение"),
                                        title = data.place.label,
                                        value = data.place.subtitle.takeIf { it.isNotBlank() },
                                        tag = "setting-place",
                                        onClick = actions.openCityPicker
                                    )
                                    val language = specs.first { it.id == "language" }
                                    SettingsRow(
                                        glyph = language.glyph,
                                        overline = language.title,
                                        title = language.value,
                                        tag = "setting-language",
                                        onClick = { open = language.id }
                                    )
                                }
                                locationStatus?.let {
                                    Caption(it, Modifier.padding(start = ui.s(6f), end = ui.s(6f), top = 10.dp))
                                }
                            }
                        }
                        // By meaning, as in the reference: what is counted and for whom, how it is rounded and
                        // corrected, how it reaches you and how it looks, and the account of the calculation.
                        listOf(
                            listOf("method", "madhab"),
                            listOf("highlat", "rounding", "offsets"),
                            listOf("notify", "azan", "display"),
                            listOf("about")
                        ).forEachIndexed { groupIndex, ids ->
                            item(key = "group-$groupIndex") {
                                SettingsCard(Modifier) {
                                    ids.mapNotNull { id -> specs.firstOrNull { it.id == id } }.forEach { row ->
                                        SettingsRow(row.glyph, row.title, row.value, tag = "setting-${row.id}") { open = row.id }
                                    }
                                }
                            }
                        }
                        item(key = "version") {
                            Text(tr("Нур {0}", APP_VERSION), color = MenuGlass.Subtitle, fontSize = ui.t(12f),
                                modifier = Modifier.padding(start = ui.s(6f)))
                        }
                    }
                }
            }
        }
    }
}

internal const val APP_VERSION = "0.34.0"

private class SettingsTile(
    val id: String,
    val title: String,
    val value: String,
    val glyph: GlyphKind,
    val content: @Composable ColumnScope.() -> Unit
)

/** The surfaces the old opaque page used; the first-place card on home still takes its colours from here. */
internal class SettingsColors(val background: Color, val card: Color, val divider: Color) {
    companion object {
        fun of(palette: PhasePalette): SettingsColors {
            val base = lerp(Color(0xFF121218), palette.zenith, 0.10f)
            return SettingsColors(
                background = base,
                card = lerp(base, Color.White, 0.065f),
                divider = Color(0x14FFFFFF)
            )
        }
    }
}

/**
 * The card of the menu: one piece of glass ([MenuGlass]), 19 dp corners, no dividers inside — the rows are told apart
 * by their icons and the air around them. [inner] pads the content (the editors); the rows of the index need none.
 */
@Composable
internal fun SettingsCard(
    inner: Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    val ui = uiScale()
    Column(
        Modifier
            .fillMaxWidth()
            .menuGlass(ui.s(MenuGlass.CORNER))
            .then(inner),
        content = content
    )
}

/**
 * One settings row, measured from the reference: a 24 dp icon 19.5 dp from the edge, 18 dp to the text, a bold white
 * 16 sp title, 14 sp #929DB1 lines with a soft shadow, a thin chevron, 50.5 dp tall at least (a row with the grey
 * line above or below is ~71 dp). With [overline] the small grey line goes above and the value is the big line
 * ("Язык / Русский"), for rows whose value *is* the answer.
 */
@Composable
internal fun SettingsRow(
    glyph: GlyphKind,
    title: String,
    value: String? = null,
    overline: String? = null,
    tint: Color = MenuGlass.Title,
    tag: String? = null,
    onClick: () -> Unit
) {
    val ui = uiScale()
    val shadow = TextStyle(shadow = MenuGlass.TextShadow)
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (tag != null) Modifier.testTag(tag) else Modifier)
            .clickable(role = Role.Button, onClick = onClick)
            .heightIn(min = ui.s(50.5f))
            .padding(start = ui.s(19.5f), end = ui.s(16f), top = ui.s(15.25f), bottom = ui.s(15.25f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Glyph(glyph, tint, Modifier.size(ui.s(24f)))
        Spacer(Modifier.width(ui.s(18f)))
        Column(Modifier.weight(1f)) {
            overline?.let {
                Text(it, color = MenuGlass.Subtitle, fontSize = ui.t(14f), lineHeight = ui.t(18f), maxLines = 1,
                    overflow = TextOverflow.Ellipsis, style = shadow)
                Spacer(Modifier.height(ui.s(1f)))
            }
            Text(title, color = tint, fontSize = ui.t(16f), lineHeight = ui.t(20f), fontWeight = FontWeight.Bold,
                maxLines = 2, overflow = TextOverflow.Ellipsis, style = shadow)
            value?.let {
                Text(it, color = MenuGlass.Subtitle, fontSize = ui.t(14f), lineHeight = ui.t(18f), maxLines = 2,
                    overflow = TextOverflow.Ellipsis, style = shadow, modifier = Modifier.padding(top = ui.s(2f)))
            }
        }
        Spacer(Modifier.width(ui.s(12f)))
        MenuChevron()
    }
}

/* ------------------------------------------------------------------------------------------------
 * Local pieces
 * ---------------------------------------------------------------------------------------------- */

/** A signed number states a direction, so the plus sign is never dropped. */
private fun signed(value: Int): String = if (value > 0) "+$value" else "$value"

private fun format(value: Double): String = String.format(java.util.Locale.US, "%.4f", value)

/** One sentence about how much the current profile has actually been checked. */
private fun calibrationLine(data: PrayerData): String {
    val title = trDynamic(data.profile.method.title)
    return when (data.profile.calibration) {
        Calibration.PRINTED_CALENDAR -> tr("Профиль «{0}» сверен с печатным календарём.", title)
        Calibration.OFFICIAL_ANGLES -> tr("Профиль «{0}»: официальные углы местного управления, печатный календарь ещё не сверялся построчно.", title)
        Calibration.ASSUMED -> tr("Профиль «{0}» — общий региональный: углы официальные, поправок местного календаря в нём нет.", title)
    }
}

@Composable
private fun WarningBlock(text: String, actionText: String, onClick: () -> Unit) {
    val ui = uiScale()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(ui.s(14f)))
            .background(Crimson.copy(alpha = 0.10f))
            .padding(ui.s(13f))
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(ui.s(7f)).clip(CircleShape).background(Crimson))
            Spacer(Modifier.width(ui.s(8f)))
            Text(tr("Требуется разрешение"), color = Crimson, fontSize = ui.t(11.5f), fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(ui.s(7f)))
        Text(text = text, color = TextSecondary, fontSize = ui.t(12f), lineHeight = ui.t(16.5f))
        Spacer(Modifier.height(ui.s(11f)))
        NurButton(text = actionText, accent = Crimson, onClick = onClick, primary = true)
    }
}

private fun subtitleFor(method: CalculationMethod): String {
    val hint = when (method) {
        CalculationMethod.RUSSIA_DUM -> tr("Россия и Беларусь")
        CalculationMethod.SPIRITUAL_BOARD_TATARSTAN -> tr("Татарстан, календарь ДУМ РТ")
        CalculationMethod.UZBEKISTAN_BOARD -> tr("Узбекистан, сверено с namozvaqti.uz")
        CalculationMethod.UMM_AL_QURA -> tr("Саудовская Аравия")
        CalculationMethod.TURKEY -> tr("С поправками Diyanet")
        CalculationMethod.TEHRAN -> tr("Иран, Магриб по углу")
        else -> null
    }
    val angles = trDynamic(method.angleSummary)
    return if (hint == null) angles else "$hint · $angles"
}

private fun ruleTitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> tr("Автоматически")
    HighLatitudeRule.FIXED_INTERVAL -> tr("Фиксированный интервал (ДУМ РФ)")
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> tr("Середина ночи")
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> tr("Одна седьмая ночи")
    HighLatitudeRule.TWILIGHT_ANGLE -> tr("Пропорция по углу сумерек")
}

private fun ruleSubtitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> tr("Выше 48° широты — фиксированный интервал, иначе середина ночи")
    HighLatitudeRule.FIXED_INTERVAL -> tr("Восход − 120 мин и закат + 90 мин, как печатает ДУМ РТ")
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> tr("Фаджр и Иша не переходят середину ночи")
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> tr("Классическая доля ночи 1/7")
    HighLatitudeRule.TWILIGHT_ANGLE -> tr("Доля ночи пропорциональна углу метода")
}

/** Which piece of evidence decided the time zone. */
private fun zoneSourceLabel(source: com.nur.prayer.location.ZoneSource): String = when (source) {
    com.nur.prayer.location.ZoneSource.DEVICE -> tr("по часам телефона")
    com.nur.prayer.location.ZoneSource.NEIGHBOURHOOD -> tr("по городам рядом")
    com.nur.prayer.location.ZoneSource.LONGITUDE -> tr("по долготе (приближённо)")
}

/** Exhaustive on purpose: a new [TimeSource] must fail to compile here, not fall behind silently. */
private fun sourceLabel(source: TimeSource): String = when (source) {
    TimeSource.ANGLE -> tr("по углу солнца")
    TimeSource.PRINTED_TABLE -> tr("из печатной таблицы муфтията")
    TimeSource.METHOD_INTERVAL -> tr("интервал метода")
    TimeSource.FIXED_INTERVAL -> tr("фикс. интервал (короткая ночь)")
    TimeSource.NIGHT_FRACTION -> tr("доля ночи (короткая ночь)")
    TimeSource.MIDNIGHT_BOUND -> tr("ограничено серединой ночи")
    TimeSource.CONGREGATION -> tr("как в мечети: восход − 90 мин")
    TimeSource.DAWN_BOUND -> tr("поднято до рассвета")
}
