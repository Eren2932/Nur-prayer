package com.nur.prayer.ui.home

import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.shell.ShellGlyph

/*
 * 0.27.0 «Капсула»: the sections of the panel the capsule opens into, in the order of its grid
 * (three across, read like a page). Settings are not in the grid: the avatar on home opens them.
 */
enum class HomeSection(val glyph: ShellGlyph) {
    QURAN(ShellGlyph.BOOK),
    DHIKR(ShellGlyph.TASBIH),
    QIBLA(ShellGlyph.KAABA),
    TODAY(ShellGlyph.CHECKLIST),
    COURSE(ShellGlyph.AIN),
    SCHEDULE(ShellGlyph.CALENDAR),
    SETTINGS(ShellGlyph.DOTS);

    fun label(): String = when (this) {
        QURAN -> tr("Коран")
        DHIKR -> tr("Зикр")
        QIBLA -> tr("Кыбла")
        TODAY -> tr("Дела")
        COURSE -> tr("Учёба")
        SCHEDULE -> tr("Месяц")
        SETTINGS -> tr("Настройки")
    }

    companion object {
        /** The panel grid: two rows of three. */
        val GRID: List<HomeSection> = listOf(QURAN, DHIKR, QIBLA, TODAY, COURSE, SCHEDULE)
    }
}
