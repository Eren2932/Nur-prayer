package com.nur.prayer.ui.settings

import com.nur.prayer.i18n.tr

import com.nur.prayer.ui.components.ScreenHeader
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.City
import com.nur.prayer.data.Place
import com.nur.prayer.ui.components.ExitButtonSpec
import com.nur.prayer.ui.components.MenuGlass
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.menuGlass
import com.nur.prayer.ui.components.PanelLevel
import com.nur.prayer.ui.components.nurPanel
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import java.time.Instant
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.learn.textDp

@Immutable
private data class CityResult(val city: City, val utc: String)
private data class SearchState(val query: String = "", val rows: List<CityResult> = emptyList(),
    val loading: Boolean = true, val error: Boolean = false)

/**
 * One scroll container, transparent viewport and content-sized glass cards, even for one result.
 * 0.34.0: the same glass and the same 17 dp margins as the settings index (MenuGlass), on the sharp, darkened wallpaper;
 * no back arrow — the way out is the ring at the bottom right.
 */
@Composable
fun CityPickerScreen(
    palette: PhasePalette, selectedCityId: Int, search: suspend (String) -> List<City>,
    onPick: (City) -> Unit, onBack: () -> Unit, onUseLocation: () -> Unit,
    locating: Boolean, locationStatus: String? = null, modifier: Modifier = Modifier,
    currentPlace: Place? = null, locationButtonLabel: String = tr("Определить местоположение"),
    onOpenLocationPermissions: (() -> Unit)? = null
) {
    val ui = uiScale()
    var query by rememberSaveable { mutableStateOf("") }
    val normalized = remember(query) { query.trim().lowercase(Locale.ROOT) }
    val searchFn by rememberUpdatedState(search)
    val keyboard = LocalSoftwareKeyboardController.current
    val listState = rememberLazyListState()
    var retry by remember { mutableIntStateOf(0) }
    var result by remember { mutableStateOf(SearchState()) }
    LaunchedEffect(normalized, retry) {
        result = SearchState(query = normalized)
        if (normalized.isNotEmpty()) delay(80)
        try {
            val rows = withContext(Dispatchers.Default) {
                val cities = searchFn(normalized)
                val instant = Instant.now()
                val offsets = cities.map { it.timeZoneId }.distinct().associateWith {
                    runCatching { CityTimeZones.label(it, instant) }.getOrDefault("UTC?")
                }
                cities.map { CityResult(it, offsets.getValue(it.timeZoneId)) }
            }
            result = SearchState(normalized, rows, loading = false)
        } catch (cancel: CancellationException) {
            throw cancel
        } catch (_: Exception) {
            result = SearchState(normalized, loading = false, error = true)
        }
    }
    var previousQuery by rememberSaveable { mutableStateOf(normalized) }
    LaunchedEffect(normalized) {
        if (previousQuery != normalized) {
            listState.scrollToItem(0)
            previousQuery = normalized
        }
    }
    val busy = result.loading || result.query != normalized
    val usingDeviceLocation = currentPlace?.fromDeviceLocation == true
    Box(modifier.fillMaxSize().navigationBarsPadding().imePadding(), contentAlignment = Alignment.TopCenter) {
    Column(Modifier.fillMaxHeight().widthIn(max = MenuGlass.MaxWidth).fillMaxWidth().padding(horizontal = ui.s(MenuGlass.SIDE))) {
        ScreenHeader(tr("Город"), onBack = null, modifier = Modifier.padding(start = ui.s(4f)))
        // Controls scroll too: keyboard, landscape and a large font must not squeeze results out.
        // Never paint the full remaining height as a card; only each actual row has a background.
        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth().testTag("city-scroll"),
            // The last row stops above the ring of the exit button, which lies over the bottom right corner.
            contentPadding = PaddingValues(bottom = ExitButtonSpec.BottomPad + ExitButtonSpec.Hit), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item(key = "search") {
                Row(Modifier.fillMaxWidth().menuGlass(ui.s(14f))
                    .heightIn(min = 52.dp).padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text(tr("Город, регион или страна"), color = TextTertiary, fontSize = ui.t(15f))
                        BasicTextField(query, onValueChange = { query = it }, singleLine = true,
                            textStyle = TextStyle(color = TextPrimary, fontSize = ui.t(15f)), cursorBrush = SolidColor(palette.accent),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { keyboard?.hide() }),
                            modifier = Modifier.fillMaxWidth().semantics { contentDescription = tr("Поиск города") })
                    }
                    if (query.isNotEmpty()) TextButton(onClick = { query = "" },
                        modifier = Modifier.semantics { contentDescription = tr("Очистить поиск") }) {
                        Glyph(GlyphKind.CLOSE, TextPrimary, Modifier.size(16.dp))
                    }
                }
            }
            item(key = "locate") {
                NurButton(if (locating) tr("Определяем координаты…") else locationButtonLabel,
                    palette.accent, { keyboard?.hide(); query = ""; onUseLocation() }, enabled = !locating)
            }
            if (onOpenLocationPermissions != null && normalized.isEmpty()) item(key = "location-permissions") {
                TextButton(onClick = { keyboard?.hide(); onOpenLocationPermissions() }) {
                    Text(tr("Разрешения и точность Android"), color = palette.accentSoft, fontSize = ui.t(12f))
                }
            }
            if (currentPlace != null && normalized.isEmpty()) item(key = "current-place") {
                Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp)) {
                    Text(tr("Сейчас: {0}", currentPlace.label), color = palette.accentSoft, fontSize = ui.t(13f))
                    Text(if (usingDeviceLocation) currentPlace.subtitle else tr("Город выбран вручную"),
                        color = TextTertiary, fontSize = ui.t(11f))
                }
            }
            if (locationStatus != null && normalized.isEmpty()) item(key = "location-status") {
                Text(locationStatus, color = TextSecondary, fontSize = ui.t(12f),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp))
            }
            item(key = "results-caption") {
                Row(Modifier.padding(top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (busy) {
                        CircularProgressIndicator(Modifier.size(14.dp), color = palette.accent, strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(when {
                        busy -> tr("Поиск…")
                        result.error -> tr("Не удалось открыть базу городов")
                        normalized.isEmpty() -> tr("Города")
                        else -> tr("Найдено: {0}", result.rows.size)
                    }, color = TextSecondary, fontSize = ui.t(12f))
                }
            }
            when {
                busy -> Unit // never let stale matches be selected while a new query is running
                result.error -> item(key = "error") {
                    Column(Modifier.fillMaxWidth().menuGlass(ui.s(14f)).padding(16.dp)) {
                        Text(tr("Не удалось прочитать базу. Повторите загрузку; текущий город и настройки сохранены."), color = TextSecondary)
                        TextButton(onClick = { retry++ }) { Text(tr("Повторить"), color = palette.accentSoft) }
                    }
                }
                result.rows.isEmpty() -> item(key = "empty") {
                    Text(tr("Совпадений нет. Попробуйте часть названия, регион или страну."),
                        color = TextSecondary, fontSize = ui.t(14f),
                        modifier = Modifier.fillMaxWidth().menuGlass(ui.s(14f)).padding(16.dp).testTag("city-empty"))
                }
                else -> items(result.rows, key = { it.city.id }, contentType = { "city" }) { row ->
                    CityRow(row, selected = row.city.id == selectedCityId && !usingDeviceLocation,
                        nearby = row.city.id == selectedCityId && usingDeviceLocation, accent = palette.accent) {
                        keyboard?.hide()
                        onPick(it)
                    }
                }
            }
        }
    }
    }
}

@Composable
private fun CityRow(row: CityResult, selected: Boolean, nearby: Boolean, accent: Color, onPick: (City) -> Unit) {
    val ui = uiScale()
    // One glass card per city (no hairlines between rows); the chosen one is tinted by the accent.
    Row(Modifier.fillMaxWidth().menuGlass(ui.s(MenuGlass.CORNER))
        .background(if (selected) accent.copy(alpha = 0.14f) else Color.Transparent)
        .selectable(selected = selected, role = Role.RadioButton, onClick = { onPick(row.city) })
        .heightIn(min = 76.dp).testTag("city-row-${row.city.id}")
        .padding(horizontal = ui.s(19.5f), vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(row.city.name, color = if (selected) accent else MenuGlass.Title, fontSize = ui.t(16f),
                fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                style = TextStyle(shadow = MenuGlass.TextShadow))
            Text(row.city.subtitle, color = MenuGlass.Subtitle, fontSize = ui.t(14f), maxLines = 2,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp),
                style = TextStyle(shadow = MenuGlass.TextShadow))
        }
        Spacer(Modifier.width(16.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(row.utc, color = MenuGlass.Subtitle, fontSize = ui.t(12f), fontFamily = FontFamily.Monospace)
            if (selected) Glyph(GlyphKind.SEAL, accent, Modifier.padding(top = 2.dp).size(textDp(16f)))
            else if (nearby) Text(tr("Рядом"), color = accent, fontSize = ui.t(12f))
        }
    }
}
