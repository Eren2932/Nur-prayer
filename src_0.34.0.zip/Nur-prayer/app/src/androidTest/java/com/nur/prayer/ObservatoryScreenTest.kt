package com.nur.prayer

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.semantics.getOrNull
import androidx.compose.ui.test.onAllNodesWithText
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Before
import com.nur.prayer.ui.home.HomeTimeline
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assert
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performClick
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.settings.SettingsScreen
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.rememberSystemBack
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.TAB_HOME
import com.nur.prayer.ui.shell.CapsuleNow
import com.nur.prayer.ui.shell.LocalShell
import com.nur.prayer.ui.shell.PrayerSheetHost
import com.nur.prayer.ui.shell.ShellGlyph
import com.nur.prayer.ui.shell.ShellLayer
import com.nur.prayer.ui.shell.ShellState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.nur.prayer.ui.qibla.Heading
import com.nur.prayer.ui.qibla.HeadingSource
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Run in the existing API 26 / 34 CI matrix. Authored here, not claimed as locally executed. */
@RunWith(AndroidJUnit4::class)
class ObservatoryScreenTest {
    @get:Rule val compose = createComposeRule()
    private val moment = ZonedDateTime.parse("2026-09-07T21:00:00+03:00[Europe/Moscow]")
    private val actions = AppActions({}, {}, {}, {}, {}, {}, {}, {}, {}, { _, _ -> }, { _, _ -> }, {}, {}, {}, {}, {})

    /** Home UI flags live in «nur_ui»; every test starts as on a first launch. */
    @Before fun startFresh() {
        InstrumentationRegistry.getInstrumentation().targetContext
            .getSharedPreferences("nur_ui", Context.MODE_PRIVATE).edit().clear().commit()
    }

    /** Nodes whose merged description starts with [prefix]: times say «Зухр 12:12», the countdown «До …». */
    private fun described(prefix: String) = SemanticsMatcher("description starts with $prefix") { node ->
        node.config.getOrNull(SemanticsProperties.ContentDescription)?.any { it.startsWith(prefix) } == true
    }

    /** 0.27.0: home, the capsule over it and the prayer sheet, wired the way NurRoot wires them. */
    private fun showHome(
        data: PrayerData,
        opened: MutableList<String> = mutableListOf()
    ) = compose.setContent {
        NurTheme {
            val shell = remember { ShellState() }
            var sheet by remember { mutableStateOf<Prayer?>(null) }
            val now = remember { mutableStateOf(moment) }
            CompositionLocalProvider(LocalShell provides shell) {
                Box(Modifier.fillMaxSize()) {
                    HomeScreen(
                        data = data, now = now, palette = paletteFor(Prayer.ISHA),
                        onOpenCity = { opened += "city" },
                        onOpenSchedule = { opened += "schedule" },
                        onOpenPrayer = { sheet = it }
                    )
                    ShellLayer(
                        shell = shell, route = TAB_HOME, data = data, now = now,
                        home = CapsuleNow("Вечерние азкары", "сейчас · 0 из 12", ShellGlyph.TASBIH) { opened += "azkar" },
                        onOpenSection = { section, _ -> opened += section.name },
                        onHome = { opened += "home" },
                        onOpenPrayer = { sheet = it }
                    )
                    PrayerSheetHost(
                        prayer = sheet, data = data, now = now, actions = actions,
                        notificationsAllowed = true, exactAlarmsAllowed = true,
                        onDismiss = { sheet = null }, onOpenSettings = {}
                    )
                }
            }
        }
    }
    private fun fixture(): PrayerData {
        val city = City.MOSCOW
        val settings = AppSettings()
        val params = settings.paramsFor(city.country)
        val place = Place(city.name, city.subtitle, city.country, city.coordinates, city.zone, false)
        return PrayerData(place, PrayerEngine.days(moment.toLocalDate(), 3, city.coordinates, city.zone, params),
            PrayerEngine.window(moment, city.coordinates, city.zone, params), qiblaBearing(city.coordinates),
            distanceToKaabaKm(city.coordinates), HijriCalendar.format(moment.toLocalDate()), settings,
            settings.profileFor(city.country), params)
    }

    @Test fun homeShowsTheSixTimesAndOneCountdown() {
        val data = fixture()
        showHome(data)
        listOf(Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA).forEach {
            compose.onNode(described("${PrayerLabels.title(it)} ")).assertExists()
        }
        compose.onAllNodes(described("До ")).assertCountEquals(1)
    }

    @Test fun tappingATimeOpensItsSheetAndCloseReturnsHome() {
        val data = fixture()
        val pages = HomeTimeline.prayers(data.fajrEqualsDawn)
        showHome(data)
        compose.onNode(described("${PrayerLabels.title(Prayer.DHUHR)} ")).performClick()
        compose.waitUntil(5000) { compose.onAllNodesWithText("Завтра").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Страница ${HomeTimeline.pageOf(Prayer.DHUHR, data.fajrEqualsDawn) + 1} из ${pages.size}")
            .assertIsDisplayed()
        compose.onAllNodesWithContentDescription("Закрыть")[0].performClick()
        compose.waitUntil(5000) { compose.onAllNodesWithText("Завтра").fetchSemanticsNodes().isEmpty() }
        compose.onNode(described("${PrayerLabels.title(Prayer.DHUHR)} ")).assertExists()
    }

    @Test fun theCapsuleOpensIntoThePanelAndEachCellDispatchesItsSection() {
        val opened = mutableListOf<String>()
        showHome(fixture(), opened)
        listOf("Кыбла", "Месяц", "Коран").forEach { label ->
            compose.onNodeWithContentDescription("Разделы").performClick()
            compose.waitUntil(3000) { compose.onAllNodesWithContentDescription(label).fetchSemanticsNodes().isNotEmpty() }
            compose.onNodeWithContentDescription(label).performClick()
            compose.waitUntil(3000) { compose.onAllNodesWithContentDescription(label).fetchSemanticsNodes().isEmpty() }
        }
        compose.runOnIdle { assertEquals(listOf("QIBLA", "SCHEDULE", "QURAN"), opened) }
    }

    @Test fun theCapsuleTextStartsWhatFitsNowAndTheGearOfThePanelOpensSettings() {
        val opened = mutableListOf<String>()
        showHome(fixture(), opened)
        compose.onNodeWithText("Вечерние азкары").performClick()
        // There is no avatar in the corner any more: settings are the gear in the panel the capsule opens into.
        compose.onNodeWithContentDescription("Настройки").assertDoesNotExist()
        compose.onNodeWithContentDescription("Разделы").performClick()
        compose.waitUntil(3000) { compose.onAllNodesWithContentDescription("Настройки").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Настройки").performClick()
        compose.runOnIdle { assertEquals(listOf("azkar", "SETTINGS"), opened) }
    }

    @Test fun homeDoesNotDisplayDecorativeCopy() {
        showHome(fixture())
        compose.onNodeWithText("Время для главного").assertDoesNotExist()
        compose.onNodeWithText("СЛЕДУЮЩЕЕ ВРЕМЯ").assertDoesNotExist()
        compose.onNodeWithText("ПУТЬ ВРЕМЕНИ").assertDoesNotExist()
        compose.onNodeWithText("КАЛЕНДАРЬ").assertDoesNotExist()
    }

    /** 0.27.1: the sensor details are a mini button above the capsule that pops a card up, not an accordion. */
    @Test fun sensorDetailsPopUpFromTheMiniButtonAndGoAwayAgain() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading()) } }
        compose.onAllNodesWithText("Азимут кыблы").assertCountEquals(0)
        compose.onNodeWithContentDescription("Точность и датчики").performClick()
        compose.waitUntil(3000) { compose.onAllNodesWithText("Азимут кыблы").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Точность и датчики").performClick()
        compose.waitUntil(3000) { compose.onAllNodesWithText("Азимут кыблы").fetchSemanticsNodes().isEmpty() }
    }

    @Test fun unavailableSensorCannotShowDirectionFound() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading()) } }
        compose.onNodeWithText("Компас недоступен").assertIsDisplayed()
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Нет достоверного направления"))
        compose.onNodeWithContentDescription("Кааба — направление кыблы").assertIsDisplayed()
    }
    @Test fun magneticInterferenceCannotReportLockEvenAtTargetAzimuth() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 110f, source = HeadingSource.FUSED)) } }
        compose.onNodeWithText("Проверьте калибровку и помехи").assertIsDisplayed()
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Нет достоверного направления"))
    }
    @Test fun alignedCalibratedFlatSensorShowsLock() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 45f, source = HeadingSource.FUSED)) } }
        // 0.23.0: the dial searches first (≥ 1 s), then turns onto the bearing and only then confirms.
        compose.waitUntil(8000) { compose.onAllNodesWithText("Направление на Каабу").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Направление найдено"))
    }
    /** 0.23.0: the hold does not matter — a phone held upright like a camera finds the Kaaba too. */
    @Test fun tiltedSensorStillFindsDirection() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 45f, tiltDegrees = 60f, source = HeadingSource.FUSED)) } }
        compose.waitUntil(8000) { compose.onAllNodesWithText("Направление на Каабу").fetchSemanticsNodes().isNotEmpty() }
        compose.onAllNodesWithText("Положите телефон горизонтально").assertCountEquals(0)
    }
    @Test fun everySettingsEditorOpensAndReturnsToTheIndex() {
        val data = fixture()
        // 0.34.0: the editors have no back arrow; the way out is the ring of NurRoot, which asks for the system back.
        var back: () -> Unit = {}
        compose.setContent { NurTheme { back = rememberSystemBack(); SettingsScreen(data, paletteFor(Prayer.ISHA), actions, true) } }
        compose.onNodeWithText("Ваш Нур").assertDoesNotExist()
        listOf("method", "madhab", "notify", "azan", "highlat", "rounding", "offsets", "about").forEach { id ->
            compose.onNodeWithTag("settings-index").performScrollToNode(hasTestTag("setting-$id"))
            compose.onNodeWithTag("setting-$id").performClick()
            compose.onNodeWithTag("settings-$id").assertIsDisplayed()
            compose.runOnIdle { back() }
            compose.onNodeWithTag("settings-index").assertIsDisplayed()
        }
    }

}
