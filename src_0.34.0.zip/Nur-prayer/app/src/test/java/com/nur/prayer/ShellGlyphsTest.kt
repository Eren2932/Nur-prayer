package com.nur.prayer

import com.nur.prayer.ui.home.GlyphPath
import com.nur.prayer.ui.shell.AinFit
import com.nur.prayer.ui.shell.ShellGlyph
import com.nur.prayer.ui.shell.ShellIconData
import com.nur.prayer.ui.shell.sectionArt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.33.0: the section glyphs (the designer's sheet, vectorised) and the letter ع that stands for «Учёба». */
class ShellGlyphsTest {
    private val drawn = listOf(
        "QURAN" to ShellIconData.QURAN, "DHIKR" to ShellIconData.DHIKR, "QIBLA" to ShellIconData.QIBLA,
        "TODO" to ShellIconData.TODO, "MONTH" to ShellIconData.MONTH
    )

    @Test fun everyDrawnGlyphParsesAndStaysInsideItsSquare() {
        for ((name, art) in drawn) {
            assertEquals(name, 100f, art.art.width, 0f)
            assertEquals(name, 100f, art.art.height, 0f)
            assertEquals(name, 1, art.art.layers.size)
            val c = GlyphPath.parse(art.art.layers[0].path)
            assertTrue(name, c.isNotEmpty())
            assertEquals(name, GlyphPath.MOVE, c[0], 0f)
            assertEquals(name, GlyphPath.CLOSE, c[c.size - 1], 0f)
            // Every number after a command is a coordinate in the 100x100 square (a bezier may overshoot a hair).
            var i = 0
            while (i < c.size) {
                val n = when (c[i]) { GlyphPath.MOVE -> 2; GlyphPath.CUBIC -> 6; else -> 0 }
                for (k in 1..n) assertTrue("$name ${c[i + k]}", c[i + k] in -3f..103f)
                i += 1 + n
            }
        }
    }

    @Test fun theGlyphsKeepTheSizeTheyHaveOnTheSheet() {
        for ((name, art) in drawn) {
            // Share of the sheet's circle: all of them are about half of it, none dwarfs the well.
            assertTrue("$name share ${art.share}", art.share in 0.4f..0.65f)
            assertTrue("$name dx", kotlin.math.abs(art.dx) < 0.05f)
            assertTrue("$name dy", kotlin.math.abs(art.dy) < 0.08f)
        }
    }

    @Test fun studyIsTheLetterNotAnArt() {
        assertNull(sectionArt(ShellGlyph.AIN))
        listOf(ShellGlyph.BOOK, ShellGlyph.TASBIH, ShellGlyph.KAABA, ShellGlyph.CHECKLIST, ShellGlyph.CALENDAR)
            .forEach { assertNotNull(it.name, sectionArt(it)) }
        // The speakers and the small icons are drawn by hand.
        listOf(ShellGlyph.SPEAKER, ShellGlyph.SPEAKER_OFF, ShellGlyph.TUNE, ShellGlyph.DOTS)
            .forEach { assertNull(it.name, sectionArt(it)) }
    }

    @Test fun theLetterPlusItsWeightIsExactlyTheBoxAtAnySize() {
        // refInk: how tall the letter's ink is at the reference size 100 (the Hafs ع is about 93 high).
        for (refInk in listOf(60f, 93.3f, 140f)) {
            for (box in listOf(16f, 22f, 40f, 88.5f)) {
                val size = AinFit.textSize(box, refInk)
                assertEquals(box, refInk * size / 100f + AinFit.weight(box), 1e-3f)
            }
        }
        // 1.1 dp of weight in the 22 dp box: the stroke of the drawn five.
        assertEquals(1.1f, AinFit.weight(22f), 1e-4f)
    }
}
