package com.nur.prayer

import com.nur.prayer.ui.shell.Minaret
import com.nur.prayer.ui.shell.ShellMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/** 0.33.0 «Минарет»: the roof's curve, measured on the mock (three cubics for the right-hand half). */
class MinaretTest {
    @Test fun theRoofStartsAtItsTipAndEndsOnTheMocksFoot() {
        assertEquals(0f, Minaret.halfWidthAt(0f), 0.01f)
        assertEquals(Minaret.HALF, Minaret.halfWidthAt(Minaret.HEIGHT), 1e-3f)
        assertEquals(ShellMath.ROOF_DP, Minaret.HEIGHT, 0f)
        // The last cubic ends on the foot, within a pixel of the mock (0.36 dp).
        assertEquals(Minaret.HALF, Minaret.RIGHT[Minaret.RIGHT.size - 2], 1e-3f)
        assertEquals(Minaret.HEIGHT, Minaret.RIGHT[Minaret.RIGHT.size - 1], 0.36f)
    }

    @Test fun theJoinsOfTheCubicsAreOnTheCurve() {
        for (i in 0 until Minaret.RIGHT.size / 6) {
            val x = Minaret.RIGHT[i * 6 + 4]
            val y = Minaret.RIGHT[i * 6 + 5]
            assertEquals("join $i", x, Minaret.halfWidthAt(y), 0.02f)
        }
    }

    @Test fun theRoofOnlyWidensDownwardsAndTheFlareIsShallowInTheMiddle() {
        var prev = 0f
        var y = 0f
        while (y <= Minaret.HEIGHT) {
            val w = Minaret.halfWidthAt(y)
            assertTrue("width at $y", w >= prev - 1e-3f)
            prev = w
            y += 0.25f
        }
        // Ogee: the width gained per dp of height is small at the tip (about 1), biggest in the flare through the
        // middle (about 2.3, the shallow slope) and small again at the foot (about 1.4): steep, shallow, steep.
        fun gain(a: Float, b: Float) = (Minaret.halfWidthAt(b) - Minaret.halfWidthAt(a)) / (b - a)
        assertTrue(gain(8f, 16f) > gain(0f, 5f) * 1.5f)
        assertTrue(gain(8f, 16f) > gain(20f, 28f) * 1.3f)
    }

    @Test fun aRowOutsideTheRoofIsRefused() {
        for (bad in listOf(-0.1f, Minaret.HEIGHT + 0.1f)) {
            try {
                Minaret.halfWidthAt(bad)
                fail("accepted $bad")
            } catch (expected: IllegalArgumentException) {
                // the point
            }
        }
    }
}
