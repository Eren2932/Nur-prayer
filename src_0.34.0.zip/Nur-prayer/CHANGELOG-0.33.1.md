# 0.33.1 — исправление сборки 0.33.0

## Что было
CI 0.33.0 упал на компиляции Kotlin (`:app:compileDebugKotlin`, `:app:compileReleaseKotlin`). Ошибка одна:

```
NavCapsule.kt:504:38 Unresolved reference 'drawOutline'.
```

`softShade` (тень под карточкой и лункой) вызывает `drawOutline(outline, color)` внутри `drawBehind`, а импорта
`androidx.compose.ui.graphics.drawOutline` в файле не было. Остальной код 0.33.0 компилятор принял.

## Что сделано
- `NavCapsule.kt`: добавлен импорт `androidx.compose.ui.graphics.drawOutline`.
- `tools/check_extension_imports.py`: кроме вызовов `receiver.name(...)` теперь ищет свободные расширения без получателя
  (`drawOutline`, `drawIntoCanvas`, `withTransform`, `toArgb`, `nativeCanvas`) и требует импорта. Именно такой вызов
  пропустила прошлая версия проверки. На 0.33.0 новая проверка нашла бы эту ошибку; на остальном дереве чистая.
- Версия 0.33.1, versionCode 72. Дизайн, иконки и логика не менялись.

## Что НЕ проверено
Gradle, компиляция Kotlin и юнит-тесты здесь по-прежнему не запускались. В логе 0.33.0 до компиляции тестовых
наборов (`MinaretTest`, `ShellGlyphsTest`, `ShellMathTest`) дело не дошло, так что компилятор их ещё не видел.
Я перечитал их построчно: сигнатуры `assertEquals`, `when` с константами, видимость `internal`.
