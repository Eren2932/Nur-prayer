#!/usr/bin/env python3
"""0.27.0 «Капсула»: a mirror of ShellMath.kt, checked in CI without a JVM.
0.33.0 «Минарет»: the glass is the mock's light cream; the checks that spoke of the old dark glass
(tint over a white wallpaper, 10-18 % hairline) are replaced by the ones that matter for cream and dark ink:
contrast of every text and icon colour, the roof's curve, the section glyphs and the speaker of the cards.

The Kotlin numbers are read from the source, so the mirror cannot silently drift from it.
"""
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SHELL = ROOT / 'app/src/main/java/com/nur/prayer/ui/shell'
SRC = (SHELL / 'ShellState.kt').read_text()
FROST = (SHELL / 'Frost.kt').read_text()
CAPS = (SHELL / 'NavCapsule.kt').read_text()
GLYPHS = (SHELL / 'ShellGlyphs.kt').read_text()
DATA = (SHELL / 'ShellIconData.kt').read_text()
MINARET = (SHELL / 'Minaret.kt').read_text()
SECTION = (ROOT / 'app/src/main/java/com/nur/prayer/ui/home/HomeSection.kt').read_text()


def num(pattern, what, text=SRC, name='ShellState.kt'):
    m = re.search(pattern, text)
    if not m: sys.exit('check_shell: %s not found in %s' % (what, name))
    return float(m.group(1))


CAP_END = num(r'capsuleAlpha\(p: Float\): Float = \(1f - p / ([0-9.]+)f\)', 'capsuleAlpha')
PAN_START = num(r'panelAlpha\(p: Float\): Float = \(\(p - ([0-9.]+)f\)', 'panelAlpha start')
PAN_SPAN = num(r'panelAlpha\(p: Float\): Float = \(\(p - [0-9.]+f\) / ([0-9.]+)f\)', 'panelAlpha span')
OVER = num(r'coerceIn\(0f, ([0-9.]+)f\)', 'clampProgress')
DAMP = num(r'OPEN_DAMPING = ([0-9.]+)f', 'OPEN_DAMPING')
ROOF_DP = num(r'const val ROOF_DP = ([0-9.]+)f', 'ROOF_DP')
ROOF_FROM = num(r'const val ROOF_FROM = ([0-9.]+)f', 'ROOF_FROM')
ROOF_TO = num(r'const val ROOF_TO = ([0-9.]+)f', 'ROOF_TO')

clamp = lambda v: min(max(v, 0.0), 1.0)
cap = lambda p: clamp(1 - p / CAP_END)
pan = lambda p: clamp((p - PAN_START) / PAN_SPAN)

errors = []

# --- the morph -------------------------------------------------------------------------------------------------
# Never two layers of text at once: the capsule is (almost) gone before the panel shows.
worst = max(cap(i / 1000) + pan(i / 1000) for i in range(0, int(OVER * 1000) + 1))
if worst > 1.0001: errors.append('capsule and panel text overlap: %.3f' % worst)
if not (0.2 <= CAP_END <= 0.4): errors.append('capsule text must leave in the first third, got %.2f' % CAP_END)
if not (PAN_START + PAN_SPAN <= 0.9): errors.append('panel text must be fully in before the spring settles')
if not (1.0 < OVER <= 1.05): errors.append('overshoot bound must be small, got %.2f' % OVER)
if not (0.7 <= DAMP < 1.0): errors.append('open spring: a hint of bounce, not a wobble (damping %.2f)' % DAMP)
if not (0.0 <= ROOF_FROM < ROOF_TO <= PAN_START + PAN_SPAN):
    errors.append('the roof must be whole no later than the panel text (from %.2f to %.2f)' % (ROOF_FROM, ROOF_TO))
if not (0.70 <= num(r'const val CAPSULE_SHARE = ([0-9.]+)f', 'CAPSULE_SHARE') <= 0.8): errors.append('capsule width share')


# --- colours: the mock's cream glass, dark-brown ink --------------------------------------------------------------
def colors_of(text, obj):
    m = re.search(r'(?:internal )?object %s \{(.*?)\n\}' % obj, text, re.S)
    if not m: sys.exit('check_shell: object %s not found' % obj)
    out = {}
    for name, v in re.findall(r'val (\w+) = Color\(0x([0-9A-Fa-f]{8})\)', m.group(1)):
        v = int(v, 16)
        out[name] = (((v >> 24) & 255) / 255.0, (v >> 16) & 255, (v >> 8) & 255, v & 255)
    return out


C = colors_of(FROST, 'ShellColors')


def over(fg, bg):
    """Colour fg (alpha, r, g, b) laid over the opaque bg (alpha, r, g, b)."""
    a = fg[0]
    return (1.0,) + tuple(a * fg[i] + (1 - a) * bg[i] for i in (1, 2, 3))


def luma(c):
    def lin(v):
        v /= 255.0
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    return 0.2126 * lin(c[1]) + 0.7152 * lin(c[2]) + 0.0722 * lin(c[3])


def contrast(fg, bg):
    fg = over(fg, bg)
    a, b = luma(fg), luma(bg)
    return (max(a, b) + 0.05) / (min(a, b) + 0.05)


def need(name):
    if name not in C: sys.exit('check_shell: ShellColors.%s not found' % name)
    return C[name]


for name in ('Glass', 'GlassTop', 'Card', 'Well', 'GoldCard', 'Roof'):
    c = need(name)
    if c[0] != 1.0: errors.append('ShellColors.%s must be opaque: the glass is not a picture any more' % name)
    if luma(c) < 0.55: errors.append('ShellColors.%s is not light (luminance %.2f)' % (name, luma(c)))
# (foreground, background, minimum contrast): text 4.5, big text and the ink of icons 3
PAIRS = [
    ('Ink', 'Glass', 7.0), ('Ink', 'Card', 7.0), ('Secondary', 'Glass', 4.5), ('Label', 'Card', 4.5),
    ('Icon', 'Well', 4.5), ('Speaker', 'Card', 3.0), ('SpeakerMuted', 'Card', 3.0),
    ('OnGold', 'GoldCard', 7.0), ('OnGoldSoft', 'GoldCard', 4.5), ('OnGoldMuted', 'GoldCard', 3.0),
]
for fg, bg, floor in PAIRS:
    r = contrast(need(fg), need(bg))
    if r < floor: errors.append('%s on %s: contrast %.2f, needs %.1f' % (fg, bg, r, floor))
# The muted speaker must stay quieter than the live one, or "no call" reads as "call".
if contrast(need('SpeakerMuted'), need('Card')) >= contrast(need('Speaker'), need('Card')):
    errors.append('SpeakerMuted must be quieter than Speaker')
# The gold of "now" is the same gold in the card and in the capsule's disc.
if need('Gold') != need('GoldCard'): errors.append('Gold and GoldCard drifted apart')
# The roof is a hair darker than the glass band under it (#EFDAC9 against #F2E0D2 in the mock), not another material.
r1, r2 = need('Roof'), need('GlassTop')
if max(abs(r1[i] - r2[i]) for i in (1, 2, 3)) > 12: errors.append('Roof must stay within 12 levels of GlassTop')

# --- the glass is flat: no per-frame work while the shape morphs ----------------------------------------------------
if 'shadow(' in FROST or 'clipPath' in FROST or 'elevation' in FROST.replace('elevation shadow', ''):
    errors.append('Frost.kt: no elevation shadow and no path clip: they rebuild every frame while the shape morphs')
if re.search(r'if \((panelComposed|capsuleComposed)\) (CapsuleContent|PanelContent)', CAPS):
    errors.append('NavCapsule.kt: both faces of the capsule stay composed; opening must not compose the panel')
if 'CompositingStrategy.ModulateAlpha' not in CAPS: errors.append('NavCapsule.kt: layers fade per draw call, not in an offscreen buffer')
if 'object SheetGlass' not in FROST: errors.append('Frost.kt: the prayer sheet keeps its dark glass (SheetGlass)')

# --- the roof: the mock's ogee, three cubics, widening downwards ---------------------------------------------------
m = re.search(r'val RIGHT = floatArrayOf\((.*?)\)', MINARET, re.S)
if not m: sys.exit('check_shell: Minaret.RIGHT not found')
R = [float(x) for x in re.findall(r'-?[0-9.]+f?', m.group(1).replace('f', ''))]
if len(R) % 6 or not R: errors.append('Minaret.RIGHT: six numbers per cubic')
HALF = num(r'const val HALF = ([0-9.]+)f', 'Minaret.HALF', MINARET, 'Minaret.kt')
if R:
    if abs(R[-2] - HALF) > 0.01: errors.append('Minaret.RIGHT must end at x = HALF (%.2f vs %.2f)' % (R[-2], HALF))
    if abs(R[-1] - ROOF_DP) > 1.0: errors.append('Minaret.RIGHT must end at the roof height (%.2f vs %.2f)' % (R[-1], ROOF_DP))
    x0 = y0 = 0.0
    for i in range(0, len(R), 6):
        x1, y1, x2, y2, x3, y3 = R[i:i + 6]
        if not (x0 <= x1 <= x3 + 1e-6 and x0 <= x2 <= x3 + 1e-6 and x3 >= x0): errors.append('Minaret.RIGHT: cubic %d does not widen to the right' % (i // 6))
        if not (y0 <= y1 <= y3 + 1e-6 and y0 <= y2 <= y3 + 1e-6 and y3 > y0): errors.append('Minaret.RIGHT: cubic %d does not go down (halfWidthAt bisects y(t))' % (i // 6))
        x0, y0 = x3, y3
if (2 * HALF) / 393.0 > 0.30: errors.append('the roof is wider than a third of the screen')

# --- the glyphs --------------------------------------------------------------------------------------------------
paths = re.findall(r'GlyphLayer\(1\.0f, false, "([^"]*)"\)', DATA)
names = re.findall(r'    val (\w+) = ShellIconArt\(', DATA)
if names != ['QURAN', 'DHIKR', 'QIBLA', 'TODO', 'MONTH'] or len(paths) != 5:
    errors.append('ShellIconData: expected QURAN, DHIKR, QIBLA, TODO, MONTH (the sixth, study, is the letter ع), got %s' % names)
if 'ShellGlyph.AIN' not in SECTION: errors.append('HomeSection.COURSE must wear ShellGlyph.AIN (the letter ع)')
if 'ShellGlyph.CAP' in SECTION + CAPS + GLYPHS or 'STUDY' in GLYPHS + DATA:
    errors.append('the graduation cap is gone: «Учёба» is the letter ع')
if 'ArabicFont.paintTypeface()' not in GLYPHS or 'private const val AIN_TEXT = "\u0639"' not in GLYPHS:
    errors.append('ShellGlyphs.kt: ع is set in the mushaf face (ArabicFont) from U+0639')
# One glyph, one box: the letter is exactly as tall as its box and its weight is a share of it.
w = num(r'object AinFit \{\s*const val WEIGHT = ([0-9.]+)f', 'AinFit.WEIGHT', GLYPHS, 'ShellGlyphs.kt')
if not (0.03 <= w <= 0.08): errors.append('AinFit.WEIGHT %.3f: the letter must carry about the weight of the drawn glyphs' % w)

# --- the speaker of the cards ------------------------------------------------------------------------------------
if 'SPEAKER_OFF' not in GLYPHS or 'SPEAKER_OFF' not in CAPS:
    errors.append('every card wears a speaker; the crossed one stands for «no call» (sunrise, azan off)')
if re.search(r'PRAYERS: List<Prayer> = listOf\(([^)]*)\)', CAPS) is None:
    errors.append('PanelTimes.PRAYERS not found')
else:
    got = re.findall(r'Prayer\.(\w+)', re.search(r'PRAYERS: List<Prayer> = listOf\(([^)]*)\)', CAPS).group(1))
    if got != ['FAJR', 'SUNRISE', 'DHUHR', 'ASR', 'MAGHRIB', 'ISHA']: errors.append('the panel shows the six times in the order of the mock, got %s' % got)
if 'fun callOn(' not in CAPS: errors.append('PanelTimes.callOn: one rule for "this card has a call" (sunrise never has)')

if errors:
    print('\n'.join('check_shell: ' + e for e in errors)); sys.exit(1)
print('check_shell: ok (overlap %.3f, capsule out by %.2f, panel in by %.2f, %d colour pairs)' % (worst, CAP_END, PAN_START + PAN_SPAN, len(PAIRS)))
