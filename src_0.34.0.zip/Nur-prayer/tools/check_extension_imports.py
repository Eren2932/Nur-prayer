#!/usr/bin/env python3
"""0.30.1: a call to an extension function whose import is missing (source preflight, not a compiler).

0.30.0 failed on `constraints.constrainHeight(...)` without `import androidx.compose.ui.unit.constrainHeight`:
member-looking extensions are the one thing kt_symbols and kt_sanity do not see. This lists the extension
functions the project's Compose code is known to use and demands an import of the same name in every
file that calls them as `receiver.name(` (or `receiver.name {`), unless the file declares the name itself.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAMES = (
    # androidx.compose.ui.unit.Constraints
    "constrainWidth", "constrainHeight", "constrain", "isSatisfiedBy",
    # Modifier chains
    "padding", "paddingFromBaseline", "offset", "size", "height", "width", "fillMaxWidth", "fillMaxHeight",
    "fillMaxSize", "wrapContentSize", "aspectRatio", "heightIn", "widthIn", "sizeIn", "defaultMinSize",
    "clip", "background", "border", "clickable", "semantics", "clearAndSetSemantics", "layout", "drawBehind",
    "drawWithContent", "graphicsLayer", "onGloballyPositioned", "shadow", "zIndex", "testTag",
    "horizontalScroll", "verticalScroll", "pointerInput", "draggable",
)
# 0.33.0 failed on `drawOutline(outline, color)` inside a DrawScope without `import androidx.compose.ui.graphics.drawOutline`:
# the call has no receiver in the text, so the pattern above does not see it. These are the free-standing extensions the
# project's drawing code uses (called bare inside a DrawScope, or as `.name` on a canvas/colour).
BARE = (
    "drawOutline", "drawIntoCanvas", "withTransform", "toArgb", "nativeCanvas",
)
BARE_CALL = {n: re.compile(r"(?<![\w.])" + n + r"\s*[({]|\.\s*" + n + r"\b") for n in BARE}

# The receiver is `Modifier`, a lower-case value or the end of a call/index: `TasbihMath.size(…)` is a member.
CALL = {n: re.compile(r"(?:\bModifier|\b[a-z_]\w*|[)\]])\s*\.\s*" + n + r"\s*[({]") for n in NAMES}


def strip(src: str) -> str:
    src = re.sub(r'"""[\s\S]*?"""', '""', src)
    src = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', src)
    src = re.sub(r"/\*[\s\S]*?\*/", " ", src)
    return re.sub(r"//[^\n]*", " ", src)


def main() -> int:
    problems = []
    files = sorted((ROOT / "app/src").rglob("*.kt"))
    for f in files:
        raw = f.read_text(encoding="utf-8")
        code = strip(raw)
        imports = set(re.findall(r"^import\s+([\w.]+)(?:\s+as\s+\w+)?\s*$", raw, re.M))
        wildcard = {i for i in re.findall(r"^import\s+([\w.]+)\.\*\s*$", raw, re.M)}
        body = "\n".join(l for l in code.splitlines() if not l.startswith("import "))
        for name, rx in CALL.items():
            if not rx.search(body):
                continue
            if any(i.rsplit(".", 1)[-1] == name for i in imports):
                continue
            if re.search(r"\bfun\s+(?:[\w.<>?]+\.)?" + name + r"\b", body):
                continue
            if wildcard & {"androidx.compose.foundation.layout", "androidx.compose.foundation", "androidx.compose.ui.unit"}:
                continue
            problems.append(f"{f.relative_to(ROOT)}: .{name}(...) without an import of {name}")
        for name in BARE:
            if not BARE_CALL[name].search(body):
                continue
            if any(i.rsplit(".", 1)[-1] == name for i in imports):
                continue
            if re.search(r"\b(?:fun|val|var)\s+(?:[\w.<>?]+\.)?" + name + r"\b", body):
                continue
            if wildcard & {"androidx.compose.ui.graphics", "androidx.compose.ui.graphics.drawscope"}:
                continue
            problems.append(f"{f.relative_to(ROOT)}: {name} used without an import of {name}")
    for p in problems:
        print(p)
    print(f"check_extension_imports: {len(files)} files, {len(problems)} problems")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
