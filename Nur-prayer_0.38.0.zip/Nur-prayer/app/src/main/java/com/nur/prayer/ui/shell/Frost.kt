package com.nur.prayer.ui.shell

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.isSpecified
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.wallpaper.PAGE_DIM
import com.nur.prayer.ui.wallpaper.Wallpaper
import com.nur.prayer.ui.wallpaper.WallpaperImages
import com.nur.prayer.ui.wallpaper.WallpaperScreen
import com.nur.prayer.ui.wallpaper.drawWallpaperIn

/*
 * 0.27.1: the matte glass of the capsule, the panel, the island and the sheets: re-measured on the mock.
 *
 * 0.27.0 read the mock by eye and got it wrong: a glass at 72–82 % over a *lighter* blurred picture came
 * out grey (#545358 on the Kaaba wallpaper, the mock is #121522), a vertical gradient with a bright top
 * edge and a deep shadow made the capsule look puffed up. The mock is the opposite: almost opaque deep
 * navy, flat, with one even 1 dp hairline and no visible shadow. So now, layer by layer:
 *
 *  1. the wallpaper blurred (WallpaperImages.frost), drawn exactly where the sharp picture is on screen;
 *  2. black over it, [SheetGlass.PICTURE_DIM] at least (more where a page darkens the picture): the glass
 *     is the same dark over a white wallpaper as over a black one;
 *  3. the tint, #12141F → #0F111B at 90 %: a 3-level gradient, not a bulge;
 *  4. a 1 dp hairline of the same 14 % white all the way round;
 *  5. outside: a very faint halo, three flat low-alpha plates (no elevation shadow: its mesh is rebuilt
 *     every frame while the shape morphs and that was a part of the lag).
 *
 * Layers 1–4 are drawn inside the clip of the shape (a rounded rectangle, hardware-clipped), so there is
 * no per-frame Path and no stencil. On «Живое небо» and «Чёрный» there is no picture to blur: the tint
 * alone, nearly opaque.
 */

/*
 * 0.36.0 «Бумага»: the capsule, the island and the panel are paper now. The 0.33.0 cream glass (an opaque #EEDBCC
 * body with a lighter band, a warm rim, brown ink) is gone: the new mock is a flat, cool white, #FAFAFA, with no rim
 * and no band, black ink and grey secondary text; what lifts a card off it is a soft shade, nothing else. Opaque, so
 * the colour is the same over every wallpaper and there is no picture to blur (the light glass does not touch the
 * frost bitmap at all). The capsule body is a hair greyer than the panel (#F8F8F8 against #FAFAFA, measured on the
 * mock); the morph lerps one into the other ([frostGlass]'s `body`). The prayer sheet keeps the old dark glass
 * ([GlassStyle.DARK], [SheetGlass]).
 */

/** Which glass a surface is made of. */
enum class GlassStyle { LIGHT, DARK }

/** What the glass shows through: the wallpaper on screen and how much the current page darkens it. */
@Stable
class FrostSource(val wallpaper: () -> Wallpaper, val dim: () -> Float)

val LocalFrost = staticCompositionLocalOf<FrostSource?> { null }

/**
 * The colours of the 0.36.0 mock, measured from its pixels (576 px = 393 dp): the paper, the shade of a card, the
 * lavender of «now», the greys of the ink. Everything the capsule, the panel, the island and the compass button
 * are drawn with. The colours of the section discs live in [ShellTones].
 */
object ShellColors {
    /** The open panel: #FAFAFA, flat. */
    val Glass = Color(0xFFFAFAFA)
    /**
     * 0.38.0: the round buttons of the bar on home are really transparent: only a faint shade lies inside the ring
     * (black at 8 %), the picture shows through. Home sits on the wallpaper under the page scrim (62 % black), where
     * the white ring and glyph keep their contrast without any help from the veil. The morph lerps it into [Glass].
     */
    val BarGlass = Color(0x14000000)
    /**
     * 0.37.0's firmer veil (black at 45 %, white ink keeps 3:1 even over a white page: #8C8C8C). Inside a section the
     * page under the bar is not the scrimmed wallpaper (the Quran's paper is white), so the buttons wear this one.
     */
    val BarGlassPage = Color(0x73000000)
    /** The ring of a veil button and its ink (0.37.0). */
    val BarRing = Color(0xE6FFFFFF)
    val BarInk = Color(0xFFFFFFFF)
    /** 0.38.0: «Учёба», the pill on the right of the bar: light grey of the mock (#DDDEDC) and near-black ink on it. */
    val PillFill = Color(0xFFDDDEDC)
    val PillInk = Color(0xFF141514)
    /** The light that runs over the pill now and then; its peak alpha is [PillShimmer.PEAK_ALPHA]. */
    val PillGlint = Color(0xFFFFFFFF)
    /** A card has the colour of the panel: only its shade sets it apart (the mock's cards are #FAFAFA too). */
    val Card = Color(0xFFFAFAFA)
    val CardPressed = Color(0xFFEFEFF1)
    /** The shade of a card: black, laid in three flat plates, see [cardShade]. */
    val Shade = Color(0xFF000000)
    /** The lines: the one under the cards (#E1E1E1) and the upright one in the header (#DCDCDC). */
    val Divider = Color(0xFFE1E1E1)
    val Separator = Color(0xFFDCDCDC)
    /** The little arch on the divider. */
    val Ornament = Color(0xFFD6D6D6)
    /** The gear's disc (#EBECEE): a hair darker than the paper, cool. */
    val GearWell = Color(0xFFEBECEE)
    /** Text and icons: black for what is read, greys for what is around it. */
    val Ink = Color(0xFF0A0A0C)
    val DateInk = Color(0xFF343437)
    val Secondary = Color(0xFF5E5E62)
    val Label = Ink
    val Icon = Color(0xFF3F3F44)
    val Speaker = Color(0xFF4B4A50)
    /** The speaker of a time without a call (sunrise, or a prayer whose azan is off): the same grey at 70 %, still 3:1 on the card. */
    val SpeakerMuted = Color(0xB34B4A50)
    /** «Now»: the lavender card (#EAD0FA) and the near-black with a violet breath that is written on it. */
    val NowCard = Color(0xFFEAD0FA)
    val OnNow = Color(0xFF0D0316)
    val OnNowSoft = Color(0xFF42315B)
    val OnNowMuted = Color(0xB342315B)
    /** The small accent dot of the island: the gold of the timeline, which reads on white as well. */
    val Accent = Color(0xFFE0993F)
}

/** The dark glass of the sheets, unchanged since 0.27.1. */
internal object SheetGlass {
    val TintTop = Color(0xFF12141F)
    val TintBottom = Color(0xFF0F111B)
    const val TINT_ALPHA = 0.90f
    const val TINT_PLAIN_ALPHA = 0.96f
    /** Black over the blurred picture before the tint: a light wallpaper must not lift the glass. */
    const val PICTURE_DIM = ShellMath.PICTURE_DIM
    val Edge = Color(0x24FFFFFF)
}

/** One handle per glass surface: the blurred picture and where on screen the surface is. */
@Stable
class FrostHandle internal constructor(internal val source: FrostSource?) {
    internal var bitmap by mutableStateOf<ImageBitmap?>(null)
    internal var wallpaper by mutableStateOf<Wallpaper?>(null)
    internal var originInRoot by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberFrost(): FrostHandle {
    val source = LocalFrost.current
    val handle = remember(source) { FrostHandle(source) }
    val context = LocalContext.current
    val wallpaper = source?.wallpaper?.invoke()
    val screen by WallpaperScreen.size
    LaunchedEffect(handle, wallpaper?.id, screen) {
        handle.wallpaper = wallpaper
        if (wallpaper == null || !wallpaper.isImage) {
            handle.bitmap = null
            return@LaunchedEffect
        }
        handle.bitmap = WallpaperImages.peekFrost(wallpaper, screen.width, screen.height)
            ?: WallpaperImages.frost(context, wallpaper, screen.width, screen.height)
    }
    return handle
}

/**
 * Paints the glass of [shape] behind the content of this element and clips the content to it. Read
 * only while drawing: a panel that changes size every frame redraws, it does not recompose.
 *
 *  - [halo]: the faint plates outside the shape. Off for a sheet that touches the screen edges.
 *  - [track]: the glass follows where it is on screen by itself (onGloballyPositioned). A surface that
 *    is moved by a layer transform (a sheet sliding up) sets it off and sets [FrostHandle.originInRoot] itself.
 *  - [wash]: a colour laid very lightly over the tint (the prayer sheet carries the colour of its sky).
 *  - [body]: the colour of the light glass, read while drawing; it may be translucent (0.37.0: the bar's veil).
 *  - [haloScale]: how much of the halo is drawn, 0..1, read while drawing: a closed veil has none, the panel all of it.
 */
fun Modifier.frostGlass(
    frost: FrostHandle,
    shape: Shape,
    halo: Boolean = true,
    track: Boolean = true,
    edge: Boolean = true,
    wash: Color = Color.Unspecified,
    style: GlassStyle = GlassStyle.LIGHT,
    body: (() -> Color)? = null,
    haloScale: (() -> Float)? = null
): Modifier = this
    .then(
        if (halo) Modifier.glassHalo(shape) { (if (style == GlassStyle.LIGHT) LIGHT_HALO else 1f) * (haloScale?.invoke() ?: 1f) }
        else Modifier
    )
    .then(if (track && style == GlassStyle.DARK) Modifier.onGloballyPositioned { frost.originInRoot = it.positionInRoot() } else Modifier)
    .clip(shape)
    .drawBehind {
        if (style == GlassStyle.LIGHT) {
            // Opaque paper: no picture, no dim, no rim; the colour is read here, in the draw phase, so a morph
            // that changes it every frame redraws and never recomposes.
            drawRect(body?.invoke() ?: ShellColors.Glass)
        } else {
            val bitmap = frost.bitmap
            val wallpaper = frost.wallpaper
            val screen = WallpaperScreen.size.value
            val picture = bitmap != null && wallpaper != null && screen.width > 0 && screen.height > 0
            if (picture) {
                val o = frost.originInRoot
                translate(-o.x, -o.y) {
                    drawWallpaperIn(bitmap!!, wallpaper!!, screen.width.toFloat(), screen.height.toFloat(), FilterQuality.Low)
                }
                drawRect(Color.Black.copy(alpha = ShellMath.pictureDim(frost.source?.dim?.invoke() ?: 0f, PAGE_DIM)))
            }
            val a = if (picture) SheetGlass.TINT_ALPHA else SheetGlass.TINT_PLAIN_ALPHA
            drawRect(Brush.verticalGradient(listOf(SheetGlass.TintTop.copy(alpha = a), SheetGlass.TintBottom.copy(alpha = a))))
            if (wash.isSpecified) drawRect(wash.copy(alpha = WASH_ALPHA))
            if (edge) {
                // Twice the hairline, centred on the outline: the half outside the clip is cut, 1 dp stays.
                drawOutline(
                    shape.createOutline(size, layoutDirection, this),
                    SheetGlass.Edge,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }

private const val WASH_ALPHA = 0.20f

/** The light glass needs less of a halo than the dark one: a white body already reads on any picture. */
private const val LIGHT_HALO = 0.55f

/** Three flat, very faint plates around a rounded shape: enough to lift it off the picture, nothing more. */
private fun Modifier.glassHalo(shape: Shape, strength: () -> Float): Modifier = drawBehind {
    val outline = shape.createOutline(size, layoutDirection, this)
    if (outline !is Outline.Rounded) return@drawBehind
    val k = strength()
    if (k <= 0.001f) return@drawBehind
    val box = outline.roundRect
    val r = box.topLeftCornerRadius.x
    HALO.forEach { plate ->
        val grow = plate.grow.dp.toPx()
        drawRoundRect(
            Color.Black.copy(alpha = plate.alpha * k),
            topLeft = Offset(box.left - grow, box.top - grow + plate.drop.dp.toPx()),
            size = Size(box.width + 2f * grow, box.height + 2f * grow),
            cornerRadius = CornerRadius(r + grow)
        )
    }
}

private class Plate(val grow: Float, val drop: Float, val alpha: Float)

private val HALO = listOf(Plate(2f, 3f, 0.10f), Plate(6f, 6f, 0.06f), Plate(11f, 9f, 0.035f))
