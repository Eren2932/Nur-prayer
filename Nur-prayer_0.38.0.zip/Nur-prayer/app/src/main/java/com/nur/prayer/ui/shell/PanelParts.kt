package com.nur.prayer.ui.shell

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/*
 * 0.36.0 «Бумага»: the two small drawn parts of the paper panel. They replace Minaret.kt, whose roof and header
 * ornament belonged to the cream design (0.33.0) and are gone with it.
 */

/** One flat layer of a card's shade: how far it grows around the card, how far it drops, how dark it is. */
private class ShadePlate(val grow: Float, val drop: Float, val alpha: Float)

/**
 * The mock's shade of a time card, measured on the pixels around it: #EDEDED at the very edge on #FAFAFA (about
 * 5 % black), fading over 6 px at the top and the sides and 9 px at the bottom, so it is cast a little downward.
 * Three flat rounded plates, each a touch wider and fainter than the last, stack to that fall-off: no blur, no
 * per-frame bitmap, nothing the GPU has to think about while the panel is opening. The card is opaque and drawn
 * over them, so only what sticks out shows.
 */
private val CARD_SHADE = listOf(
    ShadePlate(0.8f, 0.4f, 0.020f),
    ShadePlate(2.4f, 0.6f, 0.016f),
    ShadePlate(4.2f, 0.9f, 0.014f)
)

internal fun Modifier.cardShade(corner: Dp): Modifier = drawBehind {
    val r = corner.toPx()
    for (p in CARD_SHADE) {
        val g = p.grow.dp.toPx()
        drawRoundRect(
            color = ShellColors.Shade.copy(alpha = p.alpha),
            topLeft = Offset(-g, -g + p.drop.dp.toPx()),
            size = Size(size.width + 2f * g, size.height + 2f * g),
            cornerRadius = CornerRadius(r + g)
        )
    }
}

/**
 * The line between the times and the sections: 1 dp, #E1E1E1, 43.6 dp short of the panel's edges (the mock: the line
 * runs from x = 96 px to 480 px on a panel 32 px to 543 px wide), broken by 22 dp around a small arch that stands on
 * it, about 10 dp wide and 4 dp high. The line is [LINE_Y] dp from the top of the box.
 */
@Composable
internal fun PanelDivider(modifier: Modifier = Modifier) {
    Canvas(modifier.height(DIVIDER_HEIGHT.dp)) {
        val d = density
        val cx = size.width / 2f
        val y = LINE_Y * d
        val inset = 43.6f * d
        val gap = 11f * d
        val w = 1f * d
        drawLine(ShellColors.Divider, Offset(inset, y), Offset(cx - gap, y), strokeWidth = w)
        drawLine(ShellColors.Divider, Offset(cx + gap, y), Offset(size.width - inset, y), strokeWidth = w)
        val hw = 4.8f * d
        val h = 4.1f * d
        val arch = Path().apply {
            moveTo(cx - hw, y)
            cubicTo(cx - hw * 0.55f, y - h * 0.15f, cx - hw * 0.22f, y - h, cx, y - h)
            cubicTo(cx + hw * 0.22f, y - h, cx + hw * 0.55f, y - h * 0.15f, cx + hw, y)
        }
        drawPath(arch, ShellColors.Ornament, style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Height of the divider's box and where its line runs in it (dp). */
internal const val DIVIDER_HEIGHT = 8f
private const val LINE_Y = 7.4f
