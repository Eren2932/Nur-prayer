package com.nur.prayer

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.ui.home.HomeSection
import com.nur.prayer.ui.shell.PanelTimes
import com.nur.prayer.ui.shell.ShellMath
import com.nur.prayer.ui.shell.ShellRoutes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.27.0 «Капсула»: the arithmetic of the morph and which page shows the capsule and the island. */
class ShellMathTest {
    @Test fun capsuleContentLeavesBeforeThePanelArrives() {
        assertEquals(1f, ShellMath.capsuleAlpha(0f), 0f)
        assertEquals(0f, ShellMath.capsuleAlpha(0.3f), 1e-6f)
        assertEquals(0f, ShellMath.panelAlpha(0.28f), 1e-6f)
        assertEquals(1f, ShellMath.panelAlpha(0.8f), 1e-6f)
        // Never both at full strength: no frame shows two layers of text on top of each other.
        var p = 0f
        while (p <= 1.03f) {
            assertTrue(ShellMath.capsuleAlpha(p) + ShellMath.panelAlpha(p) <= 1.0001f)
            p += 0.01f
        }
    }

    @Test fun springOvershootIsBounded() {
        assertEquals(1.03f, ShellMath.clampProgress(1.4f), 0f)
        assertEquals(0f, ShellMath.clampProgress(-0.2f), 0f)
    }

    /** 0.37.0: the glass of the bar is a veil at first and the panel's paper by [ShellMath.FILL_DONE_AT] of the way. */
    @Test fun theVeilBecomesPaperBeforeThePanelsContentHasAnyWeight() {
        assertEquals(0f, ShellMath.fillProgress(0f), 0f)
        assertEquals(0.5f, ShellMath.fillProgress(ShellMath.FILL_DONE_AT / 2f), 1e-6f)
        assertEquals(1f, ShellMath.fillProgress(ShellMath.FILL_DONE_AT), 1e-6f)
        assertEquals(1f, ShellMath.fillProgress(1.03f), 0f)
        // Where the panel's text starts to arrive the glass is already four fifths paper.
        assertEquals(0f, ShellMath.panelAlpha(0.28f), 1e-6f)
        assertTrue(ShellMath.fillProgress(0.28f) >= 0.79f)
    }

    @Test fun clockLiftsOnlyAsFarAsNeededAndNeverIntoTheHeader() {
        // Fits already: no lift.
        assertEquals(0f, ShellMath.clockLift(300f, 500f, 900f, 20f, 100f), 0f)
        // Overlaps by 120 (bottom 800, panel top 700 - gap 20 = 680).
        assertEquals(120f, ShellMath.clockLift(400f, 800f, 700f, 20f, 100f), 0f)
        // Would need 500 but only 300 of room under the header.
        assertEquals(300f, ShellMath.clockLift(400f, 1200f, 700f, 20f, 100f), 0f)
        // Panel not measured yet.
        assertEquals(0f, ShellMath.clockLift(400f, 800f, Float.NaN, 20f, 100f), 0f)
    }

    @Test fun everyGridSectionOpensAPageAndThatPageNamesItsSection() {
        HomeSection.GRID.forEach { section ->
            val route = ShellRoutes.routeOf(section)!!
            assertEquals(section, ShellRoutes.sectionOf(route))
            // The calendar is the one section that gives the bottom edge to its cards (0.29.0).
            assertEquals(section != HomeSection.SCHEDULE, ShellRoutes.capsuleOn(route))
        }
        assertNull(ShellRoutes.routeOf(HomeSection.SETTINGS))
        assertEquals(
            listOf(HomeSection.DHIKR, HomeSection.QIBLA, HomeSection.TODAY, HomeSection.SCHEDULE),
            HomeSection.GRID
        )
    }

    /** 0.37.0: the Quran left the panel for the bar's left button; its page still names its section. */
    @Test fun theQuranIsNotInThePanelButItsPageStillNamesItsSection() {
        assertFalse(HomeSection.QURAN in HomeSection.GRID)
        val route = ShellRoutes.routeOf(HomeSection.QURAN)!!
        assertEquals(HomeSection.QURAN, ShellRoutes.sectionOf(route))
    }

    /** 0.38.0: «Учёба» left the panel for the bar's pill; its page still names its section and keeps the capsule. */
    @Test fun theCourseIsNotInThePanelButItsPagesStillNameItsSection() {
        assertFalse(HomeSection.COURSE in HomeSection.GRID)
        val route = ShellRoutes.routeOf(HomeSection.COURSE)!!
        assertEquals(HomeSection.COURSE, ShellRoutes.sectionOf(route))
        assertTrue(ShellRoutes.capsuleOn(route))
    }

    @Test fun capsuleAndIslandPlacement() {
        assertTrue(ShellRoutes.capsuleOn("home"))
        assertFalse(ShellRoutes.islandOn("home"))
        assertTrue(ShellRoutes.islandOn("qibla"))
        // Paper pages keep the capsule but not the island over their own header.
        assertTrue(ShellRoutes.capsuleOn("quran"))
        assertFalse(ShellRoutes.islandOn("quran"))
        // 0.29.0: the calendar keeps the island (it is the way home) and gives the capsule's place to its cards.
        assertTrue(ShellRoutes.islandOn("schedule"))
        assertFalse(ShellRoutes.capsuleOn("schedule"))
        // Pages with their own way out: neither.
        listOf("settings", "city", "lesson", "story").forEach {
            assertFalse(ShellRoutes.capsuleOn(it))
            assertFalse(ShellRoutes.islandOn(it))
        }
    }

    /** 0.27.1: the glass is as dark over a white picture as over a black one. */
    @Test fun glassPictureDimNeverDropsBelowTheFloor() {
        assertEquals(ShellMath.PICTURE_DIM, ShellMath.pictureDim(0f, 0.62f), 0f)
        // A page that darkens more than the floor wins; one that darkens less does not lift the glass.
        assertEquals(0.62f, ShellMath.pictureDim(1f, 0.62f), 1e-6f)
        assertEquals(ShellMath.PICTURE_DIM, ShellMath.pictureDim(0.4f, 0.62f), 0f)
        assertEquals(ShellMath.PICTURE_DIM, ShellMath.pictureDim(-3f, 0.62f), 0f)
        assertEquals(0.62f, ShellMath.pictureDim(7f, 0.62f), 1e-6f)
    }

    @Test fun aPageCanSendTheCapsuleAway() {
        assertTrue(ShellMath.capsuleVisible(true, false))
        assertFalse(ShellMath.capsuleVisible(true, true))
        assertFalse(ShellMath.capsuleVisible(false, false))
    }

    /** The reader's chrome: tap/top/page turn bring it, reading on, a selection or a sheet take it away. */
    @Test fun readerChromeFollowsTheTapAndYieldsTheBottomEdge() {
        assertTrue(ShellMath.readerChrome(chromeShown = true, ayahSelected = false, sheetOpen = false))
        assertFalse(ShellMath.readerChrome(chromeShown = false, ayahSelected = false, sheetOpen = false))
        assertFalse(ShellMath.readerChrome(chromeShown = true, ayahSelected = true, sheetOpen = false))
        assertFalse(ShellMath.readerChrome(chromeShown = true, ayahSelected = false, sheetOpen = true))
    }

    @Test fun closeSpringNeverBounces() {
        assertEquals(1f, ShellMath.CLOSE_DAMPING, 0f)
        assertTrue(ShellMath.OPEN_DAMPING in 0.7f..1f)
    }

    /** 0.30.2: the opening spring overshoots by far less than the layout's headroom (clampProgress), so the glass never grows past the panel. */
    @Test fun openSpringOvershootsLessThanTheHeadroom() {
        val z = ShellMath.OPEN_DAMPING.toDouble()
        val overshoot = kotlin.math.exp(-Math.PI * z / kotlin.math.sqrt(1.0 - z * z))
        assertTrue("overshoot $overshoot", overshoot < 0.005)
        assertTrue(1f + overshoot.toFloat() < ShellMath.clampProgress(1.4f))
        assertTrue(ShellMath.CLOSE_STIFFNESS >= ShellMath.OPEN_STIFFNESS)
    }

    /** 0.30.2: width first, height after; the pill narrows last on the way back. */
    @Test fun widthArrivesBeforeHeight() {
        assertEquals(0f, ShellMath.widthProgress(0f), 0f)
        assertEquals(1f, ShellMath.widthProgress(ShellMath.WIDTH_DONE_AT), 1e-6f)
        assertEquals(1f, ShellMath.widthProgress(1.03f), 0f)
        assertEquals(0f, ShellMath.widthProgress(-0.1f), 0f)
        for (i in 0..100) {
            val p = i / 100f
            assertTrue(ShellMath.widthProgress(p) >= p - 1e-6f)
        }
    }

    /** 0.33.0: every card wears a speaker; this decides which one. Sunrise has no call, whatever the settings hold. */
    @Test fun aCardHasACallOnlyForAPrayerWhoseAzanIsOn() {
        val on = Prayer.entries.associateWith { true }
        val off = Prayer.entries.associateWith { false }
        assertEquals(6, PanelTimes.PRAYERS.size)
        assertEquals(Prayer.SUNRISE, PanelTimes.PRAYERS[1])
        assertFalse(PanelTimes.callOn(Prayer.SUNRISE, on))
        assertFalse(PanelTimes.callOn(Prayer.SUNRISE, off))
        assertFalse(PanelTimes.callOn(Prayer.SUNRISE, emptyMap()))
        listOf(Prayer.FAJR, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA).forEach {
            assertTrue(PanelTimes.callOn(it, on))
            assertFalse(PanelTimes.callOn(it, off))
            // No entry at all is no call, not a crash.
            assertFalse(PanelTimes.callOn(it, emptyMap()))
        }
        assertTrue(PanelTimes.callOn(Prayer.ISHA, mapOf(Prayer.ISHA to true)))
    }
}
