package com.nur.prayer.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.City
import com.nur.prayer.ui.components.LocalBackdropPaused
import com.nur.prayer.ui.components.SkyBackdrop
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.settings.SettingsScreen
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.animatedPhasePalette
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime

/**
 * 0.6.0 shell: no dock. Home is the root and owns the whole screen; Календарь, Кыбла and Настройки
 * open over it from the right and close back to it, Город opens one level deeper from wherever it
 * was called. The sky is drawn once, behind every route, so a transition never flashes black.
 */
@Composable
fun NurRoot(
    data: PrayerData?, now: State<ZonedDateTime>, locating: Boolean, locationStatus: String?,
    exactAlarmsAllowed: Boolean, notificationsAllowed: Boolean, citySearch: suspend (String) -> List<City>, onPickCity: (City) -> Unit,
    actionsFactory: (openCityPicker: () -> Unit) -> AppActions,
    locationButtonLabel: String = "Определить местоположение"
) {
    val nav = rememberSaveable(saver = NurNavigator.Saver) { NurNavigator() }
    val pages = rememberSaveableStateHolder()
    val backdropPaused = remember { mutableStateOf(false) }
    BackHandler(nav.canGoBack) { nav.back() }
    val targetPalette = remember(data?.window?.current) { paletteFor(data?.window?.current ?: Prayer.ISHA) }
    val palette = animatedPhasePalette(targetPalette)
    val actions = remember(nav) { actionsFactory { nav.go(ROUTE_CITY) } }
    // Without a dock, the bottom inset of scrolling screens is just the system bar plus air.
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    CompositionLocalProvider(LocalDockInset provides (bottom + 28.dp), LocalBackdropPaused provides backdropPaused) {
        Box(Modifier.fillMaxSize()) {
            SkyBackdrop(
                palette,
                sky = data?.settings?.skyBackdrop ?: true,
                motionEnabled = data?.settings?.ambientBackdrop == true
            )
            Box(Modifier.fillMaxSize().statusBarsPadding()) {
                AnimatedContent(
                    targetState = nav.current,
                    transitionSpec = {
                        val deeper = routeDepth(targetState) > routeDepth(initialState)
                        val shallower = routeDepth(targetState) < routeDepth(initialState)
                        val enter = when {
                            deeper -> slideInHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS, easing = FastOutSlowInEasing)) { it } +
                                fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS))
                            shallower -> fadeIn(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) +
                                slideInHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) { -it / 10 }
                            else -> fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS))
                        }
                        val exit = when {
                            shallower -> slideOutHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS, easing = FastOutLinearInEasing)) { it } +
                                fadeOut(tween(NavigationMotion.DETAIL_EXIT_MILLIS))
                            deeper -> fadeOut(tween(NavigationMotion.EXIT_MILLIS)) +
                                slideOutHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS)) { -it / 10 }
                            else -> fadeOut(tween(NavigationMotion.EXIT_MILLIS))
                        }
                        (enter togetherWith exit).apply { targetContentZIndex = if (shallower) -1f else 1f }.using(null)
                    }, label = "nurRoute", modifier = Modifier.fillMaxSize()
                ) { route ->
                    pages.SaveableStateProvider(route) {
                        if (data == null) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Считаем солнце…", color = TextSecondary)
                            }
                        } else when (route) {
                            ROUTE_CITY -> CityPickerScreen(palette, data.settings.cityId, citySearch,
                                onPick = { city -> onPickCity(city); nav.back() }, onBack = { nav.back() },
                                onUseLocation = actions.requestLocation, locating = locating, locationStatus = locationStatus,
                                currentPlace = data.place, locationButtonLabel = locationButtonLabel,
                                onOpenLocationPermissions = actions.openLocationPermissions)
                            TAB_SETTINGS -> SettingsScreen(data, palette, actions, exactAlarmsAllowed, locating, locationStatus,
                                notificationsAllowed = notificationsAllowed, locationButtonLabel = locationButtonLabel,
                                onBack = { nav.back() })
                            TAB_SCHEDULE -> ScheduleScreen(data, now, palette, onBack = { nav.back() })
                            TAB_QIBLA -> QiblaScreen(data, palette, onBack = { nav.back() })
                            else -> HomeScreen(
                                data = data, now = now, palette = palette, actions = actions,
                                notificationsAllowed = notificationsAllowed, exactAlarmsAllowed = exactAlarmsAllowed,
                                onOpenCity = { nav.go(ROUTE_CITY) },
                                onOpenSchedule = { nav.go(TAB_SCHEDULE) },
                                onOpenQibla = { nav.go(TAB_QIBLA) },
                                onOpenSettings = { nav.go(TAB_SETTINGS) }
                            )
                        }
                    }
                }
            }
            // A light scrim under the system navigation bar: three-button navigation draws white
            // glyphs, and the horizon of a noon or sunset sky is light enough to swallow them.
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .windowInsetsBottomHeight(WindowInsets.navigationBars)
                    .background(Brush.verticalGradient(listOf(Color(0x14000000), Color(0x59000000))))
            )
        }
    }
}

/** Home 0, the three sections 1, the city picker 2: deeper slides in from the right. */
internal fun routeDepth(route: String): Int = when (route) {
    TAB_HOME -> 0
    ROUTE_CITY -> 2
    else -> 1
}
