package com.nur.prayer.ui.settings

import com.nur.prayer.ui.components.ScreenHeader
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Calibration
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.RegionalProfiles
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.core.astro.TimeSource
import com.nur.prayer.notify.AzanSound
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.NavigationMotion
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.Caption
import com.nur.prayer.ui.components.ChoiceRow
import com.nur.prayer.ui.components.FactRow
import com.nur.prayer.ui.components.HairRule
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.PanelLevel
import com.nur.prayer.ui.components.SectionLabel
import com.nur.prayer.ui.components.SegmentedControl
import com.nur.prayer.ui.components.StepperField
import com.nur.prayer.ui.components.SwitchRow
import com.nur.prayer.ui.components.nurPanel
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/** Atlas settings: a categorized index with current values, then one focused editor.
 * All calculation/notification controls remain available; root and editor scroll are saved separately. */
@Composable
fun SettingsScreen(
    data: PrayerData,
    palette: PhasePalette,
    actions: AppActions,
    exactAlarmsAllowed: Boolean,
    locating: Boolean = false,
    locationStatus: String? = null,
    notificationsAllowed: Boolean = true,
    modifier: Modifier = Modifier,
    locationButtonLabel: String = "Определить местоположение",
    onBack: (() -> Unit)? = null
) {
    val ui = uiScale()
    val dockInset = LocalDockInset.current
    val settings = data.settings
    val accent = palette.accent
    val effectiveMethod = data.params.method

    // Survives rotation and process death, so coming back to the app does not silently collapse the
    // group the user was working in.
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    val pages = rememberSaveableStateHolder()
    BackHandler(enabled = open != null) { open = null }

    // Leaving the screen must never leave the adhan playing: the preview is the one place in the app
    // where sound starts without a prayer time behind it.
    val editingAzan = open == "azan"
    DisposableEffect(editingAzan) { onDispose { if (editingAzan) actions.stopAzan() } }

        val specs = buildList<SettingsTile> {
            run {
                val countryDefault = RegionalProfiles.forCountry(data.place.country)
                add(
                    SettingsTile(
                        id = "method",
                        title = "Метод расчёта",
                        value = if (settings.methodIsAutomatic) {
                                "Автоматически · ${effectiveMethod.title}"
                            } else {
                                "Вручную · ${effectiveMethod.title}"
                            },
                        icon = Icons.Filled.Build
                    ) {
                        Column {
                            ChoiceRow(
                                title = "Автоматически по стране",
                                subtitle = "${data.place.country} → ${countryDefault.method.title}",
                                selected = settings.methodIsAutomatic,
                                accent = accent,
                                onClick = { actions.setMethod(null) }
                            )
                            HairRule()
                            /*
                             * Only the methods that mean something here, plus whatever the user has already
                             * chosen by hand — a selected row must never disappear from the list it lives in.
                             * `remember` keys on the country so this is computed on a city change, not on
                             * every recomposition of a screen that also carries a one-second clock.
                             */
                            val methods = remember(
                                data.place.country,
                                effectiveMethod,
                                settings.methodIsAutomatic
                            ) {
                                val offered = RegionalProfiles.methodsFor(data.place.country)
                                if (settings.methodIsAutomatic || effectiveMethod in offered) {
                                    offered
                                } else {
                                    offered + effectiveMethod
                                }
                            }
                            methods.forEach { method ->
                                ChoiceRow(
                                    title = method.title,
                                    subtitle = subtitleFor(method),
                                    selected = !settings.methodIsAutomatic && effectiveMethod == method,
                                    accent = accent,
                                    onClick = { actions.setMethod(method) }
                                )
                            }
                            HairRule()
                            Caption(calibrationLine(data), color = TextSecondary)
                            Spacer(Modifier.height(ui.s(6f)))
                            Caption(
                                "В списке — методы, которые действительно применяются в стране выбранного " +
                                    "города (${data.place.country}), и международные наборы углов. " +
                                    "Печатные календари других стран не показываются: они совпадают со " +
                                    "своей страной и расходятся на минуты с любой другой."
                            )
                            Spacer(Modifier.height(ui.s(6f)))
                            Caption(
                                "Метод — это углы солнца и правила печати местного муфтията, а не подпись: " +
                                    "переключатель меняет арифметику, поэтому углы указаны у каждой строки. " +
                                    "Ручной выбор остаётся ручным и не становится новым правилом для " +
                                    "остальных стран."
                            )
                        }
                    }
                )
            }
            run {
                add(
                    SettingsTile(
                        id = "madhab",
                        title = "Мазхаб · время Асра",
                        value = if (settings.madhab == Madhab.HANAFI) "Ханафитский" else "Шафиитский",
                        icon = Icons.Filled.Star
                    ) {
                        Column {
                            SegmentedControl(
                                options = listOf("Ханафитский", "Шафиитский"),
                                selectedIndex = if (settings.madhab == Madhab.HANAFI) 0 else 1,
                                accent = accent,
                                onSelect = { index ->
                                    actions.setMadhab(if (index == 0) Madhab.HANAFI else Madhab.STANDARD)
                                }
                            )
                            Spacer(Modifier.height(ui.s(10f)))
                            Caption(
                                "Ханафитский Аср наступает позже: тень предмета должна вырасти до двух его " +
                                    "высот вместо одной."
                            )
                        }
                    }
                )
            }
            run {
                val on = Prayer.entries.count { it.isPrayer && settings.notifications[it] == true }
                val total = Prayer.entries.count { it.isPrayer }
                val lead = if (settings.preAlertMinutes > 0) " · за ${settings.preAlertMinutes} мин" else ""
                add(
                    SettingsTile(
                        id = "notify",
                        title = "Уведомления",
                        value = when {
                            !notificationsAllowed -> "Выключены в Android"
                            !exactAlarmsAllowed -> "$on из $total$lead · нет точных будильников"
                            else -> "$on из $total$lead"
                        },
                        icon = Icons.Filled.Notifications
                    ) {
                        Column {
                            if (!notificationsAllowed) {
                                WarningBlock(
                                    text = "Уведомления запрещены в Android. Переключатели ниже сохраняют ваши предпочтения, " +
                                        "но не могут выдать системное разрешение.",
                                    actionText = "Открыть настройки уведомлений",
                                    onClick = actions.openNotificationSettings
                                )
                                Spacer(Modifier.height(ui.s(12f)))
                            }
                            if (!exactAlarmsAllowed) {
                                WarningBlock(
                                    text = "Android запрещает приложению точные будильники. Без этого " +
                                        "разрешения уведомление может опоздать на несколько минут.",
                                    actionText = "Разрешить точные будильники",
                                    onClick = { actions.openExactAlarmSettings() }
                                )
                                Spacer(Modifier.height(ui.s(12f)))
                            }
                            Prayer.entries.filter { it.isPrayer }.forEach { prayer ->
                                SwitchRow(
                                    title = PrayerLabels.title(prayer),
                                    subtitle = PrayerLabels.hint(prayer),
                                    checked = settings.notifications[prayer] == true,
                                    accent = accent,
                                    onCheckedChange = { actions.setNotification(prayer, it) }
                                )
                            }
                            HairRule()
                            StepperField(
                                label = "Напомнить заранее",
                                value = "${settings.preAlertMinutes} мин",
                                accent = accent,
                                onMinus = { actions.setPreAlert(settings.preAlertMinutes - 5) },
                                onPlus = { actions.setPreAlert(settings.preAlertMinutes + 5) }
                            )
                            Spacer(Modifier.height(ui.s(10f)))
                            NurButton(
                                text = "Отключить экономию батареи для Nur",
                                accent = accent,
                                onClick = { actions.openBatterySettings() }
                            )
                            Spacer(Modifier.height(ui.s(8f)))
                            Caption(
                                "Xiaomi, Huawei, Samsung и Oppo выгружают фоновые процессы: разрешите " +
                                    "автозапуск и снимите ограничения батареи, иначе система задержит любое " +
                                    "уведомление."
                            )
                        }
                    }
                )
            }
            run {
                add(
                    SettingsTile(
                        id = "azan",
                        title = "Звук азана",
                        value = settings.azanSound.title,
                        icon = Icons.Filled.PlayArrow
                    ) {
                        Column {
                            AzanSound.entries.forEach { sound ->
                                ChoiceRow(
                                    title = sound.title,
                                    subtitle = sound.explanation,
                                    selected = settings.azanSound == sound,
                                    accent = accent,
                                    onClick = {
                                        actions.setAzanSound(sound)
                                        // Choosing is the only moment the choice can be judged, and the
                                        // alternative is judging it at four in the morning.
                                        if (sound.playsAzan) actions.previewAzan(sound) else actions.stopAzan()
                                    }
                                )
                            }
                            HairRule()
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.weight(1f)) {
                                    NurButton(
                                        text = "Прослушать",
                                        accent = accent,
                                        onClick = { actions.previewAzan(settings.azanSound) },
                                        enabled = settings.azanSound.playsAzan
                                    )
                                }
                                Spacer(Modifier.width(ui.s(10f)))
                                Box(Modifier.weight(1f)) {
                                    NurButton(
                                        text = "Остановить",
                                        accent = accent,
                                        onClick = { actions.stopAzan() }
                                    )
                                }
                            }
                            Spacer(Modifier.height(ui.s(8f)))
                            Caption(
                                "Запись — азан Мохаммада Башира, встроена в приложение: интернет для звука " +
                                    "не нужен. Играет на будильничном канале и забирает аудиофокус, поэтому " +
                                    "музыка ставится на паузу, а не мешается. В беззвучном режиме телефона " +
                                    "азан молчит, уведомление всё равно приходит."
                            )
                        }
                    }
                )
            }
            run {
                add(
                    SettingsTile(
                        id = "highlat",
                        title = "Высокие широты",
                        value = ruleTitle(settings.highLatitudeRule),
                        icon = Icons.Filled.Warning
                    ) {
                        Column {
                            HighLatitudeRule.entries.forEach { rule ->
                                ChoiceRow(
                                    title = ruleTitle(rule),
                                    subtitle = ruleSubtitle(rule),
                                    selected = settings.highLatitudeRule == rule,
                                    accent = accent,
                                    onClick = { actions.setHighLatitudeRule(rule) }
                                )
                            }
                            HairRule()
                            Caption(
                                "Правило из этого списка — запасной вариант, а не потолок: оно включается " +
                                    "только в те дни, когда солнце физически не доходит до угла метода."
                            )
                        }
                    }
                )
            }
            run {
                add(
                    SettingsTile(
                        id = "rounding",
                        title = "Округление секунд",
                        value = settings.rounding.title,
                        icon = Icons.Filled.Refresh
                    ) {
                        Column {
                            SegmentedControl(
                                options = listOf("Ближайшая", "Вверх", "Вниз"),
                                selectedIndex = RoundingMode.entries.indexOf(settings.rounding),
                                accent = accent,
                                onSelect = { index -> actions.setRounding(RoundingMode.entries[index]) }
                            )
                            Spacer(Modifier.height(ui.s(10f)))
                            Caption(settings.rounding.explanation, color = TextSecondary)
                            Spacer(Modifier.height(ui.s(6f)))
                            Caption(
                                "Расхождение в одну минуту между двумя приложениями в одном городе почти " +
                                    "всегда именно это: секунды упали по разные стороны границы минуты."
                            )
                        }
                    }
                )
            }
            run {
                val edited = Prayer.entries.filter { (settings.offsets[it] ?: 0) != 0 }
                add(
                    SettingsTile(
                        id = "offsets",
                        title = "Ручная коррекция",
                        value = when {
                                edited.isEmpty() && settings.hijriOffset == 0 -> "без правок"
                                edited.isEmpty() -> "хиджра ${signed(settings.hijriOffset)} дн."
                                else -> edited.joinToString(", ") {
                                    "${PrayerLabels.title(it)} ${signed(settings.offsets[it] ?: 0)}"
                                }
                            },
                        icon = Icons.Filled.Edit
                    ) {
                        Column {
                            Prayer.entries.forEach { prayer ->
                                val value = settings.offsets[prayer] ?: 0
                                StepperField(
                                    label = PrayerLabels.title(prayer),
                                    value = "${signed(value)} мин",
                                    accent = accent,
                                    onMinus = { actions.setOffset(prayer, value - 1) },
                                    onPlus = { actions.setOffset(prayer, value + 1) }
                                )
                            }
                            HairRule()
                            StepperField(
                                label = "Сдвиг даты по хиджре",
                                value = "${signed(settings.hijriOffset)} дн.",
                                accent = accent,
                                onMinus = { actions.setHijriOffset(settings.hijriOffset - 1) },
                                onPlus = { actions.setHijriOffset(settings.hijriOffset + 1) }
                            )
                            Spacer(Modifier.height(ui.s(8f)))
                            Caption(
                                "Сверьте расписание со своей мечетью и выровняйте разницу здесь: коррекция " +
                                    "применяется и к уведомлениям. Если время уже совпадает с местным " +
                                    "календарём, держите здесь нули — профиль страны делает эту работу сам."
                            )
                        }
                    }
                )
            }
            run {
                add(
                    SettingsTile(
                        id = "display",
                        title = "Экран",
                        value = buildString {
                            append(if (settings.skyBackdrop) "Небо по времени намаза" else "Чёрный AMOLED")
                            if (settings.ambientBackdrop) append(" · звёзды")
                        },
                        icon = Icons.Filled.Star
                    ) {
                        Column {
                            SwitchRow(
                                title = "Цвет неба",
                                subtitle = "Фон повторяет небо текущего намаза: синий полдень, розовый Аср, " +
                                    "ночь Иша. Выключите, чтобы вернуть чистый чёрный фон.",
                                checked = settings.skyBackdrop,
                                accent = accent,
                                onCheckedChange = { actions.setSkyBackdrop(it) }
                            )
                            HairRule()
                            SwitchRow(
                                title = "Звёзды ночью",
                                subtitle = "Мерцание на небе Сухура, Фаджра, Магриба и Иши. Замирает при прокрутке, " +
                                    "в режиме энергосбережения и при выключенной анимации Android.",
                                checked = settings.ambientBackdrop,
                                accent = accent,
                                onCheckedChange = { actions.setAmbientBackdrop(it) }
                            )
                            HairRule()
                            Caption(
                                "Небо меняется только на границе намаза и плавно перетекает за полторы секунды; " +
                                    "всё остальное время фон статичен и не тратит кадры. Чёрный режим выключает " +
                                    "пиксели AMOLED целиком — это самый экономный вариант."
                            )
                        }
                    }
                )
            }
            run {
                add(
                    SettingsTile(
                        id = "about",
                        title = "О расчёте",
                        value = "${effectiveMethod.angleSummary} · ${data.place.zone.id}",
                        icon = Icons.Filled.Info
                    ) {
                        Column {
                            FactRow("Страна профиля", data.place.country)
                            FactRow("Метод", effectiveMethod.title)
                            FactRow("Углы метода", effectiveMethod.angleSummary)
                            FactRow("Сверка", data.profile.calibration.label)
                            FactRow(
                                "Координаты",
                                format(data.place.coordinates.latitude) + ", " +
                                    format(data.place.coordinates.longitude)
                            )
                            FactRow("Часовой пояс", data.place.zone.id)
                            FactRow("Пояс определён", zoneSourceLabel(data.place.zoneSource))
                            data.place.accuracyMeters?.let { FactRow("Точность точки", "±${it.toInt()} м") }
                            if (data.place.fromDeviceLocation) {
                                settings.locationAddress?.let { FactRow("Адрес точки", it) }
                                settings.locationPostalCode?.let { FactRow("Почтовый индекс", it) }
                            }
                            FactRow("Азимут кыблы", "${Math.round(data.qibla)}°")
                            FactRow("Сухур сегодня", sourceLabel(data.today.saharSource))
                            FactRow("Фаджр сегодня", sourceLabel(data.today.fajrSource))
                            FactRow("Иша сегодня", sourceLabel(data.today.ishaSource))
                            HairRule()
                            Caption(data.profile.note, color = TextSecondary)
                            data.place.zoneExplanation.takeIf { it.isNotEmpty() }?.let {
                                HairRule()
                                Caption(it, color = TextSecondary)
                            }
                            data.today.note?.let {
                                HairRule()
                                Caption(it, color = TextSecondary)
                            }
                            HairRule()
                            Caption(
                                "Алгоритм: астрономические формулы Жана Мееса (Astronomical Algorithms, 2-е " +
                                    "изд.), точность солнечных событий — единицы секунд. Каждое пересечение " +
                                    "проверяется по высоте солнца и по смене знака остатка, поэтому касание " +
                                    "угла в белую ночь не выдаётся за наступление времени, а существующее " +
                                    "время не теряется на плоском дне летней ночи. Нур 0.6.0"
                            )
                        }
                    }
                )
            }
        }

    AnimatedContent(targetState = open ?: "index", transitionSpec = {
        val opening = targetState != "index"
        val enter = if (opening) slideInHorizontally(tween(NavigationMotion.EDITOR_ENTER_MILLIS, easing = FastOutSlowInEasing)) { it }
            else fadeIn(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) + slideInHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) { -it / 12 }
        val exit = if (opening) fadeOut(tween(NavigationMotion.EXIT_MILLIS))
            else slideOutHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS, easing = FastOutLinearInEasing)) { it }
        (enter togetherWith exit).apply { targetContentZIndex = if (opening) 1f else -1f }.using(null)
    }, label = "settingsEditor", modifier = modifier.fillMaxSize()) { page ->
        pages.SaveableStateProvider(page) {
            val spec = specs.firstOrNull { it.id == page }
            LazyColumn(
                modifier = Modifier.fillMaxSize().testTag("settings-$page"),
                contentPadding = PaddingValues(start = ui.s(24f), end = ui.s(24f), top = 16.dp, bottom = dockInset),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                item(key = "heading") {
                    ScreenHeader(
                        title = spec?.title ?: "Настройки",
                        onBack = if (spec != null) ({ open = null }) else onBack,
                        modifier = Modifier.padding(bottom = 12.dp),
                        backLabel = if (spec != null) "К настройкам" else "Назад"
                    )
                }
                if (spec != null) {
                    item(key = "editor-${spec.id}") {
                        Column(Modifier.fillMaxWidth()) { spec.content() }
                    }
                } else {
                    if (!notificationsAllowed || !exactAlarmsAllowed) item(key = "permission-summary") {
                        Row(Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = { open = "notify" })
                            .heightIn(min = 56.dp).padding(bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (!notificationsAllowed) "Разрешите уведомления" else "Разрешите точные напоминания",
                                color = Crimson, fontSize = ui.t(14f), modifier = Modifier.weight(1f))
                            Text("›", color = Crimson, fontSize = ui.t(24f))
                        }
                    }
                    item(key = "place") {
                        Column {
                            SectionLabel("Местоположение")
                            Row(Modifier.fillMaxWidth().heightIn(min = 76.dp)
                                .clickable(role = Role.Button, onClick = actions.openCityPicker), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(data.place.label, color = TextPrimary, fontSize = ui.t(18f), fontWeight = FontWeight.Medium)
                                    Text(data.place.subtitle, color = TextSecondary, fontSize = ui.t(12f), modifier = Modifier.padding(top = 4.dp))
                                }
                                Text("›", color = TextTertiary, fontSize = ui.t(24f))
                            }
                            locationStatus?.let { Caption(it) }
                            HairRule()
                        }
                    }
                    val groups = listOf(
                        "Расчёт времени" to listOf("method", "madhab"),
                        "Звук и напоминания" to listOf("notify", "azan"),
                        "Точная настройка" to listOf("highlat", "rounding", "offsets"),
                        "Внешний вид" to listOf("display"),
                        "Сведения" to listOf("about")
                    )
                    groups.forEach { (title, ids) ->
                        item(key = "group-$title") {
                            Column(Modifier.padding(top = 20.dp)) {
                                SectionLabel(title, Modifier.padding(bottom = 6.dp))
                                Column(Modifier.fillMaxWidth().nurPanel(RoundedCornerShape(16.dp))) {
                                    specs.filter { it.id in ids }.forEachIndexed { index, row ->
                                        if (index > 0) Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                                            .height(1.dp).background(com.nur.prayer.ui.theme.SurfaceEdge))
                                        SettingsIndexRow(row, accent) { open = row.id }
                                    }
                                }
                            }
                        }
                    }
                    item(key = "version") {
                        Text("Нур 0.6.0", color = TextTertiary, fontSize = ui.t(12f), modifier = Modifier.padding(top = 28.dp))
                    }
                }
            }
        }
    }
}

private class SettingsTile(
    val id: String, val title: String, val value: String, val icon: ImageVector,
    val content: @Composable () -> Unit
)

@Composable
private fun SettingsIndexRow(spec: SettingsTile, accent: Color, onClick: () -> Unit) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().testTag("setting-${spec.id}")
        .clickable(role = Role.Button, onClick = onClick).heightIn(min = 76.dp).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(spec.icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(spec.title, color = TextPrimary, fontSize = ui.t(15f), fontWeight = FontWeight.Medium)
            Text(spec.value, color = TextSecondary, fontSize = ui.t(12f), modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.width(8.dp))
        Text("›", color = TextTertiary, fontSize = ui.t(24f))
    }
}

/* ------------------------------------------------------------------------------------------------
 * Local pieces
 * ---------------------------------------------------------------------------------------------- */

/** A signed number states a direction, so the plus sign is never dropped. */
private fun signed(value: Int): String = if (value > 0) "+$value" else "$value"

private fun format(value: Double): String = String.format(java.util.Locale.US, "%.4f", value)

/**
 * One sentence about how much the current profile has actually been checked.
 *
 * Printed in the method group rather than hidden in "О расчёте" because it is the answer to the
 * question that brings a user here: "why does your app disagree with the site I usually read".
 */
private fun calibrationLine(data: PrayerData): String = when (data.profile.calibration) {
    Calibration.PRINTED_CALENDAR ->
        "Профиль «${data.profile.method.title}» сверен с печатным календарём этой страны."
    Calibration.OFFICIAL_ANGLES ->
        "Профиль «${data.profile.method.title}»: официальные углы местного управления, " +
            "печатный календарь ещё не сверялся построчно."
    Calibration.ASSUMED ->
        "Профиль «${data.profile.method.title}» — общий региональный: углы официальные, " +
            "редакционных поправок местного календаря в нём нет."
}

@Composable
private fun WarningBlock(text: String, actionText: String, onClick: () -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(ui.s(16f))
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .nurPanel(shape, PanelLevel.FLAT, Crimson)
            .padding(ui.s(13f))
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(ui.s(7f))
                    .clip(CircleShape)
                    .background(Crimson)
            )
            Spacer(Modifier.width(ui.s(8f)))
            Text(
                text = "Требуется разрешение",
                color = Crimson,
                fontSize = ui.t(11.5f),
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(Modifier.height(ui.s(7f)))
        Text(text = text, color = TextSecondary, fontSize = ui.t(12f), lineHeight = ui.t(16.5f))
        Spacer(Modifier.height(ui.s(11f)))
        NurButton(text = actionText, accent = Crimson, onClick = onClick, primary = true)
    }
}

private fun subtitleFor(method: CalculationMethod): String {
    val hint = when (method) {
        CalculationMethod.RUSSIA_DUM -> "Россия и Беларусь"
        CalculationMethod.SPIRITUAL_BOARD_TATARSTAN -> "Сверено с календарём ДУМ РТ"
        CalculationMethod.UZBEKISTAN_BOARD -> "Узбекистан, сверено с namozvaqti.uz"
        CalculationMethod.UMM_AL_QURA -> "Саудовская Аравия"
        CalculationMethod.TURKEY -> "С поправками Diyanet"
        CalculationMethod.TEHRAN -> "Иран, Магриб по углу"
        else -> null
    }
    return if (hint == null) method.angleSummary else "$hint · ${method.angleSummary}"
}

private fun ruleTitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> "Автоматически"
    HighLatitudeRule.FIXED_INTERVAL -> "Фиксированный интервал (ДУМ РФ)"
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> "Середина ночи"
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> "Одна седьмая ночи"
    HighLatitudeRule.TWILIGHT_ANGLE -> "Пропорция по углу сумерек"
}

private fun ruleSubtitle(rule: HighLatitudeRule): String = when (rule) {
    HighLatitudeRule.AUTO -> "Выше 48° широты — фиксированный интервал, иначе середина ночи"
    HighLatitudeRule.FIXED_INTERVAL -> "Восход − 120 мин и закат + 90 мин, как печатает ДУМ РТ"
    HighLatitudeRule.MIDDLE_OF_THE_NIGHT -> "Фаджр и Иша не переходят середину ночи"
    HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> "Классическая доля ночи 1/7"
    HighLatitudeRule.TWILIGHT_ANGLE -> "Доля ночи пропорциональна углу метода"
}

/**
 * Which piece of evidence decided the time zone.
 *
 * Worth a row of its own: a zone taken from longitude means the app is guessing within an hour, and
 * the user is the only one who can tell it the truth by picking a city.
 */
private fun zoneSourceLabel(source: com.nur.prayer.location.ZoneSource): String = when (source) {
    com.nur.prayer.location.ZoneSource.DEVICE -> "по часам телефона"
    com.nur.prayer.location.ZoneSource.NEIGHBOURHOOD -> "по городам рядом"
    com.nur.prayer.location.ZoneSource.LONGITUDE -> "по долготе (приближённо)"
}

/**
 * Plain words for where today's Sahar / Fajr / Isha actually came from.
 *
 * Exhaustive on purpose, with no `else` branch: when a new [TimeSource] appears, this has to fail to
 * compile, so the explanation shown to the user cannot quietly fall behind the engine.
 */
private fun sourceLabel(source: TimeSource): String = when (source) {
    TimeSource.ANGLE -> "по углу солнца"
    TimeSource.PRINTED_TABLE -> "из печатной таблицы муфтията"
    TimeSource.METHOD_INTERVAL -> "интервал метода"
    TimeSource.FIXED_INTERVAL -> "фикс. интервал (короткая ночь)"
    TimeSource.NIGHT_FRACTION -> "доля ночи (короткая ночь)"
    TimeSource.MIDNIGHT_BOUND -> "ограничено серединой ночи"
    TimeSource.CONGREGATION -> "как в мечети: восход − 90 мин"
    TimeSource.DAWN_BOUND -> "поднято до рассвета"
}
