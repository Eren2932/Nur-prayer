package com.nur.prayer.ui.names

import java.text.Normalizer
import java.util.Locale

internal data class NameEntry(
    val id: Int, val arabic: String, val reading: String, val gloss: String,
    val senses: String, val note: String, val verse: Pair<Int, Int>?
) {
    // Indexed once when reading the asset, not for each key stroke or visible row.
    val terms = listOf(arabic, reading, gloss, senses).map(NamesCatalog::fold)
}

internal object NamesCatalog {
    const val ASSET = "names/ru.tsv"
    private const val HEADER = "id\tar\treading\tgloss\tsenses\tnote\tverse"

    fun fold(text: String): String = Normalizer.normalize(text.lowercase(Locale.ROOT)
        .replace('ё', 'е').replace('ٱ', 'ا'), Normalizer.Form.NFD)
        .filter { it.isLetterOrDigit() && it != 'ـ' }

    fun parse(lines: List<String>): List<NameEntry> {
        require(lines.firstOrNull() == HEADER)
        val rows = lines.drop(1).filter { it.isNotBlank() }.mapIndexed { index, line ->
            val c = line.split('\t')
            require(c.size == 7 && c.none { it.isBlank() } && c[0].toInt() == index + 1)
            val ref = c[6].takeUnless { it == "-" }?.split(':')?.let {
                require(it.size == 2); it[0].toInt() to it[1].toInt()
            }
            NameEntry(index + 1, c[1], c[2], c[3], c[4], c[5], ref)
        }
        require(rows.size == 99)
        return rows
    }

    fun search(rows: List<NameEntry>, query: String): List<NameEntry> {
        val q = fold(query)
        if (q.isEmpty()) return rows
        q.toIntOrNull()?.let { n -> return rows.filter { it.id == n } }
        return rows.filter { row -> row.terms.any { q in it } }
    }
}
