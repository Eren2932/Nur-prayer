package com.nur.prayer.ui.daily

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.unit.dp
import com.nur.prayer.daily.StoryTouch
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** The input surface stays still even when the artwork follows a pull. The native scrollable
 * gets vertical drags inside an overflowing card; it never competes for a horizontal page. */
internal suspend fun PointerInputScope.storyGestures(
    mayPull: (Offset) -> Boolean, onContact: (Boolean) -> Unit, onHidden: (Boolean) -> Unit,
    onPull: (Float) -> Unit, settle: () -> Unit, onAction: (StoryTouch.Action) -> Unit
) = coroutineScope {
    val swipe = 56.dp.toPx(); val close = 120.dp.toPx(); val slop = viewConfiguration.touchSlop
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        if (down.isConsumed) return@awaitEachGesture
        val touch = StoryTouch(down.position.x, size.width.toFloat(), slop, swipe, close, mayPull(down.position))
        onContact(true)
        val deadline = launch {
            delay(StoryTouch.TAP_MS + 1)
            if (touch.hold()) onHidden(true)
        }
        var result = StoryTouch.Action.NONE
        try {
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val change = event.changes.singleOrNull()
                if (change == null || change.id != down.id || change.isConsumed) { touch.cancel(); break }
                val delta = change.position - down.position
                val owner = touch.move(delta.x, delta.y)
                if (owner != StoryTouch.Mode.PENDING) deadline.cancel()
                if (!change.pressed) {
                    result = touch.finish(change.uptimeMillis - down.uptimeMillis, delta.x, delta.y)
                    if (owner != StoryTouch.Mode.TEXT && owner != StoryTouch.Mode.CANCELLED) change.consume()
                    break
                }
                when (owner) {
                    StoryTouch.Mode.PULL -> { onPull((delta.y - slop).coerceAtLeast(0f)); change.consume() }
                    StoryTouch.Mode.PAGE, StoryTouch.Mode.HOLD -> change.consume()
                    else -> Unit // native verticalScroll gets the original events
                }
            }
        } finally {
            deadline.cancel(); onHidden(false); onContact(false)
            if (result != StoryTouch.Action.CLOSE) settle()
        }
        onAction(result)
    }
}
