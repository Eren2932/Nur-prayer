package com.nur.prayer.ui.today

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.R
import com.nur.prayer.daily.CoverOrder
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val photos = intArrayOf(R.drawable.status_courtyard, R.drawable.status_blue_domes,
    R.drawable.status_arcade, R.drawable.status_green_dome, R.drawable.status_moon,
    R.drawable.status_birds, R.drawable.status_dusk)
private val fresh = Brush.linearGradient(listOf(Color(0xFF60F2D4), Color(0xFF41C9DD), Color(0xFF95A1FF)))
private val read = Brush.linearGradient(listOf(Color(0xFFC7D2D2), Color(0xFF91A0A5)))
private val shade = Brush.verticalGradient(0f to Color(0x5C000000), .28f to Color.Transparent,
    .48f to Color.Transparent, .72f to Color(0x99000000), 1f to Color(0xCF000000))

@Composable
internal fun StatusCover(day: Long, mask: Int, ready: Boolean, modifier: Modifier, open: () -> Unit) {
    val ui = uiScale()
    val id = remember(day) { photos[CoverOrder.index(day)] }
    val left = ready && !StoryMath.allSeen(mask, StoryMath.SLIDE_COUNT)
    val seen = (0 until StoryMath.SLIDE_COUNT).count { StoryMath.isSeen(mask, it) }
    val desc = if (ready) tr("Просмотрено: {0} из {1}", seen, StoryMath.SLIDE_COUNT) else tr("Загрузка")
    val shape = RoundedCornerShape(ui.s(21f))
    Box(modifier.clip(shape).background(Color(0xFF213D45)).pressClick(enabled = ready, onClick = open)
        .semantics { stateDescription = desc }) {
        // One density-independent thumbnail; decode off the UI thread, never all seven at launch.
        val resources = LocalContext.current.resources
        key(id) {
            val photo by produceState<ImageBitmap?>(null, resources, id) {
                value = withContext(Dispatchers.IO) { BitmapFactory.decodeResource(resources, id)?.asImageBitmap() }
            }
            photo?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        }
        Box(Modifier.matchParentSize().background(shade))
        Row(Modifier.align(Alignment.TopStart).padding(ui.s(14f)).widthIn(max = ui.s(106f)).fillMaxWidth()
            .background(Color(0x990B1920), CircleShape).padding(horizontal = 3.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(ui.s(3f))) {
            repeat(StoryMath.SLIDE_COUNT) { i ->
                Spacer(Modifier.weight(1f).height(ui.s(3f)).background(
                    if (StoryMath.isSeen(mask, i)) Color.White else Color(0x99BFCBD1), CircleShape))
            }
        }
        Column(Modifier.align(Alignment.BottomStart).padding(ui.s(16f))) {
            Text(tr("На сегодня"), color = Color.White, fontSize = ui.t(16f), lineHeight = ui.t(20f), fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(ui.s(3f)))
            Text(tr("4 статуса"), color = Color.White, fontSize = ui.t(13.5f), lineHeight = ui.t(17f))
        }
        // Dark keyline separates the bright rim from pale photos AND pale wallpaper; no animation.
        Box(Modifier.matchParentSize().border(if (left) ui.s(4f) else 1.dp, Color(0xFF263C45), shape))
        Box(Modifier.matchParentSize().padding(if (left) 0.8.dp else 0.dp).border(
            if (left) ui.s(2.5f) else 1.dp, if (left) fresh else read, shape))
    }
}
