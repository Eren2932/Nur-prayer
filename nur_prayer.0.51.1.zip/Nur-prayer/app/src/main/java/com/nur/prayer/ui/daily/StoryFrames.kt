package com.nur.prayer.ui.daily

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.nur.prayer.daily.StoryPhotoOrder
import com.nur.prayer.daily.StorySlide
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal class StoryFrame(val index: Int, val slide: StorySlide, val photo: Bitmap, val art: StoryArtwork,
    val title: String, val scale: Float)

/** Paint & typography are prepared once off the UI thread. Keep adjacent pages warm, bounded
 * to three entries irrespective of catalog size. Outgoing animations retain their own frame. */
@Composable
internal fun rememberStoryFrame(slides: List<StorySlide>, index: Int, day: Long, scale: Float): State<StoryFrame?> {
    val res = LocalContext.current.resources
    val locale = L10n.language.locale
    val titles = remember(slides, locale) { slides.map { tr(it.kind).uppercase(locale) } }
    val cache = remember(slides, day, titles, scale, res) { LruCache<Int, StoryFrame>(3) }
    return produceState<StoryFrame?>(null, cache, index) {
        suspend fun load(i: Int): StoryFrame = cache.get(i) ?: withContext(Dispatchers.Default) {
            val ref = storyPhotos[StoryPhotoOrder.index(day, i, storyPhotos.size)]
            val photo = requireNotNull(BitmapFactory.decodeResource(res, ref))
            StoryFrame(i, slides[i], photo, StoryArtwork(slides[i], titles[i], scale), titles[i], scale)
        }.also { cache.put(i, it) }
        value = load(index)
        if (index + 1 < slides.size) load(index + 1)
        if (index > 0) load(index - 1)
    }
}
