package com.nur.prayer.ui.daily

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableString
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.style.TypefaceSpan
import com.nur.prayer.daily.StorySlide
import com.nur.prayer.ui.theme.ArabicFont

/** Design units from the reference. Screen and export draw this exact same composition. */
internal class StoryArtwork(private val slide: StorySlide, title: String, fontScale: Float) {
    companion object {
        const val WIDTH = 608
        const val PHOTO = 346
        const val RADIUS = 38f
        private const val PAD = 44
        private const val TEXT_WIDTH = WIDTH - 2 * PAD
        private val ink = 0xff1b1917.toInt()
        private val quiet = 0xff56514d.toInt()
    }
    private data class Line(val text: StaticLayout, val y: Float)
    private data class Body(val lines: List<Line>, val height: Float, val rule: Float?)

    private fun paragraph(text: String, size: Float, color: Int, arabic: Boolean = false, leading: Float = 1.05f): StaticLayout {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
            textSize = size
            this.color = color
            typeface = if (arabic) ArabicFont.paintTypeface() else Typeface.DEFAULT_BOLD
            if (arabic) isFakeBoldText = true // keep the bundled face and all its vowel marks
        }
        val value: CharSequence = if (!arabic) text else SpannableString(text).apply {
            text.forEachIndexed { i, c -> if (c in "،؛؟.!:") setSpan(TypefaceSpan("sans-serif"), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
        }
        return StaticLayout.Builder.obtain(value, 0, value.length, paint, TEXT_WIDTH)
            .setAlignment(if (arabic) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(if (arabic) TextDirectionHeuristics.RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
            .setBreakStrategy(Layout.BREAK_STRATEGY_HIGH_QUALITY)
            .setIncludePad(true)
            .setLineSpacing(0f, if (arabic) ArabicFont.spacingFor(paint, 1.32f) else leading).build()
    }
    private val label = paragraph(title, 21f, android.graphics.Color.WHITE)
    private fun measure(scale: Float): Body {
        val lines = ArrayList<Line>(5)
        var y = 0f
        fun add(text: String, size: Float, color: Int, after: Float, arabic: Boolean = false) {
            val block = paragraph(text, size * scale, color, arabic)
            lines.add(Line(block, y)); y += block.height + after * scale
        }
        slide.arabic?.let { add(it, 42f, ink, 12f, true) }
        slide.translit?.let { add(it, 25f, quiet, 14f) }
        add(slide.ru, if (slide.arabic == null) 40f else 33f, ink, 17f)
        add(slide.source, 24f, quiet, 0f)
        val rule = slide.note?.let { note ->
            y += 27f * scale
            val at = y
            y += 25f * scale
            add(note, 23f, quiet, 0f)
            at
        }
        return Body(lines, y, rule)
    }
    // Measure every shaped paragraph once at the reading size. No fixed page height, no
    // binary shrinking for a long translation and no empty half-page beneath a short hadith.
    private val body = measure(fontScale.coerceIn(.85f, 2f))
    private val top = PHOTO + 32f
    val height = top + body.height + 32f
    val description: String = listOfNotNull(title, slide.arabic, slide.translit, slide.ru, slide.source, slide.note).joinToString("\n")
    private val shape = Path().apply { addRoundRect(0f, 0f, WIDTH.toFloat(), height, RADIUS, RADIUS, Path.Direction.CW) }
    private val photoFrame = RectF(0f, 0f, WIDTH.toFloat(), PHOTO.toFloat())
    private val paper = Paint().apply { color = 0xfff5ebdf.toInt() }
    private val photoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fade = Paint().apply { shader = LinearGradient(0f, PHOTO * .52f, 0f, PHOTO.toFloat(), 0x00000000, 0x95000000.toInt(), Shader.TileMode.CLAMP) }
    private val rulePaint = Paint().apply { color = 0xffdcd2c6.toInt(); strokeWidth = 1.5f }
    enum class CardSurface { VIEWER, PNG }

    fun draw(canvas: Canvas, width: Float, photo: Bitmap, surface: CardSurface = CardSurface.VIEWER) {
        val save = canvas.save()
        // PNG height rounds up to a whole pixel. Fill before scaling so even the last
        // fractional row is opaque. Its top corners are photo pixels, not a paper matte.
        if (surface == CardSurface.PNG) canvas.drawColor(paper.color)
        canvas.scale(width / WIDTH, width / WIDTH)
        if (surface == CardSurface.VIEWER) canvas.clipPath(shape)
        canvas.drawRect(0f, 0f, WIDTH.toFloat(), height, paper)
        canvas.drawBitmap(photo, null, photoFrame, photoPaint)
        canvas.drawRect(photoFrame, fade)
        fun drawAt(text: StaticLayout, y: Float) {
            val mark = canvas.save(); canvas.translate(PAD.toFloat(), y); text.draw(canvas); canvas.restoreToCount(mark)
        }
        drawAt(label, PHOTO - 24f - label.height)
        body.lines.forEach { drawAt(it.text, top + it.y) }
        body.rule?.let { canvas.drawLine(PAD.toFloat(), top + it, (WIDTH - PAD).toFloat(), top + it, rulePaint) }
        canvas.restoreToCount(save)
    }
}
