package com.nur.prayer.ui.today

import com.nur.prayer.ui.components.pageContentInsets
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.unit.dp
import com.nur.prayer.R
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.Vird
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.daily.Ring
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.uiScale
import java.text.NumberFormat

internal data class TodayState(val currentSet: AzkarSet, val morning: Int, val evening: Int,
    val virdDone: Int, val virdSize: Int, val salawat: Long, val imageBackdrop: Boolean,
    val day: Long, val storyMask: Int, val storiesReady: Boolean)

internal class TodayActions(val close: () -> Unit, val names: () -> Unit,
    val vird: () -> Unit, val azkar: (AzkarSet) -> Unit, val salawat: () -> Unit, val story: () -> Unit)

@Composable
internal fun TodayScreen(state: TodayState, reveal: Reveal, on: TodayActions) {
    val ui = uiScale()
    val pull = rememberDraggableState { delta -> reveal.drag(-delta) }
    val side = ui.s(18f)
    val gap = ui.s(11f)
    val titleInk = if (state.imageBackdrop) DeedTone.Ink else Color.White
    BoxWithConstraints(Modifier.fillMaxSize().pageContentInsets()
        .onSizeChanged { reveal.extentPx = it.height.toFloat() }, contentAlignment = Alignment.TopCenter) {
        val single = maxWidth - side * 2f < ui.s(285f) || ui.systemFontScale >= 1.5f
        val room = with(LocalDensity.current) { (ui.t(19f).toDp() + ui.t(16f).toDp()) * 2f }
        val tightType = ui.largeFont || maxWidth < 350.dp || L10n.language.locale.language != "ru"
        val small = maxOf(ui.s(129f), ui.s(if (tightType) 74f else 59f) + room)
        val lower = maxOf(ui.s(141f), small)
        Column(Modifier.widthIn(max = 600.dp).fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = side).padding(top = LocalIslandInset.current + ui.s(12f), bottom = LocalDockInset.current + 8.dp)) {
            Text(tr("Дела"), Modifier.fillMaxWidth().draggable(state = pull, orientation = Orientation.Vertical,
                onDragStarted = { reveal.grab() }, onDragStopped = { v ->
                    if (reveal.release(-v, RevealMath.SHEET_KEEP_AT)) reveal.settle(true) else on.close()
                }), fontSize = ui.t(28f), lineHeight = ui.t(34f), fontWeight = FontWeight.Bold, color = titleInk)
            Spacer(Modifier.height(ui.s(16f)))
            if (single) {
                StatusCover(state.day, state.storyMask, state.storiesReady, Modifier.fillMaxWidth().height(ui.s(212f)), on.story)
                Spacer(Modifier.height(gap))
                SecondaryTiles(state, on, small, gap, Modifier.fillMaxWidth())
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    StatusCover(state.day, state.storyMask, state.storiesReady, Modifier.weight(1.035f).height(small * 2f + gap), on.story)
                    SecondaryTiles(state, on, small, gap, Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(ui.s(21f)))
            if (single) {
                Column(verticalArrangement = Arrangement.spacedBy(gap)) {
                    for (set in AzkarSet.values()) AzkarTile(set, state, lower, Modifier.fillMaxWidth(), on.azkar)
                }
            } else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                for (set in AzkarSet.values()) AzkarTile(set, state, lower, Modifier.weight(1f), on.azkar)
            }
            Spacer(Modifier.height(ui.s(16f)))
            SalawatPanel(state.salawat, on.salawat)
        }
    }
}

@Composable
private fun SecondaryTiles(state: TodayState, on: TodayActions, height: Dp, gap: Dp, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(gap)) {
        DeedTile(tr("99 имён Аллаха"), tr("Имена и смыслы"), R.drawable.deed_allah, tr("Новое"), Modifier.fillMaxWidth(), height, on.names)
        DeedTile(tr("Вирд дня"), if (state.virdSize == 0) tr("Выбрать зикры") else tr("Выполнено {0} из {1}", state.virdDone, state.virdSize),
            R.drawable.deed_star, null, Modifier.fillMaxWidth(), height, on.vird)
    }
}

@Composable
private fun AzkarTile(set: AzkarSet, state: TodayState, height: Dp, modifier: Modifier, open: (AzkarSet) -> Unit) {
    val morning = set == AzkarSet.MORNING
    DeedTile(tr(set.title), tr("Азкаров: {0}", if (morning) state.morning else state.evening),
        if (morning) R.drawable.deed_sun else R.drawable.deed_moon, if (state.currentSet == set) tr("Сейчас") else null,
        modifier, height) { open(set) }
}

@Composable
private fun DeedTile(title: String, sub: String, icon: Int, badge: String?, modifier: Modifier, tileHeight: Dp, open: () -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(ui.s(24f))
    Column(modifier.height(tileHeight).deedMatte(shape, true).pressClick(onClick = open)
        .padding(start = ui.s(18f), end = ui.s(10f), top = ui.s(10f), bottom = ui.s(12f))) {
        Box(Modifier.fillMaxWidth().height(ui.s(44f))) {
            // Reserve the badge’s width before measuring the icon on small screens.
            Row(Modifier.fillMaxWidth()) {
                Box(Modifier.weight(1f)) {
                    val azkar = icon == R.drawable.deed_sun || icon == R.drawable.deed_moon
                    DeedIcon(icon, Modifier.offset(y = ui.s(if (azkar) 5f else 3f)))
                }
                if (badge != null) Text(badge, Modifier.padding(start = ui.s(4f), top = ui.s(2f))
                    .background(DeedTone.Badge, CircleShape).padding(horizontal = ui.s(9f), vertical = ui.s(3f)),
                    color = DeedTone.GreenInk, fontSize = ui.t(10.5f), lineHeight = ui.t(14f), fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.weight(1f))
        AutoSizeText(title, DeedTone.Ink, ui.t(15f), Modifier.fillMaxWidth(), lineHeight = ui.t(19f),
            minFontSize = ui.t(12f), fontWeight = FontWeight.SemiBold, maxLines = 2)
        Spacer(Modifier.height(ui.s(5f)))
        AutoSizeText(sub, DeedTone.Quiet, ui.t(12.5f), Modifier.fillMaxWidth(), lineHeight = ui.t(16f),
            minFontSize = ui.t(10.5f), maxLines = 2)
    }
}

@Composable
private fun DeedIcon(id: Int, modifier: Modifier = Modifier) {
    // Each vector owns its aspect ratio and pigment; a uniform tint would erase the shading.
    val painter = painterResource(id)
    val scale = uiScale().space
    val density = LocalDensity.current
    with(density) {
        Image(painter, null, modifier.size(painter.intrinsicSize.width.toDp() * scale,
            painter.intrinsicSize.height.toDp() * scale))
    }
}

@Composable
private fun SalawatPanel(n: Long, open: () -> Unit) {
    val ui = uiScale()
    val locale = L10n.language.locale
    val formatted = remember(n, locale) { NumberFormat.getIntegerInstance(locale).format(n) }
    val fraction = SalawatGoal.fraction(n)
    Column(Modifier.fillMaxWidth().deedMatte(RoundedCornerShape(ui.s(24f)), true).pressClick(onClick = open)
        .heightIn(min = ui.s(121f)).padding(horizontal = ui.s(20f), vertical = ui.s(13f)), verticalArrangement = Arrangement.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    DeedIcon(R.drawable.deed_bars); Spacer(Modifier.width(ui.s(14f)))
                    Text(tr("Зикр"), color = DeedTone.Ink, fontSize = ui.t(16.5f), lineHeight = ui.t(20f), fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(ui.s(5f)))
                AutoSizeText(formatted, DeedTone.Ink, ui.t(27f), Modifier.fillMaxWidth(), lineHeight = ui.t(30f), fontWeight = FontWeight.Medium)
                Text(tr("Салават · Цель 500М"), color = DeedTone.Quiet, fontSize = ui.t(13f), lineHeight = ui.t(16f))
            }
            Spacer(Modifier.width(ui.s(8f)))
            Box(contentAlignment = Alignment.Center) {
                Ring(fraction, DeedTone.Green, ui.s(62f), ui.s(6f), track = DeedTone.Track)
                Text("${SalawatGoal.percent(n)}%", color = DeedTone.Ink, fontSize = ui.t(15f), fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(ui.s(8f)))
        Box(Modifier.fillMaxWidth().height(ui.s(6f)).clip(CircleShape).background(DeedTone.Track)) {
            Spacer(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(DeedTone.Green, CircleShape))
        }
    }
}

@Composable
internal fun VirdPage(ids: List<String>, counts: Map<String, Long>, open: (String?) -> Unit) {
    val ui = uiScale()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = LocalDockInset.current)) {
        DeedHeading(tr("Вирд дня"))
        Column(Modifier.padding(horizontal = ui.s(23f)), verticalArrangement = Arrangement.spacedBy(ui.s(10f))) {
            if (ids.isEmpty()) DeedCard {
                Text(tr("Выбрать зикры"), Modifier.fillMaxWidth().pressClick { open(null) }.padding(18.dp), color = DeedTone.Ink)
            }
            ids.forEach { id ->
                val preset = Dhikr.preset(id)
                DeedCard {
                    Row(Modifier.fillMaxWidth().pressClick { open(id) }.padding(ui.s(17f)), verticalAlignment = Alignment.CenterVertically) {
                        Ring(Vird.fraction(id, counts), DeedTone.Green, 28.dp, 3.dp, track = DeedTone.Track)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(tr(preset.title), color = DeedTone.Ink, fontWeight = FontWeight.Medium)
                            Text("${counts[id] ?: 0L} / ${preset.target}", color = DeedTone.Quiet, fontSize = ui.t(12f))
                        }
                    }
                }
            }
        }
    }
}
