import com.nur.prayer.daily.StoryPhotoOrder;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Runs against production code with only a JDK. Also exercises negative dates and deck seams. */
public class StoryPhotoOrderCheck {
    public static void main(String[] args) {
        for (int count : new int[]{9, 10, 11, 12, 15}) {
            int[] last = new int[count]; Arrays.fill(last, -500_000);
            int[] deck = new int[count]; Set<String> orders = new HashSet<>();
            for (int slot = -200_000; slot < 200_000; slot++) {
                long day = Math.floorDiv(slot, 4); int slide = Math.floorMod(slot, 4);
                int n = StoryPhotoOrder.index(day, slide, count);
                if (n < 0 || n >= count || slot - last[n] < 8) throw new AssertionError("gap: " + slot);
                if (n != StoryPhotoOrder.index(day, slide, count)) throw new AssertionError("unstable");
                last[n] = slot;
                int position = Math.floorMod(slot, count); deck[position] = n;
                if (position == count - 1 && slot >= -200_000 + count) {
                    if (Arrays.stream(deck).distinct().count() != count) throw new AssertionError("deck");
                    orders.add(Arrays.toString(deck));
                }
            }
            if (orders.size() < 1000) throw new AssertionError("too few distinct permutations");
            System.out.println(count + " photos: 100000 days, distinct decks=" + orders.size() + ", OK");
        }
    }
}
