package com.nur.prayer.ui.today

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.DayItem
import com.nur.prayer.daily.DayPlan
import com.nur.prayer.daily.DayTask
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.daily.Vird
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.KhatmPlan
import com.nur.prayer.quran.QuranMark
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import com.nur.prayer.ui.components.RollingNumber
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.daily.Ring
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.HGap
import com.nur.prayer.ui.shell.ShellGlyph
import com.nur.prayer.ui.shell.ShellIcon
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale

/** What the «Дела» layer shows; computed by the root from the view models. */
data class TodayState(
    val hijri: String,
    val today: Long,
    val azkarSet: AzkarSet,
    val azkarDone: Int,
    val azkarTotal: Int,
    /** 0.18.5: the vird of the day in its order, and today's count of every dhikr. */
    val vird: List<String>,
    val dhikrToday: Map<String, Long>,
    /** Story slides seen today, one bit each (StoryMath). */
    val storyMask: Int,
    /** Where the Quran reader stopped; null before the first reading. */
    val quranMark: QuranMark? = null,
    /** The khatm plan, null when there is none: the Quran row then shows today's share of it. */
    val quranKhatm: KhatmPlan? = null
)

/** Everything the «Дела» layer can open. Learning, the dictionary and the short surahs live in «Учёба» since 0.40.0. */
class TodayActions(
    val close: () -> Unit,
    val story: (Int) -> Unit,
    /** The reader, on the bookmark (al-Fatiha the first time); its back arrow leads to the contents. */
    val quran: () -> Unit,
    val azkar: () -> Unit,
    /** The one counter: on the given dhikr, or (null) on the first of the vird still open. */
    val dhikr: (String?) -> Unit
)

private val STORY_LABELS = listOf("Аят", "Хадис", "Дуа", "Слово")

/**
 * «Дела», 0.41.0: the page of the day, laid out from the owner's reference. Top to bottom: the title and the Hijri date,
 * the ring of the day with the next task, «Сегодня» and the three task cards (azkar, Quran, dhikr), the counters of
 * the vird, the history of the day. Same logic as before ([DayPlan]); the page lies on the SOFT copy of the wallpaper,
 * darkened (NurRoot), and the cards are tall (68 dp) and close (7 dp) on purpose: easier to hit than the reference's.
 *
 * It shares one [Reveal] with home: a drag down on its header drives the same number back.
 */
@Composable
fun TodayScreen(state: TodayState, palette: PhasePalette, reveal: Reveal, on: TodayActions) {
    val ui = uiScale()
    val accent = DeedMint
    val pullDown = rememberDraggableState { delta -> reveal.drag(-delta) }
    val items = DayPlan.build(
        state.azkarDone, state.azkarTotal, state.quranKhatm, state.today,
        state.vird, state.dhikrToday, state.storyMask, STORY_LABELS.size
    )
    val open: (DayTask) -> Unit = { task ->
        when (task) {
            DayTask.AZKAR -> on.azkar()
            DayTask.READING -> on.quran()
            DayTask.VIRD -> on.dhikr(null)
            DayTask.STORY -> on.story(StoryMath.firstUnseen(state.storyMask, STORY_LABELS.size))
        }
    }
    Column(Modifier.fillMaxSize().onSizeChanged { reveal.extentPx = it.height.toFloat() }
        .verticalScroll(rememberScrollState()).padding(horizontal = ui.s(20f))
        .padding(top = LocalIslandInset.current, bottom = LocalDockInset.current + 16.dp)) {
        Column(Modifier.fillMaxWidth().draggable(state = pullDown, orientation = Orientation.Vertical,
            onDragStarted = { reveal.grab() }, onDragStopped = { v ->
                if (reveal.release(-v, RevealMath.SHEET_KEEP_AT)) reveal.settle(true) else on.close()
            }).padding(start = 6.dp, top = ui.s(20f))) {
            Text(tr("Дела"), color = TextPrimary, fontSize = ui.t(36f), fontWeight = FontWeight.ExtraBold)
            Gap(3f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Glyph(GlyphKind.CALENDAR, TextSecondary, Modifier.size(15.dp)); HGap(6f)
                Text(state.hijri, color = TextSecondary, fontSize = ui.t(13f))
            }
        }
        Gap(32f)
        val next = DayPlan.next(items)
        val done = DayPlan.doneCount(items)
        val total = DayPlan.total(items)
        Row(Modifier.fillMaxWidth().pressClick(enabled = next != null) { next?.let(open) }
            .padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(ui.s(75f)), contentAlignment = Alignment.Center) {
                Ring(DayPlan.fraction(items), accent, ui.s(75f), 5.dp, track = Color.White.copy(alpha = 0.12f))
                Text("$done/$total", color = accent, fontSize = ui.t(19f), fontWeight = FontWeight.Bold)
            }
            HGap(14f); DividerMark(42); HGap(14f)
            Column(Modifier.weight(1f)) {
                Text(if (DayPlan.allDone(items)) tr("Дела дня выполнены") else tr("Выполнено {0} из {1}", done, total),
                    color = TextPrimary, fontSize = ui.t(15f), fontWeight = FontWeight.Bold)
                Gap(4f)
                Text(if (next != null) tr("Дальше: {0}", taskTitle(next, state)) else tr("Да примет Аллах."), color = TextSecondary, fontSize = ui.t(13f))
            }
            if (next != null) Box(Modifier.size(30.dp).background(DeedSurface, RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                Glyph(GlyphKind.CHEVRON, TextPrimary, Modifier.size(13.dp))
            }
        }
        Gap(30f)
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Сегодня"), Modifier.weight(1f), color = TextPrimary, fontSize = ui.t(21f), fontWeight = FontWeight.ExtraBold)
            Box(Modifier.width(28.dp).height(2.dp).background(TextSecondary, RoundedCornerShape(50)))
        }
        Gap(18f)
        DeedRow(tr(state.azkarSet.title), if (items[0].complete) tr("прочитаны") else tr("прочитано {0} из {1}", state.azkarDone, state.azkarTotal), items[0].complete, on.azkar) {
            Glyph(if (state.azkarSet == AzkarSet.EVENING) GlyphKind.MOON else GlyphKind.SUN, accent, Modifier.size(29.dp))
        }
        Gap(7f)
        DeedRow(tr("Коран"), quranStatus(state), items[1].complete, on.quran) { ShellIcon(ShellGlyph.BOOK, accent, Modifier.size(30.dp)) }
        Gap(7f)
        DeedRow(tr("Зикр"), dhikrStatus(state, items[2]), items[2].complete, { on.dhikr(null) }) { ShellIcon(ShellGlyph.TASBIH, accent, Modifier.size(30.dp)) }
        Gap(15f)
        CounterBand(state, on.dhikr)
        Gap(15f)
        DeedRow(tr("История дня"), storyStatus(state.storyMask, items[3]), items[3].complete, { open(DayTask.STORY) }) {
            DeedGlyphIcon(DeedGlyph.HISTORY, accent, Modifier.size(30.dp))
        }
    }
}

private val DeedMint = Color(0xFF37E4C5)
private val DeedSurface = Color(0xCF151515)
private val CardShape = RoundedCornerShape(20.dp)

@Composable
private fun DividerMark(height: Int) {
    Box(Modifier.width(1.dp).height(height.dp).background(Color.White.copy(alpha = 0.16f)))
}

@Composable
private fun DeedRow(title: String, status: String, complete: Boolean, onClick: () -> Unit, icon: @Composable () -> Unit) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().clip(CardShape).background(DeedSurface).pressClick(onClick = onClick)
        .heightIn(min = ui.s(68f)).padding(horizontal = ui.s(16f), vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(ui.s(48f)), contentAlignment = Alignment.Center) { icon() }
        HGap(22f)
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.Bold)
            Gap(2f)
            Text(status, color = if (complete) DeedMint else TextSecondary, fontSize = ui.t(13f))
        }
        HGap(6f); Glyph(GlyphKind.CHEVRON, TextSecondary, Modifier.size(14.dp))
    }
}

@Composable
private fun CounterBand(state: TodayState, onOpen: (String?) -> Unit) {
    val ui = uiScale()
    val ids = state.vird.ifEmpty { listOf(Dhikr.AFTER_PRAYER, Dhikr.SALAWAT, Dhikr.ISTIGHFAR) }
    Column(Modifier.fillMaxWidth().clip(CardShape).background(DeedSurface)) {
        ids.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                row.forEachIndexed { index, id ->
                    if (index > 0) DividerMark(50)
                    Column(Modifier.weight(1f).pressClick { onOpen(id) }.padding(horizontal = 4.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        when (id) {
                            Dhikr.SALAWAT -> DeedGlyphIcon(DeedGlyph.BOWL, DeedMint, Modifier.size(22.dp))
                            Dhikr.ISTIGHFAR -> DeedGlyphIcon(DeedGlyph.FRUITS, DeedMint, Modifier.size(22.dp))
                            else -> ShellIcon(ShellGlyph.TASBIH, DeedMint, Modifier.size(21.dp))
                        }
                        RollingNumber(state.dhikrToday[id] ?: 0L, TextPrimary, ui.t(22f))
                        Text(tr(Dhikr.preset(id).title), color = TextSecondary, fontSize = ui.t(11f), textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

private fun taskTitle(task: DayTask, state: TodayState): String = when (task) {
    DayTask.AZKAR -> tr(state.azkarSet.title)
    DayTask.READING -> tr("Коран")
    DayTask.VIRD -> tr("Зикр")
    DayTask.STORY -> tr("История дня")
}

private fun quranStatus(state: TodayState): String {
    val mark = state.quranMark
    val khatm = state.quranKhatm
    return when {
        // With a khatm the row is its day: pages read of today's share, a ring that closes at the norm.
        khatm != null && khatm.finished -> tr("хатм завершён")
        khatm != null && khatm.doneToday(state.today) -> tr("норма дня выполнена")
        khatm != null -> tr("сегодня {0} из {1} стр.", khatm.readToday(state.today), khatm.goalToday(state.today))
        mark == null -> tr("{0} · аят {1}", QuranMath.title(QuranMath.surah(1), L10n.language.code), 1)
        else -> tr("{0} · аят {1}", QuranMath.title(QuranMath.surah(mark.surah), L10n.language.code), mark.ayah)
    }
}

private fun dhikrStatus(state: TodayState, item: DayItem): String {
    val said = state.dhikrToday.values.sum()
    return when {
        state.vird.isEmpty() && said > 0 -> tr("сегодня {0}", said)
        state.vird.isEmpty() -> tr("тасбих, салават, истигфар…")
        item.complete -> tr("вирд дня выполнен")
        else -> tr("вирд дня · {0} из {1}", Vird.doneCount(state.vird, state.dhikrToday), state.vird.size)
    }
}

private fun storyStatus(mask: Int, item: DayItem): String {
    val count = STORY_LABELS.size
    val seen = (0 until count).count { StoryMath.isSeen(mask, it) }
    return when {
        item.complete -> tr("просмотрена")
        seen == 0 -> tr("аят, хадис, дуа и слово дня")
        else -> tr("просмотрено {0} из {1}", seen, count)
    }
}

