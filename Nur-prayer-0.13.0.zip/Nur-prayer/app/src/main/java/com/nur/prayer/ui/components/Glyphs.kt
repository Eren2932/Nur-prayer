package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * The app's icon set, drawn rather than imported.
 *
 * `material-icons-extended` is ~30 MB of vectors for the nine glyphs we need, and the core set has
 * no compass, no muted speaker and no calendar that matches our stroke weight. These are drawn in
 * a 1×1 unit box with one stroke width, so they sit on the same optical grid at every size.
 * Decorative by default: the clickable around a glyph carries the accessible label.
 */
enum class GlyphKind { COMPASS, MORE, CALENDAR, BACK, CLOSE, LOCATION, SOUND, SOUND_OFF, CHEVRON, MOON, SETTINGS, GLOBE, BELL, CLOCK, INFO, SUN, SLIDERS, SPARKLE }

@Composable
fun Glyph(kind: GlyphKind, tint: Color, modifier: Modifier = Modifier) {
    // Arrows point along the reading direction: mirrored for Arabic, everything else stays put.
    val mirror = (kind == GlyphKind.BACK || kind == GlyphKind.CHEVRON) &&
        androidx.compose.ui.platform.LocalLayoutDirection.current == androidx.compose.ui.unit.LayoutDirection.Rtl
    Canvas(modifier) {
        if (mirror) androidx.compose.ui.graphics.drawscope.scale(-1f, 1f) { drawGlyph(kind, tint) }
        else drawGlyph(kind, tint)
    }
}

private fun DrawScope.drawGlyph(kind: GlyphKind, color: Color) {
    val s = size.minDimension
    if (s <= 0f) return
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val w = s * 0.09f
    val stroke = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(ox + x * s, oy + y * s)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, width: Float = w) =
        drawLine(color, p(x1, y1), p(x2, y2), strokeWidth = width, cap = StrokeCap.Round)

    when (kind) {
        GlyphKind.COMPASS -> {
            drawCircle(color, radius = s * 0.42f, center = p(0.5f, 0.5f), style = stroke)
            val needle = Path().apply {
                moveTo(ox + 0.68f * s, oy + 0.32f * s)
                lineTo(ox + 0.45f * s, oy + 0.45f * s)
                lineTo(ox + 0.32f * s, oy + 0.68f * s)
                lineTo(ox + 0.55f * s, oy + 0.55f * s)
                close()
            }
            drawPath(needle, color)
        }
        GlyphKind.MORE -> {
            listOf(0.22f, 0.5f, 0.78f).forEach { x -> drawCircle(color, s * 0.075f, p(x, 0.5f)) }
        }
        GlyphKind.CALENDAR -> {
            drawRoundRect(
                color, topLeft = p(0.12f, 0.2f), size = Size(s * 0.76f, s * 0.68f),
                cornerRadius = CornerRadius(s * 0.14f, s * 0.14f), style = stroke
            )
            line(0.32f, 0.1f, 0.32f, 0.27f)
            line(0.68f, 0.1f, 0.68f, 0.27f)
            line(0.12f, 0.42f, 0.88f, 0.42f, w * 0.8f)
            drawCircle(color, s * 0.055f, p(0.34f, 0.62f))
            drawCircle(color, s * 0.055f, p(0.5f, 0.62f))
            drawCircle(color, s * 0.055f, p(0.66f, 0.62f))
        }
        GlyphKind.BACK -> {
            line(0.62f, 0.18f, 0.3f, 0.5f)
            line(0.3f, 0.5f, 0.62f, 0.82f)
        }
        GlyphKind.CHEVRON -> {
            line(0.4f, 0.22f, 0.68f, 0.5f)
            line(0.68f, 0.5f, 0.4f, 0.78f)
        }
        GlyphKind.CLOSE -> {
            line(0.26f, 0.26f, 0.74f, 0.74f)
            line(0.74f, 0.26f, 0.26f, 0.74f)
        }
        GlyphKind.LOCATION -> {
            // The "navigation arrow", as on a map: a filled dart pointing north-east.
            val dart = Path().apply {
                moveTo(ox + 0.86f * s, oy + 0.14f * s)
                lineTo(ox + 0.14f * s, oy + 0.46f * s)
                lineTo(ox + 0.5f * s, oy + 0.52f * s)
                lineTo(ox + 0.56f * s, oy + 0.88f * s)
                close()
            }
            drawPath(dart, color)
        }
        GlyphKind.SOUND, GlyphKind.SOUND_OFF -> {
            val body = Path().apply {
                moveTo(ox + 0.12f * s, oy + 0.38f * s)
                lineTo(ox + 0.3f * s, oy + 0.38f * s)
                lineTo(ox + 0.52f * s, oy + 0.18f * s)
                lineTo(ox + 0.52f * s, oy + 0.82f * s)
                lineTo(ox + 0.3f * s, oy + 0.62f * s)
                lineTo(ox + 0.12f * s, oy + 0.62f * s)
                close()
            }
            drawPath(body, color)
            if (kind == GlyphKind.SOUND) {
                drawArc(
                    color, startAngle = -50f, sweepAngle = 100f, useCenter = false,
                    topLeft = p(0.46f, 0.3f), size = Size(s * 0.24f, s * 0.4f), style = stroke
                )
                drawArc(
                    color, startAngle = -55f, sweepAngle = 110f, useCenter = false,
                    topLeft = p(0.5f, 0.16f), size = Size(s * 0.38f, s * 0.68f), style = stroke
                )
            } else {
                line(0.64f, 0.36f, 0.9f, 0.64f)
                line(0.9f, 0.36f, 0.64f, 0.64f)
            }
        }
        GlyphKind.SETTINGS -> {
            // A gear in strokes, the same weight as every other glyph: eight teeth round a ring.
            val c = p(0.5f, 0.5f)
            for (i in 0 until 8) {
                val a = Math.toRadians(i * 45.0)
                val dx = kotlin.math.cos(a).toFloat()
                val dy = kotlin.math.sin(a).toFloat()
                drawLine(
                    color, Offset(c.x + dx * s * 0.27f, c.y + dy * s * 0.27f),
                    Offset(c.x + dx * s * 0.4f, c.y + dy * s * 0.4f), strokeWidth = s * 0.13f, cap = StrokeCap.Round
                )
            }
            drawCircle(color, s * 0.27f, c, style = Stroke(width = w * 1.15f))
            drawCircle(color, s * 0.09f, c, style = Stroke(width = w))
        }
        GlyphKind.GLOBE -> {
            val c = p(0.5f, 0.5f)
            val r = s * 0.38f
            drawCircle(color, r, c, style = stroke)
            drawOval(color, topLeft = Offset(c.x - r * 0.42f, c.y - r), size = Size(r * 0.84f, r * 2f), style = stroke)
            line(0.12f, 0.5f, 0.88f, 0.5f)
            line(0.2f, 0.32f, 0.8f, 0.32f, w * 0.8f)
            line(0.2f, 0.68f, 0.8f, 0.68f, w * 0.8f)
        }
        GlyphKind.BELL -> {
            val bell = Path().apply {
                moveTo(ox + 0.2f * s, oy + 0.72f * s)
                lineTo(ox + 0.8f * s, oy + 0.72f * s)
                cubicTo(ox + 0.72f * s, oy + 0.62f * s, ox + 0.72f * s, oy + 0.54f * s, ox + 0.72f * s, oy + 0.44f * s)
                cubicTo(ox + 0.72f * s, oy + 0.26f * s, ox + 0.62f * s, oy + 0.16f * s, ox + 0.5f * s, oy + 0.16f * s)
                cubicTo(ox + 0.38f * s, oy + 0.16f * s, ox + 0.28f * s, oy + 0.26f * s, ox + 0.28f * s, oy + 0.44f * s)
                cubicTo(ox + 0.28f * s, oy + 0.54f * s, ox + 0.28f * s, oy + 0.62f * s, ox + 0.2f * s, oy + 0.72f * s)
                close()
            }
            drawPath(bell, color, style = stroke)
            line(0.43f, 0.84f, 0.57f, 0.84f)
        }
        GlyphKind.CLOCK -> {
            drawCircle(color, s * 0.38f, p(0.5f, 0.5f), style = stroke)
            line(0.5f, 0.5f, 0.5f, 0.28f)
            line(0.5f, 0.5f, 0.66f, 0.6f)
        }
        GlyphKind.INFO -> {
            drawCircle(color, s * 0.38f, p(0.5f, 0.5f), style = stroke)
            drawCircle(color, s * 0.055f, p(0.5f, 0.32f))
            line(0.5f, 0.46f, 0.5f, 0.7f)
        }
        GlyphKind.SUN -> {
            // A sun half under the horizon: the high-latitude rules are about twilight.
            val c = p(0.5f, 0.62f)
            drawArc(color, 180f, 180f, false, topLeft = Offset(c.x - s * 0.2f, c.y - s * 0.2f),
                size = Size(s * 0.4f, s * 0.4f), style = stroke)
            line(0.1f, 0.62f, 0.9f, 0.62f)
            line(0.5f, 0.14f, 0.5f, 0.26f)
            line(0.2f, 0.3f, 0.27f, 0.37f)
            line(0.8f, 0.3f, 0.73f, 0.37f)
            line(0.3f, 0.8f, 0.7f, 0.8f, w * 0.8f)
        }
        GlyphKind.SLIDERS -> {
            line(0.14f, 0.32f, 0.86f, 0.32f)
            line(0.14f, 0.68f, 0.86f, 0.68f)
            drawCircle(color, s * 0.085f, p(0.36f, 0.32f))
            drawCircle(color, s * 0.085f, p(0.64f, 0.68f))
        }
        GlyphKind.SPARKLE -> {
            val star = Path().apply {
                moveTo(ox + 0.5f * s, oy + 0.12f * s)
                quadraticBezierTo(ox + 0.56f * s, oy + 0.44f * s, ox + 0.88f * s, oy + 0.5f * s)
                quadraticBezierTo(ox + 0.56f * s, oy + 0.56f * s, ox + 0.5f * s, oy + 0.88f * s)
                quadraticBezierTo(ox + 0.44f * s, oy + 0.56f * s, ox + 0.12f * s, oy + 0.5f * s)
                quadraticBezierTo(ox + 0.44f * s, oy + 0.44f * s, ox + 0.5f * s, oy + 0.12f * s)
                close()
            }
            drawPath(star, color, style = stroke)
        }
        GlyphKind.MOON -> {
            val r = s * 0.38f
            val crescent = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(p(0.5f, 0.5f), r))
            }
            val bite = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(p(0.66f, 0.38f), r * 0.86f))
            }
            val shape = Path().apply { op(crescent, bite, androidx.compose.ui.graphics.PathOperation.Difference) }
            drawPath(shape, color)
        }
    }
}
