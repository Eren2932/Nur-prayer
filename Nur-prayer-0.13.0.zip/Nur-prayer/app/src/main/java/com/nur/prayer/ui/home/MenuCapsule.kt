package com.nur.prayer.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import kotlin.math.roundToInt

/*
 * 0.13.0 home menu: one round button bottom-left that opens into a capsule to the right.
 *
 *  - The capsule is one surface whose width is a single 0→1 spring value, read only in the layout
 *    phase: opening re-lays out one small node per frame and never recomposes the home screen.
 *  - The dots turn into a cross on the same spot, so the finger that opened it can close it.
 *  - Items arrive one after another (scale + fade, a short stagger) and leave in reverse, faster:
 *    closing should feel like a release, not a second animation to wait for.
 *  - While open, a transparent layer over the sky closes it on any tap outside and the system Back
 *    closes it before leaving home. The layer also swallows the sky's own tap (list ⇄ clock), so
 *    dismissing the menu never flips the home face by accident.
 *  - Choosing an item reports the item's centre in root coordinates: the page then grows out of
 *    that exact point (see MenuReveal in NurRoot).
 */

class MenuEntry(val glyph: GlyphKind, val label: String, val onClick: (Offset) -> Unit)

private val BUTTON = 48.dp
private val ITEM = 44.dp
private val GAP = 6.dp

/**
 * The outside-tap layer. Drawn under the capsule, over everything else on home.
 *
 * [dim] is read only in the draw phase, so fading the shade costs no recomposition. The layer stays
 * composed while it fades out but stops intercepting at once: a tap right after closing is a normal
 * tap again.
 */
@Composable
fun MenuScrim(open: Boolean, dim: () -> Float, onDismiss: () -> Unit) {
    val dismiss by rememberUpdatedState(onDismiss)
    Box(
        Modifier
            .fillMaxSize()
            .drawBehind { val a = dim(); if (a > 0f) drawRect(Color.Black, alpha = 0.22f * a) }
            .then(
                if (!open) Modifier else Modifier
                    .pointerInput(Unit) {
                        // Consume the whole gesture, down to the last move: the sky under it must not
                        // see a tap (face switch) nor a drag (the pull-up layer).
                        awaitEachGesture {
                            awaitFirstDown(requireUnconsumed = false).consume()
                            dismiss()
                            do {
                                val event = awaitPointerEvent()
                                event.changes.forEach { it.consume() }
                            } while (event.changes.any { it.pressed })
                        }
                    }
                    .semantics { contentDescription = tr("Закрыть меню") }
            )
    )
}

@Composable
fun MenuCapsule(
    open: Boolean,
    onOpenChange: (Boolean) -> Unit,
    entries: List<MenuEntry>,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val expand = remember { Animatable(if (open) 1f else 0f) }
    // "Remove animations" in Android scales these to zero by itself (MotionDurationScale).
    LaunchedEffect(open) {
        if (open) expand.animateTo(1f, spring(dampingRatio = 0.78f, stiffness = 520f))
        // Closing: no overshoot, a bit stiffer: out of the way quickly.
        else expand.animateTo(0f, spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 900f))
    }
    BackHandler(enabled = open) { onOpenChange(false) }

    val items = entries.size
    Box(
        modifier
            .layout { measurable, constraints ->
                val p = measurable.measure(constraints.copy(minWidth = 0, maxWidth = Constraints.Infinity))
                val collapsed = BUTTON.roundToPx()
                // The spring may overshoot 1 a little: let the capsule breathe past its width too.
                val w = (collapsed + (p.width - collapsed) * expand.value).roundToInt().coerceAtLeast(collapsed)
                layout(w, p.height) { p.placeRelative(0, 0) }
            }
            .clip(CircleShape)
            .background(SurfaceRaised)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ToggleButton(open, expand) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onOpenChange(!open)
            }
            entries.forEachIndexed { i, entry ->
                MenuItemButton(entry, i, items, expand, enabled = open) { origin ->
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onOpenChange(false)
                    entry.onClick(origin)
                }
                if (i < items - 1) Spacer(Modifier.width(GAP))
            }
            Spacer(Modifier.width(GAP))
        }
    }
}

@Composable
private fun ToggleButton(open: Boolean, expand: Animatable<Float, *>, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box(
        Modifier
            .size(BUTTON)
            .clip(CircleShape)
            .semantics {
                contentDescription = tr("Меню")
                stateDescription = if (open) tr("Открыто") else tr("Закрыто")
            }
            .clickable(interactionSource = interaction, indication = ripple(), role = Role.Button, onClick = onClick)
            .graphicsLayer { val k = if (pressed) 0.92f else 1f; scaleX = k; scaleY = k },
        contentAlignment = Alignment.Center
    ) {
        // Dots and cross share the spot and turn a quarter together.
        Glyph(GlyphKind.MORE, TextPrimary, Modifier.size(BUTTON * 0.42f).graphicsLayer {
            val e = expand.value.coerceIn(0f, 1f)
            alpha = 1f - e
            rotationZ = e * 90f
            val k = 1f - 0.3f * e; scaleX = k; scaleY = k
        })
        Glyph(GlyphKind.CLOSE, TextPrimary, Modifier.size(BUTTON * 0.42f).graphicsLayer {
            val e = expand.value.coerceIn(0f, 1f)
            alpha = e
            rotationZ = (e - 1f) * 90f
            val k = 0.7f + 0.3f * e; scaleX = k; scaleY = k
        })
    }
}

@Composable
private fun MenuItemButton(
    entry: MenuEntry, index: Int, count: Int, expand: Animatable<Float, *>, enabled: Boolean,
    onClick: (Offset) -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val coords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    Box(
        Modifier
            .size(ITEM)
            .onGloballyPositioned { coords[0] = it }
            .graphicsLayer {
                // Staggered arrival: each item starts a little later and needs 55% of the travel.
                val start = 0.18f + index * (0.22f / count.coerceAtLeast(1))
                val t = ((expand.value - start) / 0.55f).coerceIn(0f, 1f)
                alpha = t
                val k = (0.55f + 0.45f * t) * (if (pressed) 0.9f else 1f)
                scaleX = k; scaleY = k
                translationX = (1f - t) * -10.dp.toPx()
            }
            .clip(CircleShape)
            .semantics { contentDescription = entry.label }
            .clickable(enabled = enabled, interactionSource = interaction, indication = ripple(), role = Role.Button) {
                val c = coords[0]
                val origin = if (c != null && c.isAttached) c.positionInRoot() + Offset(c.size.width / 2f, c.size.height / 2f)
                else Offset.Unspecified
                onClick(origin)
            }
            .padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        Glyph(entry.glyph, TextPrimary, Modifier.size(ITEM * 0.46f))
    }
}
