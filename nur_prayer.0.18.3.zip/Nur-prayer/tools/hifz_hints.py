#!/usr/bin/env python3
"""Hifz «первые буквы» for Nur 0.18.3: which words open with a one-letter particle.

  python3 tools/hifz_hints.py         -> check: the asset matches what the Quran text gives (CI)
  python3 tools/hifz_hints.py build   -> app/src/main/assets/hifz/particles.tsv + the Kotlin golden test file
  python3 tools/hifz_hints.py show S:A[-B] -> the masked ayat, as the reader draws them

A first-letter hint is worth something only if it is the first letter of the word itself. In
وَإِذَا or فَزَادَهُمُ the first letter is a joined particle (و ف ب ل ك): every such word would read
«و…» or «ف…». The Quran has no morphology in the APK, so the text itself decides: a word is
particle + rest when the rest also stands in the Quran as a word of its own (ولهم: لهم is a word;
وعد: عد is not). The forms where that test is fooled by a root letter (كتاب — تاب, فضل — ضل,
ليس — يس) are listed in ROOT_STARTS by hand. Up to two particles stack (وبالآخرة, فلما is one).

The asset has one line per form: «N<TAB>bare word», N = particles in front. «Bare» is the word
without marks with ٱ as ا: QuranText.bare() in Kotlin does exactly the same.
"""
import collections, glob, os, sys

ROOT = os.path.normpath(os.path.join(os.path.dirname(__file__), '..'))
QURAN = os.path.join(ROOT, 'app/src/main/assets/quran')
OUT = os.path.join(ROOT, 'app/src/main/assets/hifz/particles.tsv')
GOLDEN = os.path.join(ROOT, 'app/src/test/resources/hifz_first_letters.tsv')
# Ayat the Kotlin QuranText.firstLetterParts must mask exactly as this file does (QuranTextSearchTest):
# al-Fatiha, the start of al-Baqara with its muqatta'at, Ayat al-Kursi, the longest ayah, the openings
# with letters of their own, and the last three surahs.
GOLDEN_AYAT = ([(1, a) for a in range(1, 8)] + [(2, a) for a in range(1, 26)] + [(2, 255), (2, 282), (3, 1), (7, 1),
               (19, 1), (20, 1), (36, 1), (38, 1), (42, 1), (42, 2), (50, 1), (68, 1)]
               + [(112, a) for a in range(1, 5)] + [(113, a) for a in range(1, 6)] + [(114, a) for a in range(1, 7)])

PARTICLES = 'وفبلك'
STEM_MIN = {'و': 2, 'ف': 2, 'ب': 3, 'ل': 3, 'ك': 3}
# Bare beginnings where the first letter belongs to the root although the rest happens to be a
# word too. Checked against the most frequent hits of the test; a miss costs one extra letter shown.
ROOT_STARTS = (
    'بشر', 'بغيا', 'بغت', 'بعيد', 'بكر', 'بلغ', 'بلاء',
    'كتب', 'كتاب', 'كل', 'كيد', 'كره', 'كرب', 'كرم', 'كفر', 'كفل', 'كفي', 'كدن', 'كبر', 'كذب', 'كسب', 'كشف',
    'ليس', 'لكن', 'لعل', 'لعن', 'لدن', 'لدى', 'لقي', 'لقاء', 'لبث', 'لهب', 'لوم', 'لوط', 'ليل', 'لين',
    'فضل', 'فوق', 'فرق', 'فرح', 'فتن', 'فتح', 'فسق', 'فعل', 'فصل', 'فقر', 'فلك', 'فئة', 'فيه',
    'وعد', 'ولد', 'وجه', 'وجد', 'وحي', 'وزر', 'وسع', 'وصي', 'وقت', 'وكيل', 'وهب', 'ويل',
)
MUQATTAAT = {'الم', 'المص', 'الر', 'المر', 'كهيعص', 'طه', 'طسم', 'طس', 'يس', 'حم', 'عسق'}

MASK = '\u0640'
MASK_PER_LETTER = 2   # NotoNaskhArabic: an average letter is 2.04 tatweels wide (measured, 3000 words)
MASK_MIN = 2
MASK_MAX = 24


def is_mark(c):
    return ('\u0610' <= c <= '\u061A' or '\u064B' <= c <= '\u065F' or c == '\u0670'
            or '\u06D6' <= c <= '\u06ED' or c == '\u0640')


def is_mark_after(word, i):
    return i + 1 < len(word) and is_mark(word[i + 1])


def bare(word):
    return ''.join(c for c in word if not is_mark(c)).replace('ٱ', 'ا')


def surahs():
    for path in sorted(glob.glob(os.path.join(QURAN, '[0-9][0-9][0-9].tsv'))):
        s = int(os.path.basename(path)[:3])
        with open(path, encoding='utf-8') as f:
            header = next(f).rstrip('\n').split('\t')
            ia, ar = header.index('ayah'), header.index('arabic')   # by name, as QuranMath.parse does
            for line in f:
                cols = line.rstrip('\n').split('\t')
                if len(cols) > max(ia, ar) and cols[ar]:
                    yield s, int(cols[ia]), cols[ar]


def vocabulary():
    v = collections.Counter()
    for _, _, text in surahs():
        for w in text.split(' '):
            b = bare(w)
            if b:
                v[b] += 1
    return v


def particles_of(b, vocab):
    n = 0
    while n < 2 and len(b) - n >= 3 and b[n] in PARTICLES:
        rest = b[n + 1:]
        if any(b[n:].startswith(r) for r in ROOT_STARTS):
            break
        # لِلنَّاسِ: li before the article drops its alef — the rest is الناس, written لناس.
        # لِلَّهِ is li + الله with both its alef and a lam gone: three letters, «لله».
        if b[n] == 'ل' and rest.startswith('ل') and ('ا' + rest in vocab or rest == 'له'):
            return n + 1                           # the second ل is the article: nothing stacks on it
        # و and ف stand before anything (وَمَا, فَهُمْ). ب ل ك before a two-letter pronoun (لَهُمْ,
        # بِهَا, لَكُمْ) are left as one word: there the particle IS the shape the hafiz remembers,
        # and «لَهُـ» would give away two letters of three.
        if len(rest) < STEM_MIN[b[n]]:
            break
        if rest in vocab:
            n += 1
        else:
            break
    return n


def table():
    vocab = vocabulary()
    rows = {}
    for b in vocab:
        n = particles_of(b, vocab)
        if n:
            rows[b] = n
    return rows


def render(rows):
    return ''.join(f'{n}\t{b}\n' for b, n in sorted(rows.items()))


# ---- the reference of QuranText.firstLetterParts (Kotlin), for `show` and the cross-check ----

def mask_word(word, rows, opening):
    letters = [i for i, c in enumerate(word) if not is_mark(c)]
    if len(letters) <= 1:
        return [(word, False)]
    b = bare(word)
    if opening and b in MUQATTAAT:
        return [(word, False)]
    n = rows.get(b, 0)
    keep = n
    rest = b[n:]
    if len(rest) >= 4 and rest.startswith('ال'):
        keep += 2
    elif n and b[n - 1] == 'ل' and rest.startswith('ل') and len(rest) >= 3:
        keep += 1                                  # li + the article without its alef
    keep += 1                                      # the first letter of the word itself
    # اهْدِنَا, اتَّقُوا: a bare alef with no vowel of its own is the silent hamzat al-wasl — the
    # sound starts on the letter after it, so that one is the hint.
    if b[keep - 1] == 'ا' and keep - 1 == len(b) - len(rest) and not is_mark_after(word, letters[keep - 1]):
        keep += 1
    keep = min(keep, len(letters) - 1)             # something is always left to recall
    hidden = len(letters) - keep
    mask = MASK * max(MASK_MIN, min(MASK_MAX, hidden * MASK_PER_LETTER))
    return [(word[:letters[keep]], False), (mask, True)]


def first_letters(text, rows):
    out = []
    for i, w in enumerate(text.split(' ')):
        if i:
            out.append((' ', False))
        out += mask_word(w, rows, i == 0)
    return out


def golden(rows):
    want = set(GOLDEN_AYAT)
    lines = [f'{s}:{a}\t' + ''.join(t for t, _ in first_letters(text, rows)) + '\n'
             for s, a, text in surahs() if (s, a) in want]
    if len(lines) != len(want):
        sys.exit('FAIL: some golden ayat are missing from the Quran assets')
    return ''.join(lines)


def main(argv):
    cmd = argv[1] if len(argv) > 1 else 'check'
    rows = table()
    if cmd == 'build':
        for path, body in ((OUT, render(rows)), (GOLDEN, golden(rows))):
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(body)
        print(f'hifz_hints: {len(rows)} forms with particles -> {os.path.relpath(OUT, ROOT)}, '
              f'{len(GOLDEN_AYAT)} golden ayat -> {os.path.relpath(GOLDEN, ROOT)}')
    elif cmd == 'check':
        for path, body in ((OUT, render(rows)), (GOLDEN, golden(rows))):
            have = open(path, encoding='utf-8').read() if os.path.exists(path) else ''
            if have != body:
                sys.exit(f'FAIL: {os.path.relpath(path, ROOT)} is stale: run python3 tools/hifz_hints.py build')
        two = sum(1 for n in rows.values() if n == 2)
        print(f'PASS: hifz particles — {len(rows)} forms ({two} with two particles), asset up to date.')
    elif cmd == 'show':
        s, a = argv[2].split(':')
        lo, hi = (a.split('-') + [a])[:2]
        for ss, aa, text in surahs():
            if ss == int(s) and int(lo) <= aa <= int(hi):
                print(f'{ss}:{aa}', ''.join(t for t, _ in first_letters(text, rows)))
    else:
        sys.exit(__doc__)


if __name__ == '__main__':
    main(sys.argv)
