#!/usr/bin/env python3
import os, sys, unittest
sys.path.insert(0, os.path.dirname(__file__))
from kt_accessor_clash import check_text

class T(unittest.TestCase):
    def test_the_0_17_0_failure(self):
        src = "class S {\n var translationSize by mutableStateOf(1)\n  private set\n fun setTranslationSize(v: Int) { }\n}"
        self.assertEqual(1, len(check_text(src, "S.kt")))
    def test_var_with_private_setter(self):
        self.assertEqual(1, len(check_text("class S {\n var a: Int = 0\n  private set\n fun setA(v: Int) {}\n}")))
    def test_getter_clash(self):
        self.assertEqual(1, len(check_text("class S {\n val size = 1\n fun getSize(): Int = 2\n}")))
    def test_different_names_are_fine(self):
        self.assertEqual([], check_text("class S {\n var readerTheme = 0\n fun setTheme(v: Int) {}\n var arabicSize = 0\n fun setSize(v: Int) {}\n}"))
    def test_val_with_set_function_is_fine(self):
        self.assertEqual([], check_text("class S {\n val a = 0\n fun setA(v: Int) {}\n}"))
    def test_nested_scopes_and_strings_ignored(self):
        src = 'class S {\n var a = 0\n fun x() { val s = "fun setA(v: Int)" ; fun setA(v: Int) {} }\n}'
        self.assertEqual([], check_text(src))
    def test_two_classes_do_not_mix(self):
        self.assertEqual([], check_text("class A {\n var a = 0\n}\nclass B {\n fun setA(v: Int) {}\n}"))

if __name__ == "__main__":
    unittest.main()
