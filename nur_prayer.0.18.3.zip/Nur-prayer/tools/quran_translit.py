"""Arabic (Tanzil "simple", Hafs) -> Russian scientific transliteration.

The scheme is the one the app already uses in quran_short.tsv (and was written by hand there):
  ح ҳ · ه һ · ع ‘ · ء ’ · غ ғ · ق қ · ث с̱ · ذ з̱ · ص с̣ · ض д̣ · ط т̣ · ظ з̣ · ج дж · خ х · ش ш
  long vowels doubled (аа, ии, уу), diphthongs ай / ав, article ль- / assimilated (р-р…),
  hamza not written at the very start of a word, pause form at the end of every ayah.

It reads only the vowel marks that are actually in the text: nothing is guessed from a
dictionary, so the same input always gives the same output.
"""
import re

FATHA, DAMMA, KASRA = '\u064e', '\u064f', '\u0650'
FATHATAN, DAMMATAN, KASRATAN = '\u064b', '\u064c', '\u064d'
SHADDA, SUKUN, DAGGER = '\u0651', '\u0652', '\u0670'
VOWELS = {FATHA: 'а', DAMMA: 'у', KASRA: 'и', FATHATAN: 'ан', DAMMATAN: 'ун', KASRATAN: 'ин'}
IGNORED = set('\u0640\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06dc\u06dd\u06de\u06df\u06e0\u06e1\u06e2\u06e3'
              '\u06e4\u06e5\u06e6\u06e7\u06e8\u06e9\u06ea\u06eb\u06ec\u06ed\ufeff')
CONS = {
    'ب': 'б', 'ت': 'т', 'ث': 'с̱', 'ج': 'дж', 'ح': 'ҳ', 'خ': 'х', 'د': 'д', 'ذ': 'з̱', 'ر': 'р',
    'ز': 'з', 'س': 'с', 'ش': 'ш', 'ص': 'с̣', 'ض': 'д̣', 'ط': 'т̣', 'ظ': 'з̣', 'ع': '‘', 'غ': 'ғ',
    'ف': 'ф', 'ق': 'қ', 'ك': 'к', 'ل': 'л', 'م': 'м', 'ن': 'н', 'ه': 'һ', 'و': 'в', 'ي': 'й',
    'ء': '’', 'أ': '’', 'إ': '’', 'ؤ': '’', 'ئ': '’', 'ة': 'т', 'ى': 'й',
}
HAMZA = set('ءأإؤئآ')
SUN = set('تثدذرزسشصضطظلن')
LETTERS = set(CONS) | {'ا', 'آ'}
PREFIXES = set('وفبكلأس')

# Disjoined letters opening 29 surahs, read by their names.
MUQATTAAT = {
    'الم': 'алиф-лаам-миим', 'المص': 'алиф-лаам-миим-с̣аад', 'الر': 'алиф-лаам-раа',
    'المر': 'алиф-лаам-миим-раа', 'كهيعص': 'кааф-һаа-йаа-‘айн-с̣аад', 'طه': 'т̣аа-һаа',
    'طسم': 'т̣аа-сиин-миим', 'طس': 'т̣аа-сиин', 'يس': 'йаа-сиин', 'ص': 'с̣аад',
    'حم': 'ҳаа-миим', 'عسق': '‘айн-сиин-қааф', 'ق': 'қааф', 'ن': 'нуун',
}
MUQATTAAT_AYAT = {(2, 1), (3, 1), (7, 1), (10, 1), (11, 1), (12, 1), (13, 1), (14, 1), (15, 1), (19, 1),
                  (20, 1), (26, 1), (27, 1), (28, 1), (29, 1), (30, 1), (31, 1), (32, 1), (36, 1), (38, 1),
                  (40, 1), (41, 1), (42, 1), (42, 2), (43, 1), (44, 1), (45, 1), (46, 1), (50, 1), (68, 1)}


class Unit:
    __slots__ = ('ch', 'vowel', 'shadda', 'sukun', 'dagger')

    def __init__(self, ch):
        self.ch, self.vowel, self.shadda, self.sukun, self.dagger = ch, None, False, False, False

    @property
    def bare(self):
        return self.vowel is None and not self.shadda and not self.sukun and not self.dagger


def units(word):
    out = []
    for c in word:
        if c in IGNORED:
            continue
        if c in LETTERS:
            out.append(Unit(c))
        elif not out:
            continue
        elif c in VOWELS:
            out[-1].vowel = c
        elif c == SHADDA:
            out[-1].shadda = True
        elif c == SUKUN:
            out[-1].sukun = True
        elif c == DAGGER:
            out[-1].dagger = True
        else:
            raise ValueError('unexpected character U+%04X in %r' % (ord(c), word))
    return out


def is_wasl_article(us, i):
    """us[i] is a bare alif starting ال: returns 'moon', 'sun', 'lam' (الَّذي / الله) or None."""
    if i + 1 >= len(us) or us[i + 1].ch != 'ل':
        return None
    lam = us[i + 1]
    if lam.shadda and all(p.ch in PREFIXES and p.vowel and not p.shadda for p in us[:i]):
        return 'lam'  # الَّذِي، الَّتِي (one lam, doubled), also after a prefix: وَالَّذِينَ
    if lam.sukun:
        return 'moon'
    if lam.bare and i + 2 < len(us) and us[i + 2].shadda:
        return 'sun'
    if i == 0 and lam.bare and i + 2 < len(us):
        return 'moon'  # a word-initial wasl alif is always wasl, whatever the lam carries
    return None


class Seg:
    """One pronounced piece: consonant + vowel; kept apart so pause and idgham can edit them."""
    __slots__ = ('cons', 'vowel', 'unit')

    def __init__(self, cons, vowel, unit):
        self.cons, self.vowel, self.unit = cons, vowel, unit

    def text(self):
        return self.cons + self.vowel


def word_segments(us, at_start, prev_open):
    """Segments of one word. at_start: first word of the ayah. prev_open: previous word ended in a vowel."""
    segs = []
    i = 0
    n = len(us)
    article = None
    # Hamzat al-wasl opening the word.
    if us and us[0].ch == 'ا' and us[0].bare:
        article = is_wasl_article(us, 0)
        if at_start or not prev_open:
            if article:
                v = 'а'
            else:
                v = 'у' if n > 2 and us[2].vowel == DAMMA else 'и'
            segs.append(Seg('', v, us[0]))
        i = 1
    while i < n:
        u = us[i]
        prev = us[i - 1] if i > 0 else None
        nxt = us[i + 1] if i + 1 < n else None
        c = u.ch
        if c == 'ا':
            after_prefix = all(p.ch in PREFIXES and p.vowel and not p.shadda for p in us[:i])
            if u.bare and i > 0 and nxt is not None and (
                nxt.sukun or
                (nxt.ch == 'ل' and is_wasl_article(us, i)) or
                (after_prefix and (nxt.shadda or (nxt.bare and nxt.ch not in 'اويىة')))
            ):
                # Wasl after a prefix: وَالنَّاس، بِالْغَيْب، فَاسْتَغْفِرْ
                article = is_wasl_article(us, i)
                if not segs or not segs[-1].vowel:
                    segs.append(Seg('', 'и', u))
                i += 1
                if article:
                    i = emit_article(us, i, segs, article)
                continue
            if prev is not None and prev.vowel == FATHA and segs and segs[-1].vowel.endswith('а') \
                    and not segs[-1].vowel.endswith('аа'):
                segs[-1].vowel += 'а'
            elif u.vowel or u.shadda:
                segs.append(Seg('’', VOWELS.get(u.vowel, ''), u))
            # otherwise silent: after tanwin, after waw al-jama'a, the alif of مِائَة
            i += 1
            continue
        if article and i == 1:
            i = emit_article(us, i, segs, article)
            article = None
            continue
        if c == 'آ':
            cons = '' if not segs else '’'
            segs.append(Seg(cons, 'аа', u))
            i += 1
            continue
        if c == 'ى':
            if u.vowel and u.vowel != FATHATAN:
                segs.append(Seg('й', VOWELS[u.vowel], u))
            elif prev is not None and prev.vowel == FATHATAN:
                pass
            elif prev is not None and prev.vowel == KASRA and segs and segs[-1].vowel == 'и':
                segs[-1].vowel = 'ии'
            elif segs and segs[-1].vowel.endswith('а') and not segs[-1].vowel.endswith('аа'):
                segs[-1].vowel += 'а'
            i += 1
            continue
        if c in 'وي' and not u.shadda and u.vowel is None:
            long_v = 'у' if c == 'و' else 'и'
            short = DAMMA if c == 'و' else KASRA
            if c == 'و' and prev is not None and prev.ch == 'أ' and prev.vowel == DAMMA and nxt is not None and nxt.ch == 'ل':
                i += 1  # أُولَٰئِكَ، أُولُو: the waw is written, not read
                continue
            if not u.sukun and prev is not None and prev.vowel == short and segs and segs[-1].vowel == long_v:
                segs[-1].vowel += long_v
                if u.dagger:
                    pass
                i += 1
                continue
            if u.dagger and segs and segs[-1].vowel == 'а':
                segs[-1].vowel = 'аа'
                i += 1
                continue
            segs.append(Seg(CONS[c], '', u))
            i += 1
            continue
        # لِلْ / لِلنَّاس: the preposition li- swallows the alif of the article.
        if c == 'ل' and prev is not None and prev.ch == 'ل' and prev.vowel == KASRA and not prev.shadda \
                and all(p.ch in PREFIXES and p.vowel and not p.shadda for p in us[:i]) and not u.shadda:
            if u.sukun:
                segs.append(Seg('ль-', '', u))
                i += 1
                continue
            if u.bare and nxt is not None and nxt.shadda:
                i = emit_article(us, i, segs, 'sun')
                continue
        # A consonant left bare before a doubled one is absorbed by it: عَاهَدتُّم -> ‘ааһаттум.
        if u.bare and c not in HAMZA and c != 'ة' and nxt is not None and nxt.shadda and nxt.ch not in 'اى':
            i += 1
            continue
        # Consonant (including hamza carriers, ة with a vowel).
        cons = CONS[c]
        if c in HAMZA and not segs:
            cons = ''
        if c == 'ة' and u.vowel is None:
            cons = 'һ'
        if u.shadda and cons:
            cons = double(cons)
        v = VOWELS.get(u.vowel, '')
        if u.dagger:
            v = 'аа'
        segs.append(Seg(cons, v, u))
        i += 1
    return segs


def double(cons):
    if cons == 'дж':
        return 'джж'
    return cons + cons


def emit_article(us, i, segs, article):
    """us[i] is the lam of the article (wasl alif already consumed). Returns the next index."""
    lam = us[i]
    if article == 'lam':
        return i  # الَّذِي / اللَّه: the doubled lam is read as written
    if article == 'moon':
        segs.append(Seg('ль-', '', lam))
        return i + 1
    # sun letter: the lam is not read, the next consonant is doubled across a hyphen
    nxt = us[i + 1]
    c = CONS[nxt.ch]
    # الَّذِي، اللَّه: the doubled lam is written as one cluster, not л-л
    segs.append(Seg(c if nxt.ch == 'ل' else c + '-', '', lam))
    nxt_v = VOWELS.get(nxt.vowel, '')
    if nxt.dagger:
        nxt_v = 'аа'
    segs.append(Seg(c, nxt_v, nxt))
    return i + 2


def apply_pause(segs):
    """Waqf at the end of the ayah: short final vowel and -un/-in drop, -an becomes -аа, ة becomes һ."""
    for s in reversed(segs):
        if s.cons == '' and s.vowel == '':
            continue
        u = s.unit
        if u.ch == 'ة':
            s.cons, s.vowel = 'һ', ''
        elif s.vowel in ('а', 'у', 'и', 'ун', 'ин'):
            s.vowel = ''
        elif s.vowel == 'ан':
            s.vowel = 'аа'
        return


def transliterate_ayah(text, surah, ayah):
    words = [w for w in text.split(' ') if units(w)]
    out = []          # list of [string, joined_to_previous]
    prev_segs = None
    for wi, w in enumerate(words):
        us = units(w)
        letters = ''.join(u.ch for u in us)
        if (surah, ayah) in MUQATTAAT_AYAT and all(u.bare for u in us) and letters in MUQATTAAT:
            out.append([MUQATTAAT[letters], False])
            prev_segs = None
            continue
        at_start = wi == 0
        prev_open = bool(prev_segs) and prev_segs[-1].vowel != '' and not prev_segs[-1].vowel.endswith('н')
        if not at_start and us[0].ch == 'ا' and us[0].bare and prev_segs and not prev_open:
            # tanwin or a closed syllable before wasl: a helping kasra joins the two words
            prev_segs[-1].vowel += 'и'
            out[-1][0] = ''.join(s.text() for s in prev_segs)
            prev_open = True
        idgham = not at_start and us[0].shadda and us[0].ch != 'ا' and bool(prev_segs)
        if us[0].shadda and us[0].ch != 'ا':
            us[0].shadda = False  # the doubling belongs to the junction, handled below
        segs = word_segments(us, at_start, prev_open)
        joined = False
        # Idgham the text marks with a shadda on the first letter (Tanzil): مِّنَ، لِّلْ، رَّبِّ
        if idgham:
            first = segs[0]
            base = CONS[us[0].ch]
            last = prev_segs[-1]
            if last.vowel.endswith('н'):
                last.vowel = last.vowel[:-1] + base
                out[-1][0] = ''.join(s.text() for s in prev_segs)
                joined = True
            elif last.vowel == '' and last.cons:
                last.cons = base
                out[-1][0] = ''.join(s.text() for s in prev_segs)
                joined = True
            else:
                first.cons = double(base)
        if wi == len(words) - 1:
            apply_pause(segs)
        elif letters in ('أنا', 'وأنا', 'فأنا') and segs and segs[-1].vowel == 'аа':
            segs[-1].vowel = 'а'  # أَنَا: the final alif is read only at a pause
        text_w = ''.join(s.text() for s in segs)
        core = ''.join(u.ch for u in us)
        is_allah = re.fullmatch(r'(ا)?لله(م)?', core) is not None and us[-2 if core.endswith('م') else -1].ch == 'ه' \
            and (us[0].ch == 'ا')
        if is_allah:
            if at_start or not prev_open:
                text_w = text_w[0].upper() + text_w[1:] if text_w else text_w
            else:
                joined = True
        out.append([text_w, joined])
        prev_segs = segs
    s = ''
    out = [[t.replace('ййй', 'йй'), j] for t, j in out]  # بِأَييِّكُمُ is spelled with two ya
    for t, j in out:
        if not s:
            s = t
        elif j:
            s += '-' + t
        else:
            s += ' ' + t
    return s


# ── Latin reading for the non-Cyrillic interface languages ──────────────────────────────────────
# Derived from the Cyrillic reading above, letter for letter, so both always say the same thing.
# Long vowels take a macron; emphatics keep the dot below; ‘ayn and hamza keep their own signs.
LATIN_MULTI = [
    ('джж', 'jj'), ('ддж', 'jj'), ('дж', 'j'), ('с\u0331', 'th'), ('з\u0331', 'dh'), ('с\u0323', 'ṣ'), ('д\u0323', 'ḍ'),
    ('т\u0323', 'ṭ'), ('з\u0323', 'ẓ'), ('аа', 'ā'), ('ии', 'ī'), ('уу', 'ū'), ('ль-', 'l-'),
]
LATIN_SINGLE = {
    'а': 'a', 'б': 'b', 'в': 'w', 'д': 'd', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l',
    'м': 'm', 'н': 'n', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u', 'ф': 'f', 'х': 'kh', 'ш': 'sh',
    'ғ': 'gh', 'қ': 'q', 'ҳ': 'ḥ', 'һ': 'h', '‘': 'ʿ', '’': 'ʾ', 'ь': '', '-': '-', ' ': ' ',
}
# A plain h after these letters would read as one sound (t+h is not th): keep them apart.
LATIN_SPLIT_BEFORE_H = ('t', 's', 'd', 'z', 'k', 'g')


def to_latin(cyr):
    out = []
    i = 0
    while i < len(cyr):
        ch = cyr[i]
        upper = ch.isupper()
        low = cyr[i:].lower()
        for src, dst in LATIN_MULTI:
            if low.startswith(src):
                piece, i = dst, i + len(src)
                break
        else:
            if ch.lower() not in LATIN_SINGLE:
                raise ValueError('no Latin for %r in %r' % (ch, cyr))
            piece, i = LATIN_SINGLE[ch.lower()], i + 1
        if piece == 'h' and out and out[-1][-1:] in LATIN_SPLIT_BEFORE_H and cyr[i - 1] == 'һ':
            piece = '·h'
        out.append(piece[:1].upper() + piece[1:] if upper else piece)
    return ''.join(out)


# ── Uzbek: the Tanzil text is in Cyrillic, the app speaks Latin Uzbek (O‘zbekcha) ─────────────────
UZ = {
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'ё': 'yo', 'ж': 'j', 'з': 'z', 'и': 'i',
    'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's',
    'т': 't', 'у': 'u', 'ф': 'f', 'х': 'x', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'ъ': 'ʼ', 'ь': '',
    'э': 'e', 'ю': 'yu', 'я': 'ya', 'ў': 'oʻ', 'қ': 'q', 'ғ': 'gʻ', 'ҳ': 'h', 'щ': 'sh', 'ы': 'i',
}
UZ_VOWELS = set('аеёиоуэюяўАЕЁИОУЭЮЯЎ')


def uz_latin(text):
    """Official 1995 Uzbek Latin alphabet; е is ye at a word start and after a vowel or ъ/ь."""
    out = []
    for i, ch in enumerate(text):
        low = ch.lower()
        if low == 'е':
            prev = text[i - 1] if i else ' '
            piece = 'ye' if (not prev.isalpha() or prev in UZ_VOWELS or prev.lower() in 'ъь') else 'e'
        elif low in UZ:
            piece = UZ[low]
        else:
            out.append(ch)
            continue
        if ch != low and piece:
            nxt = text[i + 1] if i + 1 < len(text) else ''
            whole_word_caps = nxt.isalpha() and nxt.isupper()
            piece = piece.upper() if whole_word_caps else piece[:1].upper() + piece[1:]
        out.append(piece)
    return ''.join(out)
