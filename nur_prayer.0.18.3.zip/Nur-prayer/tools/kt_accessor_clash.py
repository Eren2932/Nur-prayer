#!/usr/bin/env python3
"""
0.17.0 died in CI on `Platform declaration clash: setTranslationSize(I)V`: a class had
`var translationSize … private set` and also `fun setTranslationSize(v: Int)`. The property already
owns that JVM name, so the two cannot live in one class — even when the setter is private.

Check, per class body (direct members only, no compiler needed):
  a `var name` next to `fun setName(<one parameter>)`, and
  a `val/var name` next to `fun getName()` with no parameters.
Exit code 1 on any finding. Runs in CI before Gradle, next to kt_sanity.py.
"""
from __future__ import annotations
import os, re, sys

ROOT = os.path.normpath(os.path.join(os.path.dirname(__file__), ".."))
SRC = os.path.join(ROOT, "app/src")
CLASS = re.compile(r"\b(?:class|object|interface)\s+(\w+)[^{;=]*\{")
PROP = re.compile(r"^\s*(?:(?:private|internal|protected|public|override|lateinit|@\w+)\s+)*(val|var)\s+(?:\w+\.)?(\w+)\b")
FUN = re.compile(r"^\s*(?:(?:private|internal|protected|public|override|inline|suspend)\s+)*fun\s+(?:<[^>]*>\s*)?(\w+)\s*\(([^)]*)\)")


def strip(s: str) -> str:
    s = re.sub(r"/\*.*?\*/", lambda m: re.sub(r"[^\n]", " ", m.group()), s, flags=re.S)
    s = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', s)
    return re.sub(r"//[^\n]*", "", s)


def members(text: str, open_idx: int):
    """Lines at depth 1 of the block that opens at open_idx."""
    depth, line, out = 0, [], []
    for ch in text[open_idx:]:
        if ch == "{":
            depth += 1
            if depth > 1: line.append(" ")
            continue
        if ch == "}":
            depth -= 1
            if depth == 0: break
            continue
        if depth == 1:
            if ch == "\n": out.append("".join(line)); line = []
            else: line.append(ch)
        elif ch == "\n" and depth > 1:
            pass
    out.append("".join(line))
    return out


def check_text(text: str, name: str = "") -> list[str]:
    text = strip(text)
    problems = []
    for m in CLASS.finditer(text):
        props, funs = {}, []
        for ln in members(text, m.end() - 1):
            p = PROP.match(ln)
            if p: props[p.group(2)] = p.group(1)
            f = FUN.match(ln)
            if f: funs.append((f.group(1), f.group(2).strip()))
        for fn, params in funs:
            if fn.startswith("set") and len(fn) > 3 and params and "," not in params:
                prop = fn[3].lower() + fn[4:]
                if props.get(prop) == "var":
                    problems.append(f"{name}: class {m.group(1)}: `var {prop}` and `fun {fn}(…)` share the JVM name {fn}")
            if fn.startswith("get") and len(fn) > 3 and not params:
                prop = fn[3].lower() + fn[4:]
                if prop in props:
                    problems.append(f"{name}: class {m.group(1)}: `{props[prop]} {prop}` and `fun {fn}()` share the JVM name {fn}")
    return problems


def main() -> int:
    bad = []
    for d, _, files in os.walk(SRC):
        for f in files:
            if f.endswith(".kt"):
                p = os.path.join(d, f)
                bad += check_text(open(p, encoding="utf-8").read(), os.path.relpath(p, ROOT))
    for b in bad: print(b)
    print(f"kt_accessor_clash: {len(bad)} problems" if bad else "kt_accessor_clash: no clashes")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
