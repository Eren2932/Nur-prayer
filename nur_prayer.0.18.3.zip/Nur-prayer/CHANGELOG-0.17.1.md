# Nur 0.17.1 — исправление сборки 0.17.0

## Причина падения CI
`:app:compileDebugKotlin` и `:app:compileReleaseKotlin`, `Quran.kt`: `Platform declaration clash`.
В `QuranStore` свойства `var translationSize … private set` и `var keepAwake … private set` уже владеют
JVM-методами `setTranslationSize(I)V` и `setKeepAwake(Z)V`. Рядом лежали одноимённые функции — компилятор
не позволяет иметь оба, даже если сеттер свойства приватный. Других ошибок в логе нет: разбор типов и
символов компилятор прошёл, упала только генерация кода.

## Исправление
- `setTranslationSize` → `setTranslationTextSize`, `setKeepAwake` → `setAwake` (`Quran.kt`, `QuranReader.kt`).
  Поведение и сохранённые настройки не менялись.

## Чтобы не повторилось
- `tools/kt_accessor_clash.py`: в теле класса `var name` рядом с `fun setName(x)` и `val/var name` рядом
  с `fun getName()` — ошибка до Gradle. На исходниках 0.17.0 находит обе коллизии из лога.
  Проверка и её тест (`test_kt_accessor_clash.py`, 7 случаев) включены в шаг «Static and data checks».
- versionCode 39.
