package com.nur.prayer.ui.quran

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * 0.18.0. An ayah as a picture: the Arabic, the translation, the reference and a quiet «Nur», in
 * the colours of the reader's current surface. Drawn straight onto a Bitmap — no view tree, no
 * dependency — 1080 px wide with 80 px margins, as tall as the text needs.
 */
internal class AyahCard(
    val arabic: String,
    val translation: String?,
    val caption: String,
    val colors: QuranColors
)

internal object AyahImageShare {
    const val WIDTH = 1080
    const val MARGIN = 80
    /** A card is never shorter than a square: one short ayah must not become a strip. */
    private const val MIN_HEIGHT = 1080
    private const val PAD_TOP = 130
    private const val PAD_BOTTOM = 110
    private const val MAX_ARABIC_HEIGHT = 2000
    private const val MAX_TRANSLATION_HEIGHT = 1500
    private const val FILE_NAME = "ayah.png"

    // «Небо» has no background of its own; the card then takes the same deep dusk the sky theme sits on.
    private val SKY_TOP = AColor.rgb(0x2B, 0x24, 0x5E)
    private val SKY_BOTTOM = AColor.rgb(0x12, 0x10, 0x2C)

    fun authority(context: Context): String = context.packageName + ".share"

    fun render(card: AyahCard): Bitmap {
        val width = WIDTH - 2 * MARGIN
        val c = card.colors
        val textColor = c.text.toArgb()
        val quiet = c.textSecondary.toArgb()
        val accent = c.accent.toArgb()
        val top = if (c.sky) SKY_TOP else c.background.toArgb()
        val bottom = if (c.sky) SKY_BOTTOM else c.backgroundBottom.toArgb()

        // The Arabic is shrunk until it fits: the longest ayah of al-Baqarah is a tall column at 72 px.
        var arabicSize = 72f
        var arabic = layout(card.arabic, paint(arabicSize, textColor, bold = false), width, rtl = true, spacing = 1.65f)
        while (arabic.height > MAX_ARABIC_HEIGHT && arabicSize > 36f) {
            arabicSize -= 4f
            arabic = layout(card.arabic, paint(arabicSize, textColor, bold = false), width, rtl = true, spacing = 1.65f)
        }
        var translation: StaticLayout? = null
        card.translation?.takeIf { it.isNotBlank() }?.let { text ->
            var size = 40f
            var l = layout(text, paint(size, quiet, bold = false), width, rtl = false, spacing = 1.4f)
            while (l.height > MAX_TRANSLATION_HEIGHT && size > 28f) {
                size -= 2f
                l = layout(text, paint(size, quiet, bold = false), width, rtl = false, spacing = 1.4f)
            }
            translation = l
        }
        val caption = layout(card.caption, paint(34f, accent, bold = true), width, rtl = false, spacing = 1.2f)
        val mark = paint(34f, accent, bold = true).apply { letterSpacing = 0.3f; alpha = 150 }
        val markText = "Nur"
        val markHeight = mark.fontMetrics.let { it.descent - it.ascent }

        val gap = 64
        val divider = 40
        var content = arabic.height + gap + divider
        translation?.let { content += gap + it.height }
        content += gap + caption.height
        val total = PAD_TOP + content + gap + markHeight.toInt() + PAD_BOTTOM
        val height = maxOf(MIN_HEIGHT, total)

        val bitmap = Bitmap.createBitmap(WIDTH, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawRect(0f, 0f, WIDTH.toFloat(), height.toFloat(),
            Paint().apply { shader = LinearGradient(0f, 0f, 0f, height.toFloat(), top, bottom, Shader.TileMode.CLAMP) })

        // Short text sits in the optical middle of the square; long text starts at the top margin.
        var y = PAD_TOP + (height - total) / 2f
        canvas.save(); canvas.translate(MARGIN.toFloat(), y); arabic.draw(canvas); canvas.restore()
        y += arabic.height + gap
        drawDivider(canvas, y + divider / 2f, accent, c.hairline.toArgb())
        y += divider
        translation?.let {
            y += gap
            canvas.save(); canvas.translate(MARGIN.toFloat(), y); it.draw(canvas); canvas.restore()
            y += it.height
        }
        y += gap
        canvas.save(); canvas.translate(MARGIN.toFloat(), y); caption.draw(canvas); canvas.restore()
        y += caption.height + gap
        val markWidth = mark.measureText(markText)
        canvas.drawText(markText, (WIDTH - markWidth) / 2f, y - mark.fontMetrics.ascent, mark)
        return bitmap
    }

    /** Writes the card to cacheDir/share/ayah.png and hands it to the share sheet. */
    suspend fun share(context: Context, card: AyahCard): Boolean {
        val file = withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(context.cacheDir, "share").apply { mkdirs() }
                val out = File(dir, FILE_NAME)
                val bitmap = render(card)
                try {
                    out.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                } finally {
                    bitmap.recycle()
                }
                out
            }.getOrNull()
        } ?: return false
        return runCatching {
            val uri = FileProvider.getUriForFile(context, authority(context), file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.isSuccess
    }

    private fun paint(size: Float, color: Int, bold: Boolean) = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
        textSize = size
        this.color = color
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun layout(text: String, paint: TextPaint, width: Int, rtl: Boolean, spacing: Float): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(if (rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
            .setLineSpacing(0f, spacing)
            .setIncludePad(true)
            .setBreakStrategy(Layout.BREAK_STRATEGY_BALANCED)
            .build()

    /** ──── ◆ ────: a hairline with a diamond, the card's only ornament. */
    private fun drawDivider(canvas: Canvas, cy: Float, accent: Int, hairline: Int) {
        val mid = WIDTH / 2f
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = hairline; strokeWidth = 2f }
        canvas.drawLine(MARGIN.toFloat() + 120f, cy, mid - 36f, cy, line)
        canvas.drawLine(mid + 36f, cy, WIDTH - MARGIN - 120f, cy, line)
        val d = Path().apply { moveTo(mid, cy - 12f); lineTo(mid + 12f, cy); lineTo(mid, cy + 12f); lineTo(mid - 12f, cy); close() }
        canvas.drawPath(d, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent })
    }
}
