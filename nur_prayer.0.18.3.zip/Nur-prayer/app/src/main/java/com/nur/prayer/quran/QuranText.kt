package com.nur.prayer.quran

/**
 * 0.18.0. Text shapes of an ayah that are not stored anywhere: the folded forms the search runs on
 * and the first-letter mask of the hifz mode. Pure and unit-tested (QuranTextTest).
 */
object QuranText {
    /** Tanzil "simple" Arabic: harakat, sukun, shadda, superscript alef, Quranic annotation marks, tatweel. */
    fun isMark(c: Char): Boolean =
        c in '\u0610'..'\u061A' || c in '\u064B'..'\u065F' || c == '\u0670' || c in '\u06D6'..'\u06ED' || c == '\u0640'

    fun hasArabic(text: String): Boolean = text.any { it in '\u0621'..'\u064A' || it == '\u0671' }

    /** Letters people type interchangeably: every alef as ا, alef maqsura as ي, ta marbuta as ه. */
    private fun baseLetter(c: Char): Char = when (c) {
        'آ', 'أ', 'إ', 'ٱ' -> 'ا'
        'ى', 'ئ' -> 'ي'
        'ة' -> 'ه'
        'ؤ' -> 'و'
        else -> c
    }

    /** Arabic without vowels and marks, letter variants unified, one space between words. */
    fun foldArabic(text: String): String = foldArabicMapped(text).first

    /**
     * [foldArabic] plus, for every folded character, the index of the original character it came
     * from: a match in the folded text is highlighted on the vowelled one.
     */
    fun foldArabicMapped(text: String): Pair<String, IntArray> {
        val out = StringBuilder(text.length)
        val map = IntArray(text.length)
        var n = 0
        for ((i, raw) in text.withIndex()) {
            if (isMark(raw)) continue
            if (raw.isWhitespace()) {
                if (out.isEmpty() || out[out.length - 1] == ' ') continue
                out.append(' '); map[n++] = i
                continue
            }
            out.append(baseLetter(raw)); map[n++] = i
        }
        if (out.isNotEmpty() && out[out.length - 1] == ' ') { out.setLength(out.length - 1); n-- }
        return out.toString() to map.copyOf(n)
    }

    /**
     * Lower case one character at a time, so the folded translation keeps the length — and the
     * offsets — of the shown one. ё/е and the Uzbek ‘okina/apostrophe variants are made equal;
     * Turkish İ becomes i (String.lowercase would turn it into two characters).
     */
    fun foldLatin(text: String): String {
        val out = CharArray(text.length)
        for ((i, c) in text.withIndex()) {
            out[i] = when (c) {
                'ё', 'Ё' -> 'е'
                'İ' -> 'i'
                'ʻ', 'ʼ', '‘', '’', '`', 'ʹ' -> '\''
                else -> Character.toLowerCase(c)
            }
        }
        return String(out)
    }

    /** The word as the particle table knows it: no marks, ٱ as ا. One character per letter of [word]. */
    fun bare(word: String): String {
        val out = StringBuilder(word.length)
        for (c in word) if (!isMark(c)) out.append(if (c == '\u0671') '\u0627' else c)
        return out.toString()
    }

    /** One run of the hifz text: shown as it is, or [hidden] — a mask to be painted quieter. */
    data class HintPart(val text: String, val hidden: Boolean)

    /**
     * 0.18.3 hifz «первые буквы». Every word keeps the start a hafiz recalls it by, the rest becomes
     * a kashida bar as long as the hidden letters (two tatweels a letter: an average letter of Noto
     * Naskh is 2.04 tatweels wide), so فِي and فَزَادَهُمُ no longer look the same.
     *
     * The start is the word's own first letter with its vowels, after
     *  - joined particles from [particles] (و ف ب ل ك, up to two: وَإِذَا → وَإِ, وَبِالْآخِرَةِ → وَبِالْآ),
     *    the table built from the Quran text itself by tools/hifz_hints.py;
     *  - the article ال, or the ل left of it after li (لِلنَّاسِ → لِلنَّ);
     *  - a bare hamzat al-wasl alef, which is not pronounced (اهْدِنَا → اهْ).
     * At least one letter is always hidden. One-letter words, stand-alone pause marks and the
     * muqatta'at opening a surah (الم, حم, …) stay as they are.
     * tools/hifz_hints.py has the same algorithm; QuranTextSearchTest compares the two on golden ayat.
     */
    fun firstLetterParts(text: String, particles: Map<String, Int> = emptyMap()): List<HintPart> {
        val out = ArrayList<HintPart>()
        for ((i, word) in text.split(' ').withIndex()) {
            if (i > 0) out += HintPart(" ", false)
            maskWord(word, particles, opening = i == 0, out)
        }
        return out
    }

    fun firstLetters(text: String, particles: Map<String, Int> = emptyMap()): String =
        firstLetterParts(text, particles).joinToString("") { it.text }

    private fun maskWord(word: String, particles: Map<String, Int>, opening: Boolean, out: MutableList<HintPart>) {
        val letters = word.indices.filter { !isMark(word[it]) }
        val b = bare(word)
        if (letters.size <= 1 || (opening && b in MUQATTAAT)) {
            out += HintPart(word, false)
            return
        }
        val n = (particles[b] ?: 0).coerceIn(0, letters.size - 1)
        val rest = b.substring(n)
        var keep = n
        if (rest.length >= 4 && rest.startsWith("\u0627\u0644")) keep += 2
        else if (n > 0 && b[n - 1] == '\u0644' && rest.length >= 3 && rest[0] == '\u0644') keep += 1
        keep += 1
        if (keep - 1 == n && b[n] == '\u0627' && !(letters[n] + 1 < word.length && isMark(word[letters[n] + 1]))) keep += 1
        keep = minOf(keep, letters.size - 1)
        val hidden = letters.size - keep
        out += HintPart(word.substring(0, letters[keep]), false)
        out += HintPart(MASK_CHAR.toString().repeat((hidden * MASK_PER_LETTER).coerceIn(MASK_MIN, MASK_MAX)), true)
    }

    /** particles.tsv: «N<TAB>bare word» per line. Anything malformed is skipped, not fatal. */
    fun parseParticles(tsv: String): Map<String, Int> {
        val out = HashMap<String, Int>(4096)
        for (line in tsv.lineSequence()) {
            val tab = line.indexOf('\t')
            if (tab <= 0) continue
            val n = line.substring(0, tab).toIntOrNull() ?: continue
            if (n in 1..2 && tab + 1 < line.length) out[line.substring(tab + 1)] = n
        }
        return out
    }

    const val PARTICLES_ASSET = "hifz/particles.tsv"
    const val MASK_CHAR = '\u0640'
    const val MASK_PER_LETTER = 2
    const val MASK_MIN = 2
    const val MASK_MAX = 24

    /** The disconnected letters opening 29 surahs: read letter by letter, they are their own hint. */
    private val MUQATTAAT = setOf(
        "\u0627\u0644\u0645", "\u0627\u0644\u0645\u0635", "\u0627\u0644\u0631", "\u0627\u0644\u0645\u0631",
        "\u0643\u0647\u064A\u0639\u0635", "\u0637\u0647", "\u0637\u0633\u0645", "\u0637\u0633",
        "\u064A\u0633", "\u062D\u0645", "\u0639\u0633\u0642"
    )
}

/**
 * 0.18.0 hifz switch in the reader's bar. A hidden ayah opens by a tap on it; see [QuranText.firstLetters].
 */
enum class HifzMode {
    OFF, FIRST_LETTERS, HIDE_ARABIC, HIDE_TRANSLATION;

    companion object {
        fun of(ordinal: Int): HifzMode = entries.getOrElse(ordinal) { OFF }
    }
}
