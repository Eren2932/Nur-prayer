package com.nur.prayer.quran

import android.content.Context
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/**
 * One surah of the mushaf. [start] is the global index (0-based) of its first ayah, so the 6236
 * ayat are numbered without gaps; it comes from the Tanzil metadata like everything else here.
 */
data class SurahMeta(
    val number: Int,
    val arabic: String,
    val latin: String,
    val ru: String,
    val meaningRu: String,
    val english: String,
    val ayat: Int,
    val medinan: Boolean,
    val start: Int
)

/** The translations shipped in assets/quran/NNN.tsv, each under its own column. */
enum class QuranTranslation(val code: String, val label: String, val author: String) {
    RU("ru", "Русский", "Эльмир Кулиев"),
    EN("en", "English", "Saheeh International"),
    TR("tr", "Türkçe", "Diyanet İşleri"),
    UZ("uz", "Oʻzbekcha", "Muhammad Sodiq Muhammad Yusuf");

    companion object {
        fun of(code: String?): QuranTranslation? = entries.firstOrNull { it.code == code }
    }
}

class QuranAyah(
    val surah: Int,
    val number: Int,
    val arabic: String,
    /** Russian scientific reading (ҳ, һ, ‘), the one the azkar and the course use. */
    val translit: String,
    /** The same reading in Latin letters (ḥ, h, ʿ) for the non-Cyrillic interfaces. */
    val latin: String,
    private val translations: Map<QuranTranslation, String>
) {
    fun translation(t: QuranTranslation?): String? = t?.let { translations[it] }
    val key: Int get() = surah * 1000 + number
}

/** Where a reader stopped. */
data class QuranMark(val surah: Int, val ayah: Int)

/** Pure functions over the index: no Android, unit-tested on the JVM. */
object QuranMath {
    private val CYRILLIC_UI = setOf("ru", "kk", "ky", "tt", "tg")

    fun surah(number: Int): SurahMeta = QuranIndex.SURAHS[(number.coerceIn(1, QuranIndex.SURAH_COUNT)) - 1]

    /** Juz 1..30 that contains [surah]:[ayah]. */
    fun juzOf(surah: Int, ayah: Int): Int {
        val key = surah * 1000 + ayah
        var juz = 1
        for (i in QuranIndex.JUZ.indices) if (QuranIndex.JUZ[i] <= key) juz = i + 1
        return juz
    }

    /** The juz that starts exactly at this ayah, or 0. */
    fun juzStartingAt(surah: Int, ayah: Int): Int = QuranIndex.JUZ.indexOf(surah * 1000 + ayah) + 1

    fun isSajda(surah: Int, ayah: Int): Boolean = (surah * 1000 + ayah) in QuranIndex.SAJDA

    /** Basmala is read before every surah except at-Tawba; in al-Fatiha it is the first ayah itself. */
    fun showsBasmala(surah: Int): Boolean = surah != 1 && surah != 9

    /** The translation a reader sees before choosing one: the interface language when we ship it. */
    fun defaultTranslation(uiLanguage: String): QuranTranslation? = when (uiLanguage) {
        "ar" -> null
        "en", "id" -> QuranTranslation.EN
        "tr", "az" -> QuranTranslation.TR
        "uz" -> QuranTranslation.UZ
        else -> QuranTranslation.RU
    }

    /** Cyrillic reading for the Cyrillic interfaces, Latin for the rest. */
    fun latinReading(uiLanguage: String): Boolean = uiLanguage !in CYRILLIC_UI

    /** Surah name as the interface language writes it. */
    fun title(s: SurahMeta, uiLanguage: String): String = when {
        uiLanguage == "ar" -> s.arabic
        uiLanguage in CYRILLIC_UI -> s.ru
        else -> s.latin
    }

    /** What the name means; empty for Arabic (the name says it) and when it equals the title. */
    fun meaning(s: SurahMeta, uiLanguage: String): String = when {
        uiLanguage == "ar" -> ""
        uiLanguage in CYRILLIC_UI -> if (s.meaningRu == s.ru) "" else s.meaningRu
        else -> if (s.english == s.latin) "" else s.english
    }

    /** "2:255", "2 255", "2.255" → that ayah, when it exists. */
    fun parseReference(query: String): QuranMark? {
        val m = Regex("""^\s*(\d{1,3})\s*[:.\s]\s*(\d{1,3})\s*$""").find(query) ?: return null
        val s = m.groupValues[1].toInt()
        val a = m.groupValues[2].toInt()
        if (s !in 1..QuranIndex.SURAH_COUNT || a !in 1..surah(s).ayat) return null
        return QuranMark(s, a)
    }

    /**
     * Lower case without apostrophes, hyphens, spaces, soft signs and ‘ayn marks, doubled letters
     * once: "ал ихлас", "ikhlas" and "Al-Ikhlaas" all fold to something "ихлас"/"ikhlas" is part of.
     */
    fun fold(text: String): String = buildString {
        for (raw in text.lowercase()) {
            val ch = when (raw) {
                'ё' -> 'е'
                '\'', '‘', '’', 'ʿ', 'ʾ', '`', '-', ' ', '_', 'ь', 'ъ' -> continue
                else -> raw
            }
            if (isNotEmpty() && last() == ch) continue
            append(ch)
        }
    }

    /** Surahs matching a number, any of their names, or what the name means. Mushaf order is kept. */
    fun search(query: String): List<SurahMeta> {
        val q = query.trim()
        if (q.isEmpty()) return QuranIndex.SURAHS
        parseReference(q)?.let { return listOf(surah(it.surah)) }
        parsePage(q)?.let { return listOf(surah(pageStart(it).surah)) }
        q.toIntOrNull()?.let { n -> return QuranIndex.SURAHS.filter { it.number == n } }
        val f = fold(q)
        return QuranIndex.SURAHS.filter { s ->
            listOf(s.ru, s.meaningRu, s.latin, s.english, s.arabic).any { fold(it).contains(f) }
        }
    }

    /**
     * One surah file: a header naming the columns, then one ayah per line. Columns are found by
     * name, so adding a translation never shifts the others.
     */
    fun parse(surah: Int, tsv: String): List<QuranAyah> {
        val lines = tsv.lineSequence().filter { it.isNotEmpty() }.toList()
        if (lines.isEmpty()) return emptyList()
        val header = lines.first().split('\t')
        fun col(name: String) = header.indexOf(name)
        val iAyah = col("ayah"); val iAr = col("arabic"); val iTr = col("translit"); val iLat = col("latin")
        val iTrans = QuranTranslation.entries.associateWith { col(it.code) }.filterValues { it >= 0 }
        if (iAyah < 0 || iAr < 0) return emptyList()
        return lines.drop(1).mapNotNull { line ->
            val c = line.split('\t')
            val n = c.getOrNull(iAyah)?.toIntOrNull() ?: return@mapNotNull null
            val ar = c.getOrNull(iAr).orEmpty()
            if (ar.isEmpty()) return@mapNotNull null
            QuranAyah(
                surah, n, ar, c.getOrNull(iTr).orEmpty(), c.getOrNull(iLat).orEmpty(),
                iTrans.mapNotNull { (t, i) -> c.getOrNull(i)?.takeIf { it.isNotEmpty() }?.let { t to it } }.toMap()
            )
        }
    }

    fun asset(surah: Int): String = "quran/%03d.tsv".format(surah)

    // ── 0.18.0: the Madani mushaf layout. Pure and unit-tested (QuranKhatmTest). ────────────────

    /** Page of the 604-page Madani mushaf this ayah is printed on. */
    fun pageOf(surah: Int, ayah: Int): Int {
        val i = QuranIndex.PAGE_STARTS.binarySearch(surah * 1000 + ayah)
        // Not a page start: the insertion point is the index of the next page, i.e. this page's number.
        return (if (i >= 0) i + 1 else -i - 1).coerceIn(1, QuranIndex.PAGE_COUNT)
    }

    /** First ayah printed on [page] (1..604). */
    fun pageStart(page: Int): QuranMark {
        val key = QuranIndex.PAGE_STARTS[page.coerceIn(1, QuranIndex.PAGE_COUNT) - 1]
        return QuranMark(key / 1000, key % 1000)
    }

    /**
     * Pages fully read once the reader has finished ayah [ayah] of [surah]: the page before the one
     * the next ayah is printed on. Finishing the last ayah of an-Nas is all 604.
     */
    fun pagesCompleted(surah: Int, ayah: Int): Int {
        val s = surah(surah)
        val next = when {
            ayah < s.ayat -> s.number * 1000 + ayah + 1
            s.number < QuranIndex.SURAH_COUNT -> (s.number + 1) * 1000 + 1
            else -> return QuranIndex.PAGE_COUNT
        }
        return pageOf(next / 1000, next % 1000) - 1
    }

    /** The page that begins with this ayah, 0 when the ayah is not the first one of a page. */
    fun pageStartingAt(surah: Int, ayah: Int): Int {
        val i = QuranIndex.PAGE_STARTS.binarySearch(surah * 1000 + ayah)
        return if (i >= 0) i + 1 else 0
    }

    /**
     * The rub' al-hizb (0..239) that begins with this ayah, -1 otherwise. Quarter q is hizb q/4+1,
     * and q%4 quarters into it: 0 — the hizb itself starts here, 1 — ¼, 2 — ½, 3 — ¾.
     */
    fun quarterStartingAt(surah: Int, ayah: Int): Int {
        val i = QuranIndex.HIZB_STARTS.binarySearch(surah * 1000 + ayah)
        return if (i >= 0) i else -1
    }

    /** "¼", "½", "¾" for the quarters inside a hizb, "" for its start. */
    fun quarterFraction(quarter: Int): String = when (quarter % 4) {
        1 -> "¼"
        2 -> "½"
        3 -> "¾"
        else -> ""
    }

    /**
     * "p42", "с42", "стр 42", "page 42", "sayfa 42", "bet 42", "ص 42" → that page of the mushaf.
     * A bare number stays a surah: it is what people mean by it.
     */
    fun parsePage(query: String): Int? {
        val m = PAGE_QUERY.find(query.trim()) ?: return null
        val n = m.groupValues[1].toIntOrNull() ?: return null
        return n.takeIf { it in 1..QuranIndex.PAGE_COUNT }
    }

    private val PAGE_QUERY = Regex(
        """^(?:p|pg|page|п|с|стр|страница|sayfa|sahifa|bet|ص|صفحة)\s*\.?\s*(\d{1,3})$""",
        RegexOption.IGNORE_CASE
    )

    // ── 0.17.0: navigation math of the reader. Pure and unit-tested (QuranTest). ──────────────────

    /** 0-based place of [surah]:[ayah] among all 6236 ayat, in mushaf order. */
    fun globalIndex(surah: Int, ayah: Int): Int {
        val s = surah(surah)
        return s.start + ayah.coerceIn(1, s.ayat) - 1
    }

    /** Share of the whole Quran read up to and including this ayah: 1:1 → 1/6236, 114:6 → 1. */
    fun quranProgress(surah: Int, ayah: Int): Float =
        (globalIndex(surah, ayah) + 1).toFloat() / QuranIndex.AYAH_COUNT

    /** First ayah of juz [juz] (1..30). */
    fun juzStart(juz: Int): QuranMark {
        val key = QuranIndex.JUZ[juz.coerceIn(1, QuranIndex.JUZ.size) - 1]
        return QuranMark(key / 1000, key % 1000)
    }

    /** Last ayah of juz [juz]: the ayah right before the next juz starts, 114:6 for the thirtieth. */
    fun juzEnd(juz: Int): QuranMark {
        val j = juz.coerceIn(1, QuranIndex.JUZ.size)
        if (j == QuranIndex.JUZ.size) return QuranMark(QuranIndex.SURAH_COUNT, surah(QuranIndex.SURAH_COUNT).ayat)
        val next = juzStart(j + 1)
        if (next.ayah > 1) return QuranMark(next.surah, next.ayah - 1)
        val previous = surah(next.surah - 1)
        return QuranMark(previous.number, previous.ayat)
    }

    /** Number of ayat in juz [juz]. */
    fun juzAyat(juz: Int): Int {
        val a = juzStart(juz); val b = juzEnd(juz)
        return globalIndex(b.surah, b.ayah) - globalIndex(a.surah, a.ayah) + 1
    }

    /** How far into its juz this ayah is, (0..1]: the last ayah of a juz gives exactly 1. */
    fun juzProgress(surah: Int, ayah: Int): Float {
        val juz = juzOf(surah, ayah)
        val a = juzStart(juz)
        return (globalIndex(surah, ayah) - globalIndex(a.surah, a.ayah) + 1).toFloat() / juzAyat(juz)
    }

    /**
     * Reading position in a surah list where item 0 is the surah header and item n is ayah n:
     * the index of the first item under the reading line plus how much of it has scrolled away.
     * Header → 1, past the last ayah (the footer) → [ayat].
     */
    fun readingPosition(firstIndex: Int, offsetFraction: Float, ayat: Int): Float = when {
        ayat <= 0 -> 0f
        firstIndex <= 0 -> 1f
        firstIndex >= ayat -> ayat.toFloat()
        else -> firstIndex + offsetFraction.coerceIn(0f, 1f)
    }

    /** Share of a surah read: (position − 1) / ayat, and exactly 1 when the list is at its end. */
    fun surahProgress(position: Float, ayat: Int, atEnd: Boolean): Float = when {
        atEnd -> 1f
        ayat <= 0 -> 0f
        else -> ((position - 1f) / ayat).coerceIn(0f, 1f)
    }

    /** Ayah 1..[ayat] under a fast-scroll thumb at [fraction] of its track: the ends are exact. */
    fun ayahAt(fraction: Float, ayat: Int): Int =
        if (ayat <= 1) 1 else (fraction.coerceIn(0f, 1f) * (ayat - 1)).roundToInt() + 1

    /** Where on the track (0..1) a reading [position] sits; the inverse of [ayahAt]. */
    fun trackFraction(position: Float, ayat: Int): Float =
        if (ayat <= 1) 0f else ((position - 1f) / (ayat - 1)).coerceIn(0f, 1f)

    /**
     * «Перейти к аяту»: a bare number is an ayah of the open surah, "2:255" (or "2 255", "2.255")
     * any ayah of the Quran, "с42"/"p42" the first ayah of a mushaf page. Null when it does not exist.
     */
    fun resolveJump(query: String, currentSurah: Int): QuranMark? {
        parseReference(query)?.let { return it }
        parsePage(query)?.let { return pageStart(it) }
        val n = query.trim().toIntOrNull() ?: return null
        val s = surah(currentSurah)
        return if (n in 1..s.ayat) QuranMark(s.number, n) else null
    }

    /** Ayah number in Arabic-Indic digits, as the mushaf prints it after the ayah: 255 → ٢٥٥. */
    fun arabicDigits(n: Int): String = buildString { for (d in n.toString()) append(if (d in '0'..'9') Char(0x0660 + (d - '0')) else d) }

    /**
     * The reader pages through surahs right to left, like a mushaf: al-Fatiha on the right, the
     * next surah to its left. A pager follows the layout direction, so in a left-to-right
     * interface it has to be reversed and in an Arabic one it already runs right to left.
     */
    fun mushafPagerReversed(rtlLayout: Boolean): Boolean = !rtlLayout

    /** A bookmark key surah×1000+ayah that names a real ayah. */
    fun isAyahKey(key: Int): Boolean {
        val s = key / 1000; val a = key % 1000
        return s in 1..QuranIndex.SURAH_COUNT && a in 1..surah(s).ayat
    }

    /** Bookmarks as stored ("2255,18010"): valid keys only, unique, newest first, at most [MAX_BOOKMARKS]. */
    fun parseBookmarks(raw: String?): List<Int> =
        raw.orEmpty().split(',').mapNotNull { it.trim().toIntOrNull() }.filter { isAyahKey(it) }.distinct().take(MAX_BOOKMARKS)

    /** Adds [key] on top, or removes it when it is already there. */
    fun toggleBookmark(list: List<Int>, key: Int): List<Int> =
        if (key in list) list - key else (listOf(key) + list).take(MAX_BOOKMARKS)

    const val MAX_BOOKMARKS = 300

    /**
     * Splits a translation into the words of the translator and his remarks in parentheses, so the
     * remarks can be drawn quieter. Returns (text, isRemark) runs; unbalanced brackets end the remark.
     */
    fun remarks(text: String): List<Pair<String, Boolean>> {
        val out = ArrayList<Pair<String, Boolean>>()
        val sb = StringBuilder()
        var depth = 0
        for (ch in text) {
            if (ch == '(' && depth == 0) {
                if (sb.isNotEmpty()) { out += sb.toString() to false; sb.clear() }
                depth = 1; sb.append(ch)
            } else if (ch == '(') {
                depth++; sb.append(ch)
            } else if (ch == ')' && depth > 0) {
                sb.append(ch); depth--
                if (depth == 0) { out += sb.toString() to true; sb.clear() }
            } else sb.append(ch)
        }
        if (sb.isNotEmpty()) out += sb.toString() to (depth > 0)
        return out
    }
}

/** Reads one surah at a time from the APK; the last few stay in memory for swiping back and forth. */
class QuranRepository private constructor(private val context: Context) {
    private val cache = LruCache<Int, List<QuranAyah>>(8)

    fun cached(surah: Int): List<QuranAyah>? = cache.get(surah)

    /**
     * 0.18.3: the hifz particle table of [QuranText.firstLetterParts] (assets/hifz/particles.tsv,
     * ~2.7k short lines). Compose state: null until [loadHifzParticles] has read it once.
     */
    var hifzParticles by mutableStateOf<Map<String, Int>?>(null)
        private set

    suspend fun loadHifzParticles(): Map<String, Int> {
        hifzParticles?.let { return it }
        val table = withContext(Dispatchers.IO) {
            runCatching {
                context.assets.open(QuranText.PARTICLES_ASSET).bufferedReader().use { QuranText.parseParticles(it.readText()) }
            }.getOrDefault(emptyMap())
        }
        hifzParticles = table
        return table
    }

    suspend fun surah(surah: Int): List<QuranAyah> {
        cache.get(surah)?.let { return it }
        val ayat = withContext(Dispatchers.IO) {
            runCatching {
                context.assets.open(QuranMath.asset(surah)).bufferedReader().use { QuranMath.parse(surah, it.readText()) }
            }.getOrDefault(emptyList())
        }
        if (ayat.isNotEmpty()) cache.put(surah, ayat)
        return ayat
    }

    companion object {
        @Volatile private var instance: QuranRepository? = null
        fun get(context: Context): QuranRepository =
            instance ?: synchronized(this) { instance ?: QuranRepository(context.applicationContext).also { instance = it } }
    }
}

/**
 * Reader preferences and the bookmark: its own small SharedPreferences file. Values are Compose
 * state, so the today tile and the reader follow one another without a view model in between.
 */
class QuranStore private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("nur_quran", Context.MODE_PRIVATE)

    var showReading by mutableStateOf(prefs.getBoolean(K_READING, true))
        private set
    /** null: follow the interface language. */
    var translationCode by mutableStateOf(prefs.getString(K_TRANSLATION, null))
        private set
    var arabicSize by mutableStateOf(prefs.getInt(K_SIZE, 1).coerceIn(0, SIZES.lastIndex))
        private set
    var mark by mutableStateOf(readMark())
        private set
    /** 0.17.0 reading surface: [THEME_NIGHT] (default), [THEME_BLACK] or [THEME_SKY] (the old look). */
    var readerTheme by mutableStateOf(prefs.getInt(K_THEME, THEME_NIGHT).coerceIn(THEME_NIGHT, THEME_SKY))
        private set
    var translationSize by mutableStateOf(prefs.getInt(K_TR_SIZE, 1).coerceIn(0, TRANSLATION_SIZES.lastIndex))
        private set
    /** The screen stays on while the reader is open. */
    var keepAwake by mutableStateOf(prefs.getBoolean(K_AWAKE, true))
        private set
    /** Ayah keys (surah×1000+ayah), newest first. */
    var bookmarks by mutableStateOf(QuranMath.parseBookmarks(prefs.getString(K_BOOKMARKS, null)))
        private set

    /** 0.18.0. The khatm plan, null while there is none. Compose state: the tile and the card follow it. */
    var khatm by mutableStateOf(readKhatm())
        private set

    private fun readKhatm(): KhatmPlan? = KhatmPlan.restore(
        active = prefs.getBoolean(K_KHATM, false),
        startDay = prefs.getLong(K_KHATM_START_DAY, 0L),
        targetDays = prefs.getInt(K_KHATM_DAYS, 0),
        startPage = prefs.getInt(K_KHATM_FROM, 0),
        lastPage = prefs.getInt(K_KHATM_LAST, 0),
        todayDay = prefs.getLong(K_KHATM_TODAY_DAY, 0L),
        todayPages = prefs.getInt(K_KHATM_TODAY, 0)
    )

    private fun saveKhatm(plan: KhatmPlan?) {
        khatm = plan
        prefs.edit().apply {
            if (plan == null) {
                putBoolean(K_KHATM, false).remove(K_KHATM_START_DAY).remove(K_KHATM_DAYS).remove(K_KHATM_FROM)
                    .remove(K_KHATM_LAST).remove(K_KHATM_TODAY_DAY).remove(K_KHATM_TODAY)
            } else {
                putBoolean(K_KHATM, true).putLong(K_KHATM_START_DAY, plan.startDay).putInt(K_KHATM_DAYS, plan.targetDays)
                    .putInt(K_KHATM_FROM, plan.startPage).putInt(K_KHATM_LAST, plan.lastPage)
                    .putLong(K_KHATM_TODAY_DAY, plan.todayDay).putInt(K_KHATM_TODAY, plan.todayPages)
            }
        }.apply()
    }

    /** A new plan from [fromPage] pages done (0: the whole Quran), replacing any earlier one. */
    fun startKhatm(targetDays: Int, fromPage: Int, today: Long) = saveKhatm(KhatmPlan.start(today, targetDays, fromPage))

    /** The reader finished [completedPage] pages; see [KhatmPlan.credited] for what counts. */
    fun creditKhatm(completedPage: Int, today: Long) {
        val plan = khatm ?: return
        val next = plan.credited(completedPage, today)
        if (next != plan) saveKhatm(next)
    }

    /** The reader's own correction of where he is, forward or back. */
    fun moveKhatm(page: Int, today: Long) {
        val plan = khatm ?: return
        val next = plan.movedTo(page, today)
        if (next != plan) saveKhatm(next)
    }

    fun stopKhatm() = saveKhatm(null)

    private fun readMark(): QuranMark? {
        val s = prefs.getInt(K_SURAH, 0)
        val a = prefs.getInt(K_AYAH, 0)
        return if (s in 1..QuranIndex.SURAH_COUNT && a in 1..QuranMath.surah(s).ayat) QuranMark(s, a) else null
    }

    fun setReading(v: Boolean) { showReading = v; prefs.edit().putBoolean(K_READING, v).apply() }

    /** [NONE_CODE] hides the translation; null returns to the interface language. */
    fun setTranslation(code: String?) {
        translationCode = code
        prefs.edit().apply { if (code == null) remove(K_TRANSLATION) else putString(K_TRANSLATION, code) }.apply()
    }

    fun setSize(v: Int) { arabicSize = v.coerceIn(0, SIZES.lastIndex); prefs.edit().putInt(K_SIZE, arabicSize).apply() }

    fun setTheme(v: Int) { readerTheme = v.coerceIn(THEME_NIGHT, THEME_SKY); prefs.edit().putInt(K_THEME, readerTheme).apply() }

    fun setTranslationTextSize(v: Int) {
        translationSize = v.coerceIn(0, TRANSLATION_SIZES.lastIndex)
        prefs.edit().putInt(K_TR_SIZE, translationSize).apply()
    }

    fun setAwake(v: Boolean) { keepAwake = v; prefs.edit().putBoolean(K_AWAKE, v).apply() }

    fun isBookmarked(key: Int): Boolean = key in bookmarks

    fun toggleBookmark(key: Int) {
        if (!QuranMath.isAyahKey(key)) return
        bookmarks = QuranMath.toggleBookmark(bookmarks, key)
        prefs.edit().putString(K_BOOKMARKS, bookmarks.joinToString(",")).apply()
    }

    fun saveMark(m: QuranMark) {
        if (m == mark) return
        mark = m
        prefs.edit().putInt(K_SURAH, m.surah).putInt(K_AYAH, m.ayah).apply()
    }

    fun translation(uiLanguage: String): QuranTranslation? = when (val c = translationCode) {
        null -> QuranMath.defaultTranslation(uiLanguage)
        NONE_CODE -> null
        else -> QuranTranslation.of(c) ?: QuranMath.defaultTranslation(uiLanguage)
    }

    companion object {
        const val NONE_CODE = "none"
        /** Arabic size steps, sp. 0.17.0 appended 40: stored indices of 0.16 keep their meaning. */
        val SIZES = floatArrayOf(24f, 28f, 34f, 40f)
        /** Translation size steps, sp; index 1 is the 0.16 size. */
        val TRANSLATION_SIZES = floatArrayOf(13f, 15f, 17f, 19f)
        const val THEME_NIGHT = 0
        const val THEME_BLACK = 1
        const val THEME_SKY = 2
        private const val K_THEME = "reader_theme"
        private const val K_TR_SIZE = "translation_size"
        private const val K_AWAKE = "keep_awake"
        private const val K_BOOKMARKS = "bookmarks"
        private const val K_READING = "reading"
        private const val K_TRANSLATION = "translation"
        private const val K_SIZE = "arabic_size"
        private const val K_KHATM = "khatm_active"
        private const val K_KHATM_START_DAY = "khatm_start_day"
        private const val K_KHATM_DAYS = "khatm_target_days"
        private const val K_KHATM_FROM = "khatm_start_page"
        private const val K_KHATM_LAST = "khatm_last_page"
        private const val K_KHATM_TODAY_DAY = "khatm_today_day"
        private const val K_KHATM_TODAY = "khatm_today_pages"
        private const val K_SURAH = "mark_surah"
        private const val K_AYAH = "mark_ayah"

        @Volatile private var instance: QuranStore? = null
        fun get(context: Context): QuranStore =
            instance ?: synchronized(this) { instance ?: QuranStore(context).also { instance = it } }
    }
}
