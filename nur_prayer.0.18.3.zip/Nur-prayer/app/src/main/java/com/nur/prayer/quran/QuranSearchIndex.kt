package com.nur.prayer.quran

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * One ayah found by the full-text search. [ranges] are character ranges of the match in the text
 * that was searched: the translation as stored (folding keeps its offsets) or, for an Arabic
 * query, the folded Arabic — [QuranSearchIndex.arabicRanges] moves them onto the vowelled text.
 */
class QuranSearchHit(
    val surah: Int,
    val ayah: Int,
    val arabic: Boolean,
    val score: Int,
    val ranges: List<IntRange>
)

class QuranSearchResult(val hits: List<QuranSearchHit>, val total: Int) {
    companion object { val EMPTY = QuranSearchResult(emptyList(), 0) }
}

/**
 * 0.18.0 full-text search over all 6236 ayat, held in memory — no database. Built lazily on the
 * IO dispatcher the first time a 3+ letter query is typed, for one translation only (the one the
 * reader shows); choosing another translation drops the index and the next query rebuilds it.
 * A pass over the whole Quran is a few milliseconds; ranking is pure and unit-tested.
 */
object QuranSearchIndex {
    /** One ayah: Arabic without harakat ([QuranText.foldArabic]) and the translation folded by [QuranText.foldLatin]. */
    class Entry(val surah: Short, val ayah: Short, val arFolded: String, val trLower: String)

    const val MIN_QUERY = 3
    const val LIMIT = 100

    private val lock = Mutex()
    @Volatile private var built: Pair<QuranTranslation?, List<Entry>>? = null

    /** Text queries only: a surah number, "2:255" or "с42" is a jump, not a search. */
    fun wants(query: String): Boolean {
        val q = query.trim()
        if (q.length < MIN_QUERY) return false
        return QuranMath.parseReference(q) == null && QuranMath.parsePage(q) == null && q.toIntOrNull() == null
    }

    suspend fun entries(context: Context, translation: QuranTranslation?): List<Entry> = lock.withLock {
        built?.let { (t, list) -> if (t == translation) return@withLock list }
        built = null // let the old language go before the new one is read
        val list = withContext(Dispatchers.IO) { read(context.applicationContext, translation) }
        if (list.size == QuranIndex.AYAH_COUNT) built = translation to list
        list
    }

    private fun read(context: Context, translation: QuranTranslation?): List<Entry> {
        val out = ArrayList<Entry>(QuranIndex.AYAH_COUNT)
        for (n in 1..QuranIndex.SURAH_COUNT) {
            val ayat = runCatching {
                context.assets.open(QuranMath.asset(n)).bufferedReader().use { QuranMath.parse(n, it.readText()) }
            }.getOrDefault(emptyList())
            for (a in ayat) {
                val text = a.translation(translation).orEmpty()
                out += Entry(n.toShort(), a.number.toShort(), QuranText.foldArabic(a.arabic), QuranText.foldLatin(text))
            }
        }
        return out
    }

    /**
     * Ranking: the whole query as a phrase first (a whole word, then the start of a word, then
     * anywhere inside one), then ayat that hold every word of it apart. Long words also match by
     * their stem («терпение» finds «терпения»), ranked below exact words. Ties keep mushaf order.
     */
    fun find(entries: List<Entry>, query: String, limit: Int = LIMIT): QuranSearchResult {
        val arabic = QuranText.hasArabic(query)
        val q = normalizeQuery(query, arabic)
        if (q.length < MIN_QUERY) return QuranSearchResult.EMPTY
        val words = q.split(' ').filter { it.isNotEmpty() }
        val hits = ArrayList<QuranSearchHit>()
        for (e in entries) {
            val text = if (arabic) e.arFolded else e.trLower
            if (text.isEmpty()) continue
            val phrase = best(text, q)
            if (phrase != null) {
                hits += QuranSearchHit(e.surah.toInt(), e.ayah.toInt(), arabic, PHRASE + phrase.first, listOf(phrase.second))
                continue
            }
            if (words.size < 2 && arabic) continue
            var score = 0
            val ranges = ArrayList<IntRange>(words.size)
            for (w in words) {
                val m = best(text, w) ?: stem(w, arabic)?.let { s -> best(text, s)?.takeIf { it.first >= START }?.let { 0 to it.second } }
                if (m == null) { score = -1; break }
                score += m.first + 1
                ranges += m.second
            }
            if (score > 0) hits += QuranSearchHit(e.surah.toInt(), e.ayah.toInt(), arabic, score, ranges.sortedBy { it.first })
        }
        hits.sortByDescending { it.score } // stable: equal scores stay in mushaf order
        return QuranSearchResult(if (hits.size > limit) hits.subList(0, limit).toList() else hits, hits.size)
    }

    fun normalizeQuery(query: String, arabic: Boolean): String =
        if (arabic) QuranText.foldArabic(query)
        else QuranText.foldLatin(query).trim().split(WHITESPACE).filter { it.isNotEmpty() }.joinToString(" ")

    private const val PHRASE = 100
    private const val WORD = 3
    private const val START = 2
    private const val INSIDE = 1
    private val WHITESPACE = Regex("\\s+")

    /** Russian/Latin stem: a long word without its last two letters. No stemming for Arabic. */
    private fun stem(word: String, arabic: Boolean): String? =
        if (!arabic && word.length >= 6 && word.all { it.isLetter() }) word.dropLast(2) else null

    /** The best occurrence of [q] in [text]: its quality and range. */
    private fun best(text: String, q: String): Pair<Int, IntRange>? {
        var i = text.indexOf(q)
        if (i < 0) return null
        var bestQ = 0
        var bestAt = i
        while (i >= 0) {
            val quality = quality(text, i, q.length)
            if (quality > bestQ) { bestQ = quality; bestAt = i }
            if (bestQ == WORD) break
            i = text.indexOf(q, i + 1)
        }
        return bestQ to (bestAt until bestAt + q.length)
    }

    private fun quality(text: String, at: Int, len: Int): Int {
        val starts = at == 0 || !isWordChar(text[at - 1])
        val ends = at + len >= text.length || !isWordChar(text[at + len])
        return when {
            starts && ends -> WORD
            starts -> START
            else -> INSIDE
        }
    }

    private fun isWordChar(c: Char) = c.isLetterOrDigit() || c == '\''

    /** Folded-Arabic ranges moved onto the vowelled text, each grown over the marks of its last letter. */
    fun arabicRanges(original: String, folded: List<IntRange>): List<IntRange> {
        val map = QuranText.foldArabicMapped(original).second
        return folded.mapNotNull { r ->
            if (r.first < 0 || r.last >= map.size || r.isEmpty()) return@mapNotNull null
            var end = map[r.last] + 1
            while (end < original.length && QuranText.isMark(original[end])) end++
            map[r.first] until end
        }
    }

    /**
     * A long text cut around its first match: about [radius] characters on each side, on word
     * boundaries, with … where it was cut. Ranges move with the text.
     */
    fun snippet(text: String, ranges: List<IntRange>, radius: Int = 90): Pair<String, List<IntRange>> {
        if (text.length <= radius * 2 + 40 || ranges.isEmpty()) return text to ranges
        val first = ranges.minOf { it.first }
        var from = (first - radius).coerceAtLeast(0)
        while (from > 0 && !text[from - 1].isWhitespace()) from--
        var to = (first + radius).coerceAtMost(text.length)
        while (to < text.length && !text[to].isWhitespace()) to++
        val head = if (from > 0) "… " else ""
        val tail = if (to < text.length) " …" else ""
        val shift = head.length - from
        val moved = ranges.filter { it.first >= from && it.last < to }.map { (it.first + shift)..(it.last + shift) }
        return head + text.substring(from, to) + tail to moved
    }
}
