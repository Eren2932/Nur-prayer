package com.nur.prayer.ui.quran

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.quran.QuranIndex
import com.nur.prayer.quran.QuranStore
import com.nur.prayer.ui.components.LocalBackdropPaused
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.uiScale

/**
 * Where the Quran page stands. Hoisted to the root so the today tile can open the reader on the
 * bookmark and the "Ещё" link on the table of contents; saved across process death by the root.
 */
class QuranNav(reading: Boolean = false, surah: Int = 1, jump: Int = 0, token: Int = 0) {
    var reading by mutableStateOf(reading)
    var surah by mutableStateOf(surah.coerceIn(1, QuranIndex.SURAH_COUNT))
    /** Ayah to scroll to once the surah is on screen; 0 when there is nothing to do. */
    var jump by mutableStateOf(jump)
    /**
     * Bumped by every explicit open. The reader is keyed on it, so a page restored from an earlier
     * visit never wins over the surah that was just asked for.
     */
    var token by mutableStateOf(token)
        private set

    fun read(surah: Int, ayah: Int = 0) {
        this.surah = surah.coerceIn(1, QuranIndex.SURAH_COUNT); jump = ayah; token++; reading = true
    }
    fun contents() { reading = false }

    companion object {
        val Saver = androidx.compose.runtime.saveable.listSaver<QuranNav, Int>(
            save = { listOf(if (it.reading) 1 else 0, it.surah, it.jump, it.token) },
            restore = { QuranNav(it.getOrElse(0) { 0 } == 1, it.getOrElse(1) { 1 }, it.getOrElse(2) { 0 }, it.getOrElse(3) { 0 }) }
        )
    }
}

/**
 * The whole Quran: 114 surahs in mushaf order. Two faces — the table of contents (search by name,
 * number or "2:255"; surahs, juz and bookmarks on swipeable tabs) and the reader, where surahs
 * turn right to left like the pages of a mushaf and each surah is read top to bottom.
 *
 * 0.17.0: the section has its own reading surface (see QuranTheme.kt); the sky stops animating
 * under it, and the screen stays on while reading.
 */
@Composable
fun QuranScreen(
    nav: QuranNav,
    palette: PhasePalette,
    onBack: () -> Unit,
    /** Ayat already in the repetition, surah×1000+ayah. */
    reviewed: Set<Int> = emptySet(),
    /** Adds an ayah to the repetition; false when it was already there. */
    onReview: (Int, Int) -> Boolean = { _, _ -> false }
) {
    val context = LocalContext.current
    val store = remember { QuranStore.get(context) }
    val colors = animatedQuranColors(quranColors(store.readerTheme, palette))

    // An opaque page hides the sky completely: no reason to keep the stars ticking under it.
    val opaque = store.readerTheme != QuranStore.THEME_SKY
    val backdropPaused = LocalBackdropPaused.current
    DisposableEffect(opaque) {
        if (opaque) backdropPaused.value = true
        onDispose { if (opaque) backdropPaused.value = false }
    }
    // Long surahs are read for minutes without a touch; the screen must not go dark mid-ayah.
    val view = LocalView.current
    val awake = nav.reading && store.keepAwake
    DisposableEffect(awake) {
        if (awake) view.keepScreenOn = true
        onDispose { if (awake) view.keepScreenOn = false }
    }

    // The table of contents keeps its tab, scroll and query across a visit to the reader.
    val tabs = rememberPagerState { CONTENTS_TABS }
    val surahList = rememberLazyListState()
    val juzList = rememberLazyListState()
    val bookmarkList = rememberLazyListState()
    var query by rememberSaveable { mutableStateOf("") }

    BackHandler(nav.reading) { nav.contents() }
    // The root pads every page below the status bar. The reading surface reaches up under it too:
    // drawn from this page (outside its bounds, nothing above clips), so it slides in and out
    // with the page instead of a strip that pops in the root. The sky theme draws nothing.
    val statusBar = WindowInsets.statusBars.getTop(LocalDensity.current).toFloat()
    Box(
        Modifier.fillMaxSize().drawBehind {
            if (colors.background.alpha > 0f) drawRect(colors.background, Offset(0f, -statusBar), Size(size.width, statusBar))
            drawRect(Brush.verticalGradient(listOf(colors.background, colors.backgroundBottom)))
        }
    ) {
        AnimatedContent(
            targetState = nav.reading,
            transitionSpec = {
                // Opening a surah is opening the book: the page comes up from slightly smaller while
                // the contents recede past the reader; closing runs the same motion backwards.
                val opening = targetState
                (fadeIn(tween(FACE_IN_MILLIS, delayMillis = FACE_IN_DELAY)) +
                    scaleIn(NurMotion.gentle(), initialScale = if (opening) 0.94f else 1.04f)) togetherWith
                    (fadeOut(tween(FACE_OUT_MILLIS)) + scaleOut(NurMotion.gentle(), targetScale = if (opening) 1.04f else 0.94f))
            },
            label = "quranFace", modifier = Modifier.fillMaxSize()
        ) { reading ->
            if (reading) key(nav.token) { QuranReader(nav, store, colors, reviewed, onReview) }
            else QuranContents(
                store, colors, nav.surah, query, { query = it }, tabs, surahList, juzList, bookmarkList,
                onBack = onBack, onOpen = { s, a -> nav.read(s, a) }
            )
        }
    }
}

// ── shared pieces ────────────────────────────────────────────────────────────────────────────────

/**
 * A round number plate; with [progress] it carries a thin gold ring showing how far the reader
 * has come (in the surah, in the juz).
 */
@Composable
internal fun NumberBadge(n: Int, colors: QuranColors, highlighted: Boolean = false, progress: Float? = null, size: Dp = 44.dp) {
    val ui = uiScale()
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Box(
            Modifier.size(size - 6.dp).clip(CircleShape)
                .background(if (highlighted) colors.accent.copy(alpha = 0.26f) else colors.inset),
            contentAlignment = Alignment.Center
        ) {
            Text("$n", color = if (highlighted) colors.text else colors.textSecondary, fontSize = ui.t(14f), fontWeight = FontWeight.Bold)
        }
        if (progress != null) {
            val track = colors.hairline
            val arc = colors.accent
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 2.5.dp.toPx()
                val inset = stroke / 2f
                val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
                drawArc(track, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke))
                drawArc(arc, -90f, 360f * progress.coerceIn(0f, 1f), false, Offset(inset, inset), arcSize,
                    style = Stroke(stroke, cap = StrokeCap.Round))
            }
        }
    }
}

/** A small tinted capsule: «джуз 4», «۩ земной поклон». */
@Composable
internal fun Tagline(text: String, color: Color) {
    val ui = uiScale()
    Box(Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Text(text, color = color.liftedForText(), fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold)
    }
}

internal const val CONTENTS_TABS = 3
private const val FACE_IN_MILLIS = 240
private const val FACE_IN_DELAY = 60
private const val FACE_OUT_MILLIS = 170

// Tanzil order (shadda before the vowel), the same code points as the ayat below it.
// tools/quran_data.py checks every vowelled literal of this file against the data.
internal const val BASMALA =
    "\u0628\u0650\u0633\u0652\u0645\u0650 \u0627\u0644\u0644\u0651\u064E\u0647\u0650 " +
        "\u0627\u0644\u0631\u0651\u064E\u062D\u0652\u0645\u064E\u0670\u0646\u0650 " +
        "\u0627\u0644\u0631\u0651\u064E\u062D\u0650\u064A\u0645\u0650"
internal const val BASMALA_CYR = "бисми-ллаһи р-раҳмаани р-раҳиим"
internal const val BASMALA_LATIN = "bismi-llahi r-raḥmāni r-raḥīm"
