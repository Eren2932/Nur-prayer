package com.nur.prayer.quran

/**
 * 0.18.2. Ayat picked in the reader for copy, share, a picture, a bookmark or the repetition.
 *
 * A long press starts a selection on one ayah (the [anchor]); while it is open, a tap on another
 * ayah of the same surah stretches it from the anchor to that ayah, a tap on the far end pulls it
 * back to the anchor, and a tap on a lone selected ayah closes it. The range never grows past
 * [MAX] ayat — a picture or a message of half a surah helps nobody. Pure and unit-tested
 * (AyahSelectionTest).
 */
data class AyahSelection(val surah: Int, val anchor: Int, val focus: Int) {
    val from: Int get() = minOf(anchor, focus)
    val to: Int get() = maxOf(anchor, focus)
    val count: Int get() = to - from + 1
    val single: Boolean get() = anchor == focus

    operator fun contains(key: Int): Boolean = key / 1000 == surah && key % 1000 in from..to

    /** "2:255" or "2:255–257". */
    val reference: String get() = if (single) "$surah:$from" else "$surah:$from–$to"

    /**
     * A tap on [ayah] of [tappedSurah] while the selection is open; null closes it. Another surah
     * cannot be part of the range — the tap then just closes it.
     */
    fun tap(tappedSurah: Int, ayah: Int): AyahSelection? {
        if (tappedSurah != surah) return null
        if (single && ayah == anchor) return null
        // The far end tapped again: back to the anchor alone.
        if (!single && ayah == focus) return copy(focus = anchor)
        val limited = ayah.coerceIn(anchor - (MAX - 1), anchor + (MAX - 1))
        return copy(focus = limited)
    }

    companion object {
        const val MAX = 20

        /** A long press on [ayah]: a fresh selection, or none when that very ayah alone was selected. */
        fun press(current: AyahSelection?, surah: Int, ayah: Int): AyahSelection? =
            if (current != null && current.single && current.surah == surah && current.anchor == ayah) null
            else AyahSelection(surah, ayah, ayah)
    }
}

/** 0.18.2. The text that leaves the app for one ayah or a run of them. Pure, tested with the selection. */
object AyahShareText {
    /** Arabic with ﴿N﴾ after every ayah of a run, the translation with (N) in front, then the reference. */
    fun build(ayat: List<QuranAyah>, title: String, translation: QuranTranslation?): String = buildString {
        if (ayat.isEmpty()) return@buildString
        val many = ayat.size > 1
        append(arabic(ayat))
        val meanings = ayat.mapNotNull { a -> a.translation(translation)?.let { a.number to it } }
        if (meanings.isNotEmpty()) {
            append("\n\n")
            append(meanings.joinToString(" ") { (n, t) -> if (many) "($n) $t" else t })
        }
        val first = ayat.first()
        val last = ayat.last()
        append("\n\n— ").append(title).append(", ").append(first.surah).append(':').append(first.number)
        if (many) append('–').append(last.number)
    }

    /** The Arabic of the run, every ayah closed by its number as the mushaf prints it. */
    fun arabic(ayat: List<QuranAyah>): String =
        if (ayat.size == 1) ayat[0].arabic
        else ayat.joinToString(" ") { it.arabic + " \uFD3F" + QuranMath.arabicDigits(it.number) + "\uFD3E" }
}
