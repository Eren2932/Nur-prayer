package com.nur.prayer.ui.quran

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import com.nur.prayer.quran.QuranStore
import com.nur.prayer.ui.theme.Glass
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary

/*
 * 0.17.0 — the Quran gets its own reading surface.
 *
 * The rest of the app is a window onto the sky of the current prayer; a long read is not. Behind
 * the mushaf the colour of noon or sunset only competes with the text, so the section draws an
 * even, hue-less dark of its own («Тёмный», the default), true black for night and AMOLED
 * («Чёрный»), or keeps the sky for those who liked 0.16 («Небо»). Accents on the dark surfaces
 * are one muted gold, the colour of mushaf ornament, instead of the prayer accent that changes
 * five times a day.
 */
@Immutable
internal class QuranColors(
    /** Top and bottom of the page gradient; transparent for the sky. */
    val background: Color,
    val backgroundBottom: Color,
    /** The plate of the reader's top bar. */
    val bar: Color,
    val card: Color,
    val raised: Color,
    val inset: Color,
    val hairline: Color,
    val accent: Color,
    val text: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val sky: Boolean
)

/** Muted mushaf gold: readable on both dark surfaces, never loud. */
private val Gold = Color(0xFFD9BA74)
private val GoldNight = Color(0xFFCDAE69)

internal fun quranColors(theme: Int, palette: PhasePalette): QuranColors = when (theme) {
    QuranStore.THEME_BLACK -> QuranColors(
        background = Color(0xFF000000), backgroundBottom = Color(0xFF000000), bar = Color(0xF5000000),
        card = Color(0xFF0F1114), raised = Color(0xFF181B20), inset = Color(0xFF0A0B0D), hairline = Color(0x17FFFFFF),
        accent = GoldNight, text = Color(0xFFE6E7EA), textSecondary = Color(0xFFADB1B9), textTertiary = Color(0xFF80858F),
        sky = false
    )
    QuranStore.THEME_SKY -> QuranColors(
        background = Color.Transparent, backgroundBottom = Color.Transparent, bar = palette.zenith.copy(alpha = 0.94f),
        card = Glass, raised = SurfaceRaised, inset = SurfaceInset, hairline = SurfaceRaised,
        accent = palette.accent, text = TextPrimary, textSecondary = TextSecondary, textTertiary = TextTertiary,
        sky = true
    )
    else -> QuranColors(
        background = Color(0xFF13161C), backgroundBottom = Color(0xFF0C0E12), bar = Color(0xF513161C),
        card = Color(0xFF191D24), raised = Color(0xFF20252E), inset = Color(0xFF0E1015), hairline = Color(0x17FFFFFF),
        accent = Gold, text = Color(0xFFEDEEF0), textSecondary = Color(0xFFB9BDC6), textTertiary = Color(0xFF8B909A),
        sky = false
    )
}

/** A theme switch cross-fades every surface instead of flashing. */
@Composable
internal fun animatedQuranColors(target: QuranColors): QuranColors {
    val spec = tween<Color>(360)
    val background by animateColorAsState(target.background, spec, label = "qBg")
    val bottom by animateColorAsState(target.backgroundBottom, spec, label = "qBgBottom")
    val bar by animateColorAsState(target.bar, spec, label = "qBar")
    val card by animateColorAsState(target.card, spec, label = "qCard")
    val raised by animateColorAsState(target.raised, spec, label = "qRaised")
    val inset by animateColorAsState(target.inset, spec, label = "qInset")
    val accent by animateColorAsState(target.accent, spec, label = "qAccent")
    val text by animateColorAsState(target.text, spec, label = "qText")
    val secondary by animateColorAsState(target.textSecondary, spec, label = "qText2")
    val tertiary by animateColorAsState(target.textTertiary, spec, label = "qText3")
    return QuranColors(background, bottom, bar, card, raised, inset, target.hairline, accent, text, secondary, tertiary, target.sky)
}

/** Accent tints sit on dark surfaces: lifted halfway to white, text on them stays readable. */
internal fun Color.liftedForText(): Color = Color(
    red = red + (1f - red) * 0.45f, green = green + (1f - green) * 0.45f, blue = blue + (1f - blue) * 0.45f, alpha = 1f
)
