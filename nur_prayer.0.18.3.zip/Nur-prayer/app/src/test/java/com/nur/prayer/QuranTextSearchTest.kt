package com.nur.prayer

import com.nur.prayer.quran.QuranAyah
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.quran.QuranSearchIndex
import com.nur.prayer.quran.QuranText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** The pure parts of 0.18.0 (hifz mask reworked in 0.18.3): the folding and the ranking of the in-memory text search. */
class QuranTextSearchTest {
    // «بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ» with a plain alef, as the generator writes it.
    private val basmala = "\u0628\u0650\u0633\u0652\u0645\u0650 \u0627\u0644\u0644\u064E\u0651\u0647\u0650 " +
        "\u0627\u0644\u0631\u064E\u0651\u062D\u0652\u0645\u064E\u0670\u0646\u0650 \u0627\u0644\u0631\u064E\u0651\u062D\u0650\u064A\u0645\u0650"

    @Test fun firstLettersMasksEveryWordButKeepsItsStart() {
        val parts = QuranText.firstLetterParts(basmala)
        val words = QuranText.firstLetters(basmala).split(' ')
        assertEquals(4, words.size)
        assertTrue(words.all { it.endsWith(QuranText.MASK_CHAR) })
        // «بِسْمِ» without the particle table: the letter keeps its vowel, the bar stands for س and م.
        assertEquals("\u0628\u0650" + "\u0640".repeat(4), words[0])
        assertFalse("nothing of the rest leaks", parts.filter { !it.hidden }.any { it.text.contains("\u0645") })
        assertTrue(parts.filter { it.hidden }.all { p -> p.text.all { it == QuranText.MASK_CHAR } })
    }

    @Test fun theBarIsAsLongAsTheLettersItHides() {
        val fi = QuranText.firstLetterParts("\u0641\u0650\u064A").single { it.hidden }          // فِي
        val fazada = QuranText.firstLetterParts("\u0641\u064E\u0632\u064E\u0627\u062F\u064E\u0647\u064F\u0645\u064F")
            .single { it.hidden }                                                                   // فَزَادَهُمُ
        assertEquals(QuranText.MASK_MIN, fi.text.length)
        assertEquals(5 * QuranText.MASK_PER_LETTER, fazada.text.length)
    }

    @Test fun aParticleFromTheTableKeepsTheWordsOwnFirstLetter() {
        val waIdha = "\u0648\u064E\u0625\u0650\u0630\u064E\u0627"                            // وَإِذَا
        val table = mapOf(QuranText.bare(waIdha) to 1)
        assertEquals("\u0648\u064E" + "\u0640".repeat(3 * QuranText.MASK_PER_LETTER),
            QuranText.firstLetters(waIdha))                                                         // without: «وَ…»
        assertEquals("\u0648\u064E\u0625\u0650" + "\u0640".repeat(2 * QuranText.MASK_PER_LETTER),
            QuranText.firstLetters(waIdha, table))                                                  // with: «وَإِ…»
    }

    @Test fun theArticleAndASilentAlefAreNotTheHint() {
        val words = QuranText.firstLetters(basmala).split(' ')
        // «ٱل» is not a letter of the word, it is its article: «ٱلله» opens with «ٱللَّ», not with a lone alef.
        assertTrue(words[1].startsWith("\u0627\u0644\u0644"))
        // اهْدِنَا: the hamzat al-wasl is not pronounced, the hint is the ه after it.
        assertTrue(QuranText.firstLetters("\u0627\u0647\u0652\u062F\u0650\u0646\u064E\u0627").startsWith("\u0627\u0647\u0652\u0640"))
    }

    @Test fun aOneLetterWordAndTheMuqattaatAreLeftAsTheyAre() {
        assertEquals("\u0648", QuranText.firstLetters("\u0648"))
        assertEquals("\u0627\u0644\u0645", QuranText.firstLetters("\u0627\u0644\u0645"))          // الم opening 2:1
        assertTrue(QuranText.firstLetters("\u0642\u064F\u0644 \u0627\u0644\u0645").endsWith("\u0640"))  // not opening: masked
    }

    @Test fun maskingMatchesTheReferenceOnGoldenAyat() {
        fun file(name: String) = listOf(File("src/$name"), File("app/src/$name")).first { it.isFile }
        val particles = QuranText.parseParticles(file("main/assets/${QuranText.PARTICLES_ASSET}").readText())
        assertTrue(particles.size > 2000)
        val surahs = HashMap<Int, List<QuranAyah>>()
        var checked = 0
        for (line in file("test/resources/hifz_first_letters.tsv").readLines()) {
            if (line.isBlank()) continue
            val (ref, want) = line.split('\t', limit = 2)
            val (s, a) = ref.split(':').map { it.toInt() }
            val ayat = surahs.getOrPut(s) { QuranMath.parse(s, file("main/assets/${QuranMath.asset(s)}").readText()) }
            assertEquals(ref, want, QuranText.firstLetters(ayat[a - 1].arabic, particles))
            checked++
        }
        assertTrue(checked >= 50)
    }

    @Test fun foldArabicDropsEveryMarkAndUnifiesNothingElse() {
        assertEquals(
            "\u0628\u0633\u0645 \u0627\u0644\u0644\u0647 \u0627\u0644\u0631\u062D\u0645\u0646 \u0627\u0644\u0631\u062D\u064A\u0645",
            QuranText.foldArabic(basmala)
        )
    }

    @Test fun textQueriesAreNotJumps() {
        assertTrue(QuranSearchIndex.wants("patience"))
        assertTrue(QuranSearchIndex.wants("  \u0635\u0628\u0631 "))
        assertFalse(QuranSearchIndex.wants("ab"))
        assertFalse(QuranSearchIndex.wants("2:255"))
        assertFalse(QuranSearchIndex.wants("114"))
        assertFalse(QuranSearchIndex.wants("p42"))
        assertFalse(QuranSearchIndex.wants("\u0441\u0442\u0440 42"))
    }

    private fun e(s: Int, a: Int, ar: String, tr: String) = QuranSearchIndex.Entry(s.toShort(), a.toShort(), ar, tr.lowercase())

    @Test fun wholeWordsComeBeforeStartsOfWordsAndInsideMatches() {
        val entries = listOf(
            e(2, 153, "", "O you who believe, seek help through patience and prayer"),
            e(3, 200, "", "Be patient and persevere"),
            e(5, 1, "", "patiently waiting"),
            e(7, 1, "", "impatience is a trial")
        )
        val r = QuranSearchIndex.find(entries, "patience")
        assertEquals(4, r.total)
        // the word itself, then the word inside another, then the stem at the start of a word, in mushaf order
        assertEquals(listOf(2 to 153, 7 to 1, 3 to 200, 5 to 1), r.hits.map { it.surah to it.ayah })
        assertTrue(r.hits.none { it.arabic })
    }

    @Test fun theMatchIsMarkedWhereItIs() {
        val text = "seek help through patience and prayer"
        val r = QuranSearchIndex.find(listOf(e(2, 153, "", text)), "Patience")
        val range = r.hits.single().ranges.single()
        assertEquals("patience", text.substring(range.first, range.last + 1))
    }

    @Test fun arabicIsFoundWithoutHarakatAndMarkedInTheFoldedText() {
        val folded = QuranText.foldArabic(basmala)
        val r = QuranSearchIndex.find(listOf(e(1, 1, folded, "")), "\u0627\u0644\u0631\u064E\u0651\u062D\u0652\u0645\u064E\u0670\u0646")
        val hit = r.hits.single()
        assertTrue(hit.arabic)
        assertEquals(9..14, hit.ranges.single())
        // the marks are put back onto the vowelled text by the index; the vowel of the last letter
        // (the kasra of ن) belongs to the word and is highlighted with it
        val moved = QuranSearchIndex.arabicRanges(basmala, hit.ranges).single()
        assertEquals(
            "\u0627\u0644\u0631\u064E\u0651\u062D\u0652\u0645\u064E\u0670\u0646\u0650",
            basmala.substring(moved.first, moved.last + 1)
        )
    }

    @Test fun theAnswerHoldsAHundredAndCountsTheRest() {
        val entries = List(150) { e(2, it + 1, "", "patience in every ayah") }
        val r = QuranSearchIndex.find(entries, "patience")
        assertEquals(100, r.hits.size)
        assertEquals(150, r.total)
    }

    @Test fun aShortQueryFindsNothing() {
        val r = QuranSearchIndex.find(listOf(e(2, 1, "", "patience")), "pa")
        assertTrue(r.hits.isEmpty())
    }
}
