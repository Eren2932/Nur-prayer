package com.nur.prayer

import com.nur.prayer.learn.Course
import com.nur.prayer.learn.Exercise
import com.nur.prayer.learn.ExerciseFactory
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.learn.LearnProgress
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Ayat sent to the repetition from the Quran reader: card keys and how they come back as exercises. */
class QuranRecallTest {
    private fun asset(name: String): String =
        listOf(File("src/main/assets/$name"), File("app/src/main/assets/$name")).first { it.exists() }.readText()

    private val content by lazy { LearnContent.parse(asset(LearnContent.WORDS_ASSET), asset(LearnContent.QURAN_ASSET)) }

    @Test fun ayahKeysRoundTrip() {
        assertEquals("quran:2:255", LearnProgress.ayahKey(2, 255))
        assertEquals(2255, LearnProgress.ayahOf("quran:2:255"))
        assertEquals(114006, LearnProgress.ayahOf("quran:114:6"))
    }

    @Test fun damagedKeysAreNotAyat() {
        assertNull(LearnProgress.ayahOf("W:abc"))
        assertNull(LearnProgress.ayahOf("quran:"))
        assertNull(LearnProgress.ayahOf("quran:2"))
        assertNull(LearnProgress.ayahOf("quran:2:0"))
        assertNull(LearnProgress.ayahOf("quran:2:287"))      // al-Baqarah has 286
        assertNull(LearnProgress.ayahOf("quran:115:1"))
        assertNull(LearnProgress.ayahOf("quran:x:1"))
        assertNull(LearnProgress.ayahOf("quran:2:255:1"))
    }

    @Test fun reviewedAyatListsOnlyAyahCards() {
        val p = LearnProgress().introduce(listOf("quran:2:255", "quran:1:1", "W:abc", "quran:9:9999"), 100L)
        assertEquals(setOf(2255, 1001), p.reviewedAyat())
    }

    @Test fun anAyahCardComesBackAsARecallAndTheAyatAreCapped() {
        val c = content
        val keys = (1..8).map { LearnProgress.ayahKey(2, it) }
        val p = LearnProgress().introduce(keys, 100L)
        val review = c.course.lesson(Course.REVIEW_ID)!!
        val ex = ExerciseFactory(c.lexicon, c.quran, 3).build(review.plan, c.course, p, 100L)
        val recalls = ex.filterIsInstance<Exercise.Recall>()
        assertEquals(5, recalls.size)                        // a few ayat a lesson, never all of them
        assertTrue(recalls.all { it.surah == 2 && it.ayah in 1..8 })
        assertEquals(listOf(LearnProgress.ayahKey(2, 1)), recalls.first().cards)
    }
}
