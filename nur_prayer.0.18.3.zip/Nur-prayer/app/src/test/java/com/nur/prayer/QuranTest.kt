package com.nur.prayer

import com.nur.prayer.quran.QuranIndex
import com.nur.prayer.quran.QuranMark
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.quran.QuranTranslation
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class QuranTest {
    private companion object {
        const val BASMALA_TANZIL =
            "\u0628\u0650\u0633\u0652\u0645\u0650 \u0627\u0644\u0644\u0651\u064E\u0647\u0650 " +
                "\u0627\u0644\u0631\u0651\u064E\u062D\u0652\u0645\u064E\u0670\u0646\u0650 " +
                "\u0627\u0644\u0631\u0651\u064E\u062D\u0650\u064A\u0645\u0650"
    }

    private fun asset(name: String): File =
        listOf(File("src/main/assets/$name"), File("app/src/main/assets/$name")).first { it.isFile }

    @Test
    fun indexIsTheMushafInOrder() {
        assertEquals(114, QuranIndex.SURAHS.size)
        assertEquals((1..114).toList(), QuranIndex.SURAHS.map { it.number })
        assertEquals(6236, QuranIndex.SURAHS.sumOf { it.ayat })
        var start = 0
        for (s in QuranIndex.SURAHS) { assertEquals(s.number.toString(), start, s.start); start += s.ayat }
        assertEquals(7, QuranMath.surah(1).ayat)
        assertEquals(286, QuranMath.surah(2).ayat)
        assertEquals(6, QuranMath.surah(114).ayat)
        assertFalse(QuranMath.surah(1).medinan)
        assertTrue(QuranMath.surah(2).medinan)
    }

    @Test
    fun everySurahFileHasEveryAyahAndEveryTranslation() {
        for (s in QuranIndex.SURAHS) {
            val ayat = QuranMath.parse(s.number, asset(QuranMath.asset(s.number)).readText())
            assertEquals("surah ${s.number}", (1..s.ayat).toList(), ayat.map { it.number })
            for (a in ayat) {
                assertTrue(a.translit.isNotEmpty() && a.latin.isNotEmpty())
                for (t in QuranTranslation.entries) assertNotNull("${a.surah}:${a.number} ${t.code}", a.translation(t))
            }
        }
    }

    @Test
    fun knownAyatReadAsExpected() {
        val fatiha = QuranMath.parse(1, asset("quran/001.tsv").readText())
        // Tanzil puts shadda before the vowel (U+0651 U+064E); an editor typing or normalizing (NFC)
        // the literal flips them to fatha+shadda. Same glyphs, different string, so the escapes are exact.
        assertEquals(BASMALA_TANZIL, fatiha[0].arabic)
        assertEquals("Во имя Аллаха, Милостивого, Милосердного!", fatiha[0].translation(QuranTranslation.RU))
        val ikhlas = QuranMath.parse(112, asset("quran/112.tsv").readText())
        assertEquals("қул һува-ллаһу аҳад", ikhlas[0].translit)
        assertEquals("qul huwa-llahu aḥad", ikhlas[0].latin)
        assertNull(ikhlas[0].translation(null))
    }

    @Test
    fun juzAndSajda() {
        assertEquals(1, QuranMath.juzOf(1, 1))
        assertEquals(1, QuranMath.juzOf(2, 141))
        assertEquals(2, QuranMath.juzOf(2, 142))
        assertEquals(30, QuranMath.juzOf(114, 6))
        assertEquals(30, QuranMath.juzStartingAt(78, 1))
        assertEquals(0, QuranMath.juzStartingAt(78, 2))
        assertEquals(15, QuranIndex.SAJDA.size)
        assertTrue(QuranMath.isSajda(96, 19))
        assertFalse(QuranMath.isSajda(96, 18))
        assertFalse(QuranMath.showsBasmala(9))
        assertFalse(QuranMath.showsBasmala(1))
        assertTrue(QuranMath.showsBasmala(2))
    }

    @Test
    fun referencesAndSearch() {
        assertEquals(QuranMark(2, 255), QuranMath.parseReference("2:255"))
        assertEquals(QuranMark(2, 255), QuranMath.parseReference(" 2 255 "))
        assertNull(QuranMath.parseReference("1:8"))
        assertNull(QuranMath.parseReference("115:1"))
        assertEquals(listOf(112), QuranMath.search("112").map { it.number })
        assertEquals(listOf(2), QuranMath.search("2:255").map { it.number })
        assertTrue(QuranMath.search("ихлас").any { it.number == 112 })
        assertTrue(QuranMath.search("ikhlas").any { it.number == 112 })
        assertEquals(114, QuranMath.search("").size)
    }

    @Test
    fun remarksAreSplitOff() {
        val runs = QuranMath.remarks("Аллах сомад. (Удовлетворяющий нужды.) Он один")
        assertEquals(listOf(false, true, false), runs.map { it.second })
        assertEquals("Аллах сомад. (Удовлетворяющий нужды.) Он один", runs.joinToString("") { it.first })
        assertEquals(listOf(false), QuranMath.remarks("без скобок").map { it.second })
    }

    @Test
    fun languagesPickTheirTranslationAndReading() {
        assertEquals(QuranTranslation.RU, QuranMath.defaultTranslation("ru"))
        assertEquals(QuranTranslation.RU, QuranMath.defaultTranslation("kk"))
        assertEquals(QuranTranslation.UZ, QuranMath.defaultTranslation("uz"))
        assertEquals(QuranTranslation.TR, QuranMath.defaultTranslation("tr"))
        assertEquals(QuranTranslation.EN, QuranMath.defaultTranslation("en"))
        assertNull(QuranMath.defaultTranslation("ar"))
        assertFalse(QuranMath.latinReading("ru"))
        assertTrue(QuranMath.latinReading("uz"))
    }
}
