package com.nur.prayer

import com.nur.prayer.quran.AyahSelection
import com.nur.prayer.quran.AyahShareText
import com.nur.prayer.quran.QuranAyah
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.18.2: the reader's ayah selection and the text it shares. */
class AyahSelectionTest {
    @Test fun aLongPressSelectsAndASecondOneOnTheSameAyahCloses() {
        val s = AyahSelection.press(null, 2, 255)!!
        assertTrue(s.single)
        assertEquals("2:255", s.reference)
        assertNull(AyahSelection.press(s, 2, 255))
        assertEquals(AyahSelection(2, 10, 10), AyahSelection.press(s, 2, 10))
    }

    @Test fun aTapStretchesFromTheAnchorBothWays() {
        val s = AyahSelection(2, 255, 255)
        val down = s.tap(2, 257)!!
        assertEquals(255..257, down.from..down.to)
        assertEquals("2:255–257", down.reference)
        assertEquals(3, down.count)
        val up = down.tap(2, 250)!!
        assertEquals(250..255, up.from..up.to)
        assertTrue(2252 in up)
    }

    @Test fun theFarEndTappedAgainPullsBackAndALoneAyahTappedCloses() {
        val s = AyahSelection(2, 5, 9)
        assertEquals(AyahSelection(2, 5, 5), s.tap(2, 9))
        assertNull(AyahSelection(2, 5, 5).tap(2, 5))
        assertNull(s.tap(3, 1))   // another surah cannot join the passage
    }

    @Test fun thePassageNeverGrowsPastTheLimit() {
        val s = AyahSelection(2, 100, 100).tap(2, 286)!!
        assertEquals(AyahSelection.MAX, s.count)
        assertEquals(100, s.from)
        val back = AyahSelection(2, 100, 100).tap(2, 1)!!
        assertEquals(AyahSelection.MAX, back.count)
        assertEquals(100, back.to)
    }

    @Test fun containsKnowsTheSurah() {
        val s = AyahSelection(2, 1, 5)
        assertTrue(2003 in s)
        assertFalse(3003 in s)
        assertFalse(2006 in s)
    }

    @Test fun oneAyahIsSharedAsBeforeAPassageWithNumbers() {
        val a = QuranAyah(112, 1, "قُلْ هُوَ اللَّهُ أَحَدٌ", "", "", emptyMap())
        val b = QuranAyah(112, 2, "اللَّهُ الصَّمَدُ", "", "", emptyMap())
        assertEquals("قُلْ هُوَ اللَّهُ أَحَدٌ\n\n— Аль-Ихлас, 112:1", AyahShareText.build(listOf(a), "Аль-Ихлас", null))
        val two = AyahShareText.build(listOf(a, b), "Аль-Ихлас", null)
        assertTrue(two.contains("\uFD3F١\uFD3E"))
        assertTrue(two.endsWith("— Аль-Ихлас, 112:1–2"))
    }
}
