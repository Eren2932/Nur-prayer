package com.nur.prayer

import com.nur.prayer.quran.QuranIndex
import com.nur.prayer.quran.QuranMark
import com.nur.prayer.quran.QuranMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.17.0: the reader's navigation math — positions, juz bounds, the fast scroll, go-to, bookmarks. */
class QuranNavigationTest {
    private val eps = 1e-6f

    @Test
    fun globalIndexWalksTheMushaf() {
        assertEquals(0, QuranMath.globalIndex(1, 1))
        assertEquals(7, QuranMath.globalIndex(2, 1))
        assertEquals(261, QuranMath.globalIndex(2, 255))
        assertEquals(QuranIndex.AYAH_COUNT - 1, QuranMath.globalIndex(114, 6))
        assertEquals(1f / QuranIndex.AYAH_COUNT, QuranMath.quranProgress(1, 1), eps)
        assertEquals(1f, QuranMath.quranProgress(114, 6), eps)
    }

    @Test
    fun juzBoundsTileTheWholeQuran() {
        assertEquals(QuranMark(1, 1), QuranMath.juzStart(1))
        assertEquals(QuranMark(2, 141), QuranMath.juzEnd(1))
        assertEquals(QuranMark(2, 252), QuranMath.juzEnd(2))
        assertEquals(QuranMark(77, 50), QuranMath.juzEnd(29))
        assertEquals(QuranMark(114, 6), QuranMath.juzEnd(30))
        assertEquals(148, QuranMath.juzAyat(1))
        assertEquals(564, QuranMath.juzAyat(30))
        assertEquals(QuranIndex.AYAH_COUNT, (1..30).sumOf { QuranMath.juzAyat(it) })
        for (j in 1 until 30) {
            val end = QuranMath.juzEnd(j)
            val next = QuranMath.juzStart(j + 1)
            assertEquals("juz $j", QuranMath.globalIndex(end.surah, end.ayah) + 1, QuranMath.globalIndex(next.surah, next.ayah))
            assertEquals(1f, QuranMath.juzProgress(end.surah, end.ayah), eps)
        }
    }

    @Test
    fun readingPositionAndProgress() {
        assertEquals(1f, QuranMath.readingPosition(0, 0.7f, 200), eps)
        assertEquals(45.5f, QuranMath.readingPosition(45, 0.5f, 200), eps)
        assertEquals(200f, QuranMath.readingPosition(201, 0f, 200), eps)
        assertEquals(0f, QuranMath.surahProgress(1f, 200, atEnd = false), eps)
        assertEquals(0.5f, QuranMath.surahProgress(101f, 200, atEnd = false), eps)
        assertEquals(1f, QuranMath.surahProgress(150f, 200, atEnd = true), eps)
    }

    @Test
    fun fastScrollEndsAreExact() {
        assertEquals(1, QuranMath.ayahAt(0f, 286))
        assertEquals(286, QuranMath.ayahAt(1f, 286))
        assertEquals(1, QuranMath.ayahAt(-3f, 286))
        assertEquals(286, QuranMath.ayahAt(7f, 286))
        for (a in 1..286) assertEquals(a, QuranMath.ayahAt(QuranMath.trackFraction(a.toFloat(), 286), 286))
        assertEquals(1, QuranMath.ayahAt(0.5f, 1))
    }

    @Test
    fun goToAyahResolvesNumbersAndReferences() {
        assertEquals(QuranMark(3, 7), QuranMath.resolveJump("7", 3))
        assertEquals(QuranMark(2, 255), QuranMath.resolveJump("2:255", 3))
        assertEquals(QuranMark(2, 255), QuranMath.resolveJump("2.255", 3))
        assertEquals(QuranMark(2, 255), QuranMath.resolveJump(" 2 255 ", 3))
        assertNull(QuranMath.resolveJump("201", 3))
        assertNull(QuranMath.resolveJump("0", 3))
        assertNull(QuranMath.resolveJump("1:8", 3))
        assertNull(QuranMath.resolveJump("", 3))
    }

    @Test
    fun mushafDirection() {
        // Left-to-right interface: the pager is reversed so al-Fatiha sits on the right.
        assertTrue(QuranMath.mushafPagerReversed(rtlLayout = false))
        // Arabic interface already runs right to left.
        assertFalse(QuranMath.mushafPagerReversed(rtlLayout = true))
        assertEquals("\u0662\u0665\u0665", QuranMath.arabicDigits(255))
    }

    @Test
    fun bookmarksStayValidUniqueAndNewestFirst() {
        assertEquals(listOf(2255, 18010), QuranMath.parseBookmarks("2255, 18010,2255,1008,0,abc,115001"))
        assertEquals(emptyList<Int>(), QuranMath.parseBookmarks(null))
        val added = QuranMath.toggleBookmark(listOf(2255), 1001)
        assertEquals(listOf(1001, 2255), added)
        assertEquals(listOf(2255), QuranMath.toggleBookmark(added, 1001))
        val full = (1..QuranMath.MAX_BOOKMARKS).map { 2000 + it.coerceAtMost(286) }.distinct()
        assertTrue(QuranMath.toggleBookmark(full, 1001).size <= QuranMath.MAX_BOOKMARKS)
    }
}
