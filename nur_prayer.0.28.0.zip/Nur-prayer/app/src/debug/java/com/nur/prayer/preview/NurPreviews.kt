package com.nur.prayer.preview

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.SkyBackdrop
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.home.PrayerSheet
import com.nur.prayer.ui.qibla.Heading
import com.nur.prayer.ui.qibla.HeadingSource
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.settings.SettingsScreen
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime

/** Actual production composables over the real sky. Debug source set only; never in the release APK. */
private val afternoon = ZonedDateTime.parse("2026-10-31T15:28:00+03:00[Europe/Moscow]")

private fun fixture(moment: ZonedDateTime = afternoon): PrayerData {
    val city = City.MOSCOW
    val settings = AppSettings()
    val place = Place(city.name, city.subtitle, city.country, city.coordinates, city.zone, false)
    val params = settings.paramsFor(city.country)
    val date = moment.toLocalDate()
    return PrayerData(place, PrayerEngine.days(date, 3, city.coordinates, city.zone, params),
        PrayerEngine.window(moment, city.coordinates, city.zone, params), qiblaBearing(city.coordinates),
        distanceToKaabaKm(city.coordinates), HijriCalendar.format(date), settings, settings.profileFor(city.country), params)
}

/** Every action inert: previews render, they never write settings or play sound. */
private val previewActions = AppActions(
    {}, {}, {}, {}, {}, {}, {}, {}, {}, { _, _ -> }, { _, _ -> }, {}, {}, {}, {}, {}
)

@Composable
private fun Scene(phase: Prayer, content: @Composable (PhasePalette) -> Unit) {
    NurTheme {
        val palette = paletteFor(phase)
        Box(Modifier.fillMaxSize()) {
            SkyBackdrop(palette, motionEnabled = false)
            Box(Modifier.fillMaxSize().statusBarsPadding()) { content(palette) }
        }
    }
}

@Composable
private fun Home(phase: Prayer, moment: ZonedDateTime = afternoon) {
    val data = remember { fixture(moment) }
    val clock = remember { mutableStateOf(moment) }
    Scene(phase) {
        // 0.27.0: home with its capsule, as NurRoot lays them out.
        val shell = remember { com.nur.prayer.ui.shell.ShellState() }
        androidx.compose.runtime.CompositionLocalProvider(com.nur.prayer.ui.shell.LocalShell provides shell) {
            androidx.compose.foundation.layout.Box(androidx.compose.ui.Modifier.fillMaxSize()) {
                HomeScreen(data, clock, it, onOpenCity = {}, onOpenSettings = {}, onOpenSchedule = {}, onOpenPrayer = {})
                com.nur.prayer.ui.shell.ShellLayer(
                    shell = shell, route = "home", data = data, now = clock,
                    home = com.nur.prayer.ui.shell.CapsuleNow("Вечерние азкары", "сейчас · 0 из 12", com.nur.prayer.ui.shell.ShellGlyph.TASBIH) {},
                    onOpenSection = { _, _ -> }, onHome = {}, onOpenPrayer = {}
                )
            }
        }
    }
}

@Preview(name = "01 Home / Аср", widthDp = 393, heightDp = 851)
@Composable fun HomeAsrPreview() = Home(Prayer.ASR)

@Preview(name = "02 Home / Иша / 320dp", widthDp = 320, heightDp = 640)
@Composable fun HomeNightCompactPreview() = Home(Prayer.ISHA, ZonedDateTime.parse("2026-10-31T21:00:00+03:00[Europe/Moscow]"))

@Preview(name = "03 Home / Зухр / enlarged type", widthDp = 393, heightDp = 851, fontScale = 1.5f)
@Composable fun HomeNoonLargePreview() = Home(Prayer.DHUHR, ZonedDateTime.parse("2026-10-31T13:00:00+03:00[Europe/Moscow]"))

@Preview(name = "04 Home / landscape", widthDp = 800, heightDp = 360)
@Composable fun HomeLandscapePreview() = Home(Prayer.MAGHRIB, ZonedDateTime.parse("2026-10-31T17:30:00+03:00[Europe/Moscow]"))

@Preview(name = "05 Sheet / Зухр, notifications denied", widthDp = 393, heightDp = 851)
@Composable
fun SheetPreview() {
    val data = remember { fixture() }
    val clock = remember { mutableStateOf(afternoon) }
    Scene(Prayer.ASR) {
        PrayerSheet(data, Prayer.DHUHR, clock, previewActions, notificationsAllowed = false, exactAlarmsAllowed = true,
            onDismiss = {}, onOpenSettings = {})
    }
}

@Preview(name = "06 Calendar", widthDp = 360, heightDp = 800)
@Composable
fun CalendarPreview() {
    val data = remember { fixture() }
    val clock = remember { mutableStateOf(afternoon) }
    Scene(Prayer.ASR) { ScheduleScreen(data, clock, it) }
}

@Preview(name = "07 Compass", widthDp = 393, heightDp = 851)
@Composable
fun CompassPreview() {
    val data = remember { fixture() }
    Scene(Prayer.ASR) {
        QiblaScreen(data, it, onBack = {}, headingOverride = Heading(
            azimuth = data.qibla.toFloat() - 24f, accuracy = 3, fieldStrength = 45f, source = HeadingSource.FUSED))
    }
}

@Preview(name = "08 Compass / unavailable", widthDp = 320, heightDp = 640)
@Composable
fun CompassUnavailablePreview() {
    val data = remember { fixture() }
    Scene(Prayer.ISHA) { QiblaScreen(data, it, onBack = {}, headingOverride = Heading()) }
}

@Preview(name = "09 Settings", widthDp = 393, heightDp = 851)
@Composable
fun SettingsPreview() {
    val data = remember { fixture() }
    Scene(Prayer.ASR) { SettingsScreen(data, it, previewActions, true, onBack = {}) }
}

@Preview(name = "10 City search", widthDp = 393, heightDp = 851)
@Composable
fun CityPreview() {
    Scene(Prayer.DHUHR) { palette ->
        CityPickerScreen(palette, City.MOSCOW.id, search = { listOf(City.MOSCOW) },
            onPick = {}, onBack = {}, onUseLocation = {}, locating = false)
    }
}
