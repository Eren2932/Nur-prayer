package com.nur.prayer.ui.shell

import com.nur.prayer.ui.ROUTE_AZKAR
import com.nur.prayer.ui.ROUTE_COURSE
import com.nur.prayer.ui.ROUTE_DHIKR
import com.nur.prayer.ui.ROUTE_DICTIONARY
import com.nur.prayer.ui.ROUTE_QURAN
import com.nur.prayer.ui.ROUTE_SURAH
import com.nur.prayer.ui.ROUTE_TODAY
import com.nur.prayer.ui.TAB_HOME
import com.nur.prayer.ui.TAB_QIBLA
import com.nur.prayer.ui.TAB_SCHEDULE
import com.nur.prayer.ui.home.HomeSection

/*
 * 0.27.0: where the capsule and the island live. Pure, so it is unit-tested (ShellMathTest).
 *
 *  - home: the capsule says what fits this moment;
 *  - a section (and the pages inside it): the capsule says where you are, the countdown moves up
 *    into the island;
 *  - settings, the city, a lesson, a story: pages with their own way out; no capsule, no island.
 *
 * The Quran and the short surahs are paper: the island would sit on their header, so they keep
 * only the capsule.
 */
object ShellRoutes {

    fun sectionOf(route: String): HomeSection? = when (route) {
        TAB_QIBLA -> HomeSection.QIBLA
        TAB_SCHEDULE -> HomeSection.SCHEDULE
        ROUTE_TODAY, ROUTE_AZKAR -> HomeSection.TODAY
        ROUTE_COURSE, ROUTE_DICTIONARY, ROUTE_SURAH -> HomeSection.COURSE
        ROUTE_DHIKR -> HomeSection.DHIKR
        ROUTE_QURAN -> HomeSection.QURAN
        else -> null
    }

    fun capsuleOn(route: String): Boolean = route == TAB_HOME || sectionOf(route) != null

    fun islandOn(route: String): Boolean =
        sectionOf(route) != null && route != ROUTE_QURAN && route != ROUTE_SURAH

    /** The page a section opens on. Settings are reached from the avatar, never from the grid. */
    fun routeOf(section: HomeSection): String? = when (section) {
        HomeSection.QURAN -> ROUTE_QURAN
        HomeSection.DHIKR -> ROUTE_DHIKR
        HomeSection.QIBLA -> TAB_QIBLA
        HomeSection.TODAY -> ROUTE_TODAY
        HomeSection.COURSE -> ROUTE_COURSE
        HomeSection.SCHEDULE -> TAB_SCHEDULE
        HomeSection.SETTINGS -> null
    }
}
