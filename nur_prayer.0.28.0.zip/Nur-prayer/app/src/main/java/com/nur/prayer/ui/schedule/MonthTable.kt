package com.nur.prayer.ui.schedule

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDay
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.uiScale
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZonedDateTime

/*
 * 0.20.0 — «Таблица на месяц», rebuilt for reading, not for scrolling. 0.28.0 — on paper.
 *
 *  - The header with the names of the prayers is pinned: it lives outside the list, so the rows
 *    scroll under it and a time never loses its column.
 *  - One line per day (number · weekday · hijri day) instead of two: ~32dp a row, the month fits in
 *    about two screens instead of four.
 *  - The table opens on today (two rows of context above it); today's next prayer is lit.
 *  - A horizontal swipe on the table turns the month, like the grid of «Месяц».
 *  - The days of the month and the hijri note close the list, inside the same card.
 *
 *  - 0.28.0: a green pinned band; in Ramadan the Suhur and Maghrib columns are named "пост" / "ифтар" and
 *    set in gold; the card is white paper; an event is a strip standing in the list on the day it begins
 *    (it used to be a legend at the very end).
 *
 * The same rows feed the shared picture (calendarShareSpec), so what is on screen is what is sent.
 */

/** A computed month: the days in order and the columns the place actually has. */
internal class MonthTimes(val month: YearMonth, val days: List<PrayerDay>, val columns: List<Prayer>)

/** Short column names for a narrow phone; the full name stays in the accessibility label. */
internal fun columnLabel(prayer: Prayer): String = when (prayer) {
    Prayer.SAHAR -> tr("Сухур")
    Prayer.FAJR -> tr("Фаджр")
    Prayer.SUNRISE -> tr("Восход")
    Prayer.DHUHR -> tr("Зухр")
    Prayer.ASR -> tr("Аср")
    Prayer.MAGHRIB -> tr("Магриб")
    Prayer.ISHA -> tr("Иша")
}

/** Where the list opens: today with two rows of context above it, or the first day of another month. */
internal fun tableStartIndex(month: YearMonth, today: LocalDate): Int =
    if (YearMonth.from(today) == month) (today.dayOfMonth - 3).coerceAtLeast(0) else 0

/** Weights of the columns: the date cell is wider, every time is equal. */
private const val DATE_WEIGHT = 1.5f

/** What a row of the table is: a day, or the strip of an event standing before the day it begins on. */
internal sealed interface TableItem {
    data class Day(val index: Int) : TableItem
    data class Event(val occurrence: DayOccurrence) : TableItem
}

/** The days in order; each event stands right before its first day (one begun in an earlier month, before the first). */
internal fun tableItems(days: List<LocalDate>, events: List<DayOccurrence>): List<TableItem> {
    if (days.isEmpty()) return emptyList()
    val before = events.groupBy { o -> if (o.start < days.first()) days.first() else o.start }
    return buildList {
        days.forEachIndexed { i, d ->
            before[d]?.forEach { add(TableItem.Event(it)) }
            add(TableItem.Day(i))
        }
    }
}

@Composable
internal fun MonthTable(
    times: MonthTimes,
    today: LocalDate,
    hijriOffset: Int,
    events: List<DayOccurrence>,
    onOpen: (SheetTopic) -> Unit,
    modifier: Modifier = Modifier,
    /** The next prayer and its moment: its cell is lit in its own row (tomorrow's Fajr after Isha). */
    next: Prayer? = null,
    nextStart: ZonedDateTime? = null,
    onSwipe: ((forward: Boolean) -> Unit)? = null,
    bottomPadding: Dp = 8.dp
) {
    val ui = uiScale()
    val narrow = times.columns.size > 6
    val fasting = events.any { it.day == IslamicDay.RAMADAN }
    val items = remember(times, events) { tableItems(times.days.map { it.date }, events) }
    val state = rememberSaveable(times.month, saver = LazyListState.Saver) {
        val first = tableStartIndex(times.month, today)
        LazyListState(items.indexOfFirst { it is TableItem.Day && it.index == first }.coerceAtLeast(0))
    }
    val latestSwipe by rememberUpdatedState(onSwipe)
    val swipe = if (onSwipe == null) Modifier else Modifier.pointerInput(times.month) {
        var distance = 0f
        detectHorizontalDragGestures(
            onDragStart = { distance = 0f }, onDragCancel = { distance = 0f },
            onHorizontalDrag = { change, amount -> change.consume(); distance += amount },
            onDragEnd = {
                val threshold = 56.dp.toPx()
                if (distance < -threshold) latestSwipe?.invoke(true) else if (distance > threshold) latestSwipe?.invoke(false)
            }
        )
    }
    Column(modifier.fillMaxWidth().paperCard(20.dp).then(swipe).testTag("month-table")) {
        TableHeader(times.columns, narrow, fasting)
        LazyColumn(
            state = state,
            modifier = Modifier.weight(1f).fillMaxWidth().testTag("month-table-rows"),
            contentPadding = PaddingValues(top = 4.dp, bottom = bottomPadding)
        ) {
            itemsIndexed(items, key = { _, item ->
                when (item) {
                    is TableItem.Day -> times.days[item.index].date.toEpochDay()
                    is TableItem.Event -> "event-${item.occurrence.day.name}-${item.occurrence.start.toEpochDay()}"
                }
            }) { _, item ->
                when (item) {
                    is TableItem.Event -> EventStrip(item.occurrence, onOpen)
                    is TableItem.Day -> {
                        val day = times.days[item.index]
                        TableRow(times.columns, day, today, hijriOffset, narrow,
                            lit = if (nextStart != null && nextStart.toLocalDate() == day.date) next else null)
                    }
                }
            }
            item(key = "note") {
                Text(
                    tableNote(hijriOffset), color = Paper.Ink3, fontSize = ui.t(11f), lineHeight = ui.t(15f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)
                )
            }
        }
    }
}

/** The pinned green band. In Ramadan the names of the two columns that matter say what they are for. */
@Composable
private fun TableHeader(columns: List<Prayer>, narrow: Boolean, fasting: Boolean) {
    val ui = uiScale()
    val gold = Color(0xFFFFE3A0)
    Row(
        Modifier.fillMaxWidth().background(Paper.Accent).heightIn(min = ui.s(40f)).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(Modifier.width(3.dp))
        Text(tr("Дата").uppercase(), color = Color.White.copy(alpha = 0.8f), fontSize = ui.t(9.5f),
            fontWeight = FontWeight.Bold, modifier = Modifier.weight(DATE_WEIGHT).padding(start = 9.dp), maxLines = 1)
        columns.forEach { p ->
            val hint = if (!fasting) null else when (p) {
                Prayer.SAHAR -> tr("пост")
                Prayer.MAGHRIB -> tr("ифтар")
                else -> null
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    columnLabel(p).uppercase(),
                    color = when {
                        hint != null -> gold
                        p == Prayer.SUNRISE -> Color.White.copy(alpha = 0.62f)
                        else -> Color.White.copy(alpha = 0.94f)
                    },
                    fontSize = ui.t(if (narrow) 8.5f else 9.2f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                    maxLines = 1, softWrap = false, overflow = TextOverflow.Clip
                )
                if (hint != null) Text(hint, color = gold.copy(alpha = 0.85f), fontSize = ui.t(8.5f), fontWeight = FontWeight.Medium, maxLines = 1)
            }
        }
    }
}

@Composable
private fun TableRow(
    columns: List<Prayer>, day: PrayerDay, today: LocalDate, hijriOffset: Int,
    narrow: Boolean, lit: Prayer?
) {
    val ui = uiScale()
    val date = day.date
    val event = IslamicDays.primary(date, hijriOffset)
    val tone = event?.let { Paper.tone(it.kind) }
    val isToday = date == today
    val friday = date.dayOfWeek == DayOfWeek.FRIDAY
    val past = date < today
    val fasting = event?.day == IslamicDay.RAMADAN
    val shape = RoundedCornerShape(12.dp)
    val timeSize = ui.t(if (narrow) 12f else 13f)
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 1.dp)
            .then(if (isToday) Modifier.clip(shape).background(Paper.Accent.copy(alpha = 0.14f)).border(1.2.dp, Paper.Accent.copy(alpha = 0.8f), shape) else Modifier)
    ) {
        Row(
            Modifier.fillMaxWidth().heightIn(min = ui.s(30f))
                .semantics(mergeDescendants = true) {
                    contentDescription = buildString {
                        append(Format.fullDate(date))
                        event?.let { append(", ").append(IslamicDayText.title(it.day)) }
                        columns.forEach { p ->
                            append(", ").append(PrayerLabels.title(p)).append(' ')
                            append(day.times[p]?.let { Format.time(it) } ?: "—")
                        }
                    }
                }
                .testTag("table-row-$date"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // The coloured edge of a marked day.
            Box(Modifier.width(3.dp).height(ui.s(20f)).background(tone ?: Color.Transparent, RoundedCornerShape(2.dp)))
            Row(Modifier.weight(DATE_WEIGHT).padding(start = 7.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    date.dayOfMonth.toString(), color = if (past) Paper.Ink2 else Paper.Ink, fontSize = ui.t(15f),
                    fontWeight = if (isToday) FontWeight.Bold else FontWeight.SemiBold,
                    style = LocalTextStyle.current.copy(fontFeatureSettings = "tnum"),
                    maxLines = 1, softWrap = false, modifier = Modifier.width(ui.s(21f))
                )
                Column(Modifier.weight(1f).padding(start = 2.dp)) {
                    Text(
                        Format.weekdayShort(date), color = if (friday) Paper.Accent else Paper.Ink3,
                        fontSize = ui.t(9.5f), fontWeight = if (friday) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1, softWrap = false, overflow = TextOverflow.Clip
                    )
                    Text(
                        HijriCalendar.dayOfMonth(date, hijriOffset).toString(),
                        color = event?.let { Paper.toneText(it.kind) } ?: Paper.Ink3,
                        fontSize = ui.t(9.5f), fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false
                    )
                }
            }
            columns.forEach { p ->
                val on = p == lit
                val goldColumn = fasting && (p == Prayer.SAHAR || p == Prayer.MAGHRIB)
                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Text(
                        day.times[p]?.let { Format.time(it) } ?: "—",
                        color = when {
                            on -> Paper.OnGold
                            p == Prayer.SUNRISE -> Paper.Ink3
                            goldColumn -> if (past) Color(0xFF9A8458) else Paper.toneText(DayKind.FEAST)
                            past -> Paper.Ink2
                            else -> Paper.Ink
                        },
                        fontSize = timeSize,
                        fontWeight = if (isToday || on || goldColumn && !past) FontWeight.Bold else FontWeight.SemiBold,
                        textAlign = TextAlign.Center, maxLines = 1, softWrap = false,
                        // Tabular digits keep the columns of times aligned (a TextStyle feature, not a Text parameter).
                        style = LocalTextStyle.current.copy(fontFeatureSettings = "tnum"),
                        modifier = (if (on) Modifier.clip(RoundedCornerShape(10.dp)).background(Paper.Gold) else Modifier)
                            .padding(horizontal = 4.dp, vertical = 3.dp)
                    )
                }
            }
        }
        Box(Modifier.align(Alignment.BottomCenter).padding(horizontal = 10.dp).fillMaxWidth().height(0.6.dp).background(Paper.Line))
    }
}

/** "● Рамадан  Месяц обязательного поста ›" — an event as a strip in the list; it opens its sheet. */
@Composable
private fun EventStrip(o: DayOccurrence, onOpen: (SheetTopic) -> Unit) {
    val ui = uiScale()
    val tone = Paper.tone(o.kind)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp).clip(RoundedCornerShape(12.dp))
            .background(tone.copy(alpha = 0.14f))
            .pressClick(scaleTo = 0.98f, role = Role.Button, onClick = { onOpen(SheetTopic.Day(o)) })
            .heightIn(min = ui.s(26f)).padding(horizontal = 11.dp, vertical = 3.dp)
            .testTag("table-event-${o.day.name}"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(tone))
        Text(IslamicDayText.tile(o.day), color = Paper.toneText(o.kind), fontSize = ui.t(12.5f), fontWeight = FontWeight.Bold, maxLines = 1)
        Text(IslamicDayText.short(o.day), color = Paper.Ink2, fontSize = ui.t(10.5f), maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Glyph(GlyphKind.CHEVRON, Paper.toneText(o.kind), Modifier.size(10.dp))
    }
}

/** One line instead of a paragraph: the source of the hijri numbers and the user's shift, if any. */
internal fun tableNote(hijriOffset: Int): String =
    if (hijriOffset == 0) tr("Даты хиджры — по Умм аль-Кура")
    else tr("Даты хиджры — по Умм аль-Кура, сдвиг {0} дн.", if (hijriOffset > 0) "+$hijriOffset" else "$hijriOffset")

/** The spec of the shared picture, from the same rows as the screen. */
internal fun calendarShareSpec(
    times: MonthTimes, today: LocalDate, hijriOffset: Int, placeLabel: String, palette: PhasePalette
): CalendarShareSpec {
    val rows = times.days.map { d ->
        CalendarShareRow(
            day = d.date.dayOfMonth.toString(),
            weekday = Format.weekdayShort(d.date),
            hijriDay = HijriCalendar.dayOfMonth(d.date, hijriOffset).toString(),
            times = times.columns.map { p -> d.times[p]?.let { Format.time(it) } ?: "—" },
            friday = d.date.dayOfWeek == DayOfWeek.FRIDAY,
            today = d.date == today,
            tone = IslamicDays.primary(d.date, hijriOffset)?.let { DayTone.argb(it.kind) }
        )
    }
    val legend = monthEvents(times.month, hijriOffset).map { o -> DayTone.argb(o.kind) to legendLine(o) }
    return CalendarShareSpec(
        kicker = tr("Время намаза"),
        title = "${Format.monthName(times.month.monthValue)} ${times.month.year}",
        subtitle = HijriCalendar.span(times.month.atDay(1), times.month.atEndOfMonth(), hijriOffset),
        place = placeLabel,
        dateHeader = tr("Дата"),
        columns = times.columns.map { columnLabel(it) },
        rows = rows,
        legend = legend,
        footnote = tableNote(hijriOffset),
        palette = palette
    )
}

/** "10 нояб. — 12 нояб. · Дни ташрика" / "25 июня · Ашура". */
internal fun legendLine(o: DayOccurrence): String {
    val start = "${o.start.dayOfMonth} ${Format.monthShort(o.start)}"
    val span = if (o.days > 1) "$start — ${o.end.dayOfMonth} ${Format.monthShort(o.end)}" else start
    return "$span · ${IslamicDayText.title(o.day)}"
}

/** Everything that touches a Gregorian month, in order. */
internal fun monthEvents(month: YearMonth, hijriOffset: Int): List<DayOccurrence> =
    IslamicDays.between(month.atDay(1), month.atEndOfMonth(), hijriOffset)
