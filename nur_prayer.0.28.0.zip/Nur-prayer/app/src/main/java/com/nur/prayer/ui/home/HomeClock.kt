package com.nur.prayer.ui.home

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime

/*
 * 0.27.0: the big countdown of home, «1:04:55» as in the mock. The only part of home that reads the
 * clock, kept in its own file so HomeScreen itself never recomposes per second (source_audit).
 * The text changes width only when the last hour starts (1:00:00 → 59:59): resizeKey follows that.
 */
@Composable
internal fun HomeCountdown(data: PrayerData, now: State<ZonedDateTime>, next: Prayer, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val text = Format.countdown(data.window.remaining(now.value))
    AutoSizeText(
        text, color = TextPrimary, fontSize = ui.t(86f), minFontSize = ui.t(52f),
        fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, letterSpacing = ui.t(-2f),
        resizeKey = text.length,
        modifier = modifier.clearAndSetSemantics {
            contentDescription = tr("До {0}: {1}", PrayerLabels.title(next), text)
        }
    )
}
