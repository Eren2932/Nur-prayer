package com.nur.prayer.ui.schedule

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.home.HomeTimeline
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SystemBarsTone
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.findActivity
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZonedDateTime

/*
 * 0.19.0 — the calendar around three readings of time:
 *
 *   Год     — the hijri year: twelve months with their Gregorian bounds and the days of the year (YearView);
 *   Месяц   — the grid with the days of the year painted in, and the card of the selected day;
 *   Таблица — the month as a timetable, one row per day (MonthTable), shared as a picture.
 *
 * 0.28.0 — redesigned as paper: two thin bars on top (the place, the three views, share; then the one
 * period bar for all three views) and light cards on the picture. Each tab is a file of its own
 * (YearView, MonthCalendar + DayCard, MonthTable); this file only holds the state and the two bars.
 *
 * A tap on the title of the period raises the drums (PeriodPicker); a tap on a day of the year opens its
 * sheet (DaySheet). Both are overlays of this screen, so the back gesture closes them first.
 */

/** Order of the tabs; the index is what is saved. */
internal object CalendarTabs {
    const val YEAR = 0
    const val MONTH = 1
    const val TABLE = 2
}

/** The colours of the text that stands on the backdrop itself (the period title, the weekday letters). */
private class BackdropInk(val title: Color, val subtitle: Color, val label: Color, val friday: Color)

private fun backdropInk(light: Boolean, palette: PhasePalette): BackdropInk =
    if (light) BackdropInk(Paper.Ink, Paper.Accent, Paper.Ink3, Paper.Accent)
    else BackdropInk(TextPrimary, palette.accentSoft, TextTertiary, palette.accentSoft)

@Composable
fun ScheduleScreen(
    data: PrayerData, now: State<ZonedDateTime>, palette: PhasePalette,
    modifier: Modifier = Modifier,
    /** True while the wallpaper under the page is a light picture: the text on it is dark, the bars' icons too. */
    lightBackdrop: Boolean = false
) {
    val ui = uiScale()
    val today = data.today.date
    val hijriOffset = data.settings.hijriOffset
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var tab by rememberSaveable { mutableIntStateOf(CalendarTabs.MONTH) }
    var monthText by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(YearMonth.from(today).toString()) }
    var selectedEpoch by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(today.toEpochDay()) }
    var hijriYear by rememberSaveable(today.toEpochDay(), hijriOffset) { mutableIntStateOf(IslamicDays.hijriOf(today, hijriOffset).year) }
    var picker by rememberSaveable { mutableStateOf(false) }
    // A DayOccurrence is not Parcelable: the sheet is closed after a rotation, which is the honest state.
    var topic by remember { mutableStateOf<SheetTopic?>(null) }
    val month = YearMonth.parse(monthText)
    val selectedDate = LocalDate.ofEpochDay(selectedEpoch)
    fun goMonth(target: YearMonth) {
        monthText = target.toString()
        selectedEpoch = CalendarMonthModel.moveSelection(selectedDate, target).toEpochDay()
    }

    // On a light picture the status-bar icons turn dark, or the clock and battery vanish into the cream.
    val view = LocalView.current
    // The holder is released the moment the page stops being light (the route changes), not when its exit
    // animation ends, so the next screen's own tone is never overwritten.
    val barsOwner = remember { Any() }
    DisposableEffect(lightBackdrop) {
        val window = view.context.findActivity()?.window
        if (lightBackdrop) SystemBarsTone.hold(window, barsOwner)
        onDispose { SystemBarsTone.release(window, barsOwner) }
    }

    // The month timetable: the table tab shows it, the share button sends it. 31 solar days are cheap.
    val columns = remember(data.fajrEqualsDawn) { HomeTimeline.prayers(data.fajrEqualsDawn) }
    var times by remember(data.place, data.params, columns) { mutableStateOf<MonthTimes?>(null) }
    LaunchedEffect(month, data.place, data.params, columns) {
        times = try {
            withContext(Dispatchers.Default) {
                MonthTimes(month, PrayerEngine.days(month.atDay(1), month.lengthOfMonth(), data.place.coordinates, data.place.zone, data.params), columns)
            }
        } catch (cancel: CancellationException) { throw cancel } catch (_: Exception) { null }
    }
    val monthTimes = times?.takeIf { it.month == month }
    var sharing by remember { mutableStateOf(false) }
    val shareFailed = tr("Не удалось подготовить картинку")
    val share: () -> Unit = share@{
        val t = monthTimes ?: return@share
        if (sharing) return@share
        sharing = true
        val spec = calendarShareSpec(t, today, hijriOffset, data.place.label, palette)
        scope.launch {
            val ok = CalendarImageShare.share(context, spec)
            sharing = false
            if (!ok) Toast.makeText(context, shareFailed, Toast.LENGTH_SHORT).show()
        }
    }

    // The one period bar: the month (grid, table) or the hijri year, one title and one hijri span for all three.
    val yearTab = tab == CalendarTabs.YEAR
    val gregorian = remember(today) { PeriodRange.gregorianYears(today) }
    val firstMonth = YearMonth.of(gregorian.first, 1)
    val lastMonth = YearMonth.of(gregorian.last, 12)
    val hijriYears = remember(today, hijriOffset) { PeriodRange.hijriYears(today, hijriOffset) }
    val title = if (yearTab) tr("{0} год хиджры", hijriYear) else "${Format.monthName(month.monthValue)} ${month.year}"
    val subtitle = remember(yearTab, hijriYear, month, hijriOffset) {
        if (yearTab) yearSpan(hijriYear, hijriOffset)
        else HijriCalendar.span(month.atDay(1), month.atEndOfMonth(), hijriOffset)
    }
    val ink = backdropInk(lightBackdrop, palette)

    Box(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            CalendarTopBar(
                place = data.place.label, tab = tab, onTab = { tab = it },
                shareEnabled = !yearTab && monthTimes != null && !sharing, onShare = share
            )
            Spacer(Modifier.height(10.dp))
            PeriodBar(
                title = title, subtitle = subtitle,
                prevLabel = if (yearTab) tr("Предыдущий год") else tr("Предыдущий месяц"),
                nextLabel = if (yearTab) tr("Следующий год") else tr("Следующий месяц"),
                canPrev = if (yearTab) hijriYear > hijriYears.first else month > firstMonth,
                canNext = if (yearTab) hijriYear < hijriYears.last else month < lastMonth,
                onPrev = { if (yearTab) hijriYear -= 1 else goMonth(month.minusMonths(1)) },
                onNext = { if (yearTab) hijriYear += 1 else goMonth(month.plusMonths(1)) },
                onPick = { picker = true },
                ink = ink.title, subInk = ink.subtitle
            )
            Spacer(Modifier.height(8.dp))
            AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    val forward = targetState > initialState
                    (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { w -> if (forward) w / 6 else -w / 6 } +
                        fadeIn(tween(260, delayMillis = 40))) togetherWith
                        (slideOutHorizontally(tween(240)) { w -> if (forward) -w / 8 else w / 8 } + fadeOut(tween(160)))
                },
                label = "calendarTab",
                modifier = Modifier.weight(1f).fillMaxSize()
            ) { page ->
                when (page) {
                    CalendarTabs.YEAR -> YearView(
                        hijriYear, today, hijriOffset,
                        bottomInset = LocalDockInset.current + 16.dp,
                        onOpen = { topic = it }
                    )
                    CalendarTabs.TABLE -> TablePage(
                        month, monthTimes, today, hijriOffset, ink.title,
                        next = data.window.next, nextStart = data.window.nextStart,
                        onMonth = { goMonth(it) }, onOpen = { topic = it }
                    )
                    else -> MonthPage(
                        data, now, month, selectedDate, columns, ink,
                        onMonth = { goMonth(it) },
                        onSelect = { selectedEpoch = it.toEpochDay() },
                        onToday = { monthText = YearMonth.from(today).toString(); selectedEpoch = today.toEpochDay() },
                        onOpen = { topic = it }
                    )
                }
            }
        }
        PeriodPicker(
            visible = picker,
            mode = if (yearTab) PickerMode.HIJRI_YEAR else PickerMode.MONTH,
            month = month, hijriYear = hijriYear, today = today, hijriOffset = hijriOffset,
            accent = palette.accent, surface = palette.sheet,
            onMonth = { goMonth(it) }, onHijriYear = { hijriYear = it }, onDismiss = { picker = false }
        )
        DaySheet(topic, today, hijriOffset, onDismiss = { topic = null })
    }
}

/** "16 июня 2026 — 4 июня 2027": the Gregorian bounds of a hijri year. */
private fun yearSpan(year: Int, offset: Int): String {
    val first = IslamicDays.monthRange(year, 1, offset)?.first
    val last = IslamicDays.monthRange(year, 12, offset)?.second
    return if (first != null && last != null) "${Format.dayMonth(first)} ${first.year} — ${Format.dayMonth(last)} ${last.year}" else ""
}

/* ------------------------------------------------------------------------------------------------
 * Месяц: the grid, the card of the selected day, the next day of the year
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun MonthPage(
    data: PrayerData, now: State<ZonedDateTime>, month: YearMonth, selectedDate: LocalDate,
    columns: List<Prayer>, ink: BackdropInk,
    onMonth: (YearMonth) -> Unit, onSelect: (LocalDate) -> Unit, onToday: () -> Unit,
    onOpen: (SheetTopic) -> Unit
) {
    val ui = uiScale()
    val today = data.today
    val hijriOffset = data.settings.hijriOffset
    val haptic = LocalHapticFeedback.current
    // Yesterday, the day and tomorrow, computed in place: three solar days take a few milliseconds, and the card
    // keeps its height while the selection moves (an asynchronous load flashed a placeholder on every tap).
    // The key is the whole calculation identity, so times of another city or date can never stay under a new one.
    val window = remember(selectedDate, data.place, data.params) {
        runCatching {
            dayWindow(PrayerEngine.days(selectedDate.minusDays(1), 3, data.place.coordinates, data.place.zone, data.params))
        }.getOrNull()
    }
    val dayEvents = remember(selectedDate, hijriOffset) { IslamicDays.on(selectedDate, hijriOffset) }
    val nextEvent = remember(selectedDate, hijriOffset) {
        IslamicDays.between(selectedDate.plusDays(1), selectedDate.plusDays(400), hijriOffset)
            .firstOrNull { it.kind != DayKind.SEASON && it.start.isAfter(selectedDate) }
    }
    // After Isha the "next" prayer is tomorrow's Fajr: it is lit in tomorrow's card, not in today's.
    val lit = HomeTimeline.visible(data.window.next, data.fajrEqualsDawn)
        .takeIf { data.window.nextStart.toLocalDate() == selectedDate }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(12f))) {
        MonthCalendar(
            month, selectedDate, today.date, hijriOffset,
            onMonth = onMonth,
            onSelect = { date ->
                if (date != selectedDate) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onSelect(date)
                }
            },
            labelInk = ink.label, fridayInk = ink.friday
        )
        Spacer(Modifier.height(10.dp))
        DayCard(
            date = selectedDate, today = today, hijriOffset = hijriOffset, window = window, columns = columns,
            current = HomeTimeline.current(data.window, data.fajrEqualsDawn), next = lit,
            now = now, events = dayEvents, onOpen = onOpen, onToday = onToday
        )
        nextEvent?.let { NextEventStrip(it, today.date, onOpen, Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(LocalDockInset.current))
    }
}

/* ------------------------------------------------------------------------------------------------
 * Таблица: the month as a timetable
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun TablePage(
    month: YearMonth, times: MonthTimes?, today: LocalDate, hijriOffset: Int, ink: Color,
    next: Prayer?, nextStart: ZonedDateTime?,
    onMonth: (YearMonth) -> Unit, onOpen: (SheetTopic) -> Unit
) {
    val ui = uiScale()
    val years = remember(today) { PeriodRange.gregorianYears(today) }
    val min = YearMonth.of(years.first, 1)
    val max = YearMonth.of(years.last, 12)
    val events = remember(month, hijriOffset) { monthEvents(month, hijriOffset) }
    // The page does not scroll, only the rows do, under a pinned green header. The card runs down to the screen
    // edge and the rows scroll behind the capsule (as in the mockup); the last row stops above it.
    AnimatedContent(
        targetState = times,
        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
        label = "monthTable",
        modifier = Modifier.fillMaxSize().padding(start = ui.s(12f), end = ui.s(12f), top = 2.dp)
    ) { t ->
        if (t == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(tr("Рассчитываем время…"), color = ink.copy(alpha = 0.7f))
        } else MonthTable(
            t, today, hijriOffset, events, onOpen,
            modifier = Modifier.fillMaxSize(),
            next = next, nextStart = nextStart, bottomPadding = LocalDockInset.current + 8.dp,
            onSwipe = { forward ->
                val target = if (forward) month.plusMonths(1) else month.minusMonths(1)
                if (target in min..max) onMonth(target)
            }
        )
    }
}
