package com.nur.prayer.ui.schedule

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.uiScale

/*
 * 0.28.0 — the chrome of the calendar, one for the three views.
 *
 * Before: a title with a back arrow, a three-word tab bar and then, on every tab, its own period header
 * (two fonts, two alignments) — about 200 dp before the first row. Now two thin lines: the place, the
 * three views as icons and the share button; under them the one period bar (the title, its hijri span,
 * the arrows). The section is named by the capsule and left by the capsule's moon, so the back arrow
 * and the word "Календарь" went.
 */

private val GLYPHS = listOf(GlyphKind.VIEW_YEAR, GlyphKind.VIEW_MONTH, GlyphKind.VIEW_TABLE)

/** Place · the three views · share. */
@Composable
fun CalendarTopBar(
    place: String,
    tab: Int,
    onTab: (Int) -> Unit,
    shareEnabled: Boolean,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val labels = listOf(tr("Год"), tr("Месяц"), tr("Таблица"))
    Row(
        modifier.fillMaxWidth().padding(top = LocalIslandInset.current + 4.dp, start = ui.s(12f), end = ui.s(12f)),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(ui.s(8f))
    ) {
        Row(
            Modifier.weight(1f, fill = false).height(ui.s(40f)).paperCard(20.dp).padding(horizontal = ui.s(12f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Glyph(GlyphKind.LOCATION, Paper.Accent, Modifier.size(ui.s(15f)))
            Spacer(Modifier.width(ui.s(7f)))
            AutoSizeText(
                place, color = Paper.Ink, fontSize = ui.t(13.5f), minFontSize = ui.t(10f),
                fontWeight = FontWeight.SemiBold, maxLines = 1
            )
        }
        Spacer(Modifier.weight(1f))
        Row(
            Modifier.paperCard(20.dp).padding(ui.s(4f)).testTag("calendar-tabs"),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            GLYPHS.forEachIndexed { index, glyph ->
                val on = index == tab
                Box(
                    Modifier.size(width = ui.s(40f), height = ui.s(32f)).clip(RoundedCornerShape(16.dp))
                        .background(if (on) Paper.Accent else Color.Transparent)
                        .semantics { contentDescription = labels[index] }
                        .pressClick(role = Role.Tab, onClick = { onTab(index) })
                        .testTag("calendar-tab-$index"),
                    contentAlignment = Alignment.Center
                ) {
                    Glyph(glyph, if (on) Color.White else Paper.Ink2, Modifier.size(ui.s(17f)))
                }
            }
        }
        PaperButton(
            GlyphKind.SHARE, tr("Поделиться таблицей месяца"), shareEnabled, onShare,
            Modifier.testTag("calendar-share")
        )
    }
}

/** A round paper button, 40 dp: the arrows and the share. */
@Composable
internal fun PaperButton(
    glyph: GlyphKind,
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    rotation: Float = 0f
) {
    val ui = uiScale()
    Box(
        modifier.size(ui.s(40f)).graphicsLayer { alpha = if (enabled) 1f else 0.4f }
            .paperCard(20.dp)
            .semantics { contentDescription = label }
            .pressClick(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Glyph(glyph, Paper.Ink, Modifier.size(ui.s(15f)).graphicsLayer { rotationZ = rotation })
    }
}

/**
 * The one period bar of the three views: ‹ title ⌄ ›, with the hijri span under the title. A tap on the
 * title raises the drums. [ink] and [subInk] follow the backdrop: dark on a light picture, light on a dark one.
 */
@Composable
fun PeriodBar(
    title: String,
    subtitle: String,
    prevLabel: String,
    nextLabel: String,
    canPrev: Boolean,
    canNext: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onPick: () -> Unit,
    ink: Color,
    subInk: Color,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    Row(
        modifier.fillMaxWidth().padding(horizontal = ui.s(12f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PaperButton(GlyphKind.CHEVRON, prevLabel, canPrev, onPrev, Modifier.testTag("calendar-prev"), rotation = 180f)
        Box(
            Modifier.weight(1f).padding(horizontal = 6.dp).clip(RoundedCornerShape(16.dp))
                .pressClick(role = Role.Button, onClick = onPick).padding(vertical = 2.dp)
                .testTag("calendar-period"),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AutoSizeText(
                        title, color = ink, fontSize = ui.t(21f), minFontSize = ui.t(15f),
                        fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f, fill = false),
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.width(6.dp))
                    Glyph(GlyphKind.CHEVRON, ink.copy(alpha = 0.7f), Modifier.size(11.dp).graphicsLayer { rotationZ = 90f })
                }
                AutoSizeText(
                    subtitle, color = subInk, fontSize = ui.t(12f), minFontSize = ui.t(9.5f),
                    fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
        PaperButton(GlyphKind.CHEVRON, nextLabel, canNext, onNext, Modifier.testTag("calendar-next"))
    }
}

/** "сегодня" on the selected today, "К сегодня" otherwise: one tag, one place to come back to. */
@Composable
fun CalendarTodayChip(atToday: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Text(
        text = if (atToday) tr("сегодня") else tr("К сегодня"),
        color = Paper.Accent, fontSize = ui.t(11f), fontWeight = FontWeight.SemiBold, maxLines = 1,
        modifier = modifier.clip(CircleShape).background(Paper.Accent.copy(alpha = 0.12f))
            .pressClick(role = Role.Button, onClick = onClick)
            .padding(horizontal = ui.s(11f), vertical = ui.s(5f))
            .testTag("calendar-today")
    )
}
