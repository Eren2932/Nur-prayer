package com.nur.prayer.ui

import com.nur.prayer.i18n.tr
import com.nur.prayer.CrashReport
import com.nur.prayer.ui.home.HomeSection
import com.nur.prayer.ui.shell.CapsuleNow
import com.nur.prayer.ui.shell.CapsuleRoom
import com.nur.prayer.ui.shell.FrostSource
import com.nur.prayer.ui.shell.IslandRoom
import com.nur.prayer.ui.shell.LocalFrost
import com.nur.prayer.ui.shell.LocalShell
import com.nur.prayer.ui.shell.PrayerSheetHost
import com.nur.prayer.ui.shell.ShellGlyph
import com.nur.prayer.ui.shell.ShellLayer
import com.nur.prayer.ui.shell.ShellRoutes
import com.nur.prayer.ui.shell.ShellState
import com.nur.prayer.ui.theme.LocalIslandInset
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import com.nur.prayer.i18n.AppLanguage
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.LocalLanguageSwitcher
import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import kotlinx.coroutines.launch

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.absolutePadding
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.City
import com.nur.prayer.ui.components.LocalBackdropPaused
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.learn.CourseScreen
import com.nur.prayer.ui.learn.DictionaryScreen
import com.nur.prayer.ui.learn.LearnViewModel
import com.nur.prayer.ui.learn.LessonScreen
import com.nur.prayer.ui.learn.SurahScreen
import com.nur.prayer.ui.today.TodayActions
import com.nur.prayer.ui.today.TodayScreen
import com.nur.prayer.ui.today.TodayState
import com.nur.prayer.ui.daily.AzkarScreen
import com.nur.prayer.ui.daily.DailyViewModel
import com.nur.prayer.ui.daily.DhikrScreen
import com.nur.prayer.ui.daily.StoryScreen
import com.nur.prayer.daily.Azkar
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.DailyStories
import com.nur.prayer.learn.QuranShort
import com.nur.prayer.daily.StorySlide
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nur.prayer.learn.Course
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.settings.SettingsScreen
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.layout.statusBars
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.animatedPhasePalette
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime

/**
 * 0.27.0 «Капсула»: all navigation lives in one floating capsule at the bottom (ShellLayer). It
 * opens in place into a panel with the times of the day and the grid of sections; inside a section
 * it names the section, the countdown moves into the island at the top and the moon leads home.
 * The pages do not know how they were opened: the shell only calls [NurNavigator] (go from home,
 * switchTo between sections), so another way of navigating can replace it without touching them.
 *
 * 0.9.0: the pull-up from home raises «Сегодня» (learning, word of the day, tasks of the day); the
 * course, a lesson, the dictionary and the surah reader open inside that layer, so going deeper
 * never drops it. Календарь became an ordinary page opened from the right.
 *
 * 0.6.0 shell: no dock. Home is the root and owns the whole screen; Календарь, Кыбла and Настройки
 * open over it from the right and close back to it, Город opens one level deeper from wherever it
 * was called. The sky is drawn once, behind every route, so a transition never flashes black.
 */
@Composable
fun NurRoot(
    data: PrayerData?, now: State<ZonedDateTime>, locating: Boolean, locationStatus: String?,
    exactAlarmsAllowed: Boolean, notificationsAllowed: Boolean, citySearch: suspend (String) -> List<City>, onPickCity: (City) -> Unit,
    actionsFactory: (openCityPicker: () -> Unit) -> AppActions,
    locationButtonLabel: String = tr("Определить местоположение")
) {
    val nav = rememberSaveable(saver = NurNavigator.Saver) { NurNavigator() }
    // Where the menu item that opened Кыбла / Настройки sits on screen. Deliberately not saved: after
    // a restore the page simply has no origin and uses the ordinary slide.
    val menuOrigin = remember { arrayOf(Offset.Unspecified) }
    // 0.26.0: the same for the layer (Дела дня, Коран, Обучение, Зикр) opened from a cell of the
    // panel (0.27.0). With an origin the layer grows out of the sector and sinks back into it; without one
    // (a restore) it rises from below as before.
    val layerOrigin = remember { arrayOf(Offset.Unspecified) }
    val layerTopLeft = remember { arrayOf(Offset.Zero) }
    val pages = rememberSaveableStateHolder()
    val quranNav = androidx.compose.runtime.saveable.rememberSaveable(saver = com.nur.prayer.ui.quran.QuranNav.Saver) { com.nur.prayer.ui.quran.QuranNav() }
    val backdropPaused = remember { mutableStateOf(false) }
    BackHandler(nav.canGoBack) { nav.back() }
    // The capsule and its panel. Not saveable: an open panel must not greet the user after a return.
    val shell = remember { ShellState() }
    // The prayer sheet is above every page (a time on home and a card in the panel open it); its
    // prayer survives rotation and process death, stored by name and validated on read.
    var sheetName by rememberSaveable { mutableStateOf<String?>(null) }
    val sheetPrayer = sheetName?.let { name -> Prayer.entries.firstOrNull { it.name == name } }
    val targetPalette = remember(data?.window?.current) { paletteFor(data?.window?.current ?: Prayer.ISHA) }
    val palette = animatedPhasePalette(targetPalette)
    // 0.23.0: a wallpaper the user just chose is on screen at once. The stored id travels through
    // DataStore and a full PrayerData recomputation (two passes of the schedule) before it comes
    // back; until it does, this choice is what the backdrop, the gallery and the settings row show.
    var wallpaperChoice by remember { mutableStateOf<String?>(null) }
    val baseActions = remember(nav) { actionsFactory { nav.go(ROUTE_CITY) } }
    val actions = remember(baseActions) {
        baseActions.copy(setWallpaper = { id ->
            wallpaperChoice = id
            baseActions.setWallpaper(id)
        })
    }
    // «Сегодня» is not a page that slides in from the side: it is a layer above home that rises
    // from the bottom, under the finger when pulled. A route change only tells it where to settle;
    // its position is one number (see Reveal). Learning pages live inside it.
    val learn: LearnViewModel = viewModel()
    val learnContent by learn.content.collectAsStateWithLifecycle()
    val learnProgress by learn.progress.collectAsStateWithLifecycle()
    // Ayat the reader has sent to the repetition (hifz); the reader marks them "В повторении".
    val quranReviewed = remember(learnProgress) { learnProgress.reviewedAyat() }
    val activeLesson by learn.active.collectAsStateWithLifecycle()
    val daily: DailyViewModel = viewModel()
    val azkarSessions by daily.azkar.collectAsStateWithLifecycle()
    val dhikrToday by daily.dhikrToday.collectAsStateWithLifecycle()
    val vird by daily.vird.collectAsStateWithLifecycle()
    // The word the dictionary opens on: the word of the day from its tile, nothing from anywhere else.
    val dictionaryFocus = rememberSaveable { mutableStateOf<String?>(null) }
    val storyMask by daily.storyMask.collectAsStateWithLifecycle()
    val voiceContext = androidx.compose.ui.platform.LocalContext.current
    // The engine itself connects only when a screen that may speak asks for it (rememberVoiceStatus).
    val arabicVoice = remember { com.nur.prayer.audio.ArabicVoice.get(voiceContext) }
    val scheduleOpen = nav.layerOpen
    val calendar = remember { Reveal(initiallyOpen = scheduleOpen) }
    LaunchedEffect(scheduleOpen) { calendar.settle(scheduleOpen) }
    // A lesson does not survive process death (its exercises are random); a restored lesson route
    // without a running lesson steps back to the course instead of showing an empty page.
    LaunchedEffect(nav.current, activeLesson == null) {
        if (nav.current == ROUTE_LESSON && activeLesson == null) nav.back()
    }
    // The layer keeps drawing its last page while it falls back.
    val lastLayer = remember { arrayOf(ROUTE_TODAY) }
    if (nav.layerOpen) lastLayer[0] = nav.current
    // A lesson that cannot start (nothing due, still locked) opens the course map instead of doing nothing.
    val openLesson: (String) -> Unit = { id -> if (learn.start(id)) nav.go(ROUTE_LESSON) else nav.go(ROUTE_COURSE) }
    // Fully covered home is removed from the tree: nothing hidden ticks, draws or answers touches.
    // Going back flips scheduleOpen a frame before the layer starts to fall, so home is composed
    // in time and the first frames of the fall are not spent on it.
    val homeOnScreen by remember(scheduleOpen) { derivedStateOf { !scheduleOpen || calendar.progress < 1f } }
    val scheduleOnScreen by remember(scheduleOpen) { derivedStateOf { scheduleOpen || calendar.progress > 0f } }
    // Without a dock, the bottom inset of scrolling screens is just the system bar plus air.
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    // 0.18.0: with edge-to-edge enforced the content must also keep clear of the sides: a landscape phone
    // with three-button navigation has the bar on one side, and a camera cutout may sit on the other.
    // Physical left/right (absolutePadding), so the Arabic layout direction does not swap them.
    val sideBars = WindowInsets.systemBars.asPaddingValues()
    val sideCutout = WindowInsets.displayCutout.asPaddingValues()
    val sideLeft = maxOf(sideBars.calculateLeftPadding(LayoutDirection.Ltr), sideCutout.calculateLeftPadding(LayoutDirection.Ltr))
    val sideRight = maxOf(sideBars.calculateRightPadding(LayoutDirection.Ltr), sideCutout.calculateRightPadding(LayoutDirection.Ltr))
    // Which route the root was on before the current one: the menu reveal runs only between home
    // and a menu page, never between Настройки and «Город».
    val rootTarget = if (scheduleOpen) TAB_HOME else nav.current
    val rootPrevious = remember { arrayOf(rootTarget, rootTarget) } // [previous, current]
    if (rootPrevious[1] != rootTarget) { rootPrevious[0] = rootPrevious[1]; rootPrevious[1] = rootTarget }
    // 0.22.0: the backdrop is a wallpaper; «Живое небо» and «Чёрный» are two of them.
    // Before the settings are read there is no wallpaper yet: a black placeholder, so the stored one
    // fades in quietly instead of "being set" (sky → picture) on every launch.
    val storedWallpaper = data?.settings?.wallpaperId
    LaunchedEffect(storedWallpaper) { if (storedWallpaper != null && storedWallpaper == wallpaperChoice) wallpaperChoice = null }
    val wallpaper = remember(data == null, wallpaperChoice, storedWallpaper, data?.settings?.skyBackdrop) {
        when {
            data == null -> com.nur.prayer.ui.wallpaper.WallpaperCatalog.Amoled
            else -> com.nur.prayer.ui.wallpaper.WallpaperCatalog.resolve(wallpaperChoice ?: storedWallpaper, data.settings.skyBackdrop)
        }
    }
    val skyOn = wallpaper.kind == com.nur.prayer.ui.wallpaper.Wallpaper.Kind.SKY
    // 0.28.0: the calendar is a light "paper" page. Over a light picture (kaaba_day) the black page scrim
    // is lifted; over a dark one the page stays dimmed and its header text stays white.
    val paperPage = rootTarget == TAB_SCHEDULE && wallpaper.light
    val paperLift by animateFloatAsState(
        if (paperPage) 1f else 0f, tween(NavigationMotion.DETAIL_ENTER_MILLIS), label = "paperLift"
    )
    // A picture is darkened under pages that put lists of text straight on the backdrop (Календарь,
    // Кыбла); settings and the city picker are opaque and do not need it.
    val pageDim by animateFloatAsState(
        if (rootTarget == TAB_SCHEDULE || rootTarget == TAB_QIBLA) 1f else 0f,
        tween(NavigationMotion.DETAIL_ENTER_MILLIS), label = "wallpaperDim"
    )
    // The matte glass of the capsule, the panel and the island shows this wallpaper, blurred, darkened
    // exactly as the page darkens the sharp one.
    val wallpaperNow = rememberUpdatedState(wallpaper)
    val pageDimNow = rememberUpdatedState(pageDim)
    val frostSource = remember { FrostSource(wallpaper = { wallpaperNow.value }, dim = { maxOf(calendar.progress, pageDimNow.value) }) }
    var wallpapersOpen by rememberSaveable { mutableStateOf(false) }
    // Leaving settings by any path closes the gallery with it.
    LaunchedEffect(rootTarget) { if (rootTarget != TAB_SETTINGS) wallpapersOpen = false }
    val veil = remember(palette, skyOn) {
        if (skyOn) Brush.verticalGradient(0f to palette.zenith, 0.55f to palette.mid, 1f to palette.horizon)
        else Brush.verticalGradient(listOf(com.nur.prayer.ui.theme.Ink, com.nur.prayer.ui.theme.Ink))
    }
    // 0.13.0 language switch: the words fade out over the sky, change while nothing is readable and
    // come back — one calm breath instead of a flash of half-translated text. The sky never blinks,
    // the page and its scroll stay where they were. A second tap mid-way cancels the first cleanly.
    val languageScope = rememberCoroutineScope()
    val languageFade = remember { Animatable(0f) }
    val switchLanguage: (AppLanguage) -> Unit = remember {
        { language ->
            if (language != L10n.language) languageScope.launch {
                languageFade.animateTo(1f, tween(LANGUAGE_OUT_MILLIS, easing = FastOutLinearInEasing))
                L10n.set(language)
                withFrameNanos { } // recompose in the new language while invisible
                languageFade.animateTo(0f, tween(LANGUAGE_IN_MILLIS, easing = FastOutSlowInEasing))
                delay(1500)
                L10n.confirm() // survived: the crash-loop guard in L10n.install lets go of it
            }
        }
    }
    // The trace of the previous crash, if there was one: shown once over everything, ready to copy.
    val appContext = LocalContext.current
    val crashReport = remember { mutableStateOf(CrashReport.take(appContext)) }
    // A language restored at launch gets the same trust window as one chosen in the picker.
    LaunchedEffect(Unit) {
        delay(1500)
        L10n.confirm()
    }
    // A section chosen in the panel. From home it is a step forward (back returns home); from inside a
    // section it replaces the section, so back never walks through every section visited.
    val openSection: (HomeSection, Offset) -> Unit = { section, origin ->
        val route = ShellRoutes.routeOf(section)
        if (route != null) {
            if (route in LAYER_ROUTES) layerOrigin[0] = origin else menuOrigin[0] = origin
            when (section) {
                HomeSection.DHIKR -> daily.openVird(null)
                HomeSection.QURAN -> {
                    // The bookmark if there is one, al-Fatiha on the very first visit.
                    val mark = com.nur.prayer.quran.QuranStore.get(appContext).mark
                    quranNav.read(mark?.surah ?: 1, mark?.ayah ?: 0)
                }
                else -> Unit
            }
            if (nav.current == TAB_HOME) nav.go(route) else nav.switchTo(route)
        }
    }
    // The moon in the capsule: home, the page sinking back into the moon it was left by.
    val goHome: (Offset) -> Unit = { origin ->
        if (nav.layerOpen) layerOrigin[0] = origin else menuOrigin[0] = origin
        nav.go(TAB_HOME)
    }
    val capsuleRoute = nav.current
    val islandOn = ShellRoutes.islandOn(capsuleRoute)
    val capsuleOn = ShellRoutes.capsuleOn(capsuleRoute)
    val layoutDirection = if (L10n.language.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(
        // Scrolling pages keep their last line above the capsule when it is there.
        LocalDockInset provides (bottom + if (capsuleOn) CapsuleRoom else 28.dp),
        LocalIslandInset provides (if (islandOn) IslandRoom else 0.dp),
        LocalShell provides shell,
        LocalFrost provides frostSource,
        LocalBackdropPaused provides backdropPaused,
        LocalLanguageSwitcher provides switchLanguage,
        LocalLayoutDirection provides layoutDirection
    ) {
        Box(Modifier.fillMaxSize()) {
            com.nur.prayer.ui.wallpaper.WallpaperBackdrop(
                wallpaper, palette,
                motionEnabled = data?.settings?.ambientBackdrop == true,
                dim = { maxOf(calendar.progress, pageDim) },
                lift = { paperLift }
            )
            Box(Modifier.fillMaxSize().statusBarsPadding().absolutePadding(left = sideLeft, right = sideRight).graphicsLayer {
                val f = languageFade.value
                alpha = 1f - f
                scaleX = 1f - 0.015f * f
                scaleY = 1f - 0.015f * f
            }) {
              if (homeOnScreen) Box(
                Modifier.fillMaxSize().graphicsLayer {
                    val p = calendar.progress
                    alpha = RevealMath.homeAlpha(p)
                    translationY = if (layerOrigin[0].isSpecified) 0f else -p * 40.dp.toPx()
                    scaleX = 1f - 0.04f * p
                    scaleY = 1f - 0.04f * p
                }
              ) {
                AnimatedContent(
                    targetState = rootTarget,
                    transitionSpec = spec@{
                        val menuPair = menuOrigin[0].isSpecified && (
                            (initialState == TAB_HOME && targetState in MENU_ROUTES) ||
                                (targetState == TAB_HOME && initialState in MENU_ROUTES))
                        if (menuPair) {
                            // The page carries its own motion (MenuRevealBox). Home sinks a little under it
                            // and fades out late, then rises back as the page leaves: layer transforms only.
                            return@spec if (targetState == TAB_HOME)
                                ((fadeIn(tween(MenuRevealMotion.CLOSE_MILLIS)) +
                                    androidx.compose.animation.scaleIn(
                                        tween(MenuRevealMotion.CLOSE_MILLIS, easing = MenuRevealMotion.Rise),
                                        initialScale = MenuRevealMotion.HOME_SCALE
                                    )) togetherWith
                                    fadeOut(tween(MenuRevealMotion.CLOSE_MILLIS), targetAlpha = 1f))
                                    .apply { targetContentZIndex = -1f }.using(null)
                            else ((fadeIn(tween(MenuRevealMotion.OPEN_MILLIS), initialAlpha = 1f)) togetherWith
                                (fadeOut(tween(MenuRevealMotion.OPEN_MILLIS - MenuRevealMotion.HOME_FADE_DELAY,
                                    delayMillis = MenuRevealMotion.HOME_FADE_DELAY)) +
                                    androidx.compose.animation.scaleOut(
                                        tween(MenuRevealMotion.OPEN_MILLIS, easing = MenuRevealMotion.Rise),
                                        targetScale = MenuRevealMotion.HOME_SCALE
                                    )))
                                .apply { targetContentZIndex = 1f }.using(null)
                        }
                        val deeper = routeDepth(targetState) > routeDepth(initialState)
                        val shallower = routeDepth(targetState) < routeDepth(initialState)
                        if (ROUTE_CITY == (if (deeper) targetState else if (shallower) initialState else null)) {
                            // 0.18.6: the city page is opaque like settings, so it is a plain push —
                            // nothing fades, the page underneath only steps aside, and no sky can
                            // flash through a half-transparent gap on the way in or out.
                            val push = tween<IntOffset>(
                                if (deeper) NavigationMotion.DETAIL_ENTER_MILLIS else NavigationMotion.DETAIL_EXIT_MILLIS,
                                easing = FastOutSlowInEasing
                            )
                            return@spec (if (deeper)
                                slideInHorizontally(push) { it } togetherWith slideOutHorizontally(push) { -it / 8 }
                            else
                                slideInHorizontally(push) { -it / 8 } togetherWith slideOutHorizontally(push) { it })
                                .apply { targetContentZIndex = if (deeper) 1f else -1f }.using(null)
                        }
                        val enter = when {
                            deeper -> slideInHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS, easing = FastOutSlowInEasing)) { it } +
                                fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS))
                            shallower -> fadeIn(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) +
                                slideInHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) { -it / 10 }
                            else -> fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS))
                        }
                        val exit = when {
                            shallower -> slideOutHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS, easing = FastOutLinearInEasing)) { it } +
                                fadeOut(tween(NavigationMotion.DETAIL_EXIT_MILLIS))
                            deeper -> fadeOut(tween(NavigationMotion.EXIT_MILLIS)) +
                                slideOutHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS)) { -it / 10 }
                            else -> fadeOut(tween(NavigationMotion.EXIT_MILLIS))
                        }
                        (enter togetherWith exit).apply { targetContentZIndex = if (shallower) -1f else 1f }.using(null)
                    }, label = "nurRoute", modifier = Modifier.fillMaxSize()
                ) { route ->
                    pages.SaveableStateProvider(route) {
                        if (data == null) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(tr("Считаем солнце…"), color = TextSecondary)
                            }
                        } else when (route) {
                            ROUTE_CITY -> OpaquePage(palette) { CityPickerScreen(palette, data.settings.cityId, citySearch,
                                onPick = { city -> onPickCity(city); nav.back() }, onBack = { nav.back() },
                                onUseLocation = actions.requestLocation, locating = locating, locationStatus = locationStatus,
                                currentPlace = data.place, locationButtonLabel = locationButtonLabel,
                                onOpenLocationPermissions = actions.openLocationPermissions) }
                            TAB_SETTINGS, TAB_QIBLA, TAB_SCHEDULE -> MenuRevealBox(
                                active = {
                                    val other = if (rootPrevious[1] == route) rootPrevious[0] else rootPrevious[1]
                                    other == TAB_HOME
                                },
                                originInRoot = { menuOrigin[0] },
                                veil = { veil }
                            ) {
                                if (route == TAB_SCHEDULE) ScheduleScreen(data, now, palette, lightBackdrop = paperPage)
                                else if (route == TAB_SETTINGS) SettingsScreen(withWallpaperChoice(data, wallpaperChoice), palette, actions, exactAlarmsAllowed, locating, locationStatus,
                                    notificationsAllowed = notificationsAllowed, locationButtonLabel = locationButtonLabel,
                                    onBack = { nav.back() }, onOpenWallpapers = { wallpapersOpen = true })
                                else QiblaScreen(data, palette, onBack = { nav.back() })
                            }
                            else -> Box(Modifier.fillMaxSize()) { HomeScreen(
                                data = data, now = now, palette = palette,
                                onOpenCity = { nav.go(ROUTE_CITY) },
                                onOpenSettings = { origin -> menuOrigin[0] = origin; nav.go(TAB_SETTINGS) },
                                onOpenSchedule = { menuOrigin[0] = Offset.Unspecified; nav.go(TAB_SCHEDULE) },
                                onOpenPrayer = { prayer -> sheetName = prayer.name }
                            )
                                // 0.18.6: until a place is chosen, home asks for it (see FirstPlaceCard).
                                com.nur.prayer.ui.home.FirstPlaceCard(
                                    visible = !data.settings.placeChosen,
                                    placeLabel = data.place.label,
                                    palette = palette,
                                    locating = locating,
                                    status = locationStatus,
                                    onLocate = actions.requestLocation,
                                    onPickCity = { nav.go(ROUTE_CITY) },
                                    modifier = Modifier.align(Alignment.TopCenter)
                                )
                            }
                        }
                    }
                }
              }
              if (data != null && scheduleOnScreen) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .onGloballyPositioned { layerTopLeft[0] = it.positionInRoot() }
                        .graphicsLayer {
                            val p = calendar.progress
                            val origin = layerOrigin[0]
                            if (origin.isSpecified && p < 1f) {
                                // Out of the sector it was chosen on, the same motion as Кыбла and Настройки.
                                val local = origin - layerTopLeft[0]
                                transformOrigin = TransformOrigin(
                                    (local.x / size.width).coerceIn(0f, 1f),
                                    (local.y / size.height).coerceIn(0f, 1f)
                                )
                                val s = MenuRevealMotion.FROM_SCALE + (1f - MenuRevealMotion.FROM_SCALE) * p
                                scaleX = s
                                scaleY = s
                                translationY = 0f
                                alpha = RevealGeometry.contentAlpha(p)
                                clip = true
                                shape = RoundedCornerShape(((1f - p) * MenuRevealMotion.CORNER_DP).dp)
                            } else {
                                transformOrigin = TransformOrigin.Center
                                scaleX = 1f
                                scaleY = 1f
                                translationY = if (origin.isSpecified) 0f else (1f - p) * size.height
                                alpha = if (origin.isSpecified) 1f else RevealMath.calendarAlpha(p)
                                clip = false
                                shape = RectangleShape
                            }
                        }
                ) {
                    AnimatedContent(
                        targetState = lastLayer[0],
                        transitionSpec = {
                            val deeper = layerDepth(targetState) > layerDepth(initialState)
                            // Every layer page fills the screen, so there is no size to animate; without a
                            // SizeTransform nothing clips a page mid-transition (the Quran draws its surface
                            // up under the status bar, outside its bounds).
                            // Stories open like a card lifting off the page, not as a sideways step.
                            (if (targetState == ROUTE_STORY) (fadeIn(tween(200)) + androidx.compose.animation.scaleIn(tween(260, easing = FastOutSlowInEasing), initialScale = 0.9f)) togetherWith
                                fadeOut(tween(200))
                            else if (initialState == ROUTE_STORY) fadeIn(tween(200)) togetherWith
                                (fadeOut(tween(200)) + androidx.compose.animation.scaleOut(tween(220), targetScale = 0.92f))
                            else if (deeper) (slideInHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS, easing = FastOutSlowInEasing)) { it } +
                                fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS))) togetherWith
                                (fadeOut(tween(NavigationMotion.EXIT_MILLIS)) + slideOutHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS)) { -it / 10 })
                            else (fadeIn(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) + slideInHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) { -it / 10 }) togetherWith
                                (slideOutHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS, easing = FastOutLinearInEasing)) { it } +
                                    fadeOut(tween(NavigationMotion.DETAIL_EXIT_MILLIS)))).using(null)
                        }, label = "layerRoute", modifier = Modifier.fillMaxSize()
                    ) { route ->
                        pages.SaveableStateProvider(route) {
                          androidx.compose.runtime.CompositionLocalProvider(com.nur.prayer.ui.learn.LocalArabicVoice provides arabicVoice) {
                            when (route) {
                                ROUTE_COURSE -> CourseScreen(learn, learnContent?.course, learnProgress, palette,
                                    onBack = { nav.back() }, onOpenLesson = { nav.go(ROUTE_LESSON) },
                                    onOpenDictionary = { dictionaryFocus.value = null; nav.go(ROUTE_DICTIONARY) })
                                ROUTE_LESSON -> LessonScreen(learn, activeLesson, palette, onClose = { nav.back() })
                                ROUTE_DICTIONARY -> DictionaryScreen(learnContent, learnProgress, palette, focus = dictionaryFocus.value,
                                    onBack = { nav.back() })
                                ROUTE_SURAH -> SurahScreen(learnContent, learnProgress, palette, onBack = { nav.back() },
                                    onPractice = { n -> if (learn.start(QuranShort.lessonId(n), force = true)) nav.go(ROUTE_LESSON) })
                                ROUTE_AZKAR -> AzkarScreen(
                                    daily, items = { set -> Azkar.of(set, learnContent?.quran) },
                                    currentSet = AzkarSet.at(data.window.current),
                                    sessionOf = { set -> azkarSession(set, data.window) },
                                    palette = palette, onBack = { nav.back() })
                                ROUTE_DHIKR -> DhikrScreen(daily, palette, onBack = { nav.back() })
                                ROUTE_QURAN -> com.nur.prayer.ui.quran.QuranScreen(
                                    quranNav, palette, onBack = { nav.back() },
                                    reviewed = quranReviewed, onReview = { s, a -> learn.addAyah(s, a) }
                                )
                                ROUTE_STORY -> StoryScreen(
                                    storySlides(learn.today(), learnContent), daily.storyStart, daily.storyOpening, palette.accent,
                                    onSeen = { i -> daily.markStorySeen(i) }, onClose = { nav.back() })
                                else -> {
                                    val set = AzkarSet.at(data.window.current)
                                    val azkarList = Azkar.of(set, learnContent?.quran)
                                    val counts = azkarSessions[azkarSession(set, data.window)].orEmpty()
                                    TodayScreen(
                                        TodayState(
                                            hijri = data.hijri, today = learn.today(), content = learnContent, progress = learnProgress,
                                            azkarSet = set, azkarDone = azkarList.count { (counts[it.id] ?: 0L) >= it.count },
                                            azkarTotal = azkarList.size,
                                            vird = vird, dhikrToday = dhikrToday,
                                            storyMask = storyMask,
                                            quranMark = com.nur.prayer.quran.QuranStore.get(appContext).mark,
                                            quranKhatm = com.nur.prayer.quran.QuranStore.get(appContext).khatm
                                        ),
                                        palette, calendar,
                                        TodayActions(
                                            close = { nav.back() },
                                            story = { i -> daily.openStory(i); nav.go(ROUTE_STORY) },
                                            quran = {
                                                // The bookmark if there is one, al-Fatiha on the very first visit.
                                                val mark = com.nur.prayer.quran.QuranStore.get(appContext).mark
                                                quranNav.read(mark?.surah ?: 1, mark?.ayah ?: 0)
                                                nav.go(ROUTE_QURAN)
                                            },
                                            azkar = { nav.go(ROUTE_AZKAR) },
                                            dhikr = { id -> daily.openVird(id); nav.go(ROUTE_DHIKR) },
                                            continueLesson = {
                                                val next = learnContent?.course?.next(learnProgress)
                                                if (next != null) openLesson(next.id) else nav.go(ROUTE_COURSE)
                                            },
                                            course = { nav.go(ROUTE_COURSE) },
                                            review = { openLesson(Course.REVIEW_ID) },
                                            word = { id -> dictionaryFocus.value = id; nav.go(ROUTE_DICTIONARY) },
                                            dictionary = { dictionaryFocus.value = null; nav.go(ROUTE_DICTIONARY) },
                                            surahs = { nav.go(ROUTE_SURAH) },
                                            schedule = { menuOrigin[0] = Offset.Unspecified; nav.go(TAB_SCHEDULE) },
                                            // From the layer there is no menu item to grow out of: the ordinary slide.
                                            qibla = { menuOrigin[0] = Offset.Unspecified; nav.go(TAB_QIBLA) }
                                        )
                                    )
                                }
                            }
                          }
                        }
                    }
                }
              }
            }
            if (data != null) Box(Modifier.fillMaxSize().statusBarsPadding().absolutePadding(left = sideLeft, right = sideRight).graphicsLayer {
                alpha = 1f - languageFade.value
            }) {
                val set = AzkarSet.at(data.window.current)
                val azkarList = remember(set, learnContent) { Azkar.of(set, learnContent?.quran) }
                val counts = azkarSessions[azkarSession(set, data.window)].orEmpty()
                val done = azkarList.count { (counts[it.id] ?: 0L) >= it.count }
                val total = azkarList.size
                ShellLayer(
                    shell = shell,
                    route = capsuleRoute,
                    data = data,
                    now = now,
                    home = CapsuleNow(
                        title = tr(set.title),
                        subtitle = if (total > 0 && done >= total) tr("прочитаны · {0} из {1}", done, total)
                            else tr("сейчас · {0} из {1}", done, total),
                        glyph = ShellGlyph.TASBIH,
                        onClick = { layerOrigin[0] = Offset.Unspecified; nav.go(ROUTE_AZKAR) }
                    ),
                    onOpenSection = openSection,
                    onHome = goHome,
                    onOpenPrayer = { prayer -> sheetName = prayer.name }
                )
                PrayerSheetHost(
                    prayer = sheetPrayer, data = data, now = now, actions = actions,
                    notificationsAllowed = notificationsAllowed, exactAlarmsAllowed = exactAlarmsAllowed,
                    onDismiss = { sheetName = null },
                    onOpenSettings = { sheetName = null; menuOrigin[0] = Offset.Unspecified; nav.go(TAB_SETTINGS) }
                )
            }
            // A light scrim under the system navigation bar: three-button navigation draws white
            // glyphs, and the horizon of a noon or sunset sky is light enough to swallow them.
            // Over the Quran's paper page the glyphs are dark, and the scrim is paper too.
            val paperBars = com.nur.prayer.ui.theme.SystemBarsTone.light
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .windowInsetsBottomHeight(WindowInsets.navigationBars)
                    .background(if (paperBars) NAV_SCRIM_PAPER else NAV_SCRIM_SKY)
            )
            if (data != null) {
                val mock = remember(data.place.label, data.today.date, data.settings.hijriOffset, data.window) {
                    com.nur.prayer.ui.wallpaper.MockHome(
                        place = data.place.label,
                        date = com.nur.prayer.data.HijriCalendar.format(data.today.date, data.settings.hijriOffset),
                        time = Format.clock(data.window.remaining(now.value)),
                        next = "${tr("Следующий")} · ${com.nur.prayer.notify.PrayerLabels.title(data.window.next)} · ${Format.time(data.window.nextStart)}"
                    )
                }
                com.nur.prayer.ui.wallpaper.WallpaperGallery(
                    open = wallpapersOpen,
                    current = wallpaper,
                    palette = palette,
                    mock = mock,
                    onSet = { w -> actions.setWallpaper(w.id) },
                    onClose = { wallpapersOpen = false }
                )
            }
            crashReport.value?.let { report -> CrashReportSheet(report) { crashReport.value = null } }
        }
    }
}

/** [data] as the settings will be once the pending wallpaper [choice] is stored (same instance when none). */
private fun withWallpaperChoice(data: PrayerData, choice: String?): PrayerData {
    if (choice == null || data.settings.wallpaperId == choice) return data
    val s = data.settings
    return data.copy(settings = s.copy(
        wallpaperId = choice,
        recentWallpapers = com.nur.prayer.ui.wallpaper.WallpaperOrder.remember(choice, s.recentWallpapers),
        skyBackdrop = choice != com.nur.prayer.ui.wallpaper.WallpaperCatalog.AMOLED_ID
    ))
}

private val NAV_SCRIM_SKY = Brush.verticalGradient(listOf(Color(0x14000000), Color(0x59000000)))
private val NAV_SCRIM_PAPER = Brush.verticalGradient(listOf(Color(0x14F3EAD3), Color(0xB3F3EAD3)))

/** Pages opened from a cell of the panel or the avatar: they grow out of it and sink back into it. */
internal val MENU_ROUTES = setOf(TAB_QIBLA, TAB_SETTINGS, TAB_SCHEDULE)

/** Inside the pulled-up layer: today 0, course/dictionary/surahs 1, a lesson 2. */
internal fun layerDepth(route: String): Int = when (route) {
    ROUTE_TODAY -> 0
    ROUTE_LESSON, ROUTE_STORY -> 2
    else -> 1
}

/** Home 0, the three sections 1, the city picker 2: deeper slides in from the right. */
/**
 * The settings surface for pages that live "inside" settings (the city picker): drawn up behind the
 * status bar so the push transition moves one solid sheet, never a page with sky showing through.
 */
@Composable
private fun OpaquePage(palette: PhasePalette, content: @Composable () -> Unit) {
    val colors = remember(palette) { com.nur.prayer.ui.settings.SettingsColors.of(palette) }
    val statusTop = with(LocalDensity.current) { WindowInsets.statusBars.getTop(this).toFloat() }
    Box(Modifier.fillMaxSize().drawBehind {
        drawRect(colors.background, topLeft = Offset(0f, -statusTop), size = Size(size.width, size.height + statusTop))
    }) { content() }
}

internal fun routeDepth(route: String): Int = when (route) {
    TAB_HOME -> 0
    ROUTE_CITY -> 2
    else -> 1
}

/** The azkar session the counters belong to: the set and the day its prayer window began. */
internal fun azkarSession(set: AzkarSet, window: com.nur.prayer.core.astro.PrayerWindow): String {
    val day = if (AzkarSet.at(window.current) == set) window.currentStart.toLocalDate() else java.time.LocalDate.now()
    return AzkarSet.sessionKey(set, day)
}

/** Ayah, hadith and dua of the day, then the word of the day from the course lexicon. */
internal fun storySlides(today: Long, content: com.nur.prayer.learn.LearnContent?): List<StorySlide> {
    val base = DailyStories.of(today)
    val w = content?.lexicon?.wordOfDay(today) ?: return base
    return base + StorySlide(com.nur.prayer.ui.daily.WORD_KIND, w.arabic, w.translit, w.ru, tr("Словарь курса · ") + w.letters.joinToString(" · ") { it.name },
        voiced = w.machineVoiceAllowed)
}

private const val LANGUAGE_OUT_MILLIS = 150
private const val LANGUAGE_IN_MILLIS = 260
