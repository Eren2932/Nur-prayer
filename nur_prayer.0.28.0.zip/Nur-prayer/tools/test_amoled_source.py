from pathlib import Path
import re
import unittest
from design_contract import validate_ambient, validate_compass

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/com/nur/prayer/ui'

class AmoledSourceTest(unittest.TestCase):
    def test_primary_screens_have_no_decorative_copy(self):
        texts = '\n'.join((UI / path).read_text() for path in (
            'home/HomeScreen.kt', 'qibla/QiblaScreen.kt', 'schedule/ScheduleScreen.kt',
            'settings/SettingsScreen.kt', 'settings/CityPickerScreen.kt'))
        for phrase in ('Ваш Нур', 'Время для главного', 'ПУТЬ ВРЕМЕНИ', 'РИТМ ДНЕЙ',
                       'ЛИЧНОЕ ПРОСТРАНСТВО', 'Где встречаем рассвет?', 'ОДНО НАПРАВЛЕНИЕ'):
            self.assertNotIn(phrase, texts)

    def test_main_screens_do_not_use_panel_wrappers(self):
        for path in ('home/HomeScreen.kt', 'qibla/QiblaScreen.kt', 'schedule/MonthCalendar.kt', 'schedule/ScheduleScreen.kt'):
            self.assertNotIn('AtlasPanel(', (UI / path).read_text())

    def test_all_settings_editors_remain(self):
        text = (UI / 'settings/SettingsScreen.kt').read_text()
        for editor in ('method', 'madhab', 'notify', 'azan', 'highlat', 'rounding', 'offsets', 'about'):
            self.assertRegex(text, r'id\s*=\s*"' + editor + '"')
        self.assertIn('actions.stopAzan()', text)
        self.assertIn('BackHandler(enabled = open != null)', text)

    def test_compass_does_not_draw_untrusted_direction(self):
        text = (UI / 'qibla/QiblaScreen.kt').read_text()
        self.assertIn('heading.available && heading.usable && delta.isFinite()', text)
        self.assertIn('val ready = steady && (usable || motion.locked) && searchShown', text)
        self.assertIn('nearestDialRotation', text)
        self.assertIn('QiblaGuidance.aligned', text)
        # The restored instrument intentionally has cardinal labels and a ray.
        # Protect sensor trust instead of banning these approved visual elements.
        validate_compass(text)

    def test_sparse_backdrop_keeps_black_and_respects_motion_policy(self):
        validate_ambient((UI / 'components/SkyBackdrop.kt').read_text(),
                         (UI / 'components/MotionPolicy.kt').read_text())

    def test_month_swipe_has_both_bounds_and_latest_callback(self):
        text = (UI / 'schedule/MonthCalendar.kt').read_text()
        self.assertIn('rememberUpdatedState(onMonth)', text)
        self.assertIn('distance < -threshold && month < max', text)
        self.assertIn('distance > threshold && month > min', text)
        # 0.28.0: the grid has the weeks the month needs (4-6), not a fixed six rows
        self.assertIn('cells.chunked(7)', text)
        self.assertNotIn('List(42)', text)

    def test_contrast_of_standard_text_surfaces(self):
        """0.6.0 sky contract: text stays legible on every prayer palette, not only on black.

        The backdrop is modelled the way SkyBackdrop draws it (gradient, horizon glow, bottom
        scrim) and sampled where text actually sits. Source arithmetic, not a screenshot test.
        """
        colors_src = (UI / 'theme/Color.kt').read_text()
        sky_src = (UI / 'components/SkyBackdrop.kt').read_text()
        argb = lambda h: (int(h[0:2], 16) / 255, [int(h[i:i + 2], 16) / 255 for i in (2, 4, 6)])
        solid = {n: argb('FF' + h) for n, h in re.findall(r'val (\w+) = Color\(0xFF([0-9A-F]{6})\)', colors_src)}
        alpha = {n: argb(h) for n, h in re.findall(r'val (\w+) = Color\(0x([0-9A-F]{8})\)', colors_src)}
        self.assertEqual(solid['Ink'][1], [0, 0, 0])
        scrim = float(re.search(r'HORIZON_SCRIM_ALPHA = ([0-9.]+)f', sky_src)[1])
        scrim_start = float(re.search(r'HORIZON_SCRIM_START = ([0-9.]+)f', sky_src)[1])
        self.assertIn('HORIZON_SCRIM_START to Color.Transparent', sky_src)
        self.assertGreaterEqual(scrim_start, 0.45, 'scrim must stay below the list card centre')
        self.assertGreater(scrim, 0.3, 'scrim is what keeps noon legible')
        self.assertLess(scrim, 0.6, 'scrim must not turn the sky back into black')

        def over(top, bottom):
            a, rgb = top
            return [c * a + b * (1 - a) for c, b in zip(rgb, bottom)]

        def lum(rgb):
            rgb = [v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in rgb]
            return sum(x * w for x, w in zip(rgb, (0.2126, 0.7152, 0.0722)))

        def ratio(a, b):
            hi, lo = sorted((lum(a), lum(b)), reverse=True)
            return (hi + 0.05) / (lo + 0.05)

        def mix(a, b, t):
            return [x + (y - x) * t for x, y in zip(a, b)]

        palettes = re.findall(
            r'zenith = Color\(0xFF(\w{6})\), mid = Color\(0xFF(\w{6})\), horizon = Color\(0xFF(\w{6})\),\s*'
            r'glow = (Color\.Transparent|Color\(0x(\w{8})\)).*?sheet = Color\(0xFF(\w{6})\).*?name = "(\w+)"',
            colors_src, re.S)
        self.assertEqual(7, len(palettes))
        text = {k: solid[k][1] for k in ('TextPrimary', 'TextSecondary', 'TextTertiary')}

        def backdrop(p, y):
            zenith, mid, horizon = (argb('FF' + h)[1] for h in p[:3])
            base = mix(zenith, mid, y / 0.55) if y <= 0.55 else mix(mid, horizon, (y - 0.55) / 0.45)
            if p[4]:  # radial glow centred just below the bottom edge, radius 0.95 w; screen ~2:1
                a, rgb = argb(p[4])
                distance = ((1.02 - y) * 2.0) / 0.95
                base = over((a * max(0.0, 1 - distance), rgb), base)
            if y > scrim_start:
                base = over((scrim * (y - scrim_start) / (1 - scrim_start), [0, 0, 0]), base)
            return base

        for p in palettes:
            name = p[6]
            with self.subTest(palette=name):
                header = backdrop(p, 0.06)
                for k in ('TextPrimary', 'TextSecondary'):
                    self.assertGreaterEqual(ratio(text[k], header), 4.5, (name, 'header', k))
                for y in (0.80, 0.86, 0.92):  # day note and pull hint: TextPrimary, 12 sp, shadowed
                    self.assertGreaterEqual(ratio(text['TextPrimary'], backdrop(p, y)), 4.5, (name, y))
                sheet = argb('FF' + p[5])[1]
                glass = over(alpha['Glass'], backdrop(p, 0.5))
                for k, colour in text.items():
                    self.assertGreaterEqual(ratio(colour, sheet), 4.5, (name, 'sheet', k))
                    self.assertGreaterEqual(ratio(colour, glass), 4.5, (name, 'glass', k))

if __name__ == '__main__':
    unittest.main(verbosity=2)
