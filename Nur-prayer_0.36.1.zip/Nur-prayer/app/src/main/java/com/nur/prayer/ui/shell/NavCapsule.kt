package com.nur.prayer.ui.shell

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.paddingFromBaseline
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.toRect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.home.HomeSection
import com.nur.prayer.ui.home.HomeTimeline
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/*
 * 0.27.0 «Капсула» (variant D of the redesign).
 *
 *  - Home: the times are printed on the wallpaper; at the bottom one floating capsule says what fits
 *    this moment («Вечерние азкары · сейчас · 0 из 12»). A tap on its text starts that; a tap on the
 *    dots opens the panel.
 *  - The panel is the same glass grown in place (shared bounds): today's six times (a tap opens the
 *    prayer's sheet, the speaker marks the azan) and the six sections, each one tap away. A tap
 *    beside it, or back, folds it back into the capsule.
 *  - In a section the capsule says where you are («Кыбла · тап — другие разделы») and opens the same
 *    panel; the moon leads home; the countdown lives in the island at the top.
 *
 * No swipes and no hidden gestures: everything is visible and tappable, TalkBack reads it as is.
 * Every sizes and colours here are taken from the mock (see ShellColors).
 *
 * 0.33.0 «Минарет»: a new mock, a warm cream glass with a minaret roof on the panel.
 *
 * 0.36.0 «Бумага»: the cream and the roof are gone. The new mock is paper: a flat #FAFAFA panel with no rim, cards
 * that are only a soft shade, black ink; the section wells are saturated discs with a white glyph, one hue per
 * section (see ShellTones), and the capsule is smaller (50 dp, a 34 dp pastel disc, no divider, a quiet dots
 * button) and takes the hue of the place or of the task it offers. The glyphs themselves are the same as in 0.33.0.
 * Every size below is a measurement of the mock at 1.4667 px per dp (576 px = 393 dp, a 1080 px phone at 2.75
 * density, downscaled): the comments give the pixels they come from.
 *
 * 0.27.1, the motion:
 *  - the capsule and the panel stay composed for as long as the capsule is on a route. Opening used to
 *    compose ~60 nodes of the panel on the first frame of the morph (and the capsule's content again on
 *    the last frame of the fold): that was the stutter. Now only a float moves;
 *  - layers fade per draw call ([CompositingStrategy.ModulateAlpha]): no offscreen buffer the size of the
 *    panel in every frame of the fade;
 *  - the glass has no elevation shadow and no path clip (see Frost.kt);
 *  - a capsule that comes or goes slides by a layout offset, not a layer translation, so the glass keeps
 *    knowing where on screen it is and the blurred picture inside it never lags behind;
 *  - [ShellState.capsuleHidden]: a page can send the capsule away (the Quran reader while one reads) and
 *    call it back with one float.
 */

/** What the capsule says on home: the thing that fits this moment, and what a tap on it does. */
@Immutable
class CapsuleNow(
    val title: String,
    val subtitle: String,
    val glyph: ShellGlyph,
    /**
     * The hue of the task on offer (0.36.0): mint for the evening azkar, gold for the morning ones.
     * 0.36.1: placed before [onClick] so the click stays the trailing lambda of every call site.
     */
    val tone: ShellTone = ShellTones.EVENING,
    val onClick: () -> Unit
)

/** 0.36.0: 74 px of 576 in the mock: 50 dp (it was 64). */
private val CAPSULE_HEIGHT = 50.dp
/** «Вечерние азкары» at 13.5 sp is 114 dp wide; with the disc, the gaps and the button that is 240 dp, and 256 leaves air. */
private val CAPSULE_MIN_WIDTH = 256.dp
private val CAPSULE_MAX_WIDTH = 340.dp
private val PANEL_MAX_WIDTH = 460.dp
/** 0.36.0: 32 px of 576 in the mock: 22 dp on both sides (it was 20). */
private val PANEL_SIDE = 22.dp
/** 0.36.0: 39 px: 26.6 dp (it was 32). */
private val PANEL_CORNER = 26.6.dp
/** What the home and the pages reserve under their content for the capsule. Unchanged since 0.27.0. */
private val BOTTOM_GAP = 14.dp

/** 0.30.2: where the capsule really stands above the navigation bar: 1 dp lower than the room it has reserved. */
private val CAPSULE_BOTTOM = 13.dp

/**
 * Bottom room the capsule takes above the navigation bar; pages under it pad their lists by it. 0.36.0: the capsule
 * got 14 dp lower, the room did not: the clock, the timeline and every page stay exactly where the user knows them.
 */
val CapsuleRoom = 90.dp

/** Room the island takes under the status bar; page headers step down by it. */
val IslandRoom = 50.dp

@Composable
fun ShellLayer(
    shell: ShellState,
    route: String,
    data: PrayerData,
    now: State<ZonedDateTime>,
    home: CapsuleNow,
    onOpenSection: (HomeSection, Offset) -> Unit,
    onHome: (Offset) -> Unit,
    onOpenPrayer: (Prayer) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val capsuleOn = ShellRoutes.capsuleOn(route)
    val islandOn = ShellRoutes.islandOn(route)
    // The page under the capsule keeps being named while the capsule slides away with it.
    val lastSection = remember { arrayOfNulls<HomeSection>(1) }
    val liveSection = ShellRoutes.sectionOf(route)
    if (capsuleOn) lastSection[0] = liveSection
    val section = if (capsuleOn) liveSection else lastSection[0]

    // A hidden capsule is not a capsule the panel can grow out of.
    val capsuleVisible = ShellMath.capsuleVisible(capsuleOn, shell.capsuleHidden)
    LaunchedEffect(capsuleVisible) { if (!capsuleVisible) shell.hide() }
    LaunchedEffect(shell.open) {
        coroutineScope {
            // 0.30.2: the vibrator call goes after the first frame of the morph, not in front of it: on a
            // phone where it takes a few milliseconds that used to be a hitch right at the tap.
            if (shell.open) launch {
                withFrameNanos { }
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            }
            shell.settle()
        }
    }
    BackHandler(enabled = shell.open) { shell.hide() }

    val panelOnScreen by remember(shell) { derivedStateOf { shell.open || shell.progress > 0.001f } }
    val capsuleShown = animateFloatAsState(
        if (capsuleVisible) 1f else 0f,
        tween(if (capsuleVisible) 320 else 200, easing = FastOutSlowInEasing),
        label = "capsuleShown"
    )
    val islandShown = animateFloatAsState(
        if (islandOn) 1f else 0f,
        tween(if (islandOn) 320 else 180, easing = FastOutSlowInEasing),
        label = "islandShown"
    )
    val capsuleComposed by remember { derivedStateOf { capsuleOn || capsuleShown.value > 0f } }
    val islandComposed by remember { derivedStateOf { islandOn || islandShown.value > 0f } }

    Box(modifier.fillMaxSize()) {
        if (panelOnScreen) {
            // A tap anywhere beside the panel folds it; the page under it stays where it was.
            Box(
                Modifier
                    .fillMaxSize()
                    .drawBehind { drawRect(Color.Black, alpha = SCRIM_ALPHA * shell.progress.coerceIn(0f, 1f)) }
                    .pointerInput(shell) { detectTapGestures { shell.hide() } }
            )
        }
        if (islandComposed) {
            TopIsland(
                data, now, onTap = onHome,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 6.dp)
                    .offset { IntOffset(0, (-(1f - islandShown.value) * 20.dp.toPx()).roundToInt()) }
                    .graphicsLayer {
                        val k = islandShown.value
                        alpha = k
                        compositingStrategy = CompositingStrategy.ModulateAlpha
                        val s = 0.92f + 0.08f * k
                        scaleX = s
                        scaleY = s
                    }
            )
        }
        if (capsuleComposed) {
            CapsuleMorph(
                shell = shell,
                visible = capsuleVisible,
                section = section,
                home = home,
                data = data,
                onOpenSection = { s, origin ->
                    shell.hide()
                    // The page the section opens on is already showing: folding the panel is the answer.
                    if (route != ShellRoutes.routeOf(s)) onOpenSection(s, origin)
                },
                onHome = { origin -> shell.hide(); onHome(origin) },
                onOpenPrayer = { p -> shell.hide(); onOpenPrayer(p) },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = CAPSULE_BOTTOM)
                    .offset { IntOffset(0, ((1f - capsuleShown.value) * ShellMath.SLIDE_DP.dp.toPx()).roundToInt()) }
                    .graphicsLayer {
                        alpha = capsuleShown.value
                        compositingStrategy = CompositingStrategy.ModulateAlpha
                    }
            )
        }
    }
}

private const val SCRIM_ALPHA = 0.30f

/** The rounded rectangle of the glass: a pill while closed, the panel's corners once open. */
private class MorphShape(private val shell: ShellState) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val p = shell.progress.coerceIn(0f, 1f)
        val r = with(density) { ShellMath.lerp(CAPSULE_HEIGHT.toPx() / 2f, PANEL_CORNER.toPx(), p) }
            .coerceAtMost(size.minDimension / 2f)
        return Outline.Rounded(RoundRect(size.toRect(), CornerRadius(r)))
    }
}

@Composable
private fun CapsuleMorph(
    shell: ShellState,
    visible: Boolean,
    section: HomeSection?,
    home: CapsuleNow,
    data: PrayerData,
    onOpenSection: (HomeSection, Offset) -> Unit,
    onHome: (Offset) -> Unit,
    onOpenPrayer: (Prayer) -> Unit,
    modifier: Modifier = Modifier
) {
    val frost = rememberFrost()
    val shape = remember(shell) { MorphShape(shell) }
    val open = shell.open

    // The capsule's body is a hair greyer than the panel's (#F8F8F8, #FAFAFA): the morph lerps one into the other.
    val body = remember(shell) { { ShellTones.mix(ShellColors.CapsuleBody, ShellColors.Glass, shell.progress.coerceIn(0f, 1f)) } }
    Layout(
        content = {
            // Both faces stay composed; only the one that is up answers touches and TalkBack.
            Box(if (open || !visible) Modifier.clearAndSetSemantics { } else Modifier) {
                CapsuleContent(
                    section = section, home = home, enabled = visible && !open,
                    onExpand = { shell.show() }, onHome = onHome
                )
            }
            Box(if (open) Modifier else Modifier.clearAndSetSemantics { }) {
                PanelContent(
                    data = data, current = section, enabled = open,
                    onOpenPrayer = onOpenPrayer, onOpenSection = onOpenSection
                )
            }
        },
        modifier = modifier
            .frostGlass(frost, shape, body = body)
            .onGloballyPositioned { c -> shell.glassBottomInRoot = c.boundsInRoot().bottom }
    ) { measurables, constraints ->
        val p = ShellMath.clampProgress(shell.progress)
        val maxW = constraints.maxWidth
        val capW = ShellMath.capsuleWidth(
            maxW.toFloat(), CAPSULE_MIN_WIDTH.toPx(), CAPSULE_MAX_WIDTH.toPx(), PANEL_SIDE.toPx()
        ).roundToInt().coerceAtMost(maxW)
        val capH = CAPSULE_HEIGHT.roundToPx()
        val panelW = minOf(maxW - 2 * PANEL_SIDE.roundToPx(), PANEL_MAX_WIDTH.roundToPx()).coerceAtLeast(capW)
        val capsule = measurables[0].measure(Constraints.fixed(capW, capH))
        val panel = measurables[1].measure(
            Constraints(minWidth = panelW, maxWidth = panelW, minHeight = 0, maxHeight = constraints.maxHeight)
        )
        val panelH = if (panel.height > 0) panel.height else capH
        val w = ShellMath.lerp(capW.toFloat(), panelW.toFloat(), ShellMath.widthProgress(p)).roundToInt().coerceIn(0, maxW)
        val h = ShellMath.lerp(capH.toFloat(), panelH.toFloat(), p).roundToInt().coerceIn(0, constraints.maxHeight)
        if (panel.height > 0) shell.panelHeightPx = panel.height.toFloat()
        layout(w, h) {
            capsule.placeWithLayer((w - capW) / 2, h - capH) {
                alpha = ShellMath.capsuleAlpha(p)
                compositingStrategy = CompositingStrategy.ModulateAlpha
            }
            panel.placeWithLayer((w - panelW) / 2, 0) {
                alpha = ShellMath.panelAlpha(p)
                compositingStrategy = CompositingStrategy.ModulateAlpha
                translationY = (1f - p.coerceAtMost(1f)) * 14.dp.toPx()
            }
        }
    }
}

/*
 * The closed capsule, with the pixels of the 0.36.0 mock (576 px = 393 dp, 1.4667 px per dp): 397 x 74 px,
 * 271 x 50 dp, a full pill. The disc is 49 px = 34 dp, 21 px = 14.3 dp from the left edge, a 14.3 dp gap to the
 * text. The title's baseline is 21.1 dp under the capsule's top, the subtitle's 16.1 dp under that. No divider;
 * the dots button is centred 25.6 dp from the right edge, its 48 dp hit area ends 1.6 dp short of it.
 *
 * Type: the mock's font is a size heavier than the first reading of it, so the title is 14 sp bold (13.5 measured)
 * and the subtitle 12 sp medium (11.5 measured).
 */
private val CAPSULE_DISC = 34.dp

@Composable
private fun CapsuleContent(
    section: HomeSection?,
    home: CapsuleNow,
    enabled: Boolean,
    onExpand: () -> Unit,
    onHome: (Offset) -> Unit
) {
    Crossfade(targetState = section, animationSpec = tween(220), label = "capsuleSection") { here ->
        val ui = uiScale()
        val title = here?.label() ?: home.title
        val subtitle = if (here == null) home.subtitle else tr("тап — другие разделы")
        val glyph = here?.glyph ?: home.glyph
        // Where the user is, or what is on offer on home, gives the capsule its hue.
        val tone = if (here == null) home.tone else ShellTones.of(here)
        val endCenter = remember { arrayOf(Offset.Unspecified) }
        Row(
            Modifier.fillMaxSize().padding(start = 6.dp, end = 1.6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(50))
                    .clickable(
                        enabled = enabled,
                        role = Role.Button,
                        onClickLabel = if (here == null) title else tr("Разделы"),
                        onClick = { if (here == null) home.onClick() else onExpand() }
                    )
                    .padding(start = 8.3.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CapsuleDisc(glyph, tone)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    // Fits instead of cutting: «Вечерние азкары» is «азка…» on a narrow phone or a large font.
                    // The baselines are fixed, so a title that shrinks does not move.
                    AutoSizeText(
                        title, color = ShellColors.Ink, fontSize = ui.t(14f), minFontSize = ui.t(11.5f),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.paddingFromBaseline(top = 21.1.dp)
                    )
                    Text(
                        subtitle, color = ShellColors.Secondary, fontSize = ui.t(12f),
                        fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.paddingFromBaseline(top = 16.1.dp, bottom = 12.8.dp)
                    )
                }
            }
            val endLabel = if (here == null) tr("Разделы") else tr("На главную")
            Box(
                Modifier
                    .size(48.dp)
                    .onGloballyPositioned { endCenter[0] = it.boundsInRoot().center }
                    .clip(CircleShape)
                    .clickable(enabled = enabled, role = Role.Button, onClickLabel = endLabel) {
                        if (here == null) onExpand() else onHome(endCenter[0])
                    }
                    .semantics { contentDescription = endLabel },
                contentAlignment = Alignment.Center
            ) {
                // The mock's dots: four, 7.5 dp apart, in a mid tone of the capsule's hue.
                if (here == null) ShellIcon(ShellGlyph.DOTS, tone.dots, Modifier.size(22.dp))
                else ShellIcon(ShellGlyph.MOON, tone.dots, Modifier.size(22.dp))
            }
        }
    }
}

/** The pastel disc of the capsule: brighter in the middle than at the rim, the glyph dark in the same hue. */
@Composable
private fun CapsuleDisc(glyph: ShellGlyph, tone: ShellTone) {
    val art = sectionArt(glyph)
    Box(
        Modifier
            .size(CAPSULE_DISC)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(tone.core, tone.container))),
        contentAlignment = Alignment.Center
    ) {
        // The glyph keeps the size and the place it has in its circle on the designer's sheet (the mock's
        // tasbih is 0.59 of the disc, the sheet's share is 0.60).
        if (art != null) {
            ShellIcon(
                glyph, tone.ink,
                Modifier.offset(CAPSULE_DISC * art.dx, CAPSULE_DISC * art.dy).size(CAPSULE_DISC * art.share)
            )
        } else {
            ShellIcon(glyph, tone.ink, Modifier.size(CAPSULE_DISC * AIN_SHARE))
        }
    }
}

/** The letter ع is not on the sheet: half of its disc, as the sheet's glyphs are about. */
private const val AIN_SHARE = 0.5f

/*
 * The open panel, top to bottom, with the pixels of the 0.36.0 mock (576 px = 393 dp, 1.4667 px per dp; y counts
 * from the panel's top edge at 743 px; the panel is 512 x 492 px = 349 x 335.5 dp):
 *
 *   header      58 dp. The gear's disc is 36 dp (53 px), 13.6 dp from the top and 13 dp from the right; the title
 *               starts 27 dp in, its cap line is centred on the disc; an 18 dp upright line stands exactly in the
 *               middle of the panel, the date starts 37.5 dp after it
 *   cards       two rows of three, 58 dp high (85 px), 18 dp corners, 12.3 dp from the edges (18 px), 7.5 dp
 *               between columns and between rows (11 px). The label's baseline is 21.8 dp (32 px) under the
 *               card's top, the time's 27.6 dp under that (49.4 dp from the top); text starts 14.3 dp in; the
 *               speaker is 8.9 x 6.8 dp, its centre 17.7 dp from the right and 16 dp from the top
 *   divider     the line is 190.9 dp from the panel's top (9.4 dp under the cards), 1 dp, 43.6 dp short of the
 *               edges, broken by 22 dp around a small arch; 7.5 dp under it the discs begin
 *   sections    discs of 35 dp (51 px), centres 104 dp apart (the grid is 18.6 dp in from the edges), a row is
 *               64 dp: the label's baseline 14.5 dp under the disc, 14.5 dp over the next one; 12.1 dp under the
 *               last row
 *
 * Type: the mock's face is heavier and a hair wider than Roboto, so the weights are one step up (labels semi-bold,
 * the title and the times bold) and the sizes are measurement + 0.5 sp: the cap heights measured 8.9 dp for the
 * labels (12.5 sp), 10.2 for the title (14.5 sp), 12 for the times (17 sp).
 */
private val HEADER_HEIGHT = 58.dp
private val GEAR = 36.dp
private val GEAR_TOP = 13.6.dp
private val CARD_HEIGHT = 58.dp
private val CARD_CORNER = 18.dp
private val CARD_PAD = 12.3.dp
private val CARD_GAP = 7.5.dp
private val ROW_GAP = 7.5.dp
private val GRID_PAD = 18.6.dp
private val WELL = 35.dp
/** Room for the ring that marks the section the user is in: it is drawn outside the disc, inside the cell. */
private val RING_ROOM = 3.dp
private val PANEL_BOTTOM = 12.1.dp
/** The sheet's glyphs sit a shade smaller in the mock's discs than in the sheet's: 0.41 against 0.475 and the like. */
private const val PANEL_GLYPH_FIT = 0.9f

@Composable
private fun PanelContent(
    data: PrayerData,
    current: HomeSection?,
    enabled: Boolean,
    onOpenPrayer: (Prayer) -> Unit,
    onOpenSection: (HomeSection, Offset) -> Unit
) {
    val ui = uiScale()
    val date = data.today.date
    val nowPrayer = HomeTimeline.current(data.window, data.fajrEqualsDawn)
    val times = PanelTimes.PRAYERS
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(HEADER_HEIGHT)) {
            Row(
                Modifier.fillMaxWidth().height(GEAR).offset(y = GEAR_TOP),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.weight(1f).padding(start = 26.5.dp, end = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        "${tr("Сегодня")} · ${Format.weekday(date)}",
                        color = ShellColors.Ink, fontSize = ui.t(15f), fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                Box(Modifier.width(1.dp).height(18.dp).background(ShellColors.Separator))
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.width(36.2.dp))
                    Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                        Text(
                            Format.dayMonth(date), color = ShellColors.DateInk, fontSize = ui.t(13.5f),
                            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    SettingsGear(enabled = enabled, onOpen = { origin -> onOpenSection(HomeSection.SETTINGS, origin) })
                    Spacer(Modifier.width(13.dp))
                }
            }
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = CARD_PAD), verticalArrangement = Arrangement.spacedBy(ROW_GAP)) {
            times.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CARD_GAP)) {
                    row.forEach { prayer ->
                        TimeCard(
                            prayer = prayer,
                            time = data.today.times[prayer]?.let(Format::time) ?: "—",
                            now = prayer == nowPrayer,
                            azan = PanelTimes.callOn(prayer, data.settings.notifications),
                            enabled = enabled,
                            onClick = { onOpenPrayer(prayer) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(2.dp))
        PanelDivider(Modifier.fillMaxWidth())
        // The discs begin 7.5 dp under the line: the divider's box ends 0.6 dp under it, the cell keeps RING_ROOM.
        Spacer(Modifier.height(3.9.dp))
        HomeSection.GRID.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = GRID_PAD)) {
                row.forEach { s ->
                    SectionCell(s, current = s == current, enabled = enabled, onOpen = onOpenSection, modifier = Modifier.weight(1f))
                }
            }
        }
        Spacer(Modifier.height(PANEL_BOTTOM))
    }
}

/**
 * 0.29.0: settings used to be an avatar in the corner of home. The corner is empty now; the way in is this
 * small button at the end of the panel's header, reachable from home and from every section alike.
 * 0.36.0: the mock's: a round disc a hair darker than the paper (#EBECEE), no shade, no rim, sliders on it.
 */
@Composable
private fun SettingsGear(enabled: Boolean, onOpen: (Offset) -> Unit) {
    val center = remember { arrayOf(Offset.Unspecified) }
    val label = tr("Настройки")
    Box(
        Modifier
            .size(GEAR)
            .onGloballyPositioned { center[0] = it.boundsInRoot().center }
            .clip(CircleShape)
            .background(ShellColors.GearWell)
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) { onOpen(center[0]) }
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) { ShellIcon(ShellGlyph.TUNE, ShellColors.Icon, Modifier.size(17.2.dp)) }
}

/** The six times of the panel: the five prayers and sunrise, as in the mock. */
internal object PanelTimes {
    val PRAYERS: List<Prayer> = listOf(Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)

    /**
     * Whether the card of [prayer] has a call to hear: the azan is switched on for it. Sunrise never has one,
     * whatever the settings hold: it is the end of fajr, not a prayer. The card wears the speaker when this is
     * true and the crossed one when it is not.
     */
    fun callOn(prayer: Prayer, notifications: Map<Prayer, Boolean>): Boolean =
        prayer.isPrayer && notifications[prayer] == true
}

@Composable
private fun TimeCard(
    prayer: Prayer,
    time: String,
    now: Boolean,
    azan: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val ink = if (now) ShellColors.OnNow else ShellColors.Ink
    val label = PrayerLabels.title(prayer)
    val shape = RoundedCornerShape(CARD_CORNER)
    Box(
        modifier
            .height(CARD_HEIGHT)
            .cardShade(CARD_CORNER)
            .clip(shape)
            .background(if (now) ShellColors.NowCard else ShellColors.Card)
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = tr("Подробнее"), onClick = onClick)
            .semantics { contentDescription = "$label $time" }
    ) {
        // The baselines are the mock's: the label's 21.8 dp under the card's top, the time's 27.6 dp under that.
        Column(Modifier.padding(start = 14.3.dp)) {
            Text(
                label, color = ink,
                fontSize = ui.t(12.5f), fontWeight = FontWeight.SemiBold, maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(end = 26.dp).paddingFromBaseline(top = 21.8.dp, bottom = 0.dp)
            )
            Text(
                time, color = ink, fontSize = ui.t(17.5f), fontWeight = FontWeight.Bold, maxLines = 1,
                style = TextStyle(fontFeatureSettings = "tnum"),
                modifier = Modifier.paddingFromBaseline(top = 27.6.dp, bottom = 0.dp)
            )
        }
        // Every card wears one, as in the mock: the speaker when the call is on, the crossed one when there is
        // none to hear (sunrise is the end of fajr, not a prayer; or the prayer's azan is switched off).
        ShellIcon(
            if (azan) ShellGlyph.SPEAKER else ShellGlyph.SPEAKER_OFF,
            when {
                azan -> if (now) ShellColors.OnNowSoft else ShellColors.Speaker
                else -> if (now) ShellColors.OnNowMuted else ShellColors.SpeakerMuted
            },
            Modifier.align(Alignment.TopEnd).padding(top = 10.6.dp, end = 11.8.dp).size(10.8.dp)
        )
    }
}

@Composable
private fun SectionCell(
    section: HomeSection,
    current: Boolean,
    enabled: Boolean,
    onOpen: (HomeSection, Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val center = remember { arrayOf(Offset.Unspecified) }
    val label = section.label()
    val art = sectionArt(section.glyph)
    val tone = ShellTones.of(section)
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) { onOpen(section, center[0]) }
            .semantics { contentDescription = label },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .padding(top = RING_ROOM)
                .size(WELL)
                .onGloballyPositioned { center[0] = it.boundsInRoot().center }
                .drawBehind {
                    // Where the user is: a thin ring of the disc's own hue, just outside it.
                    if (current) {
                        drawCircle(
                            tone.well,
                            radius = size.minDimension / 2f + 2.25.dp.toPx(),
                            style = Stroke(width = 1.5.dp.toPx()),
                            alpha = 0.55f
                        )
                    }
                }
                .clip(CircleShape)
                .background(tone.well),
            contentAlignment = Alignment.Center
        ) {
            // The glyph keeps the place it has in its circle on the designer's sheet, a shade smaller (see
            // PANEL_GLYPH_FIT), white on the saturated disc.
            if (art != null) {
                ShellIcon(
                    section.glyph, Color.White,
                    Modifier.offset(WELL * art.dx, WELL * art.dy).size(WELL * art.share * PANEL_GLYPH_FIT)
                )
            } else {
                ShellIcon(section.glyph, Color.White, Modifier.size(WELL * AIN_SHARE))
            }
        }
        Text(
            label, color = ShellColors.Ink, fontSize = ui.t(11f), fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.paddingFromBaseline(top = 14.5.dp, bottom = 11.5.dp)
        )
    }
}

/** The countdown inside a section: a small white island under the status bar. A tap leads home. */
@Composable
private fun TopIsland(data: PrayerData, now: State<ZonedDateTime>, onTap: (Offset) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val frost = rememberFrost()
    val pill = RoundedCornerShape(50)
    val center = remember { arrayOf(Offset.Unspecified) }
    val next = HomeTimeline.next(data.window, data.fajrEqualsDawn)
    Row(
        modifier
            .height(38.dp)
            .frostGlass(frost, pill)
            .onGloballyPositioned { center[0] = it.boundsInRoot().center }
            .clickable(role = Role.Button, onClickLabel = tr("На главную")) { onTap(center[0]) }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(ShellColors.Accent))
        Spacer(Modifier.width(9.dp))
        Text(PrayerLabels.title(next), color = ShellColors.Ink, fontSize = ui.t(14f), fontWeight = FontWeight.Medium, maxLines = 1)
        Spacer(Modifier.width(5.dp))
        IslandCountdown(data, now)
    }
}

/** The only part of the island that changes every second. */
@Composable
private fun IslandCountdown(data: PrayerData, now: State<ZonedDateTime>) {
    val ui = uiScale()
    Text(
        Format.countdown(data.window.remaining(now.value)),
        color = ShellColors.Ink, fontSize = ui.t(14f), fontWeight = FontWeight.Bold, maxLines = 1,
        style = TextStyle(fontFeatureSettings = "tnum")
    )
}
