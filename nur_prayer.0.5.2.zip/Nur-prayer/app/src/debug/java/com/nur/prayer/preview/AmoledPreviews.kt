package com.nur.prayer.preview

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.DockIcon
import com.nur.prayer.ui.components.DockItem
import com.nur.prayer.ui.components.NightSky
import com.nur.prayer.ui.components.NurDock
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.qibla.Heading
import com.nur.prayer.ui.qibla.HeadingSource
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.schedule.MonthCalendar
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.settings.SettingsScreen
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.paletteFor
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZonedDateTime

/** Actual production composables, not HTML lookalikes. Debug source set only; never in release APK.
 * Times and sensor samples are preview fixtures, not live device readings.
 */
private val previewMoment = ZonedDateTime.parse("2026-09-07T21:00:00+03:00[Europe/Moscow]")

private fun fixture(): PrayerData {
    val city = City.MOSCOW
    val settings = AppSettings()
    val place = Place(city.name, city.subtitle, city.country, city.coordinates, city.zone, false)
    val params = settings.paramsFor(city.country)
    val date = previewMoment.toLocalDate()
    return PrayerData(place, PrayerEngine.days(date, 3, city.coordinates, city.zone, params),
        PrayerEngine.window(previewMoment, city.coordinates, city.zone, params), qiblaBearing(city.coordinates),
        distanceToKaabaKm(city.coordinates), HijriCalendar.format(date), settings, settings.profileFor(city.country), params)
}

@Composable
private fun Scene(phase: Prayer = Prayer.ISHA, tab: String = "home", content: @Composable (PhasePalette) -> Unit) {
    NurTheme {
        val palette = paletteFor(phase)
        Box(Modifier.fillMaxSize()) {
            NightSky(palette, motionEnabled = false)
            content(palette)
            NurDock(listOf(DockItem("home", "Намаз", DockIcon.PRAYER), DockItem("calendar", "Календарь", DockIcon.CALENDAR),
                DockItem("qibla", "Кыбла", DockIcon.QIBLA), DockItem("settings", "Настройки", DockIcon.SETTINGS)),
                tab, {}, palette.accent, Modifier.align(Alignment.BottomCenter))
        }
    }
}

@Preview(name = "01 AMOLED / Home", widthDp = 393, heightDp = 851)
@Composable
fun HomeNightPreview() {
    val data = remember { fixture() }
    val clock = remember { mutableStateOf(previewMoment) }
    Scene { HomeScreen(data, clock, it, {}) }
}

@Preview(name = "02 AMOLED / Home / 320dp", widthDp = 320, heightDp = 640)
@Composable
fun HomeDawnCompactPreview() {
    val data = remember { fixture() }
    val clock = remember { mutableStateOf(previewMoment) }
    Scene(Prayer.FAJR) { HomeScreen(data, clock, it, {}) }
}

@Preview(name = "03 AMOLED / Home / enlarged type", widthDp = 393, heightDp = 851, fontScale = 1.5f)
@Composable
fun HomeSunsetPreview() {
    val data = remember { fixture() }
    val clock = remember { mutableStateOf(previewMoment) }
    Scene(Prayer.MAGHRIB) { HomeScreen(data, clock, it, {}) }
}

@Preview(name = "04 AMOLED / Calendar / six weeks", widthDp = 360, heightDp = 800)
@Composable
fun CalendarPreview() {
    Scene(tab = "calendar") { palette ->
        MonthCalendar(YearMonth.of(2026, 8), LocalDate.of(2026, 8, 7), LocalDate.of(2026, 8, 7), 0,
            palette, {}, {}, {})
    }
}

@Preview(name = "05 AMOLED / Compass", widthDp = 393, heightDp = 851)
@Composable
fun CompassPreview() {
    val data = remember { fixture() }
    Scene(tab = "qibla") { QiblaScreen(data, it, headingOverride = Heading(
        azimuth = data.qibla.toFloat() - 24f, accuracy = 3, fieldStrength = 45f, source = HeadingSource.FUSED)) }
}

@Preview(name = "06 AMOLED / Settings", widthDp = 393, heightDp = 851)
@Composable
fun SettingsPreview() {
    val data = remember { fixture() }
    val actions = remember { AppActions({}, {}, {}, {}, {}, {}, {}, {}, {}, { _, _ -> }, { _, _ -> }, {}, {}, {}, {}, {}) }
    Scene(tab = "settings") { SettingsScreen(data, it, actions, true) }
}

@Preview(name = "07 AMOLED / City search", widthDp = 393, heightDp = 851)
@Composable
fun CityPreview() {
    NurTheme {
        val palette = paletteFor(Prayer.DHUHR)
        Box(Modifier.fillMaxSize()) {
            NightSky(palette, motionEnabled = false)
            CityPickerScreen(palette, City.MOSCOW.id, search = { listOf(City.MOSCOW) },
                onPick = {}, onBack = {}, onUseLocation = {}, locating = false)
        }
    }
}

@Preview(name = "08 AMOLED / Compass / unavailable", widthDp = 320, heightDp = 640)
@Composable
fun CompassUnavailablePreview() {
    val data = remember { fixture() }
    Scene(tab = "qibla") { QiblaScreen(data, it, headingOverride = Heading()) }
}

@Preview(name = "09 AMOLED / Home / landscape", widthDp = 800, heightDp = 360)
@Composable
fun HomeLandscapePreview() {
    val data = remember { fixture() }
    val clock = remember { mutableStateOf(previewMoment) }
    Scene { HomeScreen(data, clock, it, {}) }
}
