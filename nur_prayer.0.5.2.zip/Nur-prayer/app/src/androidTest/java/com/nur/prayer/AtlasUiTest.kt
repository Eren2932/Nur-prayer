package com.nur.prayer

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsOff
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performImeAction
import androidx.compose.ui.test.performTextInput
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.City
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.SegmentedControl
import com.nur.prayer.ui.components.SwitchRow
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AtlasUiTest {
    @get:Rule val compose = createComposeRule()

    @Test fun citySearchAndSelection() {
        val cities = listOf(City.MOSCOW, City(2, "Ташкент", "Ташкент", "Узбекистан", 41.31, 69.28, "Asia/Tashkent"))
        var picked = -1
        compose.setContent {
            NurTheme {
                CityPickerScreen(paletteFor(Prayer.ISHA), 1,
                    search = { query -> cities.filter { query.isEmpty() || it.name.lowercase().contains(query) } },
                    onPick = { picked = it.id }, onBack = {}, onUseLocation = {}, locating = false)
            }
        }
        compose.onNodeWithContentDescription("Поиск города").performTextInput("таш")
        compose.onNodeWithContentDescription("Поиск города").performImeAction()
        compose.waitUntil(5000) { compose.onAllNodesWithText("Москва").fetchSemanticsNodes().isEmpty() &&
            compose.onAllNodesWithText("Ташкент").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Ташкент").assertIsDisplayed().performClick()
        compose.runOnIdle { assertEquals(2, picked) }
    }

    @Test fun switchExposesCheckedStateToAccessibility() {
        compose.setContent {
            NurTheme {
                var checked by remember { mutableStateOf(false) }
                SwitchRow("Фаджр", checked, Mint, { checked = it })
            }
        }
        compose.onNodeWithText("Фаджр").assertIsOff().performClick().assertIsOn()
    }
    @Test fun oneSearchResultDoesNotBecomeATallEmptyPanel() {
        val zainsk = City(999, "Заинск", "Татарстан", "Россия", 55.3, 52.0, "Europe/Moscow")
        compose.setContent {
            NurTheme {
                CityPickerScreen(paletteFor(Prayer.ISHA), 999,
                    search = { query -> if (query.isEmpty() || zainsk.name.lowercase().contains(query)) listOf(zainsk) else emptyList() },
                    onPick = {}, onBack = {}, onUseLocation = {}, locating = false)
            }
        }
        val searchField = compose.onNodeWithContentDescription("Поиск города")
        searchField.performTextInput("заинс")
        searchField.performImeAction()
        compose.waitUntil(5000) { compose.onAllNodesWithText("НАЙДЕНО · 1").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("city-row-999").assertIsDisplayed()
        val row = compose.onNodeWithTag("city-row-999").fetchSemanticsNode().boundsInRoot
        val viewport = compose.onNodeWithTag("city-scroll").fetchSemanticsNode().boundsInRoot
        assertTrue("A single city card must not fill the remaining viewport", row.height < viewport.height / 2f)
    }

    @Test fun emptySearchShowsACompactHintAndCanBeCleared() {
        compose.setContent {
            NurTheme {
                CityPickerScreen(paletteFor(Prayer.ISHA), 1,
                    search = { query -> if (query.isEmpty()) listOf(City.MOSCOW) else emptyList() },
                    onPick = {}, onBack = {}, onUseLocation = {}, locating = false)
            }
        }
        val searchField = compose.onNodeWithContentDescription("Поиск города")
        searchField.performTextInput("несуществующийгород")
        searchField.performImeAction()
        compose.waitUntil(5000) { compose.onAllNodesWithText("НАЙДЕНО · 0").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("city-empty").assertIsDisplayed()
        compose.onNodeWithContentDescription("Очистить поиск").performClick()
        compose.waitUntil(5000) { compose.onAllNodesWithText("Москва").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Москва").assertIsDisplayed()
    }

    @Test fun locationButtonUsesTheCurrentRecoveryAction() {
        var requested = 0
        compose.setContent {
            NurTheme {
                CityPickerScreen(paletteFor(Prayer.ISHA), 1, search = { emptyList() },
                    onPick = {}, onBack = {}, onUseLocation = { requested++ }, locating = false,
                    locationButtonLabel = "Включить геолокацию")
            }
        }
        compose.onNodeWithText("Включить геолокацию").assertIsDisplayed().performClick()
        compose.runOnIdle { assertEquals(1, requested) }
    }

    @Test fun disabledButtonExposesDisabledState() {
        var clicks = 0
        compose.setContent {
            NurTheme { NurButton("Определяем координаты…", Mint, { clicks++ }, enabled = false) }
        }
        compose.onNodeWithText("Определяем координаты…").assertIsNotEnabled()
        compose.runOnIdle { assertEquals(0, clicks) }
    }

    @Test fun primaryButtonDispatchesExactlyOneAction() {
        var clicks = 0
        compose.setContent {
            NurTheme { NurButton("Выбрать город", Mint, { clicks++ }, primary = true) }
        }
        compose.onNodeWithText("Выбрать город").assertIsDisplayed().performClick()
        compose.runOnIdle { assertEquals(1, clicks) }
    }

    @Test fun segmentedControlExposesSelectionAndIgnoresSelectedTap() {
        var changes = 0
        compose.setContent {
            NurTheme {
                var index by remember { mutableStateOf(0) }
                SegmentedControl(listOf("Ханафитский", "Шафиитский"), index, Mint, {
                    index = it
                    changes++
                })
            }
        }
        compose.onNodeWithText("Ханафитский").assertIsSelected().performClick()
        compose.runOnIdle { assertEquals(0, changes) }
        compose.onNodeWithText("Шафиитский").performClick().assertIsSelected()
        compose.runOnIdle { assertEquals(1, changes) }
    }

}
