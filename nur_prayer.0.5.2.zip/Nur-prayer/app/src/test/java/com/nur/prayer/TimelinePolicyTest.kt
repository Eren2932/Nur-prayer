package com.nur.prayer

import com.nur.prayer.ui.TimelinePolicy
import java.time.ZonedDateTime
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TimelinePolicyTest {
    private val start = ZonedDateTime.parse("2026-09-07T21:00:00+03:00")
    private val end = ZonedDateTime.parse("2026-09-08T04:00:00+03:00")
    @Test fun midnightRefreshesDateBeforeNextPrayer() {
        assertTrue(TimelinePolicy.needsRefresh(start.plusHours(3), start.toLocalDate(), start, end))
    }
    @Test fun normalTickDoesNotRecalculate() {
        assertFalse(TimelinePolicy.needsRefresh(start.plusSeconds(1), start.toLocalDate(), start, end))
    }
    @Test fun exactBoundaryRefreshes() {
        assertTrue(TimelinePolicy.needsRefresh(end, end.toLocalDate(), start, end))
    }
    @Test fun clockMovedBackwardRefreshesWindow() {
        assertTrue(TimelinePolicy.needsRefresh(start.minusSeconds(1), start.toLocalDate(), start, end))
    }
    @Test fun usesSelectedTimezoneRatherThanPhoneDate() {
        val now = start.plusHours(1).withZoneSameInstant(java.time.ZoneId.of("Asia/Tokyo"))
        assertFalse(TimelinePolicy.needsRefresh(now, start.toLocalDate(), start, end))
    }
}
