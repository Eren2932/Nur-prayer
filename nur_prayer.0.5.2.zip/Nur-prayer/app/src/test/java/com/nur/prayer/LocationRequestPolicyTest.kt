package com.nur.prayer

import com.nur.prayer.location.LocationRequestPolicy
import com.nur.prayer.location.LocationRequestStep
import org.junit.Assert.assertEquals
import org.junit.Test

class LocationRequestPolicyTest {
    @Test fun firstRequestAsksForPermissionEvenIfGpsIsOff() {
        assertEquals(LocationRequestStep.REQUEST_PERMISSION, LocationRequestPolicy.next(false, false, false, false))
    }
    @Test fun ordinaryDenialMayBeRequestedAgain() {
        assertEquals(LocationRequestStep.REQUEST_PERMISSION, LocationRequestPolicy.next(false, true, true, true))
    }
    @Test fun permanentDenialOpensAppSettingsInsteadOfAnInvisiblePermissionDialog() {
        assertEquals(LocationRequestStep.OPEN_APP_SETTINGS, LocationRequestPolicy.next(false, true, false, true))
    }
    @Test fun grantedPermissionWithGpsOffOpensLocationSettings() {
        assertEquals(LocationRequestStep.OPEN_LOCATION_SETTINGS, LocationRequestPolicy.next(true, true, false, false))
    }
    @Test fun returnFromSettingsContinuesTheSameRequest() {
        assertEquals(LocationRequestStep.LOCATE, LocationRequestPolicy.next(true, true, false, true))
    }
    @Test fun usableCoarsePermissionDoesNotForceAnotherDialog() {
        assertEquals(LocationRequestStep.LOCATE, LocationRequestPolicy.next(true, false, false, true))
    }
}
