package com.nur.prayer

import com.nur.prayer.ui.qibla.QiblaGuidance
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QiblaGuidanceTest {
    @Test fun alignmentNeedsEverySafetyCondition() {
        assertTrue(QiblaGuidance.aligned(2.5f, true, true, true))
        assertTrue(QiblaGuidance.aligned(-2.5f, true, true, true))
        assertFalse(QiblaGuidance.aligned(2.51f, true, true, true))
        assertFalse(QiblaGuidance.aligned(0f, false, true, true))
        assertFalse(QiblaGuidance.aligned(0f, true, false, true))
        assertFalse(QiblaGuidance.aligned(0f, true, true, false))
        assertFalse(QiblaGuidance.aligned(Float.NaN, true, true, true))
    }
    @Test fun unreliableReadingNeverGivesTurnInstructions() {
        assertEquals("Компас недоступен", QiblaGuidance.instruction(30f, false, false, true))
        assertEquals("Проверьте калибровку и помехи", QiblaGuidance.instruction(30f, true, false, true))
        assertEquals("Положите телефон горизонтально", QiblaGuidance.instruction(30f, true, true, false))
        assertEquals("Проверьте калибровку и помехи", QiblaGuidance.instruction(Float.NaN, true, true, true))
    }
    @Test fun directionAndAlignmentAreExplicit() {
        assertEquals("Поверните вправо на 30°", QiblaGuidance.instruction(30f, true, true, true))
        assertEquals("Поверните влево на 30°", QiblaGuidance.instruction(-30f, true, true, true))
        assertEquals("Направление на Каабу", QiblaGuidance.instruction(0f, true, true, true))
    }
    @Test fun roundedNorthIsZeroNot360() {
        assertEquals("0°", QiblaGuidance.degrees(359.8f))
        assertEquals("0°", QiblaGuidance.degrees(-0.2f))
        assertEquals("90°", QiblaGuidance.degrees(450f))
        assertEquals("—", QiblaGuidance.degrees(Float.POSITIVE_INFINITY))
    }
}
