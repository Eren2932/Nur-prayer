package com.nur.prayer

import androidx.compose.ui.graphics.Color
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.ui.theme.Gold
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.InkSoft
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.paletteFor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AmoledPaletteTest {
    @Test fun everyPrayerKeepsTheSameBlackBackground() {
        assertEquals(Color.Black, Ink)
        Prayer.entries.forEach {
            val palette = paletteFor(it)
            assertEquals(Color.Black, palette.zenith)
            assertEquals(Color.Black, palette.mid)
            assertEquals(Color.Black, palette.horizon)
            assertEquals(0f, palette.starIntensity, 0f)
            assertEquals(0f, palette.auroraIntensity, 0f)
            assertEquals(Gold, palette.accent)
        }
    }
    @Test fun smallTextHasAAContrastOnEveryStandardSurface() {
        listOf(TextPrimary, TextSecondary, TextTertiary).forEach { text ->
            listOf(Ink, InkSoft, SurfaceRaised).forEach { background ->
                assertTrue("Insufficient text contrast", contrast(text, background) >= 4.5)
            }
        }
        assertTrue(contrast(Ink, Gold) >= 7.0)
    }
    private fun contrast(a: Color, b: Color): Double {
        fun luminance(c: Color): Double {
            fun linear(value: Float): Double = if (value <= 0.04045f) value / 12.92 else ((value + 0.055) / 1.055).pow(2.4)
            return 0.2126 * linear(c.red) + 0.7152 * linear(c.green) + 0.0722 * linear(c.blue)
        }
        val x = luminance(a)
        val y = luminance(b)
        return (max(x, y) + 0.05) / (min(x, y) + 0.05)
    }
}
