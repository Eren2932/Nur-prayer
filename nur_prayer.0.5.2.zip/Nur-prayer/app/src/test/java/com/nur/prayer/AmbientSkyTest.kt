package com.nur.prayer

import com.nur.prayer.ui.components.AmbientSky
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The backdrop is decoration, so the only things worth asserting are the promises it makes to the
 * rest of the design: it stays dim, it stays sparse, and it never leaves the viewport.
 */
class AmbientSkyTest {
    private val stars = AmbientSky.stars()

    @Test fun fieldStaysSparse() {
        assertEquals(AmbientSky.STAR_COUNT, stars.size)
        assertTrue("Too many bright stars", stars.count { it.accented } <= AmbientSky.STAR_COUNT / 8)
    }

    @Test fun noStarEverOutshinesTheForeground() {
        var t = 0f
        while (t < 120f) {
            stars.forEach { star ->
                val alpha = AmbientSky.alpha(star, t)
                assertTrue("Alpha $alpha above the ceiling", alpha <= AmbientSky.MAX_ALPHA)
                assertTrue("Negative alpha $alpha", alpha >= 0f)
            }
            t += 0.37f
        }
    }

    @Test fun driftWrapsInsideTheViewportForever() {
        listOf(0f, 1f, 60f, 3_600f, 86_400f).forEach { t ->
            stars.forEach { star ->
                val x = AmbientSky.driftX(star, t)
                assertTrue("Star left the viewport at t=$t: $x", x >= 0f && x < 1f)
            }
        }
    }

    @Test fun fieldIsDeterministicAcrossLaunches() {
        val again = AmbientSky.stars()
        stars.indices.forEach { i ->
            assertEquals(stars[i].x, again[i].x, 0f)
            assertEquals(stars[i].y, again[i].y, 0f)
            assertEquals(stars[i].brightness, again[i].brightness, 0f)
        }
    }

    @Test fun meteorIsRareAndBrief() {
        assertTrue(AmbientSky.METEOR_PERIOD >= 30f)
        assertTrue(AmbientSky.METEOR_LIFE <= 1.5f)
        // Visible for well under five percent of the time it is not.
        assertTrue(AmbientSky.METEOR_LIFE / AmbientSky.METEOR_PERIOD < 0.05f)
    }

    @Test fun cadenceStaysBelowDisplayRate() {
        assertTrue("Backdrop must not run at display rate", AmbientSky.FRAME_INTERVAL_MILLIS >= 50L)
    }
}
