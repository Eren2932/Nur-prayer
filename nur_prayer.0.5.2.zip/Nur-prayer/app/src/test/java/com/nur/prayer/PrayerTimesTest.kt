package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.PrayerParams
import com.nur.prayer.core.astro.TimeSource
import com.nur.prayer.core.astro.qiblaBearing
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PrayerTimesTest {

    private val params = PrayerParams(
        method = CalculationMethod.RUSSIA_DUM,
        madhab = Madhab.HANAFI
    )

    private fun assertMarkerOrder(label: String, day: PrayerDay) {
        assertEquals("$label: all seven markers must be present", Prayer.entries.toSet(), day.times.keys)
        for ((previous, current) in Prayer.entries.zipWithNext()) {
            val before = day.at(previous)
            val after = day.at(current)
            // Only Sahar and Fajr may coincide: the congregation cannot pray before dawn.
            // All later markers must remain strictly ordered, not merely non-decreasing.
            if (previous == Prayer.SAHAR && current == Prayer.FAJR) {
                assertTrue("$label: Fajr must not precede Sahar", !after.isBefore(before))
            } else {
                assertTrue("$label: $current must be after $previous", after.isAfter(before))
            }
        }
    }

    @Test
    fun `order is always monotonic across a year in hard cities`() {
        val cities = listOf(
            Triple("Москва", Coordinates(55.7558, 37.6173), "Europe/Moscow"),
            Triple("Санкт-Петербург", Coordinates(59.9311, 30.3609), "Europe/Moscow"),
            Triple("Мурманск", Coordinates(68.9585, 33.0827), "Europe/Moscow"),
            Triple("Махачкала", Coordinates(42.9764, 47.5024), "Europe/Moscow"),
            Triple("Владивосток", Coordinates(43.1155, 131.8855), "Asia/Vladivostok")
        )
        for ((name, coordinates, zoneId) in cities) {
            val zone = ZoneId.of(zoneId)
            var date = LocalDate.of(2026, 1, 1)
            while (date.year == 2026) {
                val day = PrayerEngine.day(date, coordinates, zone, params)
                assertMarkerOrder("$name $date", day)
                date = date.plusDays(1)
            }
        }
    }

    @Test
    fun `dhuhr in Moscow is close to solar noon`() {
        val zone = ZoneId.of("Europe/Moscow")
        val day = PrayerEngine.day(
            LocalDate.of(2026, 3, 21), Coordinates(55.7558, 37.6173), zone, params
        )
        val dhuhr = day.at(Prayer.DHUHR)
        // Solar noon in Moscow around the equinox is 12:39 local time (UTC+3, 37.6E).
        assertEquals(12, dhuhr.hour)
        assertTrue(abs(dhuhr.minute - 39) <= 3)
    }

    @Test
    fun `qibla bearings match published values`() {
        assertEquals(180.0, qiblaBearing(Coordinates(25.4225, 39.8262)), 1.0) // due north of Makkah
        assertEquals(176.0, qiblaBearing(Coordinates(55.7558, 37.6173)), 3.0) // Moscow, ~176 deg
        assertEquals(58.5, qiblaBearing(Coordinates(40.7128, -74.0060)), 2.0) // New York
    }

    @Test
    fun `polar summer still returns a full day`() {
        val zone = ZoneId.of("Europe/Moscow")
        val day = PrayerEngine.day(
            LocalDate.of(2026, 6, 21), Coordinates(68.9585, 33.0827), zone, params
        )
        assertEquals(7, day.times.size)
        assertEquals(5, day.times.keys.count { it.isPrayer })
        assertTrue(!day.note.isNullOrBlank())
        assertEquals(day.date, day.at(Prayer.DHUHR).toLocalDate())
        assertMarkerOrder("Murmansk polar summer", day)
    }

    @Test
    fun `murmansk fajr is bounded by dawn when the congregational gap is too early`() {
        val day = PrayerEngine.day(
            LocalDate.of(2026, 5, 14), Coordinates(68.9585, 33.0827),
            ZoneId.of("Europe/Moscow"), params
        )
        assertEquals(TimeSource.DAWN_BOUND, day.fajrSource)
        assertEquals(day.at(Prayer.SAHAR), day.at(Prayer.FAJR))
        assertMarkerOrder("Murmansk 2026-05-14", day)
    }

    @Test
    fun `zero congregational gap keeps fajr at dawn without inventing an extra minute`() {
        val day = PrayerEngine.day(
            LocalDate.of(2026, 3, 21), Coordinates(55.7558, 37.6173),
            ZoneId.of("Europe/Moscow"), params.copy(congregationalFajrMinutes = 0)
        )
        assertEquals(day.at(Prayer.SAHAR), day.at(Prayer.FAJR))
        assertMarkerOrder("Moscow with no congregational gap", day)
    }

    @Test
    fun `polar winter also returns all seven markers and five prayers`() {
        val day = PrayerEngine.day(
            LocalDate.of(2026, 12, 21), Coordinates(68.9585, 33.0827),
            ZoneId.of("Europe/Moscow"), params
        )
        assertEquals(7, day.times.size)
        assertEquals(5, day.times.keys.count { it.isPrayer })
        assertTrue(!day.note.isNullOrBlank())
        assertEquals(day.date, day.at(Prayer.DHUHR).toLocalDate())
        assertMarkerOrder("Murmansk polar winter", day)
    }
}
