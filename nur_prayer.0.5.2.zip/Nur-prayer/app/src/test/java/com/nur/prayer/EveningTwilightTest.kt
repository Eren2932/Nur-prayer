package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.CalendarConvention
import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerParams
import com.nur.prayer.core.astro.PrayerTimes
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.core.astro.TimeSource
import java.time.LocalDate
import java.time.ZoneId
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The evening twin of the 0.2.4 dawn fix.
 *
 * At the edge of the white-night season the Sun's altitude curve is almost flat at its lowest point.
 * A night that misses the Isha angle by four hundredths of a degree used to satisfy the old
 * "residual under 0.05" test, so Newton parked on the flat minimum and the engine published an
 * astronomical Isha that never happened - roughly an hour away from the honest answer.
 *
 * Volgograd, 14 June 2026: the Sun bottoms out at -17.9989 degrees, so an 18-degree Isha does not
 * exist and the interval must be used. The fixture therefore uses KARACHI (Isha 18 degrees),
 * not MUSLIM_WORLD_LEAGUE (Isha 17 degrees). MWL has a real crossing on that same night.
 * Ust-Kamenogorsk, 10 June 2026, is a separate 17-degree boundary (minimum -16.9677).
 */
class EveningTwilightTest {

    private fun params(method: CalculationMethod) = PrayerParams(
        method = method,
        madhab = Madhab.HANAFI,
        highLatitudeRule = HighLatitudeRule.SEVENTH_OF_THE_NIGHT,
        rounding = RoundingMode.NEAREST,
        convention = CalendarConvention.ASTRONOMICAL
    )

    private fun times(
        lat: Double, lon: Double, zone: String, date: LocalDate,
        method: CalculationMethod = CalculationMethod.KARACHI
    ) = PrayerTimes(
        date = date,
        coordinates = Coordinates(lat, lon),
        params = params(method),
        zone = ZoneId.of(zone)
    )

    @Test
    fun `volgograd mid june has no astronomical isha`() {
        val result = times(48.7071, 44.5169, "Europe/Volgograd", LocalDate.of(2026, 6, 14))
        assertEquals("This regression requires Isha at 18 degrees", 18.0, result.params.method.ishaAngle, 0.0)
        assertEquals(
            "Угол -18 недостижим: нужна именно доля ночи, а не астрономическая иша",
            TimeSource.NIGHT_FRACTION,
            result.ishaSource
        )
        assertTrue(result.times.getValue(Prayer.ISHA)!!.isAfter(result.times.getValue(Prayer.MAGHRIB)!!))
    }

    @Test
    fun `ust kamenogorsk mid june has no astronomical isha`() {
        val result = times(
            49.9787, 82.6014, "Asia/Almaty", LocalDate.of(2026, 6, 10),
            CalculationMethod.MUSLIM_WORLD_LEAGUE
        )
        assertEquals(17.0, result.params.method.ishaAngle, 0.0)
        assertEquals(TimeSource.NIGHT_FRACTION, result.ishaSource)
    }

    @Test
    fun `volgograd on the same night still has a real seventeen degree MWL isha`() {
        val result = times(
            48.7071, 44.5169, "Europe/Volgograd", LocalDate.of(2026, 6, 14),
            CalculationMethod.MUSLIM_WORLD_LEAGUE
        )
        assertEquals(17.0, result.params.method.ishaAngle, 0.0)
        assertEquals(TimeSource.ANGLE, result.ishaSource)
        assertTrue(result.times.getValue(Prayer.ISHA)!!.isAfter(result.times.getValue(Prayer.MAGHRIB)!!))
    }

    @Test
    fun `an ordinary night still resolves from the angle`() {
        // Same city, nine weeks later: the night is deep again and the angle must win.
        val result = times(48.7071, 44.5169, "Europe/Volgograd", LocalDate.of(2026, 8, 20))
        assertEquals(TimeSource.ANGLE, result.ishaSource)
    }
}
