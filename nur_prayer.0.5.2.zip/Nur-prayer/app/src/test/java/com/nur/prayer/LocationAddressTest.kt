package com.nur.prayer

import com.nur.prayer.location.LocationAddress
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LocationAddressTest {
    @Test fun addressAndIndexStaySeparateFromCoordinates() {
        val address = LocationAddress.fromParts("Казань", "Центр", "улица Примерная", "10", "420000")
        assertEquals("Казань", address.locality)
        assertEquals("Центр, улица Примерная 10", address.detail)
        assertEquals("420000", address.postalCode)
    }
    @Test fun unavailableAddressDoesNotInventANameOrIndex() {
        val address = LocationAddress.fromParts(null, null, null, null, null)
        assertNull(address.locality)
        assertNull(address.detail)
        assertNull(address.postalCode)
    }
    @Test fun blankFieldsAndDuplicateAddressPartsAreCleaned() {
        val address = LocationAddress.fromParts("  Казань  ", "район", "район", "  ", " 420000 ")
        assertEquals("Казань", address.locality)
        assertEquals("район", address.detail)
        assertEquals("420000", address.postalCode)
    }
    @Test fun internationalPostalCodesAreNotRestrictedToRussianDigits() {
        assertEquals("SW1A 1AA", LocationAddress.fromParts("London", null, null, null, "SW1A  1AA").postalCode)
    }
}
