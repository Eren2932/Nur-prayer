package com.nur.prayer

import com.nur.prayer.location.LocationFixPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LocationFixPolicyTest {
    @Test fun manualButtonNeverShortCircuitsOnCache() {
        assertFalse(LocationFixPolicy.mayUseCacheImmediately(true, 5f, 0L))
        assertFalse(LocationFixPolicy.mayUseCacheImmediately(true, 5f, 30_000L))
    }
    @Test fun onlyAFreshPreciseCacheMayServeAnAutomaticRefresh() {
        assertTrue(LocationFixPolicy.mayUseCacheImmediately(false, 20f, 30_000L))
        assertFalse(LocationFixPolicy.mayUseCacheImmediately(false, 20f, 30_001L))
        assertFalse(LocationFixPolicy.mayUseCacheImmediately(false, 500f, 10L))
    }
    @Test fun fiveMinuteOldMoscowFixCannotBeAccepted() {
        assertFalse(LocationFixPolicy.usable(55.7558, 37.6173, 5f, 300_000L))
        assertTrue(LocationFixPolicy.usable(55.7963, 49.1088, 12f, 1_000L))
    }
    @Test fun coarsePermissionStillGetsAUsableCityLevelFix() {
        assertTrue(LocationFixPolicy.usable(55.7963, 49.1088, 3_000f, 1_000L))
        assertTrue(LocationFixPolicy.usable(55.7963, 49.1088, 20_000f, 1_000L))
        assertFalse(LocationFixPolicy.usable(55.7963, 49.1088, 20_001f, 1_000L))
    }
    @Test fun invalidCoordinatesOrAccuracyAreRejected() {
        assertFalse(LocationFixPolicy.usable(Double.NaN, 49.0, 10f, 0L))
        assertFalse(LocationFixPolicy.usable(91.0, 49.0, 10f, 0L))
        assertFalse(LocationFixPolicy.usable(55.0, 181.0, 10f, 0L))
        assertFalse(LocationFixPolicy.usable(55.0, 49.0, Float.NaN, 0L))
        assertFalse(LocationFixPolicy.usable(55.0, 49.0, 0f, 0L))
        assertFalse(LocationFixPolicy.usable(55.0, 49.0, 10f, -1L))
    }
    @Test fun actualZeroLatitudeAndLongitudeAreNotAutomaticallyGarbage() {
        assertTrue(LocationFixPolicy.usable(0.0, 0.0, 10f, 1_000L))
    }
    @Test fun monotonicClockSurvivesWallClockChanges() {
        assertEquals(2_000L, LocationFixPolicy.ageMillis(12_000_000_000L, 10_000_000_000L, 1L, 500_000L))
    }
    @Test fun oldDevicesCanFallBackToWallClockButNotFutureTimestamps() {
        assertEquals(2_000L, LocationFixPolicy.ageMillis(0L, 0L, 10_000L, 8_000L))
        assertEquals(Long.MAX_VALUE, LocationFixPolicy.ageMillis(0L, 0L, 10_000L, 11_000L))
        assertEquals(Long.MAX_VALUE, LocationFixPolicy.ageMillis(0L, 0L, 10_000L, 0L))
    }
    @Test fun staleCallbackCannotPretendToBeLive() {
        val start = 100_000_000_000L
        assertFalse(LocationFixPolicy.isLiveCallback(80_000_000_000L, start, 20_000L))
        assertFalse(LocationFixPolicy.isLiveCallback(0L, start, 0L))
        assertTrue(LocationFixPolicy.isLiveCallback(101_000_000_000L, start, 100L))
    }
    @Test fun accuracyAndAgeBothContributeToRanking() {
        assertTrue(LocationFixPolicy.score(15f, 1_000L) < LocationFixPolicy.score(1_500f, 0L))
        assertTrue(LocationFixPolicy.score(20f, 0L) < LocationFixPolicy.score(20f, 30_000L))
    }
    @Test fun streetAndPostalMetadataRequirePrecisePermissionAndAGoodRadius() {
        assertTrue(LocationFixPolicy.mayDescribeStreet(true, 40f))
        assertTrue(LocationFixPolicy.mayDescribeStreet(true, 100f))
        assertFalse(LocationFixPolicy.mayDescribeStreet(true, 101f))
        assertFalse(LocationFixPolicy.mayDescribeStreet(true, 3_000f))
    }
    @Test fun approximateAccessNeverPretendsToKnowTheUsersStreet() {
        assertFalse(LocationFixPolicy.mayDescribeStreet(false, 5f))
        assertFalse(LocationFixPolicy.mayDescribeStreet(true, Float.NaN))
        assertFalse(LocationFixPolicy.mayDescribeStreet(true, 0f))
    }

}
