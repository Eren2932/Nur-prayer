package com.nur.prayer.ui.qibla

import kotlin.math.abs
import kotlin.math.roundToInt

/** Pure presentation policy: never give a turn instruction from an untrusted sensor reading. */
object QiblaGuidance {
    const val ALIGN_TOLERANCE = 2.5f

    fun aligned(delta: Float, available: Boolean, trustworthy: Boolean, flat: Boolean): Boolean =
        delta.isFinite() && available && trustworthy && flat && abs(delta) <= ALIGN_TOLERANCE

    fun instruction(delta: Float, available: Boolean, trustworthy: Boolean, flat: Boolean): String = when {
        !available -> "Компас недоступен"
        !delta.isFinite() || !trustworthy -> "Проверьте калибровку и помехи"
        !flat -> "Положите телефон горизонтально"
        abs(delta) <= ALIGN_TOLERANCE -> "Направление на Каабу"
        delta > 0f -> "Поверните вправо на ${abs(delta).roundToInt()}°"
        else -> "Поверните влево на ${abs(delta).roundToInt()}°"
    }

    fun degrees(value: Float): String = if (value.isFinite()) "${normalize(value).roundToInt() % 360}°" else "—"
}
