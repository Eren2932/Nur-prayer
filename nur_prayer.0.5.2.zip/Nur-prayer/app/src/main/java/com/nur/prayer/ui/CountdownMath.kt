package com.nur.prayer.ui

import java.time.Duration

/** Pure presentation math, independent from prayer calculation and Android. */
object CountdownMath {
    fun secondsRemaining(duration: Duration): Long = when {
        duration.isNegative || duration.isZero -> 0L
        duration.nano > 0 && duration.seconds < Long.MAX_VALUE -> duration.seconds + 1L
        else -> duration.seconds
    }
    fun progress(startMillis: Long, endMillis: Long, nowMillis: Long): Float {
        if (endMillis <= startMillis) return 0f
        return ((nowMillis.toDouble() - startMillis.toDouble()) /
            (endMillis.toDouble() - startMillis.toDouble())).coerceIn(0.0, 1.0).toFloat()
    }
}
