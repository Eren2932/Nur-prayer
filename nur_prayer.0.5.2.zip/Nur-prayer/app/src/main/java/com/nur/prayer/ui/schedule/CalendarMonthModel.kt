package com.nur.prayer.ui.schedule

import java.time.LocalDate
import java.time.YearMonth

/** Monday-first full weeks. Dates, not numeric indices, remain stable across month boundaries. */
object CalendarMonthModel {
    fun cells(month: YearMonth): List<LocalDate> {
        val first = month.atDay(1)
        val leading = first.dayOfWeek.value - 1
        val start = first.minusDays(leading.toLong())
        val count = ((leading + month.lengthOfMonth() + 6) / 7) * 7
        return List(count) { start.plusDays(it.toLong()) }
    }

    fun moveSelection(selected: LocalDate, target: YearMonth): LocalDate =
        target.atDay(selected.dayOfMonth.coerceAtMost(target.lengthOfMonth()))
}
