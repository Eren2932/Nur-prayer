package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableFloatState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette
import kotlinx.coroutines.delay

/**
 * The backdrop, given back a pulse in 0.5.1 — without giving up the AMOLED contract.
 *
 * 0.3.0 had eight layers here: a four-stop sky gradient, a horizon airglow, aurora curtains, a
 * girih lattice, film grain, two scrims and a vignette. On an OLED panel every one of those is a
 * mistake, and not only for taste: a gradient that starts at #000 and ends anywhere else means the
 * screen can no longer switch its pixels off, so the black the design is built on becomes a very
 * dark grey with visible banding, and the panel draws power across the whole surface. 0.5.0 fixed
 * that by deleting the file down to a black rectangle, which is why the app now feels switched off.
 *
 * So this is neither of the two. The substrate stays exactly [Ink] — a true, unlit black, no
 * gradient, no vignette, no grain — and the only thing added back is a sparse star field: 54 points
 * at a maximum alpha of 0.34, plus one meteor roughly every 40 seconds. Lit pixels are a fraction
 * of a percent of the surface, so the AMOLED saving survives, and nothing is drawn brightly enough
 * to compete with the text or the dial in front of it.
 *
 * Cost control, in order of importance:
 *  - the field animates only when [motionEnabled] is true, i.e. the user has not switched it off;
 *  - [rememberAmbientMotionAllowed] additionally suspends it when the app is not resumed, in
 *    battery saver, or when the OS animation scale is 0 (the accessibility "remove animations"
 *    setting);
 *  - [LocalBackdropPaused] freezes it while a screen is being scrolled, so the list never competes
 *    with the backdrop for frame time;
 *  - the clock is stepped at most 20 times a second, not at display rate, and it keeps its phase
 *    across a pause instead of snapping back to zero;
 *  - the star array is built once and walked by index — no allocation, no iterator, per frame.
 *
 * When motion is not allowed the stars are still drawn, at rest. A still sky is the honest
 * degradation of a moving one; a black rectangle is a different design.
 */
@Composable
fun NightSky(
    palette: PhasePalette,
    modifier: Modifier = Modifier,
    motionEnabled: Boolean = false
) {
    // Gated on the switch, so a disabled backdrop registers no broadcast receiver and no settings
    // observer at all — and Compose previews, which have no real system services, stay renderable.
    val systemAllows = if (motionEnabled) rememberAmbientMotionAllowed() else false
    val paused = LocalBackdropPaused.current.value
    val animating = systemAllows && !paused
    val clock = remember { mutableFloatStateOf(0f) }
    val stars = remember { AmbientSky.stars() }

    LaunchedEffect(animating) {
        if (!animating) return@LaunchedEffect
        var previous = 0L
        while (true) {
            withFrameNanos { now ->
                // Clamped so a long pause cannot teleport the field on the first frame back.
                if (previous != 0L) clock.floatValue += ((now - previous) / 1_000_000_000f).coerceAtMost(0.15f)
                previous = now
            }
            delay(AmbientSky.FRAME_INTERVAL_MILLIS)
        }
    }

    Box(modifier.fillMaxSize().background(Ink)) {
        if (motionEnabled) {
            StarField(clock, stars, palette.accentSoft)
        }
    }
}

@Composable
private fun StarField(clock: MutableFloatState, stars: Array<AmbientSky.Star>, tint: Color) {
    Canvas(Modifier.fillMaxSize()) {
        val t = clock.floatValue
        val w = size.width
        val h = size.height
        if (w < 1f || h < 1f) return@Canvas

        for (i in stars.indices) {
            val star = stars[i]
            val x = AmbientSky.driftX(star, t) * w
            val y = star.y * h
            val alpha = AmbientSky.alpha(star, t)
            if (alpha <= AmbientSky.MIN_VISIBLE_ALPHA) continue
            // The few brightest points take the palette's soft accent; the rest stay neutral, so
            // the field reads as depth rather than as decoration with an opinion.
            val color = if (star.accented) tint else Color.White
            drawCircle(color.copy(alpha = alpha), star.radius * density, Offset(x, y))
        }

        drawMeteor(t)
    }
}

/** One meteor per [AmbientSky.METEOR_PERIOD] seconds, deterministic: no particle bookkeeping. */
private fun DrawScope.drawMeteor(t: Float) {
    val index = (t / AmbientSky.METEOR_PERIOD).toInt()
    val local = t - index * AmbientSky.METEOR_PERIOD
    if (local > AmbientSky.METEOR_LIFE) return

    val w = size.width
    val h = size.height
    val rnd = AmbientSky.hash(index)
    val startX = (0.12f + 0.7f * rnd) * w
    val startY = (0.04f + 0.26f * AmbientSky.hash(index * 31 + 7)) * h
    val angle = 0.62f + 0.22f * AmbientSky.hash(index * 17 + 3)
    val travel = w * 0.38f
    val p = local / AmbientSky.METEOR_LIFE
    val eased = p * p * (3f - 2f * p)
    val hx = startX + kotlin.math.cos(angle) * travel * eased
    val hy = startY + kotlin.math.sin(angle) * travel * eased
    val tail = travel * 0.20f
    val tx = hx - kotlin.math.cos(angle) * tail
    val ty = hy - kotlin.math.sin(angle) * tail
    val fade = (1f - kotlin.math.abs(p * 2f - 1f)).coerceIn(0f, 1f) * AmbientSky.METEOR_ALPHA

    drawLine(
        brush = Brush.linearGradient(
            colors = listOf(Color.Transparent, Color.White.copy(alpha = fade)),
            start = Offset(tx, ty), end = Offset(hx, hy)
        ),
        start = Offset(tx, ty), end = Offset(hx, hy),
        strokeWidth = 1.6f * density, cap = StrokeCap.Round
    )
}

/**
 * The backdrop's arithmetic, kept free of Compose so it can be unit-tested.
 *
 * The ceilings here are the design contract, not tuning knobs: [MAX_ALPHA] is what keeps the field
 * below the text it sits behind, and [STAR_COUNT] is what keeps the lit area negligible on OLED.
 */
object AmbientSky {
    const val STAR_COUNT = 54
    /** No star may ever be brighter than this: the backdrop must lose to the foreground. */
    const val MAX_ALPHA = 0.34f
    const val MIN_VISIBLE_ALPHA = 0.012f
    /** 20 updates per second, deliberately below display rate. */
    const val FRAME_INTERVAL_MILLIS = 50L
    const val METEOR_PERIOD = 40f
    const val METEOR_LIFE = 1.1f
    const val METEOR_ALPHA = 0.55f

    class Star(
        val x: Float,
        val y: Float,
        val radius: Float,
        val brightness: Float,
        val phase: Float,
        val speed: Float,
        val parallax: Float,
        val accented: Boolean
    )

    /** Deterministic field: the same sky every launch, so nothing "moves" between sessions. */
    fun stars(): Array<Star> {
        val random = kotlin.random.Random(1445)
        return Array(STAR_COUNT) { i ->
            val near = i % 9 == 0
            Star(
                x = random.nextFloat(),
                y = random.nextFloat(),
                radius = if (near) 1.0f + random.nextFloat() * 0.5f else 0.6f + random.nextFloat() * 0.4f,
                brightness = if (near) 0.62f + random.nextFloat() * 0.30f else 0.20f + random.nextFloat() * 0.28f,
                phase = random.nextFloat(),
                speed = 0.05f + random.nextFloat() * 0.09f,
                parallax = if (near) 1.4f else 0.5f,
                accented = near
            )
        }
    }

    /** Horizontal drift, wrapped into 0..1 so a star leaving the right edge returns on the left. */
    fun driftX(star: Star, t: Float): Float {
        val drift = star.x + t * star.parallax * 0.0025f
        return drift - kotlin.math.floor(drift)
    }

    /** Twinkle, clamped by [MAX_ALPHA]. Never negative, never above the ceiling. */
    fun alpha(star: Star, t: Float): Float {
        val twinkle = 0.60f + 0.40f * kotlin.math.sin(2f * Math.PI.toFloat() * (t * star.speed + star.phase))
        return (star.brightness * twinkle).coerceIn(0f, MAX_ALPHA)
    }

    fun hash(seed: Int): Float {
        var x = seed * 374761393 + 668265263
        x = (x xor (x shr 13)) * 1274126177
        return ((x xor (x shr 16)) and 0x7FFFFFFF) / 2147483647f
    }
}
