package com.nur.prayer

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.nur.prayer.location.LocationRequestPolicy
import com.nur.prayer.location.LocationRequestStep
import com.nur.prayer.notify.AzanPlayerService
import com.nur.prayer.notify.PrayerAlarmScheduler
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.AppViewModel
import com.nur.prayer.ui.NurRoot
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.SystemBar
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()
    private var permissionEpoch by mutableIntStateOf(0)
    private var awaitingLocationSettings = false
    private var locationReceiverRegistered = false
    private val locationSettingsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { continuePendingLocation() }
    }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { permissionEpoch++; viewModel.onPermissionsChanged() }

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (viewModel.hasLocationPermission()) {
            requestLocation() // permission and the system switch are separate gates
        } else {
            awaitingLocationSettings = true
            val step = nextLocationStep()
            viewModel.locationNeedsAction(step,
                "Доступ не выдан. Можно разрешить точное или приблизительное местоположение; прежнее место сохранено.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        awaitingLocationSettings = savedInstanceState?.getBoolean("awaiting_location_settings") ?: false
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(SystemBar.toArgb())
        )
        syncSystemBars()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            NurTheme {
                val data by viewModel.data.collectAsStateWithLifecycle()
                val locating by viewModel.locating.collectAsStateWithLifecycle()
                val locationStatus by viewModel.locationStatus.collectAsStateWithLifecycle()
                val locationStep by viewModel.locationStep.collectAsStateWithLifecycle()
                // Deliberately *not* `by`: the clock travels down the tree as state, so this
                // composable never recomposes on a tick. See the doc on `NurRoot.now`.
                val now = viewModel.now.collectAsStateWithLifecycle()
                // System dialogs return through onResume. Re-check immediately rather than
                // reading the clock here and invalidating the root once every minute.
                val exactAllowed = remember(permissionEpoch) {
                    PrayerAlarmScheduler.canScheduleExact(this@MainActivity)
                }
                val notificationsAllowed = remember(permissionEpoch) {
                    androidx.core.app.NotificationManagerCompat.from(this@MainActivity).areNotificationsEnabled()
                }

                NurRoot(
                    data = data,
                    now = now,
                    locating = locating,
                    locationStatus = locationStatus,
                    locationButtonLabel = locationStep.buttonLabel,
                    exactAlarmsAllowed = exactAllowed,
                    notificationsAllowed = notificationsAllowed,
                    citySearch = { query -> viewModel.cities(query) },
                    onPickCity = { city -> awaitingLocationSettings = false; viewModel.selectCity(city) },
                    actionsFactory = { openCityPicker ->
                        AppActions(
                            openCityPicker = openCityPicker,
                            requestLocation = { requestLocation() },
                            openLocationPermissions = { openLocationPermissions() },
                            openExactAlarmSettings = { openExactAlarmSettings() },
                            openBatterySettings = { openBatterySettings() },
                            openNotificationSettings = { openNotificationSettings() },
                            setMethod = { method ->
                                lifecycleScope.launch { viewModel.repository.setMethod(method) }
                            },
                            setMadhab = { madhab ->
                                lifecycleScope.launch { viewModel.repository.setMadhab(madhab) }
                            },
                            setHighLatitudeRule = { rule ->
                                lifecycleScope.launch { viewModel.repository.setHighLatitudeRule(rule) }
                            },
                            setRounding = { mode ->
                                lifecycleScope.launch { viewModel.repository.setRounding(mode) }
                            },
                            setNotification = { prayer, enabled ->
                                viewModel.setNotification(prayer, enabled)
                            },
                            setOffset = { prayer, minutes -> viewModel.setOffset(prayer, minutes) },
                            setAmbientBackdrop = { enabled ->
                                lifecycleScope.launch { viewModel.repository.setAmbientBackdrop(enabled) }
                            },
                            setPreAlert = { minutes ->
                                lifecycleScope.launch { viewModel.repository.setPreAlert(minutes) }
                            },
                            setAzanSound = { sound ->
                                lifecycleScope.launch { viewModel.repository.setAzanSound(sound) }
                            },
                            previewAzan = { sound ->
                                AzanPlayerService.play(
                                    this@MainActivity,
                                    "Проверка азана",
                                    sound.title,
                                    sound,
                                    preview = true
                                )
                            },
                            stopAzan = { AzanPlayerService.stopPreview(this@MainActivity) },
                            setHijriOffset = { days ->
                                lifecycleScope.launch { viewModel.repository.setHijriOffset(days) }
                            }
                        )
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        permissionEpoch++
        syncSystemBars()
        // Self-heal the alarm chain and the clock every time the user opens the app.
        continuePendingLocation()
        viewModel.refresh()
        viewModel.onPermissionsChanged()
    }

    override fun onStart() {
        super.onStart()
        viewModel.setForeground(true)
        val filter = IntentFilter(LocationManager.MODE_CHANGED_ACTION).apply {
            addAction(LocationManager.PROVIDERS_CHANGED_ACTION)
        }
        ContextCompat.registerReceiver(this, locationSettingsReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        locationReceiverRegistered = true
    }

    override fun onStop() {
        if (locationReceiverRegistered) {
            unregisterReceiver(locationSettingsReceiver)
            locationReceiverRegistered = false
        }
        viewModel.setForeground(false)
        super.onStop()
    }

    @Suppress("DEPRECATION")
    private fun syncSystemBars() {
        // Android 8–14 and target-34 compatibility: colour the actual THREE-BUTTON bar,
        // not just a Compose view above it. Gesture area is backed by the same opaque ink.
        window.navigationBarColor = SystemBar.toArgb()
        if (Build.VERSION.SDK_INT >= 28) window.navigationBarDividerColor = SystemBar.toArgb()
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightNavigationBars = false
            isAppearanceLightStatusBars = false
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("awaiting_location_settings", awaitingLocationSettings)
        super.onSaveInstanceState(outState)
    }

    private fun nextLocationStep(): LocationRequestStep = LocationRequestPolicy.next(
        hasPermission = viewModel.hasLocationPermission(),
        askedBefore = getPreferences(MODE_PRIVATE).getBoolean("location_permission_requested", false),
        showRationale = shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_COARSE_LOCATION) ||
            shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION),
        locationEnabled = viewModel.isLocationEnabled())

    private fun requestLocation() {
        when (val step = nextLocationStep()) {
            LocationRequestStep.LOCATE -> {
                awaitingLocationSettings = false
                viewModel.useDeviceLocation(forceFresh = true)
            }
            LocationRequestStep.REQUEST_PERMISSION -> {
                getPreferences(MODE_PRIVATE).edit().putBoolean("location_permission_requested", true).apply()
                locationPermission.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
            }
            LocationRequestStep.OPEN_LOCATION_SETTINGS -> {
                awaitingLocationSettings = true
                viewModel.locationNeedsAction(step,
                    "Включите геолокацию в Android и вернитесь в Nur — определение продолжится автоматически.")
                openLocationSettings(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS), step)
            }
            LocationRequestStep.OPEN_APP_SETTINGS -> {
                awaitingLocationSettings = true
                viewModel.locationNeedsAction(step,
                    "Откройте «Разрешения → Местоположение» и разрешите доступ при использовании. После возврата запрос продолжится.")
                openLocationSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")), step)
            }
        }
    }

    private fun openLocationPermissions() {
        awaitingLocationSettings = true
        viewModel.locationNeedsAction(LocationRequestStep.OPEN_APP_SETTINGS,
            "В разделе «Разрешения → Местоположение» можно включить точный доступ. После возврата Nur запросит новую точку.")
        openLocationSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")),
            LocationRequestStep.OPEN_APP_SETTINGS)
    }

    private fun openLocationSettings(intent: Intent, step: LocationRequestStep) {
        runCatching { startActivity(intent) }.onFailure {
            viewModel.locationNeedsAction(step, "Не удалось открыть системный экран. Включите геолокацию и доступ к ней в настройках Android вручную.")
        }
    }

    private fun continuePendingLocation() {
        if (!awaitingLocationSettings && viewModel.locationStep.value != LocationRequestStep.OPEN_LOCATION_SETTINGS) return
        if (viewModel.hasLocationPermission() && viewModel.isLocationEnabled()) {
            awaitingLocationSettings = false
            viewModel.useDeviceLocation(forceFresh = true)
        } else {
            val step = nextLocationStep()
            viewModel.locationNeedsAction(step, if (viewModel.hasLocationPermission())
                "Геолокация пока выключена. Нажмите «Включить геолокацию»; прежнее место сохранено."
            else "Доступ к местоположению пока не выдан. Нажмите кнопку разрешения или выберите город вручную.")
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            }
        }
    }

    private fun openNotificationSettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
    }

    private fun openBatterySettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }.onFailure {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
    }
}
