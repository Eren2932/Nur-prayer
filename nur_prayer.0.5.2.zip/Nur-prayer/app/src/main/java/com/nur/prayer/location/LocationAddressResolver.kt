package com.nur.prayer.location

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.os.Build
import com.nur.prayer.core.astro.Coordinates
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull

/** Best effort only; location and prayer calculation do not wait for the geocoder. */
class LocationAddressResolver(private val context: Context) {
    suspend fun resolve(coordinates: Coordinates): LocationAddress? {
        if (!Geocoder.isPresent()) return null
        return withTimeoutOrNull(ADDRESS_TIMEOUT_MILLIS) {
            suspendCancellableCoroutine<LocationAddress?> { continuation ->
                val settled = AtomicBoolean(false)
                fun finish(address: Address?) {
                    if (!settled.compareAndSet(false, true)) return
                    val value = address?.let {
                        LocationAddress.fromParts(it.locality ?: it.subAdminArea, it.subLocality,
                            it.thoroughfare, it.subThoroughfare, it.postalCode)
                    }
                    if (continuation.isActive) continuation.resume(value)
                }
                val geocoder = Geocoder(context, Locale.forLanguageTag("ru"))
                if (Build.VERSION.SDK_INT >= 33) {
                    continuation.invokeOnCancellation { settled.set(true) }
                    try {
                        geocoder.getFromLocation(coordinates.latitude, coordinates.longitude, 1,
                            object : Geocoder.GeocodeListener {
                                override fun onGeocode(addresses: MutableList<Address>) = finish(addresses.firstOrNull())
                                override fun onError(errorMessage: String?) = finish(null)
                            })
                    } catch (_: Exception) { finish(null) }
                } else {
                    // The pre-33 Binder API can block and ignore interruption. One daemon worker
                    // bounds resource use; cancellation releases the coroutine, not just a withContext.
                    val future = legacyWorker.submit {
                        @Suppress("DEPRECATION")
                        val address = runCatching {
                            geocoder.getFromLocation(coordinates.latitude, coordinates.longitude, 1)?.firstOrNull()
                        }.getOrNull()
                        finish(address)
                    }
                    continuation.invokeOnCancellation { settled.set(true); future.cancel(true) }
                }
            }
        }
    }

    companion object {
        const val ADDRESS_TIMEOUT_MILLIS = 4_000L
        private val legacyWorker = Executors.newSingleThreadExecutor { task ->
            Thread(task, "nur-address").apply { isDaemon = true }
        }
    }
}
