package com.nur.prayer.ui.qibla

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.KaabaIcon
import com.nur.prayer.ui.theme.Amber
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Qibla, 0.5.1.
 *
 * The instrument is the 0.3.0 dial again: a graduated ring, cardinal letters that turn with the
 * world, a tolerance cone around the bearing, a fixed device pointer and a real bubble level.
 * 0.5.0 had cut all of it down to one circle and one arrow, which reads as a placeholder — and,
 * worse, gave the eye nothing to judge *how far off* it was other than a number.
 *
 * What is kept from 0.5.0, deliberately:
 *  - [QiblaGuidance] remains the single source of truth for "are we aligned" and for the wording.
 *    The dial only paints what that policy already decided, so an untrusted sensor can never turn
 *    anything green — the bug the 0.3.0 screen had, where the night accent was itself mint.
 *  - [KaabaIcon], the drawn glyph, instead of the 🕋 emoji, which rendered differently per OEM.
 *  - the collapsed "Точность и датчики" table, the test tag and the state descriptions.
 */
@Composable
fun QiblaScreen(
    data: PrayerData,
    palette: PhasePalette,
    modifier: Modifier = Modifier,
    headingOverride: Heading? = null
) {
    val ui = uiScale()
    var showDetails by rememberSaveable { mutableStateOf(false) }
    val heading = headingOverride
        ?: rememberHeading(data.place.coordinates.latitude, data.place.coordinates.longitude)
    val qibla = data.qibla.toFloat()
    val delta = angleDelta(heading.azimuth, qibla)
    val usable = heading.available && heading.trustworthy && heading.heldFlat && delta.isFinite()
    val aligned = QiblaGuidance.aligned(delta, heading.available, heading.trustworthy, heading.heldFlat)
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(aligned) {
        if (aligned) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    // Two colours answering two different questions, as in 0.3.0.
    // `markColor` — "am I on the Kaaba?"; it is allowed to go mint only on a confirmed lock.
    // `deviceColor` — "can the sensors be trusted?"; silent while everything is fine.
    val markColor by animateColorAsState(
        if (aligned) Mint else TextPrimary, tween(220), label = "qiblaMark"
    )
    val deviceColor by animateColorAsState(
        when {
            aligned -> Mint
            heading.interference -> Crimson
            heading.available && !heading.heldFlat -> Amber
            else -> TextSecondary
        },
        tween(360), label = "qiblaDevice"
    )
    // Width of the lock-on bloom: 0 while searching, 1 when locked.
    val lock by animateFloatAsState(if (aligned) 1f else 0f, tween(300), label = "qiblaLock")

    var rotationTarget by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(heading.azimuth, usable) {
        if (usable) rotationTarget = nearestDialRotation(rotationTarget, heading.azimuth)
    }
    val rotation = animateFloatAsState(rotationTarget, tween(90), label = "qiblaRotation")
    val instruction = QiblaGuidance.instruction(delta, heading.available, heading.trustworthy, heading.heldFlat)
    val warning = when {
        !heading.available -> "На устройстве нет доступного датчика направления. Используйте азимут кыблы по карте или другому компасу."
        heading.interference -> "Отойдите от металла, магнитного чехла и динамиков."
        !heading.trustworthy -> "Проведите телефоном «восьмёркой» для калибровки."
        !heading.heldFlat -> "Держите телефон экраном вверх."
        else -> null
    }

    Column(
        modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(24f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Кыбла", color = TextPrimary, fontSize = ui.t(30f), fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f))
            AutoSizeText(data.place.label, color = TextSecondary, fontSize = ui.t(13f), maxLines = 2,
                textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
        }
        Spacer(Modifier.height(if (ui.compact) 10.dp else 22.dp))

        // The dial never grows past what the viewport can host, whatever the font scale is.
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val dialSize = min(maxWidth, min((ui.heightDp * 0.42f).dp, if (ui.compact) 280.dp else 336.dp))
            Box(
                Modifier
                    .width(dialSize)
                    .aspectRatio(1f)
                    .align(Alignment.Center)
                    .testTag("qibla-instrument")
                    .semantics {
                        stateDescription = when {
                            aligned -> "Направление найдено"
                            usable -> "Поиск направления"
                            else -> "Нет достоверного направления"
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                // The world rotates, the phone stays still. With no trustworthy heading there is
                // nothing to rotate *to*, so the dial is frozen at north instead of drifting.
                Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = if (usable) rotation.value else 0f }) {
                    Canvas(Modifier.fillMaxSize()) {
                        val r = size.minDimension / 2f * 0.86f
                        if (r < 4f) return@Canvas
                        val c = center

                        drawCircle(SurfaceEdge, r, c, style = Stroke(1.2f * density))
                        drawCircle(SurfaceEdge.copy(alpha = 0.55f), r * 0.62f, c, style = Stroke(1f * density))

                        // 72 graduations, every sixth (30°) major.
                        for (i in 0 until 72) {
                            val a = Math.toRadians(i * 5.0 - 90.0)
                            val major = i % 6 == 0
                            val inner = r - r * (if (major) 0.10f else 0.045f)
                            drawLine(
                                color = if (major) TextSecondary else SurfaceEdge,
                                start = Offset(c.x + r * cos(a).toFloat(), c.y + r * sin(a).toFloat()),
                                end = Offset(c.x + inner * cos(a).toFloat(), c.y + inner * sin(a).toFloat()),
                                strokeWidth = (if (major) 2.2f else 1.2f) * density,
                                cap = StrokeCap.Round
                            )
                        }

                        // Qibla ray plus the tolerance cone: a hairline hint while searching, filled
                        // on lock, so the transition is felt rather than read.
                        val qa = Math.toRadians(qibla - 90.0)
                        val coneHalf = Math.toRadians(6.0)
                        val cone = Path().apply {
                            moveTo(c.x, c.y)
                            lineTo(c.x + r * cos(qa - coneHalf).toFloat(), c.y + r * sin(qa - coneHalf).toFloat())
                            lineTo(c.x + r * cos(qa + coneHalf).toFloat(), c.y + r * sin(qa + coneHalf).toFloat())
                            close()
                        }
                        drawPath(cone, markColor.copy(alpha = (0.04f + 0.12f * lock) * if (usable) 1f else 0.4f))
                        drawLine(
                            brush = Brush.linearGradient(
                                listOf(
                                    markColor.copy(alpha = 0.10f),
                                    markColor.copy(alpha = (0.45f + 0.55f * lock) * if (usable) 1f else 0.35f)
                                )
                            ),
                            start = c,
                            end = Offset(c.x + r * 0.94f * cos(qa).toFloat(), c.y + r * 0.94f * sin(qa).toFloat()),
                            strokeWidth = (2.4f + 1.2f * lock) * density,
                            cap = StrokeCap.Round
                        )
                    }

                    CardinalLabel("С", 0f, TextPrimary, ui.t(13f))
                    CardinalLabel("В", 90f, TextTertiary, ui.t(12f))
                    CardinalLabel("Ю", 180f, TextTertiary, ui.t(12f))
                    CardinalLabel("З", 270f, TextTertiary, ui.t(12f))

                    // Kaaba marker: rides the dial at the bearing, stays upright for the reader.
                    Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = qibla }) {
                        KaabaIcon(
                            edge = if (usable) markColor else TextTertiary,
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = ui.s(24f))
                                .size(ui.s(26f))
                                .graphicsLayer { rotationZ = -(if (usable) rotation.value else 0f) - qibla }
                                .semantics { contentDescription = "Кааба — направление кыблы" }
                        )
                    }
                }

                // Fixed device pointer, drawn on top of the rotating dial. Hidden when there is no
                // heading to point with: an arrow that cannot be trusted must not be shown at all.
                if (usable) {
                    Canvas(Modifier.fillMaxSize()) {
                        val r = size.minDimension / 2f * 0.86f
                        if (r < 4f) return@Canvas
                        val c = center
                        val tip = r * 1.11f
                        val path = Path().apply {
                            moveTo(c.x, c.y - tip)
                            lineTo(c.x - r * 0.045f, c.y - r * 0.98f)
                            lineTo(c.x + r * 0.045f, c.y - r * 0.98f)
                            close()
                        }
                        drawPath(path, deviceColor)
                        drawCircle(TextPrimary.copy(alpha = 0.85f), 2.4f * density, c)
                    }
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.widthIn(max = dialSize * 0.56f).padding(top = ui.s(16f))
                ) {
                    AutoSizeText(
                        text = if (usable) "${abs(delta).roundToInt()}°" else "—",
                        color = markColor,
                        fontSize = ui.t(44f),
                        minFontSize = ui.t(24f),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Light
                    )
                    Spacer(Modifier.height(ui.s(6f)))
                    BubbleLevel(heading.tiltDegrees, ui.s(32f), deviceColor, heading.available)
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        AutoSizeText(instruction, color = if (aligned) Mint else TextSecondary, fontSize = ui.t(15f),
            maxLines = 2, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        if (warning != null) {
            Text(warning, color = Amber, fontSize = ui.t(12f), lineHeight = ui.t(18f),
                textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp))
        }

        Spacer(Modifier.height(26.dp))
        InfoRow("Азимут кыблы", QiblaGuidance.degrees(qibla))
        InfoRow("До Каабы", "${data.kaabaDistanceKm.roundToInt()} км")
        Box(Modifier.fillMaxWidth().padding(top = 16.dp).height(1.dp).background(SurfaceEdge))
        Row(
            Modifier.fillMaxWidth().heightIn(min = 56.dp)
                .clickable(role = Role.Button, onClick = { showDetails = !showDetails })
                .semantics { stateDescription = if (showDetails) "Развёрнуто" else "Свёрнуто" },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Точность и датчики", color = TextSecondary, fontSize = ui.t(14f), modifier = Modifier.weight(1f))
            Text(if (showDetails) "−" else "+", color = palette.accent, fontSize = ui.t(22f))
        }
        AnimatedVisibility(showDetails) {
            Column {
                InfoRow("Курс устройства", if (heading.available) QiblaGuidance.degrees(heading.azimuth) else "—")
                InfoRow("Магнитный курс", if (heading.available) QiblaGuidance.degrees(heading.magneticAzimuth) else "—")
                InfoRow("Магнитная поправка", "${heading.declination.roundToInt()}°")
                InfoRow("Наклон", if (heading.available) "${heading.tiltDegrees.roundToInt()}°" else "—")
                InfoRow("Магнитное поле", if (heading.fieldStrength > 0f) "${heading.fieldStrength.roundToInt()} мкТл" else "—")
                InfoRow("Калибровка", when (heading.accuracy) {
                    3 -> "Высокая"
                    2 -> "Средняя"
                    1 -> "Низкая"
                    else -> "Не определена"
                })
                InfoRow("Датчики", when (heading.source) {
                    HeadingSource.FUSED -> "Гироскоп, магнитометр"
                    HeadingSource.GEOMAGNETIC -> "Магнитометр, акселерометр"
                    HeadingSource.RAW -> "Сырые показания"
                    HeadingSource.NONE -> "Недоступны"
                })
                Text("Азимут отсчитывается от истинного севера. Магнитная поправка учтена. Зелёный указатель — отклонение не более 2,5° по показаниям датчика, а не гарантия его точности.",
                    color = TextTertiary, fontSize = ui.t(12f), lineHeight = ui.t(18f), modifier = Modifier.padding(top = 12.dp))
            }
        }
        Spacer(Modifier.height(LocalDockInset.current))
    }
}

/** Real bubble level: the dot walks off centre as the phone tilts away from horizontal. */
@Composable
private fun BubbleLevel(tiltDegrees: Float, size: Dp, accent: Color, available: Boolean) {
    val tilt = if (available && tiltDegrees.isFinite()) tiltDegrees else 0f
    val normalized = (tilt / 45f).coerceIn(0f, 1f)
    val flat = available && tilt <= 12f
    Canvas(Modifier.size(size)) {
        if (this.size.minDimension < 4f) return@Canvas
        val r = this.size.minDimension / 2f
        val c = center
        drawCircle(SurfaceEdge, r, c, style = Stroke(1.2f * density))
        drawCircle(SurfaceEdge.copy(alpha = 0.7f), r * 0.30f, c, style = Stroke(1f * density))
        drawCircle(
            color = if (!available) TextTertiary.copy(alpha = 0.5f)
                else if (flat) accent.copy(alpha = 0.9f) else accent.copy(alpha = 0.85f),
            radius = r * 0.22f,
            center = Offset(c.x, c.y + normalized * r * 0.72f)
        )
    }
}

@Composable
private fun CardinalLabel(text: String, angle: Float, color: Color, fontSize: TextUnit) {
    Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = angle }) {
        Text(
            text = text,
            color = color,
            fontSize = fontSize,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.TopCenter).graphicsLayer { rotationZ = -angle }
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextSecondary, fontSize = ui.t(13f), modifier = Modifier.weight(1f))
        Spacer(Modifier.width(16.dp))
        AutoSizeText(value, color = TextPrimary, fontSize = ui.t(14f), maxLines = 2,
            textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}
