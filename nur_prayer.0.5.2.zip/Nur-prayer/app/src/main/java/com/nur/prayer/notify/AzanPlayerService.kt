package com.nur.prayer.notify

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.nur.prayer.MainActivity
import com.nur.prayer.R

/**
 * Plays the adhan, and can be told to stop.
 *
 * ### Why a service and not just a channel sound
 *
 * A notification channel can carry a sound file, and that is the cheap way to play an adhan — three
 * lines, no service. It is also unstoppable: once the system starts a channel sound there is no
 * "quiet down" button, so a three-and-a-half-minute recording in a meeting can only be survived.
 * On top of that a channel's sound is frozen at creation time, so every change of setting has to
 * create a new channel and the app slowly grows a graveyard of them in system settings.
 *
 * So the audio lives here: it uses the alarm stream, it takes audio focus so the music the user was
 * listening to pauses instead of mixing, it fades out instead of cutting, and the notification it
 * posts has a Stop button. If the system refuses to start a foreground service — which it can, in
 * the background on Android 12+, even with the exact-alarm exemption this app relies on — the
 * receiver falls back to a notification whose channel carries the same recording, and the user still
 * hears the adhan. Losing the call to prayer entirely is not an acceptable failure mode.
 */
class AzanPlayerService : Service() {

    private var player: MediaPlayer? = null
    private var focusRequest: AudioFocusRequest? = null
    private val handler = Handler(Looper.getMainLooper())
    private var fadeStep = 0
    private var previewPlayback = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_PREVIEW) {
            if (previewPlayback || player == null) stopEverything()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_STOP) {
            stopEverything()
            return START_NOT_STICKY
        }

        previewPlayback = intent?.getBooleanExtra(EXTRA_PREVIEW, false) == true
        val prayerTitle = intent?.getStringExtra(EXTRA_TITLE) ?: "Время намаза"
        val subtitle = intent?.getStringExtra(EXTRA_TEXT).orEmpty()
        val limitSeconds = intent?.getIntExtra(EXTRA_LIMIT_SECONDS, 0) ?: 0

        // startForeground first, and unconditionally: the system gives a started service a few
        // seconds to show its notification and kills the process if it does not.
        runCatching { startForeground(NOTIFICATION_ID, buildNotification(prayerTitle, subtitle)) }

        if (isSilenced()) {
            // The phone is switched to silent. Playing the adhan through the alarm stream anyway
            // would technically be louder than any other notification in the tray — and would be
            // exactly the behaviour that makes people uninstall a prayer app.
            stopEverything()
            return START_NOT_STICKY
        }

        startPlayback(limitSeconds)
        return START_NOT_STICKY
    }

    private fun startPlayback(limitSeconds: Int) {
        stopPlayerOnly()
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val audioManager = getSystemService(AudioManager::class.java)
        if (audioManager != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attributes)
                .build()
            focusRequest = request
            runCatching { audioManager.requestAudioFocus(request) }
        }

        val started = runCatching {
            val created = MediaPlayer()
            created.setAudioAttributes(attributes)
            resources.openRawResourceFd(AzanSound.RAW_RES_ID).use { descriptor ->
                created.setDataSource(
                    descriptor.fileDescriptor, descriptor.startOffset, descriptor.length
                )
            }
            created.isLooping = false
            created.setOnCompletionListener { stopEverything() }
            created.setOnErrorListener { _, _, _ -> stopEverything(); true }
            created.prepare()
            created.setVolume(1f, 1f)
            created.start()
            created
        }.getOrNull()

        if (started == null) {
            stopEverything()
            return
        }
        player = started

        if (limitSeconds > 0) {
            handler.postDelayed({ fadeOut() }, limitSeconds * 1000L)
        }
        // Hard ceiling: a stuck player must never hold the alarm stream for longer than the
        // recording itself, whatever the reason.
        handler.postDelayed({ stopEverything() }, MAX_PLAYBACK_MILLIS)
    }

    /** Eight steps over 1.2 s — long enough not to click, short enough not to feel like a bug. */
    private fun fadeOut() {
        val current = player ?: return stopEverything()
        fadeStep += 1
        val volume = (1f - fadeStep / 8f).coerceAtLeast(0f)
        runCatching { current.setVolume(volume, volume) }
        if (volume <= 0f) stopEverything() else handler.postDelayed({ fadeOut() }, 150L)
    }

    private fun isSilenced(): Boolean {
        val audioManager = getSystemService(AudioManager::class.java) ?: return false
        return audioManager.ringerMode == AudioManager.RINGER_MODE_SILENT
    }

    private fun buildNotification(title: String, text: String): Notification {
        val stopIntent = PendingIntent.getService(
            this,
            REQUEST_STOP,
            Intent(this, AzanPlayerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this,
            REQUEST_OPEN,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, NotificationHelper.CHANNEL_AZAN_PLAYING)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(if (text.isBlank()) "Азан" else text)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(openIntent)
            .addAction(0, "Остановить", stopIntent)
            .build()
    }

    private fun stopPlayerOnly() {
        player?.let { existing ->
            runCatching { if (existing.isPlaying) existing.stop() }
            runCatching { existing.release() }
        }
        player = null
    }

    private fun stopEverything() {
        handler.removeCallbacksAndMessages(null)
        fadeStep = 0
        stopPlayerOnly()
        val audioManager = getSystemService(AudioManager::class.java)
        val request = focusRequest
        if (audioManager != null && request != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            runCatching { audioManager.abandonAudioFocusRequest(request) }
        }
        focusRequest = null
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopPlayerOnly()
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 7712
        private const val REQUEST_STOP = 7713
        private const val REQUEST_OPEN = 7714
        private const val MAX_PLAYBACK_MILLIS = 4 * 60 * 1000L

        private const val ACTION_STOP_PREVIEW = "com.nur.prayer.AZAN_STOP_PREVIEW"
        private const val EXTRA_PREVIEW = "preview"
        const val ACTION_PLAY = "com.nur.prayer.AZAN_PLAY"
        const val ACTION_STOP = "com.nur.prayer.AZAN_STOP"
        private const val EXTRA_TITLE = "title"
        private const val EXTRA_TEXT = "text"
        private const val EXTRA_LIMIT_SECONDS = "limit_seconds"

        /**
         * @return true when the service was started, false when the system refused — the caller then
         * has to make the sound happen some other way.
         */
        fun play(context: Context, title: String, text: String, sound: AzanSound, preview: Boolean = false): Boolean {
            if (!sound.playsAzan) return false
            val intent = Intent(context, AzanPlayerService::class.java)
                .setAction(ACTION_PLAY)
                .putExtra(EXTRA_PREVIEW, preview)
                .putExtra(EXTRA_TITLE, title)
                .putExtra(EXTRA_TEXT, text)
                .putExtra(EXTRA_LIMIT_SECONDS, sound.limitSeconds)
            return runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }.isSuccess
        }

        fun stopPreview(context: Context) {
            runCatching {
                context.startService(Intent(context, AzanPlayerService::class.java).setAction(ACTION_STOP_PREVIEW))
            }
        }

        fun stop(context: Context) {
            runCatching {
                context.startService(
                    Intent(context, AzanPlayerService::class.java).setAction(ACTION_STOP)
                )
            }
        }
    }
}
