package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.CountdownMath
import com.nur.prayer.ui.theme.SurfaceEdge
import java.time.ZonedDateTime
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * The 270° observatory dial, restored in 0.5.1.
 *
 * 0.5.0 replaced it with a single progress line at the bottom edge. That line was honest but mute:
 * a bar cannot show *where* in the interval you are without a scale to read it against, so the
 * countdown text carried the whole screen alone. The dial is the 0.3.0 geometry — 270° of arc open
 * at the bottom, sixty-one graduations, one marker at the live position — redrawn with 0.5.0 tokens
 * only: [SurfaceEdge] for the unfilled track and the palette accent for elapsed time. No plate, no
 * gradient, no glow behind it, so the AMOLED background stays switched off underneath.
 *
 * Cost is unchanged from 0.3.0: one Canvas, no allocation per frame, and only this canvas is
 * invalidated on a tick because `now` is read inside the draw scope rather than in composition.
 */
@Composable
fun CountdownRing(
    startMillis: Long,
    endMillis: Long,
    now: State<ZonedDateTime>,
    accent: Color,
    accentSoft: Color,
    modifier: Modifier = Modifier,
    stroke: Dp = 2.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            if (size.minDimension < 24f) return@Canvas
            val phase = CountdownMath.progress(startMillis, endMillis, now.value.toInstant().toEpochMilli())
            val radius = size.minDimension * 0.44f
            val c = center
            val box = Size(radius * 2, radius * 2)
            val origin = Offset(c.x - radius, c.y - radius)
            val line = stroke.toPx().coerceIn(1f, radius * 0.1f)

            // Track first, elapsed arc on top: the accent never has to be drawn under anything.
            drawArc(SurfaceEdge, 135f, 270f, false, origin, box, style = Stroke(line, cap = StrokeCap.Round))
            if (phase > 0f) {
                drawArc(accent, 135f, 270f * phase, false, origin, box, style = Stroke(line, cap = StrokeCap.Round))
            }

            // 61 graduations, every fifth one long. Passed ticks take the soft accent, so the scale
            // itself reports progress even at a glance that misses the marker.
            for (i in 0..60) {
                val angle = (135.0 + i * 4.5) * PI / 180.0
                val major = i % 5 == 0
                val outer = radius + 9.dp.toPx()
                val inner = outer - (if (major) 5.dp else 2.dp).toPx()
                drawLine(
                    if (i / 60f <= phase) accentSoft else SurfaceEdge,
                    Offset(c.x + outer * cos(angle).toFloat(), c.y + outer * sin(angle).toFloat()),
                    Offset(c.x + inner * cos(angle).toFloat(), c.y + inner * sin(angle).toFloat()),
                    strokeWidth = 1.dp.toPx()
                )
            }

            val angle = (135.0 + 270.0 * phase) * PI / 180.0
            val marker = Offset(c.x + radius * cos(angle).toFloat(), c.y + radius * sin(angle).toFloat())
            drawCircle(accent, 4.dp.toPx(), marker)
            drawCircle(accentSoft, 1.5.dp.toPx(), marker)
        }
        content()
    }
}
