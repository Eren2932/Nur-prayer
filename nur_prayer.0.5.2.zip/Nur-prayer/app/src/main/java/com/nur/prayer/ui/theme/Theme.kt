package com.nur.prayer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.sp

private val NurColors = darkColorScheme(
    primary = Gold,
    onPrimary = Ink,
    secondary = Mint,
    onSecondary = Ink,
    background = Ink,
    onBackground = TextPrimary,
    surface = InkSoft,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceRaised,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceEdge
)

private val NurTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Light,
        fontSize = 60.sp, lineHeight = 64.sp, letterSpacing = (-1).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold,
        fontSize = 28.sp, lineHeight = 34.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium,
        fontSize = 17.sp, lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal,
        fontSize = 15.sp, lineHeight = 20.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium,
        fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 0.8.sp
    )
)

/**
 * The app is intentionally always dark: it is used in a dim mosque and at 4 in the morning.
 *
 * The theme also owns adaptive metrics: the system font scale is clamped to a range the layout can
 * absorb, and [LocalUiScale] carries multipliers derived from the real viewport. Text keeps growing
 * for accessibility, but it can no longer push controls off screen.
 */
@Composable
fun NurTheme(content: @Composable () -> Unit) {
    val base = LocalDensity.current
    val configuration = LocalConfiguration.current

    val clampedDensity = remember(base.density, base.fontScale) {
        Density(
            density = base.density,
            fontScale = base.fontScale.coerceIn(MIN_FONT_SCALE, MAX_FONT_SCALE)
        )
    }
    val scale = remember(configuration.screenWidthDp, configuration.screenHeightDp, base.fontScale) {
        UiScale.of(configuration.screenWidthDp, configuration.screenHeightDp, base.fontScale)
    }

    CompositionLocalProvider(
        LocalDensity provides clampedDensity,
        LocalUiScale provides scale
    ) {
        MaterialTheme(colorScheme = NurColors, typography = NurTypography, content = content)
    }
}
