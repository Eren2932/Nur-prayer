package com.nur.prayer.ui.settings

import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset

object CityTimeZones {
    /** Includes 30/45-minute offsets; callers pass one instant for the entire result set. */
    fun label(zoneId: String, at: Instant): String = label(ZoneId.of(zoneId).rules.getOffset(at))
    fun label(offset: ZoneOffset): String {
        val seconds = offset.totalSeconds
        if (seconds == 0) return "UTC±0"
        val minutes = kotlin.math.abs(seconds) / 60
        val hours = minutes / 60
        val remainder = minutes % 60
        return "UTC" + (if (seconds >= 0) "+" else "−") + hours +
            (if (remainder == 0) "" else ":" + remainder.toString().padStart(2, '0'))
    }
}
