package com.nur.prayer.location

/** Address is display metadata only: it never replaces the measured coordinates. */
data class LocationAddress(val locality: String?, val detail: String?, val postalCode: String?) {
    companion object {
        private fun clean(value: String?): String? = value?.trim()?.replace(Regex("\\s+"), " ")
            ?.take(120)?.takeIf { it.isNotBlank() }

        fun fromParts(locality: String?, subLocality: String?, street: String?, house: String?, postalCode: String?): LocationAddress {
            val road = listOfNotNull(clean(street), clean(house)).distinct().joinToString(" ").ifBlank { null }
            val detail = listOfNotNull(clean(subLocality), road).distinct().joinToString(", ").ifBlank { null }
            return LocationAddress(clean(locality), detail, clean(postalCode))
        }
    }
}
