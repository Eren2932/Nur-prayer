package com.nur.prayer.location

/** Pure policy: no Android clock, LocationManager or network required for regression tests. */
object LocationFixPolicy {
    const val TARGET_ACCURACY_METERS = 40f
    const val MAX_ACCURACY_METERS = 20_000f
    const val ADDRESS_ACCURACY_METERS = 100f
    const val MAX_CACHE_AGE_MILLIS = 120_000L
    const val FAST_CACHE_AGE_MILLIS = 30_000L
    const val DEADLINE_MILLIS = 20_000L
    const val NETWORK_GRACE_MILLIS = 2_500L
    const val AUTO_REFRESH_MILLIS = 5 * 60_000L

    fun ageMillis(nowElapsedNanos: Long, fixElapsedNanos: Long, nowWallMillis: Long, fixWallMillis: Long): Long {
        if (fixElapsedNanos > 0L && nowElapsedNanos >= fixElapsedNanos) {
            return (nowElapsedNanos - fixElapsedNanos) / 1_000_000L
        }
        // A future or missing wall timestamp must not be coerced into a fresh location.
        return if (fixWallMillis > 0L && nowWallMillis >= fixWallMillis) nowWallMillis - fixWallMillis
        else Long.MAX_VALUE
    }

    fun usable(latitude: Double, longitude: Double, accuracyMeters: Float, ageMillis: Long): Boolean =
        latitude.isFinite() && longitude.isFinite() && latitude in -90.0..90.0 && longitude in -180.0..180.0 &&
            accuracyMeters.isFinite() && accuracyMeters > 0f && accuracyMeters <= MAX_ACCURACY_METERS &&
            ageMillis in 0L..MAX_CACHE_AGE_MILLIS

    fun mayUseCacheImmediately(forceFresh: Boolean, accuracyMeters: Float, ageMillis: Long): Boolean =
        !forceFresh && accuracyMeters in 0.1f..TARGET_ACCURACY_METERS && ageMillis in 0L..FAST_CACHE_AGE_MILLIS

    fun isLiveCallback(fixElapsedNanos: Long, requestElapsedNanos: Long, ageMillis: Long): Boolean =
        fixElapsedNanos > 0L && fixElapsedNanos >= requestElapsedNanos - 5_000_000_000L &&
            ageMillis in 0L..FAST_CACHE_AGE_MILLIS

    fun mayDescribeStreet(precisePermission: Boolean, accuracyMeters: Float): Boolean =
        precisePermission && accuracyMeters.isFinite() && accuracyMeters > 0f && accuracyMeters <= ADDRESS_ACCURACY_METERS

    fun score(accuracyMeters: Float, ageMillis: Long): Double = accuracyMeters.toDouble() + ageMillis / 2000.0
}
