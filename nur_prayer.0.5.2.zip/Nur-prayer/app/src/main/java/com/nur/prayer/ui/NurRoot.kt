package com.nur.prayer.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.City
import com.nur.prayer.ui.components.DockIcon
import com.nur.prayer.ui.components.DockItem
import com.nur.prayer.ui.components.LocalBackdropPaused
import com.nur.prayer.ui.components.NightSky
import com.nur.prayer.ui.components.NurDock
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.settings.SettingsScreen
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.SystemBar
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.paletteFor
import com.nur.prayer.ui.theme.animatedPhasePalette
import java.time.ZonedDateTime

@Composable
fun NurRoot(
    data: PrayerData?, now: State<ZonedDateTime>, locating: Boolean, locationStatus: String?,
    exactAlarmsAllowed: Boolean, notificationsAllowed: Boolean, citySearch: suspend (String) -> List<City>, onPickCity: (City) -> Unit,
    actionsFactory: (openCityPicker: () -> Unit) -> AppActions,
    locationButtonLabel: String = "Определить местоположение"
) {
    val nav = rememberSaveable(saver = NurNavigator.Saver) { NurNavigator() }
    val pages = rememberSaveableStateHolder()
    val backdropPaused = remember { mutableStateOf(false) }
    BackHandler(nav.canGoBack) { nav.back() }
    val targetPalette = remember(data?.window?.current) {
        paletteFor(data?.window?.current ?: com.nur.prayer.core.astro.Prayer.ISHA)
    }
    val palette = animatedPhasePalette(targetPalette)
    val actions = remember(nav) { actionsFactory { nav.go(ROUTE_CITY) } }
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    CompositionLocalProvider(LocalDockInset provides (88.dp + bottom), LocalBackdropPaused provides backdropPaused) {
        Box(Modifier.fillMaxSize()) {
            // The backdrop lives behind every route, but it is the user's switch that arms it.
            NightSky(palette, motionEnabled = data?.settings?.ambientBackdrop == true)
            Box(Modifier.fillMaxSize().statusBarsPadding()) {
                AnimatedContent(
                    targetState = nav.current,
                    transitionSpec = {
                        val opening = targetState == ROUTE_CITY
                        val closing = initialState == ROUTE_CITY
                        val enter = when {
                            opening -> slideInHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS, easing = FastOutSlowInEasing)) { it }
                            closing -> fadeIn(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) +
                                slideInHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS)) { -it / 12 }
                            else -> fadeIn(tween(NavigationMotion.TAB_ENTER_MILLIS))
                        }
                        val exit = when {
                            closing -> slideOutHorizontally(tween(NavigationMotion.DETAIL_EXIT_MILLIS, easing = FastOutLinearInEasing)) { it }
                            opening -> fadeOut(tween(NavigationMotion.EXIT_MILLIS)) +
                                slideOutHorizontally(tween(NavigationMotion.DETAIL_ENTER_MILLIS)) { -it / 12 }
                            else -> fadeOut(tween(NavigationMotion.EXIT_MILLIS))
                        }
                        (enter togetherWith exit).apply { targetContentZIndex = if (closing) -1f else 1f }.using(null)
                    }, label = "nurRoute", modifier = Modifier.fillMaxSize()
                ) { route ->
                    pages.SaveableStateProvider(route) {
                        if (data == null) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Загрузка…", color = TextPrimary)
                            }
                        } else when (route) {
                            ROUTE_CITY -> CityPickerScreen(palette, data.settings.cityId, citySearch,
                                onPick = { city -> onPickCity(city); nav.back() }, onBack = { nav.back() },
                                onUseLocation = actions.requestLocation, locating = locating, locationStatus = locationStatus,
                                currentPlace = data.place, locationButtonLabel = locationButtonLabel,
                                onOpenLocationPermissions = actions.openLocationPermissions)
                            TAB_SETTINGS -> SettingsScreen(data, palette, actions, exactAlarmsAllowed, locating, locationStatus,
                                notificationsAllowed = notificationsAllowed, locationButtonLabel = locationButtonLabel)
                            TAB_SCHEDULE -> ScheduleScreen(data, now, palette)
                            TAB_QIBLA -> QiblaScreen(data, palette)
                            else -> HomeScreen(data, now, palette, onOpenCity = { nav.go(ROUTE_CITY) })
                        }
                    }
                }
            }
            // Backing for edge-to-edge gesture / button navigation, including the city overlay.
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .windowInsetsBottomHeight(WindowInsets.navigationBars).background(SystemBar))
            if (!nav.isOverlay) {
                Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding()) {
                    val items = remember { listOf(
                        DockItem(TAB_HOME, "Намаз", DockIcon.PRAYER),
                        DockItem(TAB_SCHEDULE, "Календарь", DockIcon.CALENDAR),
                        DockItem(TAB_QIBLA, "Кыбла", DockIcon.QIBLA),
                        DockItem(TAB_SETTINGS, "Настройки", DockIcon.SETTINGS)
                    ) }
                    NurDock(items, nav.selectedTab, { nav.go(it) }, palette.accent)
                }
            }
        }
    }
}
