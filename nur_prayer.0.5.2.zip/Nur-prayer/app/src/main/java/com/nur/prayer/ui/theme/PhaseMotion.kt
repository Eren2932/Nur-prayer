package com.nur.prayer.ui.theme

import androidx.compose.runtime.Composable

@Composable
fun animatedPhasePalette(target: PhasePalette): PhasePalette = target
