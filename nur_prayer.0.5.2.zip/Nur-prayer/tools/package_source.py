#!/usr/bin/env python3
"""Run every static/data CI check before creating a numeric source ZIP.

This does not run Gradle, build APKs, or certify Android runtime behaviour.
"""
import argparse
from pathlib import Path
import subprocess
import sys
import zipfile
from release_metadata import validate_release_metadata

ROOT = Path(__file__).resolve().parents[1]
CHECKS = (
    'check_compose_actions', 'test_compose_actions', 'kt_sanity', 'kt_symbols',
    'source_audit', 'test_amoled_source', 'test_source_archive', 'test_kt_symbols',
    'verify_cities', 'verify_uz_table', 'test_build_regressions',
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=ROOT.parent / 'dist')
    args = parser.parse_args()
    output = args.output_dir.resolve()
    if output == ROOT or ROOT in output.parents:
        parser.error('Output must be outside the source project')
    version = validate_release_metadata(
        (ROOT / 'app/build.gradle.kts').read_text(),
        (ROOT / 'app/src/main/java/com/nur/prayer/ui/settings/SettingsScreen.kt').read_text())
    for check in CHECKS:
        print(f'\n=== {check} ===', flush=True)
        subprocess.run([sys.executable, str(ROOT / 'tools' / (check + '.py'))],
                       cwd=ROOT, check=True)
    output.mkdir(parents=True, exist_ok=True)
    archive = output / f'nur_prayer.{version}.zip'
    if archive.exists():
        raise SystemExit(f'Refusing to overwrite {archive}; choose a clean output directory')
    excluded = {'.git', '.gradle', '.idea', '__pycache__', 'build', 'dist'}
    entries = []
    for path in sorted(ROOT.rglob('*')):
        relative = path.relative_to(ROOT)
        if any(part in excluded for part in relative.parts):
            continue
        if path.is_symlink():
            raise SystemExit(f'Refusing to package symlink: {relative}')
        if not path.is_file() or path.name == 'local.properties' or path.suffix in ('.pyc', '.zip', '.apk', '.jks', '.keystore'):
            continue
        entries.append((path, relative))
    # Exclusive creation and cleanup prevent publishing a half-written source ZIP.
    try:
        with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
            for path, relative in entries:
                z.write(path, Path('Nur-prayer') / relative)
        with zipfile.ZipFile(archive) as z:
            bad = z.testzip()
            if bad:
                raise RuntimeError(f'ZIP integrity failure: {bad}')
    except Exception:
        archive.unlink(missing_ok=True)
        raise
    print(f'\nPASS: {len(CHECKS)} static/data commands. Created {archive}')
    print('Android compilation, Kotlin unit tests, lint and emulator tests NOT run here.')


if __name__ == '__main__':
    main()
