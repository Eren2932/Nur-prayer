#!/usr/bin/env bash
# Isolated smoke test only. Does not change/build the Android project's Kotlin 2.0.20 toolchain.
set -euo pipefail
TOOLS=${1:?Usage: bash tools/verify_location_jvm.sh /path/to/jvm-tool-jars}
ROOT=$(cd "$(dirname "$0")/.." && pwd)
CP=""
for JAR in kotlin-compiler-embeddable-1.5.31.jar kotlin-stdlib-1.5.31.jar kotlin-reflect-1.5.31.jar kotlin-script-runtime-1.5.31.jar trove4j-1.0.20181211.jar annotations-13.0.jar junit-4.13.2.jar hamcrest-core-1.3.jar; do
    test -f "$TOOLS/$JAR" || { printf 'Missing tool dependency: %s\n' "$JAR" >&2; exit 1; }
    CP="${CP:+$CP:}$TOOLS/$JAR"
done
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT
cd "$ROOT"
printf 'Isolated Kotlin 1.5.31 / JVM smoke test of unmodified new pure source files.\n'
printf 'NOT an Android build, NOT the full project Kotlin 2.0.20 / JUnit suite.\n'
java -cp "$CP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect -jvm-target 1.8 -classpath "$CP" -d "$OUT" \
 app/src/main/java/com/nur/prayer/location/LocationFixPolicy.kt \
 app/src/main/java/com/nur/prayer/location/LocationRequestPolicy.kt \
 app/src/main/java/com/nur/prayer/location/LocationAddress.kt \
 app/src/main/java/com/nur/prayer/ui/NavigationMotion.kt \
 app/src/test/java/com/nur/prayer/LocationFixPolicyTest.kt \
 app/src/test/java/com/nur/prayer/LocationRequestPolicyTest.kt \
 app/src/test/java/com/nur/prayer/LocationAddressTest.kt \
 app/src/test/java/com/nur/prayer/NavigationMotionTest.kt
java -cp "$OUT:$CP" org.junit.runner.JUnitCore \
 com.nur.prayer.LocationFixPolicyTest com.nur.prayer.LocationRequestPolicyTest \
 com.nur.prayer.LocationAddressTest com.nur.prayer.NavigationMotionTest
