#!/usr/bin/env python3
"""Numeric archive selection and guarded extraction for repositories storing source ZIPs."""
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile

PATTERN = re.compile(r"^nur_prayer[._-](\d+(?:\.\d+)*)\.zip$", re.IGNORECASE)

def version(path):
    match = PATTERN.fullmatch(Path(path).name)
    return tuple(map(int, match.group(1).split("."))) if match else None

def latest(paths):
    candidates = [(version(path), Path(path)) for path in paths if version(path) is not None]
    if not candidates:
        raise ValueError("No versioned nur_prayer source ZIP found")
    return max(candidates, key=lambda value: value[0])[1]

def extract(archive, destination):
    destination = Path(destination).resolve()
    with zipfile.ZipFile(archive) as z:
        if sum(i.file_size for i in z.infolist()) > 200 * 1024 * 1024:
            raise ValueError("Archive exceeds 200 MiB uncompressed")
        for info in z.infolist():
            name = PurePosixPath(info.filename)
            if name.is_absolute() or ".." in name.parts or "\\" in info.filename:
                raise ValueError("Unsafe archive path")
            if stat.S_ISLNK(info.external_attr >> 16):
                raise ValueError("Symlinks are not accepted in source archives")
        z.extractall(destination)
    roots = list(destination.rglob("settings.gradle.kts"))
    if len(roots) != 1:
        raise ValueError("Expected exactly one Gradle project")
    return roots[0].parent
