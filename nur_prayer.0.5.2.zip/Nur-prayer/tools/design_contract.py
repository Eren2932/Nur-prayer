"""Source preflight for the 0.5.1 design; not runtime/performance validation."""
import re
from release_metadata import without_comments


def expect(source, pattern, message):
    if not re.search(pattern, source, re.S):
        raise AssertionError(message)


def validate_ambient(sky_source, policy_source):
    sky, policy = map(without_comments, (sky_source, policy_source))
    expect(sky, r'Box\(modifier\.fillMaxSize\(\)\.background\(Ink\)\)',
           'Backdrop: keep opaque Ink substrate, not a full-screen gradient')
    expect(sky, r'val systemAllows\s*=\s*if\s*\(motionEnabled\)\s*rememberAmbientMotionAllowed\(\)\s*else false',
           'Backdrop: user switch must gate the system policy')
    expect(sky, r'val paused\s*=\s*LocalBackdropPaused\.current\.value', 'Backdrop: observe scroll pause')
    expect(sky, r'val animating\s*=\s*systemAllows\s*&&\s*!paused', 'Backdrop: respect scroll pause')
    expect(sky, r'LaunchedEffect\(animating\)\s*\{\s*if\s*\(!animating\)\s*return@LaunchedEffect',
           'Backdrop: cancel/stop the clock when motion is not allowed')
    expect(sky, r'delay\(AmbientSky\.FRAME_INTERVAL_MILLIS\)', 'Backdrop: throttle the clock')
    expect(sky, r'if\s*\(motionEnabled\)\s*\{\s*StarField\(', 'Backdrop: hide stars when user disables backdrop')
    expect(sky, r'val stars\s*=\s*remember\s*\{\s*AmbientSky\.stars\(\)', 'Backdrop: cache the star field')
    for name, maximum in (('STAR_COUNT', 54), ('MAX_ALPHA', 0.34), ('METEOR_ALPHA', 0.55), ('METEOR_LIFE', 1.5)):
        match = re.search(r'const val ' + name + r'\s*=\s*([0-9.]+)[fL]?\b', sky)
        if not match or not 0 < float(match[1]) <= maximum:
            raise AssertionError('Backdrop: invalid ceiling ' + name)
    for name, minimum in (('FRAME_INTERVAL_MILLIS', 50), ('METEOR_PERIOD', 30)):
        match = re.search(r'const val ' + name + r'\s*=\s*([0-9.]+)[fL]?\b', sky)
        if not match or float(match[1]) < minimum:
            raise AssertionError('Backdrop: invalid cadence ' + name)
    expect(policy, r'allowed\s*=\s*owner.lifecycle.currentState.isAtLeast\(Lifecycle.State.RESUMED\)\s*&&\s*!saver\s*&&\s*scale\s*>\s*0f',
           'Backdrop policy: require resumed lifecycle, no saver and enabled OS animation')
    for token in ('isPowerSaveMode', 'Settings.Global.ANIMATOR_DURATION_SCALE',
                  'owner.lifecycle.addObserver(lifecycle)', 'owner.lifecycle.removeObserver(lifecycle)',
                  'context.unregisterReceiver(receiver)', 'unregisterContentObserver(observer)'):
        if token not in policy:
            raise AssertionError('Backdrop policy: missing ' + token)


def validate_compass(source):
    source = without_comments(source)
    expect(source, r'val usable\s*=\s*heading.available\s*&&\s*heading.trustworthy\s*&&\s*heading.heldFlat\s*&&\s*delta.isFinite\(\)',
           'Compass: require a trustworthy, flat, finite heading')
    expect(source, r'if\s*\(usable\)\s*rotationTarget\s*=\s*nearestDialRotation\(',
           'Compass: only track trustworthy headings')
    expect(source, r'rotationZ\s*=\s*if\s*\(usable\)\s*rotation.value\s*else\s*0f',
           'Compass: freeze dial at north with no trustworthy heading')
    expect(source, r'if\s*\(usable\)\s*\{\s*Canvas\(Modifier.fillMaxSize\(\)\)\s*\{[^{}]*(?:Path\(\).apply\s*\{[^{}]*\})[^{}]*drawPath\(path, deviceColor\)',
           'Compass: device pointer must remain inside the usable-heading guard')
    expect(source, r'KaabaIcon\(\s*edge\s*=\s*if\s*\(usable\)\s*markColor\s*else\s*TextTertiary',
           'Compass: keep local Kaaba vector with untrusted-state styling')
    expect(source, r'val aligned\s*=\s*QiblaGuidance.aligned\(delta, heading.available, heading.trustworthy, heading.heldFlat\)',
           'Compass: alignment must come from the trust policy')
    expect(source, r'QiblaGuidance.instruction\(delta, heading.available, heading.trustworthy, heading.heldFlat\)',
           'Compass: instructions must come from the trust policy')
    expect(source, r'if\s*\(aligned\)\s*Mint\s*else\s*TextPrimary',
           'Compass: green lock requires confirmed alignment')
