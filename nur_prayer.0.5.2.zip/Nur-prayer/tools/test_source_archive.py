import tempfile
import unittest
import zipfile
from pathlib import Path
from source_archive import latest, extract

class ArchiveTests(unittest.TestCase):
    def test_numeric_order(self):
        self.assertEqual(latest(["nur_prayer.0.2.9.zip", "nur_prayer.0.2.10.zip"]).name, "nur_prayer.0.2.10.zip")
    def test_new_major_minor(self):
        self.assertEqual(latest(["nur_prayer.0.3.0.zip", "nur_prayer.0.2.99.zip"]).name, "nur_prayer.0.3.0.zip")
    def test_unrelated_files_are_ignored(self):
        self.assertEqual(latest(["backup.zip", "nur_prayer.0.3.0.zip"]).name, "nur_prayer.0.3.0.zip")
    def test_missing_archive_is_explicit(self):
        with self.assertRaises(ValueError): latest(["backup.zip"])
    def test_traversal_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            z = Path(tmp)/"bad.zip"
            with zipfile.ZipFile(z, "w") as f: f.writestr("../escape.txt", "bad")
            with self.assertRaises(ValueError): extract(z, Path(tmp)/"out")
            self.assertFalse((Path(tmp)/"escape.txt").exists())
    def test_normal_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            z = Path(tmp)/"good.zip"
            with zipfile.ZipFile(z, "w") as f: f.writestr("Nur-prayer/settings.gradle.kts", "")
            self.assertEqual(extract(z, Path(tmp)/"out").name, "Nur-prayer")

if __name__ == "__main__": unittest.main()
