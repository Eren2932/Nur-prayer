from pathlib import Path
import re
import unittest
from design_contract import validate_ambient, validate_compass

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT / 'app/src/main/java/com/nur/prayer/ui'

class AmoledSourceTest(unittest.TestCase):
    def test_primary_screens_have_no_decorative_copy(self):
        texts = '\n'.join((UI / path).read_text() for path in (
            'home/HomeScreen.kt', 'qibla/QiblaScreen.kt', 'schedule/ScheduleScreen.kt',
            'settings/SettingsScreen.kt', 'settings/CityPickerScreen.kt'))
        for phrase in ('Ваш Нур', 'Время для главного', 'ПУТЬ ВРЕМЕНИ', 'РИТМ ДНЕЙ',
                       'ЛИЧНОЕ ПРОСТРАНСТВО', 'Где встречаем рассвет?', 'ОДНО НАПРАВЛЕНИЕ'):
            self.assertNotIn(phrase, texts)

    def test_main_screens_do_not_use_panel_wrappers(self):
        for path in ('home/HomeScreen.kt', 'qibla/QiblaScreen.kt', 'schedule/MonthCalendar.kt', 'schedule/ScheduleScreen.kt'):
            self.assertNotIn('AtlasPanel(', (UI / path).read_text())

    def test_all_settings_editors_remain(self):
        text = (UI / 'settings/SettingsScreen.kt').read_text()
        for editor in ('method', 'madhab', 'notify', 'azan', 'highlat', 'rounding', 'offsets', 'about'):
            self.assertRegex(text, r'id\s*=\s*"' + editor + '"')
        self.assertIn('actions.stopAzan()', text)
        self.assertIn('BackHandler(enabled = open != null)', text)

    def test_compass_does_not_draw_untrusted_direction(self):
        text = (UI / 'qibla/QiblaScreen.kt').read_text()
        self.assertIn('heading.available && heading.trustworthy && heading.heldFlat && delta.isFinite()', text)
        self.assertIn('if (usable) {', text)
        self.assertIn('nearestDialRotation', text)
        self.assertIn('QiblaGuidance.aligned', text)
        # The restored instrument intentionally has cardinal labels and a ray.
        # Protect sensor trust instead of banning these approved visual elements.
        validate_compass(text)

    def test_sparse_backdrop_keeps_black_and_respects_motion_policy(self):
        validate_ambient((UI / 'components/NightSky.kt').read_text(),
                         (UI / 'components/MotionPolicy.kt').read_text())

    def test_month_swipe_has_both_bounds_and_latest_callback(self):
        text = (UI / 'schedule/MonthCalendar.kt').read_text()
        self.assertIn('rememberUpdatedState(onMonth)', text)
        self.assertIn('distance < -threshold && month < max', text)
        self.assertIn('distance > threshold && month > min', text)
        self.assertIn('List(42)', text)

    def test_contrast_of_standard_text_surfaces(self):
        text = (UI / 'theme/Color.kt').read_text()
        colors = dict(re.findall(r'val (\w+) = Color\(0xFF([0-9A-F]{6})\)', text))
        def luminance(hex_color):
            rgb = [int(hex_color[i:i + 2], 16) / 255 for i in (0, 2, 4)]
            rgb = [v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in rgb]
            return sum(x * w for x, w in zip(rgb, (0.2126, 0.7152, 0.0722)))
        self.assertEqual(colors['Ink'], '000000')
        for foreground in ('TextPrimary', 'TextSecondary', 'TextTertiary'):
            for surface in ('Ink', 'InkSoft', 'SurfaceRaised'):
                high, low = sorted((luminance(colors[foreground]), luminance(colors[surface])), reverse=True)
                self.assertGreaterEqual((high + 0.05) / (low + 0.05), 4.5, (foreground, surface))

if __name__ == '__main__':
    unittest.main(verbosity=2)
