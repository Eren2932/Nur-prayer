#!/usr/bin/env python3
"""Numerical cross-checks for the 0.3.0 CI failures, using the existing Python port.

These tests DO NOT execute Kotlin or replace :app:testDebugUnitTest. The altitude
extremum uses fresh solar coordinates, independently of the root interpolation.
Run from the project root: python3 tools/test_build_regressions.py
"""
import math
import unittest
from datetime import date

from prayer_port import (
    Coordinates, Params, PrayerTimes, SolarTime, METHODS, ORDER,
    SAHAR, FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA,
    SEVENTH_OF_THE_NIGHT,
)
from verify_tangency import extremum
from verify_roots import altitude_at


class BuildRegressionTest(unittest.TestCase):
    volgograd = Coordinates(48.7071, 44.5169)
    murmansk = Coordinates(68.9585, 33.0827)

    def twilight(self, method, day=date(2026, 6, 14)):
        params = Params(method=method, high_latitude_rule=SEVENTH_OF_THE_NIGHT,
                        convention="ASTRONOMICAL")
        return PrayerTimes(day, self.volgograd, params, 3.0)

    def assert_order(self, times):
        self.assertEqual([SAHAR, FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA], list(times))
        self.assertTrue(all(v is not None for v in times.values()))
        for previous, current in zip(ORDER, ORDER[1:]):
            if (previous, current) == (SAHAR, FAJR):
                self.assertLessEqual(times[previous], times[current])
            else:
                self.assertLess(times[previous], times[current])

    def test_volgograd_minimum_reaches_17_but_not_18_degrees(self):
        day = date(2026, 6, 14)
        solar = SolarTime(day, self.volgograd, 9.0)
        minimum, _ = extremum(day, self.volgograd, solar.transit + 12)
        self.assertGreater(minimum, -18.0)
        self.assertLess(minimum, -17.0)
        self.assertAlmostEqual(-17.99895191, minimum, places=6)
        self.assertTrue(math.isnan(solar.hour_angle(-18.0, True)))
        root = solar.hour_angle(-17.0, True)
        self.assertTrue(math.isfinite(root))
        # A genuine evening crossing, independently evaluated a minute to each side.
        self.assertGreater(altitude_at(day, self.volgograd, root - 1 / 60), -17.0)
        self.assertLess(altitude_at(day, self.volgograd, root + 1 / 60), -17.0)

    def test_karachi_18_degree_fixture_uses_night_fraction(self):
        self.assertEqual(18.0, METHODS["KARACHI"].isha_angle)
        result = self.twilight("KARACHI")
        self.assertEqual("NIGHT_FRACTION", result.isha_source)
        self.assert_order(result.times)

    def test_mwl_17_degree_counterexample_keeps_real_angle(self):
        self.assertEqual(17.0, METHODS["MUSLIM_WORLD_LEAGUE"].isha_angle)
        result = self.twilight("MUSLIM_WORLD_LEAGUE")
        self.assertEqual("ANGLE", result.isha_source)
        self.assert_order(result.times)

    def test_ust_kamenogorsk_17_degree_boundary_is_preserved(self):
        params = Params(method="MUSLIM_WORLD_LEAGUE", convention="ASTRONOMICAL",
                        high_latitude_rule=SEVENTH_OF_THE_NIGHT)
        coords = Coordinates(49.9787, 82.6014)
        result = PrayerTimes(date(2026, 6, 10), coords, params, 5.0)
        self.assertEqual("NIGHT_FRACTION", result.isha_source)
        self.assert_order(result.times)

    def test_ordinary_august_night_keeps_karachi_angle(self):
        result = self.twilight("KARACHI", date(2026, 8, 20))
        self.assertEqual("ANGLE", result.isha_source)
        self.assert_order(result.times)

    def test_murmansk_fajr_equals_dawn_when_the_gap_is_too_early(self):
        result = PrayerTimes(date(2026, 5, 14), self.murmansk, Params(), 3.0)
        self.assertTrue(result.is_publishable)
        self.assertEqual("DAWN_BOUND", result.fajr_source)
        self.assertEqual(result.times[SAHAR], result.times[FAJR])
        self.assert_order(result.times)

    def test_zero_congregational_gap_does_not_invent_an_extra_minute(self):
        result = PrayerTimes(date(2026, 3, 21), Coordinates(55.7558, 37.6173),
                             Params(congregational_fajr_minutes=0), 3.0)
        self.assertEqual(result.times[SAHAR], result.times[FAJR])
        self.assert_order(result.times)

    def test_polar_donor_shape_contains_seven_ordered_markers(self):
        # Numerically cross-check the noon-offset transplant in PrayerEngine. This is
        # still Python, NOT execution of the Kotlin public API or its JUnit tests.
        from datetime import timedelta
        for day in (date(2026, 6, 21), date(2026, 12, 21)):
            direct = PrayerTimes(day, self.murmansk, Params(), 3.0)
            self.assertFalse(direct.is_publishable)
            donor = None
            for offset in range(1, 184):
                for signed in (-offset, offset):
                    candidate = PrayerTimes(day + timedelta(days=signed), self.murmansk, Params(), 3.0)
                    if candidate.is_publishable:
                        donor = candidate
                        break
                if donor is not None:
                    break
            self.assertIsNotNone(donor)
            times = {p: direct.times[DHUHR] + (value - donor.times[DHUHR])
                     for p, value in donor.times.items()}
            self.assertEqual(7, len(times))
            self.assertEqual(5, len([p for p in times if p not in (SAHAR, SUNRISE)]))
            self.assert_order(times)
            self.assertEqual(day, (times[DHUHR] + timedelta(hours=3)).date())


class ReleaseMetadataRegressionTest(unittest.TestCase):
    """Run in the existing CI entry point, including ZIP-only repository builds."""

    @staticmethod
    def validate(version="0.5.2", labels=None, code="20", gradle=None):
        from release_metadata import validate_release_metadata
        if labels is None:
            labels = [version, version]
        if gradle is None:
            gradle = f'versionName = "{version}"\nversionCode = {code}\n'
        settings = "\n".join(f'Text("Нур {label}")' for label in labels)
        return validate_release_metadata(gradle, settings)

    def test_current_project_metadata(self):
        from pathlib import Path
        from release_metadata import validate_release_metadata
        root = Path(__file__).resolve().parents[1]
        validate_release_metadata(
            (root / "app/build.gradle.kts").read_text(),
            (root / "app/src/main/java/com/nur/prayer/ui/settings/SettingsScreen.kt").read_text())

    def test_next_release_needs_no_audit_edit(self):
        for version in ("0.5.1", "0.5.2", "0.5.3", "1.0.0", "12.34.56"):
            with self.subTest(version=version):
                self.assertEqual(version, self.validate(version))

    def test_stale_labels_fail_in_either_position(self):
        for labels in (["0.5.0", "0.5.2"], ["0.5.2", "0.5.0"], ["0.5.0", "0.5.0"]):
            with self.subTest(labels=labels), self.assertRaisesRegex(AssertionError, "mismatch"):
                self.validate(labels=labels)

    def test_missing_labels_fail(self):
        for labels in ([], ["0.5.2"]):
            with self.subTest(labels=labels), self.assertRaisesRegex(AssertionError, "both"):
                self.validate(labels=labels)

    def test_invalid_version_name_fails(self):
        for version in ("", "banana", "0.5", "00.5.2", "0.5.2-beta"):
            with self.subTest(version=version), self.assertRaisesRegex(AssertionError, "versionName"):
                self.validate(version)

    def test_invalid_version_code_fails(self):
        for code in ("0", "-1", "2100000001", "abc"):
            with self.subTest(code=code), self.assertRaisesRegex(AssertionError, "versionCode"):
                self.validate(code=code)

    def test_missing_or_duplicate_declarations_fail(self):
        for gradle in ('versionCode = 20', 'versionName = "0.5.2"',
                       'versionName = "0.5.2"\nversionName = "0.5.2"\nversionCode = 20',
                       'versionName = "0.5.2"\nversionCode = 20\nversionCode = 21'):
            with self.subTest(gradle=gradle), self.assertRaises(AssertionError):
                self.validate(gradle=gradle)

    def test_formatting_and_commented_out_old_values(self):
        gradle = ('// versionName = "0.5.0"\n'
                  '/* versionCode = 1 */\n'
                  '  versionName= "0.5.2" ; // current\n'
                  '  versionCode = 20 // current\n')
        self.assertEqual("0.5.2", self.validate(gradle=gradle))

    def test_commented_ui_labels_are_not_counted(self):
        from release_metadata import validate_release_metadata
        self.assertEqual("0.5.2", validate_release_metadata(
            'versionName = "0.5.2"\nversionCode = 20',
            '// Text("Нур 0.5.0")\nText("Нур 0.5.2")\n'
            '/* Text("Нур 0.5.0") */\nText("Нур 0.5.2")'))


class DesignAuditRegressionTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from pathlib import Path
        cls.root = Path(__file__).resolve().parents[1]
        ui = cls.root / "app/src/main/java/com/nur/prayer/ui"
        cls.sky = (ui / "components/NightSky.kt").read_text()
        cls.policy = (ui / "components/MotionPolicy.kt").read_text()
        cls.compass = (ui / "qibla/QiblaScreen.kt").read_text()

    def test_actual_source_audit_passes(self):
        import subprocess
        import sys
        result = subprocess.run([sys.executable, str(self.root / "tools/source_audit.py")],
                                capture_output=True, text=True, timeout=30)
        self.assertEqual(0, result.returncode, result.stdout + result.stderr)

    def test_current_design_contract(self):
        from design_contract import validate_ambient, validate_compass
        validate_ambient(self.sky, self.policy)
        validate_compass(self.compass)

    def test_backdrop_regressions_are_rejected(self):
        from design_contract import validate_ambient
        for old, new in (("systemAllows && !paused", "systemAllows"),
                         ("if (!animating) return@LaunchedEffect", ""),
                         ("FRAME_INTERVAL_MILLIS = 50L", "FRAME_INTERVAL_MILLIS = 16L"),
                         ("MAX_ALPHA = 0.34f", "MAX_ALPHA = 1f"),
                         ("STAR_COUNT = 54", "STAR_COUNT = 540"),
                         (".background(Ink)", ".background(Color.White)"),
                         ("if (motionEnabled) {", "if (true) {")):
            with self.subTest(change=old):
                self.assertIn(old, self.sky)
                with self.assertRaises(AssertionError):
                    validate_ambient(self.sky.replace(old, new), self.policy)

    def test_system_policy_regressions_are_rejected(self):
        from design_contract import validate_ambient
        for old, new in (("&& !saver", ""), ("&& scale > 0f", ""),
                         ("Lifecycle.State.RESUMED", "Lifecycle.State.STARTED"),
                         ("context.unregisterReceiver(receiver)", "")):
            with self.subTest(change=old):
                self.assertIn(old, self.policy)
                with self.assertRaises(AssertionError):
                    validate_ambient(self.sky, self.policy.replace(old, new))

    def test_compass_regressions_are_rejected(self):
        from design_contract import validate_compass
        for old, new in (("heading.available && heading.trustworthy", "heading.available"),
                         ("rotationZ = if (usable) rotation.value else 0f", "rotationZ = rotation.value"),
                         ("if (usable) {", "if (true) {"),
                         ("if (aligned) Mint else TextPrimary", "Mint"),
                         ("KaabaIcon(", "Text(")):
            with self.subTest(change=old):
                self.assertIn(old, self.compass)
                with self.assertRaises(AssertionError):
                    validate_compass(self.compass.replace(old, new))


if __name__ == "__main__":
    unittest.main(verbosity=2)
