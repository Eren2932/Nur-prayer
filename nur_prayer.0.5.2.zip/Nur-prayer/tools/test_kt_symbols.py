import unittest
from kt_symbols import named_arguments, strip_noise

class SymbolParserTests(unittest.TestCase):
    def test_top_level_names_remain_checked(self):
        self.assertEqual(named_arguments("title = name, incorrect = 4"), ["title", "incorrect"])
    def test_nested_calls_are_not_outer_arguments(self):
        self.assertEqual(named_arguments("label, Modifier.padding(top = 12, bottom = 2)"), [])
    def test_lambda_body_is_not_outer_arguments(self):
        self.assertEqual(named_arguments("data = data, actionsFactory = { AppActions(a = 1, b = 2) }"), ["data", "actionsFactory"])
    def test_named_backtick_tests_are_not_symbols(self):
        self.assertNotIn("Moscow", strip_noise("fun `Moscow Fajr regression`() {}"))

if __name__ == "__main__": unittest.main()
