# QA 0.5.2 — 2026-09-08

## Основа и границы изменений

Получен актуальный снимок публичного репозитория Eren2932/Nur-prayer,
коммит `a431ce019cb9927d7478129e42eff3c8f791684f`.
Последний числовой архив в снимке: `nur_prayer.0.5.1.zip`.
Исходный отказ `AssertionError: Version` воспроизведён без изменения исходников.

Новая версия: 0.5.2, versionCode 20. Все Kotlin-файлы побайтово совпадают
с 0.5.1, кроме двух надписей версии в SettingsScreen (проверено сравнением).
Все 28 файлов защищённого baseline сохранены. Дизайн, ресурсы и расчёты не изменены.

## Выполненные проверки

Перед упаковкой выполнены все 11 команд статического/data-этапа вложенного workflow.
Они также покрывают все 10 команд действующего корневого workflow репозитория:

| Команда | Результат |
|---|---|
| check_compose_actions.py | PASS: 4 Android test source files |
| test_compose_actions.py | PASS: 6 Python tests |
| kt_sanity.py | PASS: 93 Kotlin files |
| kt_symbols.py | PASS: 93 Kotlin files, 392 functions |
| source_audit.py | PASS: 568 верхнеуровневых source invariants; 28 baseline files |
| test_amoled_source.py | PASS: 7 Python tests |
| test_source_archive.py | PASS: 6 Python tests |
| test_kt_symbols.py | PASS: 4 Python tests |
| verify_cities.py | PASS |
| verify_uz_table.py | PASS |
| test_build_regressions.py | PASS: 22 Python tests |

Независимый `python3 -m unittest discover -s tools -p 'test_*.py' -v`:
45 тестов, OK. Это Python-тесты, не Android/Kotlin JUnit.

В регрессиях проверяются рассинхронизация обеих надписей версии, неверные и
дублированные метаданные, будущие номера релиза, комментарии/пробелы,
а также намеренно сломанные ограничители фоновой анимации и доверия компаса.
Отдельно на временной копии проверено, что весь source_audit принимает
согласованную будущую версию 0.5.3 без редактирования аудита.

При намеренной замене интервала фона 50 мс на 16 мс package_source завершается
с ошибкой и не создаёт ZIP. Выбор последнего архива подтверждён: 0.5.2 > 0.5.1.

## Что НЕ проверено

В the Computer нет Gradle и Android SDK. Поэтому НЕ выполнены:
компиляция Kotlin/debug/release/unitTest/androidTest, Kotlin JUnit,
Android lint, сборка APK, инструментальные тесты Android 26/34,
визуальная проверка и измерения производительности/энергопотребления.
Ни Python-аудит, ни его mutation-тесты не заменяют компилятор или устройство.

## Применение

Добавить `nur_prayer.0.5.2.zip` в корень репозитория рядом с 0.5.1 и сделать commit.
Не распаковывать его внутрь старого ZIP. Действующий корневой workflow выберет
новый архив численно и запустит обновлённый аудит и регрессионные тесты.
Изменять workflow для этого исправления не требуется.

После push дождаться полного прохождения `build` и `ui-tests` на Android 26/34.
Только этот результат подтвердит Android-сборку; данный отчёт подтверждает preflight.
