# 0.28.1 — исправление сборки 0.28.0

Поведение приложения не изменилось. Это та же версия «Бумага», только она снова собирается.

## Что сломалось

CI упал на `:app:compileDebugAndroidTestKotlin`, а `compileDebugKotlin`, `compileReleaseKotlin` и
`compileDebugUnitTestKotlin` прошли:

```
ObservatoryUiTest.kt:63:39 No value passed for parameter 'onClick'.
ObservatoryUiTest.kt:63:58 Argument type mismatch: actual type is 'Function0<Unit>', but 'Modifier' was expected.
```

`CalendarTodayChip(atToday, onClick, modifier = Modifier)` вызывался в тесте как `CalendarTodayChip(x) { ... }`.
Хвостовая лямбда в Kotlin всегда идёт в **последний** параметр, а последний тут `modifier`.

## Исправлено

- `ObservatoryUiTest`: колбэк передаётся по имени, `onClick = { ... }`. Сигнатура чипа осталась прежней (как у
  `Button(onClick, modifier)`).
- `DayCard`: убрано условие, которое всегда истинно (`day != null` повторялось после `fast`). Предупреждение
  компилятора `DayCard.kt:123` ушло, логика та же.

## Новая проверка

`tools/check_trailing_lambda.py` находит функции, у которых последний параметр `Modifier`, а перед ним есть колбэк.
Для них вызов вида `Name(...) { ... }` в `main`, `test` и `androidTest` считается ошибкой. Проверка добавлена в CI
(шаг «Static and data checks»), в `tools/package_source.py` и в `source_audit`. На коде 0.28.0 она находит именно
эту ошибку.

## Не проверено

Gradle и устройство: это снова только статические проверки. Kotlin-компилятора у меня нет.
