package com.nur.prayer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.assertHeightIsEqualTo
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeLeft
import androidx.compose.ui.test.swipeRight
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.SheetGrabber
import com.nur.prayer.ui.schedule.CalendarMonthModel
import com.nur.prayer.ui.schedule.CalendarTodayChip
import com.nur.prayer.ui.schedule.MonthCalendar
import com.nur.prayer.ui.schedule.PeriodBar
import com.nur.prayer.ui.schedule.PeriodPager
import com.nur.prayer.ui.schedule.PeriodPages
import com.nur.prayer.ui.schedule.PeriodRange
import com.nur.prayer.ui.schedule.rememberPeriodPager
import com.nur.prayer.ui.theme.NurTheme
import java.time.LocalDate
import java.time.YearMonth
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ObservatoryUiTest {
    @get:Rule val compose = createComposeRule()

    private fun title(month: YearMonth) = "${Format.monthName(month.monthValue)} ${month.year}"

    /**
     * 0.29.0: the arrows are gone, a month is a page of a pager. The harness wires the pieces the way
     * ScheduleScreen does: the same bounds, the same selection rule, the same period bar over the same pages.
     */
    private fun calendar(today: LocalDate, initial: YearMonth = YearMonth.from(today)) {
        compose.setContent {
            NurTheme {
                var month by remember { mutableStateOf(initial) }
                var selected by remember { mutableStateOf(today) }
                val years = PeriodRange.gregorianYears(today)
                val first = YearMonth.of(years.first, 1)
                val count = PeriodPages.monthCount(first, YearMonth.of(years.last, 12))
                val pager = rememberPeriodPager(PeriodPages.monthPage(first, month, count), count) { page ->
                    val target = PeriodPages.monthAt(first, page)
                    if (target != month) {
                        month = target
                        selected = CalendarMonthModel.moveSelection(selected, target)
                    }
                }
                Column(Modifier.width(320.dp)) {
                    PeriodBar(
                        pager = pager,
                        title = { page -> title(PeriodPages.monthAt(first, page)) }, subtitle = { "" },
                        onPick = {}, ink = Color.Black, subInk = Color.Black
                    )
                    Box(Modifier.height(480.dp)) {
                        PeriodPager(pager, Modifier.testTag("calendar-pager")) { page ->
                            val pageMonth = PeriodPages.monthAt(first, page)
                            val pageSelected = if (pageMonth == month) selected else CalendarMonthModel.moveSelection(selected, pageMonth)
                            MonthCalendar(pageMonth, pageSelected, today, 0, onSelect = { selected = it })
                        }
                    }
                    CalendarTodayChip(selected == today, onClick = { month = YearMonth.from(today); selected = today })
                }
            }
        }
    }

    @Test fun fullMonthHasSelectableLastDayOnCompactViewport() {
        calendar(LocalDate.of(2026, 9, 7))
        compose.onNodeWithTag("calendar-day-2026-09-30").assertIsDisplayed().performClick().assertIsSelected()
    }
    @Test fun changingMonthAndReturningTodayWorks() {
        calendar(LocalDate.of(2026, 9, 7))
        compose.onNodeWithTag("calendar-pager").performTouchInput { swipeLeft() }
        compose.onNodeWithTag("calendar-day-2026-10-15").assertIsDisplayed()
        compose.onNodeWithTag("calendar-today").performClick()
        compose.onNodeWithTag("calendar-day-2026-09-07").assertIsSelected()
    }
    @Test fun leapDayCanBeSelected() {
        calendar(LocalDate.of(2028, 2, 1))
        compose.onNodeWithTag("calendar-day-2028-02-29").performClick().assertIsSelected()
    }
    @Test fun adjacentMonthPaddingDoesNotDispatchSelection() {
        calendar(LocalDate.of(2026, 9, 7))
        compose.onNodeWithTag("calendar-day-2026-08-31").assertIsNotEnabled()
        compose.onNodeWithTag("calendar-day-2026-09-07").assertIsSelected()
    }
    // A page turned by the thumb brings its own days, its title above, and can be turned back.
    @Test fun swipingTurnsThePageAndCanBeReversed() {
        calendar(LocalDate.of(2026, 9, 7))
        compose.onNodeWithTag("calendar-pager").performTouchInput { swipeLeft() }
        compose.onNodeWithTag("calendar-day-2026-10-15").assertIsDisplayed()
        compose.onNodeWithText(title(YearMonth.of(2026, 10))).assertIsDisplayed()
        compose.onNodeWithTag("calendar-pager").performTouchInput { swipeRight() }
        compose.onNodeWithTag("calendar-day-2026-09-15").assertIsDisplayed()
        compose.onNodeWithText(title(YearMonth.of(2026, 9))).assertIsDisplayed()
    }
    // The landing page's selection is what it showed while it turned: the same day number, clamped to the month.
    @Test fun theSelectionFollowsThePageThatSettled() {
        calendar(LocalDate.of(2026, 1, 31))
        compose.onNodeWithTag("calendar-pager").performTouchInput { swipeLeft() }
        compose.onNodeWithTag("calendar-day-2026-02-28").assertIsSelected()
    }
    // 0.19.0: the month wheel offers ±10 years, and the swipe goes exactly as far.
    @Test fun swipeCannotGoBeyondUpperBound() {
        calendar(LocalDate.of(2026, 9, 7), YearMonth.of(2036, 12))
        compose.onNodeWithTag("calendar-pager").performTouchInput { swipeLeft() }
        compose.onNodeWithTag("calendar-day-2036-12-15").assertIsDisplayed()
        compose.onNodeWithText(title(YearMonth.of(2036, 12))).assertIsDisplayed()
    }

    // 0.29.0: the grabber of every sheet is a lane of its own above the sheet, not a line inside it.
    @Test fun sheetGrabberStandsInItsOwnLane() {
        compose.setContent { NurTheme { SheetGrabber() } }
        compose.onNodeWithTag("sheet-grabber").assertIsDisplayed().assertHeightIsEqualTo(36.dp)
    }
}
