package com.nur.prayer

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.IslamicDay
import com.nur.prayer.ui.schedule.TableItem
import com.nur.prayer.ui.schedule.daylightDelta
import com.nur.prayer.ui.schedule.fastRange
import com.nur.prayer.ui.schedule.tableItems
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

/** 0.28.0: the arithmetic behind the day card (the fast, the daylight) and the event rows of the table. */
class DayCardTest {
    private val zone = ZoneId.of("Europe/Moscow")
    private val date = LocalDate.of(2027, 2, 12)

    private fun at(h: Int, m: Int, s: Int = 0, on: LocalDate = date) = ZonedDateTime.of(on, java.time.LocalTime.of(h, m, s), zone)

    private fun day(sahar: ZonedDateTime?, fajr: ZonedDateTime?, sunrise: ZonedDateTime?, maghrib: ZonedDateTime?, on: LocalDate = date) =
        PrayerDay(on, listOfNotNull(
            sahar?.let { Prayer.SAHAR to it }, fajr?.let { Prayer.FAJR to it },
            sunrise?.let { Prayer.SUNRISE to it }, maghrib?.let { Prayer.MAGHRIB to it }
        ).toMap())

    private fun occurrence(day: IslamicDay, start: LocalDate, end: LocalDate) = DayOccurrence(day, 1448, start, end)

    @Test fun theFastRunsFromSuhurToMaghribWhereThePlaceHasSuhur() {
        val d = day(at(5, 11), at(5, 45), at(7, 15), at(16, 39))
        val range = fastRange(d, Prayer.entries)!!
        assertEquals(at(5, 11), range.first)
        assertEquals(at(16, 39), range.second)
    }

    @Test fun theFastRunsFromFajrWhereThereIsNoSeparateSuhur() {
        val d = day(at(5, 11), at(5, 45), at(7, 15), at(16, 39))
        val range = fastRange(d, Prayer.entries.filter { it != Prayer.SAHAR })!!
        assertEquals(at(5, 45), range.first)
    }

    @Test fun noFastRangeWithoutMaghribOrWhenItIsBeforeTheStart() {
        assertNull(fastRange(day(at(5, 11), null, null, null), Prayer.entries))
        assertNull(fastRange(day(at(17, 0), null, null, at(16, 39)), Prayer.entries))
    }

    @Test fun daylightGrowthIsRoundedToWholeMinutes() {
        val before = day(null, null, at(7, 18, 0), at(16, 38, 20), date.minusDays(1))
        val today = day(null, null, at(7, 15, 0), at(16, 39, 0))   // +3 min 40 s
        assertEquals(4L, daylightDelta(today, before))
        assertEquals(-4L, daylightDelta(before, today))
        assertEquals(0L, daylightDelta(today, today))
    }

    @Test fun anEventStandsRightBeforeItsFirstDay() {
        val days = (1..28).map { LocalDate.of(2027, 2, it) }
        val ramadan = occurrence(IslamicDay.RAMADAN, LocalDate.of(2027, 2, 8), LocalDate.of(2027, 3, 8))
        val items = tableItems(days, listOf(ramadan))
        assertEquals(29, items.size)
        assertEquals(TableItem.Day(6), items[6])
        assertEquals(TableItem.Event(ramadan), items[7])
        assertEquals(TableItem.Day(7), items[8])
    }

    @Test fun anEventBegunInAnEarlierMonthOpensTheList() {
        val days = (1..31).map { LocalDate.of(2027, 3, it) }
        val ramadan = occurrence(IslamicDay.RAMADAN, LocalDate.of(2027, 2, 8), LocalDate.of(2027, 3, 8))
        val items = tableItems(days, listOf(ramadan))
        assertEquals(TableItem.Event(ramadan), items.first())
        assertEquals(TableItem.Day(0), items[1])
        assertEquals(32, items.size)
    }

    @Test fun noDaysNoItems() {
        assertTrue(tableItems(emptyList(), emptyList()).isEmpty())
    }
}
