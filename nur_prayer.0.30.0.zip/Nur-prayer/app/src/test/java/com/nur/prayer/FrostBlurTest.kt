package com.nur.prayer

import com.nur.prayer.ui.wallpaper.FrostBlur
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.27.0: the blur under the matte glass. */
class FrostBlurTest {
    @Test fun flatColourStaysFlatAndOpaque() {
        val c = 0xFF223344.toInt()
        val px = IntArray(12 * 7) { c }
        FrostBlur.blur(px, 12, 7, 3)
        assertArrayEquals(IntArray(12 * 7) { c }, px)
    }

    @Test fun aBrightDotSpreadsWithoutDarkeningTheEdges() {
        val w = 9; val h = 9
        val px = IntArray(w * h) { 0xFF000000.toInt() }
        px[4 * w + 4] = 0xFFFFFFFF.toInt()
        FrostBlur.blur(px, w, h, 1)
        // The dot is now a soft 3 × 3 square: 255 / 9 / ... each channel the same, alpha untouched.
        val centre = px[4 * w + 4]
        assertEquals(0xFF, (centre ushr 24) and 0xFF)
        assertTrue(((centre shr 16) and 0xFF) in 25..30)
        assertEquals((px[3 * w + 3] shr 16) and 0xFF, (centre shr 16) and 0xFF)
        assertEquals(0, (px[0] shr 16) and 0xFF)
        px.forEach { assertEquals(0xFF, (it ushr 24) and 0xFF) }
    }

    @Test fun degenerateInputIsLeftAlone() {
        val px = intArrayOf(1, 2, 3)
        FrostBlur.blur(px, 3, 1, 0)
        FrostBlur.blur(px, 5, 5, 2)
        assertArrayEquals(intArrayOf(1, 2, 3), px)
    }
}
