package com.nur.prayer

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.core.astro.PrayerWindow
import com.nur.prayer.ui.home.FitMath
import com.nur.prayer.ui.home.HomeMath
import com.nur.prayer.ui.home.RowState
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

/** 0.30.0: the arithmetic behind both home screens (cards and the big word with its timeline). */
class HomeMathTest {
    private val zone = ZoneId.of("Europe/Moscow")
    private val date = LocalDate.of(2026, 10, 31)
    private fun at(h: Int, m: Int, s: Int = 0, d: LocalDate = date) = ZonedDateTime.of(d.atTime(h, m, s), zone)

    private val six = listOf(Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)
    private fun day(d: LocalDate) = PrayerDay(d, mapOf(
        Prayer.SAHAR to at(5, 28, d = d),
        Prayer.FAJR to at(5, 28, d = d),
        Prayer.SUNRISE to at(7, 28, d = d),
        Prayer.DHUHR to at(12, 19, d = d),
        Prayer.ASR to at(14, 22, d = d),
        Prayer.MAGHRIB to at(16, 57, d = d),
        Prayer.ISHA to at(18, 36, d = d)
    ))
    private val today = day(date)
    private fun states(window: PrayerWindow) = six.map { HomeMath.rowState(it, window, today, fajrEqualsDawn = true) }
    private val sixTimes: List<ZonedDateTime?> = six.map { today.times[it] }

    // ------------------------------------------------------------------ states of the cards

    @Test fun middleOfTheDayMarksPastCurrentNextAndUpcoming() {
        val w = PrayerWindow(Prayer.DHUHR, at(12, 19), Prayer.ASR, at(14, 22))
        assertEquals(
            listOf(RowState.PAST, RowState.PAST, RowState.CURRENT, RowState.NEXT, RowState.UPCOMING, RowState.UPCOMING),
            states(w)
        )
    }

    @Test fun afterIshaTheNextOneIsTomorrowsFajrAndEverythingElseHasPassed() {
        val w = PrayerWindow(Prayer.ISHA, at(18, 36), Prayer.FAJR, at(5, 28, d = date.plusDays(1)))
        assertEquals(
            listOf(RowState.NEXT, RowState.PAST, RowState.PAST, RowState.PAST, RowState.PAST, RowState.CURRENT),
            states(w)
        )
    }

    @Test fun beforeFajrNothingHasPassedYet() {
        val w = PrayerWindow(Prayer.ISHA, at(18, 36, d = date.minusDays(1)), Prayer.FAJR, at(5, 28))
        val s = states(w)
        assertEquals(RowState.NEXT, s[0])
        assertTrue(s.drop(1).none { it == RowState.PAST })
    }

    @Test fun hiddenSuhoorLandsOnFajr() {
        val w = PrayerWindow(Prayer.ISHA, at(18, 36), Prayer.SAHAR, at(5, 28, d = date.plusDays(1)))
        assertEquals(RowState.NEXT, HomeMath.rowState(Prayer.FAJR, w, today, fajrEqualsDawn = true))
    }

    @Test fun aCardCountsToItsOwnMomentExceptTheNextOne() {
        val w = PrayerWindow(Prayer.ISHA, at(18, 36), Prayer.FAJR, at(5, 28, d = date.plusDays(1)))
        assertEquals(at(5, 28, d = date.plusDays(1)), HomeMath.startOf(Prayer.FAJR, RowState.NEXT, w, today))
        assertEquals(at(12, 19), HomeMath.startOf(Prayer.DHUHR, RowState.PAST, w, today))
    }

    // ------------------------------------------------------------------ «через 2 ч 01 мин»

    @Test fun untilWritesHoursWithTwoDigitMinutes() {
        assertEquals("через 2 ч 01 мин", HomeMath.until(121))
        assertEquals("через 1 ч 00 мин", HomeMath.until(60))
        assertEquals("через 4 ч 27 мин", HomeMath.until(4 * 60 + 27))
        assertEquals("через 5 мин", HomeMath.until(5))
        assertEquals("меньше минуты", HomeMath.until(0))
        assertEquals("меньше минуты", HomeMath.until(-30))
    }

    // ------------------------------------------------------------------ the timeline

    @Test fun axisIsProportionalToTheClockAndSpansZeroToOne() {
        val a = HomeMath.axis(sixTimes)
        assertEquals(6, a.size)
        assertEquals(0f, a.first(), 0f)
        assertEquals(1f, a.last(), 0f)
        val span = (18 * 60 + 36 - (5 * 60 + 28)).toFloat()
        assertEquals((7 * 60 + 28 - (5 * 60 + 28)) / span, a[1], 1e-5f)
        assertEquals((12 * 60 + 19 - (5 * 60 + 28)) / span, a[2], 1e-5f)
    }

    @Test fun aMissingOrDisorderedTimeFallsBackToEvenSteps() {
        val even = floatArrayOf(0f, 0.2f, 0.4f, 0.6f, 0.8f, 1f)
        assertArrayEquals(even, HomeMath.axis(sixTimes.toMutableList().also { it[3] = null }), 1e-6f)
        assertArrayEquals(even, HomeMath.axis(sixTimes.reversed()), 1e-6f)
        assertEquals(0, HomeMath.axis(emptyList()).size)
        assertArrayEquals(floatArrayOf(0f), HomeMath.axis(listOf(sixTimes[0])), 0f)
    }

    @Test fun nowStaysInsideTheAxisAndInterpolatesBetweenTimes() {
        val axis = HomeMath.axis(sixTimes)
        fun f(t: ZonedDateTime) = HomeMath.nowFraction(sixTimes, axis, t.toEpochSecond())
        assertEquals(0f, f(at(3, 0)), 0f)
        assertEquals(1f, f(at(23, 0)), 0f)
        assertEquals(axis[2], f(at(12, 19)), 1e-6f)
        // 12:19 → 14:22 is 123 minutes: 13:20:30 is exactly halfway.
        assertEquals((axis[2] + axis[3]) / 2f, f(at(13, 20, 30)), 1e-5f)
        // never goes backwards
        var last = -1f
        for (minute in 0 until 24 * 60 step 7) {
            val v = f(at(minute / 60, minute % 60))
            assertTrue(v >= last)
            last = v
        }
    }

    @Test fun nowWithAMissingTimeStepsByTheTimesPassed() {
        val times = sixTimes.toMutableList().also { it[3] = null }
        val axis = HomeMath.axis(times) // even steps
        assertEquals(axis[2], HomeMath.nowFraction(times, axis, at(13, 0).toEpochSecond()), 0f)
        assertEquals(axis[0], HomeMath.nowFraction(times, axis, at(6, 0).toEpochSecond()), 0f)
    }

    // ------------------------------------------------------------------ labels under the nodes

    private val gap = 6f

    @Test fun labelsThatDoNotTouchStayExactlyUnderTheirNodes() {
        val centers = floatArrayOf(50f, 200f, 350f)
        val widths = floatArrayOf(40f, 40f, 40f)
        val lefts = HomeMath.spreadLabels(centers, widths, gap, 0f, 400f)
        assertArrayEquals(floatArrayOf(30f, 180f, 330f), lefts, 1e-4f)
    }

    @Test fun aCrowdSpreadsEvenlyAroundWhereItWanted() {
        val centers = floatArrayOf(200f, 210f, 220f)
        val widths = floatArrayOf(40f, 40f, 40f)
        val lefts = HomeMath.spreadLabels(centers, widths, gap, 0f, 400f)
        assertArrayEquals(floatArrayOf(144f, 190f, 236f), lefts, 1e-3f)
        for (i in 1 until lefts.size) assertTrue(lefts[i] - (lefts[i - 1] + widths[i - 1]) >= gap - 1e-3f)
    }

    @Test fun labelsNeverLeaveTheScreen() {
        val widths = floatArrayOf(40f, 40f)
        val right = HomeMath.spreadLabels(floatArrayOf(395f, 398f), widths, gap, 8f, 392f)
        assertEquals(392f, right[1] + widths[1], 1e-3f)
        assertTrue(right[1] - (right[0] + widths[0]) >= gap - 1e-3f)
        val left = HomeMath.spreadLabels(floatArrayOf(2f, 5f), widths, gap, 8f, 392f)
        assertEquals(8f, left[0], 1e-3f)
    }

    @Test fun spreadHandlesEmptyAndMismatchedInput() {
        assertEquals(0, HomeMath.spreadLabels(FloatArray(0), FloatArray(0), gap, 0f, 100f).size)
        assertEquals(0, HomeMath.spreadLabels(floatArrayOf(1f), FloatArray(0), gap, 0f, 100f).size)
    }

    @Test fun monotoneIsTheLeastSquaresNonDecreasingFit() {
        assertArrayEquals(floatArrayOf(2f, 2f, 2f), HomeMath.monotone(floatArrayOf(3f, 1f, 2f)), 1e-6f)
        assertArrayEquals(floatArrayOf(1f, 2f, 3f), HomeMath.monotone(floatArrayOf(1f, 2f, 3f)), 1e-6f)
    }

    // ------------------------------------------------------------------ fitting the block into the room

    @Test fun aBlockThatFitsIsNotScaledAndOneThatDoesNotShrinksDownToTheFloor() {
        assertEquals(1f, FitMath.fitScale(100, 200), 0f)
        assertEquals(1f, FitMath.fitScale(100, 100), 0f)
        assertEquals(0.9f, FitMath.fitScale(100, 90), 1e-6f)
        assertEquals(FitMath.MIN_SCALE, FitMath.fitScale(100, 50), 0f)
        assertEquals(1f, FitMath.fitScale(0, 50), 0f)
    }

    @Test fun freeHeightIsSplitByTheMeasuredWeights() {
        assertEquals(130f / 207f, FitMath.topShare(130f, 77f), 1e-6f)
        assertEquals(0.5f, FitMath.topShare(0f, 0f), 0f)
    }
}
