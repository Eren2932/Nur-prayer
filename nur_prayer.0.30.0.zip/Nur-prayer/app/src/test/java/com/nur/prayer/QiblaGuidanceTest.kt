package com.nur.prayer

import com.nur.prayer.ui.qibla.QiblaGuidance
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QiblaGuidanceTest {
    @Test fun alignmentNeedsEverySafetyCondition() {
        assertTrue(QiblaGuidance.aligned(2.5f, true, true))
        assertTrue(QiblaGuidance.aligned(-2.5f, true, true))
        assertFalse(QiblaGuidance.aligned(2.51f, true, true))
        assertFalse(QiblaGuidance.aligned(0f, false, true))
        assertFalse(QiblaGuidance.aligned(0f, true, false))
        assertFalse(QiblaGuidance.aligned(Float.NaN, true, true))
    }
    /** 0.23.0: entered within 2.5°, kept until 4.5° — tremor at the edge does not blink it. */
    @Test fun alignmentHasHysteresis() {
        assertFalse(QiblaGuidance.aligned(3.5f, true, true, wasAligned = false))
        assertTrue(QiblaGuidance.aligned(3.5f, true, true, wasAligned = true))
        assertTrue(QiblaGuidance.aligned(-4.5f, true, true, wasAligned = true))
        assertFalse(QiblaGuidance.aligned(4.51f, true, true, wasAligned = true))
        assertFalse(QiblaGuidance.aligned(1f, true, false, wasAligned = true))
    }
    @Test fun unreliableReadingNeverGivesTurnInstructions() {
        assertEquals("Компас недоступен", QiblaGuidance.instruction(30f, false, false, false))
        assertEquals("Проверьте калибровку и помехи", QiblaGuidance.instruction(30f, true, false, false))
        assertEquals("Проверьте калибровку и помехи", QiblaGuidance.instruction(Float.NaN, true, true, true))
    }
    /** 0.23.0: the hold does not matter any more — no "lay the phone flat" in any state. */
    @Test fun holdIsNeverAnInstruction() {
        for (delta in listOf(-120f, -3f, 0f, 3f, 120f)) for (usable in listOf(true, false)) for (trust in listOf(true, false)) {
            assertFalse(QiblaGuidance.instruction(delta, true, usable, trust).contains("горизонтально"))
        }
    }
    @Test fun directionAndAlignmentAreExplicit() {
        assertEquals("Поверните вправо на 30°", QiblaGuidance.instruction(30f, true, true, false))
        assertEquals("Поверните влево на 30°", QiblaGuidance.instruction(-30f, true, true, true))
        assertEquals("Направление на Каабу", QiblaGuidance.instruction(0f, true, true, true))
        assertEquals("Почти на Каабу — откалибруйте компас", QiblaGuidance.instruction(0f, true, true, false))
    }
    @Test fun roundedNorthIsZeroNot360() {
        assertEquals("0°", QiblaGuidance.degrees(359.8f))
        assertEquals("0°", QiblaGuidance.degrees(-0.2f))
        assertEquals("90°", QiblaGuidance.degrees(450f))
        assertEquals("—", QiblaGuidance.degrees(Float.POSITIVE_INFINITY))
    }

    /** 0.27.1: «192°  юго-юго-запад», the line under the dial in the mock. */
    @Test fun windRoseHasSixteenSectorsCentredOnTheWinds() {
        assertEquals(0, QiblaGuidance.windIndex(0f))
        assertEquals(0, QiblaGuidance.windIndex(359.9f))
        assertEquals(0, QiblaGuidance.windIndex(11.2f))
        assertEquals(1, QiblaGuidance.windIndex(11.3f))
        assertEquals(4, QiblaGuidance.windIndex(90f))
        assertEquals(8, QiblaGuidance.windIndex(180f))
        assertEquals(8, QiblaGuidance.windIndex(191.2f))
        assertEquals(9, QiblaGuidance.windIndex(192f))
        assertEquals(12, QiblaGuidance.windIndex(270f))
        assertEquals(15, QiblaGuidance.windIndex(348.7f))
        assertEquals(0, QiblaGuidance.windIndex(348.8f + 22.5f / 2f))
        assertEquals(0, QiblaGuidance.windIndex(Float.NaN))
        assertEquals("юго-юго-запад", QiblaGuidance.windName(192f))
        assertEquals("север", QiblaGuidance.windName(-1f))
    }
}
