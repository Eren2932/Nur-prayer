package com.nur.prayer.ui.schedule

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.SheetGrabber
import com.nur.prayer.ui.components.rememberSheetDrag
import com.nur.prayer.ui.components.sheetDrag
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.ArabicFont
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate

/*
 * 0.19.0 — what a day is. Opens from the grid, the table, the year view and the home chip.
 * Order of reading: kind → name (and the Arabic) → when exactly, how long until → why it matters
 * → what to do → where it is written.
 *
 * 0.28.0 — a light sheet of paper, like the calendar under it: dark ink on cream, the kind of the day
 * only in its chip, its Arabic name and the date plate (a feast reads gold, a blessed night blue).
 */

/** What the sheet shows: one occurrence, or the note on the four sacred months. */
sealed interface SheetTopic {
    data class Day(val occurrence: DayOccurrence) : SheetTopic
    data object Sacred : SheetTopic
}

@Composable
internal fun DaySheet(
    topic: SheetTopic?,
    today: LocalDate,
    hijriOffset: Int,
    onDismiss: () -> Unit
) {
    // The last topic stays composed while the sheet slides away.
    var shown by remember { mutableStateOf(topic) }
    if (topic != null) shown = topic
    BackHandler(enabled = topic != null) { onDismiss() }
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(topic != null, enter = fadeIn(tween(220)), exit = fadeOut(tween(180))) {
            Box(
                Modifier.fillMaxSize().background(Color(0x66000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
            )
        }
        AnimatedVisibility(
            topic != null, modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.86f, stiffness = 380f)) { it } + fadeIn(tween(120)),
            exit = slideOutVertically(tween(220)) { it } + fadeOut(tween(200))
        ) {
            shown?.let { SheetBody(it, today, hijriOffset, onDismiss) }
        }
    }
}

@Composable
private fun SheetBody(topic: SheetTopic, today: LocalDate, hijriOffset: Int, onDismiss: () -> Unit) {
    val ui = uiScale()
    val drag = rememberSheetDrag(onDismiss)
    LaunchedEffect(topic) { drag.reset() }
    val kind = if (topic is SheetTopic.Day) topic.occurrence.kind else DayKind.NIGHT
    val tone = Paper.tone(kind)
    val text = Paper.toneText(kind)
    // The grabber floats above the sheet and is the first row of the same column: whatever moves the sheet
    // (the slide, the pull, the fade) moves it, and it keeps its place relative to the edge.
    Column(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight(SHEET_HEIGHT)
            .graphicsLayer { translationY = drag.offsetPx }
    ) {
        SheetGrabber(Modifier.sheetDrag(drag))
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Paper.Sheet)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                .testTag("day-sheet")
        ) {
            Row(
                Modifier.fillMaxWidth()
                    .sheetDrag(drag)
                    .padding(start = ui.s(20f), end = ui.s(14f), top = 16.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier.clip(CircleShape).background(tone.copy(alpha = 0.14f)).padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(tone))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (topic is SheetTopic.Day) DayTone.label(topic.occurrence.kind) else tr("Четыре месяца"),
                            color = text, fontSize = ui.t(13.5f), fontWeight = FontWeight.Bold, maxLines = 1
                        )
                    }
                }
                val close = tr("Закрыть")
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Paper.Ink.copy(alpha = 0.07f))
                        .semantics { contentDescription = close }
                        .pressClick(role = Role.Button, onClick = onDismiss),
                    contentAlignment = Alignment.Center
                ) { Glyph(GlyphKind.CLOSE, Paper.Ink2, Modifier.size(14.dp)) }
            }
            Column(
                Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                    .padding(horizontal = ui.s(20f)).navigationBarsPadding().padding(bottom = 28.dp)
            ) {
                when (topic) {
                    is SheetTopic.Day -> DayContent(topic.occurrence, today, hijriOffset, tone, text)
                    SheetTopic.Sacred -> SacredContent(tone, text)
                }
            }
        }
    }
}

/** The grabber row and the sheet under it, together: the sheet itself is this less the row. */
private const val SHEET_HEIGHT = 0.88f

/** A small heading of a block of the sheet: bold, in the ink, not a grey capital line. */
@Composable
private fun BlockTitle(text: String, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Text(text, color = Paper.Ink, fontSize = ui.t(18f), fontWeight = FontWeight.Bold, modifier = modifier.semantics { heading() })
}

@Composable
private fun DayContent(o: DayOccurrence, today: LocalDate, hijriOffset: Int, tone: Color, text: Color) {
    val ui = uiScale()
    Text(
        IslamicDayText.title(o.day), color = Paper.Ink, fontSize = ui.t(26f), fontWeight = FontWeight.Bold,
        lineHeight = ui.t(31f), modifier = Modifier.padding(top = 8.dp).semantics { heading() }
    )
    Text(
        IslamicDayText.arabic(o.day), color = text, fontSize = ui.t(24f),
        style = TextStyle(textDirection = TextDirection.Rtl), modifier = Modifier.padding(top = 4.dp)
    )
    Spacer(Modifier.height(16.dp))
    DateCard(o, today, hijriOffset, tone, text)
    Spacer(Modifier.height(18.dp))
    IslamicDayText.paragraphs(o.day).forEach { p ->
        Text(p, color = Paper.Ink.copy(alpha = 0.88f), fontSize = ui.t(16f), lineHeight = ui.t(25f), modifier = Modifier.padding(bottom = 12.dp))
    }
    val deeds = IslamicDayText.deeds(o.day)
    if (deeds.isNotEmpty()) {
        BlockTitle(tr("Что делать"), Modifier.padding(top = 10.dp, bottom = 6.dp))
        deeds.forEach { d ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(tone))
                Spacer(Modifier.width(14.dp))
                Text(d, color = Paper.Ink2, fontSize = ui.t(16f), lineHeight = ui.t(23f))
            }
        }
    }
    BlockTitle(tr("Источники"), Modifier.padding(top = 20.dp, bottom = 6.dp))
    Text(IslamicDayText.sources(o.day).joinToString(" · "), color = Paper.Ink2, fontSize = ui.t(13f), lineHeight = ui.t(19f))
    Text(
        IslamicDayText.datesNote(hijriOffset), color = Paper.Ink3, fontSize = ui.t(12f), lineHeight = ui.t(18f),
        modifier = Modifier.padding(top = 14.dp)
    )
}

/** The badge of the reference app («9 МАР»), with the date, the hijri date and the countdown. */
@Composable
private fun DateCard(o: DayOccurrence, today: LocalDate, hijriOffset: Int, tone: Color, text: Color) {
    val ui = uiScale()
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(tone.copy(alpha = 0.10f)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            Modifier.size(64.dp).clip(RoundedCornerShape(18.dp)).background(tone.copy(alpha = 0.20f)),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Text(o.start.dayOfMonth.toString(), color = Paper.Ink, fontSize = ui.t(26f), fontWeight = FontWeight.Bold, lineHeight = ui.t(28f))
            Text(Format.monthShort(o.start).uppercase(), color = text, fontSize = ui.t(12f), fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(DayWhen.span(o), color = Paper.Ink, fontSize = ui.t(16f), fontWeight = FontWeight.Bold)
            Text(
                HijriCalendar.format(o.start, hijriOffset), color = Paper.Ink2, fontSize = ui.t(13.5f),
                modifier = Modifier.padding(top = 2.dp)
            )
            Text(DayWhen.countdown(o, today), color = text, fontSize = ui.t(14f), fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun SacredContent(tone: Color, text: Color) {
    val ui = uiScale()
    Text(
        IslamicDayText.sacredTitle(), color = Paper.Ink, fontSize = ui.t(26f), fontWeight = FontWeight.Bold,
        lineHeight = ui.t(31f), modifier = Modifier.padding(top = 8.dp).semantics { heading() }
    )
    Text(
        "الأَشْهُر الحُرُم", color = text, fontSize = ui.t(24f),
        style = TextStyle(textDirection = TextDirection.Rtl), modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(1, 7, 11, 12).forEach { m ->
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(tone.copy(alpha = 0.12f)).padding(vertical = 10.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(IslamicDays.arabicMonth(m), color = Paper.Ink, fontSize = ui.t(14f), fontFamily = ArabicFont.family, textAlign = TextAlign.Center, maxLines = 1)
                Text(HijriCalendar.monthName(m), color = Paper.Ink2, fontSize = ui.t(11f), textAlign = TextAlign.Center, maxLines = 2)
            }
        }
    }
    Spacer(Modifier.height(18.dp))
    IslamicDayText.sacredParagraphs().forEach { p ->
        Text(p, color = Paper.Ink.copy(alpha = 0.88f), fontSize = ui.t(16f), lineHeight = ui.t(25f), modifier = Modifier.padding(bottom = 12.dp))
    }
}

/** Sentences about "when", shared by the sheet, the month list and the home chip. */
object DayWhen {
    /** "10 февраля — 11 марта · 30 дн.", "ночь на 6 марта", "25 июня, четверг". */
    fun span(o: DayOccurrence): String = when {
        o.kind == DayKind.NIGHT -> tr("Ночь на {0} — после магриба {1}", Format.dayMonth(o.start), Format.dayMonth(o.start.minusDays(1)))
        o.days > 1 -> tr("{0} — {1} · {2} дн.", Format.dayMonth(o.start), Format.dayMonth(o.end), o.days)
        else -> "${Format.dayMonth(o.start)}, ${Format.weekday(o.start)}"
    }

    fun countdown(o: DayOccurrence, today: LocalDate): String {
        val until = IslamicDays.daysBetween(today, o.start)
        return when {
            o.contains(today) && o.days > 1 -> tr("Идёт: день {0} из {1}", IslamicDays.daysBetween(o.start, today) + 1, o.days)
            o.contains(today) -> tr("Сегодня")
            o.kind == DayKind.NIGHT && until == 1L -> tr("Сегодня вечером")
            until == 1L -> tr("Завтра")
            until > 1 -> tr("Через {0} дн.", until)
            else -> tr("Прошло: {0} дн. назад", -IslamicDays.daysBetween(today, o.end))
        }
    }
}
