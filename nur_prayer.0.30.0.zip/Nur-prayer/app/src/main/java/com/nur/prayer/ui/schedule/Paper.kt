package com.nur.prayer.ui.schedule

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.DayKind

/**
 * 0.28.0 — the calendar's light "paper" palette. Every card of the calendar (table, grid, day, year tiles,
 * sheet) is a near-white sheet with dark ink, so the numbers read at a glance on any picture; the dark
 * island and capsule stay as they are. Only the hues of [DayTone] change: darker, to hold 4.5:1 on white.
 */
internal object Paper {
    val Ink = Color(0xFF1D2A24)
    val Ink2 = Color(0xFF52605A)
    val Ink3 = Color(0xFF86928B)
    val Accent = Color(0xFF17775F)
    val Gain = Color(0xFF1F8A4C)
    val Gold = Color(0xFFEFB445)
    val OnGold = Color(0xFF2B1D05)
    val Card = Color(0xE6FFFFFF)
    val Edge = Color(0x1F463714)
    val Line = Color(0x161D2A24)
    val Sheet = Color(0xFFFCFAF4)

    /** Fill / dot hue of a kind of day. */
    fun tone(kind: DayKind): Color = when (kind) {
        DayKind.FEAST -> Color(0xFFC47F00)
        DayKind.NIGHT -> Color(0xFF4F6AB0)
        DayKind.FAST -> Color(0xFF2F8F5B)
        DayKind.MEMORIAL -> Color(0xFFC0446B)
        DayKind.SEASON -> Color(0xFF127F8E)
    }

    /** The same hue, darkened for small text on its own tint. */
    fun toneText(kind: DayKind): Color = when (kind) {
        DayKind.FEAST -> Color(0xFF8A5700)
        DayKind.NIGHT -> Color(0xFF3A5391)
        DayKind.FAST -> Color(0xFF1F6B42)
        DayKind.MEMORIAL -> Color(0xFF9A2B50)
        DayKind.SEASON -> Color(0xFF0C6270)
    }
}

/** A white paper card: one translucent fill and a warm hairline. No blur and no shadow, so it stays cheap in lists. */
internal fun Modifier.paperCard(radius: Dp = 20.dp, fill: Color = Paper.Card): Modifier {
    val shape = RoundedCornerShape(radius)
    return this.clip(shape).background(fill, shape).border(0.6.dp, Paper.Edge, shape)
}
