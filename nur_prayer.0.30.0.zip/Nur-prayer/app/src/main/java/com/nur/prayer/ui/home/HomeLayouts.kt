package com.nur.prayer.ui.home

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.layout.FirstBaseline
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Where one child of a [MarkedStack] goes: [y] from the top of the stack to its first baseline
 * (a text) or to its top edge (anything else).
 */
internal class Mark(val y: Dp, val byBaseline: Boolean = false)

/** A text whose first baseline sits [y] from the top of the stack. */
internal fun baselineAt(y: Dp) = Mark(y, byBaseline = true)

/** A box whose top edge sits [y] from the top of the stack. */
internal fun topAt(y: Dp) = Mark(y, byBaseline = false)

/**
 * 0.30.0: a column that places its children on exact lines, not one under the other. The mocks
 * were measured baseline by baseline; a text's own box (ascent, leading) differs from font to font,
 * so spacing by boxes would drift by several dp on a 92 sp word. Placing by the first baseline does
 * not. Boxes may overlap, as the big word's does with the line above it. Children are centred, or
 * (with [centered] false) start-aligned.
 *
 * [marks] has one entry per child, in order; the content must emit exactly that many children.
 */
@Composable
internal fun MarkedStack(
    marks: List<Mark>,
    modifier: Modifier = Modifier,
    centered: Boolean = true,
    content: @Composable () -> Unit
) {
    Layout(content = content, modifier = modifier) { measurables, constraints ->
        val loose = Constraints(maxWidth = if (constraints.hasBoundedWidth) constraints.maxWidth else Constraints.Infinity)
        val placeables = measurables.map { it.measure(loose) }
        val w = if (constraints.hasBoundedWidth) constraints.maxWidth else (placeables.maxOfOrNull { it.width } ?: 0)
        val tops = IntArray(placeables.size)
        var bottom = 0
        placeables.forEachIndexed { i, p ->
            val mark = marks.getOrNull(i) ?: Mark(bottom.toDp(), false)
            val markPx = mark.y.roundToPx()
            val baseline = if (mark.byBaseline) p[FirstBaseline] else 0
            tops[i] = markPx - (if (baseline < 0) 0 else baseline)
            bottom = max(bottom, tops[i] + p.height)
        }
        val h = constraints.constrainHeight(bottom)
        layout(w, h) {
            placeables.forEachIndexed { i, p -> p.placeRelative(if (centered) (w - p.width) / 2 else 0, tops[i]) }
        }
    }
}

/**
 * 0.30.0: the block of a home screen, placed in the room between the header and the capsule's room.
 *
 * The free height (room − block) is split [topWeight] : [bottomWeight], so a taller phone grows the
 * gaps as the mock has them and a shorter one shrinks them. When the block itself is taller than
 * the room (a small phone, a big system font) the whole block is scaled down, never below
 * [MIN_SCALE], instead of running under the capsule. Children cannot use weights: they are measured
 * at their natural height.
 */
@Composable
internal fun FitBody(topWeight: Float, bottomWeight: Float, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Layout(content = content, modifier = modifier) { measurables, constraints ->
        val w = if (constraints.hasBoundedWidth) constraints.maxWidth else 0
        val room = if (constraints.hasBoundedHeight) constraints.maxHeight else Int.MAX_VALUE
        val p = measurables.first().measure(
            Constraints(maxWidth = if (constraints.hasBoundedWidth) constraints.maxWidth else Constraints.Infinity)
        )
        val outW = if (constraints.hasBoundedWidth) w else p.width
        val scale = FitMath.fitScale(p.height, room)
        val used = p.height * scale
        val outH = if (room == Int.MAX_VALUE) p.height else room
        val free = max(0f, outH - used)
        val top = (free * FitMath.topShare(topWeight, bottomWeight)).roundToInt()
        layout(outW, outH) {
            p.placeRelativeWithLayer((outW - p.width) / 2, top) {
                scaleX = scale
                scaleY = scale
                transformOrigin = TransformOrigin(0.5f, 0f)
            }
        }
    }
}

/** The small arithmetic of [FitBody], testable without a screen. */
internal object FitMath {
    const val MIN_SCALE = 0.76f

    /** 1 when the block fits the room, else the factor that makes it fit, not below [MIN_SCALE]. */
    fun fitScale(blockHeight: Int, roomHeight: Int): Float {
        if (blockHeight <= 0 || roomHeight >= blockHeight) return 1f
        return max(MIN_SCALE, min(1f, roomHeight.toFloat() / blockHeight))
    }

    /** The share of the free height that goes above the block. */
    fun topShare(top: Float, bottom: Float): Float {
        val total = top + bottom
        return if (total <= 0f) 0.5f else (top / total).coerceIn(0f, 1f)
    }
}
