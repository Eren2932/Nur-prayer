package com.nur.prayer.ui.schedule

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerDefaults
import androidx.compose.foundation.pager.PagerSnapDistance
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.clearAndSetSemantics
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import kotlin.math.abs

/*
 * 0.29.0 — the calendar is turned with a finger.
 *
 * A period (a Gregorian month, a Hijri year) is a *page* of a pager; the arrows are gone. One flick moves one
 * page and the page settles with a spring — the pager's own snapping, not a hand-made gesture detector, so it
 * is continuous with the thumb, interruptible, and survives a fling started mid-settle. The neighbours are
 * composed ahead (beyondViewportPageCount = 1), so a page is whole before it enters.
 *
 * The state of the screen (the month, the Hijri year) stays the single truth. The pager reports a *settled*
 * page up and takes a changed period down (the drums, "К сегодня", the restored state); [rememberPeriodPager]
 * keeps the two from echoing each other.
 */

/** The page arithmetic of the two pagers, pure so it is unit-tested. */
internal object PeriodPages {
    fun monthCount(first: YearMonth, last: YearMonth): Int = ChronoUnit.MONTHS.between(first, last).toInt() + 1

    fun monthAt(first: YearMonth, page: Int): YearMonth = first.plusMonths(page.toLong())

    fun monthPage(first: YearMonth, month: YearMonth, count: Int): Int =
        ChronoUnit.MONTHS.between(first, month).toInt().coerceIn(0, count - 1)

    fun yearPage(first: Int, year: Int, count: Int): Int = (year - first).coerceIn(0, count - 1)

    /** A far jump (the drums) is instant; a step to the next page is animated. */
    fun animated(from: Int, to: Int): Boolean = abs(from - to) <= 1
}

/**
 * A pager that agrees with [page]. [onSettled] is called once the user's flick has come to rest on another page;
 * a change of [page] from outside moves the pager and does not call it back.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun rememberPeriodPager(page: Int, count: Int, onSettled: (Int) -> Unit): PagerState {
    val state = rememberPagerState(initialPage = page.coerceIn(0, count - 1)) { count }
    val latest by rememberUpdatedState(onSettled)
    // The page both sides last agreed on. Whoever moves first writes it, so the other side finds nothing to do.
    val agreed = remember { IntArray(1) { page } }
    LaunchedEffect(state) {
        snapshotFlow { state.settledPage }.collect { settled ->
            if (settled != agreed[0]) {
                agreed[0] = settled
                latest(settled)
            }
        }
    }
    LaunchedEffect(page) {
        if (page != agreed[0]) {
            agreed[0] = page
            if (PeriodPages.animated(state.currentPage, page)) state.animateScrollToPage(page)
            else state.scrollToPage(page)
        }
    }
    return state
}

/**
 * The pages. Each page leans back a little as it leaves (a touch smaller and paler), which is what makes the
 * movement read as turning a leaf and not as scrolling a strip. Only the page in front is visible to
 * accessibility and to tests: its neighbours are composed ahead and must not answer for it.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun PeriodPager(
    state: PagerState,
    modifier: Modifier = Modifier,
    content: @Composable (page: Int) -> Unit
) {
    HorizontalPager(
        state = state,
        modifier = modifier,
        beyondViewportPageCount = 1,
        flingBehavior = PagerDefaults.flingBehavior(
            state = state,
            pagerSnapDistance = PagerSnapDistance.atMost(1)
        ),
        key = { page -> page }
    ) { page ->
        PageFrame(state, page) { content(page) }
    }
}

@Composable
private fun PageFrame(state: PagerState, page: Int, content: @Composable () -> Unit) {
    val inFront = state.currentPage == page
    Box(
        Modifier.fillMaxSize()
            .graphicsLayer {
                // 0 for the page in front, 1 for a page one whole page away. Read here, in the draw phase:
                // a drag does not recompose anything.
                val away = abs(state.currentPage - page + state.currentPageOffsetFraction).coerceIn(0f, 1f)
                val scale = 1f - LEAN_SCALE * away
                scaleX = scale
                scaleY = scale
                alpha = 1f - LEAN_FADE * away
            }
            .then(if (inFront) Modifier else Modifier.clearAndSetSemantics { })
    ) { content() }
}

private const val LEAN_SCALE = 0.05f
private const val LEAN_FADE = 0.4f
