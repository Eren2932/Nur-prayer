package com.nur.prayer.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.paddingFromBaseline
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/*
 * 0.30.0, home variant 2 («Крупный намаз»): the name of the next prayer in huge type, its time in
 * a gold pill, the countdown, and the day as a timeline.
 *
 * Measured from the mock (see HomeSpec). The timeline is a real axis: the six nodes sit where their
 * times are between the first and the last, the gold line grows to «now» and the bubble above it
 * carries the minute. Labels sit under their nodes and are pushed apart only when a summer day crowds
 * them. Only the minute-readers of HomeClock.kt look at the clock.
 */

@Composable
internal fun HomeBig(
    data: PrayerData,
    now: State<ZonedDateTime>,
    prayers: List<Prayer>,
    next: Prayer,
    heroModifier: Modifier,
    timelineModifier: Modifier,
    onOpenPrayer: (Prayer) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    FitBody(HomeSpec.Big.WEIGHT_TOP, HomeSpec.Big.WEIGHT_BOTTOM, modifier) {
        Column(Modifier.fillMaxWidth()) {
            BigHero(data, now, next, heroModifier)
            Spacer(Modifier.height(ui.s(HomeSpec.Big.HERO_TO_TIMELINE)))
            BigTimeline(data, now, prayers, timelineModifier, onOpenPrayer)
        }
    }
}

/** «Следующий намаз» / «Зухр» / «11:27» / «2:18:12» / «до начала», each on its measured line. */
@Composable
private fun BigHero(data: PrayerData, now: State<ZonedDateTime>, next: Prayer, modifier: Modifier) {
    val ui = uiScale()
    val spec = HomeSpec.Big
    val sky = TextStyle(shadow = HomeSpec.OnSky)
    val title = PrayerLabels.title(next)
    val at = Format.time(data.window.nextStart)
    MarkedStack(
        marks = listOf(
            baselineAt(ui.s(spec.KICKER_BASELINE)),
            baselineAt(ui.s(spec.WORD_BASELINE)),
            topAt(ui.s(spec.PILL_TOP)),
            baselineAt(ui.s(spec.COUNT_BASELINE)),
            baselineAt(ui.s(spec.CAPTION_BASELINE))
        ),
        modifier = modifier.fillMaxWidth().padding(horizontal = ui.s(16f))
    ) {
        Text(
            if (next.isPrayer) tr("Следующий намаз") else tr("Следующее время"),
            color = TextPrimary, fontSize = ui.t(spec.KICKER), style = sky, maxLines = 1,
            modifier = Modifier.clearAndSetSemantics { contentDescription = tr("Следующий: {0}, в {1}", title, at) }
        )
        AutoSizeText(
            title, color = TextPrimary, fontSize = ui.t(spec.WORD), minFontSize = ui.t(spec.WORD_MIN),
            fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            letterSpacing = ui.t(-1f), modifier = Modifier.fillMaxWidth().clearAndSetSemantics { }
        )
        Box(
            Modifier.size(ui.s(spec.PILL_WIDTH), ui.s(spec.PILL_HEIGHT)).clip(CircleShape).background(HomeSpec.Gold)
                .clearAndSetSemantics { },
            contentAlignment = Alignment.Center
        ) {
            Text(at, color = HomeSpec.OnGold, fontSize = ui.t(spec.PILL_TIME), fontWeight = FontWeight.Bold, maxLines = 1)
        }
        HomeCountdown(data, now, next, spec.COUNT, spec.COUNT_MIN, FontWeight.SemiBold, -2f, Modifier.fillMaxWidth())
        Text(
            tr("до начала"), color = TextPrimary, fontSize = ui.t(spec.CAPTION), style = sky, maxLines = 1,
            modifier = Modifier.clearAndSetSemantics { }
        )
    }
}

/** How a node of the timeline looks: reached (gold ring), the next one (big, gold), still ahead (dark). */
private enum class NodeLook { REACHED, NEXT, AHEAD }

private fun lookOf(state: RowState): NodeLook = when (state) {
    RowState.PAST, RowState.CURRENT -> NodeLook.REACHED
    RowState.NEXT -> NodeLook.NEXT
    RowState.UPCOMING -> NodeLook.AHEAD
}

@Composable
private fun BigTimeline(
    data: PrayerData,
    now: State<ZonedDateTime>,
    prayers: List<Prayer>,
    modifier: Modifier,
    onOpenPrayer: (Prayer) -> Unit
) {
    val ui = uiScale()
    val spec = HomeSpec.Big
    val states = prayers.map { HomeMath.rowState(it, data.window, data.today, data.fajrEqualsDawn) }
    val looks = states.map(::lookOf)
    val times = prayers.map { data.today.times[it] }
    val axis = HomeMath.axis(times)
    val minute = rememberClockMinute(now)
    val stamp = rememberClockStamp(now)

    Box(modifier.fillMaxWidth().height(ui.s(spec.TIMELINE_HEIGHT))) {
        val sidePx = with(LocalDensity.current) { ui.s(spec.SIDE).toPx() }
        val trackColor = Color.White.copy(alpha = spec.TRACK_ALPHA)
        val lineY = ui.s(spec.LINE_Y)
        val lineWidth = ui.s(spec.LINE)
        val node = ui.s(spec.NODE)
        val ring = ui.s(spec.NODE_RING)
        val ringFuture = ui.s(spec.NODE_RING_FUTURE)
        val nextNode = ui.s(spec.NEXT_NODE)
        val nextRing = ui.s(spec.NEXT_RING)

        // The line, its gold part up to «now», and the nodes. The minute is read while drawing only.
        Canvas(Modifier.fillMaxSize()) {
            val usable = size.width - 2f * sidePx
            val y = lineY.toPx()
            val stroke = lineWidth.toPx()
            val from = Offset(sidePx, y)
            val to = Offset(sidePx + usable, y)
            drawLine(color = trackColor, start = from, end = to, strokeWidth = stroke)
            val fraction = HomeMath.nowFraction(times, axis, minute.value * 60L)
            if (fraction > 0f) {
                drawLine(
                    color = HomeSpec.Gold, start = from, end = Offset(sidePx + usable * fraction, y), strokeWidth = stroke
                )
            }
            for (i in prayers.indices) {
                val c = Offset(sidePx + usable * axis[i], y)
                when (looks[i]) {
                    NodeLook.REACHED -> {
                        drawCircle(color = HomeSpec.Gold, radius = node.toPx() / 2f, center = c)
                        drawCircle(color = spec.NodeInk, radius = node.toPx() / 2f - ring.toPx(), center = c)
                    }
                    NodeLook.AHEAD -> {
                        drawCircle(color = spec.FutureRing, radius = node.toPx() / 2f, center = c)
                        drawCircle(color = spec.FutureFill, radius = node.toPx() / 2f - ringFuture.toPx(), center = c)
                    }
                    NodeLook.NEXT -> {
                        drawCircle(color = Color.White, radius = nextNode.toPx() / 2f, center = c)
                        drawCircle(color = HomeSpec.Gold, radius = nextNode.toPx() / 2f - nextRing.toPx(), center = c)
                    }
                }
            }
        }

        TimelineLabels(data, prayers, states, axis, sidePx, onOpenPrayer)
        TimelineBubble(times, axis, sidePx, minute, stamp)
    }
}

/** Names and times under their nodes; pushed apart (never moved off the screen) when they would touch. */
@Composable
private fun TimelineLabels(
    data: PrayerData,
    prayers: List<Prayer>,
    states: List<RowState>,
    axis: FloatArray,
    sidePx: Float,
    onOpenPrayer: (Prayer) -> Unit
) {
    val ui = uiScale()
    val spec = HomeSpec.Big
    val nameTop = ui.s(10f)
    val stampTop = ui.s(14.3f)
    val density = LocalDensity.current
    val gapPx = with(density) { ui.s(spec.LABEL_GAP).toPx() }
    val edgePx = with(density) { ui.s(spec.EDGE).toPx() }
    val topPx = with(density) { ui.s(spec.NAME_BASELINE - 10f).toPx().roundToInt() }

    Layout(
        content = {
            prayers.forEachIndexed { i, prayer ->
                val label = PrayerLabels.title(prayer)
                val start = HomeMath.startOf(prayer, states[i], data.window, data.today)
                val stamp = start?.let(Format::time) ?: "—"
                val isNext = states[i] == RowState.NEXT
                val ink = if (isNext) HomeSpec.Gold else TextPrimary
                Column(
                    Modifier
                        .clip(RoundedCornerShape(ui.s(6f)))
                        .clickable(role = Role.Button, onClickLabel = tr("Подробнее")) { onOpenPrayer(prayer) }
                        .semantics { contentDescription = "$label $stamp" }
                        .padding(horizontal = ui.s(3f)),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        label, color = ink, fontSize = ui.t(spec.NAME), fontWeight = FontWeight.SemiBold, maxLines = 1,
                        modifier = Modifier.paddingFromBaseline(top = nameTop)
                    )
                    Text(
                        stamp, color = ink, fontSize = ui.t(spec.STAMP), fontWeight = FontWeight.Bold, maxLines = 1,
                        modifier = Modifier.paddingFromBaseline(top = stampTop, bottom = ui.s(8f))
                    )
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { measurables, constraints ->
        val w = constraints.maxWidth
        val placeables = measurables.map { it.measure(Constraints()) }
        val usable = w - 2f * sidePx
        val centers = FloatArray(placeables.size) { sidePx + usable * axis[it] }
        val widths = FloatArray(placeables.size) { placeables[it].width.toFloat() }
        val lefts = HomeMath.spreadLabels(centers, widths, gapPx, edgePx, w - edgePx)
        layout(w, constraints.maxHeight) {
            placeables.forEachIndexed { i, p -> p.placeRelative(lefts[i].roundToInt(), topPx) }
        }
    }
}

/** The white speech bubble over «now»: the minute of the clock, its tail on the line. */
@Composable
private fun TimelineBubble(
    times: List<ZonedDateTime?>,
    axis: FloatArray,
    sidePx: Float,
    minute: State<Long>,
    stampState: State<String>
) {
    val ui = uiScale()
    val spec = HomeSpec.Big
    val m = minute.value
    val stamp = stampState.value
    val fraction = HomeMath.nowFraction(times, axis, m * 60L)
    val tailWidth = ui.s(spec.TAIL_WIDTH)
    val tailHeight = ui.s(spec.TAIL_HEIGHT)
    Box(
        Modifier
            .layout { measurable, constraints ->
                val p = measurable.measure(Constraints())
                val w = constraints.maxWidth
                val usable = w - 2f * sidePx
                val edge = ui.s(spec.EDGE).toPx()
                val center = sidePx + usable * fraction
                val left = max(edge, min(center - p.width / 2f, w - edge - p.width))
                layout(w, p.height) { p.placeRelative(left.roundToInt(), 0) }
            }
            .drawBehind {
                val radius = size.height / 2f
                drawRoundRect(color = Color.White, size = Size(size.width, size.height), cornerRadius = CornerRadius(radius, radius))
                val cx = size.width / 2f
                val tw = tailWidth.toPx()
                val th = tailHeight.toPx()
                val tail = Path().apply {
                    moveTo(cx - tw / 2f, size.height - 1f)
                    lineTo(cx - 1.4f, size.height + th - 1.6f)
                    quadraticBezierTo(cx, size.height + th, cx + 1.4f, size.height + th - 1.6f)
                    lineTo(cx + tw / 2f, size.height - 1f)
                    close()
                }
                drawPath(path = tail, color = Color.White)
            }
            .height(ui.s(spec.BUBBLE_HEIGHT))
            .padding(horizontal = ui.s(spec.BUBBLE_PAD))
            .clearAndSetSemantics { contentDescription = tr("Сейчас {0}", stamp) },
        contentAlignment = Alignment.Center
    ) {
        Text(stamp, color = HomeSpec.OnGold, fontSize = ui.t(spec.BUBBLE_TIME), fontWeight = FontWeight.Bold, maxLines = 1)
    }
}
