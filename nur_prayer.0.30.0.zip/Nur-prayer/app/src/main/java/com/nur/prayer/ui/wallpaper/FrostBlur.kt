package com.nur.prayer.ui.wallpaper

/**
 * 0.27.0: one pass of a separable box blur over opaque ARGB pixels, in place. Three passes are a
 * close gaussian. Edges repeat the border pixel, so the glass does not darken at the screen edge.
 * Pure Kotlin on a tiny array (the frost bitmap is ~40 × 90), unit-tested in FrostBlurTest.
 */
internal object FrostBlur {

    fun blur(pixels: IntArray, width: Int, height: Int, radius: Int) {
        if (radius <= 0 || width <= 0 || height <= 0 || pixels.size < width * height) return
        val tmp = IntArray(width * height)
        pass(pixels, tmp, width, height, radius, horizontal = true)
        pass(tmp, pixels, width, height, radius, horizontal = false)
    }

    private fun pass(src: IntArray, dst: IntArray, width: Int, height: Int, radius: Int, horizontal: Boolean) {
        val lines = if (horizontal) height else width
        val length = if (horizontal) width else height
        val window = radius * 2 + 1
        for (line in 0 until lines) {
            var a = 0
            var r = 0
            var g = 0
            var b = 0
            for (k in -radius..radius) {
                val c = src[index(line, k.coerceIn(0, length - 1), width, horizontal)]
                a += (c ushr 24) and 0xFF
                r += (c shr 16) and 0xFF
                g += (c shr 8) and 0xFF
                b += c and 0xFF
            }
            for (i in 0 until length) {
                dst[index(line, i, width, horizontal)] =
                    ((a / window) shl 24) or ((r / window) shl 16) or ((g / window) shl 8) or (b / window)
                val out = src[index(line, (i - radius).coerceIn(0, length - 1), width, horizontal)]
                val inc = src[index(line, (i + radius + 1).coerceIn(0, length - 1), width, horizontal)]
                a += ((inc ushr 24) and 0xFF) - ((out ushr 24) and 0xFF)
                r += ((inc shr 16) and 0xFF) - ((out shr 16) and 0xFF)
                g += ((inc shr 8) and 0xFF) - ((out shr 8) and 0xFF)
                b += (inc and 0xFF) - (out and 0xFF)
            }
        }
    }

    private fun index(line: Int, i: Int, width: Int, horizontal: Boolean): Int =
        if (horizontal) line * width + i else i * width + line
}
