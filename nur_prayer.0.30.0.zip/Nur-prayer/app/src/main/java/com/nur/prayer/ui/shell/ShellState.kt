package com.nur.prayer.ui.shell

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf

/*
 * 0.27.0 «Капсула»: the one object all navigation lives in.
 *
 * Closed, it is a capsule in reach of the thumb; open, the same glass is the panel (the times of
 * the day and the sections). Not two views swapping: one surface whose bounds move between the two
 * (shared bounds), driven by one number, [progress]: 0 is the capsule, 1 the panel. Only layout and
 * draw read it, so the morph never recomposes. A spring, so a tap mid-way turns it around smoothly.
 *
 * Not saveable on purpose: an open panel must not greet the user after a return.
 */
@Stable
class ShellState {
    var open by mutableStateOf(false)
        private set
    private val morph = Animatable(0f)
    val progress: Float get() = morph.value

    /**
     * 0.27.1: a page that wants the whole screen for itself (the Quran reader while one reads) asks the
     * capsule to step aside. The capsule keeps its place in the tree, so showing it again on a tap is
     * one animated float, not a composition.
     */
    var capsuleHidden by mutableStateOf(false)

    /** Bottom edge of the glass in root px: the capsule and the panel share it (the panel grows upwards). */
    var glassBottomInRoot by mutableFloatStateOf(Float.NaN)
    /** Height of the open panel in px, measured on the first frame of opening (NaN before). */
    var panelHeightPx by mutableFloatStateOf(Float.NaN)

    /** Where the top of the fully open panel will be, known from the first frame: home lifts its clock above it. */
    val panelTopInRoot: Float get() = glassBottomInRoot - panelHeightPx

    fun show() { open = true }
    fun hide() { open = false }

    suspend fun settle() {
        if (open) morph.animateTo(1f, spring(dampingRatio = ShellMath.OPEN_DAMPING, stiffness = ShellMath.OPEN_STIFFNESS))
        else morph.animateTo(0f, spring(dampingRatio = ShellMath.CLOSE_DAMPING, stiffness = ShellMath.CLOSE_STIFFNESS))
    }

    suspend fun snap() { morph.snapTo(if (open) 1f else 0f) }
}

val LocalShell = staticCompositionLocalOf<ShellState?> { null }

/** The arithmetic of the morph, kept pure for ShellMathTest. */
object ShellMath {
    /** 0.27.1: opens with a hair of overshoot (≈ 1 %), closes critically damped: it never bounces off the capsule. */
    const val OPEN_DAMPING = 0.86f
    const val OPEN_STIFFNESS = 420f
    const val CLOSE_DAMPING = 1f
    const val CLOSE_STIFFNESS = 600f

    /** The spring may overshoot a little; the glass may grow a hair past the panel, never further. */
    fun clampProgress(p: Float): Float = p.coerceIn(0f, 1.03f)

    fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    /** The capsule's own content leaves in the first third of the way. */
    fun capsuleAlpha(p: Float): Float = (1f - p / 0.3f).coerceIn(0f, 1f)

    /** The panel's content arrives once the glass has room for it. */
    fun panelAlpha(p: Float): Float = ((p - 0.28f) / 0.52f).coerceIn(0f, 1f)

    /** Share of the screen the closed capsule takes. The mock's 0.64 cut «Вечерние азкары» to «азка…» on real phones. */
    const val CAPSULE_SHARE = 0.74f

    /** Width of the closed capsule: three quarters of the screen, within reason. */
    fun capsuleWidth(screen: Float, min: Float, max: Float, margin: Float): Float =
        (screen * CAPSULE_SHARE).coerceIn(min, maxOf(min, minOf(max, screen - 2 * margin)))

    /**
     * Black laid over the blurred picture under the glass: [pictureDim] at least, so a light wallpaper
     * cannot lift the glass, and as much as the page darkens the sharp picture when that is more.
     */
    fun pictureDim(pageDim: Float, pagePeak: Float): Float = maxOf(PICTURE_DIM, pageDim.coerceIn(0f, 1f) * pagePeak)

    const val PICTURE_DIM = 0.50f

    /** The capsule is on screen when its route has it and no page asked it to step aside. */
    fun capsuleVisible(routeHasIt: Boolean, hiddenByPage: Boolean): Boolean = routeHasIt && !hiddenByPage

    /**
     * The reader's chrome (its top bar and the capsule) is up when the user asked for it (a tap, the top
     * of the surah) and nothing docks at the bottom: a selected ayah's actions or a sheet own that edge.
     */
    fun readerChrome(chromeShown: Boolean, ayahSelected: Boolean, sheetOpen: Boolean): Boolean =
        chromeShown && !ayahSelected && !sheetOpen

    /** Slide of a capsule that comes or goes: it travels this far down while it fades. */
    const val SLIDE_DP = 48f

    /**
     * How far home lifts its clock when the panel opens: just enough that the shrunken digits end
     * [gap] above the panel, never above [ceiling] (the header). 0 when it already fits.
     */
    fun clockLift(clockTop: Float, clockBottomScaled: Float, panelTop: Float, gap: Float, ceiling: Float): Float {
        if (panelTop.isNaN()) return 0f
        val need = clockBottomScaled - (panelTop - gap)
        val room = (clockTop - ceiling).coerceAtLeast(0f)
        return need.coerceIn(0f, room)
    }
}
