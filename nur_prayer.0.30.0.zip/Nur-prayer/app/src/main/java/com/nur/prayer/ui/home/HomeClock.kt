package com.nur.prayer.ui.home

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerWindow
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.CountdownMath
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.uiScale
import java.time.Duration
import java.time.ZonedDateTime

/*
 * 0.27.0: the big countdown of home. 0.30.0: it serves both home screens, and so do the other
 * readers of the clock below. This file is the only place of home that reads `now`, so HomeScreen
 * and the two layouts never recompose per second (source_audit). Everything that shows time
 * passing but changes less often than a second (the «через 2 ч 01 мин» of a card, the progress bar,
 * the minute in the timeline's bubble) hangs on a derivedStateOf: the clock ticks every second, the
 * composable behind it recomposes only when the value it shows really changes.
 */

/**
 * «2:01:34»: the countdown to [next], in the size a layout asks for. The text changes width only
 * when the last hour starts (1:00:00 → 59:59): resizeKey follows that.
 */
@Composable
internal fun HomeCountdown(
    data: PrayerData,
    now: State<ZonedDateTime>,
    next: Prayer,
    fontSize: Float,
    minFontSize: Float,
    weight: FontWeight,
    spacing: Float,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val text = Format.countdown(data.window.remaining(now.value))
    AutoSizeText(
        text, color = TextPrimary, fontSize = ui.t(fontSize), minFontSize = ui.t(minFontSize),
        fontWeight = weight, textAlign = TextAlign.Center, letterSpacing = ui.t(spacing),
        resizeKey = text.length,
        modifier = modifier.clearAndSetSemantics {
            contentDescription = tr("До {0}: {1}", PrayerLabels.title(next), text)
        }
    )
}

/**
 * Whole minutes left to [start], counted the way the countdown counts its seconds (the same
 * rounding), so «через 2 ч 01 мин» turns over at the very second «2:01:00» does.
 */
@Composable
internal fun rememberMinutesLeft(now: State<ZonedDateTime>, start: ZonedDateTime?): State<Long> =
    remember(now, start) {
        derivedStateOf {
            if (start == null) 0L
            else CountdownMath.secondsRemaining(Duration.between(now.value, start)) / 60L
        }
    }

/** How far through the window going on now, in thousandths: a bar a few hundred dp long moves by a pixel, not by a second. */
@Composable
internal fun rememberWindowProgress(now: State<ZonedDateTime>, window: PrayerWindow): State<Float> =
    remember(now, window) {
        derivedStateOf { (window.progress(now.value) * PROGRESS_STEPS).toInt() / PROGRESS_STEPS }
    }

/** The minute of the clock, as epoch minutes: the timeline's bubble and its line move once a minute. */
@Composable
internal fun rememberClockMinute(now: State<ZonedDateTime>): State<Long> =
    remember(now) { derivedStateOf { Math.floorDiv(now.value.toEpochSecond(), 60L) } }

/** «12:12»: the clock's minute as text. Same idea: the clock ticks, the reader recomposes once a minute. */
@Composable
internal fun rememberClockStamp(now: State<ZonedDateTime>): State<String> =
    remember(now) { derivedStateOf { Format.time(now.value) } }

private const val PROGRESS_STEPS = 1000f
