package com.nur.prayer.ui.shell

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import com.nur.prayer.ui.theme.ArabicFont
import kotlin.math.cos
import kotlin.math.sin

/*
 * 0.27.0: the thin line icons of the capsule and its panel, drawn on a 24-unit grid like the mock:
 * one stroke weight, round caps, no fills except dots. ع is a letter, so it is set as text.
 */
enum class ShellGlyph { BOOK, TASBIH, COMPASS, CHECKLIST, AIN, CALENDAR, DOTS, MOON, PERSON, LOCATE }

@Composable
fun ShellIcon(glyph: ShellGlyph, tint: Color, modifier: Modifier = Modifier) {
    if (glyph == ShellGlyph.AIN) {
        Box(modifier, contentAlignment = Alignment.Center) {
            // Sized from the box, so the letter scales with the icon like the drawn ones.
            androidx.compose.foundation.layout.BoxWithConstraints(contentAlignment = Alignment.Center) {
                val size = with(LocalDensity.current) { (maxHeight * 0.78f).toSp() }
                Text("ع", color = tint, fontSize = size, fontWeight = FontWeight.Medium, maxLines = 1, fontFamily = ArabicFont.family)
            }
        }
        return
    }
    Canvas(modifier) { drawShellGlyph(glyph, tint) }
}

internal fun DrawScope.drawShellGlyph(glyph: ShellGlyph, tint: Color) {
    val u = size.minDimension / 24f
    val ox = (size.width - 24f * u) / 2f
    val oy = (size.height - 24f * u) / 2f
    fun p(x: Float, y: Float) = Offset(ox + x * u, oy + y * u)
    val line = Stroke(width = 1.7f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    when (glyph) {
        ShellGlyph.BOOK -> {
            val left = Path().apply {
                moveTo(p(12f, 6.4f).x, p(12f, 6.4f).y)
                cubicTo(p(10f, 5f).x, p(10f, 5f).y, p(6.8f, 4.6f).x, p(6.8f, 4.6f).y, p(3.4f, 5.2f).x, p(3.4f, 5.2f).y)
                lineTo(p(3.4f, 18.4f).x, p(3.4f, 18.4f).y)
                cubicTo(p(6.8f, 17.9f).x, p(6.8f, 17.9f).y, p(10f, 18.3f).x, p(10f, 18.3f).y, p(12f, 19.6f).x, p(12f, 19.6f).y)
                close()
            }
            val right = Path().apply {
                moveTo(p(12f, 6.4f).x, p(12f, 6.4f).y)
                cubicTo(p(14f, 5f).x, p(14f, 5f).y, p(17.2f, 4.6f).x, p(17.2f, 4.6f).y, p(20.6f, 5.2f).x, p(20.6f, 5.2f).y)
                lineTo(p(20.6f, 18.4f).x, p(20.6f, 18.4f).y)
                cubicTo(p(17.2f, 17.9f).x, p(17.2f, 17.9f).y, p(14f, 18.3f).x, p(14f, 18.3f).y, p(12f, 19.6f).x, p(12f, 19.6f).y)
                close()
            }
            drawPath(left, tint, style = line)
            drawPath(right, tint, style = line)
        }
        ShellGlyph.TASBIH -> {
            // Beads on a loop, open at the bottom where the tassel hangs.
            val c = p(12f, 10f)
            val r = 6.2f * u
            for (i in 0 until 10) {
                val a = Math.toRadians(90.0 + 30.0 + i * 33.3).toFloat()
                drawCircle(tint, radius = 1.35f * u, center = Offset(c.x + r * cos(a), c.y + r * sin(a)))
            }
            drawLine(tint, p(12f, 16.6f), p(12f, 20.2f), strokeWidth = 1.6f * u, cap = StrokeCap.Round)
            drawCircle(tint, radius = 1.35f * u, center = p(12f, 16.4f))
            drawCircle(tint, radius = 1.1f * u, center = p(12f, 21.2f))
        }
        ShellGlyph.COMPASS -> {
            drawCircle(tint, radius = 8.6f * u, center = p(12f, 12f), style = line)
            val needle = Path().apply {
                moveTo(p(15.8f, 8.2f).x, p(15.8f, 8.2f).y)
                lineTo(p(13.3f, 13.3f).x, p(13.3f, 13.3f).y)
                lineTo(p(8.2f, 15.8f).x, p(8.2f, 15.8f).y)
                lineTo(p(10.7f, 10.7f).x, p(10.7f, 10.7f).y)
                close()
            }
            drawPath(needle, tint, style = Stroke(width = 1.4f * u, join = StrokeJoin.Round))
            val tip = Path().apply {
                moveTo(p(15.8f, 8.2f).x, p(15.8f, 8.2f).y)
                lineTo(p(13.3f, 13.3f).x, p(13.3f, 13.3f).y)
                lineTo(p(10.7f, 10.7f).x, p(10.7f, 10.7f).y)
                close()
            }
            drawPath(tip, tint, style = Fill)
        }
        ShellGlyph.CHECKLIST -> {
            fun tick(y: Float) {
                val t = Path().apply {
                    moveTo(p(3.6f, y).x, p(3.6f, y).y)
                    lineTo(p(5.1f, y + 1.5f).x, p(5.1f, y + 1.5f).y)
                    lineTo(p(7.8f, y - 1.6f).x, p(7.8f, y - 1.6f).y)
                }
                drawPath(t, tint, style = line)
            }
            tick(6.6f)
            tick(12.1f)
            drawCircle(tint, radius = 1.05f * u, center = p(5.3f, 17.8f))
            drawLine(tint, p(10.6f, 6.8f), p(20.6f, 6.8f), strokeWidth = line.width, cap = StrokeCap.Round)
            drawLine(tint, p(10.6f, 12.3f), p(20.6f, 12.3f), strokeWidth = line.width, cap = StrokeCap.Round)
            drawLine(tint, p(10.6f, 17.8f), p(20.6f, 17.8f), strokeWidth = line.width, cap = StrokeCap.Round)
        }
        ShellGlyph.CALENDAR -> {
            val body = Path().apply {
                addRoundRect(RoundRect(ox + 3.6f * u, oy + 5.4f * u, ox + 20.4f * u, oy + 20.4f * u, CornerRadius(2.6f * u)))
            }
            drawPath(body, tint, style = line)
            drawLine(tint, p(3.6f, 9.6f), p(20.4f, 9.6f), strokeWidth = line.width)
            drawLine(tint, p(8f, 3.4f), p(8f, 6.8f), strokeWidth = line.width, cap = StrokeCap.Round)
            drawLine(tint, p(16f, 3.4f), p(16f, 6.8f), strokeWidth = line.width, cap = StrokeCap.Round)
            for (row in 0..1) for (col in 0..2) {
                drawCircle(tint, radius = 1.05f * u, center = p(8f + col * 4f, 13.4f + row * 3.6f))
            }
        }
        ShellGlyph.DOTS -> {
            val r = 2.7f * u
            drawCircle(tint, r, p(7.6f, 7.6f))
            drawCircle(tint, r, p(16.4f, 7.6f))
            drawCircle(tint, r, p(7.6f, 16.4f))
            drawCircle(tint, r, p(16.4f, 16.4f))
        }
        ShellGlyph.MOON -> {
            drawCircle(tint, radius = 10f * u, center = p(12f, 12f), style = Stroke(width = 1.6f * u))
            val disc = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(p(12f, 12f), 5.6f * u))
            }
            val bite = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(p(14.6f, 10.2f), 4.9f * u))
            }
            val crescent = Path().apply { op(disc, bite, PathOperation.Difference) }
            drawPath(crescent, tint, style = Fill)
        }
        ShellGlyph.PERSON -> {
            // The avatar of the mock: a filled head and shoulders, cut by the circle that holds them.
            drawCircle(tint, radius = 4.3f * u, center = p(12f, 8.6f))
            val body = Path().apply {
                moveTo(p(3.2f, 22f).x, p(3.2f, 22f).y)
                cubicTo(p(3.6f, 16.6f).x, p(3.6f, 16.6f).y, p(7.4f, 14.4f).x, p(7.4f, 14.4f).y, p(12f, 14.4f).x, p(12f, 14.4f).y)
                cubicTo(p(16.6f, 14.4f).x, p(16.6f, 14.4f).y, p(20.4f, 16.6f).x, p(20.4f, 16.6f).y, p(20.8f, 22f).x, p(20.8f, 22f).y)
                close()
            }
            drawPath(body, tint, style = Fill)
        }
        ShellGlyph.LOCATE -> {
            // The navigation arrow next to the city: a filled dart pointing up and to the right.
            val dart = Path().apply {
                moveTo(p(20.5f, 3.5f).x, p(20.5f, 3.5f).y)
                lineTo(p(13.6f, 20.6f).x, p(13.6f, 20.6f).y)
                lineTo(p(11.4f, 12.6f).x, p(11.4f, 12.6f).y)
                lineTo(p(3.4f, 10.4f).x, p(3.4f, 10.4f).y)
                close()
            }
            drawPath(dart, tint, style = Fill)
            drawPath(dart, tint, style = Stroke(width = 1.2f * u, join = StrokeJoin.Round))
        }
        ShellGlyph.AIN -> Unit
    }
}
