package com.nur.prayer.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.DraggableState
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/*
 * 0.29.0 — the grabber of every sheet in the app.
 *
 * It no longer sits inside the sheet: it floats above the sheet's top edge, a little translucent, and travels
 * with it (it is the first row of the same column, so any slide, drag or fade that moves the sheet moves it).
 * The row is the sheet's grip as well: it is as wide as the screen and [LANE] tall, so a thumb finds it without
 * aiming at a 6 dp line.
 *
 * Measured from the reference sheet: 48 × 6 dp, its bottom edge 12 dp above the sheet, white at about 30 %.
 */
object SheetGrabber {
    val WIDTH = 48.dp
    val HEIGHT = 6.dp
    /** The air between the grabber and the sheet's top edge. */
    val GAP = 12.dp
    /** The whole row above the sheet: the grabber, its air, and slack above it for the thumb. */
    val LANE = 36.dp
    /** White, translucent: it reads on a dimmed picture and on a dark scrim alike. */
    val COLOR = Color.White.copy(alpha = 0.32f)
}

/** The grabber row. Put it first in the sheet's column, above the surface; [modifier] may carry the drag. */
@Composable
fun SheetGrabber(modifier: Modifier = Modifier, color: Color = SheetGrabber.COLOR) {
    Box(
        modifier.fillMaxWidth().height(SheetGrabber.LANE).testTag("sheet-grabber"),
        contentAlignment = Alignment.BottomCenter
    ) {
        Box(
            Modifier.padding(bottom = SheetGrabber.GAP).size(SheetGrabber.WIDTH, SheetGrabber.HEIGHT)
                .clip(CircleShape).background(color)
        )
    }
}

/**
 * The downward drag of a sheet that is dismissed by pulling it. [offsetPx] is read in a graphicsLayer (so a drag
 * recomposes nothing); the grip is [sheetDrag]. Released past [closeAtPx] or flung down, it calls the dismiss;
 * otherwise it springs back. A new drag takes over a spring-back in flight.
 */
@Stable
class SheetDrag internal constructor(
    private val scope: CoroutineScope,
    private val closeAtPx: Float,
    private val dismiss: () -> Unit
) {
    private val offset = Animatable(0f)

    val offsetPx: Float get() = offset.value

    internal val state: DraggableState = DraggableState { delta ->
        scope.launch { offset.snapTo((offset.value + delta).coerceAtLeast(0f)) }
    }

    internal suspend fun release(velocity: Float) {
        if (offset.value > closeAtPx || velocity > FLING_PX_PER_S) dismiss()
        else offset.animateTo(0f, spring(dampingRatio = 0.8f, stiffness = 500f))
    }

    /** Back to rest, without animation: a sheet that opens again must not open already pulled down. */
    suspend fun reset() { offset.snapTo(0f) }

    private companion object {
        const val FLING_PX_PER_S = 1800f
    }
}

@Composable
fun rememberSheetDrag(onDismiss: () -> Unit): SheetDrag {
    val scope = rememberCoroutineScope()
    val latest = rememberUpdatedState(onDismiss)
    val closeAt = with(LocalDensity.current) { 120.dp.toPx() }
    return remember(scope, closeAt) { SheetDrag(scope, closeAt) { latest.value() } }
}

/** The grip of a [SheetDrag]: apply it to the grabber row and to the header of the sheet. */
fun Modifier.sheetDrag(drag: SheetDrag): Modifier =
    draggable(drag.state, Orientation.Vertical, onDragStopped = { velocity -> drag.release(velocity) })
