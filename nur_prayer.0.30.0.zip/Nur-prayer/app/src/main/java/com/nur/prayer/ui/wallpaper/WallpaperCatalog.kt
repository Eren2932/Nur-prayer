package com.nur.prayer.ui.wallpaper

import com.nur.prayer.i18n.tr

/*
 * 0.22.0 — обои.
 *
 * The home backdrop used to be one of two things (the sky of the prayer window, or AMOLED black).
 * It is now a wallpaper, and those two are simply the first two "live" wallpapers of the catalog.
 *
 * Adding a picture (see tools/wallpapers.py):
 *   1. art/wallpapers/<id>.jpg  →  python3 tools/wallpapers.py build   (trims, encodes, locks)
 *   2. one line below: image("<id>", WallpaperCategory.X, focusX, focusY) { tr("Название") }
 * The crop for every screen (WallpaperFit), the contrast scrim (WallpaperContrast), the thumbnail,
 * the gallery section and the order in the settings row all follow from the picture and this line.
 *
 * The focus point is where the drawing is (the mosque, the Kaaba), as a fraction of the picture.
 * It is not "the centre of the crop": the crop keeps the focus at the same relative place of the
 * screen it had in the picture, so the composition the artist drew survives on any screen.
 */

enum class WallpaperCategory {
    LIVE, HARAMAIN, MOSQUES;

    fun title(): String = when (this) {
        LIVE -> tr("Основные")
        HARAMAIN -> tr("Мекка и Медина")
        MOSQUES -> tr("Мечети")
    }
}

/**
 * One wallpaper. Equality is the id: the settings store the id, and two lookups of the same id
 * must be the same wallpaper for Compose and for `==`.
 */
@androidx.compose.runtime.Immutable
class Wallpaper private constructor(
    val id: String,
    val kind: Kind,
    val category: WallpaperCategory,
    /** Focus of the drawing, 0..1 of the picture's width and height. */
    val focusX: Float,
    val focusY: Float,
    /** 0.28.0: a light picture (cream/white mean). The calendar keeps it undimmed and turns the bar icons dark. */
    val light: Boolean,
    private val name: () -> String
) {
    enum class Kind {
        /** The sky of the current prayer window (0.6.0 backdrop), stars included. */
        SKY,
        /** Pure black: the AMOLED backdrop of 0.5.x. */
        AMOLED,
        /** A picture from assets/wallpapers. */
        IMAGE
    }

    val isImage: Boolean get() = kind == Kind.IMAGE
    val asset: String get() = "wallpapers/$id.webp"

    fun title(): String = name()

    override fun equals(other: Any?): Boolean = other is Wallpaper && other.id == id
    override fun hashCode(): Int = id.hashCode()
    override fun toString(): String = "Wallpaper($id)"

    companion object {
        internal fun live(id: String, kind: Kind, name: () -> String) =
            Wallpaper(id, kind, WallpaperCategory.LIVE, 0.5f, 0.5f, false, name)

        internal fun image(
            id: String, category: WallpaperCategory, focusX: Float, focusY: Float,
            light: Boolean = false, name: () -> String
        ) = Wallpaper(id, Kind.IMAGE, category, focusX, focusY, light, name)
    }
}

object WallpaperCatalog {
    const val SKY_ID = "sky"
    const val AMOLED_ID = "amoled"

    val Sky = Wallpaper.live(SKY_ID, Wallpaper.Kind.SKY) { tr("Живое небо") }
    val Amoled = Wallpaper.live(AMOLED_ID, Wallpaper.Kind.AMOLED) { tr("Чёрный") }

    /** Catalog order is gallery order inside a category. New pictures go to the end of their category. */
    val all: List<Wallpaper> = listOf(
        Sky,
        Amoled,
        Wallpaper.image("kaaba_day", WallpaperCategory.HARAMAIN, 0.54f, 0.75f, light = true) { tr("Кааба") },
        Wallpaper.image("nabawi_moon", WallpaperCategory.HARAMAIN, 0.61f, 0.78f) { tr("Луна над Мединой") },
        Wallpaper.image("madinah_dusk", WallpaperCategory.HARAMAIN, 0.53f, 0.64f) { tr("Вечер в Медине") },
        Wallpaper.image("night_mosque", WallpaperCategory.MOSQUES, 0.52f, 0.76f) { tr("Ночь в пустыне") },
    )

    private val byId: Map<String, Wallpaper> = all.associateBy { it.id }

    fun find(id: String?): Wallpaper? = id?.let { byId[it] }

    /**
     * What is on screen. [stored] is the saved id (null before 0.22.0); a wallpaper removed from a
     * later catalog falls back to the sky instead of a black screen. Before 0.22.0 the only choice
     * was the sky switch, so an old install keeps exactly what it had.
     */
    fun resolve(stored: String?, skyBackdrop: Boolean): Wallpaper =
        find(stored) ?: if (stored == null && !skyBackdrop) Amoled else Sky

    /** Categories that have at least one wallpaper, in enum order: an empty section is never drawn. */
    fun sections(): List<Pair<WallpaperCategory, List<Wallpaper>>> =
        WallpaperCategory.entries.mapNotNull { c -> all.filter { it.category == c }.takeIf { it.isNotEmpty() }?.let { c to it } }
}
