package com.nur.prayer.ui.schedule

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.HijriMonthSpan
import com.nur.prayer.data.IslamicDay
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.components.rememberEntranceClock
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate
import kotlin.math.cos
import kotlin.math.sin

/*
 * 0.19.0 — the hijri year at a glance, as in the paper calendars of the mosques: twelve months,
 * each with its Gregorian bounds and the days that fall in it. The current month is lit and shows
 * how far it has gone; a past day fades.
 *
 * 0.28.0 — the same year on paper, in two columns instead of one tall list: six rows of tiles instead
 * of twelve cards, the current month in the middle of the screen. The period bar lives above (PeriodBar);
 * here are the chips of what is coming and the tiles. A day is a row of the reference's kind — a coloured
 * edge, a short name, a date plate — and opens its sheet; a tile shows two and folds the rest under «Ещё».
 */
private const val SHOWN = 2

@Composable
internal fun YearView(
    hijriYear: Int,
    today: LocalDate,
    hijriOffset: Int,
    bottomInset: Dp,
    onOpen: (SheetTopic) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val months = remember(hijriYear, hijriOffset) { IslamicDays.months(hijriYear, hijriOffset) }
    val current = months.indexOfFirst { it.contains(today) }
    val rows = remember(months) { months.chunked(2) }
    val list = rememberLazyListState()
    val clock = rememberEntranceClock(hijriYear)
    var unfolded by remember(hijriYear) { mutableStateOf(emptySet<Int>()) }
    // Open on the row of the current month (item 0 holds the chips): the past of the year is above it.
    LaunchedEffect(hijriYear) {
        if (current >= 0) list.scrollToItem(current / 2 + 1, -24) else list.scrollToItem(0)
    }
    val upcoming = remember(hijriYear, hijriOffset, today, current) {
        if (current < 0) emptyList()
        else IslamicDays.between(today, today.plusDays(400), hijriOffset)
            .filter { it.kind != DayKind.SEASON && !it.start.isBefore(today) }.take(3)
    }
    LazyColumn(
        state = list,
        modifier = modifier.fillMaxSize().testTag("year-view"),
        contentPadding = PaddingValues(start = ui.s(12f), end = ui.s(12f), top = 8.dp, bottom = bottomInset),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(key = "chips") { Chips(upcoming, today, onOpen) }
        itemsIndexed(rows, key = { _, pair -> pair.first().month }) { _, pair ->
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { m ->
                    MonthTile(
                        m, today, m.month == months.getOrNull(current)?.month, m.month in unfolded,
                        onToggle = { unfolded = if (m.month in unfolded) unfolded - m.month else unfolded + m.month },
                        onOpen = onOpen,
                        modifier = Modifier.weight(1f).fillMaxHeight().entrance(m.month, clock = clock)
                    )
                }
            }
        }
        item(key = "note") {
            Text(
                IslamicDayText.datesNote(hijriOffset), color = Paper.Ink3, fontSize = ui.t(11f), lineHeight = ui.t(16f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().paperCard(16.dp).padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    }
}

/** The sacred months' door, then the three next days with how far away they are. */
@Composable
private fun Chips(upcoming: List<DayOccurrence>, today: LocalDate, onOpen: (SheetTopic) -> Unit) {
    val ui = uiScale()
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        Chip(Modifier.pressClick(onClick = { onOpen(SheetTopic.Sacred) })) {
            Glyph(GlyphKind.INFO, Paper.Ink2, Modifier.size(13.dp))
            Spacer(Modifier.width(6.dp))
            Text(IslamicDayText.sacredTitle(), color = Paper.Ink, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
        upcoming.forEach { o ->
            val left = IslamicDays.daysBetween(today, o.start)
            Chip(Modifier.pressClick(onClick = { onOpen(SheetTopic.Day(o)) }).testTag("year-chip-${o.day.name}")) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(Paper.tone(o.kind)))
                Spacer(Modifier.width(6.dp))
                Text(IslamicDayText.tile(o.day), color = Paper.Ink, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold, maxLines = 1)
                Spacer(Modifier.width(6.dp))
                Text(
                    if (left <= 0L) tr("Сегодня") else tr("{0} дн.", left),
                    color = Paper.toneText(o.kind), fontSize = ui.t(11.5f), fontWeight = FontWeight.Bold, maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun Chip(modifier: Modifier, content: @Composable () -> Unit) {
    Row(
        modifier.height(uiScale().s(30f)).paperCard(15.dp).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) { content() }
}

private val Hexagon = GenericShape { size, _ ->
    val r = size.minDimension / 2f
    for (i in 0 until 6) {
        val a = Math.toRadians(60.0 * i - 90.0)
        val x = size.width / 2f + r * cos(a).toFloat()
        val y = size.height / 2f + r * sin(a).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

@Composable
private fun MonthTile(
    m: HijriMonthSpan, today: LocalDate, isCurrent: Boolean, unfolded: Boolean,
    onToggle: () -> Unit, onOpen: (SheetTopic) -> Unit, modifier: Modifier
) {
    val ui = uiScale()
    val past = m.end.isBefore(today)
    val shape = RoundedCornerShape(18.dp)
    val sacred = IslamicDays.isSacredMonth(m.month)
    val events = remember(m) { m.events.filter { it.day != IslamicDay.RAMADAN } }
    val shown = if (unfolded) events else events.take(SHOWN)
    val seasonTone = Paper.tone(DayKind.SEASON)
    Column(
        modifier.then(
            if (isCurrent) Modifier.clip(shape).background(Paper.Card, shape).background(seasonTone.copy(alpha = 0.10f), shape)
                .border(1.5.dp, seasonTone.copy(alpha = 0.85f), shape)
            else Modifier.paperCard(18.dp, if (past) Paper.Card.copy(alpha = 0.72f) else Paper.Card)
        ).padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 10.dp).testTag("hijri-month-${m.month}"),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(22.dp).clip(Hexagon).background(if (isCurrent) seasonTone else Paper.Ink.copy(alpha = if (past) 0.10f else 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Text(m.month.toString(), color = if (isCurrent) Color.White else Paper.Ink2, fontSize = ui.t(10f), fontWeight = FontWeight.Bold, maxLines = 1)
            }
            Spacer(Modifier.width(7.dp))
            Text(
                HijriCalendar.monthName(m.month).replaceFirstChar { it.uppercase() },
                color = if (past) Paper.Ink2 else Paper.Ink, fontSize = ui.t(13.2f), fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
            )
            if (sacred) {
                Spacer(Modifier.width(6.dp))
                Box(Modifier.size(6.dp).clip(CircleShape).border(1.4.dp, Paper.tone(DayKind.NIGHT), CircleShape))
            }
        }
        val total = m.end.toEpochDay() - m.start.toEpochDay() + 1
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${Format.dayMonth(m.start)} — ${Format.dayMonth(m.end)}", color = if (past) Paper.Ink3 else Paper.Ink2,
                fontSize = ui.t(10.5f), fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f)
            )
            if (!isCurrent) Text(tr("{0} дн.", total), color = Paper.Ink3, fontSize = ui.t(10.5f), maxLines = 1)
            else Text(tr("День {0} из {1}", today.toEpochDay() - m.start.toEpochDay() + 1, total),
                color = Paper.toneText(DayKind.SEASON), fontSize = ui.t(10.5f), fontWeight = FontWeight.Bold, maxLines = 1)
        }
        if (isCurrent) {
            Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Paper.Ink.copy(alpha = 0.11f))) {
                Box(Modifier.fillMaxWidth(m.progress(today)).height(5.dp).clip(RoundedCornerShape(3.dp)).background(seasonTone))
            }
        }
        shown.forEach { o -> TileEvent(o, today, onOpen) }
        if (events.size > SHOWN) {
            Row(
                Modifier.clip(RoundedCornerShape(8.dp)).pressClick(role = Role.Button, onClick = onToggle).padding(vertical = 2.dp, horizontal = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (unfolded) tr("Свернуть") else "${tr("Ещё")} ${events.size - SHOWN}",
                    color = Paper.Accent, fontSize = ui.t(10.5f), fontWeight = FontWeight.Bold, maxLines = 1
                )
                Spacer(Modifier.width(4.dp))
                Glyph(GlyphKind.CHEVRON, Paper.Accent, Modifier.size(9.dp).graphicsLayer { rotationZ = if (unfolded) -90f else 90f })
            }
        }
    }
}

/** A day in a tile: a coloured edge, the short name and a date plate. A past day fades. */
@Composable
private fun TileEvent(o: DayOccurrence, today: LocalDate, onOpen: (SheetTopic) -> Unit) {
    val ui = uiScale()
    val tone = Paper.tone(o.kind)
    val past = o.end.isBefore(today)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .pressClick(scaleTo = 0.97f, role = Role.Button, onClick = { onOpen(SheetTopic.Day(o)) })
            .graphicsLayer { alpha = if (past) 0.6f else 1f }
            .heightIn(min = 32.dp).testTag("event-${o.day.name}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(3.dp).fillMaxHeight().padding(vertical = 3.dp).background(tone, RoundedCornerShape(2.dp)))
        Text(
            IslamicDayText.tile(o.day), color = Paper.Ink, fontSize = ui.t(10.8f), fontWeight = FontWeight.SemiBold,
            maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = ui.t(12.5f),
            modifier = Modifier.weight(1f).padding(horizontal = 7.dp)
        )
        Column(
            Modifier.size(width = 32.dp, height = 28.dp).clip(RoundedCornerShape(9.dp)).background(tone.copy(alpha = if (o.contains(today)) 0.30f else 0.15f)),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Text(o.start.dayOfMonth.toString(), color = Paper.toneText(o.kind), fontSize = ui.t(12.5f), fontWeight = FontWeight.Bold, maxLines = 1, lineHeight = ui.t(13f))
            Text(Format.monthShort(o.start).uppercase(), color = Paper.toneText(o.kind), fontSize = ui.t(7.6f), fontWeight = FontWeight.Bold, maxLines = 1, lineHeight = ui.t(8f))
        }
    }
}

