package com.nur.prayer.ui.components

import com.nur.prayer.i18n.tr

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.Glass
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale

/*
 * Surfaces of the 0.6.0 design. Everything readable sits on one of three plates — [GlassCard]
 * (content), round/pill buttons (actions on the sky) and the per-prayer sheet — and every
 * secondary screen opens with the same [ScreenHeader], so "back" is always in the same place.
 */

/** The content card: dark glass, 24 dp corners, no border, no shadow. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    corner: Dp = 24.dp,
    color: Color = Glass,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(corner))
            .background(color),
        content = content
    )
}

/**
 * Title row of every secondary screen: a round back button on the left, the title, and an
 * optional trailing slot (place, action) on the right.
 */
@Composable
fun ScreenHeader(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    backLabel: String = tr("Назад"),
    trailing: @Composable RowScope.() -> Unit = {}
) {
    val ui = uiScale()
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = LocalIslandInset.current)
            .heightIn(min = 64.dp)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            RoundIconButton(GlyphKind.BACK, backLabel, onBack)
            Spacer(Modifier.width(ui.s(14f)))
        }
        AutoSizeText(
            text = title,
            color = TextPrimary,
            fontSize = ui.t(26f),
            minFontSize = ui.t(18f),
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
        trailing()
    }
}

/** A 48 dp round glass button carrying one glyph. The description is its accessible label. */
@Composable
fun RoundIconButton(
    kind: GlyphKind,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    tint: Color = TextPrimary,
    background: Color = SurfaceRaised
) {
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.92f else 1f, tween(90), label = "roundPress")
    Box(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(CircleShape)
            .background(background)
            .semantics { contentDescription = description }
            .clickable(interactionSource = interaction, indication = ripple(), role = Role.Button) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Glyph(kind, tint, Modifier.size(size * 0.42f))
    }
}

/** A capsule action on the sky: "КАЛЕНДАРЬ" on the home screen. */
@Composable
fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leading: GlyphKind? = null,
    background: Color = SurfaceRaised,
    contentColor: Color = TextPrimary
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, tween(90), label = "pillPress")
    Row(
        modifier = modifier
            .heightIn(min = 48.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(RoundedCornerShape(50))
            .background(background)
            .clickable(interactionSource = interaction, indication = ripple(), role = Role.Button) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(horizontal = ui.s(20f), vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) {
            Glyph(leading, contentColor, Modifier.size(18.dp))
            Spacer(Modifier.width(ui.s(8f)))
        }
        Text(
            text = text,
            color = contentColor,
            fontSize = ui.t(14f),
            fontWeight = FontWeight.Bold,
            letterSpacing = ui.t(0.6f),
            maxLines = 1
        )
    }
}

/** Small uppercase caption above a group, as in the sheet ("УВЕДОМЛЕНИЕ"). */
@Composable
fun GroupCaption(text: String, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Text(
        text = text.uppercase(),
        color = TextSecondary,
        fontSize = ui.t(12f),
        fontWeight = FontWeight.SemiBold,
        letterSpacing = ui.t(0.8f),
        modifier = modifier.fillMaxWidth().padding(start = 4.dp, bottom = 8.dp, top = 4.dp)
    )
}
