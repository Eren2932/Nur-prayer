package com.nur.prayer.ui

import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.Stable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.listSaver

internal const val TAB_HOME = "home"
internal const val TAB_SCHEDULE = "schedule"
internal const val TAB_QIBLA = "qibla"
internal const val TAB_SETTINGS = "settings"
internal const val ROUTE_CITY = "city"
internal val TABS = listOf(TAB_HOME, TAB_SCHEDULE, TAB_QIBLA, TAB_SETTINGS)
/** The layer pulled up from home, and the learning pages that open inside it. */
internal const val ROUTE_TODAY = "today"
internal const val ROUTE_COURSE = "course"
internal const val ROUTE_LESSON = "lesson"
internal const val ROUTE_DICTIONARY = "dictionary"
internal const val ROUTE_SURAH = "surah"
internal const val ROUTE_AZKAR = "azkar"
internal const val ROUTE_DHIKR = "dhikr"
internal const val ROUTE_STORY = "story"
/** The whole Quran: table of contents and the reader (0.16.0). */
internal const val ROUTE_QURAN = "quran"
internal val LAYER_ROUTES = listOf(ROUTE_TODAY, ROUTE_COURSE, ROUTE_LESSON, ROUTE_DICTIONARY, ROUTE_SURAH, ROUTE_AZKAR, ROUTE_DHIKR, ROUTE_STORY, ROUTE_QURAN)
private fun known(route: String) = route in TABS || route == ROUTE_CITY || route in LAYER_ROUTES

/** Bounded, validated history with home always at its base. Restored together with each route's saveable UI state. */
@Stable
internal class NurNavigator(initial: String = TAB_HOME, history: List<String> = emptyList()) {
    var current by mutableStateOf(initial.takeIf { known(it) } ?: TAB_HOME)
        private set
    private val stack = mutableStateListOf<String>().apply {
        addAll(history.filter { known(it) && it != current }.distinct().takeLast(12))
        // 0.6.0 has no dock: home is the only way out, so every other route keeps it at the base.
        if (current != TAB_HOME && firstOrNull() != TAB_HOME) { remove(TAB_HOME); add(0, TAB_HOME) }
    }
    val canGoBack get() = stack.isNotEmpty()
    val selectedTab get() = if (current in TABS) current else stack.lastOrNull { it in TABS } ?: TAB_HOME
    val isOverlay get() = current !in TABS
    fun go(destination: String) {
        if (destination == current || !known(destination)) return
        if (destination == TAB_HOME) { stack.clear(); current = TAB_HOME; return }
        stack.remove(destination)
        stack.add(current)
        while (stack.size > 12) stack.removeAt(0)
        current = destination
    }
    /**
     * 0.27.0: a section chosen from the capsule panel replaces the one on screen instead of piling
     * on top of it: home stays the only thing underneath, so back (and the moon) always lead home.
     */
    fun switchTo(destination: String) {
        if (destination == current || !known(destination)) return
        stack.clear()
        if (destination != TAB_HOME) stack.add(TAB_HOME)
        current = destination
    }
    fun back(): Boolean {
        if (stack.isEmpty()) return false
        current = stack.removeAt(stack.lastIndex)
        return true
    }
    /** Whether the pulled-up layer is showing: the today page itself or a learning page above it. */
    val layerOpen get() = current in LAYER_ROUTES
    fun snapshot(): List<String> = listOf(current) + stack
    companion object {
        val Saver = listSaver<NurNavigator, String>(save = { it.snapshot() },
            restore = { NurNavigator(it.firstOrNull() ?: TAB_HOME, it.drop(1)) })
    }
}
