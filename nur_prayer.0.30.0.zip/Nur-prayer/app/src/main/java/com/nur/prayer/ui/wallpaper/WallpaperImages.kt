package com.nur.prayer.ui.wallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.ceil
import kotlin.math.floor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 0.22.0: the pictures in memory.
 *
 * Every picture is decoded at the size it is drawn at — never more (a 2560 px asset drawn into a
 * 110 dp tile is sampled by 4 or 8), and in ARGB_8888 (RGB_565 bands a gradient sky). Bitmaps live in
 * one LRU sized from the heap, so the gallery can scroll back and forth without decoding again.
 * All decoding happens on Dispatchers.IO; the UI only ever reads finished bitmaps.
 */
object WallpaperImages {

    /** The contrast scrim of a picture on one screen: [WallpaperContrast.ROWS] alphas and its tint. */
    class Scrim(val alphas: FloatArray, val tint: Int)

    private val bitmaps = object : LruCache<String, ImageBitmap>(cacheKb()) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = (value.width * value.height * 4 / 1024).coerceAtLeast(1)
    }
    private val scrims = LruCache<String, Scrim>(48)
    private val bounds = ConcurrentHashMap<String, IntArray>()

    private fun cacheKb(): Int = (Runtime.getRuntime().maxMemory() / 1024 / 6).toInt().coerceIn(16 * 1024, 96 * 1024)

    /** Already decoded for this target size, or null: lets a tile draw on its very first frame. */
    fun peek(wallpaper: Wallpaper, width: Int, height: Int): ImageBitmap? {
        if (!wallpaper.isImage || width <= 0 || height <= 0) return null
        val b = bounds[wallpaper.id] ?: return null
        return bitmaps.get(key(wallpaper, sampleFor(wallpaper, b, width, height)))
    }

    /**
     * 0.23.0: the sharpest copy of [wallpaper] already in memory, at any size. A card that grows out
     * of a tile draws the tile's copy on its first frame instead of an empty one (that was the flash
     * and the "jerk" when a preview opened), and swaps to its own size once that is decoded.
     */
    fun peekAny(wallpaper: Wallpaper): ImageBitmap? {
        if (!wallpaper.isImage) return null
        val prefix = wallpaper.id + "@"
        var best: ImageBitmap? = null
        for ((k, v) in bitmaps.snapshot()) {
            if (k.startsWith(prefix) && (best == null || v.width > best.width)) best = v
        }
        return best
    }

    fun peekScrim(wallpaper: Wallpaper, width: Int, height: Int): Scrim? =
        if (!wallpaper.isImage) null else scrims.get(scrimKey(wallpaper, width, height))

    /** The picture sampled for a [width]×[height] px target (decodes once, then from the cache). */
    suspend fun load(context: Context, wallpaper: Wallpaper, width: Int, height: Int): ImageBitmap? {
        if (!wallpaper.isImage || width <= 0 || height <= 0) return null
        return withContext(Dispatchers.IO) {
            runCatching {
                val b = boundsOf(context, wallpaper) ?: return@runCatching null
                val sample = sampleFor(wallpaper, b, width, height)
                val key = key(wallpaper, sample)
                bitmaps.get(key) ?: decode(context, wallpaper, sample)?.also { bitmaps.put(key, it) }
            }.getOrNull()
        }
    }

    /**
     * The scrim of [wallpaper] on a [width]×[height] px screen. Measured on a ~100 px copy of the
     * picture: the scrim is 24 slabs tall, more pixels would only cost time.
     */
    suspend fun scrim(context: Context, wallpaper: Wallpaper, width: Int, height: Int): Scrim? {
        if (!wallpaper.isImage || width <= 0 || height <= 0) return null
        val key = scrimKey(wallpaper, width, height)
        scrims.get(key)?.let { return it }
        return withContext(Dispatchers.Default) {
            runCatching {
                val b = boundsOf(context, wallpaper) ?: return@runCatching null
                var sample = 1
                while (b[0] / (sample * 2) >= SCRIM_WIDTH) sample *= 2
                val small = decodeRaw(context, wallpaper, sample) ?: return@runCatching null
                val w = small.width
                val h = small.height
                val pixels = IntArray(w * h)
                small.getPixels(pixels, 0, w, 0, 0, w, h)
                small.recycle()
                val fit = WallpaperFit.fit(w.toFloat(), h.toFloat(), width.toFloat(), height.toFloat(), wallpaper.focusX, wallpaper.focusY)
                val tint = WallpaperContrast.tintOf(pixels)
                Scrim(WallpaperContrast.scrim(pixels, w, h, fit, width.toFloat(), height.toFloat(), tint), tint)
                    .also { scrims.put(key, it) }
            }.getOrNull()
        }
    }

    private const val SCRIM_WIDTH = 96

    /*
     * 0.27.0: the frosted glass of the capsule, the panel and the island.
     *
     * Compose cannot blur what lies *behind* a view on every Android version, so the glass carries
     * its own copy of the backdrop: the picture shrunk so one of its pixels covers [FROST_DIVISOR]
     * screen pixels, then blurred three times with a box of [FROST_RADIUS] (≈ a gaussian). Drawn
     * stretched under the glass at exactly the place the sharp picture is on screen, it reads as
     * the wallpaper seen through matte glass. About 40 × 90 px: built once per picture and screen,
     * in a few milliseconds, off the UI thread.
     */
    private val frosts = LruCache<String, ImageBitmap>(6)

    fun peekFrost(wallpaper: Wallpaper, width: Int, height: Int): ImageBitmap? =
        if (!wallpaper.isImage) null else frosts.get(frostKey(wallpaper, width, height))

    suspend fun frost(context: Context, wallpaper: Wallpaper, width: Int, height: Int): ImageBitmap? {
        if (!wallpaper.isImage || width <= 0 || height <= 0) return null
        val key = frostKey(wallpaper, width, height)
        frosts.get(key)?.let { return it }
        return withContext(Dispatchers.Default) {
            runCatching {
                val b = boundsOf(context, wallpaper) ?: return@runCatching null
                val fit = WallpaperFit.fit(b[0].toFloat(), b[1].toFloat(), width.toFloat(), height.toFloat(), wallpaper.focusX, wallpaper.focusY)
                // Size of the whole picture as drawn on this screen, divided down.
                val tw = (b[0] * fit.scale / FROST_DIVISOR).toInt().coerceIn(8, 512)
                val th = (b[1] * fit.scale / FROST_DIVISOR).toInt().coerceIn(8, 1024)
                var sample = 1
                while (b[0] / (sample * 2) >= tw * 2 && b[1] / (sample * 2) >= th * 2) sample *= 2
                val raw = decodeRaw(context, wallpaper, sample) ?: return@runCatching null
                val small = Bitmap.createScaledBitmap(raw, tw, th, true)
                if (small !== raw) raw.recycle()
                val pixels = IntArray(tw * th)
                small.getPixels(pixels, 0, tw, 0, 0, tw, th)
                repeat(3) { FrostBlur.blur(pixels, tw, th, FROST_RADIUS) }
                val out = if (small.isMutable) small else small.copy(Bitmap.Config.ARGB_8888, true).also { small.recycle() }
                out.setPixels(pixels, 0, tw, 0, 0, tw, th)
                out.prepareToDraw()
                out.asImageBitmap().also { frosts.put(key, it) }
            }.getOrNull()
        }
    }

    private fun frostKey(wallpaper: Wallpaper, width: Int, height: Int) = "${wallpaper.id}~${width}x$height"
    private const val FROST_DIVISOR = 10f
    private const val FROST_RADIUS = 3

    private fun key(wallpaper: Wallpaper, sample: Int) = "${wallpaper.id}@$sample"
    private fun scrimKey(wallpaper: Wallpaper, width: Int, height: Int) = "${wallpaper.id}:${width}x$height"

    private fun sampleFor(wallpaper: Wallpaper, b: IntArray, width: Int, height: Int): Int {
        val fit = WallpaperFit.fit(b[0].toFloat(), b[1].toFloat(), width.toFloat(), height.toFloat(), wallpaper.focusX, wallpaper.focusY)
        return WallpaperFit.sampleSize(fit.scale)
    }

    private fun boundsOf(context: Context, wallpaper: Wallpaper): IntArray? {
        bounds[wallpaper.id]?.let { return it }
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.assets.open(wallpaper.asset).use { BitmapFactory.decodeStream(it, null, options) }
        if (options.outWidth <= 0 || options.outHeight <= 0) return null
        return intArrayOf(options.outWidth, options.outHeight).also { bounds[wallpaper.id] = it }
    }

    private fun decodeRaw(context: Context, wallpaper: Wallpaper, sample: Int): Bitmap? {
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return context.assets.open(wallpaper.asset).use { BitmapFactory.decodeStream(it, null, options) }
    }

    private fun decode(context: Context, wallpaper: Wallpaper, sample: Int): ImageBitmap? {
        val bitmap = decodeRaw(context, wallpaper, sample) ?: return null
        // Upload once now, on the IO thread, instead of on the first frame that draws it.
        bitmap.prepareToDraw()
        return bitmap.asImageBitmap()
    }
}

/**
 * Size of the screen the wallpaper is drawn on, in px — reported by the backdrop itself, so
 * thumbnails and previews take exactly its proportions (a tile is a miniature of *this* phone).
 */
object WallpaperScreen {
    val size = mutableStateOf(IntSize.Zero)

    private class RevealRequest(val id: String, val origin: Offset, val at: Long)

    @Volatile private var request: RevealRequest? = null

    /**
     * 0.23.0: the user just chose [id] at [origin] (root px): the backdrops that change to it grow it
     * out of that point as a circle. Any change *without* a fresh request — the stored wallpaper
     * arriving at launch, a restore — is not a "set": it is shown quietly, with no circle.
     * Not consumed: the home backdrop and the gallery's backdrop both read it.
     */
    fun requestReveal(id: String, origin: Offset) {
        request = RevealRequest(id, origin, android.os.SystemClock.uptimeMillis())
    }

    /** The origin of a fresh user change to [id] (may be Unspecified: "from the default point"), or null. */
    fun revealFor(id: String): Offset? {
        val r = request ?: return null
        if (r.id != id || android.os.SystemClock.uptimeMillis() - r.at > REVEAL_REQUEST_MILLIS) return null
        return r.origin
    }

    private const val REVEAL_REQUEST_MILLIS = 4000L

    fun aspect(fallbackWidth: Int, fallbackHeight: Int): Float {
        val s = size.value
        return if (s.width > 0 && s.height > 0) s.width.toFloat() / s.height
        else if (fallbackWidth > 0 && fallbackHeight > 0) fallbackWidth.toFloat() / fallbackHeight else 9f / 19.5f
    }
}

/*
 * 0.23.0: the state is keyed, not just the loader. produceState applies its initial value once, on
 * the first composition only: when the same layer switched from wallpaper A to B the state still
 * held A's bitmap, `value == null` was false, B was never loaded — the backdrop kept the old picture
 * until the app was restarted. A new key now means a new state, starting from B's cache.
 */
@Composable
internal fun rememberWallpaperBitmap(wallpaper: Wallpaper, width: Int, height: Int): State<ImageBitmap?> {
    val context = LocalContext.current.applicationContext
    val state = remember(wallpaper.id, width, height) { mutableStateOf(WallpaperImages.peek(wallpaper, width, height)) }
    LaunchedEffect(state) {
        if (state.value == null) state.value = WallpaperImages.load(context, wallpaper, width, height)
    }
    return state
}

@Composable
internal fun rememberWallpaperScrim(wallpaper: Wallpaper, width: Int, height: Int): State<WallpaperImages.Scrim?> {
    val context = LocalContext.current.applicationContext
    val state = remember(wallpaper.id, width, height) { mutableStateOf(WallpaperImages.peekScrim(wallpaper, width, height)) }
    LaunchedEffect(state) {
        if (state.value == null) state.value = WallpaperImages.scrim(context, wallpaper, width, height)
    }
    return state
}

/**
 * Draws [bitmap] the way [WallpaperFit] says. On a phone the picture covers the screen and is drawn
 * as an image (high-quality filtering); on a wide screen the strips beyond its edges are filled by
 * its own edge pixels through a clamping shader.
 */
internal fun DrawScope.drawWallpaper(bitmap: ImageBitmap, wallpaper: Wallpaper, filterQuality: FilterQuality = FilterQuality.High) =
    drawWallpaperIn(bitmap, wallpaper, size.width, size.height, filterQuality)

/** [drawWallpaper] for a screen of [w]×[h] px whose top-left is this scope's origin (the frosted glass). */
internal fun DrawScope.drawWallpaperIn(
    bitmap: ImageBitmap,
    wallpaper: Wallpaper,
    w: Float,
    h: Float,
    filterQuality: FilterQuality = FilterQuality.High,
    alpha: Float = 1f
) {
    if (w <= 0f || h <= 0f || alpha <= 0f) return
    val bw = bitmap.width.toFloat()
    val bh = bitmap.height.toFloat()
    val fit = WallpaperFit.fit(bw, bh, w, h, wallpaper.focusX, wallpaper.focusY)
    val drawnW = bw * fit.scale
    val drawnH = bh * fit.scale
    if (drawnW >= w - 0.5f && drawnH >= h - 0.5f) {
        val left = floor(fit.dx).toInt()
        val top = floor(fit.dy).toInt()
        drawImage(
            bitmap,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(bitmap.width, bitmap.height),
            dstOffset = IntOffset(left, top),
            dstSize = IntSize(ceil(drawnW + fit.dx - left).toInt(), ceil(drawnH + fit.dy - top).toInt()),
            alpha = alpha,
            filterQuality = filterQuality
        )
    } else {
        val brush = ShaderBrush(ImageShader(bitmap, TileMode.Clamp, TileMode.Clamp))
        val s = fit.scale
        val dx = fit.dx
        val dy = fit.dy
        withTransform({
            translate(dx, dy)
            scale(s, s, pivot = Offset.Zero)
        }) {
            drawRect(brush, topLeft = Offset(-dx / s, -dy / s), size = Size(w / s, h / s), alpha = alpha)
        }
    }
}

/** The contrast scrim as one vertical gradient, stops at the slab centres (see [WallpaperContrast]). */
internal fun DrawScope.drawScrim(scrim: WallpaperImages.Scrim, strength: Float = 1f) {
    val tint = Color(scrim.tint)
    val n = scrim.alphas.size
    if (n == 0) return
    val stops = Array(n) { i -> ((i + 0.5f) / n) to tint.copy(alpha = (scrim.alphas[i] * strength).coerceIn(0f, 1f)) }
    drawRect(Brush.verticalGradient(*stops))
}
