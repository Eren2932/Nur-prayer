package com.nur.prayer.ui.shell

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.isSpecified
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.Amber
import com.nur.prayer.ui.wallpaper.PAGE_DIM
import com.nur.prayer.ui.wallpaper.Wallpaper
import com.nur.prayer.ui.wallpaper.WallpaperImages
import com.nur.prayer.ui.wallpaper.WallpaperScreen
import com.nur.prayer.ui.wallpaper.drawWallpaperIn

/*
 * 0.27.1: the matte glass of the capsule, the panel, the island and the sheets: re-measured on the mock.
 *
 * 0.27.0 read the mock by eye and got it wrong: a glass at 72–82 % over a *lighter* blurred picture came
 * out grey (#545358 on the Kaaba wallpaper, the mock is #121522), a vertical gradient with a bright top
 * edge and a deep shadow made the capsule look puffed up. The mock is the opposite: almost opaque deep
 * navy, flat, with one even 1 dp hairline and no visible shadow. So now, layer by layer:
 *
 *  1. the wallpaper blurred (WallpaperImages.frost), drawn exactly where the sharp picture is on screen;
 *  2. black over it, [ShellColors.PICTURE_DIM] at least (more where a page darkens the picture): the glass
 *     is the same dark over a white wallpaper as over a black one;
 *  3. the tint, #12141F → #0F111B at 90 %: a 3-level gradient, not a bulge;
 *  4. a 1 dp hairline of the same 14 % white all the way round;
 *  5. outside: a very faint halo, three flat low-alpha plates (no elevation shadow: its mesh is rebuilt
 *     every frame while the shape morphs and that was a part of the lag).
 *
 * Layers 1–4 are drawn inside the clip of the shape (a rounded rectangle, hardware-clipped), so there is
 * no per-frame Path and no stencil. On «Живое небо» and «Чёрный» there is no picture to blur: the tint
 * alone, nearly opaque.
 */

/** What the glass shows through: the wallpaper on screen and how much the current page darkens it. */
@Stable
class FrostSource(val wallpaper: () -> Wallpaper, val dim: () -> Float)

val LocalFrost = staticCompositionLocalOf<FrostSource?> { null }

/** The colours of the mock, measured from its pixels (glass, hairline, cards, wells, the gold of «now»). */
object ShellColors {
    /** Measured: #141521 at the top of the capsule, #11131F at the bottom, with a little wallpaper under. */
    val TintTop = Color(0xFF12141F)
    val TintBottom = Color(0xFF0F111B)
    const val TINT_ALPHA = 0.90f
    const val TINT_PLAIN_ALPHA = 0.96f
    /** Black over the blurred picture before the tint: a light wallpaper must not lift the glass. */
    const val PICTURE_DIM = ShellMath.PICTURE_DIM
    /** Measured hairline: #30333F on #121522, i.e. 13–14 % white, even all round. */
    val Edge = Color(0x24FFFFFF)
    val Card = Color(0x17FFFFFF)
    val CardPressed = Color(0x29FFFFFF)
    val Well = Color(0x21FFFFFF)
    val Divider = Color(0x24FFFFFF)
    val Gold = Amber
    val GoldCard = Color(0xFFE2B572)
    val OnGold = Color(0xFF261A09)
    val Secondary = Color(0xFFC9CAD6)
}

/** One handle per glass surface: the blurred picture and where on screen the surface is. */
@Stable
class FrostHandle internal constructor(internal val source: FrostSource?) {
    internal var bitmap by mutableStateOf<ImageBitmap?>(null)
    internal var wallpaper by mutableStateOf<Wallpaper?>(null)
    internal var originInRoot by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberFrost(): FrostHandle {
    val source = LocalFrost.current
    val handle = remember(source) { FrostHandle(source) }
    val context = LocalContext.current
    val wallpaper = source?.wallpaper?.invoke()
    val screen by WallpaperScreen.size
    LaunchedEffect(handle, wallpaper?.id, screen) {
        handle.wallpaper = wallpaper
        if (wallpaper == null || !wallpaper.isImage) {
            handle.bitmap = null
            return@LaunchedEffect
        }
        handle.bitmap = WallpaperImages.peekFrost(wallpaper, screen.width, screen.height)
            ?: WallpaperImages.frost(context, wallpaper, screen.width, screen.height)
    }
    return handle
}

/**
 * Paints the glass of [shape] behind the content of this element and clips the content to it. Read
 * only while drawing: a panel that changes size every frame redraws, it does not recompose.
 *
 *  - [halo]: the faint plates outside the shape. Off for a sheet that touches the screen edges.
 *  - [track]: the glass follows where it is on screen by itself (onGloballyPositioned). A surface that
 *    is moved by a layer transform (a sheet sliding up) sets it off and sets [FrostHandle.originInRoot] itself.
 *  - [wash]: a colour laid very lightly over the tint (the prayer sheet carries the colour of its sky).
 */
fun Modifier.frostGlass(
    frost: FrostHandle,
    shape: Shape,
    halo: Boolean = true,
    track: Boolean = true,
    edge: Boolean = true,
    wash: Color = Color.Unspecified
): Modifier = this
    .then(if (halo) Modifier.glassHalo(shape) else Modifier)
    .then(if (track) Modifier.onGloballyPositioned { frost.originInRoot = it.positionInRoot() } else Modifier)
    .clip(shape)
    .drawBehind {
        val bitmap = frost.bitmap
        val wallpaper = frost.wallpaper
        val screen = WallpaperScreen.size.value
        val picture = bitmap != null && wallpaper != null && screen.width > 0 && screen.height > 0
        if (picture) {
            val o = frost.originInRoot
            translate(-o.x, -o.y) {
                drawWallpaperIn(bitmap!!, wallpaper!!, screen.width.toFloat(), screen.height.toFloat(), FilterQuality.Low)
            }
            drawRect(Color.Black.copy(alpha = ShellMath.pictureDim(frost.source?.dim?.invoke() ?: 0f, PAGE_DIM)))
        }
        val a = if (picture) ShellColors.TINT_ALPHA else ShellColors.TINT_PLAIN_ALPHA
        drawRect(Brush.verticalGradient(listOf(ShellColors.TintTop.copy(alpha = a), ShellColors.TintBottom.copy(alpha = a))))
        if (wash.isSpecified) drawRect(wash.copy(alpha = WASH_ALPHA))
        if (edge) {
            // Twice the hairline, centred on the outline: the half outside the clip is cut, 1 dp stays.
            drawOutline(
                shape.createOutline(size, layoutDirection, this),
                ShellColors.Edge,
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }

private const val WASH_ALPHA = 0.20f

/** Three flat, very faint plates around a rounded shape: enough to lift it off the picture, nothing more. */
private fun Modifier.glassHalo(shape: Shape): Modifier = drawBehind {
    val outline = shape.createOutline(size, layoutDirection, this)
    if (outline !is Outline.Rounded) return@drawBehind
    val box = outline.roundRect
    val r = box.topLeftCornerRadius.x
    HALO.forEach { plate ->
        val grow = plate.grow.dp.toPx()
        drawRoundRect(
            Color.Black.copy(alpha = plate.alpha),
            topLeft = Offset(box.left - grow, box.top - grow + plate.drop.dp.toPx()),
            size = Size(box.width + 2f * grow, box.height + 2f * grow),
            cornerRadius = CornerRadius(r + grow)
        )
    }
}

private class Plate(val grow: Float, val drop: Float, val alpha: Float)

private val HALO = listOf(Plate(2f, 3f, 0.10f), Plate(6f, 6f, 0.06f), Plate(11f, 9f, 0.035f))
