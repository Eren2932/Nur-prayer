package com.nur.prayer.ui.qibla

import com.nur.prayer.i18n.tr

import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Pure presentation policy.
 *
 * 0.23.0: the hold no longer matters (see [forwardAzimuth]), so "lay the phone flat" is gone. Two
 * levels of trust remain:
 *  - *usable* — the dial may point: turn instructions are shown;
 *  - *trustworthy* — calibrated as well: only then is "you face the Kaaba" confirmed.
 * Confirmation has hysteresis: it is entered within [ALIGN_TOLERANCE] and kept until [RELEASE_TOLERANCE],
 * so hand tremor at the edge does not make it blink (and buzz).
 */
object QiblaGuidance {
    const val ALIGN_TOLERANCE = 2.5f
    const val RELEASE_TOLERANCE = 4.5f

    fun aligned(delta: Float, available: Boolean, trustworthy: Boolean, wasAligned: Boolean = false): Boolean =
        delta.isFinite() && available && trustworthy &&
            abs(delta) <= (if (wasAligned) RELEASE_TOLERANCE else ALIGN_TOLERANCE)

    fun instruction(delta: Float, available: Boolean, usable: Boolean, trustworthy: Boolean): String = when {
        !available -> tr("Компас недоступен")
        !delta.isFinite() || !usable -> tr("Проверьте калибровку и помехи")
        abs(delta) <= ALIGN_TOLERANCE && trustworthy -> tr("Направление на Каабу")
        abs(delta) <= ALIGN_TOLERANCE -> tr("Почти на Каабу — откалибруйте компас")
        delta > 0f -> tr("Поверните вправо на {0}°", abs(delta).roundToInt())
        else -> tr("Поверните влево на {0}°", abs(delta).roundToInt())
    }

    /** Index of the 16-wind rose (0 = N, 4 = E, 8 = S, 12 = W) a bearing falls in: 22.5° sectors centred on the winds. */
    fun windIndex(bearing: Float): Int {
        if (!bearing.isFinite()) return 0
        return (Math.floor(((normalize(bearing) + 11.25f) / 22.5f).toDouble()).toInt()) % 16
    }

    /** «юго-юго-запад»: the name of the wind a bearing points to. */
    fun windName(bearing: Float): String = when (windIndex(bearing)) {
        0 -> tr("север")
        1 -> tr("северо-северо-восток")
        2 -> tr("северо-восток")
        3 -> tr("восток-северо-восток")
        4 -> tr("восток")
        5 -> tr("восток-юго-восток")
        6 -> tr("юго-восток")
        7 -> tr("юго-юго-восток")
        8 -> tr("юг")
        9 -> tr("юго-юго-запад")
        10 -> tr("юго-запад")
        11 -> tr("запад-юго-запад")
        12 -> tr("запад")
        13 -> tr("запад-северо-запад")
        14 -> tr("северо-запад")
        else -> tr("северо-северо-запад")
    }

    fun degrees(value: Float): String = if (value.isFinite()) "${normalize(value).roundToInt() % 360}°" else "—"
}
