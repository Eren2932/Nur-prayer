package com.nur.prayer.ui.schedule

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.home.HomeTimeline
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SystemBarsTone
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.findActivity
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.abs

/*
 * 0.19.0 — the calendar around three readings of time:
 *
 *   Год     — the hijri year: twelve months with their Gregorian bounds and the days of the year (YearView);
 *   Месяц   — the grid with the days of the year painted in, and the card of the selected day;
 *   Таблица — the month as a timetable, one row per day (MonthTable), shared as a picture.
 *
 * 0.28.0 — redesigned as paper: two thin bars on top and light cards on the picture. Each tab is a file of its
 * own (YearView, MonthCalendar + DayCard, MonthTable); this file holds the state and the bars.
 *
 * 0.29.0 — turned with a finger. No arrows, no place: the three tabs are pages of two pagers (the months for
 * «Месяц» and «Таблица», the Hijri years for «Год», see PeriodPager) and the period bar above them follows
 * the thumb. The bottom capsule steps aside while the calendar is open (ShellRoutes.capsuleOn), so the
 * cards run down to the system bar and no further: the last day is the last row, not hidden behind anything.
 * The way out is the island above (it is home) or the back gesture.
 *
 * A tap on the title of the period raises the drums (PeriodPicker); a tap on a day of the year opens its
 * sheet (DaySheet). Both are overlays of this screen, so the back gesture closes them first.
 */

/** Order of the tabs; the index is what is saved. */
internal object CalendarTabs {
    const val YEAR = 0
    const val MONTH = 1
    const val TABLE = 2
}

/** The colours of the text that stands on the backdrop itself (the period title, the weekday letters). */
private class BackdropInk(val title: Color, val subtitle: Color, val label: Color, val friday: Color)

private fun backdropInk(light: Boolean, palette: PhasePalette): BackdropInk =
    if (light) BackdropInk(Paper.Ink, Paper.Accent, Paper.Ink3, Paper.Accent)
    else BackdropInk(TextPrimary, palette.accentSoft, TextTertiary, palette.accentSoft)

/**
 * The timetables of the months the pager has seen. A page asks for its month, the cache computes it once off the
 * main thread and keeps only the months near the one just added: swiping through ten years must not keep ten years.
 */
@Stable
internal class MonthTimesCache(private val compute: suspend (YearMonth) -> MonthTimes?) {
    private val months = mutableStateMapOf<YearMonth, MonthTimes>()
    private val pending = HashSet<YearMonth>()

    operator fun get(month: YearMonth): MonthTimes? = months[month]

    suspend fun ensure(month: YearMonth) {
        if (months.containsKey(month) || !pending.add(month)) return
        try {
            val times = compute(month) ?: return
            months[month] = times
            if (months.size > KEEP) {
                months.keys.filter { abs(ChronoUnit.MONTHS.between(it, month)) > NEAR }.forEach { months.remove(it) }
            }
        } finally {
            pending.remove(month)
        }
    }

    private companion object {
        const val KEEP = 7
        const val NEAR = 3L
    }
}

@Composable
fun ScheduleScreen(
    data: PrayerData, now: State<ZonedDateTime>, palette: PhasePalette,
    modifier: Modifier = Modifier,
    /** True while the wallpaper under the page is a light picture: the text on it is dark, the bars' icons too. */
    lightBackdrop: Boolean = false
) {
    val today = data.today.date
    val hijriOffset = data.settings.hijriOffset
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var tab by rememberSaveable { mutableIntStateOf(CalendarTabs.MONTH) }
    var monthText by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(YearMonth.from(today).toString()) }
    var selectedEpoch by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(today.toEpochDay()) }
    var hijriYear by rememberSaveable(today.toEpochDay(), hijriOffset) { mutableIntStateOf(IslamicDays.hijriOf(today, hijriOffset).year) }
    var picker by rememberSaveable { mutableStateOf(false) }
    // A DayOccurrence is not Parcelable: the sheet is closed after a rotation, which is the honest state.
    var topic by remember { mutableStateOf<SheetTopic?>(null) }
    val month = YearMonth.parse(monthText)
    val selectedDate = LocalDate.ofEpochDay(selectedEpoch)
    fun goMonth(target: YearMonth) {
        if (target == month) return
        monthText = target.toString()
        selectedEpoch = CalendarMonthModel.moveSelection(selectedDate, target).toEpochDay()
    }

    // On a light picture the status-bar icons turn dark, or the clock and battery vanish into the cream.
    val view = LocalView.current
    // The holder is released the moment the page stops being light (the route changes), not when its exit
    // animation ends, so the next screen's own tone is never overwritten.
    val barsOwner = remember { Any() }
    DisposableEffect(lightBackdrop) {
        val window = view.context.findActivity()?.window
        if (lightBackdrop) SystemBarsTone.hold(window, barsOwner)
        onDispose { SystemBarsTone.release(window, barsOwner) }
    }

    // The timetables: a table page shows its month, the share button sends the one in front. 31 solar days are cheap.
    val columns = remember(data.fajrEqualsDawn) { HomeTimeline.prayers(data.fajrEqualsDawn) }
    val timesCache = remember(data.place, data.params, columns) {
        MonthTimesCache { m ->
            try {
                withContext(Dispatchers.Default) {
                    MonthTimes(m, PrayerEngine.days(m.atDay(1), m.lengthOfMonth(), data.place.coordinates, data.place.zone, data.params), columns)
                }
            } catch (cancel: CancellationException) { throw cancel } catch (_: Exception) { null }
        }
    }
    LaunchedEffect(month, timesCache) { timesCache.ensure(month) }
    val monthTimes = timesCache[month]
    var sharing by remember { mutableStateOf(false) }
    val shareFailed = tr("Не удалось подготовить картинку")
    val share: () -> Unit = share@{
        val t = monthTimes ?: return@share
        if (sharing) return@share
        sharing = true
        val spec = calendarShareSpec(t, today, hijriOffset, data.place.label, palette)
        scope.launch {
            val ok = CalendarImageShare.share(context, spec)
            sharing = false
            if (!ok) Toast.makeText(context, shareFailed, Toast.LENGTH_SHORT).show()
        }
    }

    // The pages. The state above stays the one truth; each pager reports a settled page and follows a changed period.
    val yearTab = tab == CalendarTabs.YEAR
    val gregorian = remember(today) { PeriodRange.gregorianYears(today) }
    val firstMonth = YearMonth.of(gregorian.first, 1)
    val monthCount = PeriodPages.monthCount(firstMonth, YearMonth.of(gregorian.last, 12))
    val hijriYears = remember(today, hijriOffset) { PeriodRange.hijriYears(today, hijriOffset) }
    val yearCount = hijriYears.last - hijriYears.first + 1
    val monthPager = rememberPeriodPager(PeriodPages.monthPage(firstMonth, month, monthCount), monthCount) { page ->
        goMonth(PeriodPages.monthAt(firstMonth, page))
    }
    val yearPager = rememberPeriodPager(PeriodPages.yearPage(hijriYears.first, hijriYear, yearCount), yearCount) { page ->
        hijriYear = hijriYears.first + page
    }
    // The grid views are Месяц and Таблица. Going to Год keeps the one that was in front, so the page that is
    // leaving does not swap its view while it fades out.
    val lastGrid = remember { IntArray(1) { CalendarTabs.MONTH } }
    if (tab != CalendarTabs.YEAR) lastGrid[0] = tab
    val gridTab = lastGrid[0]
    val ink = backdropInk(lightBackdrop, palette)
    // The cards end above the system bar with a normal margin: the capsule is not there to be run behind.
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 12.dp

    Box(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            CalendarTopBar(
                tab = tab, onTab = { tab = it },
                shareEnabled = !yearTab && monthTimes != null && !sharing, onShare = share
            )
            Spacer(Modifier.height(10.dp))
            PeriodBar(
                pager = if (yearTab) yearPager else monthPager,
                title = { page ->
                    if (yearTab) tr("{0} год хиджры", hijriYears.first + page)
                    else PeriodPages.monthAt(firstMonth, page).let { "${Format.monthName(it.monthValue)} ${it.year}" }
                },
                subtitle = { page ->
                    if (yearTab) yearSpan(hijriYears.first + page, hijriOffset)
                    else PeriodPages.monthAt(firstMonth, page).let { HijriCalendar.span(it.atDay(1), it.atEndOfMonth(), hijriOffset) }
                },
                onPick = { picker = true },
                ink = ink.title, subInk = ink.subtitle
            )
            Spacer(Modifier.height(8.dp))
            AnimatedContent(
                targetState = yearTab,
                transitionSpec = {
                    val forward = !targetState
                    (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { w -> if (forward) w / 6 else -w / 6 } +
                        fadeIn(tween(260, delayMillis = 40))) togetherWith
                        (slideOutHorizontally(tween(240)) { w -> if (forward) -w / 8 else w / 8 } + fadeOut(tween(160)))
                },
                label = "calendarTab",
                modifier = Modifier.weight(1f).fillMaxSize()
            ) { year ->
                if (year) PeriodPager(yearPager, Modifier.testTag("year-pager")) { page ->
                    YearView(
                        hijriYears.first + page, today, hijriOffset,
                        bottomInset = bottomInset,
                        onOpen = { topic = it }
                    )
                } else PeriodPager(monthPager, Modifier.testTag("calendar-pager")) { page ->
                    val pageMonth = PeriodPages.monthAt(firstMonth, page)
                    // A neighbour page shows the day that will be selected when the page arrives, so the leaf is
                    // whole while it turns, and landing on it changes nothing under the thumb.
                    val pageSelected = if (pageMonth == month) selectedDate else CalendarMonthModel.moveSelection(selectedDate, pageMonth)
                    AnimatedContent(
                        targetState = gridTab,
                        transitionSpec = {
                            val forward = targetState > initialState
                            (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { w -> if (forward) w / 6 else -w / 6 } +
                                fadeIn(tween(260, delayMillis = 40))) togetherWith
                                (slideOutHorizontally(tween(240)) { w -> if (forward) -w / 8 else w / 8 } + fadeOut(tween(160)))
                        },
                        label = "calendarView",
                        modifier = Modifier.fillMaxSize()
                    ) { gridView ->
                        if (gridView == CalendarTabs.TABLE) TablePage(
                            pageMonth, timesCache, today, hijriOffset, ink.title,
                            next = data.window.next, nextStart = data.window.nextStart,
                            bottomInset = bottomInset, onOpen = { topic = it }
                        ) else MonthPage(
                            data, now, pageMonth, pageSelected, columns, ink, bottomInset,
                            onSelect = { selectedEpoch = it.toEpochDay() },
                            onToday = { monthText = YearMonth.from(today).toString(); selectedEpoch = today.toEpochDay() },
                            onOpen = { topic = it }
                        )
                    }
                }
            }
        }
        PeriodPicker(
            visible = picker,
            mode = if (yearTab) PickerMode.HIJRI_YEAR else PickerMode.MONTH,
            month = month, hijriYear = hijriYear, today = today, hijriOffset = hijriOffset,
            accent = palette.accent, surface = palette.sheet,
            onMonth = { goMonth(it) }, onHijriYear = { hijriYear = it }, onDismiss = { picker = false }
        )
        DaySheet(topic, today, hijriOffset, onDismiss = { topic = null })
    }
}

/** "16 июня 2026 — 4 июня 2027": the Gregorian bounds of a hijri year. */
private fun yearSpan(year: Int, offset: Int): String {
    val first = IslamicDays.monthRange(year, 1, offset)?.first
    val last = IslamicDays.monthRange(year, 12, offset)?.second
    return if (first != null && last != null) "${Format.dayMonth(first)} ${first.year} — ${Format.dayMonth(last)} ${last.year}" else ""
}

/* ------------------------------------------------------------------------------------------------
 * Месяц: the grid, the card of the selected day, the next day of the year
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun MonthPage(
    data: PrayerData, now: State<ZonedDateTime>, month: YearMonth, selectedDate: LocalDate,
    columns: List<Prayer>, ink: BackdropInk, bottomInset: Dp,
    onSelect: (LocalDate) -> Unit, onToday: () -> Unit,
    onOpen: (SheetTopic) -> Unit
) {
    val ui = uiScale()
    val today = data.today
    val hijriOffset = data.settings.hijriOffset
    val haptic = LocalHapticFeedback.current
    // Yesterday, the day and tomorrow, computed in place: three solar days take a few milliseconds, and the card
    // keeps its height while the selection moves (an asynchronous load flashed a placeholder on every tap).
    // The key is the whole calculation identity, so times of another city or date can never stay under a new one.
    val window = remember(selectedDate, data.place, data.params) {
        runCatching {
            dayWindow(PrayerEngine.days(selectedDate.minusDays(1), 3, data.place.coordinates, data.place.zone, data.params))
        }.getOrNull()
    }
    val dayEvents = remember(selectedDate, hijriOffset) { IslamicDays.on(selectedDate, hijriOffset) }
    val nextEvent = remember(selectedDate, hijriOffset) {
        IslamicDays.between(selectedDate.plusDays(1), selectedDate.plusDays(400), hijriOffset)
            .firstOrNull { it.kind != DayKind.SEASON && it.start.isAfter(selectedDate) }
    }
    // After Isha the "next" prayer is tomorrow's Fajr: it is lit in tomorrow's card, not in today's.
    val lit = HomeTimeline.visible(data.window.next, data.fajrEqualsDawn)
        .takeIf { data.window.nextStart.toLocalDate() == selectedDate }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(12f))) {
        MonthCalendar(
            month, selectedDate, today.date, hijriOffset,
            onSelect = { date ->
                if (date != selectedDate) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onSelect(date)
                }
            },
            labelInk = ink.label, fridayInk = ink.friday
        )
        Spacer(Modifier.height(10.dp))
        DayCard(
            date = selectedDate, today = today, hijriOffset = hijriOffset, window = window, columns = columns,
            current = HomeTimeline.current(data.window, data.fajrEqualsDawn), next = lit,
            now = now, events = dayEvents, onOpen = onOpen, onToday = onToday
        )
        nextEvent?.let { NextEventStrip(it, today.date, onOpen, Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(bottomInset))
    }
}

/* ------------------------------------------------------------------------------------------------
 * Таблица: the month as a timetable
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun TablePage(
    month: YearMonth, cache: MonthTimesCache, today: LocalDate, hijriOffset: Int, ink: Color,
    next: Prayer?, nextStart: ZonedDateTime?, bottomInset: Dp,
    onOpen: (SheetTopic) -> Unit
) {
    val ui = uiScale()
    LaunchedEffect(month, cache) { cache.ensure(month) }
    val times = cache[month]
    val events = remember(month, hijriOffset) { monthEvents(month, hijriOffset) }
    // The page does not scroll, only the rows do, under a pinned green header. The card ends above the system bar
    // (the capsule is away while the calendar is open) and the last row stops at its edge.
    AnimatedContent(
        targetState = times,
        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
        label = "monthTable",
        modifier = Modifier.fillMaxSize().padding(start = ui.s(12f), end = ui.s(12f), top = 2.dp, bottom = bottomInset)
    ) { t ->
        if (t == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(tr("Рассчитываем время…"), color = ink.copy(alpha = 0.7f))
        } else MonthTable(
            t, today, hijriOffset, events, onOpen,
            modifier = Modifier.fillMaxSize(),
            next = next, nextStart = nextStart
        )
    }
}
