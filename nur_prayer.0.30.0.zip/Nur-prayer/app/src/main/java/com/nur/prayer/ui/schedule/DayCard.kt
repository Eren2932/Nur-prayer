package com.nur.prayer.ui.schedule

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDay
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.UiScale
import com.nur.prayer.ui.theme.uiScale
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZonedDateTime
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/*
 * 0.28.0 — the card of the selected day, under the month grid: the date and its hijri date, the fast
 * (in Ramadan), the seven times on one line, the daylight, and the next day of the year as a strip.
 *
 * It replaces the column of seven 52 dp rows: the whole day now fits under the grid without a scroll,
 * and "Подробнее" opens what is rarely needed (the day on an hour scale, the shifts, the night).
 */

/** The selected day with its neighbours: yesterday for "+4 мин", tomorrow for the length of the night. */
internal class DayWindow(val before: PrayerDay, val day: PrayerDay, val after: PrayerDay)

internal fun dayWindow(days: List<PrayerDay>): DayWindow? =
    if (days.size >= 3) DayWindow(days[0], days[1], days[2]) else null

@Composable
internal fun DayCard(
    date: LocalDate,
    today: PrayerDay,
    hijriOffset: Int,
    window: DayWindow?,
    columns: List<Prayer>,
    current: Prayer?,
    next: Prayer?,
    now: State<ZonedDateTime>,
    events: List<DayOccurrence>,
    onOpen: (SheetTopic) -> Unit,
    onToday: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val isToday = date == today.date
    var details by rememberSaveable { mutableStateOf(false) }
    Column(
        modifier.fillMaxWidth().paperCard(22.dp).padding(horizontal = ui.s(16f), vertical = ui.s(14f))
            .testTag("calendar-detail")
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                AutoSizeText(
                    Format.fullDate(date).replaceFirstChar { it.uppercase() }, color = Paper.Ink,
                    fontSize = ui.t(21f), minFontSize = ui.t(14f), fontWeight = FontWeight.Bold
                )
                Text(
                    HijriCalendar.format(date, hijriOffset), color = Paper.Accent, fontSize = ui.t(13.5f),
                    fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.padding(top = 2.dp)
                )
            }
            Spacer(Modifier.width(8.dp))
            CalendarTodayChip(isToday, onToday)
        }
        val day = window?.day
        events.forEach { o ->
            if (day != null && o.day == IslamicDay.RAMADAN && fastRange(day, columns) != null) FastBlock(o, date, day, columns, if (isToday) now else null, onOpen, Modifier.padding(top = 12.dp))
            else DayBanner(o, date, onOpen, Modifier.padding(top = 12.dp))
        }
        when (window) {
            // The three days are computed in place (a few milliseconds); null means the engine refused this place or date.
            null -> Text(
                tr("Не удалось рассчитать день"), color = Paper.Ink2, fontSize = ui.t(13f),
                modifier = Modifier.padding(top = 14.dp)
            )
            else -> {
                TimesRow(
                    window.day, columns, if (isToday) current else null, if (isToday) next else null,
                    Modifier.padding(top = 12.dp)
                )
                Box(Modifier.fillMaxWidth().padding(top = 12.dp).height(1.dp).background(Paper.Line))
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    val length = daylight(window.day)
                    val delta = daylightDelta(window.day, window.before)
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("Световой день"), color = Paper.Ink2, fontSize = ui.t(13f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false))
                        Spacer(Modifier.width(6.dp))
                        Text(Format.hoursMinutes(length), color = Paper.Ink, fontSize = ui.t(13.5f), fontWeight = FontWeight.Bold, maxLines = 1)
                        if (delta != 0L) {
                            Spacer(Modifier.width(6.dp))
                            Text(
                                Format.signedMinutes(delta), color = if (delta > 0) Paper.Gain else Paper.Ink3,
                                fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold, maxLines = 1
                            )
                        }
                    }
                    Row(
                        Modifier.clip(CircleShape).pressClick(role = Role.Button, onClick = { details = !details })
                            .padding(start = 8.dp, top = 10.dp, bottom = 10.dp).testTag("calendar-details"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            if (details) tr("Скрыть сведения") else tr("Подробнее"), color = Paper.Accent,
                            fontSize = ui.t(13f), fontWeight = FontWeight.Bold, maxLines = 1
                        )
                        Spacer(Modifier.width(4.dp))
                        Glyph(GlyphKind.CHEVRON, Paper.Accent, Modifier.size(11.dp).graphicsLayer { rotationZ = if (details) -90f else 90f })
                    }
                }
                AnimatedVisibility(details) {
                    Column(Modifier.padding(top = 4.dp)) {
                        DayTimeline(window.day, if (isToday) now else null, Paper.Accent, Paper.Ink, ui)
                        Spacer(Modifier.height(10.dp))
                        if (!isToday) {
                            SummaryRow(tr("Разница с сегодня"), Format.signedMinutes(daylightDelta(window.day, today)), ui)
                            SummaryRow(tr("Фаджр сдвинулся"), Format.signedMinutes(minuteShift(today, window.day, Prayer.FAJR)), ui)
                            SummaryRow(tr("Магриб сдвинулся"), Format.signedMinutes(minuteShift(today, window.day, Prayer.MAGHRIB)), ui)
                        }
                        SummaryRow(tr("От Иша до Фаджра"), Format.hoursMinutes(nightLength(window.day, window.after)), ui)
                        Text(
                            tr("Малая цифра — день хиджры по Умм аль-Кура"), color = Paper.Ink3,
                            fontSize = ui.t(12f), lineHeight = ui.t(17f), modifier = Modifier.padding(top = 8.dp)
                        )
                        window.day.note?.let {
                            Text(it, color = Paper.Accent, fontSize = ui.t(11.5f), lineHeight = ui.t(16f), modifier = Modifier.padding(top = 8.dp))
                        }
                    }
                }
            }
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * The seven times
 * ---------------------------------------------------------------------------------------------- */

/**
 * The times of the day on one line. The next prayer stands on a gold plate, the current one in an
 * outline, and the sunrise is grey: it is not a prayer.
 */
@Composable
private fun TimesRow(day: PrayerDay, columns: List<Prayer>, current: Prayer?, next: Prayer?, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val shape = RoundedCornerShape(14.dp)
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        columns.forEach { prayer ->
            val lit = prayer == next
            val outlined = !lit && prayer == current
            val label = columnLabel(prayer)
            val time = day.times[prayer]?.let { Format.time(it) } ?: "—"
            Column(
                Modifier.weight(1f).clip(shape)
                    .then(
                        when {
                            lit -> Modifier.background(Paper.Gold, shape)
                            outlined -> Modifier.border(1.5.dp, Paper.Ink3, shape)
                            else -> Modifier
                        }
                    )
                    .semantics(mergeDescendants = true) { contentDescription = "$label $time" }
                    .padding(horizontal = 1.dp, vertical = ui.s(8f)),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AutoSizeText(
                    label, color = if (lit) Paper.OnGold else Paper.Ink2, fontSize = ui.t(10.5f), minFontSize = ui.t(8f),
                    maxLines = 1, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
                AutoSizeText(
                    time, color = when {
                        lit -> Paper.OnGold
                        prayer == Prayer.SUNRISE -> Paper.Ink3
                        else -> Paper.Ink
                    },
                    fontSize = ui.t(13.5f), minFontSize = ui.t(10f), fontWeight = FontWeight.Bold,
                    maxLines = 1, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 3.dp)
                )
            }
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * The fast
 * ---------------------------------------------------------------------------------------------- */

/** From the end of Suhur (or Fajr where the place has no separate Suhur) to Maghrib. Null when the day lacks either. */
internal fun fastRange(day: PrayerDay, columns: List<Prayer>): Pair<ZonedDateTime, ZonedDateTime>? {
    val start = day.times[if (Prayer.SAHAR in columns) Prayer.SAHAR else Prayer.FAJR] ?: return null
    val end = day.times[Prayer.MAGHRIB] ?: return null
    return if (end.isAfter(start)) start to end else null
}

/** "34 мин" under an hour, "2 ч 5 мин" above: the unit of the countdown on the card. */
internal fun brief(duration: Duration): String {
    val total = duration.seconds.coerceAtLeast(0)
    val hours = total / 3600
    val minutes = (total % 3600) / 60
    return if (hours > 0) tr("{0} ч {1} мин", hours, minutes) else tr("{0} мин", minutes)
}

/**
 * Ramadan on the card: which day of the month it is, from when to when the fast goes, and on today how
 * much of it has passed. The progress is read once a minute (a derived minute), not every second.
 */
@Composable
private fun FastBlock(
    o: DayOccurrence, date: LocalDate, day: PrayerDay, columns: List<Prayer>, now: State<ZonedDateTime>?,
    onOpen: (SheetTopic) -> Unit, modifier: Modifier = Modifier
) {
    val range = fastRange(day, columns) ?: return
    val ui = uiScale()
    val tone = Paper.tone(DayKind.SEASON)
    val text = Paper.toneText(DayKind.SEASON)
    val shape = RoundedCornerShape(18.dp)
    val (start, end) = range
    val total = Duration.between(start, end)
    val minute = remember(now) { derivedStateOf { now?.value?.toEpochSecond()?.div(60) ?: 0L } }.value
    val moment = Instant.ofEpochSecond(minute * 60)
    val fraction = if (now == null) 0f
        else (Duration.between(start.toInstant(), moment).seconds.toFloat() / total.seconds.coerceAtLeast(1)).coerceIn(0f, 1f)
    val left = Duration.between(moment, end.toInstant())
    val title = IslamicDayText.title(o.day)
    Column(
        modifier.fillMaxWidth().clip(shape).background(tone.copy(alpha = 0.12f), shape)
            .pressClick(scaleTo = 0.98f, role = Role.Button, onClick = { onOpen(SheetTopic.Day(o)) })
            .semantics(mergeDescendants = true) { contentDescription = title }
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .testTag("day-banner-${o.day.name}")
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    tr("{0} · день {1} из {2}", title, IslamicDays.daysBetween(o.start, date) + 1, o.days),
                    color = text, fontSize = ui.t(14.5f), fontWeight = FontWeight.Bold, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(Modifier.width(6.dp))
                Glyph(GlyphKind.CHEVRON, text, Modifier.size(10.dp))
            }
            Spacer(Modifier.width(8.dp))
            Text(
                "${Format.time(start)} – ${Format.time(end)}", color = Paper.Ink, fontSize = ui.t(14f),
                fontWeight = FontWeight.Bold, maxLines = 1
            )
        }
        if (now != null) {
            val track = Paper.Ink.copy(alpha = 0.10f)
            Canvas(Modifier.padding(top = 8.dp).fillMaxWidth().height(14.dp)) {
                val bar = 8.dp.toPx()
                val radius = bar / 2f
                val cy = size.height / 2f
                drawRoundRect(track, Offset(0f, cy - radius), Size(size.width, bar), CornerRadius(radius, radius))
                val x = size.width * fraction
                if (x > 0f) drawRoundRect(tone, Offset(0f, cy - radius), Size(x, bar), CornerRadius(radius, radius))
                val knob = 6.dp.toPx()
                val cx = x.coerceIn(knob, size.width - knob)
                drawCircle(Color.White, knob, Offset(cx, cy))
                drawCircle(tone, knob, Offset(cx, cy), style = Stroke(2.dp.toPx()))
            }
        }
        Row(Modifier.padding(top = if (now != null) 4.dp else 6.dp), verticalAlignment = Alignment.CenterVertically) {
            val duration = tr("пост {0}", brief(total))
            val passed = tr("прошло {0}%", (fraction * 100).roundToInt())
            Text(
                if (now != null) "$duration · $passed" else duration,
                color = Paper.Ink2, fontSize = ui.t(12.5f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (now != null) {
                Spacer(Modifier.width(8.dp))
                Text(
                    if (left.isNegative || left.isZero) tr("пост завершён") else tr("до ифтара {0}", brief(left)),
                    color = Paper.toneText(DayKind.FEAST), fontSize = ui.t(12.5f), fontWeight = FontWeight.Bold, maxLines = 1
                )
            }
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * Days of the year on the card
 * ---------------------------------------------------------------------------------------------- */

/** A day of the year that falls on the selected date, tinted by its kind; a tap opens its sheet. */
@Composable
internal fun DayBanner(o: DayOccurrence, date: LocalDate, onOpen: (SheetTopic) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val tone = Paper.tone(o.kind)
    val shape = RoundedCornerShape(16.dp)
    val title = IslamicDayText.title(o.day)
    Row(
        modifier.fillMaxWidth().clip(shape).background(tone.copy(alpha = 0.12f), shape).border(1.dp, tone.copy(alpha = 0.30f), shape)
            .pressClick(scaleTo = 0.98f, role = Role.Button, onClick = { onOpen(SheetTopic.Day(o)) })
            .semantics(mergeDescendants = true) { contentDescription = title }
            .padding(horizontal = 14.dp, vertical = 11.dp)
            .testTag("day-banner-${o.day.name}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(tone))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(IslamicDayText.tile(o.day), color = Paper.Ink, fontSize = ui.t(15f), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val line = if (o.days > 1) tr("День {0} из {1}", IslamicDays.daysBetween(o.start, date) + 1, o.days)
                else IslamicDayText.short(o.day)
            Text(line, color = Paper.toneText(o.kind), fontSize = ui.t(12.5f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 1.dp))
        }
        Glyph(GlyphKind.CHEVRON, Paper.Ink3, Modifier.size(11.dp))
    }
}

/** The next day of the year after the selected date: its colour, short name, date and how far away it is. */
@Composable
internal fun NextEventStrip(o: DayOccurrence, today: LocalDate, onOpen: (SheetTopic) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val tone = Paper.tone(o.kind)
    val title = IslamicDayText.title(o.day)
    Row(
        modifier.fillMaxWidth().paperCard(20.dp)
            .pressClick(scaleTo = 0.98f, role = Role.Button, onClick = { onOpen(SheetTopic.Day(o)) })
            .semantics(mergeDescendants = true) { contentDescription = title }
            .padding(horizontal = 14.dp, vertical = 13.dp)
            .testTag("calendar-next-event"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(tone))
        Spacer(Modifier.width(10.dp))
        Text(
            IslamicDayText.tile(o.day), color = Paper.Ink, fontSize = ui.t(15f), fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
        )
        Spacer(Modifier.width(8.dp))
        Text(Format.dayMonth(o.start), color = Paper.Ink3, fontSize = ui.t(12.5f), maxLines = 1)
        Spacer(Modifier.weight(1f))
        Text(
            DayWhen.countdown(o, today), color = Paper.toneText(o.kind), fontSize = ui.t(12.5f),
            fontWeight = FontWeight.Bold, maxLines = 1
        )
        Spacer(Modifier.width(8.dp))
        Glyph(GlyphKind.CHEVRON, Paper.Ink3, Modifier.size(11.dp))
    }
}

/* ------------------------------------------------------------------------------------------------
 * The day on an hour scale, summary rows
 * ---------------------------------------------------------------------------------------------- */

/**
 * The day on an hour scale: 00:00 on the left, 24:00 on the right, night faint, daylight lit, a marker
 * where each prayer falls, and a live "now" needle on today.
 */
@Composable
private fun DayTimeline(day: PrayerDay, now: State<ZonedDateTime>?, accent: Color, ink: Color, ui: UiScale) {
    val fajr = fraction(day, Prayer.FAJR)
    val sunrise = fraction(day, Prayer.SUNRISE)
    val maghrib = fraction(day, Prayer.MAGHRIB)
    val markers = remember(day) { Prayer.entries.mapNotNull { prayer -> day.times[prayer]?.let { fraction(day, prayer) } } }
    Column {
        Canvas(Modifier.fillMaxWidth().height(ui.s(34f))) {
            if (size.width < 8f || size.height < 4f) return@Canvas
            val h = size.height
            val barTop = h * 0.30f
            val barHeight = h * 0.36f
            val corner = CornerRadius(barHeight / 2f, barHeight / 2f)
            drawRoundRect(ink.copy(alpha = 0.07f), Offset(0f, barTop), Size(size.width, barHeight), corner)
            fun band(from: Float, to: Float, color: Color) {
                if (to <= from) return
                drawRoundRect(color, Offset(size.width * from, barTop), Size(size.width * (to - from), barHeight), corner)
            }
            band(fajr, sunrise, accent.copy(alpha = 0.28f))
            band(sunrise, maghrib, accent.copy(alpha = 0.60f))
            for (i in 1 until 8) {
                val x = size.width * (i / 8f)
                drawLine(ink.copy(alpha = 0.10f), Offset(x, barTop), Offset(x, barTop + barHeight), strokeWidth = 1f * density)
            }
            markers.forEach { f ->
                val x = size.width * f
                drawLine(
                    ink.copy(alpha = 0.55f), Offset(x, barTop - h * 0.16f), Offset(x, barTop + barHeight + h * 0.16f),
                    strokeWidth = 1.6f * density, cap = StrokeCap.Round
                )
            }
            // The state is read here, inside the draw scope: a tick re-runs this lambda and nothing else.
            val moment = now?.value
            if (moment != null) {
                val secondOfDay = moment.hour * 3600 + moment.minute * 60 + moment.second
                val x = size.width * (secondOfDay / 86400f).coerceIn(0f, 1f)
                drawLine(accent, Offset(x, 0f), Offset(x, h), strokeWidth = 2.2f * density, cap = StrokeCap.Round)
                drawCircle(accent, 3f * density, Offset(x, h * 0.06f))
            }
        }
        Row(Modifier.fillMaxWidth()) {
            listOf("00", "06", "12", "18", "24").forEachIndexed { index, label ->
                Text(
                    label, color = Paper.Ink3, fontSize = ui.t(8.5f),
                    textAlign = when (index) { 0 -> TextAlign.Start; 4 -> TextAlign.End; else -> TextAlign.Center },
                    modifier = Modifier.weight(if (index == 0 || index == 4) 0.5f else 1f)
                )
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String, ui: UiScale) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = ui.s(4f)),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AutoSizeText(
            label, color = Paper.Ink2, fontSize = ui.t(12f), minFontSize = ui.t(9f), maxLines = 2,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(ui.s(10f)))
        AutoSizeText(value, color = Paper.Ink, fontSize = ui.t(13f), minFontSize = ui.t(10f), fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
    }
}

/* ------------------------------------------------------------------------------------------------
 * Small calculations
 * ---------------------------------------------------------------------------------------------- */

/** Where a prayer falls inside its own local day, 0..1. */
private fun fraction(day: PrayerDay, prayer: Prayer): Float {
    val time = day.times[prayer] ?: return 0f
    val local = time.toLocalTime()
    val seconds = local.hour * 3600 + local.minute * 60 + local.second
    // A prayer pushed past midnight (short northern nights) belongs to the far right edge.
    val rolled = if (time.toLocalDate().isAfter(day.date)) 86400 else seconds
    return (rolled / 86400f).coerceIn(0f, 1f)
}

internal fun daylight(day: PrayerDay): Duration {
    val sunrise = day.times[Prayer.SUNRISE]
    val maghrib = day.times[Prayer.MAGHRIB]
    if (sunrise == null || maghrib == null) return Duration.ZERO
    return Duration.between(sunrise, maghrib)
}

/** The daylight of [day] against [other], in whole minutes, rounded (a 3 min 40 s gain reads "+4 мин"). */
internal fun daylightDelta(day: PrayerDay, other: PrayerDay): Long =
    ((daylight(day).seconds - daylight(other).seconds) / 60.0).roundToLong()

/** How many minutes a prayer moved between two days. */
private fun minuteShift(from: PrayerDay, to: PrayerDay, prayer: Prayer): Long {
    val a = from.times[prayer] ?: return 0
    val b = to.times[prayer] ?: return 0
    return (b.toLocalTime().toSecondOfDay() - a.toLocalTime().toSecondOfDay()) / 60L
}

/** Isha of the day to Fajr of the following one: the real night, across midnight. */
private fun nightLength(day: PrayerDay, following: PrayerDay): Duration {
    val isha = day.times[Prayer.ISHA] ?: return Duration.ZERO
    val fajr = following.times[Prayer.FAJR] ?: return Duration.ZERO
    val length = Duration.between(isha, fajr)
    return if (length.isNegative) Duration.ZERO else length
}
