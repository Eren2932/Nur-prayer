package com.nur.prayer.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime

/*
 * 0.30.0, home variant 1 («Карточки»): the countdown and the six times as a list of cards.
 *
 * Measured from the mock (see HomeSpec). Three rules of this screen:
 *  - one shape for every card: the gold card of the mock (height, radius, gap, padding), where the
 *    mock itself had five slightly different ones;
 *  - the next prayer is gold, every other card is white glass with the transparency measured on the
 *    reference (an 80 % layer, no blur);
 *  - the clock is read only by the leaves in HomeClock.kt: a card changes when its text changes.
 */

@Composable
internal fun HomeCards(
    data: PrayerData,
    now: State<ZonedDateTime>,
    prayers: List<Prayer>,
    next: Prayer,
    heroModifier: Modifier,
    listModifier: Modifier,
    onOpenPrayer: (Prayer) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    FitBody(HomeSpec.Cards.WEIGHT_TOP, HomeSpec.Cards.WEIGHT_BOTTOM, modifier) {
        Column(Modifier.fillMaxWidth()) {
            CardsHero(data, now, next, heroModifier)
            Spacer(Modifier.height(ui.s(HomeSpec.Cards.HERO_TO_LIST)))
            CardList(data, now, prayers, listModifier, onOpenPrayer)
        }
    }
}

/** «Зухр через» / «2:01:34» / «азан в 11:27»: three lines on their measured baselines. */
@Composable
private fun CardsHero(data: PrayerData, now: State<ZonedDateTime>, next: Prayer, modifier: Modifier) {
    val ui = uiScale()
    val spec = HomeSpec.Cards
    val sky = TextStyle(shadow = HomeSpec.OnSky)
    val title = PrayerLabels.title(next)
    val at = Format.time(data.window.nextStart)
    MarkedStack(
        marks = listOf(
            baselineAt(ui.s(spec.LABEL_BASELINE)),
            baselineAt(ui.s(spec.COUNT_BASELINE)),
            baselineAt(ui.s(spec.AZAN_BASELINE))
        ),
        modifier = modifier.fillMaxWidth().padding(horizontal = ui.s(16f))
    ) {
        Text(
            tr("{0} через", title), color = TextPrimary, fontSize = ui.t(spec.LABEL),
            fontWeight = FontWeight.Medium, style = sky, maxLines = 1,
            modifier = Modifier.clearAndSetSemantics { contentDescription = tr("Следующий: {0}, в {1}", title, at) }
        )
        HomeCountdown(
            data, now, next, spec.COUNT, spec.COUNT_MIN, FontWeight.Bold, -2f,
            Modifier.fillMaxWidth()
        )
        Text(
            if (next.isPrayer) tr("азан в {0}", at) else tr("начало в {0}", at),
            color = TextPrimary.copy(alpha = 0.92f), fontSize = ui.t(spec.AZAN),
            style = sky, maxLines = 1,
            modifier = Modifier.clearAndSetSemantics { }
        )
    }
}

@Composable
private fun CardList(
    data: PrayerData,
    now: State<ZonedDateTime>,
    prayers: List<Prayer>,
    modifier: Modifier,
    onOpenPrayer: (Prayer) -> Unit
) {
    val ui = uiScale()
    val spec = HomeSpec.Cards
    Column(modifier.fillMaxWidth().padding(horizontal = ui.s(spec.SIDE))) {
        prayers.forEachIndexed { index, prayer ->
            if (index > 0) Spacer(Modifier.height(ui.s(spec.CARD_GAP)))
            val state = HomeMath.rowState(prayer, data.window, data.today, data.fajrEqualsDawn)
            PrayerCard(prayer, state, data, now) { onOpenPrayer(prayer) }
        }
    }
}

/** What a card wears in each state: its fill and the ink of every part. */
private class CardTone(
    val fill: Color,
    val title: Color,
    val sub: Color,
    val time: Color,
    val circle: Color,
    val glyph: Color,
    val bell: Color,
    val track: Color,
    val bar: Color
)

private object Tones {
    private val ink = HomeSpec.Cards.Ink
    private val gold = HomeSpec.OnGold

    val Next = CardTone(
        fill = HomeSpec.GoldCard, title = gold, sub = gold.copy(alpha = 0.72f), time = gold,
        circle = gold.copy(alpha = 0.10f), glyph = gold, bell = gold.copy(alpha = 0.85f),
        track = gold.copy(alpha = 0.14f), bar = gold
    )
    val Current = CardTone(
        fill = HomeSpec.Cards.Glass, title = ink, sub = HomeSpec.Cards.Amber, time = ink,
        circle = HomeSpec.GoldCard.copy(alpha = 0.38f), glyph = HomeSpec.Cards.Amber,
        bell = ink.copy(alpha = 0.75f), track = ink.copy(alpha = 0.12f), bar = Color(0xFFDDA043)
    )
    val Past = CardTone(
        fill = HomeSpec.Cards.Glass, title = ink.copy(alpha = HomeSpec.Cards.INK_PAST),
        sub = ink.copy(alpha = HomeSpec.Cards.INK_SUB_PAST), time = ink.copy(alpha = HomeSpec.Cards.INK_PAST),
        circle = ink.copy(alpha = 0.06f), glyph = ink.copy(alpha = 0.55f), bell = ink.copy(alpha = 0.45f),
        track = ink.copy(alpha = 0.12f), bar = Color(0xFFDDA043)
    )
    val Upcoming = CardTone(
        fill = HomeSpec.Cards.Glass, title = ink, sub = ink.copy(alpha = HomeSpec.Cards.INK_SUB), time = ink,
        circle = ink.copy(alpha = 0.08f), glyph = ink.copy(alpha = 0.85f), bell = ink.copy(alpha = 0.75f),
        track = ink.copy(alpha = 0.12f), bar = Color(0xFFDDA043)
    )

    fun of(state: RowState): CardTone = when (state) {
        RowState.NEXT -> Next
        RowState.CURRENT -> Current
        RowState.PAST -> Past
        RowState.UPCOMING -> Upcoming
    }
}

@Composable
private fun PrayerCard(
    prayer: Prayer,
    state: RowState,
    data: PrayerData,
    now: State<ZonedDateTime>,
    onOpen: () -> Unit
) {
    val ui = uiScale()
    val spec = HomeSpec.Cards
    val tone = Tones.of(state)
    val label = PrayerLabels.title(prayer)
    val start = HomeMath.startOf(prayer, state, data.window, data.today)
    val time = start?.let(Format::time) ?: "—"
    val ahead = state == RowState.NEXT || state == RowState.UPCOMING
    val minutesLeft = rememberMinutesLeft(now, if (ahead) start else null)
    val sub = when (state) {
        RowState.PAST -> if (prayer == Prayer.ISHA) tr("прошла") else tr("прошёл")
        RowState.CURRENT -> tr("идёт сейчас")
        RowState.NEXT, RowState.UPCOMING -> HomeMath.until(minutesLeft.value)
    }
    val bell = prayer.isPrayer && data.settings.notifications[prayer] == true
    val shape = RoundedCornerShape(ui.s(spec.CARD_RADIUS))
    val textStart = spec.ICON_START + spec.ICON_DIAMETER + spec.TEXT_GAP

    Box(
        Modifier
            .fillMaxWidth()
            .height(ui.s(spec.CARD_HEIGHT))
            .clip(shape)
            .background(tone.fill)
            .clickable(role = Role.Button, onClickLabel = tr("Подробнее"), onClick = onOpen)
            .semantics { contentDescription = "$label $time, $sub" }
    ) {
        Row(
            Modifier.fillMaxSize().padding(start = ui.s(spec.ICON_START), end = ui.s(spec.END)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(ui.s(spec.ICON_DIAMETER)).clip(CircleShape).background(tone.circle),
                contentAlignment = Alignment.Center
            ) {
                PrayerGlyph(prayer, tone.glyph, Modifier.size(ui.s(spec.ICON_GLYPH)))
            }
            Spacer(Modifier.width(ui.s(spec.TEXT_GAP)))
            // On the mock's own baselines (23.1 dp and 37.5 dp under the card's top), not stacked by text boxes.
            MarkedStack(
                marks = listOf(baselineAt(ui.s(spec.TITLE_BASELINE)), baselineAt(ui.s(spec.SUB_BASELINE))),
                modifier = Modifier.weight(1f).fillMaxHeight(),
                centered = false
            ) {
                Text(
                    label, color = tone.title, fontSize = ui.t(spec.TITLE), fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(sub, color = tone.sub, fontSize = ui.t(spec.SUB), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(time, color = tone.time, fontSize = ui.t(spec.TIME), fontWeight = FontWeight.Bold, maxLines = 1)
            Spacer(Modifier.width(ui.s(spec.TIME_GAP)))
            BellGlyph(bell, tone.bell, Modifier.size(ui.s(spec.BELL)))
        }
        if (state == RowState.CURRENT) {
            val progress = rememberWindowProgress(now, data.window)
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = ui.s(textStart), end = ui.s(spec.BAR_END), bottom = ui.s(spec.BAR_BOTTOM))
                    .fillMaxWidth()
                    .height(ui.s(spec.BAR_HEIGHT))
                    .clip(CircleShape)
                    .background(tone.track)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(progress.value.coerceIn(0f, 1f))
                        .fillMaxHeight()
                        .clip(CircleShape)
                        .background(tone.bar)
                )
            }
        }
    }
}
