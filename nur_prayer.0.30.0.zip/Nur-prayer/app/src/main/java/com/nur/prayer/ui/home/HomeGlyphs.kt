package com.nur.prayer.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.nur.prayer.core.astro.Prayer
import kotlin.math.cos
import kotlin.math.sin

/**
 * 0.30.0: the six glyphs of the card list, drawn on a 24-unit grid like the rest of the app's
 * glyphs: dawn (a rising arc with its first ray), sunrise (the arc with three rays), noon (a full
 * sun), the afternoon (a sun still high above the line), sunset (the arc and an arrow into it) and
 * night (a crescent).
 */
@Composable
internal fun PrayerGlyph(prayer: Prayer, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) { drawPrayerGlyph(prayer, color) }
}

private fun DrawScope.drawPrayerGlyph(prayer: Prayer, color: Color) {
    val u = size.minDimension / 24f
    val sw = 1.7f * u
    val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)

    fun at(x: Float, y: Float) = Offset(x * u, y * u)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
        drawLine(color = color, start = at(x1, y1), end = at(x2, y2), strokeWidth = sw, cap = StrokeCap.Round)
    }
    fun horizon(y: Float) = line(3f, y, 21f, y)
    fun halfSun(cx: Float, cy: Float, r: Float) {
        drawArc(
            color = color,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = at(cx - r, cy - r),
            size = Size(2f * r * u, 2f * r * u),
            style = stroke
        )
    }
    fun ring(cx: Float, cy: Float, r: Float) {
        drawCircle(color = color, radius = r * u, center = at(cx, cy), style = stroke)
    }
    // A ray at [degrees] (0 = right, 90 = up), from [from] to [to] away from (cx, cy).
    fun ray(cx: Float, cy: Float, degrees: Float, from: Float, to: Float) {
        val a = Math.toRadians(degrees.toDouble())
        val c = cos(a).toFloat()
        val s = sin(a).toFloat()
        line(cx + from * c, cy - from * s, cx + to * c, cy - to * s)
    }

    when (prayer) {
        Prayer.FAJR -> {
            horizon(17.5f)
            halfSun(12f, 17.5f, 5.2f)
            ray(12f, 17.5f, 48f, 7.8f, 10.4f)
        }
        Prayer.SUNRISE -> {
            horizon(17.5f)
            halfSun(12f, 17.5f, 4.6f)
            ray(12f, 17.5f, 90f, 7.4f, 10.2f)
            ray(12f, 17.5f, 48f, 7.4f, 10.2f)
            ray(12f, 17.5f, 132f, 7.4f, 10.2f)
        }
        Prayer.DHUHR -> {
            ring(12f, 12f, 3.6f)
            for (k in 0 until 8) ray(12f, 12f, k * 45f, 6.5f, 8.8f)
        }
        Prayer.ASR -> {
            ring(12f, 10.5f, 3.2f)
            for (k in 0..4) ray(12f, 10.5f, k * 45f, 5.6f, 7.6f)
            horizon(18f)
        }
        Prayer.MAGHRIB -> {
            horizon(18.5f)
            halfSun(12f, 18.5f, 4.8f)
            line(12f, 3.8f, 12f, 11f)
            line(9.3f, 8.4f, 12f, 11.1f)
            line(14.7f, 8.4f, 12f, 11.1f)
        }
        else -> {
            // Isha, and anything the list is ever given beyond the six: the crescent.
            val outer = Path().apply { addOval(Rect(center = at(11.5f, 12f), radius = 7.6f * u)) }
            val cut = Path().apply { addOval(Rect(center = at(15.2f, 9.6f), radius = 6.4f * u)) }
            drawPath(path = Path.combine(PathOperation.Difference, outer, cut), color = color)
        }
    }
}

/** The bell of a card: the call is on, or (struck through) there is none for this time. */
@Composable
internal fun BellGlyph(on: Boolean, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val sw = 1.6f * u
        val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        val body = Path().apply {
            moveTo(5.8f * u, 17f * u)
            cubicTo(7.2f * u, 15.8f * u, 7.6f * u, 14f * u, 7.6f * u, 10.8f * u)
            cubicTo(7.6f * u, 8.1f * u, 9.5f * u, 6.4f * u, 12f * u, 6.4f * u)
            cubicTo(14.5f * u, 6.4f * u, 16.4f * u, 8.1f * u, 16.4f * u, 10.8f * u)
            cubicTo(16.4f * u, 14f * u, 16.8f * u, 15.8f * u, 18.2f * u, 17f * u)
            close()
        }
        drawPath(path = body, color = color, style = stroke)
        drawLine(color = color, start = Offset(12f * u, 4.2f * u), end = Offset(12f * u, 6.4f * u), strokeWidth = sw, cap = StrokeCap.Round)
        val clapper = Path().apply {
            moveTo(10.2f * u, 19.6f * u)
            quadraticBezierTo(12f * u, 21.5f * u, 13.8f * u, 19.6f * u)
        }
        drawPath(path = clapper, color = color, style = stroke)
        if (!on) {
            drawLine(color = color, start = Offset(4.6f * u, 4.6f * u), end = Offset(19.4f * u, 19.4f * u), strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}
