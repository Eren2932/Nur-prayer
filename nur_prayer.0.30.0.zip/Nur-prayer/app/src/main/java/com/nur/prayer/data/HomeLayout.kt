package com.nur.prayer.data

/**
 * 0.30.0: which of the two home screens the user keeps.
 *
 *  - [CARDS]: the countdown and the six times as a list of cards (the default);
 *  - [BIG]: the next prayer's name in huge type, its time, the countdown and the day's timeline.
 *
 * Stored by name; an unknown or missing value (an install from before 0.30.0, a downgrade, a typo
 * in a backup) reads as [DEFAULT], never as a crash.
 */
enum class HomeLayout {
    CARDS, BIG;

    companion object {
        val DEFAULT: HomeLayout = CARDS

        fun fromName(name: String?): HomeLayout = entries.firstOrNull { it.name == name } ?: DEFAULT
    }
}
