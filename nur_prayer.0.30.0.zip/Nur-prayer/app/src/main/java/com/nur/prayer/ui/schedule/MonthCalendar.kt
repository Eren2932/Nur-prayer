package com.nur.prayer.ui.schedule

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate
import java.time.YearMonth

/**
 * The month grid on paper. 0.28.0:
 *  - the weeks are as many as the month needs (4–6), not a fixed six: February 2027 is four rows and the
 *    day card under it comes up into view;
 *  - a season (Ramadan) is one continuous band across its days, other events a tinted square;
 *  - today is a solid accent square, a selected other day a ring;
 *  - the period header moved out into [PeriodBar]; 0.29.0: the swipe moved out too, into [PeriodPager] — this is
 *    one page, the grid of one month.
 */
@Composable
fun MonthCalendar(
    month: YearMonth, selected: LocalDate, today: LocalDate, hijriOffset: Int,
    onSelect: (LocalDate) -> Unit, modifier: Modifier = Modifier,
    /** The weekday letters stand on the backdrop, not on a card: dark on a light picture, light on a dark one. */
    labelInk: Color = Paper.Ink3, fridayInk: Color = Paper.Accent
) {
    val ui = uiScale()
    val weekdays = listOf(tr("Пн"), tr("Вт"), tr("Ср"), tr("Чт"), tr("Пт"), tr("Сб"), tr("Вс"))
    val cells = remember(month) { CalendarMonthModel.cells(month) }
    // One lookup per cell, kept for the neighbours: a band needs to know whether the next day is the same event.
    val events = remember(cells, hijriOffset) {
        cells.map { d -> if (YearMonth.from(d) == month) IslamicDays.primary(d, hijriOffset) else null }
    }
    Column(modifier) {
        Row(Modifier.fillMaxWidth().padding(horizontal = ui.s(8f), vertical = ui.s(6f))) {
            weekdays.forEachIndexed { i, label ->
                Text(
                    label, color = if (i == 4) fridayInk else labelInk, fontSize = ui.t(11f),
                    fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                )
            }
        }
        Column(Modifier.fillMaxWidth().paperCard(20.dp).padding(ui.s(8f)).testTag("calendar-grid")) {
            cells.chunked(7).forEachIndexed { week, days ->
                Row(Modifier.fillMaxWidth().height(ui.s(46f)), verticalAlignment = Alignment.CenterVertically) {
                    days.forEachIndexed { i, date ->
                        val k = week * 7 + i
                        val event = events[k]
                        val band = event != null && event.kind == DayKind.SEASON
                        // The grey days of the neighbouring months only fill the week: they are neither today,
                        // nor selected, nor tapped (the next page is a swipe away).
                        val inMonth = YearMonth.from(date) == month
                        DayCell(
                            date = date, inMonth = inMonth,
                            isToday = inMonth && date == today, isSelected = inMonth && date == selected,
                            hijriOffset = hijriOffset, event = event,
                            bandBefore = band && i > 0 && events[k - 1]?.day == event?.day,
                            bandAfter = band && i < 6 && events[k + 1]?.day == event?.day,
                            modifier = Modifier.weight(1f),
                            onClick = { onSelect(date) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    date: LocalDate, inMonth: Boolean, isToday: Boolean, isSelected: Boolean, hijriOffset: Int,
    event: DayOccurrence?, bandBefore: Boolean, bandAfter: Boolean, modifier: Modifier, onClick: () -> Unit
) {
    val ui = uiScale()
    val hijri = remember(date, hijriOffset) { HijriCalendar.dayOfMonth(date, hijriOffset) }
    val description = remember(date, hijriOffset, isToday) {
        "${Format.fullDate(date)}, ${HijriCalendar.format(date, hijriOffset)}" + if (isToday) tr(", сегодня") else ""
    }
    val season = event != null && event.kind == DayKind.SEASON
    val r = 13.dp
    // A season's cells touch each other: the corners are round only where the band begins or ends.
    val bandShape = RoundedCornerShape(
        topStart = if (bandBefore) 0.dp else r, bottomStart = if (bandBefore) 0.dp else r,
        topEnd = if (bandAfter) 0.dp else r, bottomEnd = if (bandAfter) 0.dp else r
    )
    val toneFill = event?.let { Paper.tone(it.kind) }
    Box(
        modifier.fillMaxWidth().height(ui.s(46f))
            .padding(horizontal = if (season) 0.dp else 1.5.dp, vertical = 2.dp)
            .then(if (season && toneFill != null) Modifier.background(toneFill.copy(alpha = 0.15f), bandShape) else Modifier)
            .semantics { contentDescription = description; selected = isSelected }
            .pressClick(enabled = inMonth, scaleTo = 0.94f, role = Role.Button, onClick = onClick)
            .testTag("calendar-day-$date"),
        contentAlignment = Alignment.Center
    ) {
        val cell = Modifier.fillMaxWidth().height(ui.s(42f)).padding(horizontal = 2.dp)
        val shape = RoundedCornerShape(12.dp)
        val box = when {
            isSelected && isToday -> cell.background(Paper.Accent, shape)
            isSelected -> cell.border(1.6.dp, Paper.Accent, shape)
            isToday -> cell.border(1.2.dp, Paper.Accent.copy(alpha = 0.55f), shape)
            event != null && !season -> cell.background(Paper.tone(event.kind).copy(alpha = 0.15f), shape)
            else -> cell
        }
        val solid = isSelected && isToday
        Column(box, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(
                date.dayOfMonth.toString(),
                color = when {
                    solid -> Color.White
                    inMonth -> Paper.Ink
                    else -> Paper.Ink3.copy(alpha = 0.55f)
                },
                fontSize = ui.t(16f), fontWeight = if (isToday) FontWeight.Bold else FontWeight.SemiBold, maxLines = 1
            )
            Text(
                hijri.toString(),
                color = when {
                    solid -> Color.White.copy(alpha = 0.85f)
                    !inMonth -> Paper.Ink3.copy(alpha = 0.45f)
                    event != null -> Paper.toneText(event.kind)
                    else -> Paper.Ink3
                },
                fontSize = ui.t(9.5f), fontWeight = FontWeight.SemiBold, maxLines = 1
            )
        }
    }
}
