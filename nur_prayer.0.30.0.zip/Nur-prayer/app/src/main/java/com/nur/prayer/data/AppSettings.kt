package com.nur.prayer.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Calibration
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerParams
import com.nur.prayer.core.astro.RegionalProfile
import com.nur.prayer.core.astro.RegionalProfiles
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.notify.AzanSound
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Sentinel written into the store for "choose the profile from the place". */
private const val AUTO_METHOD = "AUTO"

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("nur_settings")

/** Everything the user can tune. */
@androidx.compose.runtime.Immutable
data class AppSettings(
    val cityId: Int = City.MOSCOW.id,
    val useDeviceLocation: Boolean = false,
    val manualLatitude: Double? = null,
    val manualLongitude: Double? = null,
    /**
     * Radius of the stored fix in metres, and when it was taken.
     *
     * Both are persisted because both are shown: a location the app cannot describe is a location
     * the user cannot judge. The timestamp also drives expiry — a fix older than
     * [STALE_FIX_MILLIS] is re-asked for on the next return to the app instead of being trusted
     * forever, which is what 0.2.5 did to anyone who travelled.
     */
    val locationAccuracyMeters: Double? = null,
    val locationFixedAtMillis: Long? = null,
    /** Optional system-geocoder metadata belonging to this exact fix, never calculation inputs. */
    val locationLabel: String? = null,
    val locationAddress: String? = null,
    val locationPostalCode: String? = null,
    /**
     * null means "decide from the country of the place", which is the default.
     *
     * Storing the *override* rather than the method is the whole point. Until 0.2.6 the settings
     * held a concrete method that had been written once at first launch, so every city in every
     * country was computed by the rules of the Russian boards — see [RegionalProfiles]. Storing null
     * lets the profile follow the place, and storing a value means the user has spoken and the app
     * must stop being clever.
     */
    val methodOverride: CalculationMethod? = null,
    val madhab: Madhab = Madhab.HANAFI,
    val highLatitudeRule: HighLatitudeRule = HighLatitudeRule.AUTO,
    val rounding: RoundingMode = RoundingMode.NEAREST,
    /** null = keep the method default gap between congregational Fajr and sunrise. */
    val congregationalFajrMinutes: Int? = null,
    val offsets: Map<Prayer, Int> = emptyMap(),
    val notifications: Map<Prayer, Boolean> = Prayer.entries.associateWith { it.isPrayer },
    val preAlertMinutes: Int = 0,
    /**
     * 0.18.6: the plain system sound by default. A full adhan out of a pocket at the wrong moment was
     * the most common reason to turn notifications off altogether; the recording stays one tap away.
     */
    val azanSound: AzanSound = AzanSound.SYSTEM,
    val hijriOffset: Int = 0,
    /**
     * The animated star backdrop (0.5.1). On by default, because a still screen was the single
     * complaint about 0.5.0 — but stored, because on OLED any lit pixel is the user's battery.
     */
    val ambientBackdrop: Boolean = true,
    /**
     * 0.6.0: the backdrop is the colour of the sky in the current prayer window. Off gives back the
     * pure black of 0.5.x for users who keep the phone on an AMOLED always-dark routine.
     */
    val skyBackdrop: Boolean = true,
    /**
     * 0.22.0: the chosen wallpaper id (WallpaperCatalog), null on installs from before wallpapers —
     * those keep what [skyBackdrop] said. Resolve with WallpaperCatalog.resolve, never read raw.
     */
    val wallpaperId: String? = null,
    /** Wallpapers set before, newest first: the settings row shows them right after the current one. */
    val recentWallpapers: List<String> = emptyList(),
    /**
     * 0.18.6: false only on a fresh install until the user has said where they are — by a location
     * fix or by picking a city. Until then the home screen asks instead of silently computing Moscow.
     * Defaults to true so previews, tests and upgrading users never see the first-run prompt.
     */
    val placeChosen: Boolean = true,
    /** 0.30.0: the card list (default) or the big next prayer with the day's timeline. */
    val homeLayout: HomeLayout = HomeLayout.DEFAULT
) {
    /** True when the stored fix is old enough that the user has plausibly moved. */
    val locationIsStale: Boolean
        get() = useDeviceLocation && (
            locationFixedAtMillis == null ||
                System.currentTimeMillis() - locationFixedAtMillis > STALE_FIX_MILLIS
            )

    /** True while the calculation profile is being chosen from the place rather than by hand. */
    val methodIsAutomatic: Boolean get() = methodOverride == null

    /**
     * The profile in force for a country.
     *
     * A manual override keeps the user's method and takes the convention that naturally belongs to
     * it, because those two are not independent: ДУМ РФ without the Tatarstan offsets is not a
     * convention anybody publishes, and MWL *with* them is simply wrong.
     */
    fun profileFor(country: String, region: String? = null): RegionalProfile {
        val regional = PlaceProfiles.forPlace(country, region)
        val override = methodOverride ?: return regional
        if (override == regional.method) return regional
        return RegionalProfile(
            method = override,
            convention = RegionalProfiles.conventionFor(override),
            calibration = Calibration.OFFICIAL_ANGLES,
            note = "Метод выбран вручную: ${override.title}. " +
                "Для этой страны по умолчанию — ${regional.method.title}."
        )
    }

    /** Calculation parameters for a place. Every caller must go through here, alarms included. */
    fun paramsFor(country: String, region: String? = null): PrayerParams {
        val profile = profileFor(country, region)
        return PrayerParams(
            method = profile.method,
            madhab = madhab,
            highLatitudeRule = highLatitudeRule,
            rounding = rounding,
            convention = profile.convention,
            congregationalFajrMinutes = congregationalFajrMinutes,
            userAdjustments = offsets
        )
    }

    companion object {
        /** Five minutes, matching the foreground-only location refresh cadence. */
        const val STALE_FIX_MILLIS = 5 * 60 * 1000L
    }
}

class SettingsRepository(private val context: Context) {

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs -> prefs.toSettings() }

    private fun Preferences.toSettings(): AppSettings = AppSettings(
        cityId = this[Keys.cityId] ?: City.MOSCOW.id,
        useDeviceLocation = this[Keys.useDeviceLocation] ?: false,
        manualLatitude = this[Keys.manualLat]?.toDoubleOrNull(),
        manualLongitude = this[Keys.manualLon]?.toDoubleOrNull(),
        locationAccuracyMeters = this[Keys.locationAccuracy]?.toDoubleOrNull(),
        locationFixedAtMillis = this[Keys.locationFixedAt]?.takeIf { it > 0L },
        locationLabel = this[Keys.locationLabel],
        locationAddress = this[Keys.locationAddress],
        locationPostalCode = this[Keys.locationPostalCode],
        // "AUTO", and every unreadable value, means automatic. The key is deliberately a new one:
        // upgrading users have "RUSSIA_DUM" written under the old key from their first launch, and
        // reading it would pin a Bukhara user to the Kazan profile forever.
        methodOverride = this[Keys.methodOverride]
            ?.takeIf { it.isNotBlank() && it != AUTO_METHOD }
            ?.let { runCatching { CalculationMethod.valueOf(it) }.getOrNull() },
        madhab = this[Keys.madhab]?.let { runCatching { Madhab.valueOf(it) }.getOrNull() } ?: Madhab.HANAFI,
        highLatitudeRule = this[Keys.highLat]?.let { runCatching { HighLatitudeRule.valueOf(it) }.getOrNull() }
            ?: HighLatitudeRule.AUTO,
        rounding = this[Keys.rounding]?.let { runCatching { RoundingMode.valueOf(it) }.getOrNull() }
            ?: RoundingMode.NEAREST,
        congregationalFajrMinutes = this[Keys.congregationalFajr]?.takeIf { it >= 0 },
        offsets = Prayer.entries.associateWith { (this[Keys.offset(it)] ?: 0) },
        notifications = Prayer.entries.associateWith { (this[Keys.notify(it)] ?: it.isPrayer) },
        preAlertMinutes = this[Keys.preAlert] ?: 0,
        azanSound = this[Keys.azanSound]?.let { runCatching { AzanSound.valueOf(it) }.getOrNull() }
            ?: AzanSound.SYSTEM,
        hijriOffset = this[Keys.hijriOffset] ?: 0,
        ambientBackdrop = this[Keys.ambientBackdrop] ?: true,
        skyBackdrop = this[Keys.skyBackdrop] ?: true,
        wallpaperId = this[Keys.wallpaper]?.takeIf { it.isNotBlank() },
        recentWallpapers = com.nur.prayer.ui.wallpaper.WallpaperOrder.decode(this[Keys.wallpaperRecent]),
        // Upgrading users already had a place: any stored city or location choice counts as one.
        placeChosen = this[Keys.placeChosen]
            ?: (this[Keys.cityId] != null || this[Keys.useDeviceLocation] != null),
        homeLayout = HomeLayout.fromName(this[Keys.homeLayout])
    )

    /**
     * 0.18.6 first launch: before the user has answered, start from the biggest city of the phone's
     * own time zone (Ташкент for Asia/Tashkent, Екатеринбург for Asia/Yekaterinburg) instead of
     * Moscow for everyone. Written only on a truly fresh install and explicitly *not* counted as a
     * choice, so the home screen keeps asking and a location fix still replaces it.
     */
    suspend fun guessFirstCity(cityId: Int) = context.dataStore.edit {
        if (it[Keys.cityId] == null && it[Keys.placeChosen] == null && it[Keys.useDeviceLocation] == null) {
            it[Keys.cityId] = cityId
            it[Keys.placeChosen] = false
        }
    }

    suspend fun setCity(city: City) = context.dataStore.edit {
        it[Keys.cityId] = city.id
        it[Keys.useDeviceLocation] = false
        it[Keys.placeChosen] = true
    }

    suspend fun setUseDeviceLocation(enabled: Boolean) = context.dataStore.edit {
        it[Keys.useDeviceLocation] = enabled
    }

    suspend fun setDeviceLocation(
        latitude: Double,
        longitude: Double,
        nearestCityId: Int,
        accuracyMeters: Double,
        fixedAtMillis: Long
    ) = context.dataStore.edit {
        it[Keys.manualLat] = latitude.toString()
        it[Keys.manualLon] = longitude.toString()
        it[Keys.cityId] = nearestCityId
        it[Keys.useDeviceLocation] = true
        it[Keys.placeChosen] = true
        it[Keys.locationAccuracy] = accuracyMeters.toString()
        it[Keys.locationFixedAt] = fixedAtMillis
        // Never show the previous city's street/index while resolving a new fix.
        it.remove(Keys.locationLabel)
        it.remove(Keys.locationAddress)
        it.remove(Keys.locationPostalCode)
    }

    suspend fun setLocationAddress(
        latitude: Double, longitude: Double, fixedAtMillis: Long,
        label: String?, address: String?, postalCode: String?
    ) = context.dataStore.edit {
        // A slow response must not overwrite a manual city choice or a newer location.
        if (it[Keys.useDeviceLocation] != true || it[Keys.locationFixedAt] != fixedAtMillis ||
            it[Keys.manualLat] != latitude.toString() || it[Keys.manualLon] != longitude.toString()) return@edit
        if (label != null) it[Keys.locationLabel] = label else it.remove(Keys.locationLabel)
        if (address != null) it[Keys.locationAddress] = address else it.remove(Keys.locationAddress)
        if (postalCode != null) it[Keys.locationPostalCode] = postalCode else it.remove(Keys.locationPostalCode)
    }

    /** Pass null to hand the choice back to the place. */
    suspend fun setMethod(method: CalculationMethod?) = context.dataStore.edit {
        it[Keys.methodOverride] = method?.name ?: AUTO_METHOD
    }

    suspend fun setMadhab(madhab: Madhab) = context.dataStore.edit { it[Keys.madhab] = madhab.name }

    suspend fun setHighLatitudeRule(rule: HighLatitudeRule) = context.dataStore.edit {
        it[Keys.highLat] = rule.name
    }

    suspend fun setRounding(mode: RoundingMode) = context.dataStore.edit {
        it[Keys.rounding] = mode.name
    }

    /** Pass null to fall back to the gap the calculation method defines. */
    suspend fun setCongregationalFajrMinutes(minutes: Int?) = context.dataStore.edit {
        it[Keys.congregationalFajr] = minutes?.coerceIn(0, 240) ?: -1
    }

    suspend fun setOffset(prayer: Prayer, minutes: Int) = context.dataStore.edit {
        it[Keys.offset(prayer)] = minutes.coerceIn(-60, 60)
    }

    suspend fun setNotification(prayer: Prayer, enabled: Boolean) = context.dataStore.edit {
        it[Keys.notify(prayer)] = enabled
    }

    suspend fun setPreAlert(minutes: Int) = context.dataStore.edit {
        it[Keys.preAlert] = minutes.coerceIn(0, 60)
    }

    suspend fun setAzanSound(sound: AzanSound) = context.dataStore.edit {
        it[Keys.azanSound] = sound.name
    }

    suspend fun setAmbientBackdrop(enabled: Boolean) = context.dataStore.edit {
        it[Keys.ambientBackdrop] = enabled
    }

    suspend fun setSkyBackdrop(enabled: Boolean) = context.dataStore.edit {
        it[Keys.skyBackdrop] = enabled
    }

    /**
     * 0.22.0: one write for a wallpaper choice — the id, the recent list, and the old sky switch kept
     * in step (black is the AMOLED choice of 0.6.0), so nothing that still reads it disagrees.
     */
    suspend fun setWallpaper(id: String) = context.dataStore.edit {
        val recent = com.nur.prayer.ui.wallpaper.WallpaperOrder.decode(it[Keys.wallpaperRecent])
        it[Keys.wallpaper] = id
        it[Keys.wallpaperRecent] = com.nur.prayer.ui.wallpaper.WallpaperOrder.encode(
            com.nur.prayer.ui.wallpaper.WallpaperOrder.remember(id, recent))
        it[Keys.skyBackdrop] = id != com.nur.prayer.ui.wallpaper.WallpaperCatalog.AMOLED_ID
    }

    suspend fun setHomeLayout(layout: HomeLayout) = context.dataStore.edit {
        it[Keys.homeLayout] = layout.name
    }

    suspend fun setHijriOffset(days: Int) = context.dataStore.edit {
        it[Keys.hijriOffset] = days.coerceIn(-2, 2)
    }

    private object Keys {
        val cityId = intPreferencesKey("city_id")
        val useDeviceLocation = booleanPreferencesKey("use_device_location")
        val manualLat = stringPreferencesKey("manual_lat")
        val manualLon = stringPreferencesKey("manual_lon")
        val locationAccuracy = stringPreferencesKey("location_accuracy_m")
        val locationFixedAt = longPreferencesKey("location_fixed_at")
        val locationLabel = stringPreferencesKey("location_label")
        val locationAddress = stringPreferencesKey("location_address")
        val locationPostalCode = stringPreferencesKey("location_postal_code")
        val methodOverride = stringPreferencesKey("method_v2")
        val madhab = stringPreferencesKey("madhab")
        val highLat = stringPreferencesKey("high_lat")
        val rounding = stringPreferencesKey("rounding")
        val congregationalFajr = intPreferencesKey("congregational_fajr")
        val preAlert = intPreferencesKey("pre_alert")
        val azanSound = stringPreferencesKey("azan_sound")
        val hijriOffset = intPreferencesKey("hijri_offset")
        val ambientBackdrop = booleanPreferencesKey("ambient_backdrop")
        val skyBackdrop = booleanPreferencesKey("sky_backdrop")
        val wallpaper = stringPreferencesKey("wallpaper")
        val wallpaperRecent = stringPreferencesKey("wallpaper_recent")
        val placeChosen = booleanPreferencesKey("place_chosen")
        val homeLayout = stringPreferencesKey("home_layout")
        fun offset(prayer: Prayer) = intPreferencesKey("offset_${prayer.name}")
        fun notify(prayer: Prayer) = booleanPreferencesKey("notify_${prayer.name}")
    }
}
