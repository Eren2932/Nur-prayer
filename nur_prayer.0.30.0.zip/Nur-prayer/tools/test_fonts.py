#!/usr/bin/env python3
"""0.21.0: every Arabic surface goes through ArabicFont, and the font tool rejects what it must."""
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
J = ROOT / 'app/src/main/java/com/nur/prayer'
fails = []


def need(path, *snippets):
    text = (J / path).read_text(encoding='utf-8')
    for s in snippets:
        if s not in text:
            fails.append(f'{path}: expected «{s}»')


need('ui/theme/ArabicFont.kt', 'const val ASSET = "fonts/quran_hafs.ttf"', 'runCatching { android.graphics.Typeface.createFromAsset')
need('ui/learn/LearnParts.kt', 'fontFamily = ArabicFont.family', 'ArabicFont.lineHeight', 'LineHeightStyle.Trim.None')
need('ui/quran/AyahImageShare.kt', 'ArabicFont.paintTypeface()', 'ArabicFont.spacingFor(')
need('ui/home/PrayerSheet.kt', 'PrayerLabels.arabic(prayer), color = TextSecondary, fontSize = ui.t(22f), fontFamily = ArabicFont.family')
need('ui/schedule/DaySheet.kt', 'IslamicDays.arabicMonth(m), color = Paper.Ink, fontSize = ui.t(14f), fontFamily = ArabicFont.family')
need('NurApplication.kt', 'ArabicFont.install(this)')

# The only Arabic drawn by a bare Text(...) must be the ones listed here, each with the face set.
import re  # noqa: E402
for p in J.rglob('*.kt'):
    for i, line in enumerate(p.read_text(encoding='utf-8').splitlines(), 1):
        m = re.search(r'\bText\("([^"]*)"', line)
        if m and re.search(r'[\u0600-\u06FF]', m.group(1)) and 'ArabicFont.family' not in line:
            # A Russian label with a ۞/۩ prefix is UI text, not scripture.
            if re.search(r'[\u0400-\u04FF$]', m.group(1)):
                continue
            fails.append(f'{p.relative_to(ROOT)}:{i}: Arabic Text without ArabicFont.family')

if (ROOT / 'tools/fonts.py').read_text(encoding='utf-8').count("FAMILY_HINTS = ('hafs', 'uthman')") != 1:
    fails.append('tools/fonts.py: family guard changed')

if fails:
    print('\n'.join(fails))
    sys.exit(1)
print('test_fonts: OK')
