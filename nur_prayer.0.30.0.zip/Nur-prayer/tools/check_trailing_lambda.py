#!/usr/bin/env python3
"""Catch a trailing lambda that Kotlin would bind to a trailing `modifier: Modifier` parameter.

0.28.1: `CalendarTodayChip(atToday) { ... }` compiled in no static check but broke
:app:compileDebugAndroidTestKotlin, because the lambda went to `modifier`, not `onClick`.
For every function whose LAST parameter is a Modifier and which has a function-typed
parameter before it, a call `Name(...) { ... }` is reported in main, test and androidTest.
A source preflight, not a Kotlin parser: overloads with another shape are skipped.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app/src'
DECL = re.compile(r'\bfun\s+(?:<[^>]*>\s*)?([A-Za-z_][A-Za-z0-9_]*)\s*\(')


def strip(source):
    token = r'"""[\s\S]*?"""|"(?:\\.|[^"\\\n])*"|\'(?:\\.|[^\'\\])\'|//[^\n]*|/\*[\s\S]*?\*/'
    return re.sub(token, lambda m: re.sub(r'[^\n]', ' ', m[0]), source)


def close(text, start):
    depth = 0
    for i in range(start, len(text)):
        c = text[i]
        if c in '([{':
            depth += 1
        elif c in ')]}':
            depth -= 1
            if depth == 0:
                return i
    return -1


def split_params(body):
    parts, depth, cur = [], 0, ''
    body = body.replace('->', '\u2192')  # keep the arrow's '>' out of the bracket depth
    for c in body:
        if c in '([{<':
            depth += 1
        elif c in ')]}>':
            depth -= 1
        if c == ',' and depth == 0:
            parts.append(cur)
            cur = ''
        else:
            cur += c
    if cur.strip():
        parts.append(cur)
    return [p.strip() for p in parts if p.strip()]


def shapes(files):
    found = {}
    for text in files.values():
        for m in DECL.finditer(text):
            end = close(text, m.end() - 1)
            if end < 0:
                continue
            params = split_params(text[m.end():end])
            types = [p.split(':', 1)[1].split('=', 1)[0].strip() if ':' in p else '' for p in params]
            risky = bool(types) and types[-1] == 'Modifier' and any('\u2192' in t for t in types[:-1])
            found.setdefault(m[1], set()).add(risky)
    return {name for name, kinds in found.items() if kinds == {True}}


def main():
    files = {p: strip(p.read_text(encoding='utf-8')) for p in SRC.rglob('*.kt')}
    names = shapes({p: t for p, t in files.items() if '/main/' in p.as_posix()})
    errors = []
    for path, text in files.items():
        for name in names:
            for m in re.finditer(r'(?<![\w.])' + name + r'\s*\(', text):
                if re.search(r'\bfun\s+(?:<[^>]*>\s*)?$', text[max(0, m.start() - 40):m.start()]):
                    continue
                end = close(text, m.end() - 1)
                if end > 0 and re.match(r'[ \t]*\{', text[end + 1:]):
                    line = text.count('\n', 0, m.start()) + 1
                    errors.append(f'{path.relative_to(ROOT)}:{line}: trailing lambda of {name}(...) binds to `modifier`; name the callback')
    if errors:
        print('\n'.join(errors))
        return 1
    print(f'Trailing-lambda check passed ({len(names)} modifier-last functions with callbacks)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
