#!/usr/bin/env python3
"""0.27.0 «Капсула»: a mirror of ShellMath.kt, checked in CI without a JVM.
0.27.1 adds: the glass is matte (measured from the mock), the capsule has no shadow/path clip, both faces stay composed.

The Kotlin numbers are read from the source, so the mirror cannot silently drift from it.
"""
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'app/src/main/java/com/nur/prayer/ui/shell/ShellState.kt').read_text()

def num(pattern, what):
    m = re.search(pattern, SRC)
    if not m: sys.exit('check_shell: %s not found in ShellState.kt' % what)
    return float(m.group(1))

CAP_END = num(r'capsuleAlpha\(p: Float\): Float = \(1f - p / ([0-9.]+)f\)', 'capsuleAlpha')
PAN_START = num(r'panelAlpha\(p: Float\): Float = \(\(p - ([0-9.]+)f\)', 'panelAlpha start')
PAN_SPAN = num(r'panelAlpha\(p: Float\): Float = \(\(p - [0-9.]+f\) / ([0-9.]+)f\)', 'panelAlpha span')
OVER = num(r'coerceIn\(0f, ([0-9.]+)f\)', 'clampProgress')
DAMP = num(r'OPEN_DAMPING = ([0-9.]+)f', 'OPEN_DAMPING')

clamp = lambda v: min(max(v, 0.0), 1.0)
cap = lambda p: clamp(1 - p / CAP_END)
pan = lambda p: clamp((p - PAN_START) / PAN_SPAN)

errors = []
# Never two layers of text at once: the capsule is (almost) gone before the panel shows.
worst = max(cap(i / 1000) + pan(i / 1000) for i in range(0, int(OVER * 1000) + 1))
if worst > 1.0001: errors.append('capsule and panel text overlap: %.3f' % worst)
if not (0.2 <= CAP_END <= 0.4): errors.append('capsule text must leave in the first third, got %.2f' % CAP_END)
if not (PAN_START + PAN_SPAN <= 0.9): errors.append('panel text must be fully in before the spring settles')
if not (1.0 < OVER <= 1.05): errors.append('overshoot bound must be small, got %.2f' % OVER)
if not (0.7 <= DAMP < 1.0): errors.append('open spring: a hint of bounce, not a wobble (damping %.2f)' % DAMP)

# --- 0.27.1: the glass, measured on the mock (capsule ~#121522 flat, hairline ~14 % white) ---
FROST = (ROOT / 'app/src/main/java/com/nur/prayer/ui/shell/Frost.kt').read_text()
CAPS = (ROOT / 'app/src/main/java/com/nur/prayer/ui/shell/NavCapsule.kt').read_text()

def hexcolor(name):
    m = re.search(name + r' = Color\(0x([0-9A-Fa-f]{8})\)', FROST)
    if not m: sys.exit('check_shell: %s not found in Frost.kt' % name)
    v = int(m.group(1), 16)
    return ((v >> 24) & 255, (v >> 16) & 255, (v >> 8) & 255, v & 255)

def tint_over(bg, a, top=True):
    t = hexcolor('TintTop' if top else 'TintBottom')[1:]
    return tuple(a * t[i] + (1 - a) * bg[i] for i in range(3))

TINT_A = float(re.search(r'const val TINT_ALPHA = ([0-9.]+)f', FROST).group(1))
DIM = float(re.search(r'const val PICTURE_DIM = ([0-9.]+)f', SRC).group(1))
if TINT_A < 0.85: errors.append('glass must be almost opaque (tint %.2f); 0.27.0 at 0.72 came out grey' % TINT_A)
# Worst case: a white wallpaper under the blurred picture. After the dim and the tint it must stay as dark as the mock.
white = tuple(255 * (1 - DIM) for _ in range(3))
for top in (True, False):
    r, g, b = tint_over(white, TINT_A, top)
    lum = 0.2126 * r + 0.7152 * g + 0.0722 * b
    if lum > 40: errors.append('glass over a white wallpaper is too light (luma %.0f, the mock is ~21)' % lum)
tr_, tg, tb = tint_over((0, 0, 0), TINT_A, True); br_, bg_, bb = tint_over((0, 0, 0), TINT_A, False)
if abs((tr_ + tg + tb) - (br_ + bg_ + bb)) / 3 > 6: errors.append('vertical gradient of the glass is a bulge, not a matte: keep it within 6 levels')
edge_a = hexcolor('Edge')[0] / 255
if not (0.10 <= edge_a <= 0.18): errors.append('hairline must be 10-18 %% white like the mock, got %.2f' % edge_a)
if 'shadow(' in FROST or 'clipPath' in FROST or 'elevation' in FROST.replace('elevation shadow', ''):
    errors.append('Frost.kt: no elevation shadow and no path clip: they rebuild every frame while the shape morphs')
if re.search(r'if \((panelComposed|capsuleComposed)\) (CapsuleContent|PanelContent)', CAPS):
    errors.append('NavCapsule.kt: both faces of the capsule stay composed; opening must not compose the panel')
if 'CompositingStrategy.ModulateAlpha' not in CAPS: errors.append('NavCapsule.kt: layers fade per draw call, not in an offscreen buffer')
if not (0.70 <= float(re.search(r'const val CAPSULE_SHARE = ([0-9.]+)f', SRC).group(1)) <= 0.8): errors.append('capsule width share')

if errors:
    print('\n'.join('check_shell: ' + e for e in errors)); sys.exit(1)
print('check_shell: ok (overlap %.3f, capsule out by %.2f, panel in by %.2f)' % (worst, CAP_END, PAN_START + PAN_SPAN))
