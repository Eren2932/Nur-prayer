package com.nur.prayer

import android.view.KeyEvent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.assertIsOff
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.hasAnyAncestor
import androidx.compose.ui.test.hasContentDescription
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.swipe
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.swipeLeft
import com.nur.prayer.data.SettingsRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import android.content.Context
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.semantics.getOrNull
import androidx.compose.ui.test.onAllNodesWithText
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Before
import com.nur.prayer.ui.home.HomeTimeline
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assert
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.click
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.performClick
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.settings.SettingsScreen
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.getBoundsInRoot
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.rememberSystemBack
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.TAB_HOME
import com.nur.prayer.ui.shell.LocalShell
import com.nur.prayer.ui.shell.PrayerSheetHost
import com.nur.prayer.ui.shell.ShellLayer
import com.nur.prayer.ui.shell.ShellState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.DpRect
import com.nur.prayer.ui.qibla.Heading
import com.nur.prayer.ui.qibla.HeadingSource
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Run in the existing API 26 / 34 CI matrix. Authored here, not claimed as locally executed. */
@RunWith(AndroidJUnit4::class)
class ObservatoryScreenTest {
    @get:Rule val compose = createComposeRule()
    private val moment = ZonedDateTime.parse("2026-09-07T21:00:00+03:00[Europe/Moscow]")
    private val actions = AppActions({}, {}, {}, {}, {}, {}, {}, {}, {}, { _, _ -> }, { _, _ -> }, {}, {}, {}, {}, {})

    /** Home UI flags live in «nur_ui»; every test starts as on a first launch. */
    @Before fun startFresh() {
        InstrumentationRegistry.getInstrumentation().targetContext
            .getSharedPreferences("nur_ui", Context.MODE_PRIVATE).edit().clear().commit()
    }

    /** Nodes whose merged description starts with [prefix]: times say «Зухр 12:12», the countdown «До …». */
    private fun described(prefix: String) = SemanticsMatcher("description starts with $prefix") { node ->
        node.config.getOrNull(SemanticsProperties.ContentDescription)?.any { it.startsWith(prefix) } == true
    }

    /** 0.27.0: home, the capsule over it and the prayer sheet, wired the way NurRoot wires them. */
    private fun showHome(
        data: PrayerData,
        opened: MutableList<String> = mutableListOf(),
        repository: SettingsRepository? = null
    ) = compose.setContent {
        NurTheme {
            val shell = remember { ShellState() }
            var sheet by remember { mutableStateOf<Prayer?>(null) }
            val scope = rememberCoroutineScope()
            val stored = repository?.settings?.collectAsState(initial = data.settings)?.value ?: data.settings
            val displayed = data.copy(settings = data.settings.copy(notifications = stored.notifications))
            val now = remember { mutableStateOf(moment) }
            CompositionLocalProvider(LocalShell provides shell) {
                Box(Modifier.fillMaxSize()) {
                    HomeScreen(
                        data = displayed, now = now,
                        onSetNotification = { prayer, enabled ->
                            if (repository != null) scope.launch { repository.setNotification(prayer, enabled) }
                            else actions.setNotification(prayer, enabled)
                        },
                        onOpenCity = { opened += "city" },
                        onOpenSchedule = { opened += "schedule" },
                        onOpenPrayer = { sheet = it }
                    )
                    ShellLayer(
                        shell = shell, route = TAB_HOME,
                        onOpenSection = { section, _ -> opened += section.name },
                        onHome = { opened += "home" }
                    )
                    PrayerSheetHost(
                        prayer = sheet, data = displayed, actions = actions,
                        notificationsAllowed = true, exactAlarmsAllowed = true,
                        onDismiss = { sheet = null }
                    )
                }
            }
        }
    }
    private fun fixture(): PrayerData {
        val city = City.MOSCOW
        val settings = AppSettings()
        val params = settings.paramsFor(city.country)
        val place = Place(city.name, city.subtitle, city.country, city.coordinates, city.zone, false)
        return PrayerData(place, PrayerEngine.days(moment.toLocalDate(), 3, city.coordinates, city.zone, params),
            PrayerEngine.window(moment, city.coordinates, city.zone, params), qiblaBearing(city.coordinates),
            distanceToKaabaKm(city.coordinates), HijriCalendar.format(moment.toLocalDate()), settings,
            settings.profileFor(city.country), params)
    }

    @Test fun homeShowsOneCountdownAndSixTimesOnlyOnDemand() {
        showHome(fixture())
        compose.onAllNodes(described("До ")).assertCountEquals(1)
        compose.onNodeWithTag("home-day-list").assertDoesNotExist()
        compose.onNodeWithTag("home-day-toggle").performClick()
        val list = compose.onNodeWithTag("home-day-list")
        listOf(Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA).forEach {
            val name = PrayerLabels.title(it)
            list.performScrollToNode(hasText(name))
            compose.onNode(hasText(name) and hasAnyAncestor(hasTestTag("home-day-list"))).assertIsDisplayed()
        }
    }

    @Test fun pullingDownRestoresTheTimerWithoutAnotherWindow() {
        val data = fixture()
        showHome(data)
        compose.onNodeWithTag("home-day-toggle").performClick()
        val date = Format.fullDate(data.today.date).replaceFirstChar { it.titlecase(com.nur.prayer.i18n.L10n.language.locale) }
        compose.onNodeWithText(date).assertIsDisplayed()
        compose.onNodeWithText("Расписание дня").assertDoesNotExist()
        compose.onNodeWithTag("home-day-list").performTouchInput {
            swipe(Offset(width * .5f, height * .12f), Offset(width * .5f, height * .9f))
        }
        compose.onNodeWithTag("home-day-list").assertDoesNotExist()
        compose.onNodeWithTag("home-day-toggle").assertIsDisplayed()
    }

    @Test fun shortVerticalDragSnapsBackWithoutOpeningTheList() {
        showHome(fixture())
        compose.onNodeWithTag("home-center").performTouchInput {
            swipe(center, center - Offset(0f, 30.dp.toPx()))
        }
        compose.onNodeWithTag("home-day-list").assertDoesNotExist()
        compose.onNodeWithTag("home-day-toggle").assertIsDisplayed()
    }

    @Test fun narrowHomeWithLargeSystemFontKeepsBothNamesAndTheButton() {
        val data = fixture()
        val w = data.window
        val nameA = PrayerLabels.title(HomeTimeline.current(w, data.fajrEqualsDawn))
        val nameB = PrayerLabels.title(HomeTimeline.next(w, data.fajrEqualsDawn))
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, 1.6f)) {
                NurTheme {
                    Box(Modifier.width(320.dp)) {
                        HomeScreen(data, remember { mutableStateOf(moment) }, { _, _ -> }, {}, {}, {})
                    }
                }
            }
        }
        val left = compose.onNodeWithText(nameA, useUnmergedTree = true).assertIsDisplayed().getBoundsInRoot()
        val right = compose.onNodeWithText(nameB, useUnmergedTree = true).assertIsDisplayed().getBoundsInRoot()
        assertTrue(left.right < right.left)
        val pill = compose.onNodeWithTag("home-day-toggle").assertIsDisplayed().getBoundsInRoot()
        assertTrue(pill.bottom - pill.top >= 48.dp)
    }

    @Test fun aSecondTickKeepsOneInstanceOfEachSlotAndUpdatesTheClock() {
        val data = fixture()
        val clock = mutableStateOf(moment)
        compose.setContent {
            NurTheme { HomeScreen(data, clock, { _, _ -> }, {}, {}, {}) }
        }
        val next = PrayerLabels.title(HomeTimeline.next(data.window, data.fajrEqualsDawn))
        val first = Format.countdown(data.window.remaining(moment))
        compose.onNodeWithContentDescription("До $next: $first").assertExists()
        compose.runOnIdle { clock.value = moment.plusSeconds(1) }
        val second = Format.countdown(data.window.remaining(moment.plusSeconds(1)))
        compose.onNodeWithContentDescription("До $next: $second").assertExists()
        compose.onAllNodesWithText(next).assertCountEquals(1)
    }

    @Test fun aSidewaysDragAndACityTapDoNotOpenTheList() {
        val data = fixture()
        val opened = mutableListOf<String>()
        showHome(data, opened)
        compose.onNodeWithTag("home-center").performTouchInput {
            swipe(Offset(width * 0.06f, height * 0.25f), Offset(width * 0.92f, height * 0.24f))
        }
        compose.onNodeWithTag("home-day-list").assertDoesNotExist()
        compose.onNodeWithText(data.place.label).performTouchInput { click() }
        compose.runOnIdle { assertEquals(listOf("city"), opened) }
        compose.onNodeWithTag("home-day-list").assertDoesNotExist()
    }

    @Test fun swipeAndTapShareOneListAndBellPersistsWhenReopened() {
        val inst = InstrumentationRegistry.getInstrumentation()
        val repo = SettingsRepository(inst.targetContext)
        val p = Prayer.FAJR
        val initial = runBlocking { repo.settings.first().notifications[p] == true }
        val bell = "Уведомление · ${PrayerLabels.title(p)}"
        try {
            showHome(fixture(), repository = repo)
            compose.onNodeWithTag("home-center").performTouchInput {
                swipe(Offset(width * 0.04f, height * 0.70f), Offset(width * 0.04f, height * 0.08f))
            }
            val list = compose.onNodeWithTag("home-day-list").assertIsDisplayed()
            list.performScrollToNode(hasContentDescription(bell))
            compose.onNodeWithContentDescription(bell).performClick()
            // Read the actual persisted preference, not a local boolean held by the row.
            runBlocking { kotlinx.coroutines.withTimeout(5000) { repo.settings.first { it.notifications[p] == !initial } } }
            inst.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
            compose.waitUntil(5000) { compose.onAllNodes(hasTestTag("home-day-list")).fetchSemanticsNodes().isEmpty() }
            compose.onNodeWithTag("home-day-toggle").performClick()
            compose.onNodeWithTag("home-day-list").performScrollToNode(hasContentDescription(bell))
            val switch = compose.onNodeWithContentDescription(bell)
            if (initial) switch.assertIsOff() else switch.assertIsOn()
        } finally {
            runBlocking { repo.setNotification(p, initial) }
        }
    }

    private fun openNoonSheet(): PrayerData {
        val data = fixture()
        showHome(data)
        compose.onNodeWithTag("home-day-toggle").performClick()
        val name = PrayerLabels.title(Prayer.DHUHR)
        compose.onNodeWithTag("home-day-list").performScrollToNode(hasText(name))
        compose.onNode(hasText(name) and hasAnyAncestor(hasTestTag("home-day-list"))).performClick()
        compose.onNodeWithTag("prayer-sheet").assertIsDisplayed()
        return data
    }

    @Test fun aJitterReturnsButALightPullInsideCloses() {
        openNoonSheet()
        val sheet = compose.onNodeWithTag("prayer-sheet")
        val rest = sheet.getBoundsInRoot()
        sheet.performTouchInput { swipe(center, center + Offset(0f, 18.dp.toPx()), 40L) }
        assertEquals(rest, sheet.getBoundsInRoot())
        sheet.performTouchInput { swipe(center, center + Offset(0f, 50.dp.toPx()), 320L) }
        sheet.assertDoesNotExist()
        compose.onNodeWithTag("home-day-toggle").assertIsDisplayed()
    }

    @Test fun pageTurnPreservesHeightAndTheScrimTakesDragsNotTaps() {
        val data = openNoonSheet()
        val sheet = compose.onNodeWithTag("prayer-sheet")
        val bounds = sheet.getBoundsInRoot()
        sheet.performTouchInput { swipeLeft() }
        val ix = HomeTimeline.pageOf(Prayer.ASR, data.fajrEqualsDawn)
        compose.onNodeWithContentDescription("Страница ${ix + 1} из ${HomeTimeline.prayers(data.fajrEqualsDawn).size}").assertIsDisplayed()
        assertEquals(bounds, sheet.getBoundsInRoot())
        val grip = compose.onNodeWithTag("sheet-grabber").getBoundsInRoot()
        compose.onRoot().performTouchInput { click(Offset(center.x, (grip.top - 2.dp).toPx().coerceAtLeast(1f))) }
        sheet.assertIsDisplayed()
        compose.onRoot().performTouchInput {
            val start = Offset(center.x, (grip.top - 2.dp).toPx().coerceAtLeast(1f))
            swipe(start, start + Offset(0f, 50.dp.toPx()), 300L)
        }
        sheet.assertDoesNotExist()
    }

    @Test fun smallSheetCanScrollAdjustAndChooseSoundWithoutClosing() {
        val data = fixture()
        val prayer = Prayer.ASR
        val displayed = data.copy(settings = data.settings.copy(notifications = data.settings.notifications + (prayer to true)))
        var permissionRequests = 0
        var correction: Pair<Prayer, Int>? = null
        var dismissed = false
        val local = actions.copy(openNotificationSettings = { permissionRequests++ }, setOffset = { p, v -> correction = p to v })
        compose.setContent { NurTheme {
            Box(Modifier.fillMaxWidth().height(420.dp)) {
                PrayerSheetHost(prayer, displayed, local, notificationsAllowed = false, exactAlarmsAllowed = true,
                    onDismiss = { dismissed = true })
            }
        } }
        val sheet = compose.onNodeWithTag("prayer-sheet")
        val bounds = sheet.getBoundsInRoot()
        compose.onNodeWithText("Включить").performScrollTo().performTouchInput { click() }
        compose.onNodeWithText("Звук").performScrollTo().performTouchInput { click() }
        val plus = compose.onNodeWithContentDescription("Увеличить: Поправка времени")
        plus.performScrollTo().performTouchInput { click() }
        // There is now an expanded sound list above us: dragging down scrolls it, not the window.
        sheet.performTouchInput { swipe(center, center + Offset(0f, 52.dp.toPx()), 400L) }
        assertEquals(bounds, sheet.getBoundsInRoot())
        compose.runOnIdle {
            assertEquals(1, permissionRequests)
            assertEquals(prayer to ((data.settings.offsets[prayer] ?: 0) + 1), correction)
            assertTrue(!dismissed)
        }
    }

    @Test fun theCapsuleOpensIntoThePanelAndEachCellDispatchesItsSection() {
        val opened = mutableListOf<String>()
        showHome(fixture(), opened)
        listOf("Кыбла", "Месяц", "Зикр").forEach { label ->
            compose.onNodeWithContentDescription("Разделы").performClick()
            compose.waitUntil(3000) { compose.onAllNodesWithContentDescription(label).fetchSemanticsNodes().isNotEmpty() }
            compose.onNodeWithContentDescription(label).performClick()
            compose.waitUntil(3000) { compose.onAllNodesWithContentDescription(label).fetchSemanticsNodes().isEmpty() }
        }
        compose.runOnIdle { assertEquals(listOf("QIBLA", "SCHEDULE", "DHIKR"), opened) }
    }

    @Test fun physicalTapOpensDismissesAndReopensTheCompactPanel() {
        val opened = mutableListOf<String>()
        showHome(fixture(), opened)
        val button = compose.onNodeWithContentDescription("Разделы")
        button.performTouchInput { click() }
        compose.waitForIdle()
        listOf("Зикр", "Кыбла", "Дела", "Месяц", "Настройки").forEach {
            compose.onNodeWithContentDescription(it).assertIsDisplayed()
        }
        assertEquals(compose.onRoot().getBoundsInRoot(), compose.onNodeWithTag("shell-panel-scrim").getBoundsInRoot())
        compose.onRoot().performTouchInput { click(center) }
        compose.waitForIdle()
        compose.onNodeWithContentDescription("Настройки").assertDoesNotExist()
        button.assertIsDisplayed().performTouchInput { click() }
        compose.waitForIdle()
        compose.onNodeWithContentDescription("Дела").performTouchInput { click() }
        compose.waitForIdle()
        button.assertIsDisplayed().performTouchInput { click() }
        compose.waitForIdle()
        compose.onNodeWithContentDescription("Настройки").performTouchInput { click() }
        compose.runOnIdle { assertEquals(listOf("TODAY", "SETTINGS"), opened) }
    }

    /** 0.37.0: the Quran is the left button of the bar itself, not a cell of the panel. */
    @Test fun theQuranIsTheLeftButtonOfTheBarAndNotACellOfThePanel() {
        val opened = mutableListOf<String>()
        showHome(fixture(), opened)
        compose.onNodeWithContentDescription("Коран").performClick()
        compose.runOnIdle { assertEquals(listOf("QURAN"), opened) }
        compose.onNodeWithContentDescription("Разделы").performClick()
        compose.waitUntil(3000) { compose.onAllNodesWithContentDescription("Кыбла").fetchSemanticsNodes().isNotEmpty() }
        // While the panel is up the bar's side buttons are out of the semantic tree, and the panel has no Quran cell.
        compose.onNodeWithContentDescription("Коран").assertDoesNotExist()
    }

    /** 0.38.0: «Учёба» is the pill on the right of the bar (it used to be the azkar of the moment) and opens the course. */
    @Test fun thePillOpensTheCourseAndTheGearOfThePanelOpensSettings() {
        val opened = mutableListOf<String>()
        showHome(fixture(), opened)
        compose.onNodeWithText("Учёба").performClick()
        // There is no avatar in the corner any more: settings are the gear in the panel the capsule opens into.
        compose.onNodeWithContentDescription("Настройки").assertDoesNotExist()
        compose.onNodeWithContentDescription("Разделы").performClick()
        compose.waitUntil(3000) { compose.onAllNodesWithContentDescription("Настройки").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Настройки").performClick()
        compose.runOnIdle { assertEquals(listOf("COURSE", "SETTINGS"), opened) }
    }

    /** 0.38.0: what the bar has the panel does not repeat: «Учёба» is not a cell of the panel any more. */
    @Test fun theCourseIsThePillOfTheBarAndNotACellOfThePanel() {
        showHome(fixture())
        compose.onNodeWithContentDescription("Разделы").performClick()
        compose.waitUntil(3000) { compose.onAllNodesWithContentDescription("Кыбла").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Учёба").assertDoesNotExist()
        compose.onNodeWithContentDescription("Учёба").assertDoesNotExist()
    }

    /** 0.38.0: the middle button is at the centre of the screen; the Quran and the pill stand 33 dp from it, all 35.5 dp high. */
    @Test fun theMiddleButtonIsAtTheCentreAndTheOthersStandEvenlyFromIt() {
        showHome(fixture())
        val root = compose.onRoot().getBoundsInRoot()
        val middle = compose.onNodeWithContentDescription("Разделы").getBoundsInRoot()
        val left = compose.onNodeWithContentDescription("Коран").getBoundsInRoot()
        val pill = compose.onNodeWithText("Учёба").getBoundsInRoot()
        // DpRect.width / .height are extension properties that need their own imports; plain right - left does not.
        fun width(r: DpRect) = r.right.value - r.left.value
        fun height(r: DpRect) = r.bottom.value - r.top.value
        assertEquals(width(root) / 2f, (middle.left.value + middle.right.value) / 2f, 1f)
        assertEquals(35.5f, width(middle), 1f)
        assertEquals(35.5f, width(left), 1f)
        assertEquals(35.5f, height(pill), 1f)
        assertEquals(33f, middle.left.value - left.right.value, 1f)
        assertEquals(33f, pill.left.value - middle.right.value, 1f)
        assertEquals(95f, width(pill), 1f)
    }

    @Test fun homeDoesNotDisplayDecorativeCopy() {
        showHome(fixture())
        compose.onNodeWithText("Время для главного").assertDoesNotExist()
        compose.onNodeWithText("СЛЕДУЮЩЕЕ ВРЕМЯ").assertDoesNotExist()
        compose.onNodeWithText("ПУТЬ ВРЕМЕНИ").assertDoesNotExist()
        compose.onNodeWithText("КАЛЕНДАРЬ").assertDoesNotExist()
    }

    /** 0.27.1: the sensor details are a mini button above the capsule that pops a card up, not an accordion. */
    @Test fun sensorDetailsPopUpFromTheMiniButtonAndGoAwayAgain() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading()) } }
        compose.onAllNodesWithText("Азимут кыблы").assertCountEquals(0)
        compose.onNodeWithContentDescription("Точность и датчики").performClick()
        compose.waitUntil(3000) { compose.onAllNodesWithText("Азимут кыблы").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Точность и датчики").performClick()
        compose.waitUntil(3000) { compose.onAllNodesWithText("Азимут кыблы").fetchSemanticsNodes().isEmpty() }
    }

    @Test fun unavailableSensorCannotShowDirectionFound() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading()) } }
        compose.onNodeWithText("Компас недоступен").assertIsDisplayed()
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Нет достоверного направления"))
        compose.onNodeWithContentDescription("Кааба — направление кыблы").assertIsDisplayed()
    }
    @Test fun magneticInterferenceCannotReportLockEvenAtTargetAzimuth() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 110f, source = HeadingSource.FUSED)) } }
        compose.onNodeWithText("Проверьте калибровку и помехи").assertIsDisplayed()
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Нет достоверного направления"))
    }
    @Test fun alignedCalibratedFlatSensorShowsLock() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 45f, source = HeadingSource.FUSED)) } }
        // 0.23.0: the dial searches first (≥ 1 s), then turns onto the bearing and only then confirms.
        compose.waitUntil(8000) { compose.onAllNodesWithText("Направление на Каабу").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Направление найдено"))
    }
    /** 0.23.0: the hold does not matter — a phone held upright like a camera finds the Kaaba too. */
    @Test fun tiltedSensorStillFindsDirection() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 45f, tiltDegrees = 60f, source = HeadingSource.FUSED)) } }
        compose.waitUntil(8000) { compose.onAllNodesWithText("Направление на Каабу").fetchSemanticsNodes().isNotEmpty() }
        compose.onAllNodesWithText("Положите телефон горизонтально").assertCountEquals(0)
    }
    @Test fun everySettingsEditorOpensAndReturnsToTheIndex() {
        val data = fixture()
        // 0.34.0: the editors have no back arrow; the way out is the ring of NurRoot, which asks for the system back.
        var back: () -> Unit = {}
        compose.setContent { NurTheme { back = rememberSystemBack(); SettingsScreen(data, paletteFor(Prayer.ISHA), actions, true) } }
        compose.onNodeWithText("Ваш Нур").assertDoesNotExist()
        listOf("method", "madhab", "notify", "azan", "highlat", "rounding", "offsets", "about").forEach { id ->
            compose.onNodeWithTag("settings-index").performScrollToNode(hasTestTag("setting-$id"))
            compose.onNodeWithTag("setting-$id").performClick()
            compose.onNodeWithTag("settings-$id").assertIsDisplayed()
            compose.runOnIdle { back() }
            compose.onNodeWithTag("settings-index").assertIsDisplayed()
        }
    }

}
