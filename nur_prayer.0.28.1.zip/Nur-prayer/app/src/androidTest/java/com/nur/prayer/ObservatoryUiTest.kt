package com.nur.prayer

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeLeft
import androidx.compose.ui.test.swipeRight
import androidx.compose.ui.test.performClick
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.ui.schedule.CalendarMonthModel
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.schedule.CalendarTodayChip
import com.nur.prayer.ui.schedule.MonthCalendar
import com.nur.prayer.ui.schedule.PeriodBar
import com.nur.prayer.ui.schedule.PeriodRange
import com.nur.prayer.ui.theme.NurTheme
import java.time.LocalDate
import java.time.YearMonth
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ObservatoryUiTest {
    @get:Rule val compose = createComposeRule()

    /**
     * 0.28.0: the header left MonthCalendar for the shared PeriodBar, and "К сегодня" for the day card, so the
     * harness wires the three the way ScheduleScreen does: the same bounds, the same selection rule.
     */
    private fun calendar(today: LocalDate, initial: YearMonth = YearMonth.from(today)) {
        compose.setContent {
            NurTheme {
                var month by remember { mutableStateOf(initial) }
                var selected by remember { mutableStateOf(today) }
                val years = PeriodRange.gregorianYears(today)
                val move = { target: YearMonth ->
                    month = target
                    selected = CalendarMonthModel.moveSelection(selected, target)
                }
                Column(Modifier.width(320.dp)) {
                    PeriodBar(
                        title = "${Format.monthName(month.monthValue)} ${month.year}", subtitle = "",
                        prevLabel = "Предыдущий месяц", nextLabel = "Следующий месяц",
                        canPrev = month > YearMonth.of(years.first, 1), canNext = month < YearMonth.of(years.last, 12),
                        onPrev = { move(month.minusMonths(1)) }, onNext = { move(month.plusMonths(1)) },
                        onPick = {}, ink = Color.Black, subInk = Color.Black
                    )
                    MonthCalendar(month, selected, today, 0, onMonth = move, onSelect = { selected = it })
                    CalendarTodayChip(selected == today, onClick = { month = YearMonth.from(today); selected = today })
                }
            }
        }
    }

    @Test fun fullMonthHasSelectableLastDayOnCompactViewport() {
        calendar(LocalDate.of(2026, 9, 7))
        compose.onNodeWithTag("calendar-day-2026-09-30").assertIsDisplayed().performClick().assertIsSelected()
    }
    @Test fun changingMonthAndReturningTodayWorks() {
        calendar(LocalDate.of(2026, 9, 7))
        compose.onNodeWithContentDescription("Следующий месяц").performClick()
        compose.onNodeWithTag("calendar-day-2026-10-15").assertIsDisplayed()
        compose.onNodeWithTag("calendar-today").performClick()
        compose.onNodeWithTag("calendar-day-2026-09-07").assertIsSelected()
    }
    @Test fun leapDayCanBeSelected() {
        calendar(LocalDate.of(2028, 2, 1))
        compose.onNodeWithTag("calendar-day-2028-02-29").performClick().assertIsSelected()
    }
    @Test fun adjacentMonthPaddingDoesNotDispatchSelection() {
        calendar(LocalDate.of(2026, 9, 7))
        compose.onNodeWithTag("calendar-day-2026-08-31").assertIsNotEnabled()
        compose.onNodeWithTag("calendar-day-2026-09-07").assertIsSelected()
    }
    // 0.19.0: the month wheel offers ±10 years, and the arrows and the swipe go exactly as far.
    @Test fun navigationHasAnExplicitUpperBound() {
        calendar(LocalDate.of(2026, 9, 7), YearMonth.of(2036, 12))
        compose.onNodeWithContentDescription("Следующий месяц").assertIsNotEnabled()
    }
    @Test fun swipingChangesMonthAndCanBeReversed() {
        calendar(LocalDate.of(2026, 9, 7))
        compose.onNodeWithTag("calendar-grid").performTouchInput { swipeLeft() }
        compose.onNodeWithTag("calendar-day-2026-10-15").assertIsDisplayed()
        compose.onNodeWithTag("calendar-grid").performTouchInput { swipeRight() }
        compose.onNodeWithTag("calendar-day-2026-09-15").assertIsDisplayed()
    }
    @Test fun swipeCannotGoBeyondUpperBound() {
        calendar(LocalDate.of(2026, 9, 7), YearMonth.of(2036, 12))
        compose.onNodeWithTag("calendar-grid").performTouchInput { swipeLeft() }
        compose.onNodeWithTag("calendar-day-2036-12-15").assertIsDisplayed()
    }

}
