package com.nur.prayer.ui.shell

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.indication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.ripple
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import com.nur.prayer.ui.today.DeedGlyphIcon
import com.nur.prayer.ui.components.ExitButtonSpec
import com.nur.prayer.ui.ringWanted
import com.nur.prayer.ui.components.pageContentInsets
import com.nur.prayer.ui.today.DeedGlyph
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.paddingFromBaseline
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.toRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.rememberAmbientMotionAllowed
import com.nur.prayer.ui.home.HomeSection
import com.nur.prayer.ui.home.HomeTimeline
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/*
 * 0.27.0 «Капсула» (variant D of the redesign).
 *
 *  - Home: the times are printed on the wallpaper; at the bottom one floating capsule says what fits
 *    this moment («Вечерние азкары · сейчас · 0 из 12»). A tap on its text starts that; a tap on the
 *    dots opens the panel.
 *  - The panel is the same glass grown in place (shared bounds): today's six times (a tap opens the
 *    prayer's sheet, the speaker marks the azan) and the six sections, each one tap away. A tap
 *    beside it, or back, folds it back into the capsule.
 *  - In a section the capsule says where you are («Кыбла · тап — другие разделы») and opens the same
 *    panel; the moon leads home; the countdown lives in the island at the top.
 *
 * No swipes and no hidden gestures: everything is visible and tappable, TalkBack reads it as is.
 * Every sizes and colours here are taken from the mock (see ShellColors).
 *
 * 0.33.0 «Минарет»: a new mock, a warm cream glass with a minaret roof on the panel.
 *
 * 0.39.0 «Капля» supersedes everything below about the open panel: it has no times, no header and no cards, only the four
 * sections and the settings on a matte glass, and it grows out of the middle button sideways first (see [PanelLayout]).
 *
 * 0.36.0 «Бумага»: the cream and the roof are gone. The new mock is paper: a flat #FAFAFA panel with no rim, cards
 * that are only a soft shade, black ink; the section wells are saturated discs with a white glyph, one hue per
 * section (see ShellTones), and the capsule is smaller (50 dp, a 34 dp pastel disc, no divider, a quiet dots
 * button) and takes the hue of the place or of the task it offers. The glyphs themselves are the same as in 0.33.0.
 * Every size below is a measurement of the mock at 1.4667 px per dp (576 px = 393 dp, a 1080 px phone at 2.75
 * density, downscaled): the comments give the pixels they come from.
 *
 * 0.27.1, the motion:
 *  - the capsule and the panel stay composed for as long as the capsule is on a route. Opening used to
 *    compose ~60 nodes of the panel on the first frame of the morph (and the capsule's content again on
 *    the last frame of the fold): that was the stutter. Now only a float moves;
 *  - layers fade per draw call ([CompositingStrategy.ModulateAlpha]): no offscreen buffer the size of the
 *    panel in every frame of the fade;
 *  - the glass has no elevation shadow and no path clip (see Frost.kt);
 *  - a capsule that comes or goes slides by a layout offset, not a layer translation, so the glass keeps
 *    knowing where on screen it is and the blurred picture inside it never lags behind;
 *  - [ShellState.capsuleHidden]: a page can send the capsule away (the Quran reader while one reads) and
 *    call it back with one float.
 */

/*
 * 0.37.0: the capsule is a bar of three round things, after the reference the owner sent: a button at each end of the
 * row and the panel's button in the middle, all on one line, 46 dp high. Left: the Quran on home (a veil button with a
 * white ring, the reference's outlined circle), and inside a section the way home, a disc in the hue of the section.
 * Middle: three dots on a veil, the panel grows out of it. Right: the task of the moment as a pill in its hue (mint
 * for the evening azkar, gold for the morning ones), hidden on the azkar page itself. The Quran is not in the panel
 * any more: what the bar has the panel does not repeat. In the old capsule the section's name was spelt out; now
 * the page has its own title and the hue of the left button says where the user is.
 */
/*
 * 0.38.0 «Учёба»: the bar is redrawn after a new reference, to the pixel (the numbers and where they come from are in
 * [BarLayout]). All three things are 35.5 dp high; the two rings are round and 35.5 dp across, and nearly transparent:
 * a ring and a faint shade of black (8 %) inside, the picture shows through. The middle one is exactly at the centre of
 * the screen, the Quran button and the pill stand 33 dp from it on each side. The middle button wears the reference's
 * four dots (⌀ 4.1 dp, see [ShellGlyph.APPS]), the Quran button keeps the 0.37 book. The right-hand thing is not the azkar
 * of the moment any more but a constant: «Учёба», a light grey pill with dark ink, with a glint running over it now and
 * then ([PillShimmer]). It opens the course page like the panel's «Учёба» cell did, and that cell is gone from the panel
 * (the panel does not repeat what the bar has): the learning will get its own format later. Inside a section the buttons
 * keep the firmer veil of 0.37: the page under the bar there may be white paper.
 */
private val BAR_BUTTON = BarLayout.BUTTON.dp
/** Least room between the pill and the screen's edge. */
private val BAR_MARGIN = BarLayout.MARGIN.dp
/** Between the middle button and each of the two others. */
private val BAR_GAP = BarLayout.GAP.dp
/** The width of the pill of the reference. */
private val PILL_WIDTH = BarLayout.PILL_WIDTH.dp
/** The ring of a veil button: 2 px of the reference at 1.4667 px per dp, a hair of it fading, so 1.2 dp. */
private val BAR_RING = 1.2.dp
/** The moon of the way home was 22 dp in the 46 dp button; it keeps its share. */
private const val MOON_SHARE = 22f / 46f
/** The four dots live on a 24-unit grid where one unit is one dp (see [ShellGlyph.APPS]). */
private val APPS_BOX = 24.dp
/** What the home and the pages reserve under their content for the capsule. Unchanged since 0.27.0. */
private val BOTTOM_GAP = 14.dp

/** 0.30.2: where the capsule really stands above the navigation bar: 1 dp lower than the room it has reserved. */
private val CAPSULE_BOTTOM = 13.dp

/**
 * Bottom room the capsule takes above the navigation bar; pages under it pad their lists by it. 0.36.0: the capsule
 * got 14 dp lower, the room did not: the clock, the timeline and every page stay exactly where the user knows them.
 */
val CapsuleRoom = 90.dp

/** Room the island takes under the status bar; page headers step down by it. */
val IslandRoom = 50.dp

@Composable
fun ShellLayer(
    shell: ShellState,
    route: String,
    data: PrayerData,
    now: State<ZonedDateTime>,
    onOpenSection: (HomeSection, Offset) -> Unit,
    onHome: (Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val capsuleOn = ShellRoutes.capsuleOn(route)
    val islandOn = ShellRoutes.islandOn(route)
    // The page under the capsule keeps being named while the capsule slides away with it.
    val lastSection = remember { arrayOfNulls<HomeSection>(1) }
    val liveSection = ShellRoutes.sectionOf(route)
    if (capsuleOn) lastSection[0] = liveSection
    val section = if (capsuleOn) liveSection else lastSection[0]

    // A hidden capsule is not a capsule the panel can grow out of.
    val capsuleVisible = ShellMath.capsuleVisible(capsuleOn, shell.capsuleHidden)
    LaunchedEffect(capsuleVisible) { if (!capsuleVisible) shell.hide() }
    LaunchedEffect(shell.open) {
        coroutineScope {
            // 0.30.2: the vibrator call goes after the first frame of the morph, not in front of it: on a
            // phone where it takes a few milliseconds that used to be a hitch right at the tap.
            if (shell.open) launch {
                withFrameNanos { }
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            }
            shell.settle()
        }
    }
    BackHandler(enabled = shell.open) { shell.hide() }

    val panelOnScreen by remember(shell) { derivedStateOf { shell.open || shell.progress > 0.001f } }
    val capsuleShown = animateFloatAsState(
        if (capsuleVisible) 1f else 0f,
        tween(if (capsuleVisible) 320 else 200, easing = FastOutSlowInEasing),
        label = "capsuleShown"
    )
    val islandShown = animateFloatAsState(
        if (islandOn) 1f else 0f,
        tween(if (islandOn) 320 else 180, easing = FastOutSlowInEasing),
        label = "islandShown"
    )
    // The veil of the middle button: faint on home (the scrimmed wallpaper), firmer in a section (maybe a white page).
    val veil = animateColorAsState(
        if (section == null) ShellColors.BarGlass else ShellColors.BarGlassPage,
        tween(220), label = "barVeil"
    )
    // 0.39.0: over the Quran's white page the matte glass of the panel turns into flat white paper.
    val paper = animateFloatAsState(
        if (ShellRoutes.paperPage(route)) 1f else 0f,
        tween(220), label = "panelPaper"
    )
    val capsuleComposed by remember { derivedStateOf { capsuleShown.value > 0f } }
    val islandComposed by remember { derivedStateOf { islandShown.value > 0f } }

    Box(modifier.fillMaxSize()) {
        if (panelOnScreen) {
            // A tap anywhere beside the panel folds it; the page under it stays where it was.
            Box(
                Modifier
                    .fillMaxSize()
                    .testTag("shell-panel-scrim")
                    .drawBehind { drawRect(Color.Black, alpha = SCRIM_ALPHA * shell.progress.coerceIn(0f, 1f)) }
                    .pointerInput(shell) { detectTapGestures { shell.hide() } }
            )
        }
        Box(Modifier.fillMaxSize().pageContentInsets()) {
            if (islandComposed) {
                TopIsland(
                    data, now, onTap = onHome,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset { IntOffset(0, (-(1f - islandShown.value) * 20.dp.toPx()).roundToInt()) }
                        .graphicsLayer {
                            val k = islandShown.value
                            alpha = k
                            compositingStrategy = CompositingStrategy.ModulateAlpha
                            val s = 0.92f + 0.08f * k
                            scaleX = s
                            scaleY = s
                        }
                )
            }
            if (capsuleComposed) {
                val openSection: (HomeSection, Offset) -> Unit = { target, origin ->
                    shell.hide()
                    // The page the section opens on is already showing: folding the panel is the answer.
                    if (route != ShellRoutes.routeOf(target)) onOpenSection(target, origin)
                }
                // «Учёба» has nothing to offer on its own pages.
                val pillShown = animateFloatAsState(
                    if (section == HomeSection.COURSE) 0f else 1f,
                    tween(180, easing = FastOutSlowInEasing),
                    label = "pillShown"
                )
                BoxWithConstraints(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(bottom = CAPSULE_BOTTOM + if (capsuleOn && ringWanted(route)) ExitButtonSpec.BarClearance else 0.dp)
                        .offset { IntOffset(0, ((1f - capsuleShown.value) * ShellMath.SLIDE_DP.dp.toPx()).roundToInt()) }
                        .graphicsLayer {
                            alpha = capsuleShown.value
                            compositingStrategy = CompositingStrategy.ModulateAlpha
                        }
                ) {
                    // The middle button is at the centre; the others are placed from it (see BarLayout).
                    val leftStart = BarLayout.leftStart(maxWidth.value).dp
                    val pillStart = BarLayout.pillStart(maxWidth.value).dp
                    val pillRoom = maxOf(BarLayout.pillRoom(maxWidth.value), BarLayout.BUTTON).dp
                    val interactive = capsuleVisible && !shell.open
                    // The side buttons go first: the panel, which grows over them, must cover them.
                    BarLeft(
                        section = section, enabled = interactive,
                        onQuran = { origin -> openSection(HomeSection.QURAN, origin) },
                        onHome = { origin -> shell.hide(); onHome(origin) },
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = leftStart)
                            .barSide(shell)
                    )
                    if (pillShown.value > 0f) {
                        LearnPill(
                            enabled = interactive && pillShown.value > 0.99f, room = pillRoom,
                            onLearn = { origin -> openSection(HomeSection.COURSE, origin) },
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(start = pillStart)
                                .barSide(shell)
                                .graphicsLayer {
                                    alpha = pillShown.value
                                    compositingStrategy = CompositingStrategy.ModulateAlpha
                                }
                        )
                    }
                    CapsuleMorph(
                        shell = shell,
                        visible = capsuleVisible,
                        section = section,
                        veil = veil,
                        paper = paper,
                        onOpenSection = openSection,
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )
                }
            }
        }
    }
}

/**
 * The side buttons leave with the first third of the panel's way, as the capsule's content used to, and while the panel
 * is up TalkBack does not see them. Read while drawing only.
 */
private fun Modifier.barSide(shell: ShellState): Modifier = this
    .graphicsLayer {
        alpha = ShellMath.capsuleAlpha(ShellMath.clampProgress(shell.progress))
        compositingStrategy = CompositingStrategy.ModulateAlpha
    }
    .then(if (shell.open) Modifier.clearAndSetSemantics { } else Modifier)

private const val SCRIM_ALPHA = 0.30f

/**
 * The shape of the glass: a pill (a circle at first) while it spreads, the slab's own corners once it is tall enough to
 * have them. It follows the size it is given, not the progress, so the curve is right on every frame of a half-way turn.
 */
private object GlassShape : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val r = minOf(size.minDimension / 2f, with(density) { PanelLayout.CORNER.dp.toPx() })
        return Outline.Rounded(RoundRect(size.toRect(), CornerRadius(r)))
    }
}

/*
 * 0.39.0 «Капля»: the open panel grows out of the middle button like a drop spreading on a table. The glass is one
 * layout whose width runs ahead of its height ([ShellMath.reachProgress], [ShellMath.riseProgress]): a flat wide pill
 * stands for a moment, then it rises into the slab; the bottom edge stays where the button's was and the whole glass
 * floats [PanelLayout.LIFT] up as it opens. The cells appear from the middle outwards ([ShellMath.cellProgress]). Closing
 * is the same curves backwards: the slab is squashed flat, then it narrows into the circle. Everything is read in the
 * layout and draw phases from the one spring, so nothing recomposes while it moves.
 */
@Composable
private fun CapsuleMorph(
    shell: ShellState,
    visible: Boolean,
    section: HomeSection?,
    veil: State<Color>,
    paper: State<Float>,
    onOpenSection: (HomeSection, Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    val frost = rememberFrost()
    val open = shell.open

    // The veil of the closed button fades out under the matte glass that fades in over it.
    val body = remember(shell, veil) {
        {
            val v = veil.value
            v.copy(alpha = v.alpha * (1f - ShellMath.fillProgress(shell.progress)))
        }
    }
    // The veil has no halo; the panel has all of it.
    val matte = remember(shell) { { ShellMath.fillProgress(shell.progress) } }
    val sheet = remember(paper) { { paper.value } }
    Layout(
        content = {
            // Both faces stay composed; only the one that is up answers touches and TalkBack.
            Box(if (open || !visible) Modifier.clearAndSetSemantics { } else Modifier) {
                BarCenter(enabled = visible && !open, onExpand = { shell.show() })
            }
            Box(if (open) Modifier else Modifier.clearAndSetSemantics { }) {
                PanelContent(
                    current = section, enabled = open,
                    progress = { shell.progress }, onOpenSection = onOpenSection
                )
            }
        },
        modifier = modifier
            .offset {
                val lift = PanelLayout.LIFT.dp.toPx() * ShellMath.clampProgress(shell.progress).coerceAtMost(1f)
                IntOffset(0, (-lift).roundToInt())
            }
            .frostGlass(
                frost, GlassShape, style = GlassStyle.MATTE,
                body = body, haloScale = matte, matte = matte, paper = sheet
            )
            .onGloballyPositioned { c -> shell.glassBottomInRoot = c.boundsInRoot().bottom }
    ) { measurables, constraints ->
        val p = ShellMath.clampProgress(shell.progress)
        val maxW = constraints.maxWidth
        // Closed, the glass is the middle button: a circle.
        val capH = BAR_BUTTON.roundToPx()
        val capW = capH
        val panelW = minOf(maxW - 2 * PanelLayout.SIDE.dp.roundToPx(), PanelLayout.MAX_WIDTH.dp.roundToPx()).coerceAtLeast(capW)
        val panelH = PanelLayout.HEIGHT.dp.roundToPx()
        val capsule = measurables[0].measure(Constraints.fixed(capW, capH))
        val panel = measurables[1].measure(Constraints.fixed(panelW, panelH))
        val w = ShellMath.lerp(capW.toFloat(), panelW.toFloat(), ShellMath.reachProgress(p)).roundToInt().coerceIn(0, maxW)
        val h = ShellMath.lerp(capH.toFloat(), panelH.toFloat(), ShellMath.riseProgress(p)).roundToInt().coerceIn(0, constraints.maxHeight)
        layout(w, h) {
            // Alpha and clearAndSetSemantics do not remove a placed child from pointer hit testing.
            // Keep both measured for a smooth reversal, but never place an invisible face at rest.
            // While folding, the returning button must hit-test above the outgoing section cells.
            if (ShellMath.capsuleAlpha(p) > 0f || !open) capsule.placeWithLayer(
                (w - capW) / 2, h - capH, zIndex = if (open) 0f else 1f
            ) {
                alpha = ShellMath.capsuleAlpha(p)
                compositingStrategy = CompositingStrategy.ModulateAlpha
            }
            // The slab keeps its middle on the glass's middle: it is uncovered from the centre both ways.
            if (ShellMath.panelAlpha(p) > 0f) panel.placeWithLayer(
                (w - panelW) / 2, (h - panelH) / 2, zIndex = if (open) 1f else 0f
            ) {
                alpha = ShellMath.panelAlpha(p)
                compositingStrategy = CompositingStrategy.ModulateAlpha
            }
        }
    }
}

/** The middle button: four dots in a ring on the veil of the glass. The panel grows out of it. */
@Composable
private fun BarCenter(enabled: Boolean, onExpand: () -> Unit) {
    val label = tr("Разделы")
    Box(
        Modifier
            .fillMaxSize()
            .clip(CircleShape)
            .border(BAR_RING, ShellColors.BarRing, CircleShape)
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label, onClick = onExpand)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) {
        ShellIcon(ShellGlyph.APPS, ShellColors.BarInk, Modifier.size(APPS_BOX))
    }
}

/**
 * The left button. On home: the Quran, a nearly transparent circle with a white ring and a white book. In a section:
 * the way home, a disc in the hue of the section (a pastel with its dark moon), so the colour of the bar still says where the user is.
 */
@Composable
private fun BarLeft(
    section: HomeSection?,
    enabled: Boolean,
    onQuran: (Offset) -> Unit,
    onHome: (Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    val center = remember { arrayOf(Offset.Unspecified) }
    Box(modifier.size(BAR_BUTTON).onGloballyPositioned { center[0] = it.boundsInRoot().center }) {
        Crossfade(targetState = section, animationSpec = tween(220), label = "barLeft") { here ->
            val label = if (here == null) tr("Коран") else tr("На главную")
            val tone = if (here == null) null else ShellTones.of(here)
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(tone?.container ?: ShellColors.BarGlass)
                    .then(if (tone == null) Modifier.border(BAR_RING, ShellColors.BarRing, CircleShape) else Modifier)
                    .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) {
                        if (here == null) onQuran(center[0]) else onHome(center[0])
                    }
                    .semantics { contentDescription = label },
                contentAlignment = Alignment.Center
            ) {
                if (tone == null) DiscGlyph(ShellGlyph.BOOK, ShellColors.BarInk, BAR_BUTTON)
                else ShellIcon(ShellGlyph.MOON, tone.ink, Modifier.size(BAR_BUTTON * MOON_SHARE))
            }
        }
    }
}

/**
 * The right button: «Учёба», a light grey pill with dark ink (the reference's), 35.5 dp high and 95 dp wide, as wide as
 * the word needs if the word is longer in another language, never wider than [room], where it would meet the edge of
 * the screen: then the word shrinks. A glint runs over it now and then ([PillShimmer]) while the bar is at rest.
 */
@Composable
private fun LearnPill(enabled: Boolean, room: Dp, onLearn: (Offset) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val label = tr("Учёба")
    val center = remember { arrayOf(Offset.Unspecified) }
    val glintProgress = rememberGlint(running = rememberAmbientMotionAllowed() && enabled)
    Box(
        modifier
            .height(BAR_BUTTON)
            .widthIn(min = minOf(PILL_WIDTH, room), max = room)
            .onGloballyPositioned { center[0] = it.boundsInRoot().center }
            .clip(CircleShape)
            .background(ShellColors.PillFill)
            .glint(glintProgress)
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) { onLearn(center[0]) }
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        AutoSizeText(
            label, color = ShellColors.PillInk, fontSize = ui.t(14.5f), minFontSize = ui.t(9f),
            fontWeight = FontWeight.ExtraBold
        )
    }
}

/** A glyph of the designer's sheet in a [disc] of its own: the size and the place it has there, a shade smaller. */
@Composable
private fun DiscGlyph(glyph: ShellGlyph, tint: Color, disc: Dp) {
    val art = sectionArt(glyph)
    if (art != null) {
        ShellIcon(glyph, tint, Modifier.offset(disc * art.dx, disc * art.dy).size(disc * art.share * PANEL_GLYPH_FIT))
    } else {
        ShellIcon(glyph, tint, Modifier.size(disc * AIN_SHARE))
    }
}

/** The letter ع is not on the sheet: half of its disc, as the sheet's glyphs are about. */
private const val AIN_SHARE = 0.5f

/*
 * The open panel (0.39.0), from the owner's mock; the pixels and where they come from are in [PanelLayout]. No times,
 * no header, no cards: four discs with their labels in a row, and the settings at the end. The discs keep the colours
 * and the drawings of the 0.36.0 panel (the mock's were other hues; the owner kept the originals).
 */
/** Room for the ring that marks the section the user is in: it is drawn outside the disc, inside the cell. */
private val RING_ROOM = 3.dp
/** The sheet's glyphs sit a shade smaller in the discs than in the sheet's: 0.41 against 0.475 and the like. */
private const val PANEL_GLYPH_FIT = 0.9f

@Composable
private fun PanelContent(
    current: HomeSection?,
    enabled: Boolean,
    progress: () -> Float,
    onOpenSection: (HomeSection, Offset) -> Unit
) {
    Box(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxSize()
                .padding(start = PanelLayout.GRID_START.dp, end = PanelLayout.gridEnd.dp)
        ) {
            val count = HomeSection.GRID.size
            HomeSection.GRID.forEachIndexed { index, section ->
                SectionCell(
                    section, current = section == current, enabled = enabled, onOpen = onOpenSection,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .cellIn(progress, ShellMath.cellRank(index, count))
                )
            }
        }
        SettingsGear(
            enabled = enabled,
            onOpen = { origin -> onOpenSection(HomeSection.SETTINGS, origin) },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(
                    top = (PanelLayout.GEAR_CENTER_Y - PanelLayout.GEAR_HIT / 2f).dp,
                    end = (PanelLayout.GEAR_FROM_END - PanelLayout.GEAR_HIT / 2f).dp
                )
                .cellIn(progress, PanelLayout.GEAR_RANK)
        )
    }
}

/**
 * A cell of the panel appears from the middle outwards: it grows from [ShellMath.CELL_FROM_SCALE] of its size and comes
 * up a few dp while it fades in. Read while drawing only.
 */
private fun Modifier.cellIn(progress: () -> Float, rank: Int): Modifier = graphicsLayer {
    val t = ShellMath.cellProgress(progress(), rank)
    val s = ShellMath.lerp(ShellMath.CELL_FROM_SCALE, 1f, t)
    alpha = t
    scaleX = s
    scaleY = s
    translationY = (1f - t) * 6.dp.toPx()
    compositingStrategy = CompositingStrategy.ModulateAlpha
}

/**
 * Settings: the end of the panel, reachable from home and from every section alike. A bare line icon of our own (see
 * [ShellGlyph.GEAR]) in a 44 dp touch box, no disc.
 */
@Composable
private fun SettingsGear(enabled: Boolean, onOpen: (Offset) -> Unit, modifier: Modifier = Modifier) {
    val center = remember { arrayOf(Offset.Unspecified) }
    val label = tr("Настройки")
    Box(
        modifier
            .size(PanelLayout.GEAR_HIT.dp)
            .onGloballyPositioned { center[0] = it.boundsInRoot().center }
            .clip(CircleShape)
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) { onOpen(center[0]) }
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) { ShellIcon(ShellGlyph.GEAR, ShellColors.GearInk, Modifier.size(PanelLayout.GEAR_ICON.dp)) }
}

@Composable
private fun SectionCell(
    section: HomeSection,
    current: Boolean,
    enabled: Boolean,
    onOpen: (HomeSection, Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val well = PanelLayout.DISC.dp
    val center = remember { arrayOf(Offset.Unspecified) }
    val label = section.label()
    val art = sectionArt(section.glyph)
    val tone = ShellTones.of(section)
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) { onOpen(section, center[0]) }
            .semantics { contentDescription = label },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // The disc's top is DISC_TOP under the slab's top: the ring's room is part of what is above it.
        Spacer(Modifier.height((PanelLayout.DISC_TOP).dp - RING_ROOM))
        Box(
            Modifier
                .padding(top = RING_ROOM)
                .size(well)
                .onGloballyPositioned { center[0] = it.boundsInRoot().center }
                .drawBehind {
                    // Where the user is: a thin ring of the disc's own hue, just outside it.
                    if (current) {
                        drawCircle(
                            tone.well,
                            radius = size.minDimension / 2f + 2.25.dp.toPx(),
                            style = Stroke(width = 1.5.dp.toPx()),
                            alpha = 0.55f
                        )
                    }
                }
                .clip(CircleShape)
                .background(tone.well),
            contentAlignment = Alignment.Center
        ) {
            // The glyph keeps the place it has in its circle on the designer's sheet, a shade smaller (see
            // PANEL_GLYPH_FIT), white on the saturated disc.
            if (art != null) {
                ShellIcon(
                    section.glyph, Color.White,
                    Modifier.offset(well * art.dx, well * art.dy).size(well * art.share * PANEL_GLYPH_FIT)
                )
            } else {
                ShellIcon(section.glyph, Color.White, Modifier.size(well * AIN_SHARE))
            }
        }
        // The baseline is LABEL_UNDER_DISC under the disc; the label is a size up from the mock's and bold (see PanelLayout).
        Text(
            label, color = ShellColors.PanelInk, fontSize = ui.t(PanelLayout.LABEL_SP), fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.paddingFromBaseline(top = PanelLayout.LABEL_UNDER_DISC.dp)
        )
    }
}

/** The timer is information, not another deed card. Stable dark jade keeps the figures legible
 * over bright and dark walls, without a stroke. Its small painted body and larger tap target are independent. */
internal object TimerInk {
    val Surface = Color(0xF023322D)
    val Icon = Color(0xFFAFF1CE)
    val Label = Color(0xFFE0ECE6)
    val Time = Color(0xFFFAFFFC)
}

@Composable
private fun TopIsland(data: PrayerData, now: State<ZonedDateTime>, onTap: (Offset) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val pill = RoundedCornerShape(50)
    val center = remember { arrayOf(Offset.Unspecified) }
    val next = HomeTimeline.next(data.window, data.fajrEqualsDawn)
    val touches = remember { MutableInteractionSource() }
    val homeLabel = tr("На главную")
    Box(modifier.height(48.dp)
        .onGloballyPositioned { center[0] = it.boundsInRoot().center }
        .clickable(interactionSource = touches, indication = null, role = Role.Button, onClickLabel = homeLabel) { onTap(center[0]) },
        contentAlignment = Alignment.Center) {
        Row(Modifier.height(28.dp).clip(pill).background(TimerInk.Surface).indication(touches, ripple())
            .padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            DeedGlyphIcon(DeedGlyph.MOSQUE, TimerInk.Icon, Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(PrayerLabels.title(next), color = TimerInk.Label, fontSize = ui.t(11f), lineHeight = ui.t(14f),
                fontWeight = FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.width(5.dp))
            IslandCountdown(data, now)
        }
    }
}

/** The only part of the island that changes every second. */
@Composable
private fun IslandCountdown(data: PrayerData, now: State<ZonedDateTime>) {
    val ui = uiScale()
    Text(
        Format.countdown(data.window.remaining(now.value)),
        color = TimerInk.Time, fontSize = ui.t(12f), lineHeight = ui.t(15f), fontWeight = FontWeight.Bold, maxLines = 1,
        style = TextStyle(fontFeatureSettings = "tnum")
    )
}
