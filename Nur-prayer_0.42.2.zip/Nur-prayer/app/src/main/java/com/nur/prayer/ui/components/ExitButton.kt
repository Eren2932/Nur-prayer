package com.nur.prayer.ui.components

import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr

/** Physical left and right, independent of the reading direction. One optical axis, including gallery overlays. */
object ExitButtonSpec {
    val Hit = 52.dp
    val Side = 14.dp
    val Diameter = 32.dp
    val ExtraRoom = 64.dp
    val BarClearance = 48.dp
    const val FADE_MILLIS = 140
}

/**
 * What the ring does: the system's back, exactly as the gesture would. Every page already answers it (its own
 * [androidx.activity.compose.BackHandler] first, the navigator last), so one ring serves all of them and an editor
 * inside a page closes itself before the page does. The keyboard goes first, or it would hang over the page below.
 */
@Composable
fun rememberSystemBack(): () -> Unit {
    val dispatcher = LocalOnBackPressedDispatcherOwner.current?.onBackPressedDispatcher
    val keyboard = LocalSoftwareKeyboardController.current
    return remember(dispatcher, keyboard) {
        val action: () -> Unit = {
            keyboard?.hide()
            dispatcher?.onBackPressed()
        }
        action
    }
}

@Composable
fun ExitDock(onClose: () -> Unit, bottom: Dp, modifier: Modifier = Modifier,
             description: String = tr("Назад"), tint: Color = Color.White) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(modifier.fillMaxWidth().padding(horizontal = ExitButtonSpec.Side)
            .padding(bottom = (bottom - 8.dp).coerceAtLeast(10.dp)), horizontalArrangement = Arrangement.SpaceBetween) {
            // Reserved for a future menu: no action, no focus target, no false promise to TalkBack.
            Box(Modifier.size(ExitButtonSpec.Hit).pointerInput(Unit) { detectTapGestures { } }, contentAlignment = Alignment.Center) { DockMark(tint, more = true) }
            ExitButton(onClose, description = description, tint = tint)
        }
    }
}

@Composable
private fun ExitButton(onClick: () -> Unit, description: String, tint: Color) {
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.9f else 1f, tween(90), label = "exitPress")
    Box(
        modifier = Modifier
            .size(ExitButtonSpec.Hit)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .semantics { contentDescription = description }
            .clickable(interactionSource = interaction, indication = null, role = Role.Button) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        DockMark(tint, more = false)
    }
}

@Composable
private fun DockMark(tint: Color, more: Boolean) {
    Canvas(Modifier.size(ExitButtonSpec.Diameter)) {
        val w = 1.dp.toPx()
        val r = size.minDimension / 2f
        drawCircle(Color.Black.copy(alpha = .12f), r)
        drawCircle(tint.copy(alpha = .50f), r - w / 2f, style = Stroke(w))
        val ink = tint.copy(alpha = .82f)
        if (more) {
            for (i in -1..1) drawCircle(ink, 1.65.dp.toPx(), Offset(center.x + i * 6.3.dp.toPx(), center.y))
        } else {
            val d = 4.7.dp.toPx()
            val line = 1.7.dp.toPx()
            drawLine(ink, center - Offset(d, d), center + Offset(d, d), line, StrokeCap.Round)
            drawLine(ink, center + Offset(-d, d), center + Offset(d, -d), line, StrokeCap.Round)
        }
    }
}
