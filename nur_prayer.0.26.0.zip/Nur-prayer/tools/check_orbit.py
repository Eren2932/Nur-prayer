#!/usr/bin/env python3
"""0.26.0 «Орбита дня»: a line-for-line mirror of OrbitMath.kt, checked in CI without a JVM.

The Kotlin constants are read from the source, so the mirror cannot silently drift from it.
"""
import math, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'app/src/main/java/com/nur/prayer/ui/home/OrbitMath.kt').read_text()

def const(name):
    m = re.search(r'const val ' + name + r'\s*=\s*([0-9.]+)', SRC)
    if not m: sys.exit('check_orbit: constant %s not found in OrbitMath.kt' % name)
    return float(m.group(1))

DAY_STEP = const('DAY_STEP_DEG'); RUBBER = const('WHEEL_RUBBER_DEG'); SLACK = const('SECTOR_SLACK_DEG')
HOLD = const('HOLD_MILLIS'); TICK = const('TICK_DEG')

def norm(d): r = math.fmod(d, 360.0); return r + 360.0 if r < 0 else r
def turn(a, b): d = norm(b - a); return d - 360.0 if d > 180 else d
def sweep(a, b): return norm(b - a)
def angle_of(h, m): return norm(90 + (h * 60 + m) / 1440 * 360)
def pointer(dx, dy): return norm(math.degrees(math.atan2(dy, dx)))
def center(i, n): return norm(270 + i * 360 / n)
def sector(dx, dy, hub, n, cur=-1):
    if n <= 0 or math.hypot(dx, dy) < hub: return -1
    a = pointer(dx, dy); w = 360 / n
    if 0 <= cur < n and abs(turn(center(cur, n), a)) <= w / 2 + SLACK: return cur
    return int(math.floor(norm(a - 270 + w / 2) / w)) % n
def rubber(o, lim): return lim * o / (lim + abs(o))
def wheel(t, s, lo_d, hi_d):
    lo = (lo_d - s) * DAY_STEP - DAY_STEP / 2; hi = (hi_d - s) * DAY_STEP + DAY_STEP / 2
    if t > hi: return hi + rubber(t - hi, RUBBER)
    if t < lo: return lo + rubber(t - lo, RUBBER)
    return t
def day_at(w, s, lo, hi):
    r = w / DAY_STEP
    k = math.floor(r + 0.5)  # Kotlin roundToInt: half up
    return min(max(s + k, lo), hi)

errors = []
def need(ok, msg):
    if not ok: errors.append(msg)

need(angle_of(0, 0) == 90 and angle_of(12, 0) == 270 and angle_of(6, 0) == 180, 'midnight bottom, noon top')
need(abs(turn(350, 10) - 20) < 1e-9 and abs(turn(10, 350) + 20) < 1e-9, 'turn across zero')
n = 7
need(sector(0, -100, 10, n) == 0 and sector(0, 0, 10, n) == -1, 'first sector at the top, hub is no sector')
for i in range(n):
    a = math.radians(center(i, n))
    need(sector(100 * math.cos(a), 100 * math.sin(a), 10, n) == i, 'sector %d at its centre' % i)
b = math.radians(center(0, n) + 360 / n / 2 + 1)
need(sector(100 * math.cos(b), 100 * math.sin(b), 10, n) == 1, 'border goes to the neighbour')
need(sector(100 * math.cos(b), 100 * math.sin(b), 10, n, 0) == 0, 'lit sector holds on at its border')
need(day_at(70, 0, -7, 30) == 1 and day_at(50, 0, -7, 30) == 0, 'nearest day')
far = wheel(-1e4, 0, -7, 30)
need(far > -7 * DAY_STEP - DAY_STEP / 2 - RUBBER and day_at(far, 0, -7, 30) == -7, 'rubber stops at the first day')
need(DAY_STEP % TICK == 0, 'the wheel rests on an hour tick')
need(150 <= HOLD <= 450, 'hold to open stays between a tap and a wait')

if errors:
    print('check_orbit: FAIL'); [print(' -', e) for e in errors]; sys.exit(1)
print('check_orbit: PASS (%d sectors, %g° per day, hold %d ms)' % (n, DAY_STEP, HOLD))
