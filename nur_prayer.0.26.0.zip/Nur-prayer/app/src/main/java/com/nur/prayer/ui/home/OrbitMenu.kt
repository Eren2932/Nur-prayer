package com.nur.prayer.ui.home

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/*
 * 0.26.0: the sections of the ring — a marking menu.
 *
 *  - hold the centre                → the ring blooms into sections under the finger; slide onto one
 *                                      and let go: one movement, no extra screen;
 *  - press and flick out at once    → the same, without waiting: the direction is enough;
 *  - tap the centre                 → the sections open and stay, for a tap (and for TalkBack);
 *  - let go back over the centre    → they stay open too: the user is looking, not choosing;
 *  - tap outside, Back, tap centre  → closed.
 *
 * The finger is owned by whoever saw it go down: the dial during a hold, this layer once the menu
 * stays open. Both hit-test with the same OrbitMath.sectorAt and the same radii, so what lights up
 * under the finger is always what opens.
 */

object OrbitMotion {
    /** The chosen section flashes this long before its page starts to come. */
    const val CHOOSE_DELAY_MILLIS = 70L
    const val CLOSE_MILLIS = 170
    const val INTRO_MILLIS = 560
    const val DAY_FADE_MILLIS = 220
}

@Stable
internal class OrbitMenuState {
    var open by mutableStateOf(false)
        private set

    /** Open without a finger on it: waits for a tap. */
    var sticky by mutableStateOf(false)
        private set

    var highlighted by mutableIntStateOf(-1)
        private set

    /** The section on its way to open; it stays lit while the rest fold away. */
    var chosen by mutableIntStateOf(-1)
        private set

    val bloom = Animatable(0f)

    // Geometry, rewritten by the dial on every layout. Plain fields: read by gestures and draws only.
    var dialCenterInRoot: Offset = Offset.Unspecified
    var homeTopLeftInRoot: Offset = Offset.Zero
    var hubPx = 0f
    var outerPx = 0f

    val count: Int get() = HomeSection.entries.size

    /** Centre of the dial in the coordinates of the home screen (and of this layer, which fills it). */
    val localCenter: Offset
        get() = if (dialCenterInRoot.isSpecified) dialCenterInRoot - homeTopLeftInRoot else Offset.Unspecified

    /** Where the page of section [i] grows from: the middle of its sector, in root coordinates. */
    fun originInRoot(i: Int): Offset {
        if (!dialCenterInRoot.isSpecified) return Offset.Unspecified
        val a = Math.toRadians(OrbitMath.sectorCenter(i, count).toDouble())
        val r = (hubPx + outerPx) / 2f
        return dialCenterInRoot + Offset((r * cos(a)).toFloat(), (r * sin(a)).toFloat())
    }

    fun show(sticky: Boolean) {
        this.sticky = sticky
        highlighted = -1
        chosen = -1
        open = true
    }

    fun stick() {
        sticky = true
    }

    fun hide() {
        open = false
        highlighted = -1
    }

    /** Lights section [i] (-1: none) with a light tick of the motor on every change. */
    fun point(i: Int, haptic: HapticFeedback) {
        if (i == highlighted || chosen >= 0) return
        highlighted = i
        if (i >= 0) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    /** False when a section is already on its way: a second tap must not open a second page. */
    fun markChosen(i: Int): Boolean {
        if (chosen >= 0 || i !in 0 until count) return false
        chosen = i
        highlighted = i
        return true
    }

    fun clearChosen() {
        chosen = -1
    }
}

private val SectorFill = Color(0xF21B1838)
private val SectorEdge = Color(0x1FFFFFFF)
private val HubFill = Color(0xFA120F26)

/**
 * The open sections, over a dimmed home. Composed only while the menu is open or folding away; the
 * bloom is read in draw and layer lambdas, so the animation itself never recomposes.
 */
@Composable
internal fun OrbitMenuLayer(
    menu: OrbitMenuState,
    palette: PhasePalette,
    haptic: HapticFeedback,
    onChoose: (Int) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val sections = HomeSection.entries
    val n = sections.size
    val accent = palette.accent
    val choose by rememberUpdatedState(onChoose)
    val dismiss by rememberUpdatedState(onDismiss)
    Box(
        modifier
            .fillMaxSize()
            .pointerInput(menu) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    val c = menu.localCenter
                    if (!c.isSpecified) {
                        dismiss()
                        return@awaitEachGesture
                    }
                    val d0 = down.position - c
                    val r0 = d0.getDistance()
                    val reach = menu.outerPx + 28.dp.toPx()
                    val onSections = r0 >= menu.hubPx && r0 <= reach
                    if (onSections) menu.point(OrbitMath.sectorAt(d0.x, d0.y, menu.hubPx, n, menu.highlighted), haptic)
                    var up = false
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) {
                            change.consume()
                            up = true
                            break
                        }
                        change.consume()
                        if (onSections) {
                            val d = change.position - c
                            menu.point(OrbitMath.sectorAt(d.x, d.y, menu.hubPx, n, menu.highlighted), haptic)
                        }
                    }
                    if (!up) {
                        menu.point(-1, haptic)
                    } else if (!onSections) {
                        // The centre or the sky around: close, as every sheet in the app does.
                        dismiss()
                    } else if (menu.highlighted >= 0) {
                        choose(menu.highlighted)
                    }
                    // Slid back onto the centre: nothing chosen, the sections stay for another try.
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val b = menu.bloom.value
            val shown = b.coerceIn(0f, 1f)
            drawRect(Color.Black, alpha = 0.55f * shown)
            val c = menu.localCenter
            if (!c.isSpecified || menu.outerPx <= 0f) return@Canvas
            val inner = menu.hubPx + 3.dp.toPx()
            val outerMax = menu.outerPx
            val width = 360f / n
            // The same physical gap at the inner edge for any number of sections.
            val gapDeg = Math.toDegrees((5.dp.toPx() / inner).toDouble()).toFloat()
            val chosen = menu.chosen
            for (i in 0 until n) {
                val t = if (i == chosen) 1f else OrbitMath.stagger(b, i, n)
                if (t <= 0f) continue
                val outer = inner + (outerMax - inner) * t
                val sweepDeg = width - gapDeg
                val start = OrbitMath.sectorCenter(i, n) - sweepDeg / 2f - 10f * (1f - t.coerceAtMost(1f))
                val path = Path().apply {
                    arcTo(Rect(c, outer), start, sweepDeg, true)
                    arcTo(Rect(c, inner), start + sweepDeg, -sweepDeg, false)
                    close()
                }
                val lit = i == menu.highlighted
                val alpha = t.coerceIn(0f, 1f)
                drawPath(path, if (lit) accent else SectorFill, alpha = alpha)
                if (!lit) drawPath(path, SectorEdge, alpha = alpha, style = Stroke(width = 1.dp.toPx()))
            }
            drawCircle(HubFill, radius = menu.hubPx * (0.86f + 0.14f * shown), center = c, alpha = shown)
            drawCircle(Color.White, radius = menu.hubPx * (0.86f + 0.14f * shown), center = c, alpha = 0.08f * shown,
                style = Stroke(width = 1.dp.toPx()))
        }

        // The centre names what the finger is on; with nothing lit it says what to do.
        Layout(
            content = {
                Column(
                    Modifier.graphicsLayer { alpha = menu.bloom.value.coerceIn(0f, 1f) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val lit = menu.highlighted
                    if (lit >= 0) {
                        SectionGlyph(sections[lit], TextPrimary, accent, Modifier.size(30.dp))
                        Text(
                            sections[lit].label(), color = TextPrimary, fontSize = ui.t(15f),
                            fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1
                        )
                    } else {
                        Text(
                            tr("Разделы"), color = TextPrimary, fontSize = ui.t(15f),
                            fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1
                        )
                        Text(
                            tr("выберите или нажмите мимо"), color = TextSecondary, fontSize = ui.t(11f),
                            textAlign = TextAlign.Center, maxLines = 2
                        )
                    }
                }
                sections.forEachIndexed { i, section ->
                    val lit = i == menu.highlighted
                    Column(
                        Modifier
                            .widthIn(max = 92.dp)
                            .graphicsLayer {
                                val t = if (i == menu.chosen) 1f else OrbitMath.stagger(menu.bloom.value, i, n)
                                alpha = t.coerceIn(0f, 1f)
                                val k = 0.6f + 0.4f * t
                                scaleX = k
                                scaleY = k
                            }
                            .clearAndSetSemantics {
                                contentDescription = section.label()
                                role = Role.Button
                                selected = lit
                                onClick(label = section.label()) { onChoose(i); true }
                            },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        SectionGlyph(section, if (lit) Ink else TextPrimary, if (lit) Ink else accent, Modifier.size(26.dp))
                        Text(
                            section.label(), color = if (lit) Ink else TextPrimary, fontSize = ui.t(11.5f),
                            fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 1
                        )
                    }
                }
            }
        ) { measurables, constraints ->
            val loose = Constraints(maxWidth = constraints.maxWidth, maxHeight = constraints.maxHeight)
            val hubSide = (menu.hubPx * 1.5f).roundToInt().coerceAtLeast(1)
            val placeables = measurables.mapIndexed { k, m ->
                if (k == 0) m.measure(Constraints(maxWidth = hubSide, maxHeight = hubSide)) else m.measure(loose)
            }
            layout(constraints.maxWidth, constraints.maxHeight) {
                val c = menu.localCenter
                if (!c.isSpecified) return@layout
                val mid = (menu.hubPx + 3.dp.toPx() + menu.outerPx) / 2f
                placeables.forEachIndexed { k, p ->
                    val at = if (k == 0) c else {
                        val a = Math.toRadians(OrbitMath.sectorCenter(k - 1, n).toDouble())
                        c + Offset((mid * cos(a)).toFloat(), (mid * sin(a)).toFloat())
                    }
                    p.place((at.x - p.width / 2f).roundToInt(), (at.y - p.height / 2f).roundToInt())
                }
            }
        }
    }
}
