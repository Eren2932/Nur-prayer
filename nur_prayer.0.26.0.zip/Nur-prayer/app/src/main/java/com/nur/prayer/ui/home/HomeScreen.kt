package com.nur.prayer.ui.home

import com.nur.prayer.i18n.tr

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.PillButton
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/*
 * 0.26.0 home: «Орбита дня». No curtain to pull, no list, no capsule.
 *
 *  - the ring of the day (OrbitDial): the prayers at their real times, the one going on now as an
 *    arc filling towards the next, the sun or the moon at this minute;
 *  - turn the ring → other days; tap the centre → back to today;
 *  - tap a prayer → its sheet; hold the centre (or flick out of it) → the sections (OrbitMenu):
 *    hold, slide, let go. Tapping the centre opens them for a tap as well.
 *
 * Back closes the sheet, then the sections, then the other day; from today it leaves the app.
 */

/** Text drawn straight on the sky gets a soft shadow so it survives the light horizon of noon. */
private val OnSky = Shadow(Color(0x73000000), blurRadius = 10f)
private val SheetScrim = Color(0x8C000000)
private val TodayPill = Color(0x33FFFFFF)

@Composable
fun HomeScreen(
    data: PrayerData,
    now: State<ZonedDateTime>,
    palette: PhasePalette,
    actions: AppActions,
    notificationsAllowed: Boolean,
    exactAlarmsAllowed: Boolean,
    onOpenCity: () -> Unit,
    /** The day chip under the header: the month calendar, opened plainly. */
    onOpenSchedule: () -> Unit,
    /** A section chosen on the orbit, and the middle of its sector in root coordinates: the page grows from it. */
    onOpenSection: (HomeSection, Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val context = LocalContext.current.applicationContext
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    // The open sheet survives rotation and process death; stored by name, validated on read.
    var sheetName by rememberSaveable { mutableStateOf<String?>(null) }
    val sheetPrayer = sheetName?.let { name -> Prayer.entries.firstOrNull { it.name == name } }

    // Not saveable on purpose: open sections or another day must not greet the user after a return.
    val menu = remember { OrbitMenuState() }
    val wheel = remember { OrbitWheelState() }
    var hint by remember { mutableStateOf(OrbitHint.visible(context)) }

    BackHandler(enabled = sheetPrayer != null) { sheetName = null }
    BackHandler(enabled = sheetPrayer == null && menu.open) { menu.hide() }
    BackHandler(enabled = sheetPrayer == null && !menu.open && wheel.day != 0) { scope.launch { wheel.goTo(0) } }

    // The sections bloom with a little spring and fold fast; the chosen one stays lit while they fold.
    LaunchedEffect(menu.open) {
        if (menu.open) {
            menu.bloom.animateTo(1f, spring(dampingRatio = 0.74f, stiffness = 520f))
        } else {
            menu.bloom.animateTo(0f, tween(OrbitMotion.CLOSE_MILLIS))
            menu.clearChosen()
        }
    }
    val menuOnScreen by remember { derivedStateOf { menu.open || menu.bloom.value > 0f } }

    val choose: (Int) -> Unit = { i ->
        if (menu.markChosen(i)) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            if (hint) {
                OrbitHint.used(context)
                hint = OrbitHint.visible(context)
            }
            scope.launch {
                // A short flash of the chosen sector, then its page starts growing out of it.
                delay(OrbitMotion.CHOOSE_DELAY_MILLIS)
                onOpenSection(HomeSection.entries[i], menu.originInRoot(i))
                menu.hide()
            }
        }
    }

    // The prayer sheet is a layer driven by a Reveal: a finger and an animation move the same number,
    // and only draw lambdas read it (see Reveal). Nothing here recomposes per frame.
    val sheet = remember { Reveal(initiallyOpen = sheetPrayer != null) }
    LaunchedEffect(sheetPrayer != null) {
        if (sheetPrayer != null) {
            // Let the heavy first composition of the sheet land before the clock of the slide starts;
            // otherwise its first frames are spent composing and the slide visibly skips ahead.
            withFrameNanos { }
            withFrameNanos { }
            sheet.settle(true)
        } else {
            sheet.settle(false)
        }
    }
    val sheetOnScreen by remember(sheetPrayer != null) {
        derivedStateOf { sheetPrayer != null || sheet.progress > 0f }
    }

    Box(
        modifier
            .fillMaxSize()
            .onGloballyPositioned { menu.homeTopLeftInRoot = it.positionInRoot() }
    ) {
        Column(Modifier.fillMaxSize()) {
            HomeHeader(data, onOpenCity)
            // 0.19.0: a feast, a night or a fast of the Islamic year, in its colour (see HomeDayChip).
            HomeDayChip(
                data.today.date, data.settings.hijriOffset, onOpen = onOpenSchedule,
                modifier = Modifier.padding(start = ui.s(20f), end = ui.s(20f), top = 10.dp)
            )

            OrbitDial(
                data = data, now = now, palette = palette, menu = menu, wheel = wheel, haptic = haptic,
                onOpenPrayer = { if (!menu.open) sheetName = it.name },
                onOpenMenu = { sticky -> if (sheetPrayer == null) menu.show(sticky) },
                onChoose = choose,
                modifier = Modifier.weight(1f).padding(horizontal = ui.s(8f))
            )

            // One fixed slot under the ring, so the ring never moves when its content changes.
            Box(
                Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = ui.s(20f))
                    .padding(top = 6.dp, bottom = ui.s(18f))
                    .height(52.dp)
                    .graphicsLayer { alpha = 1f - menu.bloom.value.coerceIn(0f, 1f) },
                contentAlignment = Alignment.Center
            ) {
                Crossfade(
                    targetState = when {
                        wheel.day != 0 -> BottomLine.TODAY
                        hint -> BottomLine.HINT
                        else -> BottomLine.NONE
                    },
                    animationSpec = tween(180),
                    label = "orbitBottom"
                ) { line ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        when (line) {
                            BottomLine.TODAY -> PillButton(
                                tr("Вернуться к сегодня"), { scope.launch { wheel.goTo(0) } },
                                background = TodayPill, contentColor = TextPrimary
                            )
                            BottomLine.HINT -> Text(
                                tr("Зажмите центр — разделы · крутите кольцо — дни"),
                                color = TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center, maxLines = 2, style = TextStyle(shadow = OnSky)
                            )
                            BottomLine.NONE -> Spacer(Modifier.height(1.dp))
                        }
                    }
                }
            }
        }

        if (menuOnScreen) {
            OrbitMenuLayer(menu, palette, haptic, onChoose = choose, onDismiss = { menu.hide() })
        }

        // The sheet keeps rendering the last prayer while it slides away.
        // A plain holder, not state: it only has to remember, never to trigger a recomposition.
        val lastSheet = remember { arrayOfNulls<Prayer>(1) }
        if (sheetPrayer != null) lastSheet[0] = sheetPrayer
        if (sheetOnScreen) {
            Box(Modifier.fillMaxSize().onSizeChanged { sheet.extentPx = it.height.toFloat() }) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .drawBehind { drawRect(SheetScrim, alpha = sheet.progress) }
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClickLabel = tr("Закрыть"),
                            onClick = { sheetName = null }
                        )
                )
                Box(Modifier.fillMaxSize().graphicsLayer { translationY = (1f - sheet.progress) * size.height }) {
                    PrayerSheet(
                        data = data,
                        initial = lastSheet[0] ?: Prayer.FAJR,
                        now = now,
                        actions = actions,
                        notificationsAllowed = notificationsAllowed,
                        exactAlarmsAllowed = exactAlarmsAllowed,
                        onDismiss = { sheetName = null },
                        onOpenSettings = { sheetName = null; onOpenSection(HomeSection.SETTINGS, Offset.Unspecified) },
                        motion = sheet
                    )
                }
            }
        }
    }
}

private enum class BottomLine { TODAY, HINT, NONE }

/**
 * The line «Зажмите центр — разделы» teaches the gesture and then goes away: after the sections
 * have been used [LEARNED] times it is not shown again. Kept beside the other home UI flags, outside
 * the settings DataStore: it is a hint, not a setting.
 */
internal object OrbitHint {
    private const val FILE = "nur_ui"
    private const val KEY = "orbit_menu_uses"
    const val LEARNED = 3

    private fun prefs(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun visible(context: Context): Boolean = prefs(context).getInt(KEY, 0) < LEARNED

    fun used(context: Context) {
        val p = prefs(context)
        p.edit().putInt(KEY, p.getInt(KEY, 0) + 1).apply()
    }
}

@Composable
private fun HomeHeader(data: PrayerData, onOpenCity: () -> Unit) {
    val ui = uiScale()
    val sky = TextStyle(shadow = OnSky)
    Row(
        Modifier.fillMaxWidth().padding(start = ui.s(20f), end = ui.s(12f), top = 8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Column(Modifier.weight(1f).padding(top = 6.dp)) {
            Text(
                Format.weekday(data.today.date).replaceFirstChar { it.uppercase() },
                color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Bold, style = sky
            )
            // 0.19.0: on a feast or a fast the hijri date takes the colour of the day.
            val dayTone = remember(data.today.date, data.settings.hijriOffset) {
                com.nur.prayer.data.IslamicDays.primary(data.today.date, data.settings.hijriOffset)
                    ?.takeIf { it.kind == com.nur.prayer.data.DayKind.FEAST || it.kind == com.nur.prayer.data.DayKind.FAST }
                    ?.let { com.nur.prayer.ui.schedule.DayTone.of(it.kind) }
            }
            Text(
                HijriCalendar.format(data.today.date, data.settings.hijriOffset),
                color = dayTone ?: TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.Medium, style = sky,
                maxLines = 1
            )
        }
        Column(
            Modifier
                .weight(1f)
                .clip(RoundedCornerShape(14.dp))
                .clickable(role = Role.Button, onClickLabel = tr("Выбрать город"), onClick = onOpenCity)
                .heightIn(min = 48.dp)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.End
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (data.settings.useDeviceLocation) {
                    Glyph(GlyphKind.LOCATION, TextPrimary, Modifier.size(13.dp))
                    Spacer(Modifier.width(6.dp))
                }
                AutoSizeText(
                    data.place.label, color = TextPrimary, fontSize = ui.t(17f), minFontSize = ui.t(13f),
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.End
                )
            }
            Text(
                Format.dayMonth(data.today.date), color = TextSecondary, fontSize = ui.t(13f),
                fontWeight = FontWeight.Medium, style = sky
            )
        }
    }
}
