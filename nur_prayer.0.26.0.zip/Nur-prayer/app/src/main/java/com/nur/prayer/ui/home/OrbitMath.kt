package com.nur.prayer.ui.home

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.roundToInt

/*
 * 0.26.0 «Орбита дня»: the numbers behind the home dial. Pure, so every edge is unit-tested
 * (OrbitMathTest) and mirrored line for line in tools/check_orbit.py, which runs in CI without a JVM.
 *
 * Angles are screen degrees: 0° points right and angles grow clockwise, because y points down.
 * The dial is a 24-hour clock with midnight at the bottom (90°) and noon at the top (270°): the
 * morning climbs the left side, the evening runs down the right, exactly as the sun moves.
 */
object OrbitMath {
    const val MINUTES_PER_DAY = 1440f

    /** Hold the centre this long and the sections open under the finger. */
    const val HOLD_MILLIS = 300L

    /** One day of the wheel: a third of a turn. Short enough to scroll a week in two swipes. */
    const val DAY_STEP_DEG = 120f

    /** The decorative ticks repeat every hour, so the wheel always comes to rest on a tick. */
    const val TICK_DEG = 15f

    /** How far the wheel may be pulled past the first or the last available day. */
    const val WHEEL_RUBBER_DEG = 24f

    /** Sticky switching: a highlighted section keeps the finger this far past its border. */
    const val SECTOR_SLACK_DEG = 6f

    /** Angle of [minutes] after local midnight. */
    fun angleOfMinutes(minutes: Float): Float = normalize(90f + minutes / MINUTES_PER_DAY * 360f)

    fun angleOf(hour: Int, minute: Int, second: Int = 0): Float =
        angleOfMinutes(hour * 60f + minute + second / 60f)

    fun normalize(deg: Float): Float {
        val r = deg % 360f
        return if (r < 0f) r + 360f else r
    }

    /** Shortest signed turn from [from] to [to], in (-180, 180]. Positive is clockwise. */
    fun turn(from: Float, to: Float): Float {
        val d = normalize(to - from)
        return if (d > 180f) d - 360f else d
    }

    /** Clockwise sweep from [from] to [to], in [0, 360). Arcs on the dial are drawn with it. */
    fun sweep(from: Float, to: Float): Float = normalize(to - from)

    /** Screen angle of a point relative to the centre. */
    fun pointerAngle(dx: Float, dy: Float): Float =
        normalize(Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat())

    /**
     * Length along the tangent that an axis-aligned label of [w]×[h] occupies at [angle]: its
     * projection on the direction (-sin, cos). Width at the top and bottom, height at the sides.
     */
    fun tangentExtent(angle: Float, w: Float, h: Float): Float {
        val a = Math.toRadians(angle.toDouble())
        return (w * abs(kotlin.math.sin(a)) + h * abs(kotlin.math.cos(a))).toFloat()
    }

    /**
     * Where a label sits relative to its anchor point, as fractions of its own size: 0 = the label
     * starts at the point, 1 = it ends there. A label on the right reads away from the ring, one on
     * the left ends at it, one at the top stands on it, one at the bottom hangs from it. The square
     * root pushes diagonal labels further out of the corner, so their inner corner never grazes the ring.
     */
    fun anchorX(angle: Float): Float = anchor(kotlin.math.cos(Math.toRadians(angle.toDouble())).toFloat())

    fun anchorY(angle: Float): Float = anchor(kotlin.math.sin(Math.toRadians(angle.toDouble())).toFloat())

    private fun anchor(c: Float): Float {
        val k = kotlin.math.sqrt(abs(c))
        return (1f - (if (c < 0f) -k else k)) / 2f
    }

    /**
     * Moves labels apart along the ring with the least total movement (in the least-squares sense)
     * so that neighbours [i] and [i+1] keep at least half of both tangent extents plus [padding]
     * between them. Order around the ring never changes.
     *
     * The circle is cut at its widest empty arc and unrolled into a line. On the line the problem
     * "x(i+1) - x(i) >= g(i), minimise Σ (x - a)²" becomes, with y = x - Σg, an isotonic regression
     * of a - Σg, solved exactly by pool-adjacent-violators: a run of crowded labels moves as one
     * block, centred on where its labels want to be.
     */
    fun spread(angles: FloatArray, extents: FloatArray, radius: Float, padding: Float): FloatArray {
        val n = angles.size
        val out = FloatArray(n) { normalize(angles[it]) }
        if (n < 2 || radius <= 0f) return out
        val order = (0 until n).sortedBy { out[it] }
        // Widest empty arc: the line starts right after it.
        var cut = 0
        var widest = -1f
        for (k in 0 until n) {
            val gap = sweep(out[order[k]], out[order[(k + 1) % n]])
            if (gap > widest) { widest = gap; cut = (k + 1) % n }
        }
        val line = FloatArray(n)
        val idx = IntArray(n)
        for (k in 0 until n) {
            idx[k] = order[(cut + k) % n]
            line[k] = if (k == 0) out[idx[0]] else line[k - 1] + sweep(out[idx[k - 1]], out[idx[k]])
        }
        val need = FloatArray(n) // cumulative minimal distance from the first label, degrees
        for (k in 1 until n) {
            val gapPx = (extents[idx[k - 1]] + extents[idx[k]]) / 2f + padding
            need[k] = need[k - 1] + Math.toDegrees((gapPx / radius).toDouble()).toFloat()
        }
        val fitted = isotonic(FloatArray(n) { line[it] - need[it] })
        for (k in 0 until n) out[idx[k]] = normalize(fitted[k] + need[k])
        return out
    }

    /** Non-decreasing least-squares fit (pool adjacent violators, equal weights). */
    fun isotonic(values: FloatArray): FloatArray {
        val n = values.size
        val sums = DoubleArray(n)
        val counts = IntArray(n)
        var blocks = 0
        for (v in values) {
            sums[blocks] = v.toDouble()
            counts[blocks] = 1
            blocks++
            while (blocks > 1 && sums[blocks - 2] / counts[blocks - 2] > sums[blocks - 1] / counts[blocks - 1]) {
                sums[blocks - 2] += sums[blocks - 1]
                counts[blocks - 2] += counts[blocks - 1]
                blocks--
            }
        }
        val out = FloatArray(n)
        var at = 0
        for (b in 0 until blocks) {
            val mean = (sums[b] / counts[b]).toFloat()
            repeat(counts[b]) { out[at++] = mean }
        }
        return out
    }

    /* ---------------------------------------------------------------- sections (marking menu) */

    /** Centre of section [i] of [count]: section 0 points straight up, the rest follow clockwise. */
    fun sectorCenter(i: Int, count: Int): Float = normalize(270f + i * 360f / count)

    /**
     * The section under a finger at ([dx], [dy]) from the centre, or -1 inside the hub. Only the
     * direction counts beyond the hub — a marking menu: a quick flick works as well as a careful aim.
     * [current] keeps its section for [SECTOR_SLACK_DEG] past the border, so a finger resting on the
     * line between two sections never makes the highlight flicker.
     */
    fun sectorAt(dx: Float, dy: Float, hub: Float, count: Int, current: Int = -1): Int {
        if (count <= 0 || hypot(dx, dy) < hub) return -1
        val a = pointerAngle(dx, dy)
        val width = 360f / count
        if (current in 0 until count && abs(turn(sectorCenter(current, count), a)) <= width / 2f + SECTOR_SLACK_DEG) {
            return current
        }
        return (floor(normalize(a - 270f + width / 2f) / width).toInt()) % count
    }

    /* ---------------------------------------------------------------- the day wheel */

    /** Pulling past the ends gets harder and harder and never goes further than [limit]. */
    fun rubber(overshoot: Float, limit: Float): Float = limit * overshoot / (limit + abs(overshoot))

    /**
     * Where the wheel is drawn for [turned] degrees of finger travel when it started on day [start]
     * and may show days [min]..[max]: free inside, rubber-banded past the half-step beyond an end.
     */
    fun wheel(turned: Float, start: Int, min: Int, max: Int): Float {
        val lo = (min - start) * DAY_STEP_DEG - DAY_STEP_DEG / 2f
        val hi = (max - start) * DAY_STEP_DEG + DAY_STEP_DEG / 2f
        return when {
            turned > hi -> hi + rubber(turned - hi, WHEEL_RUBBER_DEG)
            turned < lo -> lo + rubber(turned - lo, WHEEL_RUBBER_DEG)
            else -> turned
        }
    }

    /** Day shown for a wheel at [wheel] degrees: the nearest step, clamped to what exists. */
    fun dayAt(wheel: Float, start: Int, min: Int, max: Int): Int =
        (start + (wheel / DAY_STEP_DEG).roundToInt()).coerceIn(min, max)

    /**
     * Local progress of item [i] of [n] in a staggered bloom driven by one [progress]: the first item
     * starts at once, the last one [step]·(n-1) later, all of them arrive together at 1. Not clamped
     * above 1, so the overshoot of the spring reaches every item.
     */
    fun stagger(progress: Float, i: Int, n: Int, step: Float = 0.035f): Float {
        val span = 1f - (n - 1) * step
        return ((progress - i * step) / span).coerceAtLeast(0f)
    }

    /** Where the ticks come to rest after a release: the nearest hour tick. */
    fun restOf(wheel: Float): Float = (wheel / TICK_DEG).roundToInt() * TICK_DEG
}
