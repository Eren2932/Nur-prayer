package com.nur.prayer

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.semantics.getOrNull
import androidx.compose.ui.test.click
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipe
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Before
import com.nur.prayer.ui.home.HomeTimeline
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assert
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performClick
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.settings.SettingsScreen
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.qibla.Heading
import com.nur.prayer.ui.qibla.HeadingSource
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Run in the existing API 26 / 34 CI matrix. Authored here, not claimed as locally executed. */
@RunWith(AndroidJUnit4::class)
class ObservatoryScreenTest {
    @get:Rule val compose = createComposeRule()
    private val moment = ZonedDateTime.parse("2026-09-07T21:00:00+03:00[Europe/Moscow]")
    private val actions = AppActions({}, {}, {}, {}, {}, {}, {}, {}, {}, { _, _ -> }, { _, _ -> }, {}, {}, {}, {}, {})

    /** Home UI flags (the orbit hint) live in «nur_ui»; every test starts as on a first launch. */
    @Before fun startFresh() {
        InstrumentationRegistry.getInstrumentation().targetContext
            .getSharedPreferences("nur_ui", Context.MODE_PRIVATE).edit().clear().commit()
    }

    /** Nodes whose merged description starts with [prefix]: rows say «Зухр, 12:12…», the plate «Следующий: …». */
    private fun described(prefix: String) = SemanticsMatcher("description starts with $prefix") { node ->
        node.config.getOrNull(SemanticsProperties.ContentDescription)?.any { it.startsWith(prefix) } == true
    }

    private fun showHome(
        data: PrayerData,
        opened: MutableList<String> = mutableListOf()
    ) = compose.setContent {
        NurTheme {
            HomeScreen(
                data = data, now = mutableStateOf(moment), palette = paletteFor(Prayer.ISHA), actions = actions,
                notificationsAllowed = true, exactAlarmsAllowed = true,
                onOpenCity = { opened += "city" }, onOpenSchedule = { opened += "schedule" },
                onOpenSection = { section, _ -> opened += section.name }
            )
        }
    }
    private fun fixture(): PrayerData {
        val city = City.MOSCOW
        val settings = AppSettings()
        val params = settings.paramsFor(city.country)
        val place = Place(city.name, city.subtitle, city.country, city.coordinates, city.zone, false)
        return PrayerData(place, PrayerEngine.days(moment.toLocalDate(), 3, city.coordinates, city.zone, params),
            PrayerEngine.window(moment, city.coordinates, city.zone, params), qiblaBearing(city.coordinates),
            distanceToKaabaKm(city.coordinates), HijriCalendar.format(moment.toLocalDate()), settings,
            settings.profileFor(city.country), params)
    }

    @Test fun orbitShowsEveryPrayerAndTheCountdown() {
        val data = fixture()
        showHome(data)
        HomeTimeline.prayers(data.fajrEqualsDawn).forEach {
            compose.onNode(described("${PrayerLabels.title(it)}, ")).assertExists()
        }
        compose.onNode(described("${PrayerLabels.title(HomeTimeline.next(data.window, data.fajrEqualsDawn))}, ")).assertExists()
        compose.onAllNodes(described("До ")).assertCountEquals(1)
    }

    @Test fun tappingAPrayerOpensItsSheetAndCloseReturnsToTheOrbit() {
        val data = fixture()
        val pages = HomeTimeline.prayers(data.fajrEqualsDawn)
        showHome(data)
        compose.onNode(described("${PrayerLabels.title(Prayer.DHUHR)}, ")).performClick()
        compose.waitUntil(5000) { compose.onAllNodesWithText("Завтра").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Страница ${HomeTimeline.pageOf(Prayer.DHUHR, data.fajrEqualsDawn) + 1} из ${pages.size}")
            .assertIsDisplayed()
        compose.onNodeWithContentDescription("Закрыть").performClick()
        compose.waitUntil(5000) { compose.onAllNodesWithText("Завтра").fetchSemanticsNodes().isEmpty() }
        compose.onNode(described("${PrayerLabels.title(Prayer.DHUHR)}, ")).assertExists()
    }

    @Test fun theCentreOpensTheSectionsAndEachDispatchesItsPage() {
        val opened = mutableListOf<String>()
        showHome(fixture(), opened)
        listOf("Кыбла", "Настройки", "Календарь").forEach { label ->
            compose.onNodeWithContentDescription("Разделы").performClick()
            compose.waitUntil(3000) { compose.onAllNodesWithContentDescription(label).fetchSemanticsNodes().isNotEmpty() }
            compose.onNodeWithContentDescription(label).performClick()
            compose.waitUntil(3000) { compose.onAllNodesWithContentDescription(label).fetchSemanticsNodes().isEmpty() }
        }
        compose.runOnIdle { assertEquals(listOf("QIBLA", "SETTINGS", "SCHEDULE"), opened) }
    }

    @Test fun holdingTheCentreAndLettingGoOnASectorOpensIt() {
        val opened = mutableListOf<String>()
        showHome(fixture(), opened)
        // Hold the centre, slide straight up (the first sector), let go: one motion.
        compose.onNodeWithContentDescription("Разделы").performTouchInput {
            down(center)
            advanceEventTime(600)
            moveBy(Offset(0f, -height * 0.6f))
            moveBy(Offset(0f, -height * 0.6f))
            advanceEventTime(100)
            up()
        }
        compose.waitUntil(3000) { opened.isNotEmpty() }
        compose.runOnIdle { assertEquals(1, opened.size) }
    }

    @Test fun turningTheRingShowsAnotherDayAndTheCentreBringsTodayBack() {
        showHome(fixture())
        compose.onNode(described("${PrayerLabels.title(Prayer.ASR)}, ")).performTouchInput {
            // A long clockwise arc around the ring: tomorrow at least.
            swipe(center, center + Offset(width * 3f, height * 4f), 600)
        }
        compose.waitUntil(3000) { compose.onAllNodesWithContentDescription("Вернуться к сегодня").fetchSemanticsNodes().isNotEmpty() }
        compose.onAllNodesWithContentDescription("Вернуться к сегодня")[0].performClick()
        compose.waitUntil(3000) { compose.onAllNodesWithContentDescription("Разделы").fetchSemanticsNodes().isNotEmpty() }
    }

    @Test fun homeDoesNotDisplayDecorativeCopy() {
        showHome(fixture())
        compose.onNodeWithText("Время для главного").assertDoesNotExist()
        compose.onNodeWithText("СЛЕДУЮЩЕЕ ВРЕМЯ").assertDoesNotExist()
        compose.onNodeWithText("ПУТЬ ВРЕМЕНИ").assertDoesNotExist()
        compose.onNodeWithText("КАЛЕНДАРЬ").assertDoesNotExist()
    }

    @Test fun unavailableSensorCannotShowDirectionFound() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading()) } }
        compose.onNodeWithText("Компас недоступен").assertIsDisplayed()
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Нет достоверного направления"))
        compose.onNodeWithContentDescription("Кааба — направление кыблы").assertIsDisplayed()
    }
    @Test fun magneticInterferenceCannotReportLockEvenAtTargetAzimuth() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 110f, source = HeadingSource.FUSED)) } }
        compose.onNodeWithText("Проверьте калибровку и помехи").assertIsDisplayed()
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Нет достоверного направления"))
    }
    @Test fun alignedCalibratedFlatSensorShowsLock() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 45f, source = HeadingSource.FUSED)) } }
        // 0.23.0: the dial searches first (≥ 1 s), then turns onto the bearing and only then confirms.
        compose.waitUntil(8000) { compose.onAllNodesWithText("Направление на Каабу").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Направление найдено"))
    }
    /** 0.23.0: the hold does not matter — a phone held upright like a camera finds the Kaaba too. */
    @Test fun tiltedSensorStillFindsDirection() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 45f, tiltDegrees = 60f, source = HeadingSource.FUSED)) } }
        compose.waitUntil(8000) { compose.onAllNodesWithText("Направление на Каабу").fetchSemanticsNodes().isNotEmpty() }
        compose.onAllNodesWithText("Положите телефон горизонтально").assertCountEquals(0)
    }
    @Test fun everySettingsEditorOpensAndReturnsToTheIndex() {
        val data = fixture()
        compose.setContent { NurTheme { SettingsScreen(data, paletteFor(Prayer.ISHA), actions, true) } }
        compose.onNodeWithText("Ваш Нур").assertDoesNotExist()
        listOf("method", "madhab", "notify", "azan", "highlat", "rounding", "offsets", "about").forEach { id ->
            compose.onNodeWithTag("settings-index").performScrollToNode(hasTestTag("setting-$id"))
            compose.onNodeWithTag("setting-$id").performClick()
            compose.onNodeWithTag("settings-$id").assertIsDisplayed()
            compose.onNodeWithContentDescription("К настройкам").performClick()
            compose.onNodeWithTag("settings-index").assertIsDisplayed()
        }
    }

}
