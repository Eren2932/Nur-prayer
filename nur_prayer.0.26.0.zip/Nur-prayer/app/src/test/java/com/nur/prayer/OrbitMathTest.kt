package com.nur.prayer

import com.nur.prayer.ui.home.OrbitMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/** The numbers behind «Орбита дня». Mirrored in tools/check_orbit.py, which CI runs without a JVM. */
class OrbitMathTest {
    private val eps = 1e-3f

    @Test fun midnightIsAtTheBottomAndNoonAtTheTop() {
        assertEquals(90f, OrbitMath.angleOf(0, 0), eps)
        assertEquals(180f, OrbitMath.angleOf(6, 0), eps)
        assertEquals(270f, OrbitMath.angleOf(12, 0), eps)
        assertEquals(0f, OrbitMath.angleOf(18, 0), eps)
    }

    @Test fun turnTakesTheShortWayAcrossZero() {
        assertEquals(20f, OrbitMath.turn(350f, 10f), eps)
        assertEquals(-20f, OrbitMath.turn(10f, 350f), eps)
        assertEquals(340f, OrbitMath.sweep(10f, 350f), eps)
    }

    @Test fun sectorsStartAtTheTopAndGoClockwise() {
        val n = 7
        assertEquals(-1, OrbitMath.sectorAt(0f, 0f, 10f, n))
        assertEquals(0, OrbitMath.sectorAt(0f, -100f, 10f, n))
        for (i in 0 until n) {
            val a = Math.toRadians(OrbitMath.sectorCenter(i, n).toDouble())
            assertEquals(i, OrbitMath.sectorAt((100 * kotlin.math.cos(a)).toFloat(), (100 * kotlin.math.sin(a)).toFloat(), 10f, n))
        }
    }

    @Test fun theLitSectorHoldsOnAtItsBorder() {
        val n = 7
        val border = Math.toRadians((OrbitMath.sectorCenter(0, n) + 360f / n / 2f + 1f).toDouble())
        val x = (100 * kotlin.math.cos(border)).toFloat()
        val y = (100 * kotlin.math.sin(border)).toFloat()
        assertEquals(1, OrbitMath.sectorAt(x, y, 10f, n))
        assertEquals(0, OrbitMath.sectorAt(x, y, 10f, n, current = 0))
    }

    @Test fun theWheelIsFreeInsideAndRubberPastTheEnds() {
        assertEquals(240f, OrbitMath.wheel(240f, 0, -7, 30), eps)
        assertEquals(1, OrbitMath.dayAt(70f, 0, -7, 30))
        assertEquals(0, OrbitMath.dayAt(50f, 0, -7, 30))
        val far = OrbitMath.wheel(-10_000f, 0, -7, 30)
        assertTrue(far > -7 * OrbitMath.DAY_STEP_DEG - OrbitMath.DAY_STEP_DEG / 2f - OrbitMath.WHEEL_RUBBER_DEG)
        assertEquals(-7, OrbitMath.dayAt(far, 0, -7, 30))
    }

    @Test fun closeLabelsAreSpreadApartAndOthersStayPut() {
        // Сухур and Фаджр 30 minutes apart (7.5°) with labels needing ~20° each.
        val angles = floatArrayOf(OrbitMath.angleOf(4, 30), OrbitMath.angleOf(5, 0), OrbitMath.angleOf(12, 0))
        val extents = floatArrayOf(40f, 40f, 40f)
        val out = OrbitMath.spread(angles, extents, 120f, 4f)
        val needDeg = Math.toDegrees((44.0 / 120.0)).toFloat()
        assertTrue(abs(OrbitMath.turn(out[0], out[1])) >= needDeg - 0.01f)
        assertEquals(angles[2], out[2], 0.01f)
        // The pair moves symmetrically around where it was.
        assertEquals(OrbitMath.normalize((angles[0] + angles[1]) / 2f), OrbitMath.normalize((out[0] + out[1]) / 2f), 0.05f)
    }
}
