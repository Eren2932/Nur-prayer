package com.nur.prayer.ui.wallpaper

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.settings.CheckMark
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/**
 * 0.22.0: the wallpaper row of «Оформление».
 *
 * What is on now comes first (with the check), then what was on recently, then the rest of the
 * catalog; the last tile opens the whole gallery. Tiles have the proportions of this very screen, so
 * each is an honest miniature of the home backdrop. A tap sets the wallpaper at once: the tile jumps,
 * flies to the front of the row (the row scrolls back to meet it) and the home backdrop changes by a
 * circle growing from that tile.
 *
 * The row bleeds to the card's edges ([bleed] = the card's inner padding), so tiles scroll out under
 * the card's rounded border instead of being cut at the padding.
 */
@Composable
internal fun WallpaperRow(
    current: Wallpaper,
    recent: List<String>,
    palette: PhasePalette,
    accent: Color,
    bleed: Dp,
    onPick: (Wallpaper) -> Unit,
    onOpenAll: () -> Unit
) {
    val ui = uiScale()
    val config = LocalConfiguration.current
    val aspect = WallpaperScreen.aspect(config.screenWidthDp, config.screenHeightDp)
    val items = remember(current.id, recent) {
        WallpaperOrder.row(current.id, recent, WallpaperCatalog.all.map { it.id }).mapNotNull { WallpaperCatalog.find(it) }
    }
    val rest = WallpaperCatalog.all.size - items.size
    val list = rememberLazyListState()
    LaunchedEffect(current.id) { if (list.firstVisibleItemIndex > 0 || list.firstVisibleItemScrollOffset > 0) list.animateScrollToItem(0) }
    // 0.23.0: a tile pops in once; scrolling it out and back does not replay it.
    val popMemory = rememberPopMemory()

    CompositionLocalProvider(LocalPopMemory provides popMemory) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(bottom = ui.s(10f)), verticalAlignment = Alignment.CenterVertically) {
            Text(
                tr("Обои").uppercase(),
                color = TextTertiary, fontSize = ui.t(11f), fontWeight = FontWeight.SemiBold,
                letterSpacing = ui.t(0.9f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f).padding(start = ui.s(2f))
            )
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .squishClick(onClick = onOpenAll)
                    .padding(horizontal = ui.s(8f), vertical = ui.s(4f)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(tr("Все"), color = accent, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold, maxLines = 1)
                Spacer(Modifier.width(ui.s(2f)))
                Glyph(GlyphKind.CHEVRON, accent, Modifier.size(ui.s(14f)))
            }
        }
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .layout { measurable, constraints ->
                    val extra = bleed.roundToPx()
                    val wide = constraints.maxWidth + extra * 2
                    val placeable = measurable.measure(constraints.copy(minWidth = wide, maxWidth = wide))
                    layout(constraints.maxWidth, placeable.height) { placeable.place(-extra, 0) }
                }
        ) {
            val gap = ui.s(10f)
            // Three tiles and the edge of a fourth: the row says "there is more" without a word.
            val tileW = (maxWidth - bleed * 2 - gap * 2) / 3.3f
            val tileH = tileW / aspect
            LazyRow(
                state = list,
                contentPadding = PaddingValues(horizontal = bleed),
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                itemsIndexed(items, key = { _, w -> w.id }) { i, w ->
                    RowTile(
                        w, w == current, palette, accent, tileW, tileH, i,
                        Modifier.animateItem(fadeInSpec = null, placementSpec = Toon.pop<IntOffset>(), fadeOutSpec = null)
                    ) { origin ->
                        WallpaperScreen.requestReveal(w.id, origin)
                        onPick(w)
                    }
                }
                item(key = "all") {
                    AllTile(palette, rest, tileW, tileH, items.size, onOpenAll)
                }
            }
        }
        Spacer(Modifier.height(ui.s(4f)))
    }
    }
}

/** One wallpaper of the row: the miniature, the check on the current one, the name under it. */
@Composable
internal fun RowTile(
    wallpaper: Wallpaper,
    selected: Boolean,
    palette: PhasePalette,
    accent: Color,
    width: Dp,
    height: Dp,
    order: Int,
    modifier: Modifier = Modifier,
    showName: Boolean = true,
    onClick: (Offset) -> Unit
) {
    val ui = uiScale()
    val shape = RoundedCornerShape(ui.s(16f))
    var center by remember { mutableStateOf(Offset.Unspecified) }
    // Boing when it becomes the chosen one — not on the first frame (the pop-in already plays then).
    val boing = remember { Animatable(1f) }
    var seen by remember { mutableStateOf(selected) }
    LaunchedEffect(selected) {
        if (selected && !seen) {
            boing.snapTo(0.82f)
            boing.animateTo(1f, Toon.rubber<Float>())
        }
        seen = selected
    }
    val ring by animateColorAsState(if (selected) accent else Color.White.copy(alpha = 0.10f), Toon.squash<Color>(), label = "tileRing")
    val ringWidth by animateDpAsState(if (selected) 2.5.dp else 1.dp, Toon.rubber<Dp>(), label = "tileRingWidth")
    val check by animateFloatAsState(if (selected) 1f else 0f, Toon.rubber<Float>(), label = "tileCheck")
    val name = wallpaper.title()
    Column(modifier.width(width).popIn(order, wallpaper.id), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(width, height)
                .graphicsLayer {
                    scaleX = boing.value
                    scaleY = boing.value
                }
                .onGloballyPositioned { center = it.boundsInRoot().center }
                .squishClick(role = Role.RadioButton) { onClick(center) }
                .semantics {
                    contentDescription = name
                    this.selected = selected
                }
                .clip(shape)
                .border(ringWidth, ring, shape)
        ) {
            WallpaperThumb(wallpaper, palette, Modifier.fillMaxSize())
            if (check > 0.01f) {
                CheckMark(accent, check, Modifier.align(Alignment.TopEnd).padding(ui.s(6f)).size(ui.s(20f)))
            }
        }
        if (showName) {
            Spacer(Modifier.height(ui.s(6f)))
            Text(
                name,
                color = if (selected) TextPrimary else TextTertiary,
                fontSize = ui.t(11.5f),
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/** «Все обои»: a 2×2 mosaic of pictures and a count — the album cover of the gallery. */
@Composable
private fun AllTile(palette: PhasePalette, rest: Int, width: Dp, height: Dp, order: Int, onClick: () -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(ui.s(16f))
    val mosaic = remember { WallpaperCatalog.all.filter { it.isImage }.take(4) }
    val label = tr("Все обои")
    Column(Modifier.width(width).popIn(order, "all"), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(width, height)
                .squishClick(onClick = onClick)
                .semantics { contentDescription = label }
                .clip(shape)
                .background(Color.White.copy(alpha = 0.06f))
                .border(1.dp, Color.White.copy(alpha = 0.12f), shape)
                .padding(ui.s(7f))
        ) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(ui.s(5f))) {
                for (r in 0 until 2) {
                    Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(ui.s(5f))) {
                        for (c in 0 until 2) {
                            val w = mosaic.getOrNull(r * 2 + c)
                            Box(Modifier.weight(1f).fillMaxSize().clip(RoundedCornerShape(ui.s(8f))).background(Color.White.copy(alpha = 0.05f))) {
                                if (w != null) WallpaperThumb(w, palette, Modifier.fillMaxSize())
                            }
                        }
                    }
                }
            }
            if (rest > 0) {
                Box(
                    Modifier
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(50))
                        .background(Color.Black.copy(alpha = 0.55f))
                        .padding(horizontal = ui.s(10f), vertical = ui.s(4f))
                ) {
                    Text("+$rest", color = TextPrimary, fontSize = ui.t(13f), fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.height(ui.s(6f)))
        Text(
            label, color = TextTertiary, fontSize = ui.t(11.5f), maxLines = 1,
            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
    }
}
