package com.nur.prayer

import com.nur.prayer.i18n.tr

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.nur.prayer.icon.AppIconSwitcher
import com.nur.prayer.location.LocationRequestPolicy
import com.nur.prayer.location.LocationRequestStep
import com.nur.prayer.notify.AzanPlayerService
import com.nur.prayer.notify.PrayerAlarmScheduler
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.AppViewModel
import com.nur.prayer.ui.NurRoot
import com.nur.prayer.ui.components.LaunchScreen
import com.nur.prayer.ui.theme.NurTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()
    private var permissionEpoch by mutableIntStateOf(0)
    private var awaitingLocationSettings = false
    private var locationReceiverRegistered = false
    private val locationSettingsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { continuePendingLocation() }
    }

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { permissionEpoch++; viewModel.onPermissionsChanged(); askFirstLocationOnce() }

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (viewModel.hasLocationPermission()) {
            requestLocation() // permission and the system switch are separate gates
        } else {
            awaitingLocationSettings = true
            val step = nextLocationStep()
            viewModel.locationNeedsAction(step,
                tr("Доступ не выдан — разрешите точное или приблизительное местоположение"))
        }
    }

    /** Set by the launch screen's first composition: until then the system splash stays up. */
    @Volatile private var launchScreenDrawn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        // 0.24.0: swaps Theme.Nur.Starting (white, the Nur mark) for Theme.Nur. Must run before super.
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        awaitingLocationSettings = savedInstanceState?.getBoolean("awaiting_location_settings") ?: false
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        syncSystemBars()
        runCatching { AppIconSwitcher.migrateArtworkSwap(this) }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // The location question follows from its callback: Android shows one dialog at a time.
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else if (savedInstanceState == null) {
            askFirstLocationOnce()
        }

        setContent {
            NurTheme {
                val data by viewModel.data.collectAsStateWithLifecycle()
                val locating by viewModel.locating.collectAsStateWithLifecycle()
                val locationStatus by viewModel.locationStatus.collectAsStateWithLifecycle()
                val locationStep by viewModel.locationStep.collectAsStateWithLifecycle()
                // Deliberately *not* `by`: the clock travels down the tree as state, so this
                // composable never recomposes on a tick. See the doc on `NurRoot.now`.
                val now = viewModel.now.collectAsStateWithLifecycle()
                // System dialogs return through onResume. Re-check immediately rather than
                // reading the clock here and invalidating the root once every minute.
                val exactAllowed = remember(permissionEpoch) {
                    PrayerAlarmScheduler.canScheduleExact(this@MainActivity)
                }
                val notificationsAllowed = remember(permissionEpoch) {
                    androidx.core.app.NotificationManagerCompat.from(this@MainActivity).areNotificationsEnabled()
                }

                NurRoot(
                    data = data,
                    now = now,
                    locating = locating,
                    locationStatus = locationStatus,
                    locationButtonLabel = locationStep.buttonLabel,
                    exactAlarmsAllowed = exactAllowed,
                    notificationsAllowed = notificationsAllowed,
                    citySearch = { query -> viewModel.cities(query) },
                    onPickCity = { city -> awaitingLocationSettings = false; viewModel.selectCity(city) },
                    actionsFactory = { openCityPicker ->
                        AppActions(
                            openCityPicker = openCityPicker,
                            requestLocation = { requestLocation() },
                            openLocationPermissions = { openLocationPermissions() },
                            openExactAlarmSettings = { openExactAlarmSettings() },
                            openBatterySettings = { openBatterySettings() },
                            openNotificationSettings = { openNotificationSettings() },
                            setMethod = { method ->
                                lifecycleScope.launch { viewModel.repository.setMethod(method) }
                            },
                            setMadhab = { madhab ->
                                lifecycleScope.launch { viewModel.repository.setMadhab(madhab) }
                            },
                            setHighLatitudeRule = { rule ->
                                lifecycleScope.launch { viewModel.repository.setHighLatitudeRule(rule) }
                            },
                            setRounding = { mode ->
                                lifecycleScope.launch { viewModel.repository.setRounding(mode) }
                            },
                            setNotification = { prayer, enabled ->
                                viewModel.setNotification(prayer, enabled)
                            },
                            setOffset = { prayer, minutes -> viewModel.setOffset(prayer, minutes) },
                            setAmbientBackdrop = { enabled ->
                                lifecycleScope.launch { viewModel.repository.setAmbientBackdrop(enabled) }
                            },
                            setSkyBackdrop = { enabled ->
                                lifecycleScope.launch { viewModel.repository.setSkyBackdrop(enabled) }
                            },
                            setWallpaper = { id ->
                                lifecycleScope.launch { viewModel.repository.setWallpaper(id) }
                            },
                            setPreAlert = { minutes ->
                                lifecycleScope.launch { viewModel.repository.setPreAlert(minutes) }
                            },
                            setAzanSound = { sound ->
                                lifecycleScope.launch { viewModel.repository.setAzanSound(sound) }
                            },
                            previewAzan = { sound ->
                                AzanPlayerService.play(
                                    this@MainActivity,
                                    tr("Проверка азана"),
                                    sound.title,
                                    sound,
                                    preview = true
                                )
                            },
                            stopAzan = { AzanPlayerService.stopPreview(this@MainActivity) },
                            setHijriOffset = { days ->
                                lifecycleScope.launch { viewModel.repository.setHijriOffset(days) }
                            }
                        )
                    }
                )
            }
        }

        // A fresh start only: a rotation or a re-created activity must not replay the launch screen.
        if (savedInstanceState == null) showLaunchScreen(splash)
    }

    /**
     * 0.24.0: the launch screen above the app. A separate ComposeView on top of the content, so NurRoot
     * is composed and loading underneath the whole time and is simply uncovered when the data is there.
     * The system splash shows the same picture (white, the mark in the middle) and is removed without
     * its own exit animation the moment the first frame of this one is ready: no black window between.
     */
    private fun showLaunchScreen(splash: SplashScreen) {
        val deadline = SystemClock.uptimeMillis() + 1500L
        splash.setKeepOnScreenCondition { !launchScreenDrawn && SystemClock.uptimeMillis() < deadline }
        splash.setOnExitAnimationListener { it.remove() }
        val overlay = ComposeView(this)
        overlay.setContent {
            NurTheme {
                val data by viewModel.data.collectAsStateWithLifecycle()
                LaunchScreen(
                    ready = data != null,
                    onShown = { launchScreenDrawn = true },
                    onFinished = { overlay.post { (overlay.parent as? ViewGroup)?.removeView(overlay) } }
                )
            }
        }
        addContentView(overlay, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    override fun onResume() {
        super.onResume()
        permissionEpoch++
        syncSystemBars()
        // Self-heal the alarm chain and the clock every time the user opens the app.
        continuePendingLocation()
        viewModel.refresh()
        viewModel.onPermissionsChanged()
    }

    override fun onStart() {
        super.onStart()
        viewModel.setForeground(true)
        val filter = IntentFilter(LocationManager.MODE_CHANGED_ACTION).apply {
            addAction(LocationManager.PROVIDERS_CHANGED_ACTION)
        }
        ContextCompat.registerReceiver(this, locationSettingsReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        locationReceiverRegistered = true
    }

    override fun onStop() {
        if (locationReceiverRegistered) {
            unregisterReceiver(locationSettingsReceiver)
            locationReceiverRegistered = false
        }
        viewModel.setForeground(false)
        // Left normally: whatever language is showing did not crash the process.
        com.nur.prayer.i18n.L10n.confirm()
        // A new launcher icon is applied only once the app is off screen: see AppIconSwitcher.
        if (!isChangingConfigurations) runCatching { AppIconSwitcher.applyPending(this) }
        super.onStop()
    }

    private fun syncSystemBars() {
        // 0.18.0 (targetSdk 35): edge-to-edge is no longer a choice — Android 15 draws the app under
        // both system bars and ignores the window bar colours (status, navigation, divider), so
        // they are not set any more. enableEdgeToEdge() in onCreate makes the bars transparent; the sky
        // runs under them, and on three-button navigation NurRoot draws the translucent scrim itself.
        // What is left to say here: no system scrim over the buttons, and the icon tone — light on
        // the sky, dark while the Quran's paper page is open (0.18.4, see SystemBarsTone).
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        com.nur.prayer.ui.theme.SystemBarsTone.apply(window)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("awaiting_location_settings", awaitingLocationSettings)
        super.onSaveInstanceState(outState)
    }

    private fun nextLocationStep(): LocationRequestStep = LocationRequestPolicy.next(
        hasPermission = viewModel.hasLocationPermission(),
        askedBefore = getPreferences(MODE_PRIVATE).getBoolean("location_permission_requested", false),
        showRationale = shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_COARSE_LOCATION) ||
            shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION),
        locationEnabled = viewModel.isLocationEnabled())

    /**
     * 0.18.6: a fresh install asks where the user is right away instead of silently computing Moscow.
     * Once per install, and only while no place has been chosen: a refusal is final here — the home
     * card and the city picker stay available, the app never nags with the system dialog again.
     */
    private fun askFirstLocationOnce() {
        val prefs = getPreferences(MODE_PRIVATE)
        if (prefs.getBoolean(KEY_FIRST_LOCATION_ASKED, false)) return
        lifecycleScope.launch {
            val stored = viewModel.repository.settings.first()
            if (stored.placeChosen) {
                prefs.edit().putBoolean(KEY_FIRST_LOCATION_ASKED, true).apply()
                return@launch
            }
            prefs.edit().putBoolean(KEY_FIRST_LOCATION_ASKED, true).apply()
            requestLocation()
        }
    }

    private fun requestLocation() {
        when (val step = nextLocationStep()) {
            LocationRequestStep.LOCATE -> {
                awaitingLocationSettings = false
                viewModel.useDeviceLocation(forceFresh = true)
            }
            LocationRequestStep.REQUEST_PERMISSION -> {
                getPreferences(MODE_PRIVATE).edit().putBoolean("location_permission_requested", true).apply()
                locationPermission.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
            }
            LocationRequestStep.OPEN_LOCATION_SETTINGS -> {
                awaitingLocationSettings = true
                viewModel.locationNeedsAction(step,
                    tr("Включите геолокацию в Android и вернитесь в Nur — определение продолжится автоматически."))
                openLocationSettings(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS), step)
            }
            LocationRequestStep.OPEN_APP_SETTINGS -> {
                awaitingLocationSettings = true
                viewModel.locationNeedsAction(step,
                    tr("Откройте «Разрешения → Местоположение» и разрешите доступ при использовании. После возврата запрос продолжится."))
                openLocationSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")), step)
            }
        }
    }

    private fun openLocationPermissions() {
        awaitingLocationSettings = true
        viewModel.locationNeedsAction(LocationRequestStep.OPEN_APP_SETTINGS,
            tr("В разделе «Разрешения → Местоположение» можно включить точный доступ. После возврата Nur запросит новую точку."))
        openLocationSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")),
            LocationRequestStep.OPEN_APP_SETTINGS)
    }

    private fun openLocationSettings(intent: Intent, step: LocationRequestStep) {
        runCatching { startActivity(intent) }.onFailure {
            viewModel.locationNeedsAction(step, tr("Не удалось открыть системный экран. Включите геолокацию и доступ к ней в настройках Android вручную."))
        }
    }

    private fun continuePendingLocation() {
        if (!awaitingLocationSettings && viewModel.locationStep.value != LocationRequestStep.OPEN_LOCATION_SETTINGS) return
        if (viewModel.hasLocationPermission() && viewModel.isLocationEnabled()) {
            awaitingLocationSettings = false
            viewModel.useDeviceLocation(forceFresh = true)
        } else {
            val step = nextLocationStep()
            viewModel.locationNeedsAction(step, if (viewModel.hasLocationPermission())
                tr("Геолокация выключена — нажмите «Включить геолокацию»")
            else tr("Доступ к местоположению пока не выдан. Нажмите кнопку разрешения или выберите город вручную."))
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            }
        }
    }

    private fun openNotificationSettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
    }

    private fun openBatterySettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }.onFailure {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
    }

    private companion object {
        const val KEY_FIRST_LOCATION_ASKED = "first_location_asked"
    }
}
