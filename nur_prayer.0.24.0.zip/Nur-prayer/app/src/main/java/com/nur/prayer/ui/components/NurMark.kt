package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp

/**
 * 0.24.0: the Nur mark — a ring with a crescent inside.
 *
 * The numbers below are `tools/launcher_icons/nur_mark.py`, digit for digit: that script draws the
 * launcher icon and writes the system-splash vector from the same geometry, and
 * `tools/check_splash.py` fails the build when this object and the script disagree. Unit space: the
 * mark spans [-1, 1], the ring's outer radius is 1; the crescent is disc A minus disc B.
 */
object NurMarkSpec {
    const val RING_W = 0.115f
    const val A_CX = 0.075f
    const val A_CY = 0.095f
    const val A_R = 0.54f
    const val B_CX = -0.125f
    const val B_CY = -0.09f
    const val B_R = 0.485f
    const val G0X = 0.12f
    const val G0Y = 0.05f
    const val G1X = 0.88f
    const val G1Y = 0.95f

    val RingLight = Color(0xFF9C74FF)
    val RingDeep = Color(0xFF5B2BD8)
    val CrescentLight = Color(0xFFB79CFF)
    val CrescentDeep = Color(0xFF6D3FF0)
}

/**
 * Draws the mark filling its square. [sweepAngle] >= 0 lays a soft highlight on the ring at that angle
 * (the launch screen turns it while the app is loading); [sweepAlpha] fades it in and out.
 */
fun DrawScope.drawNurMark(sweepAngle: Float = 0f, sweepAlpha: Float = 0f) {
    val r = size.minDimension / 2f
    val c = Offset(size.width / 2f, size.height / 2f)
    fun gradient(light: Color, deep: Color) = Brush.linearGradient(
        colors = listOf(light, deep),
        start = Offset(c.x + (NurMarkSpec.G0X * 2f - 1f) * r, c.y + (NurMarkSpec.G0Y * 2f - 1f) * r),
        end = Offset(c.x + (NurMarkSpec.G1X * 2f - 1f) * r, c.y + (NurMarkSpec.G1Y * 2f - 1f) * r)
    )
    val stroke = r * NurMarkSpec.RING_W
    val ringRadius = r - stroke / 2f
    drawCircle(
        brush = gradient(NurMarkSpec.RingLight, NurMarkSpec.RingDeep),
        radius = ringRadius,
        center = c,
        style = Stroke(width = stroke)
    )
    val discA = Path().apply {
        addOval(Rect(Offset(c.x + NurMarkSpec.A_CX * r, c.y + NurMarkSpec.A_CY * r), NurMarkSpec.A_R * r))
    }
    val discB = Path().apply {
        addOval(Rect(Offset(c.x + NurMarkSpec.B_CX * r, c.y + NurMarkSpec.B_CY * r), NurMarkSpec.B_R * r))
    }
    drawPath(
        path = Path.combine(PathOperation.Difference, discA, discB),
        brush = gradient(NurMarkSpec.CrescentLight, NurMarkSpec.CrescentDeep)
    )
    if (sweepAlpha > 0f) {
        drawArc(
            color = Color.White.copy(alpha = 0.62f * sweepAlpha),
            startAngle = sweepAngle,
            sweepAngle = 64f,
            useCenter = false,
            topLeft = Offset(c.x - ringRadius, c.y - ringRadius),
            size = Size(ringRadius * 2f, ringRadius * 2f),
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )
    }
}

/** The mark as a composable, [size] across the ring's outer edge. */
@Composable
fun NurMark(size: Dp, modifier: Modifier = Modifier, sweepAngle: Float = 0f, sweepAlpha: Float = 0f) {
    Box(modifier.size(size)) {
        Canvas(Modifier.size(size)) { drawNurMark(sweepAngle, sweepAlpha) }
    }
}
