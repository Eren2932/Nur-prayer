package com.nur.prayer.ui.components

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.nur.prayer.ui.theme.SystemBarsTone
import com.nur.prayer.ui.theme.findActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * 0.24.0: the launch screen. It continues the system splash (Theme.Nur.Starting: the same white, the
 * same mark, the same size and place) so there is no black window and no jump between the two.
 *
 * While the data is not there yet the ring carries a soft highlight round it; when the data is ready
 * (and the screen has been up for at least [MIN_MILLIS], so it never flashes) the mark swells slightly
 * and the screen fades into the app, which has been composed underneath all along.
 */
object LaunchScreenSpec {
    /** Matches @color/splash_bg and the splash icon in res/drawable/ic_splash_mark.xml. */
    val Background = Color(0xFFFFFFFF)
    val Wordmark = Color(0xFF9B93B8)
    const val MARK_DP = 112
    const val MIN_MILLIS = 700L
    /** Never trap the user: if the data has not come by now, the app opens anyway. */
    const val MAX_MILLIS = 5000L
    const val EXIT_MILLIS = 420
    const val SPIN_MILLIS = 1500
}

@Composable
fun LaunchScreen(ready: Boolean, onShown: () -> Unit, onFinished: () -> Unit) {
    val readyNow by rememberUpdatedState(ready)
    val exit = remember { Animatable(0f) }
    val sweepIn = remember { Animatable(0f) }
    val angle by rememberInfiniteTransition(label = "launch-spin").animateFloat(
        initialValue = -90f,
        targetValue = 270f,
        animationSpec = infiniteRepeatable(tween(LaunchScreenSpec.SPIN_MILLIS, easing = LinearEasing)),
        label = "launch-angle"
    )

    // Dark system-bar icons on the white screen; the app's own tone comes back when it is gone.
    val window = LocalContext.current.findActivity()?.window
    val view = LocalView.current
    DisposableEffect(window) {
        window?.let {
            WindowCompat.getInsetsController(it, view).apply {
                isAppearanceLightStatusBars = true
                isAppearanceLightNavigationBars = true
            }
        }
        onDispose { SystemBarsTone.apply(window) }
    }
    // The system splash is held until this first frame exists, so it hands over to white, not black.
    SideEffect { onShown() }

    LaunchedEffect(Unit) {
        val started = SystemClock.uptimeMillis()
        launch {
            delay(260)
            sweepIn.animateTo(1f, tween(320))
        }
        withTimeoutOrNull(LaunchScreenSpec.MAX_MILLIS) { snapshotFlow { readyNow }.first { it } }
        val left = LaunchScreenSpec.MIN_MILLIS - (SystemClock.uptimeMillis() - started)
        if (left > 0) delay(left)
        launch { sweepIn.animateTo(0f, tween(160)) }
        exit.animateTo(1f, tween(LaunchScreenSpec.EXIT_MILLIS, easing = FastOutSlowInEasing))
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = 1f - exit.value }
            .background(LaunchScreenSpec.Background)
            // Nothing underneath may be tapped while the screen is up.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        NurMark(
            size = LaunchScreenSpec.MARK_DP.dp,
            modifier = Modifier
                .align(Alignment.Center)
                .graphicsLayer {
                    val s = 1f + 0.12f * exit.value
                    scaleX = s
                    scaleY = s
                },
            sweepAngle = angle,
            sweepAlpha = sweepIn.value
        )
        Text(
            text = "Nur",
            color = LaunchScreenSpec.Wordmark,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 5.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 44.dp)
        )
    }
}
