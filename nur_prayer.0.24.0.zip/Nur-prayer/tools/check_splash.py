#!/usr/bin/env python3
"""0.24.0: the launch screen must stay one picture, and must stay white.

Before 0.24.0 the activity's starting theme was Theme.Nur, whose window is black: the dark flash between
the tap on the icon and the first frame. The fix has four parts that only work together, and each can be
broken silently by an innocent edit:

  1. Theme.Nur.Starting (Theme.SplashScreen): white background, the mark as the icon, hand-over to Theme.Nur;
     the manifest gives it to MainActivity.
  2. res/drawable/ic_splash_mark.xml is generated from tools/launcher_icons/nur_mark.py — never edited by hand.
  3. ui/components/NurMark.kt repeats the geometry of that script, and LaunchScreen draws it at the size and
     colour of the system splash, so the hand-over has no jump.
  4. MainActivity installs the splash before super.onCreate, keeps it until the launch screen has its first
     frame, removes it without its own exit animation, and shows the launch screen on a fresh start only.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools/launcher_icons'))
import nur_mark  # noqa: E402

FILES = {
    'themes': 'app/src/main/res/values/themes.xml',
    'colors': 'app/src/main/res/values/colors.xml',
    'manifest': 'app/src/main/AndroidManifest.xml',
    'gradle': 'app/build.gradle.kts',
    'vector': 'app/src/main/res/drawable/ic_splash_mark.xml',
    'mark': 'app/src/main/java/com/nur/prayer/ui/components/NurMark.kt',
    'launch': 'app/src/main/java/com/nur/prayer/ui/components/LaunchScreen.kt',
    'activity': 'app/src/main/java/com/nur/prayer/MainActivity.kt',
}


def read_all(root=ROOT):
    return {k: (root / v).read_text(encoding='utf-8') for k, v in FILES.items()}


def const(src, name):
    m = re.search(r'const val %s\s*=\s*(-?[0-9.]+)[fL]?\b' % name, src)
    return float(m[1]) if m else None


def colour(src, name):
    m = re.search(r'val %s\s*=\s*Color\(0xFF([0-9A-Fa-f]{6})\)' % name, src)
    return '#' + m[1].upper() if m else None


def problems(f):
    out = []
    # 1. theme and manifest
    themes = f['themes']
    m = re.search(r'<style name="Theme\.Nur\.Starting" parent="Theme\.SplashScreen">(.*?)</style>', themes, re.S)
    if not m:
        out.append('themes.xml: Theme.Nur.Starting (parent Theme.SplashScreen) is missing')
    else:
        body = m[1]
        for need, why in (('windowSplashScreenBackground">@color/splash_bg<', 'the white background'),
                          ('windowSplashScreenAnimatedIcon">@drawable/ic_splash_mark<', 'the Nur mark'),
                          ('postSplashScreenTheme">@style/Theme.Nur<', 'the hand-over to Theme.Nur')):
            if need not in body:
                out.append(f'Theme.Nur.Starting: lost {why}')
    if not re.search(r'<color name="splash_bg">#FFFFFFFF</color>', f['colors']):
        out.append('colors.xml: splash_bg must be opaque white (the launch screen is drawn on white)')
    if not re.search(r'android:name="\.MainActivity"[^>]*?android:theme="@style/Theme\.Nur\.Starting"', f['manifest'], re.S):
        out.append('AndroidManifest: MainActivity must use @style/Theme.Nur.Starting (a black window flashes otherwise)')
    if 'androidx.core:core-splashscreen:' not in f['gradle']:
        out.append('build.gradle.kts: androidx.core:core-splashscreen is missing')

    # 2. the system-splash vector is generated, never edited
    if f['vector'] != nur_mark.splash_xml():
        out.append('ic_splash_mark.xml differs from nur_mark.py output: run python3 tools/launcher_icons/nur_mark.py')

    # 3. Kotlin geometry == generator geometry
    mark, launch = f['mark'], f['launch']
    for name, want in (('RING_W', nur_mark.RING_W), ('A_CX', nur_mark.A_C[0]), ('A_CY', nur_mark.A_C[1]),
                       ('A_R', nur_mark.A_R), ('B_CX', nur_mark.B_C[0]), ('B_CY', nur_mark.B_C[1]),
                       ('B_R', nur_mark.B_R), ('G0X', nur_mark.G0[0]), ('G0Y', nur_mark.G0[1]),
                       ('G1X', nur_mark.G1[0]), ('G1Y', nur_mark.G1[1])):
        got = const(mark, name)
        if got is None or abs(got - want) > 1e-9:
            out.append(f'NurMarkSpec.{name} = {got} but nur_mark.py says {want}')
    for name, want in (('RingLight', nur_mark.SPLASH_RING[0]), ('RingDeep', nur_mark.SPLASH_RING[1]),
                       ('CrescentLight', nur_mark.SPLASH_CRESCENT[0]), ('CrescentDeep', nur_mark.SPLASH_CRESCENT[1])):
        if colour(mark, name) != want.upper():
            out.append(f'NurMarkSpec.{name} = {colour(mark, name)} but nur_mark.py says {want}')
    if const(launch, 'MARK_DP') != nur_mark.SPLASH_RING_DP:
        out.append('LaunchScreenSpec.MARK_DP must equal the ring size of the system splash icon (SPLASH_RING_DP)')
    if colour(launch, 'Background') != '#FFFFFF':
        out.append('LaunchScreenSpec.Background must be the splash white')
    exit_ms, min_ms, max_ms = const(launch, 'EXIT_MILLIS'), const(launch, 'MIN_MILLIS'), const(launch, 'MAX_MILLIS')
    if not (min_ms and 300 <= min_ms <= 1200):
        out.append('LaunchScreen: MIN_MILLIS must be a short minimum (0.3-1.2 s), long enough not to flash')
    if not (max_ms and max_ms <= 8000):
        out.append('LaunchScreen: MAX_MILLIS must cap the wait (<= 8 s): the screen may never trap the user')
    if 'withTimeoutOrNull(LaunchScreenSpec.MAX_MILLIS)' not in launch:
        out.append('LaunchScreen: the wait for the data must be capped by MAX_MILLIS')
    if not (exit_ms and 200 <= exit_ms <= 700):
        out.append('LaunchScreen: EXIT_MILLIS out of range (0.2-0.7 s)')
    if '.pointerInput(Unit) { detectTapGestures { } }' not in launch:
        out.append('LaunchScreen: must swallow touches while it is up')
    if 'SideEffect { onShown() }' not in launch:
        out.append('LaunchScreen: must report its first frame (onShown) so the system splash can go')

    # 4. activity order and conditions
    act = f['activity']
    i_install, i_super = act.find('installSplashScreen()'), act.find('super.onCreate(savedInstanceState)')
    if not (0 <= i_install < i_super):
        out.append('MainActivity: installSplashScreen() must come before super.onCreate')
    if not re.search(r'if \(savedInstanceState == null\) showLaunchScreen\(splash\)', act):
        out.append('MainActivity: the launch screen belongs to a fresh start only (savedInstanceState == null)')
    if 'splash.setOnExitAnimationListener { it.remove() }' not in act:
        out.append('MainActivity: the system splash must be removed without its own exit animation')
    if not re.search(r'setKeepOnScreenCondition \{ !launchScreenDrawn && SystemClock\.uptimeMillis\(\) < deadline \}', act):
        out.append('MainActivity: keep the system splash until the launch screen is drawn, with a deadline')
    if 'ready = data != null' not in act:
        out.append('MainActivity: the launch screen is ready only when the data is')
    return out


def main():
    found = problems(read_all())
    if found:
        print('\n'.join(found))
        sys.exit(f'check_splash: {len(found)} problem(s)')
    print('PASS: launch screen — white starting theme, one mark geometry, safe hand-over.')


if __name__ == '__main__':
    main()
