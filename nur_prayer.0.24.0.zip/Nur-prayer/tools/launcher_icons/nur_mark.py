#!/usr/bin/env python3
"""0.24.0: the Nur mark — a ring with a crescent inside — and everything drawn from it.

One geometry, three consumers, so the launcher icon, the system splash and the in-app launch screen
are the same picture to the pixel:

  * build_icons.py rasterises it for the default launcher icon («Нур») and «Оникс»;
  * `python3 tools/launcher_icons/nur_mark.py` writes res/drawable/ic_splash_mark.xml (the system
    splash icon, Android 12+ and the compat library below it);
  * ui/components/NurMark.kt repeats the same numbers for the Compose launch screen;
    tools/check_splash.py fails the build if the two drift apart.

Unit coordinates: the mark spans [-1, 1] in both axes, the ring's outer radius is 1. The crescent is
disc A minus disc B, thick side to the lower right (the lit side), horns up-right and left-down.
"""
import math, os, sys
import numpy as np

RING_W = 0.115
A_C, A_R = (0.075, 0.095), 0.54
B_C, B_R = (-0.125, -0.09), 0.485
# Gradient axis as fractions of the mark's bounding box (top-left light -> bottom-right deep).
G0, G1 = (0.12, 0.05), (0.88, 0.95)

def _hex(s): return tuple(int(s[i:i + 2], 16) / 255 for i in (1, 3, 5))

# (ring light, ring deep), (crescent light, crescent deep)
VIOLET = ((_hex("#9C74FF"), _hex("#5B2BD8")), (_hex("#B79CFF"), _hex("#6D3FF0")))
LAVENDER = ((_hex("#F1EAFF"), _hex("#B9A0FF")), (_hex("#FFFFFF"), _hex("#CDBBFF")))
# Splash on white: the same violet. Hex for the XML / Kotlin.
SPLASH_RING = ("#9C74FF", "#5B2BD8")
SPLASH_CRESCENT = ("#B79CFF", "#6D3FF0")

def _grad(n, c0, c1):
    ys, xs = np.mgrid[:n, :n]; u = (xs + .5) / n; v = (ys + .5) / n
    d = np.array(G1) - np.array(G0)
    t = np.clip(((u - G0[0]) * d[0] + (v - G0[1]) * d[1]) / (d @ d), 0, 1)[..., None]
    return np.array(c0) * (1 - t) + np.array(c1) * t

def masks(n, ss=4):
    N = n * ss; ys, xs = np.mgrid[:N, :N]; x = (xs + .5) / N * 2 - 1; y = (ys + .5) / N * 2 - 1
    r = np.hypot(x, y)
    ring = (r <= 1) & (r >= 1 - RING_W)
    cres = (np.hypot(x - A_C[0], y - A_C[1]) <= A_R) & ~(np.hypot(x - B_C[0], y - B_C[1]) <= B_R)
    f = lambda m: m.astype(np.float32).reshape(n, ss, n, ss).mean((1, 3))
    return f(ring), f(cres)

def render(n, palette):
    """(rgb float HxWx3, alpha float HxW), the mark filling the square."""
    ring, cres = masks(n)
    (r0, r1), (c0, c1) = palette
    ga, gb = _grad(n, r0, r1), _grad(n, c0, c1)
    alpha = 1 - (1 - ring) * (1 - cres)
    rgb = (ga * ring[..., None] + gb * (cres * (1 - ring))[..., None]) / np.maximum(alpha, 1e-6)[..., None]
    return np.clip(rgb, 0, 1), alpha

def mask(n):
    ring, cres = masks(n)
    return 1 - (1 - ring) * (1 - cres)

# --- the crescent as two arcs ---------------------------------------------------------------------
def crescent_points():
    """Intersections of the two circles, the horns, ordered (upper-right horn, lower-left horn)."""
    (ax, ay), (bx, by) = A_C, B_C
    d = math.hypot(ax - bx, ay - by)
    a = (A_R ** 2 - B_R ** 2 + d ** 2) / (2 * d)
    h = math.sqrt(A_R ** 2 - a ** 2)
    mx, my = ax + a * (bx - ax) / d, ay + a * (by - ay) / d
    p = [(mx + h * (by - ay) / d, my - h * (bx - ax) / d), (mx - h * (by - ay) / d, my + h * (bx - ax) / d)]
    p.sort(key=lambda q: q[0] - q[1], reverse=True)   # first = upper right
    return p

def _arc_flags(c, r, p, q, through):
    """SVG arc flags (large, sweep) for the arc p->q on circle (c, r) that passes the angle `through`."""
    ang = lambda pt: math.atan2(pt[1] - c[1], pt[0] - c[0])
    t0, t1, tm = ang(p), ang(q), through
    cw = (t1 - t0) % (2 * math.pi)            # increasing angle = clockwise in y-down coordinates
    mid = (tm - t0) % (2 * math.pi)
    if mid <= cw: sweep, span = 1, cw
    else: sweep, span = 0, 2 * math.pi - cw
    return (1 if span > math.pi else 0), sweep

def crescent_path(scale, cx, cy, digits=3):
    """Vector-drawable pathData of the crescent in a viewport where the unit is `scale` px at (cx, cy)."""
    u, l = crescent_points()
    face = math.atan2(A_C[1] - B_C[1], A_C[0] - B_C[0])
    la, sa = _arc_flags(A_C, A_R, u, l, face)           # outer edge: A, on the side away from B
    lb, sb = _arc_flags(B_C, B_R, l, u, face)           # inner edge: B, the part inside A
    f = lambda v, o: f"{o + v * scale:.{digits}f}"
    P = lambda q: f"{f(q[0], cx)},{f(q[1], cy)}"
    ra, rb = f"{A_R * scale:.{digits}f}", f"{B_R * scale:.{digits}f}"
    return f"M{P(u)}A{ra},{ra} 0 {la} {sa} {P(l)}A{rb},{rb} 0 {lb} {sb} {P(u)}Z"

def ring_path(scale, cx, cy, digits=3):
    """Even-odd annulus: outer circle, inner circle."""
    def circle(r):
        s = lambda v: f"{v:.{digits}f}"
        return f"M{s(cx - r)},{s(cy)}a{s(r)},{s(r)} 0 1 0 {s(2 * r)},0a{s(r)},{s(r)} 0 1 0 {s(-2 * r)},0Z"
    return circle(scale) + circle(scale * (1 - RING_W))

# --- system splash icon ---------------------------------------------------------------------------
SPLASH_DP = 288          # the splash icon canvas (Android draws 2/3 of it inside a circle)
SPLASH_RING_DP = 112     # the ring's outer diameter

def splash_xml():
    R, c = SPLASH_RING_DP / 2, SPLASH_DP / 2
    def grad(c0, c1):
        # gradient axis in viewport coordinates
        x0, y0 = c + (G0[0] * 2 - 1) * R, c + (G0[1] * 2 - 1) * R
        x1, y1 = c + (G1[0] * 2 - 1) * R, c + (G1[1] * 2 - 1) * R
        return (f'        <aapt:attr name="android:fillColor">\n'
                f'            <gradient android:type="linear" android:startX="{x0:.3f}" android:startY="{y0:.3f}"'
                f' android:endX="{x1:.3f}" android:endY="{y1:.3f}">\n'
                f'                <item android:offset="0" android:color="{c0}" />\n'
                f'                <item android:offset="1" android:color="{c1}" />\n'
                f'            </gradient>\n        </aapt:attr>\n')
    return ('<?xml version="1.0" encoding="utf-8"?>\n'
            '<!-- Generated by tools/launcher_icons/nur_mark.py: the Nur mark on the system splash. -->\n'
            f'<vector xmlns:android="http://schemas.android.com/apk/res/android"\n'
            f'    xmlns:aapt="http://schemas.android.com/aapt"\n'
            f'    android:width="{SPLASH_DP}dp" android:height="{SPLASH_DP}dp"\n'
            f'    android:viewportWidth="{SPLASH_DP}" android:viewportHeight="{SPLASH_DP}">\n'
            f'    <path android:fillType="evenOdd" android:pathData="{ring_path(R, c, c)}">\n'
            + grad(*SPLASH_RING) + '    </path>\n'
            f'    <path android:pathData="{crescent_path(R, c, c)}">\n'
            + grad(*SPLASH_CRESCENT) + '    </path>\n</vector>\n')

if __name__ == "__main__":
    root = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
    out = os.path.join(root, "app/src/main/res/drawable/ic_splash_mark.xml")
    open(out, "w").write(splash_xml())
    print("wrote", os.path.relpath(out, root))
