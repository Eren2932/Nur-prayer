#!/usr/bin/env python3
"""Nur 0.15.0 launcher icon generator.

    python3 tools/launcher_icons/build_icons.py            # regenerate app/src/main/res/mipmap-*
    python3 tools/launcher_icons/build_icons.py --store    # + store/ (Play icon, marketing, sheet)

Input: art/launcher/source_disc.webp — the approved artwork, the disc already cropped to a square
(the upscaled original's anti-aliased rim is trimmed off; the alpha edge is rebuilt here exactly).

Geometry (adaptive icon, 108dp layer, 72dp visible):
  * DISC_RATIO of the visible area is the disc. The approved source had 0.7675; 0.735 leaves a
    slightly wider ring so the disc reads cleanly under circle and squircle masks. Disc = 52.9dp,
    well inside the 66dp safe zone.
  * The monochrome layer (Android 13 themed icons) is the moon, star, figure and prayer rug only.

0.24.0: «Нур» and «Оникс» are no longer the photographic disc but the minimal Nur mark — a ring with a
crescent (nur_mark.py draws it; the splash screen uses the same geometry). The other ten palettes stay
recolours of the disc artwork. The mark is drawn a little larger than the disc (MARK_RATIO): a thin ring
needs the room to read at 48dp. The monochrome layer is the mark itself.

Colour variants are OKLCH gradient maps of the one artwork: lightness and texture are kept, hue runs
from `h[0]` in the shadows to `h[1]` in the highlights, chroma is scaled and then fitted into sRGB
per pixel. White parts (moon, star, figure) keep their lightness and lose almost all chroma, so the
symbol stays white on every palette. Background colours live in res/values/launcher_icons.xml;
this script rewrites that file too, so the table below is the single source.
"""
import os, sys
import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import nur_mark

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
SRC = os.path.join(ROOT, "art/launcher/source_disc.webp")
RES = os.path.join(ROOT, "app/src/main/res")
STORE = os.path.join(ROOT, "store")
DISC_RATIO = 0.735
MARK_RATIO = 0.80
MARKS = {"nur": nur_mark.VIOLET, "pearl": nur_mark.LAVENDER}
MONO_DP = 52.0
DENS = {"mdpi": 1, "hdpi": 1.5, "xhdpi": 2, "xxhdpi": 3, "xxxhdpi": 4}

# id, background, recolour (None = original artwork). Order = AppIcon order. `same` reuses a layer.
PALETTES = [
    # 0.18.6: the light ring is the default «Нур» (alias Nur); the dark one moved to alias Pearl,
    # shown as «Оникс». Aliases are frozen, so the artwork moved and not the components.
    ("nur",      "#F4F0FA", None),
    ("pearl",    "#07050B", None),
    ("fajr",     "#14091A", dict(h=(285, 40),  c=1.0,  l0=0.44, ls=1.0,  ht=1.2)),
    ("emerald",  "#04110D", dict(h=(170, 140), c=0.85, l0=0.36, ls=1.0)),
    ("gold",     "#0E0A04", dict(h=(62, 98),   c=0.95, l0=0.50, ls=1.05, ht=0.8)),
    ("midnight", "#03060F", dict(h=(268, 240), c=0.95, l0=0.30, ls=0.95)),
    ("lagoon",   "#EEF7F6", dict(h=(235, 180), c=0.80, l0=0.44, ls=1.0)),
    ("maghrib",  "#12050A", dict(h=(330, 55),  c=1.0,  l0=0.40, ls=1.0,  ht=0.9)),
    ("garnet",   "#0F0407", dict(h=(15, 355),  c=0.95, l0=0.34, ls=0.95)),
    ("aurora",   "#050A10", dict(h=(300, 165), c=0.85, l0=0.38, ls=1.0,  ht=1.3)),
    ("sand",     "#F6F0E6", dict(h=(48, 78),   c=0.55, l0=0.58, ls=0.85)),
    ("graphite", "#0A0A0C", dict(h=(270, 270), c=0.10, l0=0.34, ls=1.0)),
]

# --- OKLab ----------------------------------------------------------------------------------------
M1 = np.array([[0.4122214708, 0.5363325363, 0.0514459929], [0.2119034982, 0.6806995451, 0.1073969566],
               [0.0883024619, 0.2817188376, 0.6299787005]])
M2 = np.array([[0.2104542553, 0.7936177850, -0.0040720468], [1.9779984951, -2.4285922050, 0.4505937099],
               [0.0259040371, 0.7827717662, -0.8086757660]])
M1i, M2i = np.linalg.inv(M1), np.linalg.inv(M2)

def to_lin(c): return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
def to_srgb(c): c = np.clip(c, 0, 1); return np.where(c <= 0.0031308, 12.92 * c, 1.055 * c ** (1 / 2.4) - 0.055)
def oklab(rgb): return np.cbrt(to_lin(rgb) @ M1.T) @ M2.T
def smooth(e0, e1, x): t = np.clip((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t)

def recolor(rgb, p):
    if p is None: return rgb
    lab = oklab(rgb); L = lab[..., 0]; C = np.hypot(lab[..., 1], lab[..., 2])
    w = smooth(0.78, 0.90, L) * smooth(0.16, 0.07, C)          # 1 on moon, star and figure
    t = np.clip((L - 0.40) / 0.40, 0, 1)
    hA, hB = p["h"]; dh = ((hB - hA + 180) % 360) - 180
    H = np.radians(hA + dh * t ** p.get("ht", 1.0))
    Lb = np.clip(p.get("l0", 0.40) + (L - 0.40) * p.get("ls", 1.0), 0, 0.97)
    Ln = Lb * (1 - w) + L * w
    Cn = C * p["c"] * (1 - w) + np.minimum(C * p["c"], 0.012) * w
    def lin(k): return ((np.stack([Ln, Cn * k * np.cos(H), Cn * k * np.sin(H)], -1) @ M2i.T) ** 3) @ M1i.T
    def fits(x): return ((x >= -1e-4) & (x <= 1 + 1e-4)).all(-1)
    ok = fits(lin(1.0)); lo = np.where(ok, 1.0, 0.0); hi = np.ones_like(Cn)
    for _ in range(10):                                         # largest chroma that fits sRGB
        k = (lo + hi) / 2; g = fits(lin(k)) | ok
        lo = np.where(g, k, lo); hi = np.where(g, hi, k)
    return to_srgb(lin(np.where(ok, 1.0, lo)))

def mono_mask(rgb):
    n = rgb.shape[0]; lab = oklab(rgb); L = lab[..., 0]; C = np.hypot(lab[..., 1], lab[..., 2])
    c = (n - 1) / 2; Y, X = np.mgrid[:n, :n]; d = np.hypot(X - c, Y - c) / (n / 2)
    keep = ~((Y < c) & (d > 0.70))                               # lilac rim highlight in the sky
    return smooth(0.74, 0.86, L) * smooth(0.17, 0.11, C) * keep * (d < 0.92)

# --- raster helpers -------------------------------------------------------------------------------
def disc_alpha(n):
    c = (n - 1) / 2; Y, X = np.mgrid[:n, :n]
    return np.clip(n / 2 - np.hypot(X - c, Y - c), 0, 1)

def resize(rgb, a, size):
    """Premultiplied Lanczos: no dark fringe from the transparent outside."""
    A = np.clip(np.asarray(Image.fromarray(a.astype(np.float32), "F").resize((size, size), Image.LANCZOS)), 0, 1)
    C = np.stack([np.asarray(Image.fromarray((rgb[..., i] * a).astype(np.float32), "F").resize((size, size), Image.LANCZOS))
                  for i in range(3)], -1)
    return np.clip(np.where(A[..., None] > 1e-4, C / np.maximum(A[..., None], 1e-4), 0), 0, 1), A

def canvas(rgb, a, px, content):
    di = int(round(content)); c, al = resize(rgb, a, di)
    out = np.zeros((px, px, 4)); o = (px - di) // 2
    out[o:o + di, o:o + di, :3] = c; out[o:o + di, o:o + di, 3] = al
    return Image.fromarray((out * 255 + 0.5).astype(np.uint8), "RGBA")

def flat(rgb, a, px, content, bg):
    img = Image.new("RGBA", (px, px), bg); img.alpha_composite(canvas(rgb, a, px, content)); return img.convert("RGB")

def main(store):
    rgb = np.asarray(Image.open(SRC).convert("RGB")).astype(np.float64) / 255.0
    n = rgb.shape[0]; alpha = disc_alpha(n)
    colours, art = [], {}       # art[id] = (rgb, alpha, ratio of the visible area it fills)
    for id_, bg, p in PALETTES:
        colours.append(f'    <color name="ic_launcher_{id_}_bg">#FF{bg[1:]}</color>')
        if id_ in MARKS:
            mrgb, malpha = nur_mark.render(1024, MARKS[id_])
            art[id_] = (mrgb, malpha, MARK_RATIO)
        else:
            art[id_] = (np.clip(recolor(rgb, p), 0, 1), alpha, DISC_RATIO)
        a_rgb, a_alpha, ratio = art[id_]
        for dn, s in DENS.items():
            d = os.path.join(RES, f"mipmap-{dn}"); os.makedirs(d, exist_ok=True)
            canvas(a_rgb, a_alpha, int(round(108 * s)), 72 * ratio * s).save(
                os.path.join(d, f"ic_launcher_{id_}_fg.webp"), "WEBP", quality=94, method=6, alpha_quality=100)
        print("layer", id_)
    # monochrome (themed icons): the mark itself, white, a little smaller than the coloured layer
    mono = nur_mark.mask(1024).astype(np.float64)
    for dn, s in DENS.items():
        canvas(np.ones(mono.shape + (3,)), mono, int(round(108 * s)), MONO_DP * s).save(
            os.path.join(RES, f"mipmap-{dn}", "ic_launcher_monochrome.webp"), "WEBP", lossless=True)
    with open(os.path.join(RES, "values/launcher_icons.xml"), "w") as f:
        f.write('<?xml version="1.0" encoding="utf-8"?>\n<!-- Generated by tools/launcher_icons/build_icons.py. '
                'Background layer of each launcher icon. -->\n<resources>\n' + "\n".join(colours) + "\n</resources>\n")
    if not store: return
    os.makedirs(os.path.join(STORE, "icons"), exist_ok=True)
    # Google Play: 512x512 full-bleed square, Play applies its own mask. Same disc/visible ratio.
    for id_, bg, _ in PALETTES:
        r, a, k = art[id_]
        flat(r, a, 512, 512 * k, bg).save(os.path.join(STORE, "icons", f"{id_}-512.png"), optimize=True)
    r, a, k = art["nur"]
    flat(r, a, 512, 512 * k, PALETTES[0][1]).save(os.path.join(STORE, "play-icon-512.png"), optimize=True)
    flat(r, a, 1024, 1024 * k, PALETTES[0][1]).save(os.path.join(STORE, "icon-1024.png"), optimize=True)
    flat(r, a, 512, 512 * k, PALETTES[0][1]).save(os.path.join(ROOT, "app/src/main/ic_launcher-playstore.png"), optimize=True)
    # Review sheet: every icon under a circle and a squircle mask, as launchers show them.
    T, V = 260, 220; sheet = Image.new("RGB", (4 * T + 40, 3 * T * 2 + 40), (24, 24, 27))
    for i, (id_, bg, _) in enumerate(PALETTES):
        r, a, k = art[id_]
        tile = flat(r, a, V, V * k, bg)
        for k, shape in enumerate(("circle", "squircle")):
            mk = Image.new("L", (V, V), 0); dr = ImageDraw.Draw(mk)
            if shape == "circle": dr.ellipse((0, 0, V - 1, V - 1), fill=255)
            else: dr.rounded_rectangle((0, 0, V - 1, V - 1), int(V * 0.26), fill=255)
            x = 20 + (i % 4) * T + (T - V) // 2; y = 20 + (i // 4) * T + k * 3 * T + (T - V) // 2
            sheet.paste(tile, (x, y), mk)
    sheet.save(os.path.join(STORE, "launcher-icons-sheet.png"), optimize=True)

if __name__ == "__main__":
    main("--store" in sys.argv)
