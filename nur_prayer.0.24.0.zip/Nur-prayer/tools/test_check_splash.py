#!/usr/bin/env python3
"""check_splash.py must fail on each way of bringing the black flash (or a jump) back."""
import unittest

import check_splash as cs


class SplashChecks(unittest.TestCase):
    def setUp(self):
        self.files = cs.read_all()

    def test_current_sources_pass(self):
        self.assertEqual(cs.problems(self.files), [])

    def broken(self, key, old, new):
        self.assertIn(old, self.files[key], f'{key}: the mutation target is gone — update this test')
        mutated = dict(self.files, **{key: self.files[key].replace(old, new, 1)})
        self.assertTrue(cs.problems(mutated), f'not caught: {old!r} -> {new!r}')

    def test_mutations(self):
        for key, old, new in (
            ('manifest', '@style/Theme.Nur.Starting', '@style/Theme.Nur'),
            ('themes', '@color/splash_bg', '@color/ink'),
            ('themes', 'postSplashScreenTheme">@style/Theme.Nur<', 'postSplashScreenTheme">@style/Other<'),
            ('colors', '#FFFFFFFF', '#FF000000'),
            ('gradle', 'core-splashscreen', 'core-other'),
            ('vector', '56.000', '57.000'),
            ('mark', 'const val A_R = 0.54f', 'const val A_R = 0.55f'),
            ('mark', 'Color(0xFF5B2BD8)', 'Color(0xFF5B2BD9)'),
            ('launch', 'const val MARK_DP = 112', 'const val MARK_DP = 120'),
            ('launch', 'withTimeoutOrNull(LaunchScreenSpec.MAX_MILLIS)', 'run'),
            ('launch', 'SideEffect { onShown() }', ''),
            ('launch', '.pointerInput(Unit) { detectTapGestures { } }', ''),
            ('activity', 'if (savedInstanceState == null) showLaunchScreen(splash)', 'showLaunchScreen(splash)'),
            ('activity', 'splash.setOnExitAnimationListener { it.remove() }', ''),
            ('activity', 'val splash = installSplashScreen()\n        super.onCreate(savedInstanceState)',
                         'super.onCreate(savedInstanceState)\n        val splash = installSplashScreen()'),
            ('activity', 'ready = data != null', 'ready = true'),
        ):
            with self.subTest(change=old):
                self.broken(key, old, new)


if __name__ == '__main__':
    unittest.main()
