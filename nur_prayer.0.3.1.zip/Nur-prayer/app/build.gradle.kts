plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.nur.prayer"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nur.prayer"
        minSdk = 26
        targetSdk = 34
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        versionCode = 14
        versionName = "0.3.1"

        /*
         * The app has exactly one language and no support-library vector shims.
         *
         * Weight measured on 0.2.6: androidx and Material3 ship 80+ translated `values-xx` folders,
         * and every one of them lands in the APK even though every string in the UI is a Russian
         * literal in Kotlin. Filtering them out is the single biggest saving available that does not
         * remove a feature — ~1.1 MB of resources and about 700 entries out of resources.arsc.
         */
        resourceConfigurations += listOf("ru")
        vectorDrawables.useSupportLibrary = false
    }

    buildTypes {
        debug {
            // R8 stays off in debug: this is the variant CI builds first, and a minified debug build
            // adds minutes to the pipeline for an APK nobody ships.
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Debug signing so that CI can produce an *installable* release APK out of the box.
            // Without this the release artifact is unsigned and `adb install` refuses it, which is
            // why the previous pipeline told people to take the fat debug build instead.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        // Everything below is off by default in AGP 8 *except* buildConfig, which generates a class
        // this project never reads. Listing them keeps a future AGP default change from quietly
        // adding a code generation step.
        buildConfig = false
        aidl = false
        renderScript = false
        resValues = false
        shaders = false
    }
    packaging {
        resources.excludes += setOf(
            "/META-INF/{AL2.0,LGPL2.1}",
            "/META-INF/*.kotlin_module",
            "/META-INF/*.version",
            "/META-INF/androidx.*.version",
            "DebugProbesKt.bin",
            "kotlin-tooling-metadata.json",
            "/kotlin/**",
            "**/*.kotlin_builtins"
        )
    }
    sourceSets {
        getByName("test") {
            /*
             * Unit tests read the shipped asset itself, not a copy.
             *
             * The Uzbek table is the app's answer to "почему у вас время не как в календаре": a test
             * against a second copy of it would only prove the copy is consistent. Putting
             * `src/main/assets` on the test classpath means `UzMuftiyatTableTest` parses exactly the
             * bytes that land in the APK, and a regenerated asset that breaks the calendar fails CI
             * before it reaches a phone.
             */
            resources.srcDir("src/main/assets")
        }
    }
    androidResources {
        // The adhan is already a compressed MP3. Re-compressing it in the APK saves nothing and
        // costs build time, and a stored entry lets MediaPlayer read it straight from the package.
        noCompress += "mp3"
    }
    // The Play-services dependency blob is 8 KB of metadata for an app that has no Play dependency.
    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }
    lint {
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.5")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    // ui-tooling-preview used to be an `implementation` dependency, so the tooling stubs shipped in
    // the release APK for the sake of @Preview functions that only Android Studio ever calls.
    debugImplementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation(composeBom)
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
