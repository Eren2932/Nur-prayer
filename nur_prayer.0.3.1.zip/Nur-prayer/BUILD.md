# Сборка и проверка Nur 0.3.1

## Требования

JDK 17, Gradle 8.9, Android SDK Platform 34 / Build Tools 34.0.0. Зависимости скачиваются из обычных
Google/Maven/Gradle репозиториев. В ZIP нет полноценного Gradle wrapper: используйте установленный
`gradle`, а не несуществующий `./gradlew`. В Android Studio откройте каталог с `settings.gradle.kts`.
При желании обёртку можно сгенерировать командой `gradle wrapper --gradle-version 8.9`.

## До APK

````bash
python3 tools/kt_sanity.py
python3 tools/kt_symbols.py
python3 tools/source_audit.py
python3 tools/test_source_archive.py
python3 tools/test_kt_symbols.py
python3 tools/test_build_regressions.py
python3 tools/verify_cities.py
python3 tools/verify_uz_table.py
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleRelease :app:assembleDebugAndroidTest --stacktrace
````

Lint оставлен в исходном режиме `abortOnError=false`, поэтому обязательно прочитайте HTML-отчёт:
зелёная сборка сама по себе не означает отсутствие lint-замечаний. JVM-тесты и ошибка компиляции
должны останавливать CI. APK: `app/build/outputs/apk/debug/` и `release/`.

## На устройстве или эмуляторе

Подключите устройство с USB debugging либо запустите эмулятор API 26+. Затем:

````bash
gradle :app:connectedDebugAndroidTest
gradle :app:installDebug
````

Два UI smoke-теста проверяют поиск/выбор города и семантику переключателя. Они не заменяют
матрицу экранов, системной навигации, разрешений и нагрузки из `docs/QA-0.3.0.md`.

Для сравнения прокрутки используйте release-сборки одинаково подписанных 0.2.10 и 0.3.1,
одно устройство, одинаковые настройки/заряд/температуру. Сбросьте gfxinfo, выполните один и тот же
сценарий поиска и десять быстрых прокруток, затем сохраните framestats. Сравнивайте долю медленных
кадров и p50/p95, а не только визуальное впечатление. В этом пакете такие измерения не выполнены.

## Важное о подписи

Исходная конфигурация сохранена: release минифицируется, но подписывается **тестовым debug-ключом**.
Это удобно для проверки, но не производственная подпись. CI может создавать другой ключ на новом
runner, и APK тогда не установится поверх предыдущего с тем же applicationId. Для настоящих обновлений
настройте постоянный release keystore через GitHub Secrets. Не кладите keystore или пароли в ZIP.

Не удаляйте старое приложение только ради установки бездумно: удаление может стереть настройки.
Сначала обеспечьте тот же сертификат подписи или сохраните необходимые параметры. Debug-вариант
использует суффикс `.debug` и может стоять отдельно; переключение между debug/release не переносит DataStore.

## Что подготовлено, но не запускалось

Для 0.3.1 выполнены проверки, перечисленные в `docs/QA-0.3.1.md`, включая восемь численных
регрессий Python. Они не исполняют Kotlin. Gradle/JVM/Android-проверки исправленной версии
в the Computer не выполнялись: Gradle и Android SDK отсутствуют. Ветка репозитория не изменялась,
GitHub Actions от вашего имени не запускался. Внешний workflow, уже находящийся в репозитории,
подхватит `nur_prayer.0.3.1.zip` без изменений: он уже сортирует номера версий численно.
