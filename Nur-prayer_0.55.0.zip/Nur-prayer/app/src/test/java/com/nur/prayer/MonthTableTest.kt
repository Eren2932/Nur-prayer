package com.nur.prayer

import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.ui.schedule.MonthTimes
import com.nur.prayer.ui.schedule.calendarPage
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import java.time.DayOfWeek
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

/** 0.20.0: the compact month table — its Hijri header, engine columns and whole-month sheet. */
class MonthTableTest {

    @Test fun hijriSpanSaysTheYearOnceWithinOneYear() {
        // 1 Nov 2026 = 21 джумада аль-уля 1448, 30 Nov 2026 = 20 джумада ас-сани 1448 (Umm al-Qura).
        assertEquals("джумада аль-уля — джумада ас-сани 1448",
            HijriCalendar.span(LocalDate.of(2026, 11, 1), LocalDate.of(2026, 11, 30)))
    }

    @Test fun hijriSpanKeepsBothYearsAcrossTheNewYear() {
        // 1 Jun 2026 = 15 зуль-хиджа 1447, 30 Jun 2026 = 15 мухаррам 1448.
        assertEquals("зуль-хиджа 1447 — мухаррам 1448",
            HijriCalendar.span(LocalDate.of(2026, 6, 1), LocalDate.of(2026, 6, 30)))
    }

    @Test fun hijriSpanOfOneMonthIsOneName() {
        assertEquals("джумада аль-уля 1448", HijriCalendar.span(LocalDate.of(2026, 11, 6), LocalDate.of(2026, 11, 6)))
    }

    @Test fun hijriSpanHonoursTheOffset() {
        // Shifted by +10 days, 21–22 Nov 2026 read as 1–2 Dec: 21–22 джумада ас-сани.
        assertEquals("джумада ас-сани 1448", HijriCalendar.span(LocalDate.of(2026, 11, 21), LocalDate.of(2026, 11, 22), 10))
    }

    @Test fun printedMonthIsChronologicalAndHijriTransitionFollowsOffset() {
        val month = YearMonth.of(2026, 11)
        val days = (1..month.lengthOfMonth()).map { PrayerDay(month.atDay(it), emptyMap()) }
        val times = MonthTimes(month, days, Prayer.entries)
        fun sheet(offset: Int) = calendarPage(times, offset, "Казань", CalculationMethod.SPIRITUAL_BOARD_TATARSTAN, month.atEndOfMonth())
        val page = sheet(0)
        assertEquals(days.map { it.date }, page.rows.map { it.date })
        assertEquals(listOf(6, 13, 20, 27), page.rows.filter { it.date.dayOfWeek == DayOfWeek.FRIDAY }.map { it.date.dayOfMonth })
        assertEquals(11, page.rows.single { it.hijri == 1 }.date.dayOfMonth)
        assertEquals(10, sheet(1).rows.single { it.hijri == 1 }.date.dayOfMonth)
        assertEquals(Prayer.entries.indexOf(Prayer.SUNRISE), page.sunrise)
        assertEquals(List(7) { "—" }, page.rows.first().times)
    }

    @Test fun leapMonthAndSixColumnProfileUseTheSuppliedEngineValues() {
        val month = YearMonth.of(2028, 2)
        val columns = Prayer.entries.filterNot { it == Prayer.SAHAR }
        val zone = java.time.ZoneId.of("Asia/Tashkent")
        val days = (1..month.lengthOfMonth()).map { d ->
            val date = month.atDay(d)
            PrayerDay(date, columns.mapIndexed { k, p -> p to date.atTime(k+4, d).atZone(zone) }.toMap())
        }
        val page = calendarPage(MonthTimes(month, days, columns), 0, "Ташкент", CalculationMethod.UZBEKISTAN_BOARD, month.atDay(1))
        assertEquals(29, page.rows.size)
        assertEquals(6, page.columns.size)
        assertEquals(1, page.sunrise)
        days.zip(page.rows).forEach { (day, row) ->
            assertEquals(columns.map { com.nur.prayer.ui.Format.time(day.times.getValue(it)) }, row.times)
        }
    }

    @Test fun feastKeepsPriorityInsideSeasonAndMovesWithHijriOffset() {
        val feast = requireNotNull(com.nur.prayer.data.IslamicDays.gregorian(1447, 12, 10))
        val month = YearMonth.from(feast)
        val times = MonthTimes(month, (1..month.lengthOfMonth()).map { PrayerDay(month.atDay(it), emptyMap()) }, Prayer.entries)
        for (offset in -1..1) {
            val page = calendarPage(times, offset, "Казань", CalculationMethod.SPIRITUAL_BOARD_TATARSTAN, feast)
            val row = page.rows.single { it.date == feast.minusDays(offset.toLong()) }
            org.junit.Assert.assertTrue(row.special && row.seasonal)
            org.junit.Assert.assertTrue(row.description.contains("Курбан-байрам"))
            org.junit.Assert.assertTrue(page.legend.any { it == "${row.date.dayOfMonth} · Курбан-байрам" })
            val season = page.rows.single { it.date == row.date.minusDays(2) }
            org.junit.Assert.assertTrue(!season.special && season.seasonal)
        }
    }
}
