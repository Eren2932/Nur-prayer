package com.nur.prayer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import com.nur.prayer.ui.schedule.rememberPaperFocus
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.ui.schedule.MonthStrip
import com.nur.prayer.ui.theme.NurTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** A partial drag in each direction: assert the transformed, not just measured, page edges meet. */
@RunWith(AndroidJUnit4::class)
class MonthStripUiTest {
    @get:Rule val compose = createComposeRule()

    @OptIn(ExperimentalFoundationApi::class)
    @Test fun pagesShareOneEdgeInBothMonthViews() {
        val bounds = mutableMapOf<Pair<Int, Int>, Pair<Float, Float>>()
        compose.setContent {
            NurTheme {
                Column {
                    listOf(false, true).forEachIndexed { kind, paper ->
                        listOf(-.375f, .375f).forEachIndexed { direction, offset ->
                            val row = 2 * kind + direction
                            val pager = rememberPagerState(initialPage = 2, initialPageOffsetFraction = offset) { 5 }
                            Box(Modifier.width(320.dp).height(96.dp)) {
                                MonthStrip(pager, paper, floor = 0.dp) { page, _ ->
                                    Box(Modifier.fillMaxSize().onGloballyPositioned { box ->
                                        bounds[row to page] = box.localToRoot(Offset.Zero).x to
                                            box.localToRoot(Offset(box.size.width.toFloat(), 0f)).x
                                    })
                                }
                            }
                        }
                    }
                }
            }
        }
        compose.runOnIdle {
            for (row in 0..3) {
                val first = if (row % 2 == 0) 1 else 2
                val a = bounds.getValue(row to first); val b = bounds.getValue(row to (first + 1))
                assertTrue(a.second > a.first && b.second > b.first)
                assertEquals(a.second, b.first, .5f)
            }
        }
    }

    @Test fun interruptedFocusReturnsWithoutFirstFinishingItsForwardTrip() {
        compose.mainClock.autoAdvance = false
        val reading = mutableStateOf(false)
        lateinit var progress: State<Float>
        compose.setContent { progress = rememberPaperFocus(reading.value) }
        compose.runOnIdle { reading.value = true }
        compose.mainClock.advanceTimeBy(80)
        compose.runOnIdle {
            assertTrue(progress.value > 0f && progress.value < 1f)
            reading.value = false
        }
        compose.mainClock.advanceTimeBy(208)
        compose.runOnIdle { assertEquals(0f, progress.value, .0001f) }
    }
}
