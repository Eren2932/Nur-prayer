package com.nur.prayer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.assertHasNoClickAction
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.click
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipe
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.data.IslamicDay
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.ui.schedule.DaySheet
import com.nur.prayer.ui.schedule.SheetTopic
import com.nur.prayer.ui.schedule.YearView
import com.nur.prayer.ui.theme.NurTheme
import java.time.LocalDate
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class YearReadingUiTest {
    @get:Rule val compose = createComposeRule()
    private fun year() {
        val today = LocalDate.of(2026, 11, 28)
        compose.setContent {
            NurTheme {
                var topic by remember { mutableStateOf<SheetTopic?>(null) }
                Box(Modifier.width(360.dp).height(590.dp)) {
                    YearView(1448, today, 0, 64.dp, { topic = it })
                    DaySheet(topic, today, 0) { topic = null }
                }
            }
        }
    }

    private fun tile(month: Int) = "hijri-month-$month".let { tag ->
        compose.onNodeWithTag("year-view").performScrollToNode(hasTestTag(tag))
        compose.onNodeWithTag(tag)
    }

    @Test fun tileCornerOpensItsArticleAndDraggingTextAtTheTopDismisses() {
        year()
        tile(7).performTouchInput { click(Offset(12f, 12f)) }
        compose.onNodeWithText(IslamicDayText.title(IslamicDay.ISRA_MIRAJ)).assertIsDisplayed()
        compose.onNodeWithTag("article-scroll").performTouchInput {
            swipe(Offset(width*.55f, height*.30f), Offset(width*.55f, height*.85f), 350)
        }
        compose.onNodeWithTag("day-sheet").assertDoesNotExist()
        tile(2).assertHasNoClickAction()
    }

    @Test fun monthIndexIncludesRamadanAndQadrAndLongTextCanBeReadWithoutClosing() {
        year()
        tile(9).performClick()
        compose.onNodeWithTag("event-RAMADAN").assertIsDisplayed()
        compose.onNodeWithTag("event-QADR").performScrollTo().performClick()
        val body = compose.onNodeWithTag("article-scroll")
        body.performTouchInput { swipe(Offset(center.x, height*.86f), Offset(center.x,height*.20f), 400) }
        body.performTouchInput { swipe(Offset(center.x, height*.45f), Offset(center.x,height*.54f), 350) }
        compose.onNodeWithTag("day-sheet").assertIsDisplayed()
    }
}
