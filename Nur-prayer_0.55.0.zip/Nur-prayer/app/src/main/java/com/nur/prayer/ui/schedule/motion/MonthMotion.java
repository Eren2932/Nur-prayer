package com.nur.prayer.ui.schedule.motion;

/** Pure geometry shared with the desktop regression: Android supplies pixels and its own touch slop. */
public final class MonthMotion {
    private MonthMotion() {}
    public static final int WAIT = 0, HORIZONTAL = 1, VERTICAL = 2;
    public static int firstAxis(float dx, float dy, float slop) {
        float x = Math.abs(dx), y = Math.abs(dy);
        if (Math.max(x, y) <= slop) return WAIT;
        return x > y ? HORIZONTAL : VERTICAL;
    }
    public static boolean neighbour(int page, int settled) { return Math.abs(page - settled) <= 1; }
    public static boolean visible(int page, int nearest, float offset) {
        return Math.abs((page - nearest) - offset) < 1f;
    }
}
