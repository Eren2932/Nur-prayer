package com.nur.prayer.ui.schedule

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.uiScale
import java.time.Duration
import java.time.LocalDate
import java.time.ZonedDateTime
import kotlin.math.roundToLong

/** The time column hugs the trailing edge. Long names wrap; a clock is never squeezed into a chip. */
@Composable
internal fun DayCard(date: LocalDate, city: String, offset: Int, day: PrayerDay?, loading: Boolean,
                     columns: List<Prayer>, next: Prayer?, events: List<DayOccurrence>,
                     wide: Boolean, onOpen: (SheetTopic) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val shape = RoundedCornerShape(16.dp)
    Column(modifier.fillMaxWidth().clip(shape).background(Paper.Card).border(1.dp, Paper.Line, shape)
        .padding(horizontal = ui.s(14f), vertical = ui.s(9f)).testTag("calendar-detail")) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(2f)) {
                Text(Format.fullDate(date).replaceFirstChar { it.uppercase(L10n.language.locale) }, color = Paper.Ink,
                    style = TextStyle(fontSize = ui.t(15f), lineHeight = ui.t(18f), fontWeight = FontWeight.SemiBold))
                Text(HijriCalendar.dayAndMonth(date, offset), color = Paper.Ink2,
                    style = TextStyle(fontSize = ui.t(12f), lineHeight = ui.t(15f)))
            }
            Spacer(Modifier.width(8.dp))
            Text(city, Modifier.weight(1f), color = Paper.Ink2, textAlign = TextAlign.End,
                style = TextStyle(fontSize = ui.t(13f), lineHeight = ui.t(16f)))
        }
        events.forEach { event ->
            Text(IslamicDayText.tile(event.day), modifier = Modifier.fillMaxWidth()
                .pressClick(role = Role.Button, onClick = { onOpen(SheetTopic.Day(event)) })
                .padding(vertical = 6.dp), color = Paper.tone(event.kind),
                style = TextStyle(fontSize = ui.t(13f), lineHeight = ui.t(16f), fontWeight = FontWeight.SemiBold))
        }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Paper.Line))
        Spacer(Modifier.height(4.dp))
        if (day == null) Text(if (loading) tr("Рассчитываем время…") else tr("Не удалось рассчитать день"), color = Paper.Ink2)
        else if (wide) {
            val half = (columns.size + 1) / 2
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                columns.chunked(half).forEach { group -> Column(Modifier.weight(1f)) {
                    group.forEach { TimeLine(it, day, it == next) }
                } }
            }
        } else columns.forEach { TimeLine(it, day, it == next) }
    }
}

@Composable
private fun TimeLine(prayer: Prayer, day: PrayerDay, next: Boolean) {
    val ui = uiScale()
    val tone = if (prayer == Prayer.SUNRISE) Paper.Ink2 else Paper.Ink
    Row(Modifier.fillMaxWidth().heightIn(min = ui.s(26f)).testTag("month-time-${prayer.name}")
        .semantics(mergeDescendants = true) {}, verticalAlignment = Alignment.CenterVertically) {
        Text(columnLabel(prayer), Modifier.weight(1f), color = tone,
            style = TextStyle(fontSize = ui.t(15f), lineHeight = ui.t(19f), fontWeight = FontWeight.Medium))
        Spacer(Modifier.width(8.dp))
        Text(day.times[prayer]?.let(Format::time) ?: "—", color = tone, maxLines = 1, softWrap = false,
            style = TextStyle(fontSize = ui.t(21f), lineHeight = ui.t(25f), fontWeight = if (next) FontWeight.Bold else FontWeight.SemiBold,
                fontFeatureSettings = "tnum"))
    }
}

/** From the end of Suhur (or Fajr where the place has no separate Suhur) to Maghrib. Null when the day lacks either. */
internal fun fastRange(day: PrayerDay, columns: List<Prayer>): Pair<ZonedDateTime, ZonedDateTime>? {
    val start = day.times[if (Prayer.SAHAR in columns) Prayer.SAHAR else Prayer.FAJR] ?: return null
    val end = day.times[Prayer.MAGHRIB] ?: return null
    return if (end.isAfter(start)) start to end else null
}

internal fun daylight(day: PrayerDay): Duration {
    val sunrise = day.times[Prayer.SUNRISE]
    val maghrib = day.times[Prayer.MAGHRIB]
    if (sunrise == null || maghrib == null) return Duration.ZERO
    return Duration.between(sunrise, maghrib)
}

/** The daylight of [day] against [other], in whole minutes, rounded (a 3 min 40 s gain reads "+4 мин"). */
internal fun daylightDelta(day: PrayerDay, other: PrayerDay): Long =
    ((daylight(day).seconds - daylight(other).seconds) / 60.0).roundToLong()

