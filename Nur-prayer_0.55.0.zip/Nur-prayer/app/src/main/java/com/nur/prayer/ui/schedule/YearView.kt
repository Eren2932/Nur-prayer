package com.nur.prayer.ui.schedule

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.HijriMonthSpan
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate

/** One useful destination per tile. A month with several articles opens its index, not an arbitrary first article. */
internal fun HijriMonthSpan.description(): SheetTopic? = when {
    events.size > 1 -> SheetTopic.Month(this)
    events.size == 1 -> SheetTopic.Day(events.single())
    IslamicDays.isSacredMonth(month) -> SheetTopic.Sacred
    else -> null
}

@Composable
internal fun YearView(hijriYear: Int, today: LocalDate, hijriOffset: Int, bottomInset: Dp,
                      onOpen: (SheetTopic) -> Unit, modifier: Modifier = Modifier) {
    val months = remember(hijriYear, hijriOffset) { IslamicDays.months(hijriYear, hijriOffset) }
    val current = remember(months, today) { months.indexOfFirst { it.contains(today) } }
    val upcoming = remember(today, hijriOffset, current) {
        if (current < 0) null else IslamicDays.between(today, today.plusDays(400), hijriOffset)
            .firstOrNull { it.kind != DayKind.SEASON && !it.start.isBefore(today) }
    }
    BoxWithConstraints(modifier.fillMaxSize().padding(bottom = bottomInset).monthVerticalGuard()) {
        val pad = maxWidth * .031f
        val minTile = 139.dp * maxOf(1f, LocalDensity.current.fontScale, uiScale().systemFontScale)
        val cols = if (maxWidth - pad * 2 - 8.dp >= minTile * 2) 2 else 1
        val rows = remember(months, cols) { months.chunked(cols) }
        // Keep the current row visible without a delayed scroll jump on first draw.
        val list = rememberLazyListState(initialFirstVisibleItemIndex = if (current >= 0) current / cols + 1 else 0)
        LazyColumn(state = list, modifier = Modifier.fillMaxSize().testTag("year-view"),
            contentPadding = PaddingValues(horizontal = pad, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item(key = "shortcuts") {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    YearShortcut(IslamicDayText.sacredTitle()) { onOpen(SheetTopic.Sacred) }
                    if (upcoming != null) YearShortcut(IslamicDayText.tile(upcoming.day) + " · " + Format.dayMonth(upcoming.start)) {
                        onOpen(SheetTopic.Day(upcoming))
                    }
                }
            }
            items(rows, key = { it.first().month }) { row ->
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { m -> MonthTile(m, today, onOpen, Modifier.weight(1f).fillMaxHeight()) }
                }
            }
        }
    }
}

@Composable
private fun YearShortcut(label: String, onOpen: () -> Unit) {
    val ui = uiScale()
    Box(Modifier.heightIn(min = 48.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onOpen),
        contentAlignment = Alignment.Center) {
        Text(label, color = Paper.Accent, style = TextStyle(fontWeight = FontWeight.Medium, fontSize = ui.t(13f)),
            modifier = Modifier.border(1.dp, Paper.Line, CircleShape).padding(horizontal = 12.dp, vertical = 6.dp))
    }
}

@Composable
private fun MonthTile(m: HijriMonthSpan, today: LocalDate, onOpen: (SheetTopic) -> Unit, modifier: Modifier) {
    val ui = uiScale()
    val target = remember(m) { m.description() }
    val active = m.contains(today)
    val shape = RoundedCornerShape(13.dp)
    Column(modifier.clip(shape).background(if (active) Paper.Friday else Paper.Card)
        .border(if (active) 1.5.dp else 1.dp, if (active) Paper.Accent else Paper.Line, shape)
        .testTag("hijri-month-${m.month}")
        .then(if (target == null) Modifier else Modifier.clickable(role = Role.Button) { onOpen(target) })
        .padding(horizontal = 10.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(verticalAlignment = Alignment.Top) {
            Text(m.month.toString().padStart(2, '0'), color = Paper.Accent,
                style = TextStyle(fontSize = ui.t(12f), lineHeight = ui.t(18f), fontWeight = FontWeight.SemiBold))
            Spacer(Modifier.width(6.dp))
            Text(HijriCalendar.monthName(m.month).replaceFirstChar { it.uppercase(L10n.language.locale) }, color = Paper.Ink,
                style = TextStyle(fontSize = ui.t(15f), lineHeight = ui.t(18f), fontWeight = FontWeight.SemiBold))
        }
        Text("${Format.dayMonth(m.start)} — ${Format.dayMonth(m.end)}", color = Paper.Ink2,
            style = TextStyle(fontSize = ui.t(12f), lineHeight = ui.t(15f)))
        if (active) {
            val total = m.end.toEpochDay() - m.start.toEpochDay() + 1
            Text(tr("День {0} из {1}", today.toEpochDay() - m.start.toEpochDay() + 1, total), color = Paper.Accent,
                style = TextStyle(fontSize = ui.t(12f), lineHeight = ui.t(15f), fontWeight = FontWeight.Medium))
            Box(Modifier.fillMaxWidth().height(3.dp).clip(CircleShape).background(Paper.Line)) {
                Box(Modifier.fillMaxWidth(m.progress(today)).fillMaxHeight().background(Paper.Accent))
            }
        }
        if (m.events.isNotEmpty()) {
            val first = m.events.first()
            val remaining = m.events.size - 1
            Text(IslamicDayText.tile(first.day) + if (remaining == 0) "" else "  +$remaining", color = Paper.tone(first.kind),
                style = TextStyle(fontSize = ui.t(12f), lineHeight = ui.t(15f), fontWeight = FontWeight.Medium))
        } else if (target == SheetTopic.Sacred) Text(IslamicDayText.sacredTitle(), color = Paper.Accent,
            style = TextStyle(fontSize = ui.t(12f), lineHeight = ui.t(15f), fontWeight = FontWeight.Medium))
    }
}
