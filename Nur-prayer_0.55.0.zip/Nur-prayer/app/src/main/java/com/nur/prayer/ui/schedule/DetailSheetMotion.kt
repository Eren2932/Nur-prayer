package com.nur.prayer.ui.schedule

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.unit.Velocity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import com.nur.prayer.ui.schedule.motion.ReadingMetrics
import kotlin.math.abs
import kotlin.math.roundToInt

/** One displacement for entrance, touch, snap-back and exit. Direct drags never launch a frame job. */
internal class DetailSheetMotion(private val scope: CoroutineScope, initialHeight: Float,
                                 private val oneDp: Float, private val dismissed: () -> Unit) : NestedScrollConnection {
    var heightPx: Float = initialHeight
        private set
    fun measured(height: Int) { heightPx = height.coerceAtLeast(1).toFloat() }

    var fraction by mutableFloatStateOf(1f)
        private set
    private var job: Job? = null
    private var closing = false
    private var dragging = false

    fun open() = settle(false)
    fun close() = settle(true)
    fun stop() { job?.cancel() }

    private fun settle(hide: Boolean) {
        if (closing) return
        closing = hide
        dragging = false
        job?.cancel()
        val target = if (hide) 1f else 0f
        val ms = ((if (hide) 155 else 190) * abs(target - fraction)).roundToInt().coerceAtLeast(65)
        job = scope.launch {
            animate(initialValue = fraction, targetValue = target, animationSpec = tween(ms, easing = FastOutSlowInEasing)) { value, _ -> fraction = value }
            if (hide) dismissed()
        }
    }

    fun pull(delta: Float): Float {
        if (closing || delta == 0f) return 0f
        val old = fraction
        val next = (old + delta / heightPx).coerceIn(0f, 1f)
        if (old == next) return 0f
        job?.cancel()
        dragging = true
        fraction = next
        return (next - old) * heightPx
    }

    fun release(velocity: Float) {
        if (!dragging || closing) return
        val travel = fraction * heightPx
        settle(ReadingMetrics.dismiss(travel, heightPx, oneDp, velocity))
    }

    // Reversing a pull restores the sheet first; otherwise the text scroll consumes as usual.
    override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset =
        if (source == NestedScrollSource.UserInput && dragging && available.y < 0f) Offset(0f, pull(available.y)) else Offset.Zero

    // Only real finger deltas which the article couldn't consume at its start can pull the sheet.
    override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset =
        if (source == NestedScrollSource.UserInput && available.y > 0f) Offset(0f, pull(available.y)) else Offset.Zero

    override suspend fun onPreFling(available: Velocity): Velocity {
        if (!dragging) return Velocity.Zero
        val displaced = fraction > 0f
        release(available.y)
        return if (displaced) Velocity(0f, available.y) else Velocity.Zero
    }
}
