package com.nur.prayer.ui.schedule

import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.nur.prayer.data.HijriMonthSpan
import com.nur.prayer.i18n.L10n
import com.nur.prayer.ui.components.DockGlyphButton
import com.nur.prayer.ui.components.GlyphKind
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.theme.ArabicFont
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate

/** Only real catalogue entries are navigable; a month index never invents an article. */
sealed interface SheetTopic {
    data class Month(val span: HijriMonthSpan) : SheetTopic
    data class Day(val occurrence: DayOccurrence) : SheetTopic
    data object Sacred : SheetTopic
}

@Composable
internal fun DaySheet(topic: SheetTopic?, today: LocalDate, hijriOffset: Int, onDismiss: () -> Unit) {
    if (topic == null) return
    val latestDismiss by rememberUpdatedState(onDismiss)
    val scope = rememberCoroutineScope()
    var article by remember(topic) { mutableStateOf<SheetTopic?>(null) }
    val shown = article ?: topic
    // Back returns from an article to its month's index. The cross, scrim and pull always close the sheet.
    var closeRequested by remember(topic) { mutableStateOf(false) }
    Dialog(onDismissRequest = { if (article != null) article = null else closeRequested = true },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            val density = LocalDensity.current
            val height = (maxHeight - WindowInsets.safeDrawing.asPaddingValues().calculateTopPadding()).coerceAtLeast(1.dp) * .90f
            val px = with(density) { height.toPx().coerceAtLeast(1f) }
            val motion = remember(topic, px, density.density) { DetailSheetMotion(scope, px, density.density) { latestDismiss() } }
            DisposableEffect(motion) {
                motion.open()
                onDispose { motion.stop() }
            }
            LaunchedEffect(motion, closeRequested) { if (closeRequested) motion.close() }
            // The platform dialog supplies the scrim and focus trap. Do not draw a second scrim over it.
            Box(Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null,
                onClickLabel = tr("Закрыть"), onClick = motion::close))
            Column(Modifier.fillMaxWidth().heightIn(max = height).onSizeChanged { motion.measured(it.height) }
                .graphicsLayer { translationY = motion.fraction * size.height }
                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)).background(Paper.Sheet)
                .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom))
                .testTag("day-sheet")) {
                Box(Modifier.fillMaxWidth().height(48.dp)
                    .draggable(rememberDraggableState { motion.pull(it) }, Orientation.Vertical,
                        onDragStopped = { velocity -> motion.release(velocity) })) {
                    Box(Modifier.align(Alignment.Center).size(38.dp, 4.dp).background(Paper.Edge, CircleShape))
                    if (article != null) DockGlyphButton(GlyphKind.BACK, tr("Назад"), Paper.Ink, { article = null }, Modifier.align(Alignment.CenterStart))
                    DockGlyphButton(GlyphKind.CLOSE, tr("Закрыть"), Paper.Ink, motion::close, Modifier.align(Alignment.CenterEnd))
                }
                key(shown) {
                    val scroll = rememberScrollState()
                    Column(Modifier.weight(1f, fill = false).fillMaxWidth().testTag("article-scroll").nestedScroll(motion).verticalScroll(scroll)
                        .padding(horizontal = uiScale().s(18f)).padding(bottom = 16.dp)) {
                        when (shown) {
                            is SheetTopic.Day -> DayContent(shown.occurrence, today, hijriOffset, Paper.tone(shown.occurrence.kind))
                            SheetTopic.Sacred -> SacredContent()
                            is SheetTopic.Month -> MonthContents(shown.span) { article = it }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MonthContents(m: HijriMonthSpan, onOpen: (SheetTopic) -> Unit) {
    val ui = uiScale()
    BlockTitle(HijriCalendar.monthName(m.month).replaceFirstChar { it.uppercase(L10n.language.locale) })
    Text("${Format.dayMonth(m.start)} — ${Format.dayMonth(m.end)}", color = Paper.Ink2, fontSize = ui.t(14f))
    Spacer(Modifier.height(8.dp))
    for (o in m.events) {
        Column(Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("event-${o.day.name}")
            .clickable(role = Role.Button) { onOpen(SheetTopic.Day(o)) }.padding(vertical = 6.dp), verticalArrangement = Arrangement.Center) {
            Text(IslamicDayText.title(o.day), color = Paper.Ink, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
            Text(DayWhen.span(o), color = Paper.Ink2, fontSize = ui.t(13f))
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Paper.Line))
    }
    if (IslamicDays.isSacredMonth(m.month)) Text(IslamicDayText.sacredTitle(), color = Paper.Accent,
        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable(role = Role.Button) { onOpen(SheetTopic.Sacred) }.padding(vertical = 10.dp))
}

/** A small heading of a block of the sheet: bold, in the ink, not a grey capital line. */
@Composable
private fun BlockTitle(text: String, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Text(text, color = Paper.Ink, fontSize = ui.t(18f), fontWeight = FontWeight.Bold, modifier = modifier.semantics { heading() })
}

@Composable
private fun DayContent(o: DayOccurrence, today: LocalDate, hijriOffset: Int, tone: Color) {
    val ui = uiScale()
    Text(
        IslamicDayText.title(o.day), color = Paper.Ink, fontSize = ui.t(26f), fontWeight = FontWeight.Bold,
        lineHeight = ui.t(31f), modifier = Modifier.padding(top = 8.dp).semantics { heading() }
    )
    Text(
        IslamicDayText.arabic(o.day), color = tone, fontSize = ui.t(24f),
        fontFamily = ArabicFont.family, style = TextStyle(textDirection = TextDirection.Rtl), modifier = Modifier.padding(top = 4.dp)
    )
    Spacer(Modifier.height(16.dp))
    DateCard(o, today, hijriOffset, tone)
    Spacer(Modifier.height(18.dp))
    IslamicDayText.paragraphs(o.day).forEach { p ->
        Text(p, color = Paper.Ink, fontSize = ui.t(16f), lineHeight = ui.t(23f), fontWeight = FontWeight.Normal, modifier = Modifier.padding(bottom = 12.dp))
    }
    val deeds = IslamicDayText.deeds(o.day)
    if (deeds.isNotEmpty()) {
        BlockTitle(tr("Что делать"), Modifier.padding(top = 10.dp, bottom = 6.dp))
        deeds.forEach { d ->
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(tone))
                Spacer(Modifier.width(14.dp))
                Text(d, color = Paper.Ink2, fontSize = ui.t(16f), lineHeight = ui.t(23f))
            }
        }
    }
    BlockTitle(tr("Источники"), Modifier.padding(top = 20.dp, bottom = 6.dp))
    Text(IslamicDayText.sources(o.day).joinToString(" · "), color = Paper.Ink2, fontSize = ui.t(13f), lineHeight = ui.t(19f))
    Text(
        IslamicDayText.datesNote(hijriOffset), color = Paper.Ink2, fontSize = ui.t(12f), lineHeight = ui.t(18f),
        modifier = Modifier.padding(top = 14.dp)
    )
}

/** Show the date once; for a night keep the previous evening explicitly. */
@Composable
private fun DateCard(o: DayOccurrence, today: LocalDate, hijriOffset: Int, text: Color) {
    val ui = uiScale()
    Column(
        Modifier.fillMaxWidth().background(Paper.SeasonWash, RoundedCornerShape(12.dp)).padding(12.dp)
    ) {
            Text(DayWhen.span(o), color = Paper.Ink, fontSize = ui.t(16f), fontWeight = FontWeight.Bold)
            Text(
                HijriCalendar.format(o.start, hijriOffset), color = Paper.Ink2, fontSize = ui.t(13.5f),
                modifier = Modifier.padding(top = 2.dp)
            )
            Text(DayWhen.countdown(o, today), color = text, fontSize = ui.t(14f), fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun SacredContent() {
    val tone = Paper.Accent
    val ui = uiScale()
    Text(
        IslamicDayText.sacredTitle(), color = Paper.Ink, fontSize = ui.t(26f), fontWeight = FontWeight.Bold,
        lineHeight = ui.t(31f), modifier = Modifier.padding(top = 8.dp).semantics { heading() }
    )
    Text(
        "الأَشْهُر الحُرُم", color = tone, fontSize = ui.t(24f),
        fontFamily = ArabicFont.family, style = TextStyle(textDirection = TextDirection.Rtl), modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
    )
    // Two columns rather than four narrow pills; Arabic and translated names may wrap.
    for (pair in listOf(1 to 7, 11 to 12)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (m in listOf(pair.first, pair.second)) {
                Column(Modifier.weight(1f).background(Paper.Friday, RoundedCornerShape(10.dp)).padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(IslamicDays.arabicMonth(m), color = tone, fontSize = ui.t(16f), fontFamily = ArabicFont.family, textAlign = TextAlign.Center)
                    Text(HijriCalendar.monthName(m), color = Paper.Ink, fontSize = ui.t(13f), textAlign = TextAlign.Center)
                }
            }
        }
    }
    Spacer(Modifier.height(18.dp))
    IslamicDayText.sacredParagraphs().forEach { p ->
        Text(p, color = Paper.Ink, fontSize = ui.t(16f), lineHeight = ui.t(23f), fontWeight = FontWeight.Normal, modifier = Modifier.padding(bottom = 12.dp))
    }
}

/** Sentences about "when", shared by the sheet, the month list and the home chip. */
object DayWhen {
    /** "10 февраля — 11 марта · 30 дн.", "ночь на 6 марта", "25 июня, четверг". */
    fun span(o: DayOccurrence): String = when {
        o.kind == DayKind.NIGHT -> tr("Ночь на {0} — после магриба {1}", Format.dayMonth(o.start), Format.dayMonth(o.start.minusDays(1)))
        o.days > 1 -> tr("{0} — {1} · {2} дн.", Format.dayMonth(o.start), Format.dayMonth(o.end), o.days)
        else -> "${Format.dayMonth(o.start)}, ${Format.weekday(o.start)}"
    }

    fun countdown(o: DayOccurrence, today: LocalDate): String {
        val until = IslamicDays.daysBetween(today, o.start)
        return when {
            o.contains(today) && o.days > 1 -> tr("Идёт: день {0} из {1}", IslamicDays.daysBetween(o.start, today) + 1, o.days)
            o.contains(today) -> tr("Сегодня")
            o.kind == DayKind.NIGHT && until == 1L -> tr("Сегодня вечером")
            until == 1L -> tr("Завтра")
            until > 1 -> tr("Через {0} дн.", until)
            else -> tr("Прошло: {0} дн. назад", -IslamicDays.daysBetween(today, o.end))
        }
    }
}
