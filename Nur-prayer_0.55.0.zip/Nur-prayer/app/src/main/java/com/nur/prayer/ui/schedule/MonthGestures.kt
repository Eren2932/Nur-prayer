package com.nur.prayer.ui.schedule

import com.nur.prayer.ui.schedule.motion.MonthMotion

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput

/** The child scroll column gets Main first, then this node, then HorizontalPager. At an edge or on
 * a short month there may be no vertical scroll delta to consume. Don't let its sideways tail turn
 * the page. Never consume a down, a tap, a horizontal drag, or a second pointer's input. */
internal fun Modifier.monthVerticalGuard(): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        var vertical = false
        do {
            val changes = awaitPointerEvent(PointerEventPass.Main).changes
            val p = changes.singleOrNull() ?: break
            if (p.id != down.id || !p.pressed) break
            if (!vertical) {
                val d = p.position - down.position
                when (MonthMotion.firstAxis(d.x, d.y, viewConfiguration.touchSlop)) {
                    MonthMotion.WAIT -> continue
                    MonthMotion.HORIZONTAL -> break
                    else -> vertical = true
                }
            }
            if (!p.isConsumed && p.position != p.previousPosition) p.consume()
        } while (true)
    }
}

/** The fixed dock is not a scroll container. Let clickable own keyboard/TalkBack, but a drag that
 * starts and ends inside the wide label still isn't a tap. Initial runs before clickable sees it. */
internal fun Modifier.shareTapGuard(): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        var cancelled = false
        do {
            val changes = awaitPointerEvent(PointerEventPass.Initial).changes
            val p = changes.firstOrNull { it.id == down.id } ?: break
            if (changes.size != 1 || (p.position - down.position).getDistance() > viewConfiguration.touchSlop) cancelled = true
            if (cancelled) p.consume()
        } while (p.pressed)
    }
}
