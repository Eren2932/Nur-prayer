package com.nur.prayer.ui.schedule

import com.nur.prayer.ui.schedule.motion.ReadingMetrics
import com.nur.prayer.ui.schedule.motion.MonthMotion

import com.nur.prayer.ui.components.pageContentInsets
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.background
import com.nur.prayer.i18n.L10n
import com.nur.prayer.core.astro.CalculationMethod
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.systemBarsIgnoringVisibility
import androidx.compose.foundation.layout.union
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.daily.StoryBars
import com.nur.prayer.ui.Format
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.layout.SubcomposeLayout
import androidx.compose.ui.unit.Constraints
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.ExitDock
import com.nur.prayer.ui.components.ExitButtonSpec
import com.nur.prayer.ui.components.rememberSystemBack
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.home.HomeTimeline
import com.nur.prayer.ui.theme.SystemBarsTone
import com.nur.prayer.ui.theme.findActivity
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import kotlin.math.abs

/** One settled Gregorian period drives both month views and the share action.
 * The grid and year retain their own detail UI; the table is a full-sheet reader. */
private class CalendarSend(val city: String, val offset: Int, val method: CalculationMethod, val stamp: LocalDate)

internal object CalendarTabs {
    const val YEAR = 0
    const val MONTH = 1
    const val TABLE = 2
}

/**
 * The timetables of the months the pager has seen. A page asks for its month, the cache computes it once off the
 * main thread and keeps only the months near the one just added: swiping through ten years must not keep ten years.
 */
@Stable
internal class MonthTimesCache(private val compute: suspend (YearMonth) -> MonthTimes?) {
    private val months = mutableStateMapOf<YearMonth, MonthTimes?>()
    fun failed(month: YearMonth): Boolean = months.containsKey(month) && months[month] == null
    private val gate = Mutex()

    operator fun get(month: YearMonth): MonthTimes? = months[month]

    suspend fun ensure(month: YearMonth) {
        gate.withLock {
            if (months[month] != null) return
            val times = compute(month)
            months[month] = times
            if (months.size > KEEP) {
                months.keys.filter { abs(ChronoUnit.MONTHS.between(it, month)) > NEAR }.forEach { months.remove(it) }
            }
        }
    }

    private companion object {
        const val KEEP = 7
        const val NEAR = 3L
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScheduleScreen(
    data: PrayerData,
    modifier: Modifier = Modifier,
    onModalChange: (Boolean) -> Unit = {}
) {
    val today = data.today.date
    val hijriOffset = data.settings.hijriOffset

    var tab by rememberSaveable { mutableIntStateOf(CalendarTabs.MONTH) }
    var monthText by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(YearMonth.from(today).toString()) }
    var selectedEpoch by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(today.toEpochDay()) }
    var hijriYear by rememberSaveable(today.toEpochDay(), hijriOffset) { mutableIntStateOf(IslamicDays.hijriOf(today, hijriOffset).year) }
    var picker by rememberSaveable { mutableStateOf(false) }
    // A DayOccurrence is not Parcelable: the sheet is closed after a rotation, which is the honest state.
    var topic by remember { mutableStateOf<SheetTopic?>(null) }
    val tableTab = tab == CalendarTabs.TABLE
    var focus by rememberSaveable(tab) { mutableStateOf(false) }
    val reading = tableTab && focus
    val toggleFocus: () -> Unit = remember(tab) { { focus = !focus } }
    StoryBars(reading)
    BackHandler(enabled = reading) { focus = false }
    val month = remember(monthText) { YearMonth.parse(monthText) }
    val selectedDate = remember(selectedEpoch) { LocalDate.ofEpochDay(selectedEpoch) }
    fun goMonth(target: YearMonth) {
        if (target == month) return
        monthText = target.toString()
        selectedEpoch = CalendarMonthModel.moveSelection(selectedDate, target).toEpochDay()
    }

    // The opaque paper extends behind the system bars on all three tabs.
    val view = LocalView.current
    val barsOwner = remember { Any() }
    DisposableEffect(view) {
        val window = view.context.findActivity()?.window
        SystemBarsTone.hold(window, barsOwner)
        onDispose { SystemBarsTone.release(window, barsOwner) }
    }

    // The timetables: a table page shows its month, the share button sends the one in front. 31 solar days are cheap.
    val columns = remember(data.fajrEqualsDawn) { HomeTimeline.prayers(data.fajrEqualsDawn) }
    val timesCache = remember(data.place, data.params, columns) {
        MonthTimesCache { m ->
            try {
                withContext(Dispatchers.Default) {
                    MonthTimes(m, PrayerEngine.days(m.atDay(1), m.lengthOfMonth(), data.place.coordinates, data.place.zone, data.params), columns)
                }
            } catch (cancel: CancellationException) { throw cancel } catch (_: Exception) { null }
        }
    }
    LaunchedEffect(month, timesCache) { timesCache.ensure(month) }
    val language = L10n.language
    var pendingSend by remember(timesCache, tab, hijriOffset, today, language) {
        mutableStateOf<CalendarSend?>(null)
    }
    BackHandler(enabled = pendingSend != null) { pendingSend = null }
    if (picker || topic != null || reading) DisposableEffect(onModalChange) {
        onModalChange(true)
        onDispose { onModalChange(false) }
    }

    // The pages. The state above stays the one truth; each pager reports a settled page and follows a changed period.
    val yearTab = tab == CalendarTabs.YEAR
    val gregorian = remember(today) { PeriodRange.gregorianYears(today) }
    val firstMonth = YearMonth.of(gregorian.first, 1)
    val monthCount = PeriodPages.monthCount(firstMonth, YearMonth.of(gregorian.last, 12))
    val hijriYears = remember(today, hijriOffset) { PeriodRange.hijriYears(today, hijriOffset) }
    val yearCount = hijriYears.last - hijriYears.first + 1
    val monthPager = rememberPeriodPager(PeriodPages.monthPage(firstMonth, month, monthCount), monthCount) { page ->
        goMonth(PeriodPages.monthAt(firstMonth, page))
    }
    val yearPager = rememberPeriodPager(PeriodPages.yearPage(hijriYears.first, hijriYear, yearCount), yearCount) { page ->
        hijriYear = hijriYears.first + page
    }
    // The grid views are Месяц and Таблица. Going to Год keeps the one that was in front, so the page that is
    // leaving does not swap its view while it fades out.
    val lastGrid = remember { IntArray(1) { CalendarTabs.MONTH } }
    if (tab != CalendarTabs.YEAR) lastGrid[0] = tab
    val gridTab = lastGrid[0]
    // The cards end above the system bar with a normal margin: the capsule is not there to be run behind.
    val cutout = WindowInsets.displayCutout
    val safe = WindowInsets.systemBarsIgnoringVisibility.union(cutout)
    val stable = safe.asPaddingValues()
    val cut = cutout.asPaddingValues()
    val bottom = if (tableTab) stable.calculateBottomPadding() else WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val bottomInset = ExitButtonSpec.contentFloor(bottom)
    val normalTop = stable.calculateTopPadding() - cut.calculateTopPadding() + LocalIslandInset.current + ExitButtonSpec.Hit
    val normalBottom = (bottomInset - cut.calculateBottomPadding()).coerceAtLeast(0.dp)
    val progress = rememberPaperFocus(reading)
    val back = rememberSystemBack()

    val tint = Paper.Ink
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val failed = tr("Не удалось подготовить картинку")
    var chooserOpen by rememberSaveable { mutableStateOf(false) }
    val chooser = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { chooserOpen = false }
    val request = pendingSend
    LaunchedEffect(request, picker, topic, reading) {
        if (request == null) return@LaunchedEffect
        try {
            if (picker || topic != null || reading) return@LaunchedEffect
            // Only an actual tap subscribes to motion. Wait for the pager AND selection to agree
            // (including a picker jump); a cancelled swipe exports the original month.
            val target = snapshotFlow {
                if (monthPager.isScrollInProgress) null else PeriodPages.monthAt(firstMonth, monthPager.settledPage)
                    .takeIf { it.toString() == monthText }
            }.filterNotNull().first()
            timesCache.ensure(target)
            val times = checkNotNull(timesCache[target])

            val page = withContext(Dispatchers.Default) {
                calendarPage(times, request.offset, request.city, request.method, request.stamp)
            }
            val image = CalendarImageShare.prepare(context, page)
            if (owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
                chooserOpen = true
                chooser.launch(CalendarImageShare.chooser(context, image))
            }
        } catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { chooserOpen = false; Toast.makeText(context, failed, Toast.LENGTH_SHORT).show() }
        finally { if (pendingSend === request) pendingSend = null }
    }
    val focusLabel = if (reading) tr("Показать управление") else tr("Скрыть управление")
    val tap = tableTab && !picker && topic == null && pendingSend == null
    Box(modifier.fillMaxSize().background(Paper.Sheet)
        .then(if (tap) Modifier.calendarPaperTap(toggleFocus) else Modifier)) {
        // Fixed viewport: transient OS insets never resize the pager. Overlay rails own no layout space.
        Column(Modifier.fillMaxSize().then(if (tableTab) Modifier
            .windowInsetsPadding(safe.only(WindowInsetsSides.Horizontal))
            .windowInsetsPadding(cutout.only(WindowInsetsSides.Vertical)) else Modifier.pageContentInsets())) {
            if (!tableTab) CalendarTopBar(tab, { tab = it }, tint)
            AnimatedContent(
                targetState = yearTab,
                transitionSpec = {
                    val forward = !targetState
                    (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { w -> if (forward) w / 6 else -w / 6 } +
                        fadeIn(tween(260, delayMillis = 40))) togetherWith
                        (slideOutHorizontally(tween(240)) { w -> if (forward) -w / 8 else w / 8 } + fadeOut(tween(160)))
                },
                label = "calendarTab",
                modifier = Modifier.weight(1f).fillMaxSize()
            ) { year ->
                if (year) PeriodPager(yearPager, Modifier.testTag("year-pager"), motion = PageMotion.STRIP) { page ->
                    Column {
                        val yearNumber = hijriYears.first + page
                        PageCaption(tr("{0} год хиджры", yearNumber), remember(yearNumber, hijriOffset, language) { yearSpan(yearNumber, hijriOffset) })
                        YearView(
                            yearNumber, today, hijriOffset, bottomInset = bottomInset, onOpen = { topic = it }
                        )
                    }
                } else MonthStrip(monthPager, gridTab == CalendarTabs.TABLE, bottomInset) { page, edge ->
                    val pageMonth = PeriodPages.monthAt(firstMonth, page)
                    // A neighbour page shows the day that will be selected when the page arrives, so the leaf is
                    // whole while it turns, and landing on it changes nothing under the thumb.
                    val pageSelected = if (pageMonth == month) selectedDate else CalendarMonthModel.moveSelection(selectedDate, pageMonth)
                    AnimatedContent(
                        targetState = gridTab,
                        transitionSpec = {
                            val forward = targetState > initialState
                            (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { w -> if (forward) w / 6 else -w / 6 } +
                                fadeIn(tween(260, delayMillis = 40))) togetherWith
                                (slideOutHorizontally(tween(240)) { w -> if (forward) -w / 8 else w / 8 } + fadeOut(tween(160)))
                        },
                        label = "calendarView",
                        modifier = Modifier.fillMaxSize()
                    ) { gridView ->
                        if (gridView == CalendarTabs.TABLE) TablePage(
                            pageMonth, timesCache, today, hijriOffset, data.place.label, data.params.method,
                            normalTop = normalTop, normalBottom = normalBottom, progress = progress, edge = edge, reading = reading,
                            focusLabel = focusLabel, onToggle = toggleFocus
                        ) else MonthPage(
                            data, timesCache, pageMonth, pageSelected, columns,
                            onSelect = {
                                if (!monthPager.isScrollInProgress && monthPager.settledPage == page && pageMonth == month)
                                    selectedEpoch = it.toEpochDay()
                            },
                            onOpen = { topic = it }
                        )
                    }
                }
            }
        }
        if (tableTab) AnimatedVisibility(!reading, modifier = Modifier.align(Alignment.TopCenter), enter = fadeIn(tween(110)), exit = fadeOut(tween(90))) {
            CalendarTopBar(tab, { if (!reading) tab = it }, tint,
                Modifier.windowInsetsPadding(safe.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal)))
        }
        PeriodPicker(
            visible = picker,
            mode = if (yearTab) PickerMode.HIJRI_YEAR else PickerMode.MONTH,
            month = month, hijriYear = hijriYear, today = today, hijriOffset = hijriOffset,
            onMonth = { goMonth(it) }, onHijriYear = { hijriYear = it },
            onToday = {
                if (yearTab) hijriYear = IslamicDays.hijriOf(today, hijriOffset).year
                else { monthText = YearMonth.from(today).toString(); selectedEpoch = today.toEpochDay() }
            }, onDismiss = { picker = false }
        )
        DaySheet(topic, today, hijriOffset, onDismiss = { topic = null })
        // A dialog owns its own focus and close control; no duplicate dock over the article.
        val modal = picker || topic != null
        AnimatedVisibility(!reading && !modal, modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(110)), exit = fadeOut(tween(90))) {
            ExitDock(onClose = { if (!reading) back() },
            bottom = bottom, modifier = if (tableTab) Modifier.windowInsetsPadding(safe.only(WindowInsetsSides.Horizontal)) else Modifier.pageContentInsets(),
            description = tr("Назад"),
            tint = tint,
            onMenu = { if (!reading && !modal) picker = true },
            menuDescription = tr("Выбрать период"),
            centerAction = if (!yearTab && !modal) ({
                CalendarShareButton(tint, !reading && !chooserOpen && request == null) {
                    if (!reading && !chooserOpen && pendingSend == null) {
                        pendingSend = CalendarSend(data.place.label, hijriOffset, data.params.method, LocalDate.now(data.place.zone))
                    }
                }
            }) else null)
        }
    }
}

/** "16 июня 2026 — 4 июня 2027": the Gregorian bounds of a hijri year. */
private fun yearSpan(year: Int, offset: Int): String {
    val first = IslamicDays.monthRange(year, 1, offset)?.first
    val last = IslamicDays.monthRange(year, 12, offset)?.second
    return if (first != null && last != null) "${Format.dayMonth(first)} ${first.year} — ${Format.dayMonth(last)} ${last.year}" else ""
}

/** One stationary gutter at each side of the viewport. Content has no repeated page margin. */
@Composable
internal fun MonthStrip(pager: PagerState, paper: Boolean, floor: Dp,
                       content: @Composable (Int, Dp) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize().then(if (paper) Modifier else Modifier.padding(bottom = floor))) {
        val panels = if (maxWidth > maxHeight * 1.22f) 2 else 1
        val edge = if (paper) minOf(maxWidth / panels, maxHeight * 1.75f) * .031f else maxWidth * .031f
        PeriodPager(pager, Modifier.fillMaxSize().padding(horizontal = edge).clipToBounds().testTag("calendar-pager"),
            motion = PageMotion.STRIP) { page ->
            if (paper) content(page, edge) else {
                // HorizontalPager makes the next-next slot as soon as a sliver of the next page enters.
                // The two immediate neighbours are already warm. Don't build another grid on that frame.
                // A visible slot always qualifies, also for an interrupted fling or a distant picker jump.
                val ready by remember(pager, page) { derivedStateOf {
                    MonthMotion.neighbour(page, pager.settledPage) ||
                        MonthMotion.visible(page, pager.currentPage, pager.currentPageOffsetFraction)
                } }
                if (ready) content(page, edge)
            }
        }
    }
}

@Composable
private fun MonthPage(data: PrayerData, cache: MonthTimesCache, month: YearMonth, selectedDate: LocalDate,
                      columns: List<Prayer>, onSelect: (LocalDate) -> Unit, onOpen: (SheetTopic) -> Unit) {
    val offset = data.settings.hijriOffset
    LaunchedEffect(month, cache) { cache.ensure(month) }
    val times = cache[month]
    val day = times?.days?.getOrNull(selectedDate.dayOfMonth - 1) ?: data.days.firstOrNull { it.date == selectedDate }
    val events = remember(selectedDate, offset) { IslamicDays.on(selectedDate, offset) }
    val next = HomeTimeline.visible(data.window.next, data.fajrEqualsDawn)
        .takeIf { data.window.nextStart.toLocalDate() == selectedDate }
    Column(Modifier.fillMaxSize().monthVerticalGuard()) {
        val span = remember(month, offset, L10n.language) { HijriCalendar.span(month.atDay(1), month.atEndOfMonth(), offset) }
        PageCaption("${Format.monthName(month.monthValue)} ${month.year}", span)
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val weeks = remember(month) { (month.atDay(1).dayOfWeek.value - 1 + month.lengthOfMonth() + 6) / 7 }
            val wide = maxWidth >= 540.dp
            val viewport = constraints.maxHeight
            // Measure the real card and weekday band (including wrapped dates/events) exactly once in
            // this pass. The natural text height may exceed the minimum: never clip the last baseline.
            SubcomposeLayout(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { parent ->
                val natural = Constraints(minWidth = parent.maxWidth, maxWidth = parent.maxWidth)
                val gap = 6.dp.roundToPx()
                val band = subcompose("weekdays") { MonthWeekdays() }.single().measure(natural)
                val card = subcompose("detail") {
                    DayCard(selectedDate, data.place.label, offset, day, !cache.failed(month), columns, next, events, wide, onOpen)
                }.single().measure(natural)
                val row = ReadingMetrics.weekRowPx(viewport, band.height, card.height, gap, weeks, density).toDp()
                val grid = subcompose("days") {
                    MonthCalendar(month, selectedDate, data.today.date, offset, onSelect = onSelect, minRow = row, showWeekdays = false)
                }.single().measure(natural)
                val cardY = band.height + grid.height + gap
                layout(parent.maxWidth, (cardY + card.height + gap).coerceAtLeast(parent.minHeight)) {
                    band.placeRelative(0, 0)
                    grid.placeRelative(0, band.height)
                    card.placeRelative(0, cardY)
                }
            }
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * Таблица: the month as a timetable
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun TablePage(
    month: YearMonth, cache: MonthTimesCache, today: LocalDate, hijriOffset: Int,
    city: String, method: CalculationMethod, normalTop: Dp, normalBottom: Dp, progress: State<Float>,
    edge: Dp, reading: Boolean, focusLabel: String, onToggle: () -> Unit
) {
    LaunchedEffect(month, cache) { cache.ensure(month) }
    val times = cache[month]
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (times == null) Text(if (cache.failed(month)) tr("Не удалось рассчитать день") else tr("Рассчитываем время…"), color = Paper.Ink)
        else {
            val page = remember(times, hijriOffset, city, method, today, L10n.language) {
                calendarPage(times, hijriOffset, city, method, today)
            }
            MonthTable(page, focusLabel, onToggle, progress, normalTop, normalBottom, edge, reading)
        }
    }
}
