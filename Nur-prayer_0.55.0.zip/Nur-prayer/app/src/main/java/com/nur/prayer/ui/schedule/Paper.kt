package com.nur.prayer.ui.schedule

import androidx.compose.ui.graphics.Color
import com.nur.prayer.ui.schedule.print.CalendarPaper
import com.nur.prayer.data.DayKind

/** Same source of truth as the PNG. No surface relies on the wallpaper underneath. */
internal object Paper {
    val Sheet = Color(CalendarPaper.PAPER)
    val Ink = Color(CalendarPaper.INK)
    val Ink2 = Color(CalendarPaper.SECONDARY)
    val Accent = Color(CalendarPaper.BLUE)
    val Line = Color(CalendarPaper.LINE)
    val Edge = Color(CalendarPaper.WEEK)
    val Friday = Color(CalendarPaper.FRIDAY)
    val Event = Color(CalendarPaper.EVENT)
    val EventWash = Color(CalendarPaper.EVENT_WASH)
    val SeasonWash = Color(CalendarPaper.SEASON_WASH)
    val Card = Sheet

    fun tone(kind: DayKind): Color = if (kind == DayKind.NIGHT) Accent else Event
}
