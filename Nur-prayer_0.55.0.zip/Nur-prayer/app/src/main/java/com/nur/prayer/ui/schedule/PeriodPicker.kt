package com.nur.prayer.ui.schedule

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.schedule.print.CalendarPaper
import java.time.LocalDate
import java.time.YearMonth

enum class PickerMode { MONTH, HIJRI_YEAR }

/** The years the picker offers around today; prayer times and Umm al-Qura are valid far beyond. */
object PeriodRange {
    const val SPAN = 10

    fun gregorianYears(today: LocalDate): IntRange = (today.year - SPAN)..(today.year + SPAN)

    fun hijriYears(today: LocalDate, offset: Int): IntRange {
        val y = IslamicDays.hijriOf(today, offset).year
        return (y - SPAN).coerceAtLeast(IslamicDays.MIN_YEAR)..(y + SPAN).coerceAtMost(IslamicDays.MAX_YEAR)
    }
}

@Composable
internal fun PeriodPicker(visible: Boolean, mode: PickerMode, month: YearMonth, hijriYear: Int,
                          today: LocalDate, hijriOffset: Int, onMonth: (YearMonth) -> Unit,
                          onHijriYear: (Int) -> Unit, onToday: () -> Unit, onDismiss: () -> Unit) {
    if (!visible) return
    val gregorian = mode == PickerMode.MONTH
    val years = if (gregorian) PeriodRange.gregorianYears(today) else PeriodRange.hijriYears(today, hijriOffset)
    var year by rememberSaveable(month, hijriYear, mode) { mutableIntStateOf((if (gregorian) month.year else hijriYear).coerceIn(years)) }
    var m by rememberSaveable(month) { mutableIntStateOf(month.monthValue) }
    var yearGrid by rememberSaveable(mode) { mutableStateOf(!gregorian) }
    val blue = Color(CalendarPaper.BLUE)
    // A platform dialog owns Back, outside touches and accessibility focus; the dock behind cannot be tapped.
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.widthIn(max = 420.dp).fillMaxWidth().heightIn(max = 600.dp)
            .clip(RoundedCornerShape(22.dp)).background(Color(CalendarPaper.PAPER))
            .border(1.dp, Color(CalendarPaper.LINE), RoundedCornerShape(22.dp))
            .padding(16.dp).testTag("period-picker"), horizontalAlignment = Alignment.CenterHorizontally) {
            key(yearGrid) {
                Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (!gregorian) tr("Год по хиджре") else if (yearGrid) tr("Год") else tr("Выберите месяц"),
                        fontSize=19.sp, fontWeight=FontWeight.Bold, color=Color(CalendarPaper.INK))
                    Spacer(Modifier.height(8.dp))
                    if (gregorian) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            PickerCell("−", Modifier.weight(1f).testTag("period-prev"), enabled=year>years.first,
                                description="${tr("Предыдущее")} · ${year-1}") { year-- }
                            PickerCell("$year", Modifier.weight(2f).testTag("period-years"), active=yearGrid) { yearGrid=!yearGrid }
                            PickerCell("+", Modifier.weight(1f).testTag("period-next"), enabled=year<years.last,
                                description="${tr("Следующее")} · ${year+1}") { year++ }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    val values = if (yearGrid) years else 1..12
                    for (row in values.toList().chunked(3)) {
                        Row(Modifier.fillMaxWidth().padding(vertical=2.dp), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                            for (v in row) {
                                PickerCell(if (yearGrid) "$v" else Format.monthName(v),
                                    Modifier.weight(1f).testTag(if (yearGrid) "period-year-$v" else "period-month-$v"),
                                    active=v == (if (yearGrid) year else m)) {
                                    if (yearGrid) { year=v; if (gregorian) yearGrid=false } else m=v
                                }
                            }
                            repeat(3-row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                    val span = if (gregorian) YearMonth.of(year,m).let { HijriCalendar.span(it.atDay(1), it.atEndOfMonth(), hijriOffset) }
                        else {
                            val a=IslamicDays.monthRange(year,1,hijriOffset)?.first
                            val b=IslamicDays.monthRange(year,12,hijriOffset)?.second
                            if (a!=null && b!=null) "${Format.dayMonth(a)} ${a.year} — ${Format.dayMonth(b)} ${b.year}" else ""
                        }
                    Text(span, Modifier.padding(vertical=10.dp), color=Color(CalendarPaper.SECONDARY), fontSize=13.sp, textAlign=TextAlign.Center)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                PickerCell(tr("Сегодня"), Modifier.weight(1f).testTag("period-today")) {
                    onToday()
                    onDismiss()
                }
                Box(Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(12.dp)).background(blue)
                    .testTag("period-done").clickable(role=Role.Button) {
                        if (gregorian) onMonth(YearMonth.of(year,m)) else onHijriYear(year)
                        onDismiss()
                    }, contentAlignment=Alignment.Center) {
                    AutoSizeText(tr("Готово"), Color.White, 15.sp, fontWeight=FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PickerCell(label: String, modifier: Modifier, active: Boolean = false, enabled: Boolean = true,
                       description: String? = null, onClick: () -> Unit) {
    val shape=RoundedCornerShape(11.dp)
    val ink=Color(if (active) CalendarPaper.BLUE else CalendarPaper.INK)
    Box(modifier.height(48.dp).clip(shape).background(Color(if (active) CalendarPaper.FRIDAY else CalendarPaper.PAPER))
        .border(1.dp,Color(if (active) CalendarPaper.BLUE else CalendarPaper.LINE),shape)
        .semantics { selected=active; if (description!=null) contentDescription=description }
        .clickable(enabled=enabled,role=Role.Button,onClick=onClick).padding(horizontal=3.dp), contentAlignment=Alignment.Center) {
        AutoSizeText(label, if (enabled) ink else Color(CalendarPaper.SECONDARY).copy(alpha=.5f), 14.sp,
            minFontSize=10.sp, fontWeight=if (active) FontWeight.Bold else FontWeight.Medium)
    }
}
