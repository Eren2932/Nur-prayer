package com.nur.prayer.ui.schedule.motion;

/** Measured pixels, never estimates of line height; gesture thresholds are in dp. */
public final class ReadingMetrics {
    private ReadingMetrics() {}
    public static float weekRowPx(int viewport, int header, int detail, int gap, int weeks, float density) {
        int available = viewport - header - detail - 2 * gap;
        return Math.max(48f * density, Math.min(60f * density, (float) Math.floor((double) available / weeks)));
    }
    public static boolean dismiss(float displacement, float height, float density, float velocity) {
        float threshold = Math.min(height * .23f, 88f * density);
        float fling = 900f * density;
        return velocity > -fling && (displacement >= threshold || displacement >= 16f * density && velocity >= fling);
    }
}
