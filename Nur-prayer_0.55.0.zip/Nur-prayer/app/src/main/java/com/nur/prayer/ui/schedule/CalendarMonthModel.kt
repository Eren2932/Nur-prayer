package com.nur.prayer.ui.schedule

import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.IslamicDays
import java.time.LocalDate
import java.time.YearMonth

/** Monday-first full weeks. Dates, not numeric indices, remain stable across month boundaries. */
object CalendarMonthModel {
    fun cells(month: YearMonth): List<LocalDate> {
        val first = month.atDay(1)
        val leading = first.dayOfWeek.value - 1
        val start = first.minusDays(leading.toLong())
        val count = ((leading + month.lengthOfMonth() + 6) / 7) * 7
        return List(count) { start.plusDays(it.toLong()) }
    }

    /** One ordered event range per month, not an Islamic calendar scan per rendered cell. */
    internal fun eventPriority(month: YearMonth, offset: Int): List<DayOccurrence> =
        IslamicDays.between(month.atDay(1), month.atEndOfMonth(), offset)
            .sortedWith(compareBy({ -it.kind.priority }, { it.day.ordinal }))

    fun moveSelection(selected: LocalDate, target: YearMonth): LocalDate =
        target.atDay(selected.dayOfMonth.coerceAtMost(target.lengthOfMonth()))
}
