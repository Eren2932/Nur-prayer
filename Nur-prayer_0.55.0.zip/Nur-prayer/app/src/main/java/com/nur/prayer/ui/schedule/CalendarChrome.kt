package com.nur.prayer.ui.schedule

import com.nur.prayer.ui.schedule.print.CalendarPaper
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import com.nur.prayer.ui.components.ExitButtonSpec
import com.nur.prayer.i18n.L10n
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material3.LocalTextStyle
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.DockGlyphButton
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.uiScale

private val GLYPHS = listOf(GlyphKind.VIEW_YEAR, GlyphKind.VIEW_MONTH, GlyphKind.VIEW_TABLE)

/** A separate rail above the page: controls can never cover a date, even with a large system font. */
@Composable
fun CalendarTopBar(tab: Int, onTab: (Int) -> Unit, tint: Color, modifier: Modifier = Modifier) {
    val labels = listOf(tr("Год"), tr("Месяц"), tr("Таблица"))
    Row(modifier.fillMaxWidth().padding(top = LocalIslandInset.current).testTag("calendar-tabs"),
        horizontalArrangement = Arrangement.Center) {
        GLYPHS.forEachIndexed { index, glyph ->
            val selected = index == tab
            DockGlyphButton(glyph, labels[index], if (selected && tint != Color.White) Color(CalendarPaper.BLUE) else tint,
                { onTab(index) }, Modifier.testTag("calendar-tab-$index"), selectedTab = selected)
        }
    }
}

/** A caption belongs to the page, not to the viewport. No animated overlay or hidden picker target. */
@Composable
internal fun PageCaption(title: String, span: String) {
    val ui = uiScale()
    val measurer = rememberTextMeasurer()
    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 5.dp)
        .testTag("calendar-period"), contentAlignment = Alignment.Center) {
        val titleStyle = LocalTextStyle.current.copy(fontSize = ui.t(24f), lineHeight = ui.t(28f), fontWeight = FontWeight.Bold)
        val subStyle = LocalTextStyle.current.copy(fontSize = ui.t(13f), lineHeight = ui.t(17f), fontWeight = FontWeight.Medium)
        val titleSize = fittedCaption(measurer, title, titleStyle, constraints.maxWidth, ui.t(16f))
        val subSize = fittedCaption(measurer, span, subStyle, constraints.maxWidth, ui.t(10f))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, Modifier.testTag("calendar-month-title"), color = Paper.Ink,
                style = titleStyle, fontSize = titleSize, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
            Text(span, Modifier.testTag("calendar-month-span"), color = Paper.Ink2,
                style = subStyle, fontSize = subSize, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Fit synchronously at the new committed label, without hiding its first frame or onTextLayout retries. */
@Composable
private fun fittedCaption(measurer: TextMeasurer, text: String, style: TextStyle, width: Int, floor: TextUnit): TextUnit =
    remember(measurer, text, style, width, floor) {
        val natural = measurer.measure(AnnotatedString(text), style, softWrap = false, maxLines = 1).size.width.coerceAtLeast(1)
        val ratio = (width.toFloat() / natural).coerceIn(floor.value / style.fontSize.value, 1f)
        style.fontSize * ratio
    }

/** "сегодня" on the selected today, "К сегодня" otherwise: one tag, one place to come back to. */
@Composable
fun CalendarTodayChip(atToday: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Text(
        text = if (atToday) tr("сегодня") else tr("К сегодня"),
        color = Paper.Accent, fontSize = ui.t(11f), fontWeight = FontWeight.SemiBold, maxLines = 1,
        modifier = modifier.clip(CircleShape).background(Paper.Accent.copy(alpha = 0.12f))
            .pressClick(role = Role.Button, onClick = onClick)
            .padding(horizontal = ui.s(11f), vertical = ui.s(5f))
            .testTag("calendar-today")
    )
}

/** Match the Stories action: 144 × 32 dp outline, in a 52 dp hit area. */
@Composable
internal fun CalendarShareButton(tint: Color, enabled: Boolean, onClick: () -> Unit) {
    val feedback = LocalHapticFeedback.current
    Box(Modifier.widthIn(max = 144.dp).fillMaxWidth().height(ExitButtonSpec.Hit).testTag("calendar-share")
        .graphicsLayer { alpha = if (enabled) 1f else .45f }
        .shareTapGuard().clickable(enabled = enabled, role = Role.Button) {
            feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        }, contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxWidth().height(ExitButtonSpec.Diameter).background(Color.Black.copy(alpha=.12f), CircleShape)
            .border(1.dp, tint.copy(alpha=.5f), CircleShape).padding(horizontal=8.dp), contentAlignment = Alignment.Center) {
            AutoSizeText(tr("Поделиться").uppercase(L10n.language.locale), color=tint, fontSize=13.sp, fontWeight=FontWeight.Bold)
        }
    }
}
