package com.nur.prayer.ui.schedule

import com.nur.prayer.ui.schedule.print.CalendarPaper
import androidx.compose.runtime.State
import androidx.compose.ui.unit.Dp
import android.graphics.drawable.Drawable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Constraints
import com.nur.prayer.R
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.i18n.trDynamic
import com.nur.prayer.ui.Format
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.roundToInt

internal class MonthTimes(val month: YearMonth, val days: List<PrayerDay>, val columns: List<Prayer>)

internal fun columnLabel(prayer: Prayer): String = when (prayer) {
    Prayer.SAHAR -> tr("Сухур")
    Prayer.FAJR -> tr("Фаджр")
    Prayer.SUNRISE -> tr("Восход")
    Prayer.DHUHR -> tr("Зухр")
    Prayer.ASR -> tr("Аср")
    Prayer.MAGHRIB -> tr("Магриб")
    Prayer.ISHA -> tr("Иша")
}

internal fun calendarPage(times: MonthTimes, offset: Int, city: String, method: CalculationMethod,
                          generated: LocalDate): CalendarPaper.Page {
    val locale = L10n.language.locale
    val labels = times.columns.map(::columnLabel)
    val methodName = when (method) {
        CalculationMethod.SPIRITUAL_BOARD_TATARSTAN -> tr("ДУМ РТ")
        CalculationMethod.RUSSIA_DUM -> tr("ДУМ РФ")
        else -> trDynamic(method.title)
    }
    val first = times.month.atDay(1)
    val last = times.month.atEndOfMonth()
    val events = IslamicDays.between(first, last, offset)
    val legend = events.map { event ->
        val a = maxOf(first, event.start).dayOfMonth
        val b = minOf(last, event.end).dayOfMonth
        val range = if (a == b) "$a" else "$a–$b"
        "$range · ${IslamicDayText.tile(event.day)}"
    }
    val rows = times.days.map { day ->
        val values = times.columns.map { p -> day.times[p]?.let(Format::time) ?: "—" }
        val hijri = HijriCalendar.dayOfMonth(day.date, offset)
        val active = events.filter { it.contains(day.date) }
        CalendarPaper.Row(day.date, Format.weekdayShort(day.date), hijri, values,
            (listOf(Format.fullDate(day.date), HijriCalendar.format(day.date, offset)) +
                active.sortedByDescending { it.kind.priority }.map { IslamicDayText.title(it.day) } +
                labels.zip(values) { name, time -> "$name $time" }).joinToString(", "),
            active.any { it.kind != DayKind.SEASON }, active.any { it.kind == DayKind.SEASON })
    }
    return CalendarPaper.Page("${Format.monthName(times.month.monthValue)} ${times.month.year}",
        HijriCalendar.span(times.month.atDay(1), times.month.atEndOfMonth(), offset), city,
        "${tr("Метод")}: $methodName", generated.toString(), tr("Дата").uppercase(locale),
        labels.map { it.uppercase(locale) }, times.columns.indexOf(Prayer.SUNRISE), rows, legend)
}

internal fun calendarLogo(context: android.content.Context): Drawable =
    requireNotNull(context.getDrawable(R.drawable.ic_notification)).mutate().apply { setTint(CalendarPaper.BLUE) }

/** Transparent, positioned row nodes keep TalkBack navigation without 250 separately measured Texts. */
@Composable
internal fun MonthTable(page: CalendarPaper.Page, focusLabel: String, onToggle: () -> Unit,
                        progress: State<Float>, normalTop: Dp, normalBottom: Dp, edge: Dp, reading: Boolean, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val logo = remember(context) { calendarLogo(context) }
    val drawing = remember(page, logo, progress, normalTop, normalBottom, edge) {
        Modifier.drawWithCache {
            val v = CalendarPaper.Window(page, size.width, size.height, normalTop.toPx(), normalBottom.toPx(), edge.roundToPx().toFloat())
            val start = PaperScene(page, v.normal, v.top)
            val end = PaperScene(page, v.full)
            onDrawBehind { start.paint(drawContext.canvas.nativeCanvas, logo, end, progress.value) }
        }
    }
    Layout(content = {
        Box(Modifier.semantics {
            contentDescription = "${page.month}, ${page.span}, ${page.city}, ${page.method}, ${page.stamp}"
            onClick(label = focusLabel) { onToggle(); true }
        })
        page.rows.forEach { row -> Box(Modifier.testTag("table-row-${row.date}").semantics { contentDescription = row.description }) }
    }, modifier = modifier.fillMaxSize().testTag("month-table").then(drawing)) { nodes, constraints ->
        val w = constraints.maxWidth
        val h = constraints.maxHeight
        val v = CalendarPaper.Window(page, w.toFloat(), h.toFloat(), normalTop.toPx(), normalBottom.toPx(), edge.roundToPx().toFloat())
        // These transparent nodes are for accessibility, not pixel drawing or touch hit-testing.
        // Measure once at the target endpoint; the animation clock is read only in onDrawBehind.
        val g = if (reading) v.full else v.normal
        val top = if (reading) 0f else v.top
        val header = nodes.first().measure(Constraints.fixed(w, g.rowsTop.roundToInt()))
        val width = g.panelWidth.roundToInt()
        val rows = nodes.drop(1).mapIndexed { i, n ->
            val y = top + g.rowTop(i)
            n.measure(Constraints.fixed(width, (y + g.rowHeight).roundToInt() - y.roundToInt()))
        }
        layout(w, h) {
            header.place(0, top.roundToInt())
            rows.forEachIndexed { i, p -> p.place(g.rowLeft(i).roundToInt(), (top + g.rowTop(i)).roundToInt()) }
        }
    }
}
