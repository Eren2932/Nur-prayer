package com.nur.prayer.ui.schedule

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import com.nur.prayer.ui.schedule.print.CalendarPaper
import kotlin.math.min
import kotlin.math.roundToInt

internal fun mixPaper(a: Float, b: Float, f: Float): Float = a + (b - a) * f

/** Compile the painter's instructions once for each endpoint. Frames interpolate already-fitted
 * baselines and sizes, not pixels. No stretched glyphs, font measurements or bitmaps on tap. */
internal class PaperScene(page: CalendarPaper.Page, grid: CalendarPaper.Grid, private val top: Float = 0f) : CalendarPaper.Ink {
    private class Op(val kind: Int, val a: Float, val b: Float, val c: Float, val d: Float = 0f,
                     val radius: Float = 0f, val color: Int = 0, val s: String = "", val bold: Boolean = false,
                     val align: Paint.Align = Paint.Align.LEFT)
    private val ops = ArrayList<Op>(400)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply { fontFeatureSettings = "tnum" }
    init { CalendarPaper.draw(page, grid, this) }
    override fun box(l: Float, t: Float, r: Float, b: Float, radius: Float, color: Int) {
        ops.add(Op(0, l, top+t, r, top+b, radius, color))
    }
    override fun text(s: String, l: Float, r: Float, cy: Float, size: Float, maxHeight: Float,
                      color: Int, bold: Boolean, align: CalendarPaper.Align) {
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        p.textSize = size
        p.textSize = size * min(1f, min((r-l)/p.measureText(s).coerceAtLeast(.01f), maxHeight/(p.descent()-p.ascent())))
        val alignment = when (align) {
            CalendarPaper.Align.LEFT -> Paint.Align.LEFT
            CalendarPaper.Align.RIGHT -> Paint.Align.RIGHT
            CalendarPaper.Align.CENTER -> Paint.Align.CENTER
        }
        val x = when (align) {
            CalendarPaper.Align.LEFT -> l
            CalendarPaper.Align.RIGHT -> r
            CalendarPaper.Align.CENTER -> (l+r)*.5f
        }
        ops.add(Op(1, x, top+cy-(p.ascent()+p.descent())*.5f, p.textSize, color=color, s=s, bold=bold, align=alignment))
    }
    override fun symbol(cx: Float, cy: Float, side: Float) { ops.add(Op(2, cx, top+cy, side)) }
    fun paint(canvas: Canvas, logo: Drawable, end: PaperScene = this, f: Float = 0f) {
        // Most cells share ink, typeface, size and alignment. Avoid repeating native Paint setters
        // hundreds of times per frame when the display gives us only 8.3 ms at 120 Hz.
        var lastColor = 0
        var lastBold: Boolean? = null
        var lastAlign: Paint.Align? = null
        var lastSize = -1f
        for (i in ops.indices) {
            val a = ops[i]; val b = end.ops[i]
            val x = mixPaper(a.a,b.a,f); val y = mixPaper(a.b,b.b,f); val z = mixPaper(a.c,b.c,f)
            if (a.kind != 2 && lastColor != a.color) { p.color = a.color; lastColor = a.color }
            when (a.kind) {
                0 -> { val radius=mixPaper(a.radius,b.radius,f)
                    canvas.drawRoundRect(x,y,z,mixPaper(a.d,b.d,f),radius,radius,p) }
                1 -> {
                    if (lastBold != a.bold) { p.typeface = if (a.bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT; lastBold = a.bold }
                    if (lastAlign != a.align) { p.textAlign = a.align; lastAlign = a.align }
                    if (lastSize != z) { p.textSize = z; lastSize = z }
                    canvas.drawText(a.s,x,y,p)
                }
                2 -> { val half=z*.5f
                    logo.setBounds((x-half).roundToInt(),(y-half).roundToInt(),(x+half).roundToInt(),(y+half).roundToInt()); logo.draw(canvas) }
            }
        }
    }
}

