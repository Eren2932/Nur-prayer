package com.nur.prayer.ui.schedule

import com.nur.prayer.ui.schedule.print.CalendarPaper
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.core.content.FileProvider
import com.nur.prayer.ui.quran.AyahImageShare
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.ensureActive
import java.io.File

/** A tap creates one immutable file; no preview bitmap survives encoding. */
internal object CalendarImageShare {
    private const val WIDTH = 1440
    private const val HEIGHT = 2560
    private const val RETENTION_MS = 7L * 24 * 60 * 60 * 1000
    class Export(val file: File, val title: String)

    suspend fun prepare(context: Context, page: CalendarPaper.Page): Export = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "share/calendars").apply { mkdirs() }
        // Never replace a URI which another app or the Android thumbnail loader may still be reading.
        val cutoff = System.currentTimeMillis() - RETENTION_MS
        dir.listFiles()?.filter { it.name.startsWith("calendar-") && it.extension == "png" && it.lastModified() < cutoff }
            ?.forEach { it.delete() }
        val bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
        var out: File? = null
        try {
            val file = File.createTempFile("calendar-${page.rows.first().date.toString().take(7)}-", ".png", dir)
            out = file
            ensureActive()
            val grid = CalendarPaper.Grid(WIDTH.toFloat(), HEIGHT.toFloat(), page.rows.size, 1, page.legend.size)
            PaperScene(page, grid).paint(Canvas(bitmap), calendarLogo(context))
            ensureActive()
            file.outputStream().buffered().use { check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) }
            ensureActive()
            Export(file, "${page.month} · ${page.city}").also { out = null }
        } finally { bitmap.recycle(); out?.delete() }
    }

    fun chooser(context: Context, export: Export): Intent {
        val uri = FileProvider.getUriForFile(context, AyahImageShare.authority(context), export.file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TITLE, export.title)
            clipData = ClipData.newUri(context.contentResolver, export.title, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(send, null)
    }
}
