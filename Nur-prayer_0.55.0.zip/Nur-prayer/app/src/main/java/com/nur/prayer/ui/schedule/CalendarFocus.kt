package com.nur.prayer.ui.schedule

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput

/** Observe after children, never consume. Buttons own their click; paging, vertical drags,
 * long press and multitouch are not a tap on the paper. The empty margins are tap targets too. */
internal fun Modifier.calendarPaperTap(onTap: () -> Unit): Modifier = pointerInput(onTap) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Final)
        var valid = !down.isConsumed
        do {
            val changes = awaitPointerEvent(PointerEventPass.Final).changes
            val p = changes.firstOrNull { it.id == down.id } ?: break
            if (changes.size != 1 || p.isConsumed || (p.position-down.position).getDistance() > viewConfiguration.touchSlop ||
                p.uptimeMillis-down.uptimeMillis >= viewConfiguration.longPressTimeoutMillis) valid = false
            if (!p.pressed) { if (valid) onTap(); break }
        } while (valid)
    }
}

/** Time, not frame count. A reversal starts at the last painted value and travels only the remaining distance. */
@Composable
internal fun rememberPaperFocus(reading: Boolean): State<Float> {
    val target = if (reading) 1f else 0f
    val motion = remember { Animatable(target) }
    LaunchedEffect(target) {
        val distance = abs(target - motion.value).coerceIn(0f, 1f)
        val ms = (160f * sqrt(distance)).roundToInt()
        if (ms == 0) motion.snapTo(target)
        else motion.animateTo(target, tween(durationMillis = ms, easing = FastOutSlowInEasing))
    }
    return motion.asState()
}
