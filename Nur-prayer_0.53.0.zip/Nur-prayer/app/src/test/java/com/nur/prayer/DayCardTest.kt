package com.nur.prayer

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.ui.schedule.daylightDelta
import com.nur.prayer.ui.schedule.fastRange
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

/** 0.28.0: the arithmetic behind the day card (the fast, the daylight). */
class DayCardTest {
    private val zone = ZoneId.of("Europe/Moscow")
    private val date = LocalDate.of(2027, 2, 12)

    private fun at(h: Int, m: Int, s: Int = 0, on: LocalDate = date) = ZonedDateTime.of(on, java.time.LocalTime.of(h, m, s), zone)

    private fun day(sahar: ZonedDateTime?, fajr: ZonedDateTime?, sunrise: ZonedDateTime?, maghrib: ZonedDateTime?, on: LocalDate = date) =
        PrayerDay(on, listOfNotNull(
            sahar?.let { Prayer.SAHAR to it }, fajr?.let { Prayer.FAJR to it },
            sunrise?.let { Prayer.SUNRISE to it }, maghrib?.let { Prayer.MAGHRIB to it }
        ).toMap())


    @Test fun theFastRunsFromSuhurToMaghribWhereThePlaceHasSuhur() {
        val d = day(at(5, 11), at(5, 45), at(7, 15), at(16, 39))
        val range = fastRange(d, Prayer.entries)!!
        assertEquals(at(5, 11), range.first)
        assertEquals(at(16, 39), range.second)
    }

    @Test fun theFastRunsFromFajrWhereThereIsNoSeparateSuhur() {
        val d = day(at(5, 11), at(5, 45), at(7, 15), at(16, 39))
        val range = fastRange(d, Prayer.entries.filter { it != Prayer.SAHAR })!!
        assertEquals(at(5, 45), range.first)
    }

    @Test fun noFastRangeWithoutMaghribOrWhenItIsBeforeTheStart() {
        assertNull(fastRange(day(at(5, 11), null, null, null), Prayer.entries))
        assertNull(fastRange(day(at(17, 0), null, null, at(16, 39)), Prayer.entries))
    }

    @Test fun daylightGrowthIsRoundedToWholeMinutes() {
        val before = day(null, null, at(7, 18, 0), at(16, 38, 20), date.minusDays(1))
        val today = day(null, null, at(7, 15, 0), at(16, 39, 0))   // +3 min 40 s
        assertEquals(4L, daylightDelta(today, before))
        assertEquals(-4L, daylightDelta(before, today))
        assertEquals(0L, daylightDelta(today, today))
    }
}
