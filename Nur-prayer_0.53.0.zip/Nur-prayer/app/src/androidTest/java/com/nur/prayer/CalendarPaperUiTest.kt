package com.nur.prayer

import android.graphics.BitmapFactory
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.click
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeLeft
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.schedule.CalendarImageShare
import com.nur.prayer.ui.schedule.MonthTimes
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.schedule.calendarPage
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.time.YearMonth
import java.time.ZonedDateTime

@RunWith(AndroidJUnit4::class)
class CalendarPaperUiTest {
    @get:Rule val compose = createComposeRule()
    private val moment = ZonedDateTime.parse("2026-11-28T13:00:00+03:00[Europe/Moscow]")
    private fun fixture(): PrayerData {
        val c = City.MOSCOW
        val settings = AppSettings()
        val params = settings.paramsFor(c.country)
        val place = Place(c.name, c.subtitle, c.country, c.coordinates, c.zone, false)
        return PrayerData(place, PrayerEngine.days(moment.toLocalDate(), 3, c.coordinates, c.zone, params),
            PrayerEngine.window(moment, c.coordinates, c.zone, params), qiblaBearing(c.coordinates),
            distanceToKaabaKm(c.coordinates), HijriCalendar.format(moment.toLocalDate()), settings,
            settings.profileFor(c.country), params)
    }
    private fun awaitTag(tag: String) = compose.waitUntil(10_000) {
        compose.onAllNodesWithTag(tag).fetchSemanticsNodes().isNotEmpty()
    }

    @Test fun allDaysFitAndSwipingDoesNotToggleFocusOrOpenShare() {
        val data = fixture()
        var shellHidden = false
        compose.setContent {
            NurTheme {
                CompositionLocalProvider(LocalDensity provides Density(LocalDensity.current.density, 2f)) {
                    Box(Modifier.width(320.dp).height(520.dp)) {
                        ScheduleScreen(data, remember { mutableStateOf(moment) }, paletteFor(Prayer.ASR),
                            onModalChange = { shellHidden = it })
                    }
                }
            }
        }
        compose.onNodeWithTag("calendar-tab-2").performClick()
        awaitTag("table-row-2026-11-30")
        compose.onNodeWithTag("table-row-2026-11-01").assertIsDisplayed()
        compose.onNodeWithTag("table-row-2026-11-30").assertIsDisplayed()
        compose.onNodeWithTag("month-table").performTouchInput { click() }
        compose.onNodeWithTag("calendar-tabs").assertDoesNotExist()
        compose.onNodeWithTag("calendar-share").assertDoesNotExist()
        compose.runOnIdle { assertTrue(shellHidden) }
        compose.onNodeWithTag("calendar-pager").performTouchInput { swipeLeft() }
        awaitTag("table-row-2026-12-31")
        compose.onNodeWithTag("calendar-tabs").assertDoesNotExist()
        compose.onNodeWithTag("month-table").performTouchInput { click() }
        compose.onNodeWithTag("calendar-share").assertIsEnabled().performClick()
        awaitTag("calendar-export-image")
        compose.onNodeWithTag("calendar-export-send").assertIsEnabled()
    }

    @Test fun consecutiveExportsAreDifferentFilesAndPngMatchesItsPreview() {
        val data = fixture()
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        fun prepare(month: YearMonth): CalendarImageShare.Export {
            val days = PrayerEngine.days(month.atDay(1), month.lengthOfMonth(), data.place.coordinates, data.place.zone, data.params)
            val p = calendarPage(MonthTimes(month, days, Prayer.entries), 0, data.place.label, data.params.method, moment.toLocalDate())
            return runBlocking { CalendarImageShare.prepare(ctx, p) }
        }
        val month = YearMonth.from(moment)
        val a = prepare(month)
        val bytes = a.file.readBytes()
        a.bitmap.recycle()
        val b = prepare(month.plusMonths(1))
        try {
            assertNotEquals(a.file, b.file)
            assertTrue(bytes.contentEquals(a.file.readBytes()))
            assertTrue(!bytes.contentEquals(b.file.readBytes()))
            val decoded = BitmapFactory.decodeFile(b.file.absolutePath)
            try {
                assertEquals(1440, decoded.width)
                assertEquals(2560, decoded.height)
                assertTrue(decoded.sameAs(b.bitmap))
            } finally { decoded.recycle() }
        } finally { b.bitmap.recycle(); a.file.delete(); b.file.delete() }
    }
}
