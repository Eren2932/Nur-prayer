package com.nur.prayer.ui.schedule

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput

/** Observe after children, never consume. Buttons own their click; paging, vertical drags,
 * long press and multitouch are not a tap on the paper. The empty margins are tap targets too. */
internal fun Modifier.calendarPaperTap(onTap: () -> Unit): Modifier = pointerInput(onTap) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Final)
        var valid = !down.isConsumed
        do {
            val changes = awaitPointerEvent(PointerEventPass.Final).changes
            val p = changes.firstOrNull { it.id == down.id } ?: break
            if (changes.size != 1 || p.isConsumed || (p.position-down.position).getDistance() > viewConfiguration.touchSlop ||
                p.uptimeMillis-down.uptimeMillis >= viewConfiguration.longPressTimeoutMillis) valid = false
            if (!p.pressed) { if (valid) onTap(); break }
        } while (valid)
    }
}
