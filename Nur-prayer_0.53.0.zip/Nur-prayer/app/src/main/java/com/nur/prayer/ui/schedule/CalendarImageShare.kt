package com.nur.prayer.ui.schedule

import com.nur.prayer.ui.schedule.print.CalendarPaper
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.core.content.FileProvider
import com.nur.prayer.ui.quran.AyahImageShare
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Preview and share own one immutable file each time, even for two consecutive exports of the same month. */
internal object CalendarImageShare {
    private const val WIDTH = 1440
    private const val HEIGHT = 2560
    private const val RETENTION_MS = 7L * 24 * 60 * 60 * 1000
    class Export(val file: File, val bitmap: Bitmap, val title: String)

    suspend fun prepare(context: Context, page: CalendarPaper.Page): Export = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "share/calendars").apply { mkdirs() }
        // Never replace a URI which another app or the Android thumbnail loader may still be reading.
        val cutoff = System.currentTimeMillis() - RETENTION_MS
        dir.listFiles()?.filter { it.name.startsWith("calendar-") && it.extension == "png" && it.lastModified() < cutoff }
            ?.forEach { it.delete() }
        val out = File.createTempFile("calendar-${page.rows.first().date.toString().take(7)}-", ".png", dir)
        val bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888)
        var ready = false
        try {
            CalendarPaper.draw(page, CalendarPaper.Grid(WIDTH.toFloat(), HEIGHT.toFloat(), page.rows.size),
                AndroidPaperInk(Canvas(bitmap), calendarLogo(context)))
            out.outputStream().buffered().use { check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) }
            ready = true
            Export(out, bitmap, "${page.month} · ${page.city}")
        } finally {
            if (!ready) { out.delete(); bitmap.recycle() }
        }
    }

    fun send(context: Context, export: Export): Boolean = runCatching {
        val uri = FileProvider.getUriForFile(context, AyahImageShare.authority(context), export.file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TITLE, export.title)
            clipData = ClipData.newUri(context.contentResolver, export.title, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.isSuccess
}
