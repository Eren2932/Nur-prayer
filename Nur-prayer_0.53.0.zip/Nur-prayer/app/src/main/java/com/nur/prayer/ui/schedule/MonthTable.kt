package com.nur.prayer.ui.schedule

import com.nur.prayer.ui.schedule.print.CalendarPaper
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Constraints
import com.nur.prayer.R
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.i18n.trDynamic
import com.nur.prayer.ui.Format
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.min
import kotlin.math.roundToInt

internal class MonthTimes(val month: YearMonth, val days: List<PrayerDay>, val columns: List<Prayer>)

internal fun columnLabel(prayer: Prayer): String = when (prayer) {
    Prayer.SAHAR -> tr("Сухур")
    Prayer.FAJR -> tr("Фаджр")
    Prayer.SUNRISE -> tr("Восход")
    Prayer.DHUHR -> tr("Зухр")
    Prayer.ASR -> tr("Аср")
    Prayer.MAGHRIB -> tr("Магриб")
    Prayer.ISHA -> tr("Иша")
}

internal fun calendarPage(times: MonthTimes, offset: Int, city: String, method: CalculationMethod,
                          generated: LocalDate): CalendarPaper.Page {
    val locale = L10n.language.locale
    val labels = times.columns.map(::columnLabel)
    val methodName = when (method) {
        CalculationMethod.SPIRITUAL_BOARD_TATARSTAN -> tr("ДУМ РТ")
        CalculationMethod.RUSSIA_DUM -> tr("ДУМ РФ")
        else -> trDynamic(method.title)
    }
    val rows = times.days.map { day ->
        val values = times.columns.map { p -> day.times[p]?.let(Format::time) ?: "—" }
        val hijri = HijriCalendar.dayOfMonth(day.date, offset)
        CalendarPaper.Row(day.date, Format.weekdayShort(day.date), hijri, values,
            (listOf(Format.fullDate(day.date), HijriCalendar.format(day.date, offset)) +
                labels.zip(values) { name, time -> "$name $time" }).joinToString(", "))
    }
    return CalendarPaper.Page("${Format.monthName(times.month.monthValue)} ${times.month.year}",
        HijriCalendar.span(times.month.atDay(1), times.month.atEndOfMonth(), offset), city,
        "${tr("Метод")}: $methodName", generated.toString(), tr("Дата").uppercase(locale),
        labels.map { it.uppercase(locale) }, times.columns.indexOf(Prayer.SUNRISE), rows)
}

/** One adapter for both Android surfaces; mutable paint/drawable belong to a single drawing owner. */
internal class AndroidPaperInk(private val canvas: Canvas, private val logo: Drawable) : CalendarPaper.Ink {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply { fontFeatureSettings = "tnum" }
    override fun box(l: Float, t: Float, r: Float, b: Float, radius: Float, color: Int) {
        p.color = color
        if (radius == 0f) canvas.drawRect(l, t, r, b, p) else canvas.drawRoundRect(l, t, r, b, radius, radius, p)
    }
    override fun text(s: String, l: Float, r: Float, cy: Float, size: Float, maxHeight: Float,
                      color: Int, bold: Boolean, align: CalendarPaper.Align) {
        if (s.isEmpty() || r <= l || maxHeight <= 0f) return
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        p.color = color
        p.textSize = size
        p.textSize = size * min(1f, min((r-l)/p.measureText(s).coerceAtLeast(.01f), maxHeight/(p.descent()-p.ascent())))
        val x = when (align) {
            CalendarPaper.Align.LEFT -> l.also { p.textAlign = Paint.Align.LEFT }
            CalendarPaper.Align.RIGHT -> r.also { p.textAlign = Paint.Align.RIGHT }
            CalendarPaper.Align.CENTER -> ((l+r)*.5f).also { p.textAlign = Paint.Align.CENTER }
        }
        canvas.drawText(s, x, cy-(p.ascent()+p.descent())*.5f, p)
    }
    override fun symbol(cx: Float, cy: Float, side: Float) {
        val half = side*.5f
        logo.setBounds((cx-half).roundToInt(), (cy-half).roundToInt(), (cx+half).roundToInt(), (cy+half).roundToInt())
        logo.draw(canvas)
    }
}

internal fun calendarLogo(context: android.content.Context): Drawable =
    requireNotNull(context.getDrawable(R.drawable.ic_notification)).mutate().apply { setTint(CalendarPaper.BLUE) }

/** Transparent, positioned row nodes keep TalkBack navigation without 250 separately measured Texts. */
@Composable
internal fun MonthTable(page: CalendarPaper.Page, focusLabel: String, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val logo = remember(context) { calendarLogo(context) }
    Layout(content = {
        Box(Modifier.semantics {
            contentDescription = "${page.month}, ${page.span}, ${page.city}, ${page.method}, ${page.stamp}"
            onClick(label = focusLabel) { onToggle(); true }
        })
        page.rows.forEach { row -> Box(Modifier.testTag("table-row-${row.date}").semantics { contentDescription = row.description }) }
    }, modifier = modifier.fillMaxSize().testTag("month-table").drawWithCache {
        val grid = CalendarPaper.Grid(size.width, size.height, page.rows.size)
        onDrawBehind { CalendarPaper.draw(page, grid, AndroidPaperInk(drawContext.canvas.nativeCanvas, logo)) }
    }) { nodes, constraints ->
        val w = constraints.maxWidth
        val h = constraints.maxHeight
        val grid = CalendarPaper.Grid(w.toFloat(), h.toFloat(), page.rows.size)
        val header = nodes.first().measure(Constraints.fixed(w, grid.rowsTop.roundToInt()))
        val rows = nodes.drop(1).mapIndexed { i, n ->
            val top = grid.rowTop(i)
            n.measure(Constraints.fixed(grid.panelWidth.roundToInt(), (top+grid.rowHeight).roundToInt()-top.roundToInt()))
        }
        layout(w, h) {
            header.place(0, 0)
            rows.forEachIndexed { i, p -> p.place(grid.rowLeft(i).roundToInt(), grid.rowTop(i).roundToInt()) }
        }
    }
}
