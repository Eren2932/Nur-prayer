package com.nur.prayer.ui.schedule

import com.nur.prayer.ui.schedule.print.CalendarPaper
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.DockGlyphButton
import com.nur.prayer.ui.components.ExitDock
import com.nur.prayer.ui.components.GlyphKind
import kotlinx.coroutines.CancellationException

/** Never display a previously cached thumbnail while encoding the next month. The system receives the
 * unique file encoded from the very bitmap shown here. A platform dialog also isolates TalkBack and Back. */
@Composable
internal fun CalendarExportDialog(page: CalendarPaper.Page, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val failed = tr("Не удалось подготовить картинку")
    var export by remember(page) { mutableStateOf<CalendarImageShare.Export?>(null) }
    LaunchedEffect(page) {
        try { export = CalendarImageShare.prepare(context, page) }
        catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { Toast.makeText(context, failed, Toast.LENGTH_SHORT).show(); onDismiss() }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xff181818)).testTag("calendar-export"),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text(tr("Поделиться таблицей месяца"), color = Color.White, modifier = Modifier.padding(8.dp))
            val ready = export
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
                if (ready == null) CircularProgressIndicator(color = Color.White)
                else Image(remember(ready) { ready.bitmap.asImageBitmap() }, ready.title,
                    Modifier.fillMaxSize().testTag("calendar-export-image"), contentScale = ContentScale.Fit)
            }
            val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
            ExitDock(onClose = onDismiss, bottom = bottom, description = tr("Закрыть"), centerAction = {
                DockGlyphButton(GlyphKind.SHARE, tr("Поделиться"), Color.White, {
                    if (ready != null && CalendarImageShare.send(context, ready)) onDismiss()
                    else Toast.makeText(context, failed, Toast.LENGTH_SHORT).show()
                }, Modifier.testTag("calendar-export-send"), enabled = ready != null)
            })
        }
    }
}
