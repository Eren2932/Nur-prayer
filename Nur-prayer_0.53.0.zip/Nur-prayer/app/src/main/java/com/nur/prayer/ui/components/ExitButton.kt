package com.nur.prayer.ui.components

import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr

/** Physical left and right, independent of the reading direction. One optical axis, including gallery overlays. */
object ExitButtonSpec {
    val Hit = 52.dp
    val Side = 14.dp
    val Diameter = 32.dp
    fun bottomGap(systemBar: Dp): Dp = (systemBar - 8.dp).coerceAtLeast(10.dp)
    fun contentFloor(systemBar: Dp): Dp = bottomGap(systemBar) + Hit + 2.dp
    @Composable
    fun contentFloor(): Dp = contentFloor(WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding())
    val BarClearance = 48.dp
    const val FADE_MILLIS = 140
}

/**
 * What the ring does: the system's back, exactly as the gesture would. Every page already answers it (its own
 * [androidx.activity.compose.BackHandler] first, the navigator last), so one ring serves all of them and an editor
 * inside a page closes itself before the page does. The keyboard goes first, or it would hang over the page below.
 */
@Composable
fun rememberSystemBack(): () -> Unit {
    val dispatcher = LocalOnBackPressedDispatcherOwner.current?.onBackPressedDispatcher
    val keyboard = LocalSoftwareKeyboardController.current
    return remember(dispatcher, keyboard) {
        val action: () -> Unit = {
            keyboard?.hide()
            dispatcher?.onBackPressed()
        }
        action
    }
}

@Composable
fun ExitDock(onClose: () -> Unit, bottom: Dp, modifier: Modifier = Modifier,
             description: String = tr("Назад"), tint: Color = Color.White, onMenu: (() -> Unit)? = null,
             menuDescription: String = tr("Разделы"), centerAction: (@Composable () -> Unit)? = null) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(modifier.fillMaxWidth().padding(horizontal = ExitButtonSpec.Side)
            .padding(bottom = ExitButtonSpec.bottomGap(bottom)), horizontalArrangement = Arrangement.SpaceBetween) {
            if (onMenu != null) DockButton(onMenu, description = menuDescription, tint = tint, more = true)
            // Other screens retain their existing inert mark, without a false accessibility action.
            else Box(Modifier.size(ExitButtonSpec.Hit).pointerInput(Unit) { detectTapGestures { } }, contentAlignment = Alignment.Center) { DockMark(tint, more = true) }
            centerAction?.invoke()
            DockButton(onClose, description = description, tint = tint)
        }
    }
}

@Composable
private fun DockButton(onClick: () -> Unit, description: String, tint: Color, more: Boolean = false) {
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.9f else 1f, tween(90), label = "exitPress")
    Box(
        modifier = Modifier
            .size(ExitButtonSpec.Hit)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .semantics { contentDescription = description }
            .clickable(interactionSource = interaction, indication = null, role = Role.Button) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        DockMark(tint, more = more)
    }
}

@Composable
private fun DockMark(tint: Color, more: Boolean) {
    Canvas(Modifier.size(ExitButtonSpec.Diameter)) {
        drawDockRing(tint)
        val ink = tint.copy(alpha = .82f)
        if (more) {
            for (i in -1..1) drawCircle(ink, 1.65.dp.toPx(), Offset(center.x + i * 6.3.dp.toPx(), center.y))
        } else {
            drawCloseMark(ink)
        }
    }
}

/** The exact two round-ended diagonals used in the app's corner ring, scaled to this ring. */
@Composable
internal fun CloseMark(ink: Color, modifier: Modifier) {
    Canvas(modifier) { drawCloseMark(ink.copy(alpha = .82f)) }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCloseMark(ink: Color) {
    val u = size.minDimension / 32f
    val d = 4.7f * u
    drawLine(ink, center - Offset(d, d), center + Offset(d, d), 1.7f * u, StrokeCap.Round)
    drawLine(ink, center + Offset(-d, d), center + Offset(d, -d), 1.7f * u, StrokeCap.Round)
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDockRing(tint: Color) {
    val w = 1.dp.toPx()
    val r = size.minDimension / 2f
    drawCircle(Color.Black.copy(alpha = .12f), r)
    drawCircle(tint.copy(alpha = .50f), r - w / 2f, style = Stroke(w))
}

/** Same frame, optical diameter and touch area as ExitDock, with a caller-supplied glyph. */
@Composable
internal fun DockGlyphButton(glyph: GlyphKind, label: String, tint: Color, onClick: () -> Unit,
                             modifier: Modifier = Modifier, enabled: Boolean = true,
                             selectedTab: Boolean? = null) {
    Box(modifier.size(ExitButtonSpec.Hit).graphicsLayer { alpha = if (enabled) 1f else .40f }
        .semantics {
            contentDescription = label
            if (selectedTab != null) selected = selectedTab
        }.pressClick(enabled = enabled, role = if (selectedTab == null) Role.Button else Role.Tab,
            shape = androidx.compose.foundation.shape.CircleShape, onClick = onClick),
        contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(ExitButtonSpec.Diameter)) {
            drawDockRing(tint)
            if (selectedTab == true) drawCircle(tint, 1.35.dp.toPx(), Offset(center.x, size.height*.84f))
        }
        Glyph(glyph, tint.copy(alpha = if (selectedTab == true) 1f else .82f), Modifier.size(16.dp))
    }
}
