package com.nur.prayer.ui.schedule.print;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;

/** The printable page. All lengths are fractions of its actual bounds, not Android sp.
 * The Android screen and the PNG use this same layout and painter. No off-screen bitmap for browsing. */
public final class CalendarPaper {
    private CalendarPaper() {}
    public static final int PAPER = 0xfffaf6ec, INK = 0xff181818, SECONDARY = 0xff5b5956,
        BLUE = 0xff1b4bd1, FRIDAY = 0xffe5edfc, LINE = 0xffdfdacf, WEEK = 0xffb4afa6;
    public static final class Row {
        public final LocalDate date;
        public final String weekday, description;
        public final int hijri;
        public final List<String> times;
        public Row(LocalDate date, String weekday, int hijri, List<String> times, String description) {
            this.date=date; this.weekday=weekday; this.hijri=hijri; this.times=times; this.description=description;
        }
    }
    public static final class Page {
        public final String month, span, city, method, stamp, dateLabel;
        public final List<String> columns;
        public final List<Row> rows;
        public final int sunrise;
        public Page(String month, String span, String city, String method, String stamp, String dateLabel,
                    List<String> columns, int sunrise, List<Row> rows) {
            this.month=month; this.span=span; this.city=city; this.method=method; this.stamp=stamp;
            this.dateLabel=dateLabel; this.columns=columns; this.sunrise=sunrise; this.rows=rows;
        }
    }
    public enum Align { LEFT, CENTER, RIGHT }
    public interface Ink {
        void box(float l,float t,float r,float b,float radius,int color);
        /** Centre vertically. Fit both measured glyph width and font metrics inside this rectangle. */
        void text(String s,float l,float r,float cy,float size,float maxHeight,int color,boolean bold,Align align);
        void symbol(float cx,float cy,float side);
    }
    public static final class Grid {
        public final float w,h,unit,left,right,panelWidth,gap,rule,rowsTop,rowHeight,footer;
        public final int panels, perPanel;
        public Grid(float w,float h,int count) {
            this.w=w; this.h=h;
            panels=w>1.22f*h ? 2 : 1;
            perPanel=(count+panels-1)/panels;
            unit=Math.min(w/panels, h*1.75f);
            left=unit*.031f; right=w-left; gap=panels==2 ? unit*.046f : 0;
            panelWidth=(right-left-gap)/panels;
            rule=Math.min(.143f*h,.257f*unit);
            rowsTop=rule+Math.min(.045f*h,.082f*unit);
            footer=h-Math.min(.038f*h,.067f*unit);
            rowHeight=(footer-Math.min(.021f*h,.038f*unit)-rowsTop)/Math.max(1,perPanel);
        }
        public float panelLeft(int panel) { return left+panel*(panelWidth+gap); }
        public float rowLeft(int i) { return panelLeft(i/perPanel); }
        public float rowTop(int i) { return rowsTop+(i%perPanel)*rowHeight; }
    }
    private static void line(Ink p,float l,float r,float y,float width,int color) {
        p.box(l,y-width/2,r,y+width/2,0,color);
    }
    public static void draw(Page s, Grid g, Ink p) {
        final float u=g.unit, hair=Math.max(.45f,u*.00095f), l=g.left, r=g.right;
        p.box(0,0,g.w,g.h,0,PAPER);
        float headerX=l+u*.018f, brand=Math.min(u*.13f,g.rule*.79f), end=r-brand-u*.035f;
        p.text(s.month,headerX,end,g.rule*.37f,u*.096f,g.rule*.49f,INK,true,Align.LEFT);
        p.text(s.span,headerX,end,g.rule*.682f,u*.034f,g.rule*.188f,SECONDARY,true,Align.LEFT);
        p.text(s.city,headerX,end,g.rule*.85f,u*.03f,g.rule*.16f,INK,false,Align.LEFT);
        p.symbol(r-brand*.52f,g.rule*.52f,brand);
        line(p,l,r,g.rule,hair*1.55f,INK);
        float dw=g.panelWidth*.185f, cw=(g.panelWidth-dw)/s.columns.size();
        float labelH=g.rowsTop-g.rule, labelSize=Math.min(u*.0239f,labelH*.54f);
        for (int j=0;j<g.panels;j++) {
            float x=g.panelLeft(j), y=g.rule+labelH*.57f;
            p.text(s.dateLabel,x+u*.015f,x+dw,y,labelSize,labelH*.65f,INK,true,Align.LEFT);
            for (int k=0;k<s.columns.size();k++) {
                float a=x+dw+cw*k;
                p.text(s.columns.get(k),a+cw*.022f,a+cw*.978f,y,labelSize,labelH*.65f,
                    k==s.sunrise?SECONDARY:INK,true,Align.CENTER);
            }
            line(p,x,x+g.panelWidth,g.rowsTop,hair*1.5f,WEEK);
        }
        for (int i=0;i<s.rows.size();i++) {
            Row row=s.rows.get(i); float x=g.rowLeft(i), y=g.rowTop(i), h=g.rowHeight, mid=y+h*.505f;
            boolean fri=row.date.getDayOfWeek()==DayOfWeek.FRIDAY, sun=row.date.getDayOfWeek()==DayOfWeek.SUNDAY;
            if (fri) {
                float round=Math.min(u*.012f,h*.28f), mark=Math.min(u*.0048f,h*.14f);
                p.box(x,y+hair*.5f,x+g.panelWidth,y+h-hair*.5f,round,FRIDAY);
                p.box(x,y+hair*.6f,x+mark,y+h-hair*.6f,mark/2,BLUE);
            }
            float num=Math.min(u*.0315f,h*.81f), cap=h*.88f;
            p.text(Integer.toString(row.date.getDayOfMonth()),x+dw*.044f,x+dw*.273f,mid,num,cap,fri?BLUE:INK,true,Align.CENTER);
            p.text(row.weekday,x+dw*.286f,x+dw*.644f,mid,num*.91f,cap,fri?BLUE:INK,fri,Align.CENTER);
            p.text(Integer.toString(row.hijri),x+dw*.664f,x+dw*.945f,mid,num*.82f,cap,
                row.hijri==1?BLUE:SECONDARY,row.hijri==1,Align.CENTER);
            for(int k=0;k<row.times.size();k++) {
                float a=x+dw+cw*k;
                p.text(row.times.get(k),a+cw*.035f,a+cw*.965f,mid,num,cap,
                    k==s.sunrise?SECONDARY:INK,k!=s.sunrise,Align.CENTER);
            }
            line(p,x,x+g.panelWidth,y+h,sun?hair*1.65f:hair,sun?WEEK:LINE);
        }
        line(p,l,r,g.footer,hair*1.55f,INK);
        float footH=g.h-g.footer, footY=g.footer+footH*.43f;
        p.text(s.method,l+u*.008f,r-u*.29f,footY,u*.024f,footH*.66f,SECONDARY,false,Align.LEFT);
        p.text(s.stamp,r-u*.28f,r-u*.008f,footY,u*.024f,footH*.66f,SECONDARY,false,Align.RIGHT);
    }
}
