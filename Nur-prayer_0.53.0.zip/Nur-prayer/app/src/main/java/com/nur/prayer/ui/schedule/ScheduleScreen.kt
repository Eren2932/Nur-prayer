package com.nur.prayer.ui.schedule

import com.nur.prayer.ui.schedule.print.CalendarPaper
import com.nur.prayer.ui.components.pageContentInsets
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.background
import com.nur.prayer.i18n.L10n
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.ui.components.DockGlyphButton
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.daily.StoryBars
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.ExitDock
import com.nur.prayer.ui.components.ExitButtonSpec
import com.nur.prayer.ui.components.rememberSystemBack
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.home.HomeTimeline
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SystemBarsTone
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.findActivity
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.abs

/** One settled Gregorian period drives both month views and the share action.
 * The grid and year retain their own detail UI; the table is a full-sheet reader. */
internal object CalendarTabs {
    const val YEAR = 0
    const val MONTH = 1
    const val TABLE = 2
}

/** The colours of the text that stands on the backdrop itself (the period title, the weekday letters). */
private class BackdropInk(val title: Color, val subtitle: Color, val label: Color, val friday: Color)

private fun backdropInk(light: Boolean, palette: PhasePalette): BackdropInk =
    if (light) BackdropInk(Paper.Ink, Paper.Accent, Paper.Ink3, Paper.Accent)
    else BackdropInk(TextPrimary, palette.accentSoft, TextTertiary, palette.accentSoft)

/**
 * The timetables of the months the pager has seen. A page asks for its month, the cache computes it once off the
 * main thread and keeps only the months near the one just added: swiping through ten years must not keep ten years.
 */
@Stable
internal class MonthTimesCache(private val compute: suspend (YearMonth) -> MonthTimes?) {
    private val months = mutableStateMapOf<YearMonth, MonthTimes>()
    private val gate = Mutex()

    operator fun get(month: YearMonth): MonthTimes? = months[month]

    suspend fun ensure(month: YearMonth) {
        gate.withLock {
            if (months.containsKey(month)) return
            val times = compute(month) ?: return
            months[month] = times
            if (months.size > KEEP) {
                months.keys.filter { abs(ChronoUnit.MONTHS.between(it, month)) > NEAR }.forEach { months.remove(it) }
            }
        }
    }

    private companion object {
        const val KEEP = 7
        const val NEAR = 3L
    }
}

@Composable
fun ScheduleScreen(
    data: PrayerData, now: State<ZonedDateTime>, palette: PhasePalette,
    modifier: Modifier = Modifier,
    /** True while the wallpaper under the page is a light picture: the text on it is dark, the bars' icons too. */
    lightBackdrop: Boolean = false,
    onModalChange: (Boolean) -> Unit = {}
) {
    val today = data.today.date
    val hijriOffset = data.settings.hijriOffset

    var tab by rememberSaveable { mutableIntStateOf(CalendarTabs.MONTH) }
    var monthText by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(YearMonth.from(today).toString()) }
    var selectedEpoch by rememberSaveable(today.toEpochDay(), data.place.label) { mutableStateOf(today.toEpochDay()) }
    var hijriYear by rememberSaveable(today.toEpochDay(), hijriOffset) { mutableIntStateOf(IslamicDays.hijriOf(today, hijriOffset).year) }
    var picker by rememberSaveable { mutableStateOf(false) }
    // A DayOccurrence is not Parcelable: the sheet is closed after a rotation, which is the honest state.
    var topic by remember { mutableStateOf<SheetTopic?>(null) }
    val tableTab = tab == CalendarTabs.TABLE
    var focus by rememberSaveable(tab) { mutableStateOf(false) }
    val reading = tableTab && focus
    val toggleFocus: () -> Unit = remember(tab) { { focus = !focus } }
    val paperTone = tableTab || lightBackdrop
    StoryBars(reading)
    BackHandler(enabled = reading) { focus = false }
    val month = YearMonth.parse(monthText)
    val selectedDate = LocalDate.ofEpochDay(selectedEpoch)
    fun goMonth(target: YearMonth) {
        if (target == month) return
        monthText = target.toString()
        selectedEpoch = CalendarMonthModel.moveSelection(selectedDate, target).toEpochDay()
    }

    // On a light picture the status-bar icons turn dark, or the clock and battery vanish into the cream.
    val view = LocalView.current
    // The holder is released the moment the page stops being light (the route changes), not when its exit
    // animation ends, so the next screen's own tone is never overwritten.
    val barsOwner = remember { Any() }
    DisposableEffect(paperTone) {
        val window = view.context.findActivity()?.window
        if (paperTone) SystemBarsTone.hold(window, barsOwner)
        onDispose { SystemBarsTone.release(window, barsOwner) }
    }

    // The timetables: a table page shows its month, the share button sends the one in front. 31 solar days are cheap.
    val columns = remember(data.fajrEqualsDawn) { HomeTimeline.prayers(data.fajrEqualsDawn) }
    val timesCache = remember(data.place, data.params, columns) {
        MonthTimesCache { m ->
            try {
                withContext(Dispatchers.Default) {
                    MonthTimes(m, PrayerEngine.days(m.atDay(1), m.lengthOfMonth(), data.place.coordinates, data.place.zone, data.params), columns)
                }
            } catch (cancel: CancellationException) { throw cancel } catch (_: Exception) { null }
        }
    }
    LaunchedEffect(month, timesCache) { timesCache.ensure(month) }
    val monthTimes = timesCache[month]
    val language = L10n.language
    var exportPage by remember(month, timesCache, tab, hijriOffset, today, language) {
        mutableStateOf<CalendarPaper.Page?>(null)
    }
    if (picker || topic != null || reading || exportPage != null) DisposableEffect(onModalChange) {
        onModalChange(true)
        onDispose { onModalChange(false) }
    }

    // The pages. The state above stays the one truth; each pager reports a settled page and follows a changed period.
    val yearTab = tab == CalendarTabs.YEAR
    val gregorian = remember(today) { PeriodRange.gregorianYears(today) }
    val firstMonth = YearMonth.of(gregorian.first, 1)
    val monthCount = PeriodPages.monthCount(firstMonth, YearMonth.of(gregorian.last, 12))
    val hijriYears = remember(today, hijriOffset) { PeriodRange.hijriYears(today, hijriOffset) }
    val yearCount = hijriYears.last - hijriYears.first + 1
    val monthPager = rememberPeriodPager(PeriodPages.monthPage(firstMonth, month, monthCount), monthCount) { page ->
        goMonth(PeriodPages.monthAt(firstMonth, page))
    }
    val yearPager = rememberPeriodPager(PeriodPages.yearPage(hijriYears.first, hijriYear, yearCount), yearCount) { page ->
        hijriYear = hijriYears.first + page
    }
    // The grid views are Месяц and Таблица. Going to Год keeps the one that was in front, so the page that is
    // leaving does not swap its view while it fades out.
    val lastGrid = remember { IntArray(1) { CalendarTabs.MONTH } }
    if (tab != CalendarTabs.YEAR) lastGrid[0] = tab
    val gridTab = lastGrid[0]
    val ink = backdropInk(lightBackdrop, palette)
    // The cards end above the system bar with a normal margin: the capsule is not there to be run behind.
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val bottomInset = ExitButtonSpec.contentFloor(bottom)
    val back = rememberSystemBack()

    val tint = if (paperTone) Paper.Ink else Color.White
    val canShare = !yearTab && monthTimes != null && !monthPager.isScrollInProgress &&
        month == PeriodPages.monthAt(firstMonth, monthPager.currentPage)
    val focusLabel = if (reading) tr("Показать управление") else tr("Скрыть управление")
    val tap = tableTab && !picker && topic == null && exportPage == null
    Box(modifier.fillMaxSize().then(if (tableTab) Modifier.background(Color(CalendarPaper.PAPER)) else Modifier)
        .then(if (tap) Modifier.calendarPaperTap(toggleFocus) else Modifier)) {
        Column(Modifier.fillMaxSize().pageContentInsets().then(if (reading)
            Modifier.windowInsetsPadding(WindowInsets.displayCutout.only(WindowInsetsSides.Bottom)) else Modifier)) {
            if (!reading) CalendarTopBar(tab, { tab = it }, tint)
            if (!tableTab) {
                Spacer(Modifier.height(10.dp))
                PeriodBar(
                    pager = if (yearTab) yearPager else monthPager,
                    title = { page ->
                        if (yearTab) tr("{0} год хиджры", hijriYears.first + page)
                        else PeriodPages.monthAt(firstMonth, page).let { "${Format.monthName(it.monthValue)} ${it.year}" }
                    },
                    subtitle = { page ->
                        if (yearTab) yearSpan(hijriYears.first + page, hijriOffset)
                        else PeriodPages.monthAt(firstMonth, page).let { HijriCalendar.span(it.atDay(1), it.atEndOfMonth(), hijriOffset) }
                    },
                    onPick = { picker = true },
                    ink = ink.title, subInk = ink.subtitle
                )
                Spacer(Modifier.height(8.dp))
            }
            AnimatedContent(
                targetState = yearTab,
                transitionSpec = {
                    val forward = !targetState
                    (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { w -> if (forward) w / 6 else -w / 6 } +
                        fadeIn(tween(260, delayMillis = 40))) togetherWith
                        (slideOutHorizontally(tween(240)) { w -> if (forward) -w / 8 else w / 8 } + fadeOut(tween(160)))
                },
                label = "calendarTab",
                modifier = Modifier.weight(1f).fillMaxSize()
            ) { year ->
                if (year) PeriodPager(yearPager, Modifier.testTag("year-pager")) { page ->
                    YearView(
                        hijriYears.first + page, today, hijriOffset,
                        bottomInset = bottomInset,
                        onOpen = { topic = it }
                    )
                } else PeriodPager(monthPager, Modifier.testTag("calendar-pager")) { page ->
                    val pageMonth = PeriodPages.monthAt(firstMonth, page)
                    // A neighbour page shows the day that will be selected when the page arrives, so the leaf is
                    // whole while it turns, and landing on it changes nothing under the thumb.
                    val pageSelected = if (pageMonth == month) selectedDate else CalendarMonthModel.moveSelection(selectedDate, pageMonth)
                    AnimatedContent(
                        targetState = gridTab,
                        transitionSpec = {
                            val forward = targetState > initialState
                            (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { w -> if (forward) w / 6 else -w / 6 } +
                                fadeIn(tween(260, delayMillis = 40))) togetherWith
                                (slideOutHorizontally(tween(240)) { w -> if (forward) -w / 8 else w / 8 } + fadeOut(tween(160)))
                        },
                        label = "calendarView",
                        modifier = Modifier.fillMaxSize()
                    ) { gridView ->
                        if (gridView == CalendarTabs.TABLE) TablePage(
                            pageMonth, timesCache, today, hijriOffset, data.place.label, data.params.method,
                            bottomInset = if (reading) 0.dp else bottomInset,
                            focusLabel = focusLabel, onToggle = toggleFocus
                        ) else MonthPage(
                            data, now, pageMonth, pageSelected, columns, ink, bottomInset,
                            onSelect = { selectedEpoch = it.toEpochDay() },
                            onToday = { monthText = YearMonth.from(today).toString(); selectedEpoch = today.toEpochDay() },
                            onOpen = { topic = it }
                        )
                    }
                }
            }
        }
        PeriodPicker(
            visible = picker,
            mode = if (yearTab) PickerMode.HIJRI_YEAR else PickerMode.MONTH,
            month = month, hijriYear = hijriYear, today = today, hijriOffset = hijriOffset,
            accent = palette.accent, surface = palette.sheet,
            onMonth = { goMonth(it) }, onHijriYear = { hijriYear = it }, onDismiss = { picker = false }
        )
        DaySheet(topic, today, hijriOffset, onDismiss = { topic = null })
        // One dock serves both the calendar and its sheets. Close the overlay, never its parent.
        val modal = picker || topic != null
        if (!reading) ExitDock(onClose = { when { topic != null -> topic = null; picker -> picker = false; else -> back() } },
            bottom = bottom, modifier = Modifier.align(Alignment.BottomCenter).pageContentInsets(),
            description = if (modal) tr("Закрыть") else tr("Назад"),
            tint = if (topic != null || paperTone && !picker) Paper.Ink else Color.White,
            onMenu = if (tableTab && !modal) ({ picker = true }) else null,
            menuDescription = tr("Выбрать период"),
            centerAction = if (!yearTab && !modal) ({
                DockGlyphButton(GlyphKind.SHARE, tr("Поделиться таблицей месяца"), tint, {
                    if (monthTimes != null && canShare) exportPage = calendarPage(monthTimes, hijriOffset,
                        data.place.label, data.params.method, LocalDate.now(data.place.zone))
                }, Modifier.testTag("calendar-share"), enabled = canShare)
            }) else null)
        exportPage?.let { CalendarExportDialog(it) { exportPage = null } }
    }
}

/** "16 июня 2026 — 4 июня 2027": the Gregorian bounds of a hijri year. */
private fun yearSpan(year: Int, offset: Int): String {
    val first = IslamicDays.monthRange(year, 1, offset)?.first
    val last = IslamicDays.monthRange(year, 12, offset)?.second
    return if (first != null && last != null) "${Format.dayMonth(first)} ${first.year} — ${Format.dayMonth(last)} ${last.year}" else ""
}

/* ------------------------------------------------------------------------------------------------
 * Месяц: the grid, the card of the selected day, the next day of the year
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun MonthPage(
    data: PrayerData, now: State<ZonedDateTime>, month: YearMonth, selectedDate: LocalDate,
    columns: List<Prayer>, ink: BackdropInk, bottomInset: Dp,
    onSelect: (LocalDate) -> Unit, onToday: () -> Unit,
    onOpen: (SheetTopic) -> Unit
) {
    val ui = uiScale()
    val today = data.today
    val hijriOffset = data.settings.hijriOffset
    val haptic = LocalHapticFeedback.current
    // Yesterday, the day and tomorrow, computed in place: three solar days take a few milliseconds, and the card
    // keeps its height while the selection moves (an asynchronous load flashed a placeholder on every tap).
    // The key is the whole calculation identity, so times of another city or date can never stay under a new one.
    val window = remember(selectedDate, data.place, data.params) {
        runCatching {
            dayWindow(PrayerEngine.days(selectedDate.minusDays(1), 3, data.place.coordinates, data.place.zone, data.params))
        }.getOrNull()
    }
    val dayEvents = remember(selectedDate, hijriOffset) { IslamicDays.on(selectedDate, hijriOffset) }
    val nextEvent = remember(selectedDate, hijriOffset) {
        IslamicDays.between(selectedDate.plusDays(1), selectedDate.plusDays(400), hijriOffset)
            .firstOrNull { it.kind != DayKind.SEASON && it.start.isAfter(selectedDate) }
    }
    // After Isha the "next" prayer is tomorrow's Fajr: it is lit in tomorrow's card, not in today's.
    val lit = HomeTimeline.visible(data.window.next, data.fajrEqualsDawn)
        .takeIf { data.window.nextStart.toLocalDate() == selectedDate }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(12f))) {
        MonthCalendar(
            month, selectedDate, today.date, hijriOffset,
            onSelect = { date ->
                if (date != selectedDate) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onSelect(date)
                }
            },
            labelInk = ink.label, fridayInk = ink.friday
        )
        Spacer(Modifier.height(10.dp))
        DayCard(
            date = selectedDate, today = today, hijriOffset = hijriOffset, window = window, columns = columns,
            current = HomeTimeline.current(data.window, data.fajrEqualsDawn), next = lit,
            now = now, events = dayEvents, onOpen = onOpen, onToday = onToday
        )
        nextEvent?.let { NextEventStrip(it, today.date, onOpen, Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(bottomInset))
    }
}

/* ------------------------------------------------------------------------------------------------
 * Таблица: the month as a timetable
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun TablePage(
    month: YearMonth, cache: MonthTimesCache, today: LocalDate, hijriOffset: Int,
    city: String, method: CalculationMethod, bottomInset: Dp,
    focusLabel: String, onToggle: () -> Unit
) {
    LaunchedEffect(month, cache) { cache.ensure(month) }
    val times = cache[month]
    Box(Modifier.fillMaxSize().padding(bottom = bottomInset), contentAlignment = Alignment.Center) {
        if (times == null) Text(tr("Рассчитываем время…"), color = Paper.Ink)
        else {
            val page = remember(times, hijriOffset, city, method, today, L10n.language) {
                calendarPage(times, hijriOffset, city, method, today)
            }
            MonthTable(page, focusLabel, onToggle)
        }
    }
}
