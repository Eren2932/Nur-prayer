package com.nur.prayer.ui.home

import com.nur.prayer.i18n.tr

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.shell.CapsuleRoom
import com.nur.prayer.ui.shell.LocalShell
import com.nur.prayer.ui.shell.PanelTimes
import com.nur.prayer.ui.shell.ShellColors
import com.nur.prayer.ui.shell.ShellGlyph
import com.nur.prayer.ui.shell.ShellIcon
import com.nur.prayer.ui.shell.ShellMath
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime

/*
 * 0.27.0 home: «Капсула» (variant D). The wallpaper owns the screen, as in 0.23.0.
 *
 *  - at the top: the city with the hijri date (0.29.0: no avatar; settings are the gear in the capsule's panel);
 *  - in the middle: «Следующий · Магриб 15:42» and the big countdown;
 *  - right under it, printed on the wallpaper: all six times of the day, the one going on now in
 *    gold. A tap on a time opens its sheet. No separate list to pull out: this is the list;
 *  - at the bottom: the capsule (ShellLayer in NurRoot), the one place all navigation lives.
 *
 * When the capsule opens into the panel, the times step aside (the panel repeats them) and the
 * countdown shrinks and rises just enough to stay in sight above the panel. Both read the shell's
 * progress in draw only: the morph never recomposes home.
 */

/** Text drawn straight on the wallpaper gets a soft shadow so it survives a light picture. */
private val OnSky = Shadow(Color(0x8C000000), blurRadius = 12f)

/** Scale of the countdown while the panel is open (mock: «Отсчёт уменьшился, но остался на виду»). */
private const val CLOCK_OPEN_SCALE = 0.8f

@Composable
fun HomeScreen(
    data: PrayerData,
    now: State<ZonedDateTime>,
    palette: PhasePalette,
    onOpenCity: () -> Unit,
    /** The chip of a feast or a fast: the month calendar, opened plainly. */
    onOpenSchedule: () -> Unit,
    /** A time on the wallpaper: its sheet. */
    onOpenPrayer: (Prayer) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val shell = LocalShell.current
    // Where things are, for the lift of the clock. Plain holders: only the draw pass reads them.
    val geometry = remember { FloatArray(3) { Float.NaN } } // [header bottom, clock top, clock height]
    val next = HomeTimeline.next(data.window, data.fajrEqualsDawn)
    val current = HomeTimeline.current(data.window, data.fajrEqualsDawn)

    Column(modifier.fillMaxSize()) {
        HomeHeader(
            data, onOpenCity,
            Modifier.onGloballyPositioned { geometry[0] = it.boundsInRoot().bottom }
        )
        // 0.19.0: a feast, a night or a fast of the Islamic year, in its colour (nothing on a plain day).
        HomeDayChip(
            data.today.date, data.settings.hijriOffset, onOpen = onOpenSchedule,
            modifier = Modifier.padding(start = ui.s(20f), end = ui.s(20f), top = 8.dp)
        )
        Spacer(Modifier.weight(0.92f))
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = ui.s(16f))
                .onGloballyPositioned {
                    val b = it.boundsInRoot()
                    geometry[1] = b.top
                    geometry[2] = b.height
                }
                .graphicsLayer {
                    val p = (shell?.progress ?: 0f).coerceIn(0f, 1f)
                    if (p <= 0f) {
                        scaleX = 1f; scaleY = 1f; translationY = 0f
                    } else {
                        val s = ShellMath.lerp(1f, CLOCK_OPEN_SCALE, p)
                        transformOrigin = TransformOrigin(0.5f, 0f)
                        scaleX = s
                        scaleY = s
                        val lift = ShellMath.clockLift(
                            clockTop = geometry[1],
                            clockBottomScaled = geometry[1] + geometry[2] * CLOCK_OPEN_SCALE,
                            panelTop = shell?.panelTopInRoot ?: Float.NaN,
                            gap = 22.dp.toPx(),
                            ceiling = geometry[0] + 12.dp.toPx()
                        )
                        translationY = if (lift.isNaN()) 0f else -lift * p
                    }
                },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NextLine(data, next)
            HomeCountdown(data, now, next, Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(ui.s(26f)))
        TimesOnWallpaper(
            data, current, onOpenPrayer,
            Modifier.graphicsLayer {
                val p = (shell?.progress ?: 0f).coerceIn(0f, 1f)
                alpha = (1f - p * 2.2f).coerceIn(0f, 1f)
                translationY = p * 18.dp.toPx()
            }
        )
        Spacer(Modifier.weight(1f))
        // The capsule floats over this room; nothing of home ever hides under it.
        Spacer(Modifier.fillMaxWidth().navigationBarsPadding().height(CapsuleRoom))
    }
}

/** «Следующий · Магриб 15:42». */
@Composable
private fun NextLine(data: PrayerData, next: Prayer) {
    val ui = uiScale()
    val sky = TextStyle(shadow = OnSky)
    val title = PrayerLabels.title(next)
    val at = Format.time(data.window.nextStart)
    Row(
        Modifier.semantics { contentDescription = tr("Следующий: {0}, в {1}", title, at) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(tr("Следующий"), color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.SemiBold, style = sky, maxLines = 1)
        Text("  ·  ", color = TextPrimary.copy(alpha = 0.8f), fontSize = ui.t(17f), fontWeight = FontWeight.SemiBold, style = sky, maxLines = 1)
        Text("$title  $at", color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.SemiBold, style = sky, maxLines = 1)
    }
}

/** The six times, two rows of three, straight on the wallpaper; the one going on now in gold. */
@Composable
private fun TimesOnWallpaper(data: PrayerData, current: Prayer, onOpenPrayer: (Prayer) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val sky = TextStyle(shadow = OnSky)
    Column(modifier.fillMaxWidth().padding(horizontal = ui.s(14f)), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp)) {
        PanelTimes.PRAYERS.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { prayer ->
                    val now = prayer == current
                    val label = PrayerLabels.title(prayer)
                    val time = data.today.times[prayer]?.let(Format::time) ?: "—"
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable(role = Role.Button, onClickLabel = tr("Подробнее")) { onOpenPrayer(prayer) }
                            .semantics { contentDescription = if (now) tr("{0} {1}, сейчас", label, time) else "$label $time" }
                            .padding(vertical = 5.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            label, color = if (now) ShellColors.Gold else TextSecondary,
                            fontSize = ui.t(13f), fontWeight = FontWeight.Medium, style = sky, maxLines = 1
                        )
                        Text(
                            time, color = if (now) ShellColors.Gold else TextPrimary,
                            fontSize = ui.t(17.5f), fontWeight = FontWeight.Bold, maxLines = 1,
                            style = TextStyle(shadow = OnSky, fontFeatureSettings = "tnum")
                        )
                    }
                }
            }
        }
    }
}

/** The city and the hijri date on the right: nothing else at the top (0.29.0: the avatar is gone, settings sit in the panel). */
@Composable
private fun HomeHeader(data: PrayerData, onOpenCity: () -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val sky = TextStyle(shadow = OnSky)
    Row(
        modifier.fillMaxWidth().padding(start = ui.s(14f), end = ui.s(12f), top = 8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Spacer(Modifier.weight(1f))
        Column(
            Modifier
                .weight(3f)
                .clip(RoundedCornerShape(14.dp))
                .clickable(role = Role.Button, onClickLabel = tr("Выбрать город"), onClick = onOpenCity)
                .heightIn(min = 48.dp)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.End
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (data.settings.useDeviceLocation) {
                    ShellIcon(ShellGlyph.LOCATE, TextPrimary, Modifier.size(14.dp))
                    Spacer(Modifier.width(8.dp))
                }
                AutoSizeText(
                    data.place.label, color = TextPrimary, fontSize = ui.t(18f), minFontSize = ui.t(13f),
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.End
                )
            }
            Spacer(Modifier.height(2.dp))
            // 0.19.0: on a feast or a fast the hijri date takes the colour of the day.
            val dayTone = remember(data.today.date, data.settings.hijriOffset) {
                com.nur.prayer.data.IslamicDays.primary(data.today.date, data.settings.hijriOffset)
                    ?.takeIf { it.kind == com.nur.prayer.data.DayKind.FEAST || it.kind == com.nur.prayer.data.DayKind.FAST }
                    ?.let { com.nur.prayer.ui.schedule.DayTone.of(it.kind) }
            }
            Text(
                HijriCalendar.format(data.today.date, data.settings.hijriOffset),
                color = dayTone ?: TextPrimary.copy(alpha = 0.88f), fontSize = ui.t(13f), fontWeight = FontWeight.Medium,
                style = sky, maxLines = 1
            )
        }
    }
}

