package com.nur.prayer

import com.nur.prayer.quran.QuranSearchIndex
import com.nur.prayer.quran.QuranText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The pure parts of 0.18.0: the hifz mask, the folding and the ranking of the in-memory text search. */
class QuranTextSearchTest {
    // «بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ» with a plain alef, as the generator writes it.
    private val basmala = "\u0628\u0650\u0633\u0652\u0645\u0650 \u0627\u0644\u0644\u064E\u0651\u0647\u0650 " +
        "\u0627\u0644\u0631\u064E\u0651\u062D\u0652\u0645\u064E\u0670\u0646\u0650 \u0627\u0644\u0631\u064E\u0651\u062D\u0650\u064A\u0645\u0650"

    @Test fun firstLettersMasksEveryWordButKeepsItsStart() {
        val masked = QuranText.firstLetters(basmala)
        val words = masked.split(' ')
        assertEquals(4, words.size)
        assertTrue(words.all { it.endsWith(QuranText.MASK) })
        assertEquals("\u0628\u0650" + QuranText.MASK, words[0])  // «بِـــ»: the letter keeps its own vowel
        assertFalse("nothing of the rest leaks", masked.contains("\u0645"))
    }

    @Test fun firstLettersKeepsTheArticleWithTheLetterAfterIt() {
        val words = QuranText.firstLetters(basmala).split(' ')
        // «ٱل» is not a letter of the word, it is its article: «ٱلله» opens with «ٱللَّ», not with a lone alef.
        assertTrue(words[1].startsWith("\u0627\u0644"))
        assertTrue(words[1].length > ("\u0627" + QuranText.MASK).length)
    }

    @Test fun aOneLetterWordIsLeftAsItIs() {
        assertEquals("\u0648", QuranText.firstLetters("\u0648"))
    }

    @Test fun foldArabicDropsEveryMarkAndUnifiesNothingElse() {
        assertEquals(
            "\u0628\u0633\u0645 \u0627\u0644\u0644\u0647 \u0627\u0644\u0631\u062D\u0645\u0646 \u0627\u0644\u0631\u062D\u064A\u0645",
            QuranText.foldArabic(basmala)
        )
    }

    @Test fun textQueriesAreNotJumps() {
        assertTrue(QuranSearchIndex.wants("patience"))
        assertTrue(QuranSearchIndex.wants("  \u0635\u0628\u0631 "))
        assertFalse(QuranSearchIndex.wants("ab"))
        assertFalse(QuranSearchIndex.wants("2:255"))
        assertFalse(QuranSearchIndex.wants("114"))
        assertFalse(QuranSearchIndex.wants("p42"))
        assertFalse(QuranSearchIndex.wants("\u0441\u0442\u0440 42"))
    }

    private fun e(s: Int, a: Int, ar: String, tr: String) = QuranSearchIndex.Entry(s.toShort(), a.toShort(), ar, tr.lowercase())

    @Test fun wholeWordsComeBeforeStartsOfWordsAndInsideMatches() {
        val entries = listOf(
            e(2, 153, "", "O you who believe, seek help through patience and prayer"),
            e(3, 200, "", "Be patient and persevere"),
            e(5, 1, "", "patiently waiting"),
            e(7, 1, "", "impatience is a trial")
        )
        val r = QuranSearchIndex.find(entries, "patience")
        assertEquals(4, r.total)
        // the word itself, then the word inside another, then the stem at the start of a word, in mushaf order
        assertEquals(listOf(2 to 153, 7 to 1, 3 to 200, 5 to 1), r.hits.map { it.surah to it.ayah })
        assertTrue(r.hits.none { it.arabic })
    }

    @Test fun theMatchIsMarkedWhereItIs() {
        val text = "seek help through patience and prayer"
        val r = QuranSearchIndex.find(listOf(e(2, 153, "", text)), "Patience")
        val range = r.hits.single().ranges.single()
        assertEquals("patience", text.substring(range.first, range.last + 1))
    }

    @Test fun arabicIsFoundWithoutHarakatAndMarkedInTheFoldedText() {
        val folded = QuranText.foldArabic(basmala)
        val r = QuranSearchIndex.find(listOf(e(1, 1, folded, "")), "\u0627\u0644\u0631\u064E\u0651\u062D\u0652\u0645\u064E\u0670\u0646")
        val hit = r.hits.single()
        assertTrue(hit.arabic)
        assertEquals(9..14, hit.ranges.single())
        // the marks are put back onto the vowelled text by the index; the vowel of the last letter
        // (the kasra of ن) belongs to the word and is highlighted with it
        val moved = QuranSearchIndex.arabicRanges(basmala, hit.ranges).single()
        assertEquals(
            "\u0627\u0644\u0631\u064E\u0651\u062D\u0652\u0645\u064E\u0670\u0646\u0650",
            basmala.substring(moved.first, moved.last + 1)
        )
    }

    @Test fun theAnswerHoldsAHundredAndCountsTheRest() {
        val entries = List(150) { e(2, it + 1, "", "patience in every ayah") }
        val r = QuranSearchIndex.find(entries, "patience")
        assertEquals(100, r.hits.size)
        assertEquals(150, r.total)
    }

    @Test fun aShortQueryFindsNothing() {
        val r = QuranSearchIndex.find(listOf(e(2, 1, "", "patience")), "pa")
        assertTrue(r.hits.isEmpty())
    }
}
