# Nur 0.46.1 — передача исправления CI

База: полный `Nur-prayer_0.46.0.zip` (versionCode 102) из коммита `47eaaf4c1d14d356d220c71fd17a0a652a9fedd3`. Сверен побайтно с архивом из беседы. Диагностика: `logs_124073445750.zip`, шаг `Compile app and every test source set first`, задача `:app:compileDebugKotlin`, `app/src/debug/java/com/nur/prayer/preview/NurPreviews.kt:74:41`. Передан `PhasePalette`, ожидался `(Prayer, Boolean) -> Unit`.

В `NurPreviews.kt` используются именованные аргументы `HomeScreen`, уведомления подключены к неактивному обработчику из `previewActions`. Изменений в коде рабочего экрана, уведомлений и расчёта нет. В `tools/source_audit.py` добавлена регрессия для debug-превью, в `app/build.gradle.kts` и `SettingsScreen.kt` обновлена версия на 0.46.1 (103).

Воспроизведение без Android SDK: новый `python3 tools/source_audit.py` отвергает старый вызов из исходного ZIP и принимает исправленный. Упаковка: `python3 tools/package_source.py --output-dir <пустой каталог вне проекта>`. Это статические проверки, не компиляция Kotlin. Запустить Android CI с новым архивом: загрузить `Nur-prayer_0.46.1.zip` в корень общего репозитория. Сводка выбора должна показать `Nur 0.46.1 (versionCode 103)`; затем проверить компиляцию debug/release и тестовых source set, сборку APK и результаты тестов.
