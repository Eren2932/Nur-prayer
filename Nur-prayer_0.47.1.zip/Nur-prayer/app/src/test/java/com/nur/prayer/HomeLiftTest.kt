package com.nur.prayer

import com.nur.prayer.ui.home.HomeSpec
import org.junit.Assert.assertEquals
import org.junit.Test

/** Geometry retained by the optional BIG layout. */
class HomeLiftTest {
    @Test fun theBigWordIsUntouched() {
        assertEquals(71f, HomeSpec.Big.WEIGHT_TOP, 0f)
        assertEquals(232f, HomeSpec.Big.WEIGHT_BOTTOM, 0f)
    }
}
