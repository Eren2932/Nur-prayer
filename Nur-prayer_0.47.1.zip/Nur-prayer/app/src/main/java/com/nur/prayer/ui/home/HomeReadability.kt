package com.nur.prayer.ui.home

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.material3.LocalTextStyle
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import com.nur.prayer.ui.wallpaper.WallpaperTone
import com.nur.prayer.ui.wallpaper.WallpaperTonePolicy as P

/** Ink and the system icons switch together; never animate white text *through grey* to graphite. */
@Immutable
internal class HomeReadability(tone: WallpaperTone) {
    val paper = P.isPaper(tone)
    val ink = if (paper) Color(P.GRAPHITE) else Color.White
    private val centerWeight = if (paper) 1f else maxOf(P.strength(tone.centerLuminance), tone.brightCenterShare)
    fun quiet(alpha: Float) = ink.copy(alpha = alpha + (1f-alpha) * .52f * centerWeight)
    val topShadow = shadow(tone.topLuminance)
    val centerShadow = shadow(tone.centerLuminance, tone.brightCenterShare)
    private fun shadow(zone: Float, highlights: Float = 0f): Shadow? {
        val a = if (paper) 0f else P.shadow(zone, highlights)
        return if (a == 0f) null else Shadow(Color.Black.copy(alpha = a), Offset(0f, P.SHADOW_Y), P.SHADOW_BLUR)
    }
}

internal val LocalHomeReadability = compositionLocalOf { HomeReadability(P.Night) }

@Composable
internal fun HomeTextShadow(shadow: Shadow?, content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalTextStyle provides LocalTextStyle.current.copy(shadow = shadow), content = content)
}

/** Transparent draw-only sibling ABOVE the blurred image and BELOW every control, including edge-to-edge bars.
 * No input, semantics, blur, extra clock or gesture animation. Brushes are rebuilt only when their inputs change. */
@Composable
internal fun HomeWallpaperExposure(tone: WallpaperTone, progress: () -> Float) {
    val paper = P.isPaper(tone)
    val spec = tween<Float>(P.TRANSITION_MS)
    val top = animateFloatAsState(if (paper) 0f else P.TOP_MAX * P.strength(tone.topLuminance), spec, label = "toneTop")
    val mid = animateFloatAsState(if (paper) 0f else P.CENTER_MAX * P.strength(tone.centerLuminance), spec, label = "toneCenter")
    val foot = animateFloatAsState(if (paper) 0f else P.BOTTOM_MAX * P.strength(tone.bottomLuminance), spec, label = "toneBottom")
    val open = animateFloatAsState(P.openBlack(tone.centerLuminance), spec, label = "toneOpen")
    Box(Modifier.fillMaxSize().drawWithCache {
        val p = progress().coerceIn(0f, 1f)
        if (paper) {
            onDrawBehind { if (p > 0f) drawRect(Color.White, alpha = P.OPEN_WHITE * p) }
        } else {
            val extra = open.value * p
            fun pigment(a: Float) = Color.Black.copy(alpha = a + extra)
            val t = top.value; val m = mid.value; val b = foot.value
            val brush = if (maxOf(t,m,b) + extra == 0f) null else Brush.verticalGradient(
                0f to pigment(t), .20f to pigment(t), .35f to pigment(m), .70f to pigment(m),
                .82f to pigment(b * .86f), 1f to pigment(b))
            onDrawBehind { if (brush != null) drawRect(brush) }
        }
    })
}
