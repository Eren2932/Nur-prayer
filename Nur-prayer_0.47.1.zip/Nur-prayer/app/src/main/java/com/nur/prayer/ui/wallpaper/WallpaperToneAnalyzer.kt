package com.nur.prayer.ui.wallpaper

import android.content.Context
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.platform.LocalContext
import com.nur.prayer.ui.theme.PhasePalette
import java.io.IOException
import java.lang.SecurityException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal object WallpaperToneAnalyzer {
    data class Sky(val zenith: Int, val mid: Int, val horizon: Int, val glow: Int)
    data class Key(val id: String, val size: IntSize, val sky: Sky?)
    private val cache = LruCache<Key, WallpaperTone>(48)
    fun peek(key: Key): WallpaperTone? = cache.get(key)

    suspend fun load(ctx: Context, wall: Wallpaper, key: Key): WallpaperTone? = withContext(Dispatchers.Default) {
        peek(key)?.let { return@withContext it }
        val size = key.size
        if (size.width <= 0 || size.height <= 0) return@withContext null
        val result = when {
            wall.isImage -> try { image(ctx, wall, size) } catch (_: IOException) { null } catch (_: SecurityException) { null }
            key.sky != null -> with(key.sky) { WallpaperTonePolicy.gradient(zenith, mid, horizon, glow, size.width.toFloat()/size.height) }
            else -> WallpaperTonePolicy.Night
        }
        result?.also { cache.put(key, it) }
    }

    private fun image(ctx: Context, wall: Wallpaper, size: IntSize): WallpaperTone? {
        val b = WallpaperImages.boundsOf(ctx, wall) ?: return null
        // Power-of-two decode, bounded even for panoramas. Never decode the full wallpaper to measure it.
        var sample = 1
        while (maxOf(b[0], b[1]).toLong() >= 2L * sample * WallpaperTonePolicy.HEIGHT) sample *= 2
        val raw = WallpaperImages.decodeRaw(ctx, wall, sample) ?: return null
        val w = raw.width; val h = raw.height
        val pixels = try { IntArray(w*h).also { raw.getPixels(it, 0, w, 0, 0, w, h) } } finally { raw.recycle() }
        val fill = if (WallpaperImages.stripsOn(wall, b, size.width, size.height)) WallpaperImages.fill(ctx, wall, b) else null
        return WallpaperTonePolicy.picture(pixels, w, h, b[0], b[1], size.width, size.height, wall.focusX, wall.focusY,
            fill?.pixels, fill?.width ?: 0, fill?.height ?: 0)
    }
}

@Composable
internal fun rememberWallpaperTone(wall: Wallpaper, target: PhasePalette): WallpaperTone {
    val screen by WallpaperScreen.size
    val ctx = LocalContext.current.applicationContext
    // Target, not the 60fps palette tween. The exposure itself has a draw-only animation.
    val sky = if (wall.kind == Wallpaper.Kind.SKY) remember(target) {
        WallpaperToneAnalyzer.Sky(target.zenith.toArgb(), target.mid.toArgb(), target.horizon.toArgb(), target.glow.toArgb())
    } else null
    val key = remember(wall.id, screen, sky) { WallpaperToneAnalyzer.Key(wall.id, screen, sky) }
    // New key = new state object. A cancelled A load cannot overwrite C, even for A→B→C in one reveal.
    var measured by remember(key) { mutableStateOf(WallpaperToneAnalyzer.peek(key)) }
    LaunchedEffect(key) { if (measured == null) measured = WallpaperToneAnalyzer.load(ctx, wall, key) }
    return measured ?: if (wall.light) WallpaperTonePolicy.Paper else WallpaperTonePolicy.Night
}
