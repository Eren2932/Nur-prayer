package com.nur.prayer.ui.home

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs

/** One fraction for finger tracking, settle animation, timer motion and wallpaper softness.
 * Save the destination, never a half-pulled frame. */
@Stable
internal class DayReveal(private val scope: CoroutineScope, initiallyOpen: Boolean) {
    var open by mutableStateOf(initiallyOpen)
        private set
    var progress by mutableFloatStateOf(if (initiallyOpen) 1f else 0f)
        private set
    private var motion: Job? = null

    fun drag(value: Float) {
        motion?.cancel()
        motion = null
        progress = value.coerceIn(0f, 1f)
    }

    fun settle(expand: Boolean) {
        motion?.cancel()
        open = expand
        val end = if (expand) 1f else 0f
        val start = progress
        if (start == end) return
        motion = scope.launch {
            animate(start, end, animationSpec = tween(HomeSpec.Compact.REVEAL_MS, easing = FastOutSlowInEasing)) { value, _ ->
                progress = value
            }
        }
    }
}

@Composable
internal fun rememberDayReveal(enabled: Boolean = true): DayReveal {
    val scope = rememberCoroutineScope()
    return rememberSaveable(enabled, saver = Saver<DayReveal, Boolean>(save = { it.open }, restore = { DayReveal(scope, it) })) {
        DayReveal(scope, false)
    }
}

/** Observe before child clickables; claim only a predominantly vertical drag after touch slop.
 * In a short window the list owns scrolling. Pull down from its top to collapse. */
@Composable
internal fun Modifier.daySwipe(day: DayReveal, list: LazyListState): Modifier {
    val haptic = LocalHapticFeedback.current
    return pointerInput(day, list, haptic) {
        val travel = HomeSpec.Compact.DRAG_DP.dp.toPx()
        val threshold = HomeSpec.Compact.SWIPE_DP.dp.toPx()
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val startedOpen = day.open
            var origin = 0f
            var dragging = false
            var released = false
            var distance = 0f
            try {
                while (true) {
                    val change = awaitPointerEvent(PointerEventPass.Initial).changes.singleOrNull() ?: break
                    if (change.id != down.id || change.isConsumed) break
                    val delta = change.position - down.position
                    if (!change.pressed) {
                        if (dragging) { distance = -delta.y; change.consume(); released = true }
                        break
                    }
                    if (!dragging) {
                        if (maxOf(abs(delta.x), abs(delta.y)) <= viewConfiguration.touchSlop) continue
                        if (abs(delta.y) < abs(delta.x) * 1.3f ||
                            (startedOpen && (delta.y < 0f || list.canScrollBackward)) ||
                            (!startedOpen && delta.y > 0f)) break
                        dragging = true
                        origin = day.progress
                    }
                    distance = -delta.y
                    change.consume()
                    day.drag(origin + distance / travel)
                }
            } finally {
                if (dragging) {
                    val crossed = released && (if (startedOpen) -distance else distance) >= threshold
                    if (crossed) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    day.settle(if (crossed) !startedOpen else startedOpen)
                }
            }
        }
    }
}
