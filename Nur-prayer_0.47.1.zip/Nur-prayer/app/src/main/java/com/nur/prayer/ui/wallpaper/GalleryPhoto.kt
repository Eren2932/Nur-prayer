package com.nur.prayer.ui.wallpaper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.IOException
import java.lang.SecurityException
import java.security.DigestOutputStream
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** The system chooser grants access only to its returned document. Copy a bounded, oriented image
 * into app storage once. No media permission, stale URI grants, raw EXIF or network dependency on launch. */
internal object GalleryPhoto {
    private val idPattern = Regex("photo_[0-9a-f]{64}")
    private const val MAX_SIDE = 2560
    private const val MAX_PIXELS = 3_500_000L
    fun accepts(id: String) = idPattern.matches(id)
    private fun directory(ctx: Context) = File(ctx.filesDir, "wallpaper-photos")
    fun open(ctx: Context, wall: Wallpaper) = if (accepts(wall.id)) File(directory(ctx), wall.id).inputStream()
        else ctx.assets.open(wall.asset)

    suspend fun importPhoto(ctx: Context, uri: Uri): Wallpaper? = withContext(Dispatchers.IO) {
        if (uri.scheme != "content") return@withContext null
        try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            fun stream() = ctx.contentResolver.openInputStream(uri) ?: throw IOException("No photo stream")
            stream().use { BitmapFactory.decodeStream(it, null, options) }
            val w = options.outWidth; val h = options.outHeight
            if (w < 1 || h < 1) return@withContext null
            var s = 1
            while (maxOf(w,h)/s > MAX_SIDE || (w.toLong()/s)*(h.toLong()/s) > MAX_PIXELS) s *= 2
            val orientation = try { stream().use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } }
                catch (_: IOException) { 1 }
            options.inJustDecodeBounds = false
            options.inSampleSize = s
            options.inPreferredConfig = Bitmap.Config.ARGB_8888
            val bitmap = stream().use { BitmapFactory.decodeStream(it, null, options) } ?: return@withContext null
            val dir = directory(ctx); dir.mkdirs()
            val oriented = orient(bitmap, orientation)
            try {
                val tmp = File.createTempFile("incoming-", ".tmp", dir)
                try {
                    val digest = MessageDigest.getInstance("SHA-256")
                    val ok = DigestOutputStream(tmp.outputStream().buffered(), digest).use {
                        @Suppress("DEPRECATION")
                        oriented.compress(Bitmap.CompressFormat.WEBP, 94, it)
                    }
                    if (!ok) return@withContext null
                    val id = "photo_" + digest.digest().joinToString("") { "%02x".format(it) }
                    val dest = File(dir, id)
                    if (!dest.exists() && !tmp.renameTo(dest)) return@withContext null
                    dest.setLastModified(System.currentTimeMillis()) // protect a newly reselected photo from an older prune
                    WallpaperCatalog.find(id)
                } finally { tmp.delete() }
            } finally { oriented.recycle() }
        } catch (_: IOException) { null } catch (_: SecurityException) { null } catch (_: IllegalArgumentException) { null }
    }

    private fun orient(source: Bitmap, exif: Int): Bitmap {
        val m = Matrix()
        when (exif) {
            2 -> m.setScale(-1f,1f)
            3 -> m.setRotate(180f)
            4 -> m.setScale(1f,-1f)
            5 -> { m.setRotate(90f); m.postScale(-1f,1f) }
            6 -> m.setRotate(90f)
            7 -> { m.setRotate(-90f); m.postScale(-1f,1f) }
            8 -> m.setRotate(-90f)
            else -> return source
        }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, m, true).also { if (it !== source) source.recycle() }
    }

    /** Never remove a current/recent file or one a picker might just be committing. */
    suspend fun prune(ctx: Context, keep: List<String>) = withContext(Dispatchers.IO) {
        val cutoff = System.currentTimeMillis() - 86_400_000L
        directory(ctx).listFiles()?.forEach {
            if (it.lastModified() < cutoff && it.name !in keep && (accepts(it.name) || it.name.endsWith(".tmp"))) it.delete()
        }
        Unit
    }
}
