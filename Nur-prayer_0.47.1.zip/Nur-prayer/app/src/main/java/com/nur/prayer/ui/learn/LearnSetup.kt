package com.nur.prayer.ui.learn

import com.nur.prayer.i18n.tr

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.learn.Arabic
import com.nur.prayer.learn.LearnGoal
import com.nur.prayer.learn.LearnLevel
import com.nur.prayer.learn.LearnProfile
import com.nur.prayer.learn.LearnProgress
import com.nur.prayer.learn.Letter
import com.nur.prayer.learn.LetterForm
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/**
 * 0.35.0. First run of the course: why the learner is here, what he already knows, how much time a
 * day. Three short questions on one page with big targets (the course is also for people of 40+),
 * then the path the course will take. Kept on the device only; changeable from the course screen.
 */
@Composable
fun ProfileSetup(
    initial: LearnProfile?,
    accent: Color,
    pathOf: (LearnGoal) -> String,
    onDone: (LearnProfile) -> Unit
) {
    val ui = uiScale()
    var goalId by rememberSaveable { mutableStateOf(initial?.goal?.id) }
    var levelId by rememberSaveable { mutableStateOf(initial?.level?.id) }
    var minutes by rememberSaveable { mutableStateOf(initial?.dailyMinutes ?: LearnProfile.DEFAULT_MINUTES) }
    val goal = LearnGoal.of(goalId)
    val level = LearnLevel.of(levelId)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text(tr("Настроим обучение под вас"), color = TextPrimary, fontSize = ui.t(22f), fontWeight = FontWeight.Bold)
                Gap(4f)
                Text(tr("Три коротких вопроса. Ответы хранятся только на этом телефоне, их можно поменять в любой момент."),
                    color = TextSecondary, fontSize = ui.t(14f), lineHeight = ui.t(20f))
            }
        }
        item { SetupHeading(tr("1. Чего вы хотите достичь?")) }
        LearnGoal.values().forEach { g ->
            item(key = "goal-" + g.id) {
                OptionCard(tr(g.title), tr(g.subtitle), g == goal, accent) { goalId = g.id }
            }
        }
        if (goal == LearnGoal.LANGUAGE) {
            item {
                Text(tr("Учим литературный арабский — фусха. Это язык Корана, книг, новостей и словарей, его понимают во всех арабских странах. Диалекты (египетский и другие) — это разговорный слой поверх него, их лучше учить потом, отдельно."),
                    color = TextTertiary, fontSize = ui.t(13f), lineHeight = ui.t(19f), modifier = Modifier.padding(horizontal = 4.dp))
            }
        }
        item { SetupHeading(tr("2. Что вы уже умеете?")) }
        LearnLevel.values().forEach { l ->
            item(key = "level-" + l.id) {
                OptionCard(tr(l.title), tr(l.subtitle), l == level, accent) { levelId = l.id }
            }
        }
        item { SetupHeading(tr("3. Сколько времени в день?")) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LearnProfile.DAILY_OPTIONS.forEach { m ->
                    val on = m == minutes
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                            .background(if (on) accent.copy(alpha = 0.30f) else SurfaceInset)
                            .pressClick(shape = RoundedCornerShape(16.dp)) { minutes = m }
                            .padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(tr("{0} мин", m), color = if (on) TextPrimary else TextSecondary, fontSize = ui.t(16f), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (goal != null && level != null) {
            item {
                GlassCard(color = accent.copy(alpha = 0.18f)) {
                    Column(Modifier.padding(ui.s(16f))) {
                        Text(tr("ВАШ ПУТЬ"), color = accent, fontSize = ui.t(12f), fontWeight = FontWeight.Bold)
                        Gap(4f)
                        Text(pathOf(goal), color = TextPrimary, fontSize = ui.t(15f), lineHeight = ui.t(22f))
                        Gap(6f)
                        Text(levelAdvice(level), color = TextSecondary, fontSize = ui.t(13f), lineHeight = ui.t(19f))
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                NurButton(tr("Готово"), accent, { if (goal != null && level != null) onDone(LearnProfile(goal, level, minutes)) },
                    Modifier.fillMaxWidth(), primary = true, enabled = goal != null && level != null)
                Gap(12f)
            }
        }
    }
}

private fun levelAdvice(level: LearnLevel): String = when (level) {
    LearnLevel.ZERO -> tr("Начнём с самого начала: как устроено письмо, затем алфавит по порядку — по 2–4 буквы за урок, сразу со слогами.")
    LearnLevel.LETTERS -> tr("Буквы можно не проходить заново: сдайте короткий экзамен — и откроется раздел «Формы букв». Не получится — пройдёте алфавит, это тоже польза.")
    LearnLevel.READER -> tr("Сдайте экзамен на переход — и начнёте сразу с чтения слов. Основы при этом засчитаются.")
    LearnLevel.ADVANCED -> tr("Сдайте экзамен на переход — и начнёте после раздела «Чтение». Основы засчитаются.")
}

@Composable
private fun SetupHeading(text: String) {
    val ui = uiScale()
    Text(text, color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun OptionCard(title: String, subtitle: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val ui = uiScale()
    GlassCard(
        Modifier.pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(20.dp), onClick = onClick),
        corner = 20.dp,
        color = if (selected) accent.copy(alpha = 0.30f) else com.nur.prayer.ui.theme.Glass
    ) {
        Row(Modifier.fillMaxWidth().padding(ui.s(16f)), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Bold)
                Text(subtitle, color = TextSecondary, fontSize = ui.t(13f), lineHeight = ui.t(18f))
            }
            if (selected) { HGap(8f); Text("✓", color = Mint, fontSize = ui.t(20f), fontWeight = FontWeight.Bold) }
        }
    }
}

/** The learner's goal in one line, with a way to change it. */
@Composable
fun ProfileLine(profile: LearnProfile, accent: Color, onChange: () -> Unit) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(tr("Цель: {0}", tr(profile.goal.title)), color = TextSecondary, fontSize = ui.t(13f), modifier = Modifier.weight(1f))
        Text(tr("изменить"), color = accent, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold,
            modifier = Modifier.clip(RoundedCornerShape(50)).pressClick(shape = RoundedCornerShape(50), onClick = onChange)
                .padding(horizontal = 8.dp, vertical = 4.dp))
    }
}

/**
 * 0.35.0. The whole alphabet as one table, in its order, right to left like a Qaida page: four
 * letters a row. A learned letter is marked; a tap opens its card (sound, name, four forms).
 */
@Composable
fun AlphabetTable(progress: LearnProgress, accent: Color, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val voice = rememberVoiceStatus()
    var picked by rememberSaveable { mutableStateOf<String?>(null) }
    val learned = remember(progress) {
        Arabic.LETTERS.filter { (progress.cards[LearnProgress.letterKey(it)]?.box ?: 0) > 0 }.map { it.char }.toSet()
    }
    GlassCard(modifier, corner = 20.dp) {
        Column(Modifier.fillMaxWidth().padding(ui.s(14f))) {
            Text(tr("Алфавит по порядку"), color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.Bold)
            Text(tr("справа налево, от алифа до йа · нажмите на букву"), color = TextTertiary, fontSize = ui.t(12f))
            Gap(10f)
            // Right to left whatever the UI language: the first letter of the alphabet sits on the right.
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Column {
                    Arabic.LETTERS.chunked(4).forEach { row ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            row.forEach { l ->
                                LetterCell(l, l.char in learned, l.char == picked, accent, Modifier.weight(1f)) {
                                    picked = if (picked == l.char) null else l.char
                                }
                            }
                            repeat(4 - row.size) { Box(Modifier.weight(1f)) }
                        }
                    }
                }
            }
            val shown = picked?.let { Arabic.letter(it) }
            if (shown != null) {
                Gap(10f)
                LetterDetail(shown, voice)
            }
        }
    }
}

@Composable
private fun LetterCell(l: Letter, learned: Boolean, selected: Boolean, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    val ui = uiScale()
    val bg = when { selected -> accent.copy(alpha = 0.35f); learned -> Mint.copy(alpha = 0.16f); else -> SurfaceInset }
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(bg)
            .pressClick(scaleTo = 0.95f, shape = RoundedCornerShape(14.dp), onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ArabicText(l.char, 30f)
        Text(l.name, color = if (learned) TextPrimary else TextSecondary, fontSize = ui.t(12f), textAlign = TextAlign.Center)
    }
}

@Composable
private fun LetterDetail(l: Letter, voice: com.nur.prayer.audio.ArabicVoice.Status) {
    val ui = uiScale()
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${l.name} · ${l.sound}", color = TextPrimary, fontSize = ui.t(18f), fontWeight = FontWeight.Bold)
            HGap(8f)
            SpeakButton(com.nur.prayer.audio.VoiceText.letterSound(l), voice, size = 36.dp, label = tr("Звук буквы"))
            SpeakButton(com.nur.prayer.audio.VoiceText.letterName(l), voice, size = 36.dp, label = tr("Название буквы"))
        }
        Gap(6f)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf(LetterForm.FINAL, LetterForm.MEDIAL, LetterForm.INITIAL, LetterForm.ISOLATED).forEach { f ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    ArabicText(Arabic.shape(l, f), 28f)
                    Text(tr(f.title), color = TextTertiary, fontSize = ui.t(11f))
                }
            }
        }
        Gap(6f)
        Text(l.hint, color = TextSecondary, fontSize = ui.t(13f), lineHeight = ui.t(19f), textAlign = TextAlign.Center)
    }
}
