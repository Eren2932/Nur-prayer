package com.nur.prayer.ui.names

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.uiScale
import com.nur.prayer.ui.today.DeedCard
import com.nur.prayer.ui.today.DeedTone
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

internal val NamesJade = Color(0xFF204E40)
private enum class NameFace { INTRO, LIST, READER }

@Composable
internal fun NamesScreen(active: Boolean) {
    val context = LocalContext.current.applicationContext
    val prefs = remember(context) { context.getSharedPreferences("nur_names_reading", Context.MODE_PRIVATE) }
    var seen by remember { mutableStateOf(prefs.getBoolean("introduced", false)) }
    var last by remember { mutableStateOf(prefs.getInt("bookmark_id", 0)) }
    var face by rememberSaveable { mutableStateOf(if (seen) NameFace.LIST else NameFace.INTRO) }
    var opened by rememberSaveable { mutableStateOf(1) }
    var query by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    var rows by remember { mutableStateOf<List<NameEntry>>(emptyList()) }
    var failed by remember { mutableStateOf(false) }
    var attempt by remember { mutableStateOf(0) }
    LaunchedEffect(context, attempt) {
        failed = false
        rows = withContext(Dispatchers.IO) {
            try { context.assets.open(NamesCatalog.ASSET).bufferedReader().use { NamesCatalog.parse(it.readLines()) } }
            catch (_: java.io.IOException) { emptyList() }
            catch (_: IllegalArgumentException) { emptyList() }
        }
        failed = rows.isEmpty()
    }
    val focus = LocalFocusManager.current
    val open: (Int) -> Unit = { id -> focus.clearFocus(); opened = id; face = NameFace.READER }
    BackHandler(active && (face == NameFace.READER || (face == NameFace.INTRO && seen))) { face = NameFace.LIST }
    val area = Modifier.fillMaxSize().padding(top = LocalIslandInset.current, bottom = LocalDockInset.current)
    Crossfade(targetState = face, animationSpec = tween(200), modifier = area, label = "namesFace") { page ->
        when {
            page == NameFace.INTRO -> NamesIntro {
                seen = true; prefs.edit().putBoolean("introduced", true).apply(); face = NameFace.LIST
            }
            rows.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (failed) NameAction(tr("Повторить загрузку"), true) { attempt++ }
                else Text(tr("Загрузка…"), color = Color.White)
            }
            page == NameFace.READER -> key(opened) { NamesReader(rows, opened, onList = { face = NameFace.LIST }, onRead = { id ->
                if (last != id) { last = id; prefs.edit().putInt("bookmark_id", id).apply() }
            }) }
            else -> NamesIndex(rows, listState, query, { query = it }, last, open, { face = NameFace.INTRO })
        }
    }
}

@Composable
internal fun NameAction(label: String, primary: Boolean, enabled: Boolean = true, modifier: Modifier = Modifier,
    onClick: () -> Unit) {
    val ui = uiScale()
    val fill = if (primary) NamesJade else Color(0xFFF0F4EF)
    Box(modifier.background(fill, CircleShape).pressClick(enabled = enabled, shape = CircleShape, onClick = onClick)
        .heightIn(min = 48.dp).padding(horizontal = 14.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
        Text(label, color = if (primary) Color.White else if (enabled) NamesJade else Color(0xFF616A65),
            fontSize = ui.t(13f), lineHeight = ui.t(17f), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun NamesIntro(enter: () -> Unit) {
    val ui = uiScale()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        DeedCard { Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            ArabicText("الأسماء الحسنى", 38f, color = NamesJade)
            Text(tr("99 имён Аллаха"), color = DeedTone.Ink, fontSize = ui.t(27f), lineHeight = ui.t(32f), fontWeight = FontWeight.Bold)
            Text(tr("Откройте имя, прочитайте его смысл и листайте дальше в своём темпе."), color = DeedTone.Quiet, fontSize = ui.t(16f), lineHeight = ui.t(23f))
            NameAction(tr("Открыть имена"), true, modifier = Modifier.fillMaxWidth(), onClick = enter)
        } }
        DeedCard { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tr("Об источниках"), color = NamesJade, fontWeight = FontWeight.Bold)
            Text(tr("В хадисе о 99 именах (аль-Бухари, 2736) нет перечня. Здесь дан традиционный список из энциклопедии TDV; у учёных встречаются и другие перечни."), color = DeedTone.Ink, fontSize = ui.t(14f), lineHeight = ui.t(20f))
            Text(tr("Краткие смыслы даны на русском. Там, где указан аят, его перевод отделён от пояснения."), color = DeedTone.Quiet, fontSize = ui.t(14f), lineHeight = ui.t(20f))
            SourceAction()
        } }
    }
}

@Composable
internal fun SourceAction() {
    val handler = LocalUriHandler.current
    var showUrl by remember { mutableStateOf(false) }
    NameAction(tr("Статья TDV ↗"), false) {
        try { handler.openUri(NamesCatalog.TDV) } catch (_: IllegalArgumentException) { showUrl = true }
    }
    if (showUrl) Text(NamesCatalog.TDV, color = NamesJade)
}

@Composable
private fun NamesIndex(rows: List<NameEntry>, state: LazyListState, query: String, change: (String) -> Unit,
    last: Int, open: (Int) -> Unit, info: () -> Unit) {
    val ui = uiScale(); val visible = remember(rows, query) { NamesCatalog.search(rows, query) }
    LazyColumn(state = state, modifier = Modifier.fillMaxSize().imePadding(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item(key = "intro") { DeedCard { Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(tr("99 имён Аллаха"), color = DeedTone.Ink, fontSize = ui.t(25f), lineHeight = ui.t(30f), fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (last in 1..rows.size) NameAction(tr("Продолжить · {0}", last), true) { open(last) }
                NameAction(tr("О разделе"), false, onClick = info)
            }
            OutlinedTextField(value = query, onValueChange = change, modifier = Modifier.fillMaxWidth(), singleLine = true,
                shape = RoundedCornerShape(16.dp), placeholder = { Text(tr("Имя, смысл или номер"), color = DeedTone.Quiet) },
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = DeedTone.Ink, unfocusedTextColor = DeedTone.Ink,
                    focusedBorderColor = NamesJade, unfocusedBorderColor = Color(0xFF727D76), cursorColor = NamesJade))
        } } }
        if (visible.isEmpty()) item(key = "empty") { DeedCard { Column(Modifier.padding(18.dp)) {
            Text(tr("Ничего не найдено"), color = DeedTone.Ink)
            NameAction(tr("Сбросить поиск"), false) { change("") }
        } } }
        items(visible, key = { it.id }) { item -> DeedCard {
            Row(Modifier.fillMaxWidth().pressClick(onClick = { open(item.id) }).padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(item.id.toString().padStart(2, '0'), color = NamesJade, fontSize = ui.t(13f), fontWeight = FontWeight.Medium)
                Column(Modifier.weight(1f)) {
                    Text(item.reading, fontSize = ui.t(17f), lineHeight = ui.t(21f), color = DeedTone.Ink, fontWeight = FontWeight.SemiBold)
                    Text(item.gloss, fontSize = ui.t(14f), lineHeight = ui.t(19f), color = DeedTone.Quiet)
                }
                ArabicText(item.arabic, 22f, Modifier.weight(.60f), NamesJade)
            }
        } }
    }
}
