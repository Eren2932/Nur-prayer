package com.nur.prayer.ui.names

import java.text.Normalizer
import java.util.Locale

internal data class NameEntry(val id: Int, val sourceRow: Int, val arabic: String, val reading: String,
    val gloss: String, val note: String, val verse: Pair<Int, Int>?) {
    val terms = listOf(arabic, reading, gloss).map(NamesCatalog::fold)
}

internal object NamesCatalog {
    const val ASSET = "names/ru.tsv"
    const val TDV = "https://islamansiklopedisi.org.tr/esma-i-husna"
    fun fold(text: String): String = Normalizer.normalize(text.lowercase(Locale.ROOT).replace('ё','е'), Normalizer.Form.NFD)
        .filter { it.isLetterOrDigit() && it != 'ـ' }

    fun parse(lines: List<String>): List<NameEntry> {
        require(lines.first() == "id\ttdv\tar\treading\tgloss\tnote\tverse")
        val rows = lines.drop(1).filter { it.isNotBlank() }.map { line ->
            val c = line.split('\t'); require(c.size == 7)
            val ref = if (c[6] == "-") null else c[6].split(':').let { it[0].toInt() to it[1].toInt() }
            NameEntry(c[0].toInt(), c[1].toInt(), c[2], c[3], c[4], c[5], ref)
        }
        require(rows.map { it.id } == (1..99).toList() && rows.map { it.sourceRow }.toSet() == (1..99).toSet())
        return rows
    }

    fun search(rows: List<NameEntry>, query: String): List<NameEntry> {
        val q = fold(query); if (q.isEmpty()) return rows
        val n = q.toIntOrNull()
        return rows.filter { row -> row.id == n || row.terms.any { q in it } }
    }
}
