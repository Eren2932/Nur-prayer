#!/usr/bin/env python3
"""Data gate: TDV row IDs, unique Arabic entries, explicit noun forms in the cited verse.
Presence is not a theological proof. Don't infer a name mechanically from a verb.
"""
import csv
import hashlib
import unicodedata
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1] / 'app/src/main/assets'

def read(p):
    with p.open(encoding='utf-8') as f:
        return list(csv.DictReader(f, delimiter='\t', quoting=csv.QUOTE_NONE))

def norm(s):
    return ''.join(c for c in s if unicodedata.category(c) != 'Mn' and c != 'ـ').translate(str.maketrans('أإآٱ','اااا'))

def verify():
    rows = read(ROOT/'names/ru.tsv'); assert len(rows) == 99
    assert [int(r['id']) for r in rows] == list(range(1,100))
    assert {int(r['tdv']) for r in rows} == set(range(1,100))
    for key in ('ar','reading','gloss','note'):
        assert all(r[key].strip() for r in rows)
    assert len({norm(r['ar']) for r in rows}) == len({r['reading'] for r in rows}) == 99
    # Fingerprint of the (table row number, Arabic headword) pairs retrieved from the TDV article.
    # Independent of Nur's display order and the Russian editorial text.
    headwords = ''.join(f"{r['tdv']}\t{r['ar']}\n" for r in sorted(rows, key=lambda r: int(r['tdv'])))
    assert hashlib.sha256(headwords.encode()).hexdigest() == '12d23452e85dfc828562e8b7ba0f849d7bb739bff1342f06ff479c0aeb4f559a'
    forms = {78:'المتعال', 83:'لرءوف'}
    count=0
    for r in rows:
        if r['verse'] == '-': continue
        s,a = map(int,r['verse'].split(':')); v=next(x for x in read(ROOT/f'quran/{s:03d}.tsv') if int(x['ayah']) == a)
        name=norm(r['ar']); bare=name.removeprefix('ال'); ar=norm(v['arabic']); tokens=ar.split()
        choices={name,bare,bare+'ا',forms.get(int(r['id']),name)};choices |= {'و'+t for t in choices}
        assert any((' '+t+' ') in (' '+' '.join(tokens)+' ') for t in choices), (r['reading'],r['verse'],ar)
        assert v['ru'].strip();count+=1
    print(f'99 names / 99 distinct TDV rows; {count} verse links checked against the actual Arabic and Russian assets.')

if __name__=='__main__': verify()
