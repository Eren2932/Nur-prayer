# 0.19.1

versionCode 48. Исправление сборки 0.19.0 (упала на `compileDebugKotlin` / `compileReleaseKotlin`). Функциональность
0.19.0 не менялась.

## Две ошибки компиляции
- `MonthTable.kt:139` — `fontFeatureSettings = "tnum"` передавался прямо в `Text(...)`. У material3 `Text` такого
  параметра нет, это свойство `TextStyle`. Теперь: `style = LocalTextStyle.current.copy(fontFeatureSettings = "tnum")` —
  табличные цифры в колонках времён остаются, шрифт темы не теряется.
- `YearView.kt:95` — `YearHeader(hijriYear, months, range.first < hijriYear, range.last > hijriYear, ...)`.
  Два сравнения подряд в списке аргументов Kotlin читает как аргументы типа `first<hijriYear, range.last>`, отсюда
  каскад из 10 ошибок. Сравнения вынесены в `val hasPrev` / `val hasNext`.

## Чтобы это не повторилось
`tools/kt_sanity.py` (идёт в CI до Gradle) получил две новые проверки:
- **6.** `a < b, c > d` в аргументах вызова — ловушка разбора как generic;
- **7.** именованный аргумент `Text(...)`, которого нет у material3 `Text` (всё прочее — через `style`).
Обе проверки на исходниках 0.19.0 находят ровно эти две строки и не дают ложных срабатываний на остальных 174 файлах.
Тесты к ним — в `tools/test_kt_symbols.py`.

## Проверено без Gradle
- Все 12 статических шагов CI зелёные.
- Логика `IslamicDays` перенесена на Java 21 (`java.time.chrono.HijrahDate`, та же Умм аль-Кура) и прогнана
  по всем утверждениям `IslamicDaysTest` — 39 из 39 совпали.
- `ObservatoryUiTest` компилируется против новой сигнатуры `MonthCalendar` (`onPickMonth` с умолчанием).
