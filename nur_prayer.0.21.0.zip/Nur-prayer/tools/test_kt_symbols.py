import unittest
from kt_symbols import named_arguments, strip_noise

class SymbolParserTests(unittest.TestCase):
    def test_top_level_names_remain_checked(self):
        self.assertEqual(named_arguments("title = name, incorrect = 4"), ["title", "incorrect"])
    def test_nested_calls_are_not_outer_arguments(self):
        self.assertEqual(named_arguments("label, Modifier.padding(top = 12, bottom = 2)"), [])
    def test_lambda_body_is_not_outer_arguments(self):
        self.assertEqual(named_arguments("data = data, actionsFactory = { AppActions(a = 1, b = 2) }"), ["data", "actionsFactory"])
    def test_named_backtick_tests_are_not_symbols(self):
        self.assertNotIn("Moscow", strip_noise("fun `Moscow Fajr regression`() {}"))


from kt_sanity import check_generic_ambiguity, check_compose_text_args

class SanityTrapTests(unittest.TestCase):
    # 0.19.1: the two lines that broke 0.19.0.
    def test_two_comparisons_in_arguments_are_flagged(self):
        self.assertEqual(1, len(check_generic_ambiguity("a.kt", "Header(y, range.first < y, range.last > y, onPick)")))
    def test_generic_types_are_not_flagged(self):
        clean = "val m: Map<String, Int> = x\nfun <A, B> pair(a: A, b: B) = a\nif (a < b && c > d) {}"
        self.assertEqual([], check_generic_ambiguity("a.kt", clean))
    def test_unknown_text_parameter_is_flagged(self):
        clean = "import androidx.compose.material3.Text\nText(t, fontFeatureSettings = 1, maxLines = 1)"
        self.assertEqual(1, len(check_compose_text_args("a.kt", clean)))
    def test_text_with_comparison_and_style_is_clean(self):
        clean = ("import androidx.compose.material3.Text\n"
                 "Text(if (a > b) x else y, style = LocalTextStyle.current.copy(fontFeatureSettings = 1), "
                 "modifier = Modifier.padding(top = 8.dp))")
        self.assertEqual([], check_compose_text_args("a.kt", clean))

if __name__ == "__main__": unittest.main()
