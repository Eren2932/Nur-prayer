package com.nur.prayer.ui.home

import com.nur.prayer.i18n.tr

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.DayNotice
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.data.NoticeStage
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.schedule.DayTone
import com.nur.prayer.ui.schedule.DayWhen
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate

/*
 * 0.19.0 — the Islamic year on the home screen. On an ordinary day nothing is shown. When a feast or a
 * Sunna fast is today, a blessed night begins this evening, a day is three days away or Ramadan is
 * under way, one pill under the date says so in the colour of the calendar; on the day itself its dot
 * breathes. A tap opens the calendar.
 */

/** The sentence of the pill: "Сегодня · Курбан-байрам", "Рамадан · день 12 из 30". */
internal object HomeDayLine {
    fun lead(n: DayNotice, today: LocalDate): String {
        val o = n.occurrence
        return when (n.stage) {
            NoticeStage.TODAY -> if (o.days > 1)
                tr("Сегодня · день {0} из {1}", IslamicDays.daysBetween(o.start, today) + 1, o.days)
                else tr("Сегодня")
            NoticeStage.TONIGHT -> tr("Сегодня вечером")
            NoticeStage.SOON -> DayWhen.countdown(o, today)
            NoticeStage.ONGOING -> tr("День {0} из {1}", IslamicDays.daysBetween(o.start, today) + 1, o.days)
        }
    }
}

@Composable
internal fun HomeDayChip(today: LocalDate, hijriOffset: Int, onOpen: () -> Unit, modifier: Modifier = Modifier) {
    val notice = remember(today, hijriOffset) { IslamicDays.notice(today, hijriOffset) } ?: return
    val ui = uiScale()
    val o = notice.occurrence
    val tone = DayTone.of(o.kind)
    val title = IslamicDayText.title(o.day)
    val lead = HomeDayLine.lead(notice, today)
    val live = notice.stage == NoticeStage.TODAY || notice.stage == NoticeStage.TONIGHT
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .entrance(1, distance = 18f)
            .heightIn(min = 40.dp)
            .clip(shape)
            .background(tone.copy(alpha = if (live) 0.24f else 0.14f))
            .border(1.dp, tone.copy(alpha = if (live) 0.55f else 0.3f), shape)
            .pressClick(scaleTo = 0.97f, onClick = onOpen)
            .semantics(mergeDescendants = true) { contentDescription = "$lead, $title" }
            .testTag("home-day-chip")
            .padding(start = 12.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Pulse(tone, live)
        Spacer(Modifier.width(9.dp))
        Text(lead, color = tone, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(" · ", color = TextSecondary, fontSize = ui.t(13f), maxLines = 1)
        Text(
            title, color = TextPrimary, fontSize = ui.t(13f), fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
        )
        Spacer(Modifier.width(6.dp))
        Glyph(GlyphKind.CHEVRON, TextSecondary, Modifier.size(12.dp))
    }
}

/** The dot; on the day itself a ring breathes out of it. */
@Composable
private fun Pulse(tone: androidx.compose.ui.graphics.Color, live: Boolean) {
    Box(Modifier.size(14.dp), contentAlignment = Alignment.Center) {
        if (live) {
            val t = rememberInfiniteTransition(label = "dayPulse")
            val p = t.animateFloat(
                0f, 1f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "ring"
            )
            Box(
                Modifier.size(14.dp).graphicsLayer {
                    val v = p.value
                    scaleX = 0.5f + v
                    scaleY = 0.5f + v
                    alpha = (1f - v) * 0.7f
                }.clip(CircleShape).background(tone)
            )
        }
        Box(Modifier.size(7.dp).clip(CircleShape).background(tone))
    }
}
