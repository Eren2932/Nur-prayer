package com.nur.prayer.data

import com.nur.prayer.i18n.tr
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/**
 * Hijri date formatting. The platform Umm al-Qura implementation can be one day off compared
 * to a local moon sighting, so the user can shift it in Settings.
 */
object HijriCalendar {

    private val months = arrayOf(
        "мухаррам", "сафар", "раби аль-авваль", "раби ас-сани", "джумада аль-уля",
        "джумада ас-сани", "раджаб", "шаабан", "рамадан", "шавваль", "зуль-када", "зуль-хиджа"
    )

    fun format(date: LocalDate, offsetDays: Int = 0): String {
        val hijri = HijrahDate.from(date.plusDays(offsetDays.toLong()))
        val day = hijri.get(ChronoField.DAY_OF_MONTH)
        val month = hijri.get(ChronoField.MONTH_OF_YEAR)
        val year = hijri.get(ChronoField.YEAR)
        return "$day ${name(month)} $year"
    }

    /** Just the day number, for calendar cells. */
    fun dayOfMonth(date: LocalDate, offsetDays: Int = 0): Int =
        HijrahDate.from(date.plusDays(offsetDays.toLong())).get(ChronoField.DAY_OF_MONTH)

    /** "12 раби аль-авваль", without the year: the year is shown once in the header. */
    fun dayAndMonth(date: LocalDate, offsetDays: Int = 0): String {
        val hijri = HijrahDate.from(date.plusDays(offsetDays.toLong()))
        return "${hijri.get(ChronoField.DAY_OF_MONTH)} ${name(hijri.get(ChronoField.MONTH_OF_YEAR))}"
    }

    /** "раби аль-авваль 1448" for the month header. */
    fun monthAndYear(date: LocalDate, offsetDays: Int = 0): String {
        val hijri = HijrahDate.from(date.plusDays(offsetDays.toLong()))
        return "${name(hijri.get(ChronoField.MONTH_OF_YEAR))} ${hijri.get(ChronoField.YEAR)}"
    }

    /**
     * 0.20.0 — the hijri months a Gregorian span touches, the year said once:
     * "джумада аль-уля — джумада ас-сани 1448", "зуль-хиджа 1447 — мухаррам 1448", "рамадан 1448".
     */
    fun span(first: LocalDate, last: LocalDate, offsetDays: Int = 0): String {
        val a = HijrahDate.from(first.plusDays(offsetDays.toLong()))
        val b = HijrahDate.from(last.plusDays(offsetDays.toLong()))
        val am = a.get(ChronoField.MONTH_OF_YEAR); val ay = a.get(ChronoField.YEAR)
        val bm = b.get(ChronoField.MONTH_OF_YEAR); val by = b.get(ChronoField.YEAR)
        return when {
            am == bm && ay == by -> "${name(am)} $ay"
            ay == by -> "${name(am)} — ${name(bm)} $by"
            else -> "${name(am)} $ay — ${name(bm)} $by"
        }
    }

    fun monthName(month: Int): String = name(month)

    /** Transliterated per language through the catalogs; Russian is the key itself. */
    private fun name(month: Int): String = tr(months[(month - 1).coerceIn(0, 11)])
}
