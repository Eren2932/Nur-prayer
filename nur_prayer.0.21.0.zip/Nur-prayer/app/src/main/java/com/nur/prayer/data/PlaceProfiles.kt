package com.nur.prayer.data

import com.nur.prayer.core.astro.Calibration
import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.RegionalProfile
import com.nur.prayer.core.astro.RegionalProfiles

/**
 * 0.18.6: the automatic profile follows the *region* where a country has more than one muftiate.
 *
 * The core ([RegionalProfiles]) is hash-locked and knows countries only, so every Russian city got
 * «ДУМ РФ». In Tatarstan the authority is ДУМ Республики Татарстан: Kazan mosques pray by its
 * printed calendar, and that calendar is exactly what the Russian profile was calibrated against
 * (15–18.08.2026, 28 of 28 values). So this layer changes the *name and attribution* of the
 * profile for Tatarstan and nothing in the arithmetic: both methods are 18°/15° with the DUM_RT
 * convention and 90 minutes of congregational Fajr. A new regional authority is one line in [BY_REGION].
 */
object PlaceProfiles {

    val TATARSTAN = RegionalProfile(
        method = CalculationMethod.SPIRITUAL_BOARD_TATARSTAN,
        convention = RegionalProfiles.conventionFor(CalculationMethod.SPIRITUAL_BOARD_TATARSTAN),
        calibration = Calibration.PRINTED_CALENDAR,
        note = "ДУМ Республики Татарстан, сверено с календарём ДУМ РТ (Казань) за 15–18.08.2026 (28 из 28 значений)."
    )

    /** (country, region) exactly as in cities_ru.json. */
    private val BY_REGION: Map<Pair<String, String>, RegionalProfile> = mapOf(
        ("Россия" to "Татарстан") to TATARSTAN
    )

    /** The automatic profile of a place: its region's authority if it has one, else its country's. */
    fun forPlace(country: String, region: String?): RegionalProfile =
        region?.let { BY_REGION[country to it] } ?: RegionalProfiles.forCountry(country)

    /** The method list of [RegionalProfiles.methodsFor], with the place's own default on top. */
    fun methodsFor(country: String, region: String?): List<CalculationMethod> =
        (listOf(forPlace(country, region).method) + RegionalProfiles.methodsFor(country)).distinct()
}
