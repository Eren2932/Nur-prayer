package com.nur.prayer.ui

import com.nur.prayer.i18n.AppLanguage
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import java.time.Duration
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle

/**
 * 0.13.0: Russian keeps its hand-written forms (genitive months, lower-case weekdays); every other
 * language takes its names from the platform's CLDR data through java.time, so a new catalog never
 * has to translate a calendar.
 */
object Format {

    private val ru get() = L10n.language == AppLanguage.RU
    private val locale get() = L10n.language.locale

    private val weekdays = arrayOf(
        "понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"
    )
    private val weekdaysShort = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
    private val monthsGenitive = arrayOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )

    fun time(value: ZonedDateTime): String =
        String.format(java.util.Locale.getDefault(), "%02d:%02d", value.hour, value.minute)

    /** "1:04:37" while more than an hour is left, otherwise "04:37". */
    fun countdown(duration: Duration): String {
        val total = CountdownMath.secondsRemaining(duration)
        val hours = total / 3600
        val minutes = (total % 3600) / 60
        val seconds = total % 60
        return if (hours > 0) {
            String.format(java.util.Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    /** "01:28:40": always three fields, so the big home clock never changes width. */
    fun clock(duration: Duration): String {
        val total = CountdownMath.secondsRemaining(duration)
        return String.format(java.util.Locale.US, "%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)
    }

    fun shortCountdown(duration: Duration): String {
        val total = duration.seconds.coerceAtLeast(0)
        val hours = total / 3600
        val minutes = (total % 3600) / 60
        return when {
            hours > 0 -> tr("через {0} ч {1} мин", hours, minutes)
            minutes > 0 -> tr("через {0} мин", minutes)
            else -> tr("меньше минуты")
        }
    }

    fun weekday(date: LocalDate): String =
        if (ru) weekdays[date.dayOfWeek.value - 1] else date.dayOfWeek.getDisplayName(TextStyle.FULL_STANDALONE, locale)

    fun weekdayShort(date: LocalDate): String =
        if (ru) weekdaysShort[date.dayOfWeek.value - 1]
        else date.dayOfWeek.getDisplayName(TextStyle.SHORT_STANDALONE, locale).replaceFirstChar { it.uppercase(locale) }

    fun dayMonth(date: LocalDate): String =
        if (ru) "${date.dayOfMonth} ${monthsGenitive[date.monthValue - 1]}"
        else DateTimeFormatter.ofPattern("d MMMM", locale).format(date)

    fun fullDate(date: LocalDate): String = "${weekday(date)}, ${dayMonth(date)}"

    private val monthsNominative = arrayOf(
        "январь", "февраль", "март", "апрель", "май", "июнь",
        "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь"
    )

    /** "август 2026" for the calendar header. */
    fun monthYear(date: LocalDate): String =
        if (ru) "${monthsNominative[date.monthValue - 1]} ${date.year}"
        else "${date.month.getDisplayName(TextStyle.FULL_STANDALONE, locale)} ${date.year}"

    private val monthsShort = arrayOf(
        "янв.", "февр.", "марта", "апр.", "мая", "июня", "июля", "авг.", "сент.", "окт.", "нояб.", "дек."
    )

    /** 0.19.0: "Ноябрь" — the month alone, capitalised, for the wheel and the table header. */
    fun monthName(month: Int): String {
        val m = month.coerceIn(1, 12)
        val name = if (ru) monthsNominative[m - 1]
            else java.time.Month.of(m).getDisplayName(TextStyle.FULL_STANDALONE, locale)
        return name.replaceFirstChar { it.uppercase(locale) }
    }

    /** "нояб." under the day number of a date badge (the badge already shows the day). */
    fun monthShort(date: LocalDate): String =
        if (ru) monthsShort[date.monthValue - 1]
        else date.month.getDisplayName(TextStyle.SHORT, locale)

    /** Minutes of difference, signed and human: "+2 мин", "-1 мин", "так же". */
    fun signedMinutes(minutes: Long): String = when {
        minutes > 0 -> tr("+{0} мин", minutes)
        minutes < 0 -> tr("{0} мин", minutes)
        else -> tr("без изменений")
    }

    /** "8 ч 42 мин" for a duration of daylight. */
    fun hoursMinutes(duration: Duration): String {
        val total = duration.seconds.coerceAtLeast(0)
        return tr("{0} ч {1} мин", total / 3600, (total % 3600) / 60)
    }
}
