package com.nur.prayer.learn

/** What a lesson drills. The factory turns a plan into concrete exercises with a seeded random. */
sealed interface LessonPlan {
    data class Letters(val fresh: List<Letter>, val known: List<Letter>) : LessonPlan
    data object AlphabetReview : LessonPlan
    data object Joining : LessonPlan
    data class Forms(val form: LetterForm) : LessonPlan
    data object FindLetter : LessonPlan
    data object ShortVowels : LessonPlan
    data object Sukun : LessonPlan
    data object LongVowels : LessonPlan
    data object Shadda : LessonPlan
    data object Tanween : LessonPlan
    data class Reading(val minLetters: Int, val maxLetters: Int) : LessonPlan
    data object SunMoon : LessonPlan
    data class Vocabulary(val topic: String, val words: List<Word>) : LessonPlan
    /** level 1: any letters; 2: look-alike letters; 3: look-alikes in an unvowelled word. */
    data class MissingLetter(val level: Int) : LessonPlan
    data object Assemble : LessonPlan
    data object TranslitToArabic : LessonPlan
    data object Exam : LessonPlan
    data class Surah(val number: Int) : LessonPlan
    /** Spaced repetition of whatever is due today. */
    data object Review : LessonPlan
    /** Test-out: passing it completes every lesson before [stageIndex]. */
    data class Checkpoint(val stageIndex: Int) : LessonPlan
}

data class Lesson(val id: String, val title: String, val subtitle: String, val plan: LessonPlan)

/**
 * A block of lessons. [passCount] lessons must be completed to open the next stage: every lesson
 * for the strict foundations, a reasonable share for the vocabulary, where order is free.
 */
data class Stage(
    val id: String,
    val title: String,
    val subtitle: String,
    val lessons: List<Lesson>,
    val freeOrder: Boolean = false,
    val passCount: Int = lessons.size
)

class Course(val stages: List<Stage>) {
    val lessons: List<Lesson> = stages.flatMap { it.lessons }
    private val byId = lessons.associateBy { it.id }
    private val stageOf: Map<String, Int> = stages.withIndex()
        .flatMap { (i, s) -> s.lessons.map { it.id to i } }.toMap()

    fun lesson(id: String): Lesson? = byId[id] ?: special(id)

    fun stageIndex(lessonId: String): Int = stageOf[lessonId] ?: -1

    fun isStageUnlocked(index: Int, progress: LearnProgress): Boolean =
        index <= 0 || (0 until index).all { stageDone(it, progress) }

    fun stageDone(index: Int, progress: LearnProgress): Boolean {
        val stage = stages[index]
        return stage.lessons.count { progress.isDone(it.id) } >= stage.passCount
    }

    fun isUnlocked(lessonId: String, progress: LearnProgress): Boolean {
        val s = stageOf[lessonId] ?: return lessonId == REVIEW_ID
        if (!isStageUnlocked(s, progress)) return false
        val stage = stages[s]
        if (stage.freeOrder) return true
        val at = stage.lessons.indexOfFirst { it.id == lessonId }
        return at == 0 || progress.isDone(stage.lessons[at - 1].id)
    }

    /** The lesson the "continue" button opens: the first unlocked lesson not yet completed. */
    fun next(progress: LearnProgress): Lesson? =
        lessons.firstOrNull { !progress.isDone(it.id) && isUnlocked(it.id, progress) }

    fun completedCount(progress: LearnProgress): Int = lessons.count { progress.isDone(it.id) }

    private fun special(id: String): Lesson? = when {
        id == REVIEW_ID -> Lesson(REVIEW_ID, "Повторение", "карточки, которым пора", LessonPlan.Review)
        id.startsWith(CHECKPOINT_PREFIX) -> id.removePrefix(CHECKPOINT_PREFIX).toIntOrNull()
            ?.takeIf { it in 1 until stages.size }
            ?.let { Lesson(id, "Экзамен на переход", "к разделу «${stages[it].title}»", LessonPlan.Checkpoint(it)) }
        else -> null
    }

    companion object {
        const val REVIEW_ID = "review"
        const val CHECKPOINT_PREFIX = "checkpoint-"
        private const val CHUNK = 8

        fun checkpointId(stageIndex: Int) = CHECKPOINT_PREFIX + stageIndex

        fun build(lexicon: Lexicon): Course {
            val letters = Arabic.LETTERS
            val alphabet = ArrayList<Lesson>()
            val known = ArrayList<Letter>()
            Arabic.LESSON_GROUPS.forEachIndexed { i, group ->
                val fresh = group.map { c -> letters.first { it.char == c.toString() } }
                alphabet += Lesson("alphabet-${i + 1}", fresh.joinToString(" ") { it.char },
                    fresh.joinToString(", ") { it.name }, LessonPlan.Letters(fresh, known.toList()))
                known += fresh
            }
            alphabet += Lesson("alphabet-review", "Весь алфавит", "28 букв вперемешку", LessonPlan.AlphabetReview)

            val forms = listOf(
                Lesson("forms-join", "Связки", "какие буквы не тянутся вперёд", LessonPlan.Joining),
                Lesson("forms-initial", "Начальная форма", "буква в начале слова", LessonPlan.Forms(LetterForm.INITIAL)),
                Lesson("forms-medial", "Средняя форма", "буква в середине", LessonPlan.Forms(LetterForm.MEDIAL)),
                Lesson("forms-final", "Конечная форма", "буква в конце", LessonPlan.Forms(LetterForm.FINAL)),
                Lesson("forms-find", "Найди букву", "в каком она слове", LessonPlan.FindLetter)
            )
            val vowels = listOf(
                Lesson("vowels-short", "Фатха, касра, дамма", "а, и, у", LessonPlan.ShortVowels),
                Lesson("vowels-sukun", "Сукун", "закрытый слог", LessonPlan.Sukun),
                Lesson("vowels-long", "Долгие гласные", "аа, ии, уу", LessonPlan.LongVowels),
                Lesson("vowels-shadda", "Шадда", "удвоение", LessonPlan.Shadda),
                Lesson("vowels-tanween", "Танвин", "ан, ин, ун", LessonPlan.Tanween)
            )
            val reading = listOf(
                Lesson("reading-short", "Короткие слова", "2–3 буквы", LessonPlan.Reading(2, 3)),
                Lesson("reading-middle", "Слова длиннее", "4–5 букв", LessonPlan.Reading(4, 5)),
                Lesson("reading-article", "Артикль аль-", "солнечные и лунные буквы", LessonPlan.SunMoon),
                Lesson("reading-long", "Длинные слова", "от 6 букв", LessonPlan.Reading(6, 99))
            )
            val vocabulary = Lexicon.TOPICS.filter { it.id != Lexicon.FATIHA }.flatMap { topic ->
                chunks(lexicon.byTopic[topic.id].orEmpty()).mapIndexed { i, part ->
                    Lesson("words-${topic.id}-${i + 1}", "${topic.title} · ${i + 1}", topic.subtitle,
                        LessonPlan.Vocabulary(topic.id, part))
                }
            }
            val mastery = listOf(
                Lesson("master-missing-1", "Какой буквы не хватает", "подставьте букву", LessonPlan.MissingLetter(1)),
                Lesson("master-missing-2", "Похожие буквы", "точки решают всё", LessonPlan.MissingLetter(2)),
                Lesson("master-assemble", "Собери слово", "из букв по порядку", LessonPlan.Assemble),
                Lesson("master-translit", "Из транслита в арабский", "найдите точное написание", LessonPlan.TranslitToArabic),
                Lesson("master-missing-3", "Без огласовок", "как пишут в книгах", LessonPlan.MissingLetter(3)),
                Lesson("master-exam", "Большой экзамен", "всё вперемешку", LessonPlan.Exam)
            )
            val fatihaWords = chunks(lexicon.byTopic[Lexicon.FATIHA].orEmpty()).mapIndexed { i, part ->
                Lesson("quran-fatiha-words-${i + 1}", "Аль-Фатиха: слова · ${i + 1}", "значение каждого слова",
                    LessonPlan.Vocabulary(Lexicon.FATIHA, part))
            }
            val surahs = QuranShort.SURAHS.map { s ->
                Lesson(QuranShort.lessonId(s.number), s.nameRu, "${s.ayatCount} аятов: смысл и пропуски", LessonPlan.Surah(s.number))
            }
            val vocabularyStage = Stage("words", "Словарь", "${lexicon.words.size} слов и фраз по темам", vocabulary,
                freeOrder = true, passCount = minOf(12, vocabulary.size))
            return Course(listOf(
                Stage("alphabet", "Алфавит", "28 букв, звук и написание", alphabet),
                Stage("forms", "Формы букв", "как буква меняется в слове", forms),
                Stage("vowels", "Огласовки", "огласовки, сукун, шадда, танвин", vowels),
                Stage("reading", "Чтение", "от слогов к словам", reading),
                vocabularyStage,
                Stage("mastery", "Мастерство", "пропуски, сборка, письмо без огласовок", mastery),
                Stage("quran", "Коран", "короткие суры по смыслу", fatihaWords + surahs)
            ))
        }

        /** Lessons of eight words; a short tail is folded into the previous lesson. */
        fun chunks(words: List<Word>): List<List<Word>> {
            if (words.isEmpty()) return emptyList()
            val parts = words.chunked(CHUNK).toMutableList()
            if (parts.size > 1 && parts.last().size < CHUNK / 2) {
                val tail = parts.removeAt(parts.lastIndex)
                parts[parts.lastIndex] = parts.last() + tail
            }
            return parts
        }
    }
}
