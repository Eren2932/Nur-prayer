package com.nur.prayer.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.settings.SettingsColors
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale
import androidx.compose.material3.Text

/**
 * 0.18.6 first run: until the user has said where they are, home asks instead of silently showing
 * the times of a guessed city. The system location dialog is offered once on its own (MainActivity);
 * this card stays as the calm way back to it, or to the city list, and leaves as soon as a place
 * is chosen by either route.
 */
@Composable
internal fun FirstPlaceCard(
    visible: Boolean,
    placeLabel: String,
    palette: PhasePalette,
    locating: Boolean,
    status: String?,
    onLocate: () -> Unit,
    onPickCity: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(tween(320, easing = FastOutSlowInEasing)) { -it / 2 } + fadeIn(tween(220)),
        exit = slideOutVertically(tween(220)) { -it / 2 } + fadeOut(tween(160)),
        modifier = modifier
    ) {
        val colors = SettingsColors.of(palette)
        Column(
            Modifier
                .statusBarsPadding()
                .padding(horizontal = ui.s(16f), vertical = ui.s(10f))
                .fillMaxWidth()
                .clip(RoundedCornerShape(ui.s(20f)))
                .background(colors.card)
                .padding(ui.s(16f))
                .testTag("first-place")
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Glyph(GlyphKind.LOCATION, palette.accent, Modifier.size(ui.s(20f)))
                Spacer(Modifier.width(ui.s(10f)))
                Text(tr("Где вы находитесь?"), color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(ui.s(6f)))
            Text(
                status ?: tr("Время намаза зависит от места. Сейчас показан город «{0}».", placeLabel),
                color = TextSecondary, fontSize = ui.t(12.5f), lineHeight = ui.t(17f)
            )
            Spacer(Modifier.height(ui.s(12f)))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(ui.s(10f))) {
                NurButton(
                    text = if (locating) tr("Определяем…") else tr("Определить"),
                    accent = palette.accent,
                    onClick = onLocate,
                    modifier = Modifier.weight(1f),
                    primary = true,
                    enabled = !locating
                )
                NurButton(
                    text = tr("Выбрать город"),
                    accent = palette.accent,
                    onClick = onPickCity,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
