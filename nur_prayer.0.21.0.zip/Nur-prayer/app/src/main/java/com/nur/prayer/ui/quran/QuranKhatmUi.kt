package com.nur.prayer.ui.quran

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.KhatmMath
import com.nur.prayer.quran.KhatmPlan
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.quran.QuranStore
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.HGap
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate
import com.nur.prayer.ui.components.DoneSeal
import com.nur.prayer.ui.learn.textDp

/*
 * 0.18.0 — the khatm card of the table of contents and the sheet that makes and changes the plan.
 * The numbers all come from KhatmPlan (pure, tested); this file only draws them.
 */


private fun today(): Long = LocalDate.now().toEpochDay()

/**
 * The card on top of the surah list. Without a plan it is an invitation; with one — where the
 * reader is against the plan, what today asks, and a button that opens the next page.
 */
@Composable
internal fun KhatmCard(plan: KhatmPlan?, colors: QuranColors, modifier: Modifier, onContinue: (Int) -> Unit, onPlan: () -> Unit) {
    val ui = uiScale()
    val shape = RoundedCornerShape(24.dp)
    if (plan == null) {
        Column(
            modifier.fillMaxWidth().clip(shape).background(colors.card)
                .pressClick(scaleTo = 0.98f, shape = shape, onClick = onPlan).padding(ui.s(16f))
        ) {
            Text(tr("Хатм"), color = colors.accentText, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
            Gap(2f)
            Text(tr("Прочитать Коран за свой срок"), color = colors.text, fontSize = ui.t(18f), fontWeight = FontWeight.Bold)
            Gap(4f)
            Text(
                tr("Выберите срок — норма на день посчитается сама"),
                color = colors.textTertiary, fontSize = ui.t(13f), lineHeight = ui.t(18f)
            )
        }
        return
    }
    val now = today()
    val day = plan.day(now)
    // 0.18.2: «behind» counts only the days that are over. 0.18.0 compared the reader with the end of
    // today and told him «отстаёте на 19 стр.» the moment the plan was made.
    val behind = plan.behind(now)
    val ahead = plan.ahead(now)
    val overdue = plan.overdue(now)
    val doneToday = plan.doneToday(now)
    val status = when {
        plan.finished -> tr("Хатм завершён. Да примет Аллах")
        overdue -> tr("Срок вышел, пересчитайте план")
        behind > 0 -> tr("отстаёте на {0} стр.", behind)
        ahead > 0 -> tr("опережаете на {0} стр.", ahead)
        else -> tr("строго по графику")
    }
    val statusColor = if (!plan.finished && (overdue || behind > 0)) colors.warning else colors.positive
    val expected = plan.expectedPage(now)
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Column(modifier.fillMaxWidth().clip(shape).background(colors.card).padding(ui.s(16f))) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Хатм"), color = colors.accentText, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f))
            Text(tr("день {0} из {1}", day.coerceAtMost(plan.targetDays), plan.targetDays), color = colors.textSecondary,
                fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
        }
        Gap(2f)
        Text(tr("Стр. {0} из {1}", plan.lastPage, KhatmMath.PAGES), color = colors.text, fontSize = ui.t(20f), fontWeight = FontWeight.Bold)
        Gap(10f)
        // The bar is the whole mushaf (604 pages); the tick is where the plan wants the reader to be today.
        val track = colors.hairline
        val fill = colors.accent
        val tick = colors.textSecondary
        val done = plan.lastPage.toFloat() / KhatmMath.PAGES
        val want = expected.toFloat() / KhatmMath.PAGES
        Box(
            Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)).drawBehind {
                drawRect(track)
                val w = size.width * done.coerceIn(0f, 1f)
                drawRect(fill, topLeft = Offset(if (rtl) size.width - w else 0f, 0f), size = Size(w, size.height))
                if (!plan.finished) {
                    val x = size.width * want.coerceIn(0f, 1f)
                    drawRect(tick, topLeft = Offset((if (rtl) size.width - x else x) - 1f, 0f), size = Size(2f, size.height))
                }
            }
        )
        Gap(8f)
        Text(status, color = statusColor, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
        if (!plan.finished) {
            Gap(2f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                // The day's portion closed: the seal of the Rub el Hizb, written in with a short spring.
                if (doneToday) {
                    DoneSeal(colors.positive, textDp(14f))
                    HGap(5f)
                }
                Text(
                    if (doneToday) tr("норма дня выполнена · осталось {0} стр.", plan.pagesLeft)
                    else tr("сегодня {0} из {1} стр. · осталось {2}", plan.readToday(now), plan.goalToday(now), plan.pagesLeft),
                    color = if (doneToday) colors.textSecondary else colors.textTertiary, fontSize = ui.t(12f)
                )
            }
        }
        Gap(12f)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!plan.finished) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(colors.accent)
                        .pressClick(scaleTo = 0.97f, shape = RoundedCornerShape(16.dp)) { onContinue(plan.nextPage) }
                        .padding(horizontal = 14.dp, vertical = 13.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(tr("Продолжить со стр. {0}", plan.nextPage), color = colors.onAccent, fontSize = ui.t(14f),
                        fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
            Box(
                Modifier.clip(RoundedCornerShape(16.dp)).background(colors.raised)
                    .pressClick(scaleTo = 0.97f, shape = RoundedCornerShape(16.dp), onClick = onPlan)
                    .padding(horizontal = 16.dp, vertical = 13.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(tr("План"), color = colors.text, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
        }
    }
}

/**
 * The content of the sheet. Without a plan: term and starting point. With one: where the reader is
 * (and a way to correct it), change of term, or cancelling. The page counted by the reader cannot be
 * wrong forever — it is a number he can set.
 */
@Composable
internal fun KhatmSheet(store: QuranStore, colors: QuranColors, onClose: () -> Unit) {
    val ui = uiScale()
    val plan = store.khatm
    var changing by remember { mutableStateOf(plan == null) }
    if (plan != null && !changing) {
        KhatmManage(store, plan, colors, onChange = { changing = true }, onClose = onClose)
        return
    }
    // A plan made anew from the page the reader stands on keeps what he has read.
    val mark = store.mark
    val markPage = if (mark == null) 0 else QuranMath.pageOf(mark.surah, mark.ayah) - 1
    var days by remember { mutableIntStateOf(plan?.targetDays ?: KhatmMath.PRESETS[2]) }
    var fromMark by remember { mutableStateOf(false) }
    val from = when {
        plan != null -> plan.lastPage.coerceAtMost(KhatmMath.PAGES - 1)
        fromMark -> markPage
        else -> 0
    }
    Text(if (plan == null) tr("План хатма") else tr("Пересчитать план"), color = colors.text, fontSize = ui.t(18f), fontWeight = FontWeight.Bold)
    Gap(4f)
    Text(
        if (plan == null) tr("За сколько дней прочитать Коран? Страницы делятся поровну")
        else tr("Новый срок считается от страницы {0}: прочитанное остаётся за вами.", from),
        color = colors.textTertiary, fontSize = ui.t(13f), lineHeight = ui.t(18f)
    )
    Gap(14f)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (n in KhatmMath.PRESETS) QChip(tr("{0} дн.", n), days == n, colors) { days = n }
    }
    Gap(12f)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Stepper("−", colors, days > KhatmMath.MIN_DAYS) { days = (days - 1).coerceAtLeast(KhatmMath.MIN_DAYS) }
        Text(tr("{0} дн.", days), color = colors.text, fontSize = ui.t(20f), fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
        Stepper("+", colors, days < KhatmMath.MAX_DAYS) { days = (days + 1).coerceAtMost(KhatmMath.MAX_DAYS) }
    }
    if (plan == null && markPage >= 1) {
        Gap(12f)
        // Two long labels: on a 360dp phone in a large font they scroll instead of being cut.
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            QChip(tr("С начала Корана"), !fromMark, colors) { fromMark = false }
            QChip(tr("С моего места (стр. {0})", markPage + 1), fromMark, colors) { fromMark = true }
        }
    }
    Gap(12f)
    Text(
        tr("≈ {0} стр. в день", KhatmMath.dailyPages(from, days)) + " · " + tr("всего {0} стр.", KhatmMath.PAGES - from),
        color = colors.accentText, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold
    )
    Gap(14f)
    SheetButton(if (plan == null) tr("Начать хатм") else tr("Пересчитать"), colors, primary = true) {
        store.startKhatm(days, from, today())
        onClose()
    }
}

@Composable
private fun KhatmManage(store: QuranStore, plan: KhatmPlan, colors: QuranColors, onChange: () -> Unit, onClose: () -> Unit) {
    val ui = uiScale()
    val now = today()
    var text by remember { mutableStateOf("") }
    val page = text.trim().toIntOrNull()?.takeIf { it in plan.startPage..KhatmMath.PAGES }
    Text(tr("Ваш хатм"), color = colors.text, fontSize = ui.t(18f), fontWeight = FontWeight.Bold)
    Gap(4f)
    Text(
        tr("Срок {0} дн. · день {1} · сегодня нужно к стр. {2}", plan.targetDays, plan.day(now).coerceAtMost(plan.targetDays),
            plan.expectedPage(now)),
        color = colors.textTertiary, fontSize = ui.t(13f), lineHeight = ui.t(18f)
    )
    Gap(14f)
    Text(tr("Я дочитал до страницы"), color = colors.textSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
    Gap(8f)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(colors.inset).padding(horizontal = 16.dp, vertical = 14.dp)) {
            if (text.isEmpty()) Text("${plan.lastPage}", color = colors.textTertiary, fontSize = ui.t(20f))
            BasicTextField(
                value = text, onValueChange = { text = it.filter(Char::isDigit).take(3) }, singleLine = true,
                textStyle = TextStyle(color = colors.text, fontSize = ui.t(20f), fontWeight = FontWeight.Bold),
                cursorBrush = SolidColor(colors.accent),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { page?.let { store.moveKhatm(it, now); text = "" } }),
                modifier = Modifier.fillMaxWidth()
            )
        }
        HGap(10f)
        Box(
            Modifier.clip(RoundedCornerShape(16.dp)).background(if (page != null) colors.accent else colors.raised)
                .pressClick(enabled = page != null, scaleTo = 0.96f, shape = RoundedCornerShape(16.dp)) {
                    page?.let { store.moveKhatm(it, now); text = "" }
                }
                .padding(horizontal = 18.dp, vertical = 15.dp)
        ) {
            Text(tr("Сохранить"), color = if (page != null) colors.onAccent else colors.textTertiary, fontSize = ui.t(15f), fontWeight = FontWeight.Bold)
        }
    }
    Gap(8f)
    Text(
        when {
            text.isBlank() -> tr("Если читали по бумажному мусхафу или пролистали")
            page == null -> tr("Такой страницы нет")
            else -> QuranMath.pageStart((page + 1).coerceAtMost(KhatmMath.PAGES)).let { m ->
                "${QuranMath.title(QuranMath.surah(m.surah), L10n.language.code)} ${m.surah}:${m.ayah}"
            }
        },
        color = colors.textTertiary, fontSize = ui.t(12f), lineHeight = ui.t(17f)
    )
    Gap(14f)
    // Cancelling drops the whole plan: the first tap only asks, the second one does it.
    var confirmStop by remember { mutableStateOf(false) }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        QChip(tr("Изменить срок"), false, colors) { confirmStop = false; onChange() }
        QChip(if (confirmStop) tr("Точно отменить?") else tr("Отменить хатм"), confirmStop, colors) {
            if (confirmStop) { store.stopKhatm(); onClose() } else confirmStop = true
        }
    }
}

@Composable
private fun Stepper(label: String, colors: QuranColors, enabled: Boolean, onClick: () -> Unit) {
    val ui = uiScale()
    Box(
        Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(colors.raised)
            .pressClick(enabled = enabled, scaleTo = 0.94f, shape = RoundedCornerShape(16.dp), onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (enabled) colors.text else colors.textTertiary, fontSize = ui.t(22f), fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SheetButton(text: String, colors: QuranColors, primary: Boolean, onClick: () -> Unit) {
    val ui = uiScale()
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (primary) colors.accent else colors.raised)
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(16.dp), onClick = onClick).padding(vertical = 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (primary) colors.onAccent else colors.text, fontSize = ui.t(15f), fontWeight = FontWeight.Bold)
    }
}
