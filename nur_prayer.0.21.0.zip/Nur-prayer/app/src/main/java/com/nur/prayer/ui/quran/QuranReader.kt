package com.nur.prayer.ui.quran

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.max
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.AyahSelection
import com.nur.prayer.quran.HifzMode
import com.nur.prayer.quran.QuranAyah
import com.nur.prayer.quran.QuranIndex
import com.nur.prayer.quran.QuranMark
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.quran.QuranRepository
import com.nur.prayer.quran.QuranStore
import com.nur.prayer.quran.QuranText
import com.nur.prayer.quran.QuranTranslation
import com.nur.prayer.quran.SurahMeta
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.NurSwitch
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.HGap
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import java.time.LocalDate
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.learn.textDp
import com.nur.prayer.ui.theme.ArabicFont

/*
 * The reader, 0.17.0.
 *
 *  • Surahs turn right to left, like the pages of a mushaf: al-Fatiha is the rightmost page and
 *    each next surah lies to its left (QuranMath.mushafPagerReversed). Inside a surah the text
 *    still runs top to bottom.
 *  • The top bar gets out of the way: it slides up while reading down and returns on the first
 *    move back up, at the top of a surah, on a page turn, or when a sheet opens. It carries the
 *    live position («аят 45 из 200 · джуз 3») and a thin progress line; tapping the title opens
 *    «Перейти к аяту».
 *  • Long surahs get a fast-scroll thumb on the edge, with the ayah number beside the finger.
 *  • A tap on the text hides or shows the bar; a long press on an ayah selects it and docks the
 *    actions panel at the bottom (AyahActions.kt, 0.18.2); while it is open a tap on another ayah
 *    stretches the selection to a passage.
 *  • Reading settings live in a bottom sheet: surface, translation, Arabic and translation sizes,
 *    keep the screen on.
 */

/** What the active page tells the top bar. Written by one page at a time — the settled one. */
@Stable
internal class ReaderChrome {
    var shown by mutableStateOf(true)
    var position by mutableFloatStateOf(1f)
    var ayat by mutableIntStateOf(1)
    var atEnd by mutableStateOf(false)
}

@Composable
internal fun QuranReader(
    nav: QuranNav,
    store: QuranStore,
    colors: QuranColors,
    /** Ayat already in the repetition (surah×1000+ayah). */
    reviewed: Set<Int>,
    /** Adds an ayah to the repetition; false when it was already there. */
    onReview: (Int, Int) -> Boolean
) {
    val lang = L10n.language.code
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val pager = rememberPagerState(initialPage = nav.surah - 1) { QuranIndex.SURAH_COUNT }
    val chrome = remember { ReaderChrome() }
    var sheet by rememberSaveable { mutableIntStateOf(SHEET_NONE) }
    val lastSheet = remember { IntArray(1) { SHEET_SETTINGS } }
    var barPx by remember { mutableIntStateOf(0) }
    // 0.18.0 hifz: a mode of the open reader, not a setting — a new session starts as plain reading.
    var hifzOrdinal by rememberSaveable { mutableIntStateOf(HifzMode.OFF.ordinal) }
    val hifz = HifzMode.of(hifzOrdinal)
    // 0.18.2: the selection belongs to the reader, not to a page — its panel sits over the pager.
    var selection by remember { mutableStateOf<AyahSelection?>(null) }
    var actionPx by remember { mutableIntStateOf(0) }
    val actionInset by animateDpAsState(
        if (selection != null) with(density) { actionPx.toDp() } else 0.dp, NurMotion.gentle(), label = "ayahActionInset"
    )

    // The pager is the truth while swiping; the root only hears where it settled.
    LaunchedEffect(pager) {
        var last = -1
        snapshotFlow { pager.settledPage }.collect { page ->
            nav.surah = page + 1
            if (last >= 0 && last != page) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                chrome.shown = true
                selection = null
            }
            last = page
        }
    }
    // A jump from outside (a juz, "2:255", «Перейти к аяту») moves the pager too.
    LaunchedEffect(nav.surah) {
        if (pager.settledPage != nav.surah - 1 && !pager.isScrollInProgress) pager.scrollToPage(nav.surah - 1)
    }

    val hidden by animateFloatAsState(
        if (chrome.shown || sheet != SHEET_NONE) 0f else 1f, NurMotion.gentle(), label = "readerBar"
    )
    // Reading down hides the bar, any move back up brings it back. Only clearly vertical deltas
    // count, so a page turn never toggles it.
    val connection = remember(chrome) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (abs(available.y) > abs(available.x) * 2f) {
                    if (available.y < -BAR_SCROLL_SLOP) chrome.shown = false
                    else if (available.y > BAR_SCROLL_SLOP) chrome.shown = true
                }
                return Offset.Zero
            }
        }
    }
    // Declared first, so an open sheet (its handler is newer) closes before the selection does.
    BackHandler(selection != null) { selection = null }
    BackHandler(sheet != SHEET_NONE) { sheet = SHEET_NONE }
    SideEffect { if (sheet != SHEET_NONE) lastSheet[0] = sheet }
    val topInset = with(density) { barPx.toDp() }

    Box(Modifier.fillMaxSize().clipToBounds()) {
        HorizontalPager(
            state = pager,
            reverseLayout = QuranMath.mushafPagerReversed(rtl),
            // The neighbours are composed ahead, so a page turn never lands on «Загружаем…».
            beyondViewportPageCount = 1,
            key = { it + 1 },
            // A selection is anchored to its surah: no page turn while the panel is open.
            userScrollEnabled = selection == null,
            modifier = Modifier.fillMaxSize().nestedScroll(connection)
        ) { page ->
            val number = page + 1
            Box(
                Modifier.fillMaxSize().graphicsLayer {
                    // The page being left dims and settles back a little; the page coming in rises.
                    val distance = abs((pager.currentPage - page) + pager.currentPageOffsetFraction).coerceIn(0f, 1f)
                    alpha = 1f - PAGE_FADE * distance
                    val scale = 1f - PAGE_SHRINK * distance
                    scaleX = scale
                    scaleY = scale
                }
            ) {
                SurahPage(
                    surah = QuranMath.surah(number),
                    store = store,
                    lang = lang,
                    colors = colors,
                    chrome = chrome,
                    active = pager.settledPage == page,
                    hifz = hifz,
                    selection = selection,
                    onSelection = { selection = it },
                    actionInset = actionInset,
                    actionPx = if (selection != null) actionPx else 0,
                    topInset = topInset,
                    jumpTo = if (nav.surah == number) nav.jump else 0,
                    onJumpDone = { if (nav.surah == number) nav.jump = 0 },
                    onPrev = { if (page > 0) scope.launchPage(pager, page - 1) },
                    onNext = { if (page < QuranIndex.SURAH_COUNT - 1) scope.launchPage(pager, page + 1) }
                )
            }
        }
        ReaderBar(
            surahNumber = pager.currentPage + 1,
            lang = lang,
            colors = colors,
            chrome = chrome,
            showReading = store.showReading,
            hifz = hifz,
            onHifz = { hifzOrdinal = it.ordinal; chrome.shown = true },
            onBack = { nav.contents() },
            onReading = { store.setReading(!store.showReading) },
            onTitle = { sheet = SHEET_GOTO },
            onSettings = { sheet = if (sheet == SHEET_SETTINGS) SHEET_NONE else SHEET_SETTINGS },
            modifier = Modifier.onSizeChanged { barPx = it.height }.graphicsLayer { translationY = -hidden * size.height }
        )
        AyahActionPanel(
            selection = selection,
            store = store,
            lang = lang,
            colors = colors,
            reviewed = reviewed,
            onReview = onReview,
            onClear = { selection = null },
            onHeight = { actionPx = it }
        )
        ReaderSheet(visible = sheet != SHEET_NONE, colors = colors, onDismiss = { sheet = SHEET_NONE }) {
            val kind = if (sheet != SHEET_NONE) sheet else lastSheet[0]
            if (kind == SHEET_GOTO) {
                GoToAyah(nav.surah, lang, colors) { mark ->
                    sheet = SHEET_NONE
                    nav.jump = mark.ayah
                    nav.surah = mark.surah
                }
            } else {
                ReaderSettings(store, lang, colors)
            }
        }
    }
}

private fun CoroutineScope.launchPage(pager: PagerState, page: Int) {
    launch { pager.animateScrollToPage(page, animationSpec = NurMotion.gentle()) }
}

// ── top bar ──────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun ReaderBar(
    surahNumber: Int,
    lang: String,
    colors: QuranColors,
    chrome: ReaderChrome,
    showReading: Boolean,
    hifz: HifzMode,
    onHifz: (HifzMode) -> Unit,
    onBack: () -> Unit,
    onReading: () -> Unit,
    onTitle: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier
) {
    val ui = uiScale()
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val s = QuranMath.surah(surahNumber)
    Column(modifier.fillMaxWidth().background(colors.bar)) {
        Row(
            Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = ui.s(16f), vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIconButton(GlyphKind.BACK, tr("Оглавление"), onBack, tint = colors.text, background = colors.raised)
            HGap(10f)
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(12.dp), onClick = onTitle)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                AnimatedContent(
                    targetState = surahNumber,
                    transitionSpec = {
                        // The next surah lies to the left, so its title comes in from the left.
                        val forward = targetState > initialState
                        (slideInHorizontally(NurMotion.gentle()) { w: Int -> if (forward) -w / 3 else w / 3 } + fadeIn(tween(180))) togetherWith
                            (slideOutHorizontally(NurMotion.gentle()) { w: Int -> if (forward) w / 3 else -w / 3 } + fadeOut(tween(120)))
                    },
                    label = "readerTitle"
                ) { n ->
                    Text(QuranMath.title(QuranMath.surah(n), lang), color = colors.text, fontSize = ui.t(20f),
                        fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                val ayah = chrome.position.toInt().coerceIn(1, s.ayat)
                Text(
                    tr("аят {0} из {1}", ayah, s.ayat) + " · " + tr("джуз {0}", QuranMath.juzOf(s.number, ayah)) +
                        " · " + tr("стр. {0}", QuranMath.pageOf(s.number, ayah)),
                    color = colors.textTertiary, fontSize = ui.t(12f), maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            HGap(8f)
            RoundIconButton(GlyphKind.SLIDERS, tr("Настройки чтения"), onSettings, tint = colors.text, background = colors.raised)
        }
        // Reading aids: a row of its own, so the title keeps its width on a narrow phone.
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = ui.s(16f)).padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            QChip(tr("Транслит"), showReading, colors, onReading)
            QChip(tr("Хифз"), hifz != HifzMode.OFF, colors) { onHifz(if (hifz == HifzMode.OFF) HifzMode.FIRST_LETTERS else HifzMode.OFF) }
            if (hifz != HifzMode.OFF) {
                QChip(tr("Первые буквы"), hifz == HifzMode.FIRST_LETTERS, colors) { onHifz(HifzMode.FIRST_LETTERS) }
                QChip(tr("Без арабского"), hifz == HifzMode.HIDE_ARABIC, colors) { onHifz(HifzMode.HIDE_ARABIC) }
                QChip(tr("Без перевода"), hifz == HifzMode.HIDE_TRANSLATION, colors) { onHifz(HifzMode.HIDE_TRANSLATION) }
            }
        }
        val track = colors.hairline
        val fill = colors.accent
        Box(
            Modifier.fillMaxWidth().height(2.dp).drawBehind {
                drawRect(track)
                val w = size.width * QuranMath.surahProgress(chrome.position, chrome.ayat, chrome.atEnd)
                drawRect(fill, topLeft = Offset(if (rtl) size.width - w else 0f, 0f), size = Size(w, size.height))
            }
        )
    }
}

@Composable
internal fun QChip(text: String, selected: Boolean, colors: QuranColors, onClick: () -> Unit) {
    val ui = uiScale()
    val background = if (selected) colors.accent.copy(alpha = 0.26f) else colors.raised
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(background)
            .pressClick(scaleTo = 0.96f, shape = RoundedCornerShape(50), onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp)
    ) {
        Text(text, color = if (selected) colors.text else colors.textSecondary, fontSize = ui.t(13f),
            fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** A chevron drawn in absolute screen terms — the mushaf direction does not flip with the UI language. */
@Composable
internal fun MushafChevron(color: Color, pointsLeft: Boolean, modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val stroke = w * 0.14f
        val tail = if (pointsLeft) w * 0.66f else w * 0.34f
        val tip = if (pointsLeft) w * 0.30f else w * 0.70f
        drawLine(color, Offset(tail, h * 0.16f), Offset(tip, h * 0.5f), stroke, StrokeCap.Round)
        drawLine(color, Offset(tip, h * 0.5f), Offset(tail, h * 0.84f), stroke, StrokeCap.Round)
    }
}

// ── one surah ────────────────────────────────────────────────────────────────────────────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SurahPage(
    surah: SurahMeta,
    store: QuranStore,
    lang: String,
    colors: QuranColors,
    chrome: ReaderChrome,
    active: Boolean,
    hifz: HifzMode,
    selection: AyahSelection?,
    onSelection: (AyahSelection?) -> Unit,
    /** Room the actions panel takes at the bottom, animated; 0 without a selection. */
    actionInset: Dp,
    /** The panel's measured height in px, for bringing the selected ayah above it. */
    actionPx: Int,
    topInset: Dp,
    jumpTo: Int,
    onJumpDone: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    val ui = uiScale()
    val context = LocalContext.current
    val repo = remember { QuranRepository.get(context) }
    val ayat by produceState(repo.cached(surah.number), surah.number) { value = repo.surah(surah.number) }
    // Read with the page, not when «Первые буквы» is switched on: the masks never redraw a moment later.
    LaunchedEffect(Unit) { repo.loadHifzParticles() }
    val particles = repo.hifzParticles ?: emptyMap()
    val list = rememberLazyListState()
    val translation = store.translation(lang)
    val latin = QuranMath.latinReading(lang)
    val arabicSize = QuranStore.SIZES[store.arabicSize]
    val translationSize = QuranStore.TRANSLATION_SIZES[store.translationSize]
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val ayahActionsLabel = tr("Действия с аятом")
    // Only this surah's part of the reader's selection concerns this page.
    val mine = selection?.takeIf { it.surah == surah.number }
    var flash by remember { mutableIntStateOf(0) }
    // Ayat the reader opened by a tap in hifz mode; a new mode starts with everything closed again.
    var revealed by remember(hifz) { mutableStateOf(emptySet<Int>()) }

    // Jump: header is item 0, ayah n is item n. The ayah lands right under the bar and glows once.
    LaunchedEffect(ayat, jumpTo) {
        val loaded = ayat ?: return@LaunchedEffect
        if (jumpTo > 0 && loaded.isNotEmpty()) {
            val n = jumpTo.coerceIn(1, loaded.size)
            list.scrollToItem(n)
            flash = surah.number * 1000 + n
            onJumpDone()
        }
    }
    // Bookmark: the ayah under the reading line, once the reader stops on it.
    LaunchedEffect(active, ayat) {
        if (!active || ayat.isNullOrEmpty()) return@LaunchedEffect
        snapshotFlow { list.firstVisibleItemIndex }.collectLatest { i ->
            delay(700)
            store.saveMark(QuranMark(surah.number, i.coerceIn(1, surah.ayat)))
        }
    }
    // Khatm: pages are credited to the plan once the reader stays on them. Only the reading that
    // follows on from the plan counts (KhatmPlan.credited), so a jump through the book credits nothing.
    val tracking = store.khatm?.finished == false
    LaunchedEffect(active, ayat, tracking) {
        if (!active || !tracking || ayat.isNullOrEmpty()) return@LaunchedEffect
        snapshotFlow { list.finishedAyah(surah.ayat) }.collectLatest { done ->
            if (done < 1) return@collectLatest
            delay(KHATM_DWELL_MILLIS)
            store.creditKhatm(QuranMath.pagesCompleted(surah.number, done), LocalDate.now().toEpochDay())
        }
    }
    // Live position for the bar, and the bar comes back at the top of a surah.
    LaunchedEffect(active, ayat) {
        if (!active || ayat.isNullOrEmpty()) return@LaunchedEffect
        chrome.ayat = surah.ayat
        snapshotFlow {
            Triple(
                QuranMath.readingPosition(list.firstVisibleItemIndex, list.firstItemFraction(), surah.ayat),
                !list.canScrollForward,
                list.firstVisibleItemIndex == 0 && list.firstVisibleItemScrollOffset < TOP_REVEAL_PX
            )
        }.collect { (position, atEnd, atTop) ->
            chrome.position = position
            chrome.atEnd = atEnd
            if (atTop) chrome.shown = true
        }
    }
    // The ayah just selected (or the end the selection was stretched to) is brought into view above
    // the actions panel: a long ayah shows from its top, a short one is lifted only as far as needed.
    val focusKey = mine?.focus ?: 0
    LaunchedEffect(focusKey, actionPx) {
        if (!active || focusKey == 0 || actionPx == 0) return@LaunchedEffect
        list.reveal(index = focusKey, coverPx = actionPx, gapPx = with(density) { 12.dp.roundToPx() })
    }

    val loaded = ayat
    if (loaded == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(tr("Загружаем…"), color = colors.textSecondary) }
        return
    }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        // Lines longer than ~70 characters tire the eye: on tablets the text keeps a book's measure.
        val side = max(ui.s(10f), (maxWidth - READER_MAX_WIDTH) / 2)
        // While the actions panel is open, the end of the surah can still scroll out from under it.
        // The room grows at once (a longer padding moves nothing on screen, and reveal() below must
        // already be able to lift the last ayah above the panel) and shrinks with the panel's spring,
        // so closing it at the very end of a surah does not drop the text with a jump.
        val panelRoom = if (actionPx > 0) with(density) { actionPx.toDp() } else 0.dp
        val bottom = LocalDockInset.current + 24.dp + max(actionInset, panelRoom)
        LazyColumn(
            Modifier.fillMaxSize(),
            state = list,
            contentPadding = PaddingValues(start = side, end = side, top = topInset + 10.dp, bottom = bottom)
        ) {
            item(key = "head") { SurahHeader(surah, lang, store.showReading, latin, colors) }
            items(loaded, key = { it.key }) { a ->
                val key = a.key
                val picked = mine != null && key in mine
                AyahItem(
                    a = a,
                    translation = translation,
                    showReading = store.showReading,
                    latin = latin,
                    arabicSize = arabicSize,
                    translationSize = translationSize,
                    colors = colors,
                    selected = picked,
                    flashing = flash == key,
                    bookmarked = store.isBookmarked(key),
                    hifz = hifz,
                    particles = particles,
                    revealed = key in revealed,
                    onFlashDone = { if (flash == key) flash = 0 },
                    modifier = Modifier.combinedClickable(
                        onLongClickLabel = ayahActionsLabel,
                        // With a selection open a tap shapes it (stretch, pull back, close); otherwise in
                        // hifz mode it opens or closes the ayah, and in plain reading it shows or hides the bar.
                        onClick = {
                            when {
                                selection != null -> {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onSelection(selection.tap(surah.number, a.number))
                                }
                                hifz != HifzMode.OFF -> revealed = if (key in revealed) revealed - key else revealed + key
                                else -> chrome.shown = !chrome.shown
                            }
                        },
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onSelection(AyahSelection.press(selection, surah.number, a.number))
                        }
                    )
                )
            }
            item(key = "foot") { PageFooter(surah.number, lang, colors, onPrev, onNext) }
        }
        FastScroller(list, surah.ayat, colors, topInset, bottom)
    }
}

/**
 * The last ayah the reader has fully passed: the lowest one completely above the bottom of the list
 * (the one cut by the edge is still being read), or the last ayah of the surah once its foot is in
 * view. 0 while nothing is laid out. An ayah taller than the screen counts as soon as the next one
 * shows under it.
 */
private fun LazyListState.finishedAyah(ayat: Int): Int {
    val info = layoutInfo
    if (info.visibleItemsInfo.isEmpty()) return 0
    if (!canScrollForward) return ayat
    val last = info.visibleItemsInfo.lastOrNull { it.index in 1..ayat } ?: return 0
    val bottom = info.viewportEndOffset - info.afterContentPadding
    return if (last.offset + last.size <= bottom) last.index else last.index - 1
}

/** First visible item's share already scrolled past the reading line, 0..1. */
private fun LazyListState.firstItemFraction(): Float {
    val first = firstVisibleItemIndex
    val info = layoutInfo.visibleItemsInfo.firstOrNull { it.index == first } ?: return 0f
    return if (info.size > 0) firstVisibleItemScrollOffset.toFloat() / info.size else 0f
}

/**
 * 0.18.2. Scrolls the least that shows item [index] between the top of the list (under the bar) and
 * the top of the actions panel ([coverPx] high). An item taller than that space shows from its top —
 * the reader starts an ayah at its beginning. An item out of the laid-out window is scrolled to.
 */
private suspend fun LazyListState.reveal(index: Int, coverPx: Int, gapPx: Int) {
    val info = layoutInfo
    val item = info.visibleItemsInfo.firstOrNull { it.index == index }
    if (item == null) { animateScrollToItem(index); return }
    // Item offsets count from the end of the top content padding: 0 is the line under the bar.
    val top = gapPx
    val bottom = info.viewportEndOffset - coverPx - gapPx
    val itemTop = item.offset
    val itemBottom = item.offset + item.size
    val delta = when {
        itemTop < top -> (itemTop - top).toFloat()
        itemBottom > bottom -> minOf(itemBottom - bottom, itemTop - top).toFloat()
        else -> 0f
    }
    if (delta != 0f) animateScrollBy(delta, NurMotion.gentle())
}

@Composable
private fun SurahHeader(s: SurahMeta, lang: String, showReading: Boolean, latin: Boolean, colors: QuranColors) {
    val ui = uiScale()
    Column(
        Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(26.dp)).background(colors.card)
            .padding(horizontal = ui.s(16f), vertical = ui.s(20f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(tr("Сура {0} из {1}", s.number, QuranIndex.SURAH_COUNT), color = colors.textTertiary, fontSize = ui.t(12f))
        Gap(4f)
        ArabicText(s.arabic, 34f, color = colors.text)
        val meaning = QuranMath.meaning(s, lang)
        if (meaning.isNotEmpty()) Text("«$meaning»", color = colors.textSecondary, fontSize = ui.t(14f), textAlign = TextAlign.Center)
        Gap(4f)
        Text(
            (if (s.medinan) tr("Мединская") else tr("Мекканская")) + " · " + tr("аятов: {0}", s.ayat) + " · " +
                tr("джуз {0}", QuranMath.juzOf(s.number, 1)),
            color = colors.textTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center
        )
        Gap(12f)
        Ornament(colors)
        if (QuranMath.showsBasmala(s.number)) {
            Gap(12f)
            ArabicText(BASMALA, 24f, color = colors.accentText)
            AnimatedVisibility(showReading) {
                Text(if (latin) BASMALA_LATIN else BASMALA_CYR, color = colors.textTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center)
            }
        } else if (s.number == 9) {
            Gap(10f)
            Text(tr("Сура читается без басмалы"), color = colors.textTertiary, fontSize = ui.t(12f), textAlign = TextAlign.Center)
        }
    }
}

/** ── ۞ ── : the mushaf's rub' sign between two hairlines. */
@Composable
internal fun Ornament(colors: QuranColors) {
    val ui = uiScale()
    val line = colors.accent.copy(alpha = 0.35f)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(48.dp).height(1.dp).background(line))
        Text("  ۞  ", color = colors.accent, fontSize = ui.t(16f), fontFamily = ArabicFont.family)
        Box(Modifier.width(48.dp).height(1.dp).background(line))
    }
}

/** ─── Страница 42 ─── : where a page of the Madani mushaf begins. */
@Composable
private fun PageDivider(page: Int, colors: QuranColors) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(top = 14.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f).height(1.dp).background(colors.hairline))
        Text(tr("Страница {0}", page), color = colors.textTertiary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 12.dp))
        Box(Modifier.weight(1f).height(1.dp).background(colors.hairline))
    }
}

/** ۞ Хизб 5 / ۞ ¼ хизба 5: the quarter of a hizb that begins here (quarter 0 is the start of hizb 1). */
@Composable
private fun HizbMark(quarter: Int, colors: QuranColors) {
    val ui = uiScale()
    val hizb = quarter / 4 + 1
    val fraction = QuranMath.quarterFraction(quarter)
    val label = if (fraction.isEmpty()) tr("Хизб {0}", hizb) else tr("{0} хизба {1}", fraction, hizb)
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("۞ $label", color = colors.accentText, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun AyahItem(
    a: QuranAyah,
    translation: QuranTranslation?,
    showReading: Boolean,
    latin: Boolean,
    arabicSize: Float,
    translationSize: Float,
    colors: QuranColors,
    selected: Boolean,
    flashing: Boolean,
    bookmarked: Boolean,
    hifz: HifzMode,
    particles: Map<String, Int>,
    revealed: Boolean,
    onFlashDone: () -> Unit,
    modifier: Modifier
) {
    val ui = uiScale()
    val juzStart = QuranMath.juzStartingAt(a.surah, a.number)
    val pageStart = QuranMath.pageStartingAt(a.surah, a.number)
    val quarterStart = QuranMath.quarterStartingAt(a.surah, a.number)
    // Hifz: what is hidden depends on the mode. The reading (transliteration) would give the Arabic
    // away, so it hides with it; the translation is the cue and stays, except in its own mode.
    val masked = hifz != HifzMode.OFF && !revealed
    val firstLetters = masked && hifz == HifzMode.FIRST_LETTERS
    val hideArabic = masked && hifz == HifzMode.HIDE_ARABIC
    val hideTranslation = masked && hifz == HifzMode.HIDE_TRANSLATION
    val hideReading = masked && hifz != HifzMode.HIDE_TRANSLATION
    val glow = remember { Animatable(0f) }
    LaunchedEffect(flashing) {
        if (flashing) {
            glow.snapTo(1f)
            glow.animateTo(0f, tween(FLASH_MILLIS, delayMillis = FLASH_HOLD_MILLIS))
            onFlashDone()
        }
    }
    val pick by animateFloatAsState(if (selected) 1f else 0f, NurMotion.snappy(), label = "ayahPick")
    val tint = colors.accent
    // The ayah number closes the ayah as in the mushaf, in Arabic-Indic digits, kept on the last word.
    // On paper the ornament gold is too pale for a digit; its ink is used instead.
    val accent = if (colors.light) colors.accentText else colors.accent
    val quiet = colors.textTertiary
    val arabic = remember(a.key, a.arabic, accent, quiet, firstLetters, particles) {
        buildAnnotatedString {
            if (firstLetters) {
                // The hidden rest of a word is a quiet kashida bar the kept letters join onto, as long
                // as the letters it stands for: the hafiz sees where a word is short and where long.
                for (part in QuranText.firstLetterParts(a.arabic, particles)) {
                    if (part.hidden) withStyle(SpanStyle(color = quiet)) { append(part.text) } else append(part.text)
                }
            } else append(a.arabic)
            append("\u00A0\u00A0")
            withStyle(SpanStyle(color = accent)) { append(QuranMath.arabicDigits(a.number)) }
        }
    }
    Column(Modifier.fillMaxWidth()) {
        if (pageStart > 0) PageDivider(pageStart, colors)
        if (quarterStart >= 0) HizbMark(quarterStart, colors)
        Column(
            modifier.fillMaxWidth()
                .drawBehind {
                    val alpha = maxOf(glow.value, pick) * HIGHLIGHT_ALPHA
                    if (alpha > 0f) drawRoundRect(tint.copy(alpha = alpha), cornerRadius = CornerRadius(18.dp.toPx()))
                    // A selected ayah also gets a gold edge on its reading side, so a passage of
                    // several reads as one block even on the sky surface.
                    if (pick > 0f) {
                        val w = 3.dp.toPx()
                        val inset = 14.dp.toPx() * (1f - pick) + 10.dp.toPx()
                        val x = if (layoutDirection == LayoutDirection.Rtl) size.width - w else 0f
                        drawRoundRect(tint.copy(alpha = pick), Offset(x, inset), Size(w, size.height - 2 * inset),
                            CornerRadius(w / 2))
                    }
                }
                .padding(horizontal = 12.dp, vertical = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(colors.inset).padding(horizontal = 10.dp, vertical = 4.dp)
                ) { Text("${a.surah}:${a.number}", color = colors.textSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold) }
                if (juzStart > 1) {
                    HGap(6f)
                    Tagline(tr("джуз {0}", juzStart), colors.accent, colors)
                }
                if (QuranMath.isSajda(a.surah, a.number)) {
                    HGap(6f)
                    Tagline(if (a.key == QuranIndex.SAJDA_SHAFII_ONLY) tr("۩ земной поклон — кроме ханафитского мазхаба") else tr("۩ земной поклон"), colors.positive, colors)
                }
                Spacer(Modifier.weight(1f))
                AnimatedVisibility(bookmarked, enter = fadeIn(tween(160)), exit = fadeOut(tween(160))) {
                    Glyph(GlyphKind.BOOKMARK, accent, Modifier.size(textDp(15f)))
                }
            }
            Gap(8f)
            if (hideArabic) {
                Text(tr("Нажмите, чтобы открыть аят"), color = colors.textTertiary, fontSize = ui.t(15f),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), textAlign = TextAlign.Center)
            } else {
                ArabicText(arabic, arabicSize, Modifier.fillMaxWidth(), color = colors.text, align = TextAlign.Right)
            }
            AnimatedVisibility(
                visible = showReading && !hideReading,
                enter = expandVertically(NurMotion.gentle()) + fadeIn(NurMotion.gentle()),
                exit = shrinkVertically(NurMotion.snappy()) + fadeOut(NurMotion.snappy())
            ) {
                Text(if (latin) a.latin else a.translit, color = colors.textTertiary, fontSize = ui.t(14f), lineHeight = ui.t(20f),
                    modifier = Modifier.padding(top = 6.dp))
            }
            a.translation(translation)?.let { t ->
                Gap(8f)
                if (hideTranslation) {
                    Text(tr("Смысл скрыт — нажмите, чтобы открыть"), color = colors.textTertiary, fontSize = ui.t(14f))
                } else {
                    Text(translationText(t, colors.textTertiary), color = colors.text, fontSize = ui.t(translationSize),
                        lineHeight = ui.t(translationSize * 1.5f))
                }
            }
        }
        Box(Modifier.padding(horizontal = 12.dp).fillMaxWidth().height(1.dp).background(colors.hairline))
    }
}

/** The translator's remarks in parentheses are kept, a step quieter than the meaning itself. */
private fun translationText(text: String, quiet: Color): AnnotatedString = buildAnnotatedString {
    for ((run, remark) in QuranMath.remarks(text)) {
        if (remark) withStyle(SpanStyle(color = quiet)) { append(run) } else append(run)
    }
}

@Composable
private fun PageFooter(number: Int, lang: String, colors: QuranColors, onPrev: () -> Unit, onNext: () -> Unit) {
    val ui = uiScale()
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Column(Modifier.fillMaxWidth().padding(top = 16.dp)) {
        if (number < QuranIndex.SURAH_COUNT) {
            val next = QuranMath.surah(number + 1)
            // The next surah lies to the left: the arrow is drawn on the left and points there,
            // whatever the interface language.
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(colors.card)
                    .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(24.dp), onClick = onNext)
                    .padding(ui.s(16f)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!rtl) { MushafChevron(colors.accent, pointsLeft = true, modifier = Modifier.size(20.dp)); HGap(12f) }
                Column(Modifier.weight(1f)) {
                    Text(tr("Следующая сура"), color = colors.textTertiary, fontSize = ui.t(13f))
                    Text("${next.number}. ${QuranMath.title(next, lang)}", color = colors.text, fontSize = ui.t(17f),
                        fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (lang != "ar") ArabicText(next.arabic, 22f, color = colors.text, align = TextAlign.End)
                if (rtl) { HGap(12f); MushafChevron(colors.accent, pointsLeft = true, modifier = Modifier.size(20.dp)) }
            }
        } else {
            Text(tr("Это последняя сура Корана."), color = colors.textSecondary, fontSize = ui.t(14f),
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
        }
        if (number > 1) {
            Gap(8f)
            val prev = QuranMath.surah(number - 1)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                    .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(18.dp), onClick = onPrev)
                    .padding(horizontal = ui.s(16f), vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (rtl) { MushafChevron(colors.textTertiary, pointsLeft = false, modifier = Modifier.size(16.dp)); HGap(10f) }
                Text(tr("Предыдущая: {0}", "${prev.number}. ${QuranMath.title(prev, lang)}"), color = colors.textTertiary,
                    fontSize = ui.t(14f), modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (!rtl) { HGap(10f); MushafChevron(colors.textTertiary, pointsLeft = false, modifier = Modifier.size(16.dp)) }
            }
        }
        Gap(6f)
        Text(tr("Суры листаются справа налево, как страницы мусхафа"), color = colors.textTertiary, fontSize = ui.t(12f),
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

// ── fast scroll ──────────────────────────────────────────────────────────────────────────────────

/**
 * A thumb on the edge for long surahs. It shows up while the list moves and fades a moment after;
 * only while visible does it take touches, so an ordinary scroll near the edge stays a scroll.
 * Thumb y ↔ ayah is QuranMath.ayahAt / trackFraction: the ends of the track are exactly the first
 * and the last ayah.
 */
@Composable
private fun BoxScope.FastScroller(list: LazyListState, ayat: Int, colors: QuranColors, topInset: Dp, bottomInset: Dp) {
    if (ayat < FAST_SCROLL_MIN_AYAT) return
    val ui = uiScale()
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    var target by remember { mutableIntStateOf(0) }
    var awake by remember { mutableStateOf(false) }
    var trackPx by remember { mutableIntStateOf(1) }
    val scrolling = list.isScrollInProgress
    LaunchedEffect(scrolling, dragging) {
        if (scrolling || dragging) awake = true
        else { delay(FAST_SCROLL_HIDE_MILLIS); awake = false }
    }
    LaunchedEffect(list) { snapshotFlow { target }.collectLatest { if (it > 0) list.scrollToItem(it) } }
    val shown by animateFloatAsState(if (awake || dragging) 1f else 0f, tween(220), label = "fastScroll")
    val position by remember(list, ayat) {
        derivedStateOf { QuranMath.readingPosition(list.firstVisibleItemIndex, list.firstItemFraction(), ayat) }
    }
    val thumbPx = with(density) { FAST_THUMB_HEIGHT.toPx() }
    val fraction = if (dragging) dragFraction else QuranMath.trackFraction(position, ayat)
    val thumbY = (fraction * (trackPx - thumbPx).coerceAtLeast(0f)).roundToInt()
    val top = topInset + 12.dp

    Box(
        Modifier.align(Alignment.TopEnd).padding(top = top, bottom = bottomInset)
            .fillMaxHeight().width(FAST_TRACK_WIDTH)
            .onSizeChanged { trackPx = it.height.coerceAtLeast(1) }
            .graphicsLayer { alpha = shown }
            .then(
                if (awake || dragging) Modifier.pointerInput(ayat) {
                    fun at(y: Float) {
                        val span = (size.height - thumbPx).coerceAtLeast(1f)
                        dragFraction = ((y - thumbPx / 2f) / span).coerceIn(0f, 1f)
                        target = QuranMath.ayahAt(dragFraction, ayat)
                    }
                    detectVerticalDragGestures(
                        onDragStart = { o ->
                            dragging = true
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            at(o.y)
                        },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false }
                    ) { change, _ ->
                        change.consume()
                        at(change.position.y)
                    }
                } else Modifier
            )
    ) {
        Box(
            Modifier.align(Alignment.TopCenter).offset { IntOffset(0, thumbY) }
                .size(width = if (dragging) 8.dp else 5.dp, height = FAST_THUMB_HEIGHT)
                .clip(RoundedCornerShape(50)).background(if (dragging) colors.accent else colors.textTertiary)
        )
    }
    AnimatedVisibility(
        visible = dragging,
        enter = fadeIn(tween(120)),
        exit = fadeOut(tween(200)),
        modifier = Modifier.align(Alignment.TopEnd).padding(top = top, end = FAST_TRACK_WIDTH + 6.dp)
            .offset { IntOffset(0, thumbY + (thumbPx / 2f).roundToInt() - BUBBLE_HALF_PX(this)) }
    ) {
        Box(
            Modifier.clip(RoundedCornerShape(14.dp)).background(colors.raised)
                .border(1.dp, colors.accent.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Text(tr("аят {0}", QuranMath.ayahAt(dragFraction, ayat)), color = colors.text, fontSize = ui.t(15f), fontWeight = FontWeight.Bold)
        }
    }
}

@Suppress("FunctionName")
private fun BUBBLE_HALF_PX(density: androidx.compose.ui.unit.Density): Int = with(density) { 18.dp.roundToPx() }

// ── sheets ───────────────────────────────────────────────────────────────────────────────────────

@Composable
internal fun BoxScope.ReaderSheet(visible: Boolean, colors: QuranColors, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val ui = uiScale()
    AnimatedVisibility(visible, enter = fadeIn(tween(200)), exit = fadeOut(tween(180)), modifier = Modifier.matchParentSize()) {
        Box(
            Modifier.fillMaxSize().background(colors.scrim)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onDismiss)
        )
    }
    AnimatedVisibility(
        visible,
        enter = slideInVertically(NurMotion.gentle()) { h: Int -> h } + fadeIn(tween(160)),
        exit = slideOutVertically(NurMotion.snappy()) { h: Int -> h } + fadeOut(tween(160)),
        modifier = Modifier.align(Alignment.BottomCenter)
    ) {
        Column(
            Modifier.widthIn(max = READER_MAX_WIDTH).fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)).background(colors.card)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                .imePadding()
                .padding(horizontal = ui.s(20f))
                .padding(top = 10.dp, bottom = LocalDockInset.current + 16.dp)
        ) {
            Box(Modifier.align(Alignment.CenterHorizontally).size(width = 36.dp, height = 4.dp).clip(RoundedCornerShape(50)).background(colors.hairline))
            Gap(14f)
            content()
        }
    }
}

@Composable
internal fun SheetLabel(text: String, colors: QuranColors) {
    val ui = uiScale()
    Text(text, color = colors.textSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
    Gap(8f)
}

@Composable
private fun ReaderSettings(store: QuranStore, lang: String, colors: QuranColors) {
    val ui = uiScale()
    val current = store.translation(lang)
    Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
        Text(tr("Настройки чтения"), color = colors.text, fontSize = ui.t(18f), fontWeight = FontWeight.Bold)
        Gap(16f)
        SheetLabel(tr("Фон чтения"), colors)
        ReadingThemeRow(store, colors)
        Gap(18f)
        SheetLabel(tr("Перевод смыслов"), colors)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(QuranTranslation.entries, key = { it.code }) { t ->
                QChip(t.label, current == t, colors) { store.setTranslation(t.code) }
            }
            item(key = "none") { QChip(tr("Без перевода"), current == null, colors) { store.setTranslation(QuranStore.NONE_CODE) } }
        }
        if (current != null) {
            Gap(4f)
            Text(current.author, color = colors.textTertiary, fontSize = ui.t(12f))
        }
        Gap(18f)
        ReadingSizes(store, colors)
        Gap(18f)
        ReadingSwitch(tr("Не гасить экран"), tr("Пока открыта сура"), store.keepAwake, colors) { store.setAwake(!store.keepAwake) }
        Gap(14f)
        // Required by the Tanzil licence: name the source of the Arabic text and link to it.
        Text("Quran text: Tanzil Project · tanzil.net", color = colors.textTertiary, fontSize = ui.t(11f))
    }
}

/**
 * The three reading surfaces as swatches. Shared by the reader and the short surahs (0.18.5):
 * one choice of page for everything that is read from the mushaf.
 */
@Composable
internal fun ReadingThemeRow(store: QuranStore, colors: QuranColors) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        ThemeSwatch(tr("Тёмный"), Brush.verticalGradient(listOf(Color(0xFF1A1E26), Color(0xFF0C0E12))), SWATCH_INK_DARK,
            store.readerTheme == QuranStore.THEME_NIGHT, colors) { store.setTheme(QuranStore.THEME_NIGHT) }
        ThemeSwatch(tr("Чёрный"), SolidColor(Color.Black), SWATCH_INK_DARK,
            store.readerTheme == QuranStore.THEME_BLACK, colors) { store.setTheme(QuranStore.THEME_BLACK) }
        ThemeSwatch(tr("Светлый"), Brush.verticalGradient(listOf(Color(0xFFFAF4E4), Color(0xFFF0E6CC))), SWATCH_INK_PAPER,
            store.readerTheme == QuranStore.THEME_LIGHT, colors) { store.setTheme(QuranStore.THEME_LIGHT) }
    }
}

/** Arabic size with a basmala to judge it by, then the translation size; shared like [ReadingThemeRow]. */
@Composable
internal fun ReadingSizes(store: QuranStore, colors: QuranColors) {
    val sizes = listOf(tr("Мелкий"), tr("Обычный"), tr("Крупный"), tr("Очень крупный"))
    SheetLabel(tr("Размер арабского текста"), colors)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        sizes.forEachIndexed { i, label -> QChip(label, store.arabicSize == i, colors) { store.setSize(i) } }
    }
    Gap(8f)
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(colors.inset).padding(12.dp)) {
        ArabicText(BASMALA, QuranStore.SIZES[store.arabicSize], color = colors.text)
    }
    Gap(18f)
    SheetLabel(tr("Размер перевода"), colors)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        sizes.forEachIndexed { i, label -> QChip(label, store.translationSize == i, colors) { store.setTranslationTextSize(i) } }
    }
}

/** A setting line with a switch, the whole line tappable. */
@Composable
internal fun ReadingSwitch(title: String, subtitle: String, checked: Boolean, colors: QuranColors, onToggle: () -> Unit) {
    val ui = uiScale()
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(16.dp), onClick = onToggle)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = colors.text, fontSize = ui.t(15f), fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = colors.textTertiary, fontSize = ui.t(12f))
        }
        NurSwitch(
            checked, colors.accent, off = colors.textTertiary.copy(alpha = 0.35f),
            knobOff = if (colors.light) colors.card else colors.textSecondary
        )
    }
}

@Composable
private fun ThemeSwatch(label: String, fill: Brush, ink: Color, selected: Boolean, colors: QuranColors, onClick: () -> Unit) {
    val ui = uiScale()
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).pressClick(scaleTo = 0.95f, shape = RoundedCornerShape(16.dp), onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(width = 64.dp, height = 44.dp).clip(RoundedCornerShape(12.dp)).background(fill)
                .border(if (selected) 2.dp else 1.dp, if (selected) colors.accent else colors.hairline, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("ب", color = ink, fontSize = ui.t(18f), fontFamily = ArabicFont.family)
        }
        Gap(6f)
        Text(label, color = if (selected) colors.text else colors.textTertiary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold)
    }
}

/** «Перейти к аяту»: a number of the open surah or any "2:255". */
@Composable
private fun GoToAyah(surahNumber: Int, lang: String, colors: QuranColors, onGo: (QuranMark) -> Unit) {
    val ui = uiScale()
    val s = QuranMath.surah(surahNumber)
    var text by remember { mutableStateOf("") }
    // A number keyboard cannot type "с42": the page has a mode of its own.
    var byPage by remember { mutableStateOf(false) }
    val target = if (byPage) text.trim().toIntOrNull()?.takeIf { it in 1..QuranIndex.PAGE_COUNT }?.let { QuranMath.pageStart(it) }
        else QuranMath.resolveJump(text, surahNumber)
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(GOTO_FOCUS_DELAY_MILLIS)
        runCatching { focus.requestFocus() }
    }
    Text(if (byPage) tr("Перейти к странице") else tr("Перейти к аяту"), color = colors.text, fontSize = ui.t(18f), fontWeight = FontWeight.Bold)
    Gap(4f)
    Text(
        if (byPage) tr("Номер страницы мусхафа (1–{0})", QuranIndex.PAGE_COUNT)
        else tr("Номер аята в суре «{0}» (1–{1}) или ссылка вида 2.255", QuranMath.title(s, lang), s.ayat),
        color = colors.textTertiary, fontSize = ui.t(13f), lineHeight = ui.t(18f)
    )
    Gap(10f)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        QChip(tr("Аят"), !byPage, colors) { byPage = false; text = "" }
        QChip(tr("Страница"), byPage, colors) { byPage = true; text = "" }
    }
    Gap(12f)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(colors.inset)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            if (text.isEmpty()) Text(if (byPage) "1–${QuranIndex.PAGE_COUNT}" else "1–${s.ayat}", color = colors.textTertiary, fontSize = ui.t(20f))
            BasicTextField(
                value = text,
                onValueChange = { text = it.take(GOTO_MAX_CHARS) },
                singleLine = true,
                textStyle = TextStyle(color = colors.text, fontSize = ui.t(20f), fontWeight = FontWeight.Bold),
                cursorBrush = SolidColor(colors.accent),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { target?.let(onGo) }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus)
            )
        }
        HGap(10f)
        Box(
            Modifier.clip(RoundedCornerShape(16.dp))
                .background(if (target != null) colors.accent else colors.raised)
                .pressClick(enabled = target != null, scaleTo = 0.96f, shape = RoundedCornerShape(16.dp)) { target?.let(onGo) }
                .padding(horizontal = 18.dp, vertical = 15.dp)
        ) {
            Text(tr("Перейти"), color = if (target != null) colors.onAccent else colors.textTertiary,
                fontSize = ui.t(15f), fontWeight = FontWeight.Bold)
        }
    }
    Gap(8f)
    val hint = when {
        text.isBlank() -> ""
        target == null -> if (byPage) tr("Такой страницы нет") else tr("Такого аята нет")
        !byPage && target.surah == surahNumber -> tr("аят {0} из {1}", target.ayah, s.ayat)
        else -> "${QuranMath.title(QuranMath.surah(target.surah), lang)} ${target.surah}:${target.ayah}"
    }
    Text(hint, color = if (target == null) colors.textTertiary else colors.accentText, fontSize = ui.t(13f))
    Gap(12f)
    // Quick marks: start, the middle and the end of the surah.
    if (!byPage && s.ayat >= QUICK_MARKS_MIN_AYAT) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            QChip(tr("Начало"), false, colors) { onGo(QuranMark(s.number, 1)) }
            QChip(tr("Середина"), false, colors) { onGo(QuranMark(s.number, (s.ayat + 1) / 2)) }
            QChip(tr("Конец"), false, colors) { onGo(QuranMark(s.number, s.ayat)) }
        }
    }
}

private const val SHEET_NONE = 0
private const val SHEET_SETTINGS = 1
private const val SHEET_GOTO = 2
private const val BAR_SCROLL_SLOP = 6f
private const val TOP_REVEAL_PX = 24
private const val PAGE_FADE = 0.45f
private const val PAGE_SHRINK = 0.05f
private const val HIGHLIGHT_ALPHA = 0.16f
private val SWATCH_INK_DARK = Color(0xD9FFFFFF)
private val SWATCH_INK_PAPER = Color(0xFF1E1A13)

/** How long the reader must stay on a page before the khatm counts it: skimming is not reading. */
private const val KHATM_DWELL_MILLIS = 1200L
private const val FLASH_MILLIS = 1400
private const val FLASH_HOLD_MILLIS = 450
private const val FAST_SCROLL_MIN_AYAT = 40
private const val FAST_SCROLL_HIDE_MILLIS = 1300L
private const val GOTO_FOCUS_DELAY_MILLIS = 280L
private const val GOTO_MAX_CHARS = 8
private const val QUICK_MARKS_MIN_AYAT = 10
private val FAST_TRACK_WIDTH = 28.dp
private val FAST_THUMB_HEIGHT = 44.dp
internal val READER_MAX_WIDTH = 680.dp
