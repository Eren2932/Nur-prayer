package com.nur.prayer.ui.schedule

import com.nur.prayer.i18n.tr

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate
import java.time.YearMonth
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind

@Composable
fun MonthCalendar(
    month: YearMonth, selected: LocalDate, today: LocalDate, hijriOffset: Int,
    palette: PhasePalette, onMonth: (YearMonth) -> Unit, onSelect: (LocalDate) -> Unit,
    onToday: () -> Unit, onPickMonth: () -> Unit = {}, modifier: Modifier = Modifier
) {
    val ui = uiScale()
    // 0.19.0: the wheel offers ±10 years, so the arrows and the swipe go as far.
    val years = remember(today) { PeriodRange.gregorianYears(today) }
    val min = YearMonth.of(years.first, 1)
    val max = YearMonth.of(years.last, 12)
    val changeMonth by rememberUpdatedState(onMonth)
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onToday, contentPadding = PaddingValues(0.dp), modifier = Modifier.testTag("calendar-today")) {
                Text(tr("Сегодня"), color = palette.accent, fontSize = ui.t(13f))
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { onMonth(month.minusMonths(1)) }, enabled = month > min,
                contentPadding = PaddingValues(0.dp), modifier = Modifier.size(48.dp)
                    .semantics { contentDescription = tr("Предыдущий месяц") }) {
                Glyph(GlyphKind.BACK, if (month > min) TextPrimary else TextTertiary, Modifier.size(20.dp))
            }
            TextButton(onClick = { onMonth(month.plusMonths(1)) }, enabled = month < max,
                contentPadding = PaddingValues(0.dp), modifier = Modifier.size(48.dp)
                    .semantics { contentDescription = tr("Следующий месяц") }) {
                Glyph(GlyphKind.CHEVRON, if (month < max) TextPrimary else TextTertiary, Modifier.size(20.dp))
            }
        }
        // The title is the way into the wheel: «Ноябрь 2026 ⌄».
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .clickable(role = Role.Button, onClickLabel = tr("Выбрать месяц"), onClick = onPickMonth)
            .testTag("calendar-month"), verticalAlignment = Alignment.CenterVertically) {
            AutoSizeText(Format.monthYear(month.atDay(1)), color = TextPrimary,
                fontSize = ui.t(32f), fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f, fill = false))
            Spacer(Modifier.width(8.dp))
            Glyph(GlyphKind.CHEVRON, TextSecondary, Modifier.size(18.dp).graphicsLayer { rotationZ = 90f })
        }
        val hijriSpan = remember(month, hijriOffset) { HijriCalendar.span(month.atDay(1), month.atEndOfMonth(), hijriOffset) }
        Text(hijriSpan, color = TextSecondary,
            fontSize = ui.t(11f), modifier = Modifier.padding(top = 6.dp, bottom = 20.dp))
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
            listOf(tr("Пн"), tr("Вт"), tr("Ср"), tr("Чт"), tr("Пт"), tr("Сб"), tr("Вс")).forEachIndexed { i, label ->
                Text(label, color = if (i == 4) palette.accent else TextSecondary, fontSize = ui.t(12f),
                    textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            }
        }
        AnimatedContent(targetState = month, transitionSpec = {
            val direction = if (targetState > initialState) 1 else -1
            ((slideInHorizontally(tween(220)) { it / 8 * direction } + fadeIn(tween(180))) togetherWith
                (slideOutHorizontally(tween(160)) { -it / 8 * direction } + fadeOut(tween(140)))).using(null)
        }, label = "calendarMonth", modifier = Modifier.fillMaxWidth().testTag("calendar-grid")
            .pointerInput(month, min, max) {
                var distance = 0f
                detectHorizontalDragGestures(onDragStart = { distance = 0f }, onDragCancel = { distance = 0f },
                    onHorizontalDrag = { change, amount -> change.consume(); distance += amount },
                    onDragEnd = {
                        val threshold = 48.dp.toPx()
                        if (distance < -threshold && month < max) changeMonth(month.plusMonths(1))
                        if (distance > threshold && month > min) changeMonth(month.minusMonths(1))
                    })
            }) { visibleMonth ->
            val cells = remember(visibleMonth) {
                val original = CalendarMonthModel.cells(visibleMonth)
                List(42) { original.first().plusDays(it.toLong()) }
            }
            Column {
                cells.chunked(7).forEach { week ->
                    Box(Modifier.fillMaxWidth().height(1.dp).background(SurfaceEdge))
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        week.forEach { date ->
                            val inMonth = YearMonth.from(date) == visibleMonth
                            val active = date == selected && inMonth
                            val isToday = date == today
                            val hijri = remember(date, hijriOffset) { HijriCalendar.dayOfMonth(date, hijriOffset) }
                            val label = remember(date, hijriOffset, isToday) {
                                "${Format.fullDate(date)}, ${HijriCalendar.format(date, hijriOffset)}" + if (isToday) tr(", сегодня") else ""
                            }
                            val shape = RoundedCornerShape(10.dp)
                            // 0.19.0: the day of the Islamic year paints the cell in the colour of its kind.
                            val event = remember(date, hijriOffset) { IslamicDays.primary(date, hijriOffset) }
                            val tone = event?.let { DayTone.of(it.kind) }
                            val season = event?.kind == DayKind.SEASON
                            val fill = when {
                                active -> palette.accent
                                tone != null && inMonth && !season -> tone.copy(alpha = 0.24f)
                                tone != null && inMonth -> tone.copy(alpha = 0.10f)
                                else -> Color.Transparent
                            }
                            val eventLabel = event?.let { ", " + IslamicDayText.title(it.day) } ?: ""
                            Column(Modifier.weight(1f).height(52.dp).padding(horizontal = 1.5.dp).clip(shape)
                                .background(fill)
                                .border(1.dp, if (isToday && !active && inMonth) palette.accent else Color.Transparent, shape)
                                .selectable(selected = active, enabled = inMonth, role = Role.Button, onClick = { onSelect(date) })
                                .semantics(mergeDescendants = true) { contentDescription = label + eventLabel }
                                .testTag("calendar-day-$date"), horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center) {
                                Text(date.dayOfMonth.toString(), fontSize = ui.t(17f),
                                    fontWeight = if (active || isToday) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (active) Ink else if (inMonth) TextPrimary else TextTertiary.copy(alpha = 0.5f))
                                Text(hijri.toString(), fontSize = ui.t(10f), color = if (active) Ink.copy(alpha = 0.8f)
                                    else if (tone != null && inMonth) tone else if (inMonth) TextSecondary else TextTertiary.copy(alpha = 0.5f))
                                // A dot for a single day, a ribbon for a season (Ramadan, the ten days).
                                Box(Modifier.padding(top = 2.dp).height(3.dp).then(if (season) Modifier.fillMaxWidth(0.7f) else Modifier.width(5.dp))
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(if (tone != null && inMonth) (if (active) Ink.copy(alpha = 0.7f) else tone) else Color.Transparent))
                            }
                        }
                    }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(SurfaceEdge))
            }
        }
    }
}
