package com.nur.prayer.ui.home

import com.nur.prayer.i18n.tr

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.notify.AzanSound
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.Caption
import com.nur.prayer.ui.components.ChoiceRow
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.GroupCaption
import com.nur.prayer.ui.components.HairRule
import com.nur.prayer.ui.components.PillButton
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.components.StepperField
import com.nur.prayer.ui.components.SwitchRow
import com.nur.prayer.ui.theme.Amber
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.NextGreen
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.paletteFor
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime
import com.nur.prayer.ui.theme.ArabicFont

/**
 * The sheet of one prayer: its times, its notification, its correction.
 *
 * Pages follow the home list, so a horizontal swipe walks Фаджр → Восход → Зухр… without closing
 * the sheet, and the tint follows the sky of the page. Drag the header down (or tap outside, or
 * Back) to close. Everything here writes through [AppActions], the same path Settings uses, so the
 * alarm chain re-arms exactly as it would from there.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PrayerSheet(
    data: PrayerData,
    initial: Prayer,
    now: State<ZonedDateTime>,
    actions: AppActions,
    notificationsAllowed: Boolean,
    exactAlarmsAllowed: Boolean,
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit,
    /** Position of the whole sheet; the host translates the layer, the header drags it. */
    motion: Reveal = remember { Reveal(initiallyOpen = true) }
) {
    val ui = uiScale()
    val prayers = HomeTimeline.prayers(data.fajrEqualsDawn)
    val pager = rememberPagerState(initialPage = HomeTimeline.pageOf(initial, data.fajrEqualsDawn)) { prayers.size }
    val page = prayers[pager.currentPage.coerceIn(0, prayers.lastIndex)]
    val tint by animateColorAsState(paletteFor(page).sheet, tween(260), label = "sheetTint")

    // Drag-to-close on the header. The same Reveal that opened the sheet follows the finger, the
    // scrim fades with it, and on release it either springs back or closes from where it is.
    val dragState = rememberDraggableState { delta -> motion.drag(-delta) }

    // The adhan preview must never outlive the sheet.
    var previewing by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { if (previewing) actions.stopAzan() } }

    Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = 56.dp)) {
        Column(
            Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Brush.verticalGradient(listOf(tint, lerp(tint, Ink, 0.55f))))
                // Swallow taps so they do not fall through to the scrim and close the sheet.
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .draggable(
                        dragState, Orientation.Vertical,
                        onDragStarted = { motion.grab() },
                        onDragStopped = { velocity ->
                            if (motion.release(-velocity, RevealMath.SHEET_KEEP_AT)) motion.settle(true) else onDismiss()
                        }
                    )
                    .padding(start = ui.s(20f), end = ui.s(14f), top = 10.dp)
            ) {
                Box(
                    Modifier.align(Alignment.CenterHorizontally).width(36.dp).height(4.dp)
                        .clip(RoundedCornerShape(2.dp)).background(Color(0x59FFFFFF))
                )
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        PrayerLabels.title(page), color = TextPrimary, fontSize = ui.t(24f),
                        fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).semantics { heading() }
                    )
                    RoundIconButton(GlyphKind.CLOSE, tr("Закрыть"), onDismiss, size = 40.dp, background = Color(0x33FFFFFF))
                }
                PageDots(prayers.size, pager.currentPage, Modifier.align(Alignment.CenterHorizontally).padding(vertical = 10.dp))
            }

            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { index ->
                val prayer = prayers[index]
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = ui.s(18f))
                        .navigationBarsPadding()
                        .padding(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    TimeHero(prayer, data, now)
                    when {
                        !notificationsAllowed -> PermissionBanner(
                            tr("Уведомления отключены"),
                            tr("Разрешите уведомления — иначе азан не придёт"),
                            tr("Включить"), actions.openNotificationSettings
                        )
                        !exactAlarmsAllowed -> PermissionBanner(
                            tr("Точные напоминания выключены"),
                            tr("Без точных будильников азан может опоздать на пару минут"),
                            tr("Разрешить"), actions.openExactAlarmSettings
                        )
                    }
                    NotificationGroup(prayer, data, actions, previewing) { previewing = it }
                    Box(Modifier.fillMaxWidth().padding(top = 6.dp), contentAlignment = Alignment.Center) {
                        PillButton(tr("Другие настройки"), onOpenSettings, background = Color(0x40FFFFFF))
                    }
                }
            }
        }
    }
}

@Composable
private fun PageDots(count: Int, selected: Int, modifier: Modifier = Modifier) {
    Row(
        modifier.semantics { contentDescription = tr("Страница {0} из {1}", selected + 1, count) },
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        repeat(count) { i ->
            Box(
                Modifier.size(6.dp).clip(CircleShape)
                    .background(if (i == selected) TextPrimary else Color(0x59FFFFFF))
            )
        }
    }
}

/** Today's time, the end of its window, tomorrow's time, and — when it matters — how long is left. */
@Composable
private fun TimeHero(prayer: Prayer, data: PrayerData, now: State<ZonedDateTime>) {
    val ui = uiScale()
    val equal = data.fajrEqualsDawn
    val today = data.today.times[prayer]
    val tomorrow = data.days.getOrNull(1)?.times?.get(prayer)
    val end = HomeTimeline.endOf(prayer, data.today, data.days.getOrNull(1), equal)
    GlassCard(corner = 22.dp, color = Color(0x33000000)) {
        Column(Modifier.padding(horizontal = ui.s(18f), vertical = ui.s(16f))) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    today?.let(Format::time) ?: "—", color = TextPrimary, fontSize = ui.t(46f),
                    fontWeight = FontWeight.Bold, letterSpacing = ui.t(-1f)
                )
                Spacer(Modifier.weight(1f))
                Text(
                    PrayerLabels.arabic(prayer), color = TextSecondary, fontSize = ui.t(22f), fontFamily = ArabicFont.family,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
            Text(PrayerLabels.hint(prayer), color = TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.Medium)
            HairRule()
            end?.let { (until, at) ->
                HeroFact(tr("Длится до"), "${PrayerLabels.title(until)} · ${Format.time(at)}")
            }
            HeroFact(tr("Завтра"), tomorrow?.let(Format::time) ?: "—")
            WindowStatus(prayer, data, now)
        }
    }
}

@Composable
private fun HeroFact(label: String, value: String) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextSecondary, fontSize = ui.t(14f), modifier = Modifier.weight(1f))
        Text(value, color = TextPrimary, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
    }
}

/** The only per-second reader in the sheet; absent for prayers that are neither now nor next. */
@Composable
private fun WindowStatus(prayer: Prayer, data: PrayerData, now: State<ZonedDateTime>) {
    val ui = uiScale()
    val equal = data.fajrEqualsDawn
    val isCurrent = HomeTimeline.current(data.window, equal) == prayer
    val isNext = HomeTimeline.next(data.window, equal) == prayer
    if (!isCurrent && !isNext) return
    val left = data.window.remaining(now.value)
    val text = if (isNext) tr("Начнётся {0}", Format.shortCountdown(left)) else tr("Идёт сейчас · осталось {0}", Format.clock(left))
    Row(
        Modifier.padding(top = 10.dp).clip(RoundedCornerShape(10.dp))
            .background(if (isNext) NextGreen else Color(0x33FFFFFF))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = TextPrimary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun PermissionBanner(title: String, body: String, action: String, onAction: () -> Unit) {
    val ui = uiScale()
    GlassCard(corner = 22.dp, color = Amber) {
        Column(Modifier.padding(ui.s(18f))) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Ink, fontSize = ui.t(16f), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Glyph(GlyphKind.SOUND_OFF, Ink, Modifier.size(20.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text(body, color = Color(0xE6000000), fontSize = ui.t(13.5f), lineHeight = ui.t(19f))
            Spacer(Modifier.height(14.dp))
            PillButton(action, onAction, background = Ink, contentColor = TextPrimary)
        }
    }
}

@Composable
private fun NotificationGroup(
    prayer: Prayer, data: PrayerData, actions: AppActions,
    previewing: Boolean, setPreviewing: (Boolean) -> Unit
) {
    val ui = uiScale()
    val settings = data.settings
    val enabled = settings.notifications[prayer] == true
    val offset = settings.offsets[prayer] ?: 0
    var soundsOpen by rememberSaveable(prayer) { mutableStateOf(false) }
    val time = data.today.times[prayer]?.let(Format::time)

    GroupCaption(tr("Уведомление"))
    GlassCard(corner = 22.dp, color = Color(0x33000000)) {
        Column(Modifier.padding(horizontal = ui.s(12f), vertical = ui.s(6f))) {
            SwitchRow(
                title = tr("Уведомление"),
                subtitle = when {
                    !enabled -> tr("Выключено")
                    settings.preAlertMinutes > 0 -> tr("В {0} и за {1} мин", time ?: "—", settings.preAlertMinutes)
                    else -> tr("В {0}", time ?: "—")
                },
                checked = enabled,
                accent = Mint,
                onCheckedChange = { actions.setNotification(prayer, it) }
            )
            HairRule()
            Column(Modifier.alpha(if (enabled) 1f else 0.45f)) {
                SheetRow(
                    GlyphKind.SOUND, tr("Звук"), settings.azanSound.title,
                    open = soundsOpen, enabled = enabled, onClick = { soundsOpen = !soundsOpen }
                )
                AnimatedVisibility(
                    visible = soundsOpen && enabled,
                    enter = expandVertically(tween(200)) + fadeIn(tween(160)),
                    exit = shrinkVertically(tween(160)) + fadeOut(tween(120))
                ) {
                    Column(Modifier.padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        AzanSound.entries.forEach { sound ->
                            ChoiceRow(
                                title = sound.title, subtitle = sound.explanation,
                                selected = sound == settings.azanSound, accent = Mint,
                                onClick = { actions.setAzanSound(sound) }
                            )
                        }
                        if (settings.azanSound != AzanSound.SILENT) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.CenterStart) {
                                PillButton(
                                    if (previewing) tr("Остановить") else tr("Прослушать"),
                                    onClick = {
                                        if (previewing) actions.stopAzan() else actions.previewAzan(settings.azanSound)
                                        setPreviewing(!previewing)
                                    },
                                    background = Color(0x33FFFFFF)
                                )
                            }
                        }
                        Caption(tr("Звук общий, уведомление — для каждого намаза отдельно"))
                    }
                }
                HairRule()
                StepperField(
                    label = tr("Поправка времени"),
                    value = when {
                        offset > 0 -> tr("+{0} мин", offset)
                        offset < 0 -> tr("{0} мин", offset)
                        else -> tr("0 мин")
                    },
                    accent = Mint,
                    onMinus = { actions.setOffset(prayer, (offset - 1).coerceAtLeast(-60)) },
                    onPlus = { actions.setOffset(prayer, (offset + 1).coerceAtMost(60)) },
                    hint = tr("Сдвигает и время в расписании, и уведомление")
                )
            }
        }
    }
}

@Composable
private fun SheetRow(kind: GlyphKind, title: String, value: String, open: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val ui = uiScale()
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = if (open) tr("Свернуть") else tr("Выбрать звук"), onClick = onClick)
            .heightIn(min = 56.dp)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Glyph(kind, TextSecondary, Modifier.size(20.dp))
        Spacer(Modifier.width(ui.s(12f)))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
            Text(value, color = TextTertiary, fontSize = ui.t(12f))
        }
        Glyph(GlyphKind.CHEVRON, TextTertiary, Modifier.size(16.dp).graphicsLayer { rotationZ = if (open) 90f else 0f })
    }
}

