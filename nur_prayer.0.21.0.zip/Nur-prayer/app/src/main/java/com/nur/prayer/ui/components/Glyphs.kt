package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale

/**
 * The app's icon set, drawn rather than imported.
 *
 * `material-icons-extended` is ~30 MB of vectors for the nine glyphs we need, and the core set has
 * no compass, no muted speaker and no calendar that matches our stroke weight. These are drawn in
 * a 1×1 unit box with one stroke width, so they sit on the same optical grid at every size.
 * Decorative by default: the clickable around a glyph carries the accessible label.
 */
enum class GlyphKind {
    COMPASS, MORE, CALENDAR, BACK, CLOSE, LOCATION, SOUND, SOUND_OFF, CHEVRON, MOON, SETTINGS, GLOBE, BELL, CLOCK, INFO, SUN, SLIDERS, SPARKLE,
    /** 0.18.4 — the set that replaced emoji and font symbols (🔥 ✓ 🔒 ★), drawn from the mosque and the mushaf. */
    LAMP, SEAL, LOCK, STAR, STAR_OUTLINE, BOOKMARK,
    /** 0.19.0 — the calendar picture; same three-node figure as the ayah action bar. */
    SHARE
}

@Composable
fun Glyph(kind: GlyphKind, tint: Color, modifier: Modifier = Modifier) {
    // Arrows point along the reading direction: mirrored for Arabic, everything else stays put.
    val mirror = (kind == GlyphKind.BACK || kind == GlyphKind.CHEVRON) &&
        androidx.compose.ui.platform.LocalLayoutDirection.current == androidx.compose.ui.unit.LayoutDirection.Rtl
    Canvas(modifier) {
        if (mirror) scale(scaleX = -1f, scaleY = 1f) { drawGlyph(kind, tint) }
        else drawGlyph(kind, tint)
    }
}

private fun DrawScope.drawGlyph(kind: GlyphKind, color: Color) {
    val s = size.minDimension
    if (s <= 0f) return
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val w = s * 0.09f
    val stroke = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(ox + x * s, oy + y * s)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, width: Float = w) =
        drawLine(color, p(x1, y1), p(x2, y2), strokeWidth = width, cap = StrokeCap.Round)

    when (kind) {
        GlyphKind.COMPASS -> {
            drawCircle(color, radius = s * 0.42f, center = p(0.5f, 0.5f), style = stroke)
            val needle = Path().apply {
                moveTo(ox + 0.68f * s, oy + 0.32f * s)
                lineTo(ox + 0.45f * s, oy + 0.45f * s)
                lineTo(ox + 0.32f * s, oy + 0.68f * s)
                lineTo(ox + 0.55f * s, oy + 0.55f * s)
                close()
            }
            drawPath(needle, color)
        }
        GlyphKind.MORE -> {
            listOf(0.22f, 0.5f, 0.78f).forEach { x -> drawCircle(color, s * 0.075f, p(x, 0.5f)) }
        }
        GlyphKind.CALENDAR -> {
            drawRoundRect(
                color, topLeft = p(0.12f, 0.2f), size = Size(s * 0.76f, s * 0.68f),
                cornerRadius = CornerRadius(s * 0.14f, s * 0.14f), style = stroke
            )
            line(0.32f, 0.1f, 0.32f, 0.27f)
            line(0.68f, 0.1f, 0.68f, 0.27f)
            line(0.12f, 0.42f, 0.88f, 0.42f, w * 0.8f)
            drawCircle(color, s * 0.055f, p(0.34f, 0.62f))
            drawCircle(color, s * 0.055f, p(0.5f, 0.62f))
            drawCircle(color, s * 0.055f, p(0.66f, 0.62f))
        }
        GlyphKind.BACK -> {
            line(0.62f, 0.18f, 0.3f, 0.5f)
            line(0.3f, 0.5f, 0.62f, 0.82f)
        }
        GlyphKind.CHEVRON -> {
            line(0.4f, 0.22f, 0.68f, 0.5f)
            line(0.68f, 0.5f, 0.4f, 0.78f)
        }
        GlyphKind.CLOSE -> {
            line(0.26f, 0.26f, 0.74f, 0.74f)
            line(0.74f, 0.26f, 0.26f, 0.74f)
        }
        GlyphKind.LOCATION -> {
            // The "navigation arrow", as on a map: a filled dart pointing north-east.
            val dart = Path().apply {
                moveTo(ox + 0.86f * s, oy + 0.14f * s)
                lineTo(ox + 0.14f * s, oy + 0.46f * s)
                lineTo(ox + 0.5f * s, oy + 0.52f * s)
                lineTo(ox + 0.56f * s, oy + 0.88f * s)
                close()
            }
            drawPath(dart, color)
        }
        GlyphKind.SOUND, GlyphKind.SOUND_OFF -> {
            val body = Path().apply {
                moveTo(ox + 0.12f * s, oy + 0.38f * s)
                lineTo(ox + 0.3f * s, oy + 0.38f * s)
                lineTo(ox + 0.52f * s, oy + 0.18f * s)
                lineTo(ox + 0.52f * s, oy + 0.82f * s)
                lineTo(ox + 0.3f * s, oy + 0.62f * s)
                lineTo(ox + 0.12f * s, oy + 0.62f * s)
                close()
            }
            drawPath(body, color)
            if (kind == GlyphKind.SOUND) {
                drawArc(
                    color, startAngle = -50f, sweepAngle = 100f, useCenter = false,
                    topLeft = p(0.46f, 0.3f), size = Size(s * 0.24f, s * 0.4f), style = stroke
                )
                drawArc(
                    color, startAngle = -55f, sweepAngle = 110f, useCenter = false,
                    topLeft = p(0.5f, 0.16f), size = Size(s * 0.38f, s * 0.68f), style = stroke
                )
            } else {
                line(0.64f, 0.36f, 0.9f, 0.64f)
                line(0.9f, 0.36f, 0.64f, 0.64f)
            }
        }
        GlyphKind.SETTINGS -> {
            // A gear in strokes, the same weight as every other glyph: eight teeth round a ring.
            val c = p(0.5f, 0.5f)
            for (i in 0 until 8) {
                val a = Math.toRadians(i * 45.0)
                val dx = kotlin.math.cos(a).toFloat()
                val dy = kotlin.math.sin(a).toFloat()
                drawLine(
                    color, Offset(c.x + dx * s * 0.27f, c.y + dy * s * 0.27f),
                    Offset(c.x + dx * s * 0.4f, c.y + dy * s * 0.4f), strokeWidth = s * 0.13f, cap = StrokeCap.Round
                )
            }
            drawCircle(color, s * 0.27f, c, style = Stroke(width = w * 1.15f))
            drawCircle(color, s * 0.09f, c, style = Stroke(width = w))
        }
        GlyphKind.GLOBE -> {
            val c = p(0.5f, 0.5f)
            val r = s * 0.38f
            drawCircle(color, r, c, style = stroke)
            drawOval(color, topLeft = Offset(c.x - r * 0.42f, c.y - r), size = Size(r * 0.84f, r * 2f), style = stroke)
            line(0.12f, 0.5f, 0.88f, 0.5f)
            line(0.2f, 0.32f, 0.8f, 0.32f, w * 0.8f)
            line(0.2f, 0.68f, 0.8f, 0.68f, w * 0.8f)
        }
        GlyphKind.BELL -> {
            val bell = Path().apply {
                moveTo(ox + 0.2f * s, oy + 0.72f * s)
                lineTo(ox + 0.8f * s, oy + 0.72f * s)
                cubicTo(ox + 0.72f * s, oy + 0.62f * s, ox + 0.72f * s, oy + 0.54f * s, ox + 0.72f * s, oy + 0.44f * s)
                cubicTo(ox + 0.72f * s, oy + 0.26f * s, ox + 0.62f * s, oy + 0.16f * s, ox + 0.5f * s, oy + 0.16f * s)
                cubicTo(ox + 0.38f * s, oy + 0.16f * s, ox + 0.28f * s, oy + 0.26f * s, ox + 0.28f * s, oy + 0.44f * s)
                cubicTo(ox + 0.28f * s, oy + 0.54f * s, ox + 0.28f * s, oy + 0.62f * s, ox + 0.2f * s, oy + 0.72f * s)
                close()
            }
            drawPath(bell, color, style = stroke)
            line(0.43f, 0.84f, 0.57f, 0.84f)
        }
        GlyphKind.CLOCK -> {
            drawCircle(color, s * 0.38f, p(0.5f, 0.5f), style = stroke)
            line(0.5f, 0.5f, 0.5f, 0.28f)
            line(0.5f, 0.5f, 0.66f, 0.6f)
        }
        GlyphKind.INFO -> {
            drawCircle(color, s * 0.38f, p(0.5f, 0.5f), style = stroke)
            drawCircle(color, s * 0.055f, p(0.5f, 0.32f))
            line(0.5f, 0.46f, 0.5f, 0.7f)
        }
        GlyphKind.SUN -> {
            // A sun half under the horizon: the high-latitude rules are about twilight.
            val c = p(0.5f, 0.62f)
            drawArc(color, 180f, 180f, false, topLeft = Offset(c.x - s * 0.2f, c.y - s * 0.2f),
                size = Size(s * 0.4f, s * 0.4f), style = stroke)
            line(0.1f, 0.62f, 0.9f, 0.62f)
            line(0.5f, 0.14f, 0.5f, 0.26f)
            line(0.2f, 0.3f, 0.27f, 0.37f)
            line(0.8f, 0.3f, 0.73f, 0.37f)
            line(0.3f, 0.8f, 0.7f, 0.8f, w * 0.8f)
        }
        GlyphKind.SLIDERS -> {
            line(0.14f, 0.32f, 0.86f, 0.32f)
            line(0.14f, 0.68f, 0.86f, 0.68f)
            drawCircle(color, s * 0.085f, p(0.36f, 0.32f))
            drawCircle(color, s * 0.085f, p(0.64f, 0.68f))
        }
        GlyphKind.SPARKLE -> {
            val star = Path().apply {
                moveTo(ox + 0.5f * s, oy + 0.12f * s)
                quadraticBezierTo(ox + 0.56f * s, oy + 0.44f * s, ox + 0.88f * s, oy + 0.5f * s)
                quadraticBezierTo(ox + 0.56f * s, oy + 0.56f * s, ox + 0.5f * s, oy + 0.88f * s)
                quadraticBezierTo(ox + 0.44f * s, oy + 0.56f * s, ox + 0.12f * s, oy + 0.5f * s)
                quadraticBezierTo(ox + 0.44f * s, oy + 0.44f * s, ox + 0.5f * s, oy + 0.12f * s)
                close()
            }
            drawPath(star, color, style = stroke)
        }
        GlyphKind.LAMP -> drawLamp(color, null, ox, oy, s, w, glow = 0f, flicker = 1f)
        GlyphKind.SEAL -> drawSeal(color, ox, oy, s, w, star = 1f, check = 1f)
        GlyphKind.LOCK -> {
            // A padlock whose shackle is a pointed arch — the arch of a mihrab — over a plain body.
            val shackle = Path().apply {
                moveTo(ox + 0.33f * s, oy + 0.47f * s)
                lineTo(ox + 0.33f * s, oy + 0.36f * s)
                quadraticBezierTo(ox + 0.33f * s, oy + 0.2f * s, ox + 0.5f * s, oy + 0.1f * s)
                quadraticBezierTo(ox + 0.67f * s, oy + 0.2f * s, ox + 0.67f * s, oy + 0.36f * s)
                lineTo(ox + 0.67f * s, oy + 0.47f * s)
            }
            drawPath(shackle, color, style = stroke)
            drawRoundRect(color, p(0.2f, 0.46f), Size(s * 0.6f, s * 0.44f), CornerRadius(s * 0.11f), style = stroke)
            drawCircle(color, s * 0.06f, p(0.5f, 0.64f))
            line(0.5f, 0.66f, 0.5f, 0.76f, w * 0.9f)
        }
        GlyphKind.STAR, GlyphKind.STAR_OUTLINE -> {
            val star = octagram(ox + 0.5f * s, oy + 0.5f * s, s * 0.46f)
            if (kind == GlyphKind.STAR) drawPath(star, color)
            drawPath(star, color, style = Stroke(width = w * 0.8f, join = StrokeJoin.Round))
        }
        GlyphKind.BOOKMARK -> {
            // A ribbon with the notch of a mushaf marker; filled — this glyph only marks what is kept.
            val ribbon = Path().apply {
                moveTo(ox + 0.26f * s, oy + 0.16f * s)
                quadraticBezierTo(ox + 0.26f * s, oy + 0.1f * s, ox + 0.32f * s, oy + 0.1f * s)
                lineTo(ox + 0.68f * s, oy + 0.1f * s)
                quadraticBezierTo(ox + 0.74f * s, oy + 0.1f * s, ox + 0.74f * s, oy + 0.16f * s)
                lineTo(ox + 0.74f * s, oy + 0.9f * s)
                lineTo(ox + 0.5f * s, oy + 0.72f * s)
                lineTo(ox + 0.26f * s, oy + 0.9f * s)
                close()
            }
            drawPath(ribbon, color)
            drawPath(ribbon, color, style = Stroke(width = w * 0.6f, join = StrokeJoin.Round))
        }
        GlyphKind.SHARE -> {
            line(0.33f, 0.46f, 0.67f, 0.27f, w * 0.85f)
            line(0.33f, 0.54f, 0.67f, 0.73f, w * 0.85f)
            drawCircle(color, s * 0.115f, p(0.25f, 0.5f), style = stroke)
            drawCircle(color, s * 0.115f, p(0.75f, 0.23f), style = stroke)
            drawCircle(color, s * 0.115f, p(0.75f, 0.77f), style = stroke)
        }
        GlyphKind.MOON -> {
            val r = s * 0.38f
            val crescent = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(p(0.5f, 0.5f), r))
            }
            val bite = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(p(0.66f, 0.38f), r * 0.86f))
            }
            val shape = Path().apply { op(crescent, bite, androidx.compose.ui.graphics.PathOperation.Difference) }
            drawPath(shape, color)
        }
    }
}

/**
 * The eight-pointed star of the Rub el Hizb (۞): two squares turned 45° to each other. Its inner
 * corners sit at R·cos45°/cos22.5° ≈ 0.765 R, which is where the two square edges cross.
 */
internal fun octagram(cx: Float, cy: Float, r: Float): Path = Path().apply {
    val inner = r * 0.7654f
    for (i in 0 until 16) {
        val a = Math.toRadians(-90.0 + i * 22.5)
        val rr = if (i % 2 == 0) r else inner
        val x = cx + rr * kotlin.math.cos(a).toFloat()
        val y = cy + rr * kotlin.math.sin(a).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

/**
 * «Done»: the check inside a Rub el Hizb star — the seal that closes a quarter of the mushaf.
 * [star] and [check] are 0..1 so the mark can be drawn in (DoneSeal); the static glyph passes 1, 1.
 */
internal fun DrawScope.drawSeal(color: Color, ox: Float, oy: Float, s: Float, w: Float, star: Float, check: Float) {
    if (star > 0f) {
        // The spring may overshoot: the size follows it, the opacity stays within 0..1.
        val r = s * 0.46f * (0.7f + 0.3f * star)
        val a = star.coerceIn(0f, 1f)
        val path = octagram(ox + 0.5f * s, oy + 0.5f * s, r)
        drawPath(path, color.copy(alpha = color.alpha * 0.16f * a))
        drawPath(path, color.copy(alpha = color.alpha * a), style = Stroke(width = w * 0.8f, join = StrokeJoin.Round))
    }
    if (check > 0f) {
        val tick = Path().apply {
            moveTo(ox + 0.33f * s, oy + 0.51f * s)
            lineTo(ox + 0.45f * s, oy + 0.63f * s)
            lineTo(ox + 0.68f * s, oy + 0.38f * s)
        }
        val drawn = if (check >= 1f) tick else Path().also { out ->
            val m = androidx.compose.ui.graphics.PathMeasure()
            m.setPath(tick, false)
            m.getSegment(0f, m.length * check.coerceAtMost(1f), out, true)
        }
        drawPath(drawn, color, style = Stroke(width = w * 1.15f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/**
 * The qandil — the hanging mosque lamp of an-Nur 24:35, «a lamp in a niche». It stands for a
 * streak: the lamp is lit while the days hold. [flame] null draws it unlit (the flame an outline);
 * [glow] 0..1 is the halo, [flicker] a gentle vertical breath of the flame (1 = at rest).
 */
internal fun DrawScope.drawLamp(color: Color, flame: Color?, ox: Float, oy: Float, s: Float, w: Float, glow: Float, flicker: Float) {
    val stroke = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(ox + x * s, oy + y * s)
    if (flame != null && glow > 0f) {
        drawCircle(
            androidx.compose.ui.graphics.Brush.radialGradient(
                listOf(flame.copy(alpha = 0.45f * glow), flame.copy(alpha = 0f)), center = p(0.5f, 0.56f), radius = s * 0.5f
            ),
            radius = s * 0.5f, center = p(0.5f, 0.56f)
        )
    }
    // Chain and cap.
    drawLine(color, p(0.5f, 0.02f), p(0.5f, 0.16f), strokeWidth = w * 0.8f, cap = StrokeCap.Round)
    drawLine(color, p(0.38f, 0.2f), p(0.62f, 0.2f), strokeWidth = w, cap = StrokeCap.Round)
    // The glass: a narrow neck that opens into a round bowl.
    val body = Path().apply {
        moveTo(ox + 0.41f * s, oy + 0.2f * s)
        cubicTo(ox + 0.41f * s, oy + 0.3f * s, ox + 0.18f * s, oy + 0.36f * s, ox + 0.18f * s, oy + 0.55f * s)
        cubicTo(ox + 0.18f * s, oy + 0.71f * s, ox + 0.32f * s, oy + 0.8f * s, ox + 0.44f * s, oy + 0.82f * s)
        lineTo(ox + 0.56f * s, oy + 0.82f * s)
        cubicTo(ox + 0.68f * s, oy + 0.8f * s, ox + 0.82f * s, oy + 0.71f * s, ox + 0.82f * s, oy + 0.55f * s)
        cubicTo(ox + 0.82f * s, oy + 0.36f * s, ox + 0.59f * s, oy + 0.3f * s, ox + 0.59f * s, oy + 0.2f * s)
    }
    drawPath(body, color, style = stroke)
    drawCircle(color, s * 0.045f, p(0.5f, 0.93f))
    // The flame, a drop standing on the wick.
    val top = 0.62f - 0.22f * flicker
    val drop = Path().apply {
        moveTo(ox + 0.5f * s, oy + top * s)
        cubicTo(ox + 0.57f * s, oy + (top + 0.1f) * s, ox + 0.61f * s, oy + 0.56f * s, ox + 0.59f * s, oy + 0.63f * s)
        cubicTo(ox + 0.57f * s, oy + 0.7f * s, ox + 0.43f * s, oy + 0.7f * s, ox + 0.41f * s, oy + 0.63f * s)
        cubicTo(ox + 0.39f * s, oy + 0.56f * s, ox + 0.43f * s, oy + (top + 0.1f) * s, ox + 0.5f * s, oy + top * s)
        close()
    }
    if (flame != null) drawPath(drop, flame) else drawPath(drop, color.copy(alpha = color.alpha * 0.7f), style = Stroke(width = w * 0.75f, join = StrokeJoin.Round))
}
