package com.nur.prayer.daily

/** One slide of the story of the day. */
data class StorySlide(
    val kind: String,
    val arabic: String?,
    val translit: String?,
    val ru: String,
    val source: String,
    val note: String? = null,
    /** The speaker may read [arabic] with the phone's voice. Off by default: ayat and duas never are. */
    val voiced: Boolean = false
)

/**
 * «История дня»: an ayah, a hadith and a dua, chosen by the date. Each list walks with its own
 * stride so the same three never meet again for months. Ayat and duas carry the Arabic text;
 * hadith are given in meaning, with the collection and number to look them up.
 */
object DailyStories {
    val AYAT: List<StorySlide> = listOf(
        StorySlide("Аят дня", "فَإِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ الْعُسْرِ يُسْرًا", null,
            "Воистину, за каждой тяготой наступает облегчение. Воистину, за каждой тяготой наступает облегчение.", "Аш-Шарх 94:5–6",
            "Облегчение названо дважды — оно приходит вместе с тяготой, а не после неё."),
        StorySlide("Аят дня", "أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ", null,
            "Воистину, сердца утешаются при поминании Аллаха.", "Ар-Ра‘д 13:28"),
        StorySlide("Аят дня", "فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ", null,
            "Поминайте Меня, и Я буду помнить о вас. Благодарите Меня и не будьте неблагодарны Мне.", "Аль-Бакара 2:152"),
        StorySlide("Аят дня", "وَقُل رَّبِّ زِدْنِي عِلْمًا", null,
            "И говори: «Господи! Приумножь мои знания».", "Та Ха 20:114",
            "Короткая мольба перед каждым уроком."),
        StorySlide("Аят дня", "وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ ۖ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ", null,
            "Если Мои рабы спросят тебя обо Мне, то ведь Я близок и отвечаю на мольбу молящегося, когда он взывает ко Мне.", "Аль-Бакара 2:186"),
        StorySlide("Аят дня", "وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ", null,
            "Тому, кто уповает на Аллаха, достаточно Его.", "Ат-Талак 65:3"),
        StorySlide("Аят дня", "قُلْ يَا عِبَادِيَ الَّذِينَ أَسْرَفُوا عَلَىٰ أَنفُسِهِمْ لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ", null,
            "Скажи: «О Мои рабы, которые излишествовали во вред самим себе! Не отчаивайтесь в милости Аллаха».", "Аз-Зумар 39:53"),
        StorySlide("Аят дня", "إِنَّ اللَّهَ مَعَ الصَّابِرِينَ", null,
            "Воистину, Аллах — с терпеливыми.", "Аль-Бакара 2:153"),
        StorySlide("Аят дня", "اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ", null,
            "Читай во имя твоего Господа, Который сотворил.", "Аль-‘Аляк 96:1",
            "Первое ниспосланное слово — «читай»."),
        StorySlide("Аят дня", "لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ", null,
            "Если вы будете благодарны, то Я дам вам ещё больше.", "Ибрахим 14:7"),
        StorySlide("Аят дня", "لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا", null,
            "Аллах не возлагает на человека сверх его возможностей.", "Аль-Бакара 2:286"),
        StorySlide("Аят дня", "فَإِذَا عَزَمْتَ فَتَوَكَّلْ عَلَى اللَّهِ", null,
            "Когда же ты принял решение, то уповай на Аллаха.", "Алю ‘Имран 3:159"),
        StorySlide("Аят дня", "إِنَّ أَكْرَمَكُمْ عِندَ اللَّهِ أَتْقَاكُمْ", null,
            "Воистину, самый почитаемый из вас перед Аллахом — наиболее богобоязненный.", "Аль-Худжурат 49:13")
    )

    val HADITH: List<StorySlide> = listOf(
        StorySlide("Хадис дня", null, null, "Поистине, дела оцениваются только по намерениям, и каждому человеку — лишь то, что он намеревался обрести.", "аль-Бухари 1, Муслим 1907"),
        StorySlide("Хадис дня", null, null, "Не уверует никто из вас, пока не станет желать своему брату того же, чего желает себе.", "аль-Бухари 13, Муслим 45"),
        StorySlide("Хадис дня", null, null, "Кто верует в Аллаха и в Последний день, пусть говорит благое или молчит.", "аль-Бухари 6018, Муслим 47"),
        StorySlide("Хадис дня", null, null, "Чистота — половина веры.", "Муслим 223"),
        StorySlide("Хадис дня", null, null, "Самые любимые Аллахом дела — постоянные, даже если они малы.", "аль-Бухари 6464, Муслим 783",
            "Пять минут курса каждый день лучше часа раз в неделю."),
        StorySlide("Хадис дня", null, null, "Лучший из вас тот, кто изучил Коран и обучил ему других.", "аль-Бухари 5027"),
        StorySlide("Хадис дня", null, null, "Твоя улыбка брату — садака.", "ат-Тирмизи 1956"),
        StorySlide("Хадис дня", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ", "Субҳаана-ллааһи ва би ҳамдиһ, субҳаана-ллааһиль-‘азыим",
            "Два слова легки для языка, тяжелы на весах и любимы Милостивым: «Пречист Аллах и хвала Ему, пречист Аллах Великий».", "аль-Бухари 6406, Муслим 2694"),
        StorySlide("Хадис дня", null, null, "Силён не тот, кто одолевает в борьбе, а тот, кто владеет собой в гневе.", "аль-Бухари 6114, Муслим 2609"),
        StorySlide("Хадис дня", null, null, "Кто встал на путь поиска знания, тому Аллах облегчит путь в Рай.", "Муслим 2699"),
        StorySlide("Хадис дня", null, null, "Тот, кто читает Коран умело, — вместе с благородными писцами-ангелами, а тому, кто читает с запинками и с трудом, — двойная награда.", "аль-Бухари 4937, Муслим 798",
            "Трудность чтения на старте — не помеха, а награда."),
        StorySlide("Хадис дня", null, null, "Кто прочтёт одну букву из Книги Аллаха, тому — благое дело, а благое дело воздаётся десятикратно.", "ат-Тирмизи 2910"),
        StorySlide("Хадис дня", null, null, "Аллах не смотрит на ваши облики и имущество, но смотрит на ваши сердца и дела.", "Муслим 2564"),
        StorySlide("Хадис дня", null, null, "Облегчайте, а не затрудняйте; радуйте, а не отталкивайте.", "аль-Бухари 69, Муслим 1734"),
        StorySlide("Хадис дня", null, null, "Мусульманин — тот, от языка и рук которого в безопасности мусульмане.", "аль-Бухари 10, Муслим 41")
    )

    val DUAS: List<StorySlide> = listOf(
        StorySlide("Дуа дня", "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
            "Раббанаа аатинаа фид-дуньяя ҳасанатан ва филь-аахирати ҳасанатан ва кынаа ‘азаабан-наар",
            "Господь наш! Одари нас в этом мире добром и в Последней жизни добром и защити нас от мучений в Огне.", "Аль-Бакара 2:201"),
        StorySlide("Дуа дня", "رَبِّ اشْرَحْ لِي صَدْرِي ۝ وَيَسِّرْ لِي أَمْرِي",
            "Рабби-шраҳ лии садрии, ва йассир лии амрии",
            "Господи! Раскрой для меня мою грудь и облегчи мою задачу.", "Та Ха 20:25–26"),
        StorySlide("Дуа дня", "رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً ۚ إِنَّكَ أَنتَ الْوَهَّابُ",
            "Раббанаа ляя тузиг кулуубанаа ба‘да из һадайтанаа ва һаб ланаа мил-ладунка раҳмаһ, иннака анталь-Ваһһааб",
            "Господь наш! Не уклоняй наши сердца после того, как Ты наставил нас на прямой путь, и даруй нам милость от Тебя, ведь Ты — Дарующий.", "Алю ‘Имран 3:8"),
        StorySlide("Дуа дня", "رَبَّنَا ظَلَمْنَا أَنفُسَنَا وَإِن لَّمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ",
            "Раббанаа залямнаа анфусанаа ва иль-лям тагфир ланаа ва тарҳамнаа ляна куунанна миналь-хаасириин",
            "Господь наш! Мы поступили несправедливо по отношению к себе. Если Ты не простишь нас и не помилуешь, то мы непременно окажемся среди потерпевших убыток.", "Аль-А‘раф 7:23"),
        StorySlide("Дуа дня", "لَا إِلَٰهَ إِلَّا أَنتَ سُبْحَانَكَ إِنِّي كُنتُ مِنَ الظَّالِمِينَ",
            "Ляя илааһа илляя анта субҳаанака иннии кунту миназ-заалимиин",
            "Нет божества, кроме Тебя! Пречист Ты! Воистину, я был одним из беззаконников.", "Аль-Анбийа 21:87",
            "Мольба пророка Юнуса из чрева кита."),
        StorySlide("Дуа дня", "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا",
            "Аллааһумма иннии ас’алюка ‘ильман наафи‘ан, ва ризкан таййибан, ва ‘амалян мутакаббаля",
            "О Аллах, прошу Тебя о полезном знании, благом уделе и принимаемых делах.", "Ибн Маджа 925"),
        StorySlide("Дуа дня", "يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَىٰ دِينِكَ",
            "Йаа мукаллибаль-кулууб, саббит кальбии ‘аляя дииник",
            "О Изменяющий сердца, укрепи моё сердце в Твоей религии.", "ат-Тирмизи 2140"),
        StorySlide("Дуа дня", "رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا",
            "Раббанаа һаб ланаа мин азвааджинаа ва зуррийяатинаа куррата а‘йунив-ваджъальнаа лиль-муттакиина имаамаа",
            "Господь наш! Даруй нам в наших супругах и потомках усладу для глаз и сделай нас примером для богобоязненных.", "Аль-Фуркан 25:74")
    )

    /** The three slides of [epochDay]; the fourth, the word of the day, comes from the lexicon. */
    fun of(epochDay: Long): List<StorySlide> = listOf(
        pick(AYAT, epochDay, 1),
        pick(HADITH, epochDay, 4),
        pick(DUAS, epochDay, 3)
    )

    private fun pick(list: List<StorySlide>, day: Long, stride: Int): StorySlide =
        list[Math.floorMod(day * stride + stride, list.size.toLong()).toInt()]
}

/** A dhikr for the counter. [phases] non-empty means a sequence (tasbih after prayer). */
data class DhikrPreset(
    val id: String,
    val title: String,
    val arabic: String,
    val translit: String,
    val ru: String,
    val target: Int,
    val virtue: String,
    val source: String
)

object Dhikr {
    const val AFTER_PRAYER = "after_prayer"
    const val SALAWAT = "salawat"
    const val ISTIGHFAR = "istighfar"

    val PRESETS: List<DhikrPreset> = listOf(
        DhikrPreset(AFTER_PRAYER, "После намаза", "سُبْحَانَ اللَّهِ · الْحَمْدُ لِلَّهِ · اللَّهُ أَكْبَرُ",
            "Субҳаана-ллаһ · Аль-ҳамду лил-ляһ · Аллааһу акбар", "Пречист Аллах · Хвала Аллаху · Аллах велик",
            TasbihMath.TOTAL, "Тасбих после обязательного намаза: 33, 33 и 34 раза.", "Муслим 596"),
        DhikrPreset(SALAWAT, "Салават", "اللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ",
            "Аллааһумма салли ‘аляя Муҳаммад", "О Аллах, благослови Мухаммада", 33,
            "Кто благословит Пророка ﷺ один раз, того Аллах благословит десять раз.", "Муслим 408"),
        DhikrPreset(ISTIGHFAR, "Истигфар", "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ",
            "Астагфиру-ллааһа ва атуубу иляйһ", "Прошу прощения у Аллаха и каюсь перед Ним", 100,
            "Пророк ﷺ просил прощения у Аллаха сто раз в день.", "Муслим 2702; аль-Бухари 6307"),
        DhikrPreset("tahlil", "Ля иляха илля-Ллах", "لَا إِلَٰهَ إِلَّا اللَّهُ",
            "Ляя илааһа илля-ллаһ", "Нет божества, кроме Аллаха", 100,
            "Лучшее поминание — «ля иляха илля-Ллах».", "ат-Тирмизи 3383"),
        DhikrPreset("tasbih_hamd", "Субхана-Ллахи ва бихамдихи", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
            "Субҳаана-ллааһи ва би ҳамдиһ", "Пречист Аллах и хвала Ему", 100,
            "Сказавшему сто раз в день прощаются грехи, даже если их столько, сколько морской пены.", "аль-Бухари 6405, Муслим 2691"),
        DhikrPreset("two_words", "Два лёгких слова", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ",
            "Субҳаана-ллааһи ва би ҳамдиһ, субҳаана-ллааһиль-‘азыим", "Пречист Аллах и хвала Ему, пречист Аллах Великий", 33,
            "Легки для языка, тяжелы на весах, любимы Милостивым.", "аль-Бухари 6406, Муслим 2694"),
        DhikrPreset("hawqala", "Ля хауля ва ля куввата", "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
            "Ляя ҳауля ва ляя куввата илляя би-лляһ", "Нет мощи и нет силы, кроме как у Аллаха", 33,
            "Сокровище из сокровищ Рая.", "аль-Бухари 6384, Муслим 2704"),
        DhikrPreset("subhanallah", "Субхана-Ллах", "سُبْحَانَ اللَّهِ", "Субҳаана-ллаһ", "Пречист Аллах", 33,
            "Каждое «субхана-Ллах» — садака.", "Муслим 720"),
        DhikrPreset("alhamdulillah", "Аль-хамду ли-Ллях", "الْحَمْدُ لِلَّهِ", "Аль-ҳамду лил-ляһ", "Хвала Аллаху", 33,
            "«Аль-хамду ли-Ллях» наполняет весы.", "Муслим 223"),
        DhikrPreset("takbir", "Аллаху акбар", "اللَّهُ أَكْبَرُ", "Аллааһу акбар", "Аллах велик", 33,
            "Каждое «Аллаху акбар» — садака.", "Муслим 720")
    )

    fun preset(id: String?): DhikrPreset = PRESETS.firstOrNull { it.id == id } ?: PRESETS.first()

    /** Position in [PRESETS]; unknown ids sort last. */
    fun order(id: String): Int = PRESETS.indexOfFirst { it.id == id }.let { if (it < 0) Int.MAX_VALUE else it }
}

/**
 * 0.18.5 — the daily vird: the dhikrs a person keeps every day. It replaced the separate
 * «Салават» tile of «Сегодня», which opened the very same counter as «Зикр» with one chip
 * preselected. Now there is one counter and one tile; the tile shows the vird, one ring per dhikr.
 *
 * The goal of a dhikr in the vird is one round of it ([DhikrPreset.target]): 100 of the tasbih
 * after prayer, 33 salawat, 100 istighfar. The order is always the order of [Dhikr.PRESETS], so
 * the tile and the chip row read the same way whatever order the stars were set in.
 */
object Vird {
    val DEFAULT: List<String> = listOf(Dhikr.AFTER_PRAYER, Dhikr.SALAWAT, Dhikr.ISTIGHFAR)
    /** Four rings fit the narrowest tile with readable labels. */
    const val MAX = 4

    /** Lenient: unknown or repeated ids are dropped. Nothing stored yet is the default vird; an empty string is an empty one. */
    fun decode(raw: String?): List<String> {
        if (raw == null) return DEFAULT
        return normalize(raw.split(',').map { it.trim() })
    }

    fun encode(ids: List<String>): String = normalize(ids).joinToString(",")

    fun normalize(ids: List<String>): List<String> =
        ids.filter { id -> Dhikr.PRESETS.any { it.id == id } }.distinct().sortedBy { Dhikr.order(it) }.take(MAX)

    /** Adds or removes [id]; a full vird stays as it is (the caller says why). */
    fun toggle(ids: List<String>, id: String): List<String> = when {
        id in ids -> ids - id
        ids.size >= MAX || Dhikr.PRESETS.none { it.id == id } -> ids
        else -> normalize(ids + id)
    }

    fun isFull(ids: List<String>): Boolean = ids.size >= MAX

    fun count(id: String, today: Map<String, Long>): Long = today[id] ?: 0L

    fun done(id: String, today: Map<String, Long>): Boolean = count(id, today) >= Dhikr.preset(id).target

    /** How far today's count is towards one round, 0..1. */
    fun fraction(id: String, today: Map<String, Long>): Float =
        (count(id, today).toFloat() / Dhikr.preset(id).target).coerceIn(0f, 1f)

    fun doneCount(ids: List<String>, today: Map<String, Long>): Int = ids.count { done(it, today) }

    fun allDone(ids: List<String>, today: Map<String, Long>): Boolean = ids.isNotEmpty() && ids.all { done(it, today) }

    /**
     * The next dhikr still open, searching after [after] and wrapping around, so «Дальше» walks the
     * vird in order. Null when everything is said (or the vird is empty).
     */
    fun next(ids: List<String>, today: Map<String, Long>, after: String? = null): String? {
        if (ids.isEmpty()) return null
        val start = ids.indexOf(after).let { if (it < 0) 0 else it + 1 }
        for (k in ids.indices) {
            val id = ids[(start + k) % ids.size]
            if (id != after && !done(id, today)) return id
        }
        return null
    }
}

/** Tasbih after prayer: 33 · 33 · 34, one hundred in all (Muslim 596). */
object TasbihMath {
    const val TOTAL = 100
    private val PHASES = listOf(
        Triple("سُبْحَانَ اللَّهِ", "Субҳаана-ллаһ", 33),
        Triple("الْحَمْدُ لِلَّهِ", "Аль-ҳамду лил-ляһ", 33),
        Triple("اللَّهُ أَكْبَرُ", "Аллааһу акбар", 34)
    )

    /** Phase index and the count inside it; past 100 it stays on the finished last phase. */
    fun phase(count: Int): Pair<Int, Int> {
        var left = count.coerceIn(0, TOTAL)
        PHASES.forEachIndexed { i, p ->
            if (left < p.third || i == PHASES.lastIndex) return i to left.coerceAtMost(p.third)
            left -= p.third
        }
        return PHASES.lastIndex to PHASES.last().third
    }

    /**
     * 0.18.5: the tasbih is said after every obligatory prayer, so the counter goes round instead
     * of stopping at 100. The count inside the current round, 1..100; a round just completed reads
     * 100 (its finished face), the next tap starts the following round at 1.
     */
    fun inRound(count: Int): Int = when {
        count <= 0 -> 0
        count % TOTAL == 0 -> TOTAL
        else -> count % TOTAL
    }

    /** Rounds completed today. */
    fun rounds(count: Int): Int = count.coerceAtLeast(0) / TOTAL

    /** A round has just closed: 100, 200… — the face shows the seal until the next tap. */
    fun roundClosed(count: Int): Boolean = count > 0 && count % TOTAL == 0

    /** The tap that brought the count to [count] ended a phase (33, 66) or the round (100). */
    fun phaseEnd(count: Int): Boolean = count > 0 && (count % TOTAL).let { it == 33 || it == 66 || it == 0 }

    fun arabic(i: Int) = PHASES[i].first
    fun reading(i: Int) = PHASES[i].second
    fun size(i: Int) = PHASES[i].third
}
