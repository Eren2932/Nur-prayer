package com.nur.prayer

import android.app.Application
import com.nur.prayer.core.astro.PrintedCalendars
import com.nur.prayer.data.CityRepository
import com.nur.prayer.data.SettingsRepository
import com.nur.prayer.i18n.L10n
import com.nur.prayer.notify.NotificationHelper
import com.nur.prayer.ui.theme.ArabicFont

class NurApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        instance = this
        CrashReport.install(this)

        /*
         * The printed tables are installed here, once, and read lazily on first use.
         *
         * The engine is pure Kotlin so that every calendar claim can be locked by a JVM unit test,
         * which means it cannot reach into `assets` itself. This is the one line that connects the
         * two, and `runCatching` is deliberate: a missing or damaged asset must fall back to
         * computed astronomy, never take down the launch of a prayer app.
         */
        val assetManager = assets
        PrintedCalendars.install { name ->
            runCatching {
                assetManager.open(name).bufferedReader().use { reader -> reader.readText() }
            }.getOrNull()
        }

        // Before anything can show a word: the first frame and an alarm from a cold process both
        // speak the chosen language. Channel names follow a switch (Android keeps ids, updates names).
        L10n.install(this)
        // The mushaf face is read on a background thread so the first Quran frame does not wait.
        ArabicFont.install(this)
        NotificationHelper.createChannels(this)
        L10n.onChange { NotificationHelper.createChannels(this) }
    }

    companion object {
        lateinit var instance: NurApplication
            private set
    }
}

/** Tiny hand-rolled service locator: no DI framework, no build-time codegen, instant builds. */
object Graph {
    private var cityRepo: CityRepository? = null
    private var settingsRepo: SettingsRepository? = null

    fun cities(context: android.content.Context): CityRepository =
        cityRepo ?: CityRepository(context.applicationContext).also { cityRepo = it }

    fun settings(context: android.content.Context): SettingsRepository =
        settingsRepo ?: SettingsRepository(context.applicationContext).also { settingsRepo = it }
}
