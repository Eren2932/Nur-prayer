package com.nur.prayer.ui.quran

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import com.nur.prayer.quran.QuranStore
import com.nur.prayer.ui.theme.Amber
import com.nur.prayer.ui.theme.Mint

/*
 * 0.17.0 — the Quran gets its own reading surface.
 *
 * The rest of the app is a window onto the sky of the current prayer; a long read is not. Behind
 * the mushaf the colour of noon or sunset only competes with the text, so the section draws a
 * surface of its own:
 *  - «Тёмный» (default): an even, hue-less dark;
 *  - «Чёрный»: true black for the night and AMOLED;
 *  - «Светлый» (0.18.4, replaces «Небо»): the page of a printed mushaf. Not white: the warm
 *    cream of mushaf paper, ink that is warm near-black rather than #000, and the gold-brown of
 *    the frame ornament and ayah markers. White paper glares in a long read; cream is what the
 *    Madinah and Kazan printings use for exactly that reason.
 * Accents are one muted gold, the colour of mushaf ornament, instead of the prayer accent that
 * changes five times a day.
 *
 * Contrast (WCAG) on every paper surface — page top and bottom, card, raised, inset: text ≥ 13.4 : 1,
 * secondary ≥ 6.5, and tertiary, accentText, positive, warning all ≥ 4.5 (AA for small text) even on
 * the deepest inset plate. Dark ink on the gold fill: 5.9. QuranThemeTest holds these numbers.
 */
@Immutable
internal class QuranColors(
    /** Top and bottom of the page gradient. */
    val background: Color,
    val backgroundBottom: Color,
    /** The plate of the reader's top bar. */
    val bar: Color,
    val card: Color,
    val raised: Color,
    val inset: Color,
    val hairline: Color,
    /** Fills: progress, rings, selection, primary buttons. */
    val accent: Color,
    /** The accent as text or a thin mark on the page: ayah numbers, «Хатм», captions. */
    val accentText: Color,
    /** Ink on an [accent] fill. */
    val onAccent: Color,
    val text: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    /** Done, on schedule, sajda. */
    val positive: Color,
    /** Behind schedule. */
    val warning: Color,
    /** Dims the page under a sheet. */
    val scrim: Color,
    /** A light page: dark system-bar icons, colours darkened (not lifted) for text. */
    val light: Boolean
) {
    /** A tint used as text on this surface: lifted towards white on dark, deepened on paper. */
    fun readable(tint: Color): Color = if (light) tint.deepenedForText() else tint.liftedForText()
}

/** Muted mushaf gold: readable on both dark surfaces, never loud. */
private val Gold = Color(0xFFD9BA74)
private val GoldNight = Color(0xFFCDAE69)
/** Ornament gold of a printed page, and its deeper ink for text on paper. */
private val PaperGold = Color(0xFFB48C3F)
private val PaperGoldInk = Color(0xFF7E5A18)
private val Ink = Color(0xFF1A1405)

internal fun quranColors(theme: Int): QuranColors = when (theme) {
    QuranStore.THEME_BLACK -> QuranColors(
        background = Color(0xFF000000), backgroundBottom = Color(0xFF000000), bar = Color(0xF5000000),
        card = Color(0xFF0F1114), raised = Color(0xFF181B20), inset = Color(0xFF0A0B0D), hairline = Color(0x17FFFFFF),
        accent = GoldNight, accentText = GoldNight.liftedForText(), onAccent = Ink,
        text = Color(0xFFE6E7EA), textSecondary = Color(0xFFADB1B9), textTertiary = Color(0xFF80858F),
        positive = Mint, warning = Amber, scrim = Color(0xB3000000), light = false
    )
    QuranStore.THEME_LIGHT -> QuranColors(
        background = Color(0xFFFAF4E4), backgroundBottom = Color(0xFFF3EAD3), bar = Color(0xF5FAF4E4),
        card = Color(0xFFFFFBF0), raised = Color(0xFFF0E6CC), inset = Color(0xFFEDE2C6), hairline = Color(0x245A4524),
        accent = PaperGold, accentText = PaperGoldInk, onAccent = Ink,
        text = Color(0xFF1E1A13), textSecondary = Color(0xFF574C3B), textTertiary = Color(0xFF6E6352),
        positive = Color(0xFF286C4B), warning = Color(0xFF9A4C17), scrim = Color(0x5C2A2012), light = true
    )
    else -> QuranColors(
        background = Color(0xFF13161C), backgroundBottom = Color(0xFF0C0E12), bar = Color(0xF513161C),
        card = Color(0xFF191D24), raised = Color(0xFF20252E), inset = Color(0xFF0E1015), hairline = Color(0x17FFFFFF),
        accent = Gold, accentText = Gold.liftedForText(), onAccent = Ink,
        text = Color(0xFFEDEEF0), textSecondary = Color(0xFFB9BDC6), textTertiary = Color(0xFF8B909A),
        positive = Mint, warning = Amber, scrim = Color(0x99000000), light = false
    )
}

/** A theme switch cross-fades every surface instead of flashing. */
@Composable
internal fun animatedQuranColors(target: QuranColors): QuranColors {
    val spec = tween<Color>(360)
    return QuranColors(
        background = animateColorAsState(target.background, spec, label = "qBg").value,
        backgroundBottom = animateColorAsState(target.backgroundBottom, spec, label = "qBgBottom").value,
        bar = animateColorAsState(target.bar, spec, label = "qBar").value,
        card = animateColorAsState(target.card, spec, label = "qCard").value,
        raised = animateColorAsState(target.raised, spec, label = "qRaised").value,
        inset = animateColorAsState(target.inset, spec, label = "qInset").value,
        hairline = animateColorAsState(target.hairline, spec, label = "qHairline").value,
        accent = animateColorAsState(target.accent, spec, label = "qAccent").value,
        accentText = animateColorAsState(target.accentText, spec, label = "qAccentText").value,
        onAccent = target.onAccent,
        text = animateColorAsState(target.text, spec, label = "qText").value,
        textSecondary = animateColorAsState(target.textSecondary, spec, label = "qText2").value,
        textTertiary = animateColorAsState(target.textTertiary, spec, label = "qText3").value,
        positive = animateColorAsState(target.positive, spec, label = "qPositive").value,
        warning = animateColorAsState(target.warning, spec, label = "qWarning").value,
        scrim = target.scrim,
        light = target.light
    )
}

/** Accent tints sit on dark surfaces: lifted halfway to white, text on them stays readable. */
internal fun Color.liftedForText(): Color = Color(
    red = red + (1f - red) * 0.45f, green = green + (1f - green) * 0.45f, blue = blue + (1f - blue) * 0.45f, alpha = 1f
)

/** The paper counterpart: a third of the way to black, so a tint reads as ink on cream. */
internal fun Color.deepenedForText(): Color = Color(red = red * 0.66f, green = green * 0.66f, blue = blue * 0.66f, alpha = 1f)
