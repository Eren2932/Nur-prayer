package com.nur.prayer.ui.schedule

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.FileProvider
import com.nur.prayer.ui.quran.AyahImageShare
import com.nur.prayer.ui.theme.PhasePalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/*
 * 0.19.0 — the month as a picture, the way the mosques print it on paper: the month and the hijri
 * months it spans, the city, a ruled table of the times with Fridays and the days of the Islamic
 * year marked in their colours, a legend of those days. 0.20.0 moved the signature to the top
 * (a lockup «☾ Nur · Время намаза» next to the city) and repeated it small in the footer.
 * Drawn straight onto a Bitmap over the sky of the moment.
 *
 * The spec is plain strings and colours, built on the UI side (where tr() and the palette live), so
 * this file only lays out and paints.
 */

internal class CalendarShareRow(
    val day: String,
    val weekday: String,
    val hijriDay: String,
    val times: List<String>,
    val friday: Boolean,
    val today: Boolean,
    /** ARGB of the kind of day, or null on an ordinary day. */
    val tone: Int?
)

internal class CalendarShareSpec(
    val kicker: String,
    val title: String,
    val subtitle: String,
    val place: String,
    val dateHeader: String,
    val columns: List<String>,
    val rows: List<CalendarShareRow>,
    /** ARGB colour → "10 нояб. · Ашура". */
    val legend: List<Pair<Int, String>>,
    val footnote: String,
    val palette: PhasePalette
)

internal object CalendarImageShare {
    private const val WIDTH = 1080
    private const val MARGIN = 56
    private const val ROW = 54
    private const val HEAD = 72
    private const val FILE_NAME = "calendar.png"

    /*
     * 0.20.0 layout, top to bottom:
     *
     *   ☾ Nur · ВРЕМЯ НАМАЗА                 📍 Казань     ← the signature, where nobody crops it
     *   Ноябрь 2026                                        ← the month, once and large
     *   джумада аль-уля — джумада ас-сани 1448
     *   ┌ ДАТА  СУХУР ФАДЖР … ИША ┐                       ← ruled table, zebra rows, today lit
     *   ● 10 нояб. · …                                     ← legend, only when the month has days
     *   ─────────────────────────
     *   Даты хиджры — по Умм аль-Кура            nur       ← one quiet line
     *
     * The old picture had a kicker, a pin line, a divider ornament and a faded «Nur» at the very foot
     * (the first thing a crop removes). Now the brand opens the picture as a lockup and the footer
     * repeats it small, aligned to the right edge of the table.
     */
    fun render(spec: CalendarShareSpec): Bitmap {
        val p = spec.palette
        val accent = p.accent.toArgb()
        val accentSoft = p.accentSoft.toArgb()
        val white = 0xFFFFFFFF.toInt()
        val quiet = 0xB3FFFFFF.toInt()
        val faint = 0x80FFFFFF.toInt()
        val inner = WIDTH - 2 * MARGIN

        val brand = paint(40f, white, bold = true).apply { letterSpacing = 0.04f }
        val kicker = paint(22f, quiet, bold = true).apply { letterSpacing = 0.18f }
        val place = paint(28f, white, bold = true).apply { textAlign = Paint.Align.RIGHT }
        val title = paint(80f, white, bold = true)
        val subtitle = paint(32f, accentSoft, bold = false)
        val legendPaint = paint(28f, white, bold = false)

        // Vertical budget: header, table, legend, footer.
        val headerHeight = 56 + 56 + 34 + 92 + 46 + 40
        val tableHeight = HEAD + spec.rows.size * ROW
        val legendHeight = if (spec.legend.isEmpty()) 0 else 36 + spec.legend.size * 46
        val footerHeight = 40 + 2 + 30 + 34 + 48
        val height = headerHeight + tableHeight + legendHeight + footerHeight

        val bitmap = Bitmap.createBitmap(WIDTH, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        // Our sky: zenith → mid → horizon, with the glow of the horizon rising from the foot.
        canvas.drawRect(0f, 0f, WIDTH.toFloat(), height.toFloat(), Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, height.toFloat(),
                intArrayOf(p.zenith.toArgb(), p.mid.toArgb(), p.horizon.toArgb()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        })
        val glow = p.glow.toArgb()
        if ((glow ushr 24) > 0) canvas.drawRect(0f, 0f, WIDTH.toFloat(), height.toFloat(), Paint().apply {
            shader = RadialGradient(WIDTH / 2f, height.toFloat(), WIDTH * 0.9f, glow, 0, Shader.TileMode.CLAMP)
        })
        // A dark wash keeps every figure legible on the lightest sky (Dhuhr, Asr).
        canvas.drawRect(0f, 0f, WIDTH.toFloat(), height.toFloat(), Paint().apply { color = 0x40000000 })

        val left = MARGIN.toFloat()
        val right = (WIDTH - MARGIN).toFloat()

        // ── The signature: ☾ Nur · ВРЕМЯ НАМАЗА ··· 📍 City ─────────────────────────────────────
        var y = 56f
        val lineMid = y + 28f
        drawCrescent(canvas, left + 20f, lineMid, 20f, accent)
        val brandX = left + 52f
        val brandBase = lineMid - (brand.fontMetrics.ascent + brand.fontMetrics.descent) / 2f
        canvas.drawText("Nur", brandX, brandBase, brand)
        val afterBrand = brandX + brand.measureText("Nur") + 18f
        canvas.drawCircle(afterBrand, lineMid, 4f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = faint })
        val kickerX = afterBrand + 18f
        val kickerText = spec.kicker.uppercase()
        val kickerBase = lineMid - (kicker.fontMetrics.ascent + kicker.fontMetrics.descent) / 2f
        // The city takes what the lockup leaves, ellipsized; the pin sits just before the text.
        val placeRoom = right - (kickerX + kicker.measureText(kickerText)) - 40f - 36f
        val placeText = fit(spec.place, place, placeRoom.coerceAtLeast(120f))
        val placeBase = lineMid - (place.fontMetrics.ascent + place.fontMetrics.descent) / 2f
        canvas.drawText(placeText, right, placeBase, place)
        val pinX = right - place.measureText(placeText) - 22f
        drawPin(canvas, pinX, lineMid + 2f, accent)
        if (placeRoom >= 120f) canvas.drawText(kickerText, kickerX, kickerBase, kicker)
        y += 56f + 34f

        // ── The month ───────────────────────────────────────────────────────────────────────
        canvas.drawText(fit(spec.title, title, inner.toFloat()), left, y - title.fontMetrics.ascent, title)
        y += 92f
        canvas.drawText(fit(spec.subtitle, subtitle, inner.toFloat()), left, y - subtitle.fontMetrics.ascent, subtitle)
        y += 46f + 40f

        // ── The table ────────────────────────────────────────────────────────────────────────
        val card = RectF(left, y, right, y + tableHeight)
        canvas.drawRoundRect(card, 32f, 32f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x24FFFFFF })
        canvas.save()
        canvas.clipPath(Path().apply { addRoundRect(card, 32f, 32f, Path.Direction.CW) })
        canvas.drawRect(left, y, right, y + HEAD, Paint().apply { color = withAlpha(accent, 0x55) })

        val dateWidth = 200f
        val colWidth = (inner - dateWidth) / spec.columns.size.coerceAtLeast(1)
        fun colCenter(i: Int) = left + dateWidth + colWidth * i + colWidth / 2f
        val headPaint = paint(24f, white, bold = true).apply { textAlign = Paint.Align.CENTER; letterSpacing = 0.04f }
        val headSize = spec.columns.minOfOrNull { fitSize(it.uppercase(), 24f, colWidth - 10f, true) } ?: 24f
        headPaint.textSize = headSize
        val headBase = y + HEAD / 2f - (headPaint.fontMetrics.ascent + headPaint.fontMetrics.descent) / 2f
        val dateHead = paint(headSize, white, bold = true).apply { letterSpacing = 0.04f }
        canvas.drawText(fit(spec.dateHeader.uppercase(), dateHead, dateWidth - 28f), left + 26f, headBase, dateHead)
        spec.columns.forEachIndexed { i, c -> canvas.drawText(c.uppercase(), colCenter(i), headBase, headPaint) }
        y += HEAD

        val dayPaint = paint(30f, white, bold = true).apply { fontFeatureSettings = "tnum" }
        val weekPaint = paint(23f, quiet, bold = false)
        val hijriPaint = paint(21f, faint, bold = false).apply { textAlign = Paint.Align.RIGHT }
        val timePaint = paint(30f, white, bold = false).apply { textAlign = Paint.Align.CENTER; fontFeatureSettings = "tnum" }
        val timeBold = paint(30f, white, bold = true).apply { textAlign = Paint.Align.CENTER; fontFeatureSettings = "tnum" }
        val rule = Paint().apply { color = 0x14FFFFFF; strokeWidth = 2f }
        // A hairline between the date cell and the times: the eye reads the row left to right.
        val split = Paint().apply { color = 0x1FFFFFFF; strokeWidth = 2f }
        spec.rows.forEachIndexed { index, r ->
            val top = y + index * ROW
            when {
                r.today -> canvas.drawRect(left, top, right, top + ROW, Paint().apply { color = withAlpha(accent, 0x5C) })
                r.tone != null -> canvas.drawRect(left, top, right, top + ROW, Paint().apply { color = withAlpha(r.tone, 0x2E) })
                r.friday -> canvas.drawRect(left, top, right, top + ROW, Paint().apply { color = 0x1AFFFFFF })
                index % 2 == 1 -> canvas.drawRect(left, top, right, top + ROW, Paint().apply { color = 0x0AFFFFFF })
            }
            if (r.tone != null) canvas.drawRect(left, top + 8f, left + 7f, top + ROW - 8f, Paint().apply { color = r.tone })
            if (index > 0) canvas.drawLine(left, top, right, top, rule)
            val base = top + ROW / 2f - (timePaint.fontMetrics.ascent + timePaint.fontMetrics.descent) / 2f
            canvas.drawText(r.day, left + 26f, base, dayPaint)
            weekPaint.color = if (r.friday) accent else quiet
            weekPaint.isFakeBoldText = r.friday
            canvas.drawText(r.weekday, left + 26f + dayPaint.measureText("00") + 12f, base, weekPaint)
            hijriPaint.color = r.tone ?: faint
            canvas.drawText(r.hijriDay, left + dateWidth - 16f, base, hijriPaint)
            r.times.forEachIndexed { i, t -> canvas.drawText(t, colCenter(i), base, if (r.today) timeBold else timePaint) }
        }
        canvas.drawLine(left + dateWidth, y, left + dateWidth, y + spec.rows.size * ROW, split)
        canvas.restore()
        canvas.drawRoundRect(card, 32f, 32f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 2f; color = 0x2EFFFFFF
        })
        y += spec.rows.size * ROW

        // ── The days of the month ────────────────────────────────────────────────────────────
        if (spec.legend.isNotEmpty()) {
            y += 36f
            spec.legend.forEach { (tone, text) ->
                canvas.drawCircle(left + 12f, y + 20f, 9f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = tone })
                canvas.drawText(fit(text, legendPaint, inner - 40f), left + 38f, y + 20f - (legendPaint.fontMetrics.ascent + legendPaint.fontMetrics.descent) / 2f, legendPaint)
                y += 46f
            }
        }

        // ── Footer: the note on the left, the small signature on the right ───────────────────
        y += 40f
        canvas.drawLine(left, y, right, y, Paint().apply { color = 0x26FFFFFF; strokeWidth = 2f })
        y += 2f + 30f
        val mark = paint(26f, accent, bold = true).apply { letterSpacing = 0.12f; textAlign = Paint.Align.RIGHT }
        val markText = "Nur"
        val markWidth = mark.measureText(markText)
        val note = paint(22f, faint, bold = false)
        val footBase = y - note.fontMetrics.ascent
        canvas.drawText(fit(spec.footnote, note, inner - markWidth - 60f), left, footBase, note)
        drawCrescent(canvas, right - markWidth - 18f, footBase - 9f, 10f, accent)
        canvas.drawText(markText, right, footBase, mark)
        return bitmap
    }

    /** Writes the picture to cacheDir/share/calendar.png and opens the share sheet. */
    suspend fun share(context: Context, spec: CalendarShareSpec): Boolean {
        val file = withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(context.cacheDir, "share").apply { mkdirs() }
                val out = File(dir, FILE_NAME)
                val bitmap = render(spec)
                try {
                    out.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                } finally {
                    bitmap.recycle()
                }
                out
            }.getOrNull()
        } ?: return false
        return runCatching {
            // Same provider and path as the ayah picture (cache/share/).
            val uri = FileProvider.getUriForFile(context, AyahImageShare.authority(context), file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.isSuccess
    }

    private fun paint(size: Float, color: Int, bold: Boolean) = TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
        textSize = size
        this.color = color
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun withAlpha(argb: Int, alpha: Int): Int = (argb and 0x00FFFFFF) or (alpha shl 24)

    /** Ellipsize a single line to [width]; the header names are short, a long city is not. */
    private fun fit(text: String, paint: TextPaint, width: Float): String =
        TextUtils.ellipsize(text, paint, width, TextUtils.TruncateAt.END).toString()

    /** The largest size ≤ [start] at which [text] fits [width] (prayer names differ by language). */
    private fun fitSize(text: String, start: Float, width: Float, bold: Boolean): Float {
        val p = paint(start, 0, bold)
        var size = start
        while (size > 16f && p.measureText(text) > width) {
            size -= 1f
            p.textSize = size
        }
        return size
    }

    private fun drawPin(canvas: Canvas, cx: Float, cy: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }
        val pin = Path().apply {
            moveTo(cx, cy + 16f)
            cubicTo(cx - 16f, cy - 2f, cx - 12f, cy - 18f, cx, cy - 18f)
            cubicTo(cx + 12f, cy - 18f, cx + 16f, cy - 2f, cx, cy + 16f)
            close()
        }
        canvas.drawPath(pin, paint)
        canvas.drawCircle(cx, cy - 6f, 5f, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = 0xFF14122E.toInt() })
    }

    /** ☾ — a crescent cut from a disc by a second, offset disc: the mark of the app on paper. */
    private fun drawCrescent(canvas: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        val disc = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        val bite = Path().apply { addCircle(cx + r * 0.42f, cy - r * 0.18f, r * 0.84f, Path.Direction.CW) }
        disc.op(bite, Path.Op.DIFFERENCE)
        canvas.drawPath(disc, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
    }
}
