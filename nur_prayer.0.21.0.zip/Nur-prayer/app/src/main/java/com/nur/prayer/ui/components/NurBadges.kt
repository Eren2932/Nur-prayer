package com.nur.prayer.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp

/*
 * 0.18.4 — the marks that used to be emoji and font symbols.
 *
 * 🔥 came from a game's streak, ✓ from a to-do list, 🔒 and ★ from the keyboard: four borrowed
 * styles, each rendered differently by every vendor font. Nur draws its own, from its own world:
 *  - a streak is a lit qandil, the mosque lamp of an-Nur 24:35 — the app's name;
 *  - «done» is the Rub el Hizb star ۞ that closes a quarter of the mushaf, with a check inside;
 *  - «locked» is a padlock whose shackle is a pointed mihrab arch;
 *  - a lesson's stars are the same eight-pointed star.
 * All are vector, take the caller's colour and scale with the user's font scale through [size].
 */

/** The flame of a lit lamp: warm and the same on every background. */
val LampFlame = Color(0xFFF2B65A)

/**
 * The streak lamp. Lit while [lit] (a live streak), its flame breathes and the halo glows; unlit
 * it is an outline with an empty flame — a quiet invitation rather than a scolding zero.
 */
@Composable
fun StreakLamp(lit: Boolean, tint: Color, size: Dp, modifier: Modifier = Modifier) {
    val on by animateFloatAsState(if (lit) 1f else 0f, NurMotion.gentle(), label = "lampOn")
    val breath = if (lit) {
        val t = rememberInfiniteTransition(label = "lampFlicker")
        t.animateFloat(0.9f, 1.04f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "flame").value
    } else 1f
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        val ox = (this.size.width - s) / 2f
        val oy = (this.size.height - s) / 2f
        val flame = if (on > 0.01f) LampFlame.copy(alpha = on.coerceIn(0f, 1f)) else null
        drawLamp(tint, flame, ox, oy, s, s * 0.08f, glow = on * (0.55f + 0.45f * (breath - 0.9f) / 0.14f), flicker = 0.85f + 0.15f * breath * on)
    }
}

/**
 * «Done», drawn in: the star opens, then the check is written into it. [animate] false shows the
 * finished mark at once (lists that scroll past many done items must not replay it).
 */
@Composable
fun DoneSeal(tint: Color, size: Dp, modifier: Modifier = Modifier, animate: Boolean = true) {
    val star = remember { Animatable(if (animate) 0f else 1f) }
    val check = remember { Animatable(if (animate) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (animate) {
            star.animateTo(1f, NurMotion.bouncy())
            check.animateTo(1f, tween(260, easing = FastOutSlowInEasing))
        }
    }
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        drawSeal(tint, (this.size.width - s) / 2f, (this.size.height - s) / 2f, s, s * 0.09f, star.value, check.value)
    }
}
