package com.nur.prayer.ui.learn

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.learn.Ayah
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.learn.LearnProgress
import com.nur.prayer.learn.QuranShort
import com.nur.prayer.learn.Surah
import com.nur.prayer.quran.HifzMode
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.quran.QuranRepository
import com.nur.prayer.quran.QuranStore
import com.nur.prayer.quran.QuranText
import com.nur.prayer.ui.components.DoneSeal
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.LocalBackdropPaused
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.components.rememberEntranceClock
import com.nur.prayer.ui.quran.Ornament
import com.nur.prayer.ui.quran.QChip
import com.nur.prayer.ui.quran.QuranColors
import com.nur.prayer.ui.quran.READER_MAX_WIDTH
import com.nur.prayer.ui.quran.ReaderSheet
import com.nur.prayer.ui.quran.ReadingSizes
import com.nur.prayer.ui.quran.ReadingSwitch
import com.nur.prayer.ui.quran.ReadingThemeRow
import com.nur.prayer.ui.quran.SheetLabel
import com.nur.prayer.ui.quran.animatedQuranColors
import com.nur.prayer.ui.quran.quranColors
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SystemBarsTone
import com.nur.prayer.ui.theme.findActivity
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue

/**
 * The short surahs, 0.18.5: read on the mushaf's own surface. Page (dark, black, paper), Arabic
 * size, translation size and transliteration are the reader's ([QuranStore]): a choice made here
 * holds in the Quran and back. The surahs lie side by side — a swipe or a tab turns the page;
 * the reading aids are the reader's row (Транслит, Хифз and its three modes, a tap on an ayah
 * opens it), and every page ends with the check of that surah.
 *
 * [palette] is kept for the signature of the layer routes; the surface does not follow the sky.
 */
@Composable
fun SurahScreen(
    content: LearnContent?,
    progress: LearnProgress,
    @Suppress("UNUSED_PARAMETER") palette: PhasePalette,
    onBack: () -> Unit,
    onPractice: (Int) -> Unit
) {
    val ui = uiScale()
    val context = LocalContext.current
    val store = remember { QuranStore.get(context) }
    val target = quranColors(store.readerTheme)
    val colors = animatedQuranColors(target)

    // An opaque page: the sky under it would tick for nothing.
    val backdropPaused = LocalBackdropPaused.current
    DisposableEffect(Unit) {
        backdropPaused.value = true
        onDispose { backdropPaused.value = false }
    }
    val view = LocalView.current
    DisposableEffect(target.light) {
        val window = view.context.findActivity()?.window
        SystemBarsTone.set(window, target.light)
        onDispose { SystemBarsTone.set(window, false) }
    }
    // A surah is learnt by looking at it for minutes without a touch.
    val awake = store.keepAwake
    DisposableEffect(awake) {
        if (awake) view.keepScreenOn = true
        onDispose { if (awake) view.keepScreenOn = false }
    }

    // The reader's hifz hints (joined particles keep their letter): one mask for the whole Quran.
    val repo = remember { QuranRepository.get(context) }
    LaunchedEffect(Unit) { repo.loadHifzParticles() }
    val particles = repo.hifzParticles ?: emptyMap()

    val surahs = QuranShort.SURAHS
    val pager = rememberPagerState { surahs.size }
    var hifzOrdinal by rememberSaveable { mutableStateOf(HifzMode.OFF.ordinal) }
    val hifz = HifzMode.of(hifzOrdinal)
    var settings by rememberSaveable { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    BackHandler(settings) { settings = false }

    // Drawn up under the status bar from this page, as the Quran does: it slides with the page.
    val statusBar = WindowInsets.statusBars.getTop(LocalDensity.current).toFloat()
    Box(
        Modifier.fillMaxSize().drawBehind {
            drawRect(colors.background, Offset(0f, -statusBar), Size(size.width, statusBar))
            drawRect(Brush.verticalGradient(listOf(colors.background, colors.backgroundBottom)))
        }
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = ui.s(16f), vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIconButton(GlyphKind.BACK, tr("Назад"), onBack, tint = colors.text, background = colors.raised)
                HGap(14f)
                Text(tr("Короткие суры"), color = colors.text, fontSize = ui.t(24f), fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                HGap(8f)
                RoundIconButton(GlyphKind.SLIDERS, tr("Настройки чтения"), { settings = true }, tint = colors.text, background = colors.raised)
            }
            SurahTabs(surahs, pager.targetPage, progress, colors) { i -> scope.launch { pager.animateScrollToPage(i) } }
            ReadingAids(store, hifz, colors) { hifzOrdinal = it.ordinal }
            Box(Modifier.fillMaxWidth().height(1.dp).background(colors.hairline))
            if (content == null) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(tr("Загружаем…"), color = colors.textSecondary)
                }
            } else {
                HorizontalPager(pager, Modifier.weight(1f).fillMaxWidth(), key = { surahs[it].number }) { page ->
                    val s = surahs[page]
                    val next = surahs.getOrNull(page + 1)
                    SurahPage(
                        s, content.quran.ayat(s.number), store, colors, hifz, particles,
                        stars = progress.stars(QuranShort.lessonId(s.number)),
                        next = next,
                        onNext = { scope.launch { pager.animateScrollToPage(page + 1) } },
                        onPractice = { onPractice(s.number) },
                        // A page on its way out fades and settles back a little, as in the reader.
                        modifier = Modifier.graphicsLayer {
                            val offset = ((pager.currentPage - page) + pager.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                            alpha = 1f - offset * PAGE_FADE
                            val scale = 1f - offset * PAGE_SHRINK
                            scaleX = scale
                            scaleY = scale
                        }
                    )
                }
            }
        }
        ReaderSheet(settings, colors, onDismiss = { settings = false }) {
            ShortSurahSettings(store, colors)
        }
    }
}

/** The surah row; a checked surah carries a seal. Follows the pager while it turns. */
@Composable
private fun SurahTabs(surahs: List<Surah>, selected: Int, progress: LearnProgress, colors: QuranColors, onPick: (Int) -> Unit) {
    val ui = uiScale()
    val row = rememberLazyListState()
    LaunchedEffect(selected) { row.animateScrollToItem((selected - 1).coerceAtLeast(0)) }
    LazyRow(
        state = row,
        contentPadding = PaddingValues(horizontal = ui.s(16f)),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        itemsIndexed(surahs, key = { _, s -> s.number }) { i, s ->
            val on = i == selected
            val shape = RoundedCornerShape(50)
            val fill by animateColorAsState(if (on) colors.accent.copy(alpha = 0.26f) else colors.raised, tween(TAB_MILLIS), label = "surahTab")
            val ink by animateColorAsState(if (on) colors.text else colors.textSecondary, tween(TAB_MILLIS), label = "surahTabInk")
            Row(
                Modifier.clip(shape).background(fill).pressClick(scaleTo = 0.96f, shape = shape) { onPick(i) }
                    .padding(horizontal = 14.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (progress.isDone(QuranShort.lessonId(s.number))) {
                    DoneSeal(colors.positive, textDp(14f), animate = false)
                    HGap(6f)
                }
                Text(s.nameRu, color = ink, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
        }
    }
}

/** The reader's row of aids, the same words and the same order: one hifz for the whole Quran. */
@Composable
private fun ReadingAids(store: QuranStore, hifz: HifzMode, colors: QuranColors, onHifz: (HifzMode) -> Unit) {
    val ui = uiScale()
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = ui.s(16f)).padding(top = 8.dp, bottom = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        QChip(tr("Транслит"), store.showReading, colors) { store.setReading(!store.showReading) }
        QChip(tr("Хифз"), hifz != HifzMode.OFF, colors) { onHifz(if (hifz == HifzMode.OFF) HifzMode.FIRST_LETTERS else HifzMode.OFF) }
        AnimatedVisibility(
            hifz != HifzMode.OFF,
            enter = expandHorizontally(NurMotion.gentle()) + fadeIn(tween(180)),
            exit = shrinkHorizontally(NurMotion.snappy()) + fadeOut(tween(120))
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QChip(tr("Первые буквы"), hifz == HifzMode.FIRST_LETTERS, colors) { onHifz(HifzMode.FIRST_LETTERS) }
                QChip(tr("Без арабского"), hifz == HifzMode.HIDE_ARABIC, colors) { onHifz(HifzMode.HIDE_ARABIC) }
                QChip(tr("Без перевода"), hifz == HifzMode.HIDE_TRANSLATION, colors) { onHifz(HifzMode.HIDE_TRANSLATION) }
            }
        }
    }
}

@Composable
private fun SurahPage(
    s: Surah,
    ayat: List<Ayah>,
    store: QuranStore,
    colors: QuranColors,
    hifz: HifzMode,
    particles: Map<String, Int>,
    stars: Int,
    next: Surah?,
    onNext: () -> Unit,
    onPractice: () -> Unit,
    modifier: Modifier
) {
    val ui = uiScale()
    val clock = rememberEntranceClock(s.number)
    // Ayat opened by a tap in a hifz mode; another mode hides everything again.
    val revealed = remember(hifz) { mutableStateListOf<Int>() }
    val arabicSize = QuranStore.SIZES[store.arabicSize]
    val translationSize = QuranStore.TRANSLATION_SIZES[store.translationSize]
    val column = Modifier.widthIn(max = READER_MAX_WIDTH).fillMaxWidth()
    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), top = 12.dp, bottom = LocalDockInset.current + 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item(key = "head") {
            ShortSurahHeader(s, store.showReading, stars, colors, column.entrance(0, clock = clock))
        }
        itemsIndexed(ayat, key = { _, a -> a.number }) { i, a ->
            val masked = hifz != HifzMode.OFF && a.number !in revealed
            ShortAyah(
                a, hifz, particles, masked, store.showReading, arabicSize, translationSize, colors,
                column.entrance(1 + i, distance = 24f, clock = clock)
            ) { if (a.number in revealed) revealed.remove(a.number) else revealed.add(a.number) }
        }
        item(key = "check") {
            PracticeCard(stars, next, colors, onPractice, onNext, column.entrance(1 + ayat.size, clock = clock))
        }
    }
}

@Composable
private fun ShortSurahHeader(s: Surah, showReading: Boolean, stars: Int, colors: QuranColors, modifier: Modifier) {
    val ui = uiScale()
    Column(
        modifier.padding(bottom = 8.dp).clip(RoundedCornerShape(26.dp)).background(colors.card)
            .padding(horizontal = ui.s(16f), vertical = ui.s(20f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(tr("Сура {0}", s.number), color = colors.textTertiary, fontSize = ui.t(12f))
        Gap(4f)
        ArabicText(s.nameArabic, 34f, color = colors.text)
        Text(tr("{0} · {1} аятов", s.nameRu, s.ayatCount), color = colors.textSecondary, fontSize = ui.t(14f), textAlign = TextAlign.Center)
        if (stars > 0) {
            Gap(8f)
            Stars(stars, colors)
        }
        Gap(12f)
        Ornament(colors)
        // Al-Fatiha counts the basmala as its first ayah: it is not repeated above it.
        if (s.number != 1) {
            Gap(12f)
            ArabicText(QuranShort.BASMALA, 24f, color = colors.accentText)
            AnimatedVisibility(
                showReading,
                enter = expandVertically(NurMotion.gentle()) + fadeIn(NurMotion.gentle()),
                exit = shrinkVertically(NurMotion.snappy()) + fadeOut(NurMotion.snappy())
            ) {
                Text(QuranShort.BASMALA_TRANSLIT, color = colors.textTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center)
            }
        }
    }
}

/**
 * One ayah as the reader draws it: its number in a plate, the Arabic closed by the number in
 * Arabic-Indic digits, the reading, the meaning. In a hifz mode a tap opens or closes it.
 */
@Composable
private fun ShortAyah(
    a: Ayah,
    hifz: HifzMode,
    particles: Map<String, Int>,
    masked: Boolean,
    showReading: Boolean,
    arabicSize: Float,
    translationSize: Float,
    colors: QuranColors,
    modifier: Modifier,
    onTap: () -> Unit
) {
    val ui = uiScale()
    // What hides is what the reader hides: the reading would give the Arabic away, so it goes
    // with it; the meaning is the cue and stays, except in its own mode.
    val face = when {
        masked && hifz == HifzMode.HIDE_ARABIC -> FACE_HIDDEN
        masked && hifz == HifzMode.FIRST_LETTERS -> FACE_FIRST_LETTERS
        else -> FACE_FULL
    }
    val hideReading = masked && hifz != HifzMode.HIDE_TRANSLATION
    val hideMeaning = masked && hifz == HifzMode.HIDE_TRANSLATION
    val digits = if (colors.light) colors.accentText else colors.accent
    val quiet = colors.textTertiary
    val shape = RoundedCornerShape(18.dp)
    Column(modifier) {
        Column(
            Modifier.fillMaxWidth()
                .then(if (hifz != HifzMode.OFF) Modifier.pressClick(scaleTo = 0.99f, shape = shape, onClick = onTap) else Modifier)
                .padding(horizontal = 12.dp, vertical = 14.dp)
        ) {
            Box(Modifier.clip(RoundedCornerShape(50)).background(colors.inset).padding(horizontal = 10.dp, vertical = 4.dp)) {
                Text("${a.surah}:${a.number}", color = colors.textSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold)
            }
            Gap(8f)
            AnimatedContent(
                targetState = face,
                transitionSpec = { fadeIn(tween(FACE_IN_MILLIS)) togetherWith fadeOut(tween(FACE_OUT_MILLIS)) },
                label = "shortAyah"
            ) { f ->
                if (f == FACE_HIDDEN) {
                    Text(tr("Нажмите, чтобы открыть аят"), color = colors.textTertiary, fontSize = ui.t(15f),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), textAlign = TextAlign.Center)
                } else {
                    val text = remember(a.arabic, a.number, digits, quiet, f, particles) {
                        buildAnnotatedString {
                            if (f == FACE_FIRST_LETTERS) {
                                for (part in QuranText.firstLetterParts(a.arabic, particles)) {
                                    if (part.hidden) withStyle(SpanStyle(color = quiet)) { append(part.text) } else append(part.text)
                                }
                            } else append(a.arabic)
                            append("\u00A0\u00A0")
                            withStyle(SpanStyle(color = digits)) { append(QuranMath.arabicDigits(a.number)) }
                        }
                    }
                    ArabicText(text, arabicSize, Modifier.fillMaxWidth(), color = colors.text, align = TextAlign.Right)
                }
            }
            AnimatedVisibility(
                visible = showReading && !hideReading,
                enter = expandVertically(NurMotion.gentle()) + fadeIn(NurMotion.gentle()),
                exit = shrinkVertically(NurMotion.snappy()) + fadeOut(NurMotion.snappy())
            ) {
                Text(a.translit, color = colors.textTertiary, fontSize = ui.t(14f), lineHeight = ui.t(20f), modifier = Modifier.padding(top = 6.dp))
            }
            Gap(8f)
            AnimatedContent(
                targetState = hideMeaning,
                transitionSpec = { fadeIn(tween(FACE_IN_MILLIS)) togetherWith fadeOut(tween(FACE_OUT_MILLIS)) },
                label = "shortMeaning"
            ) { hidden ->
                if (hidden) Text(tr("Смысл скрыт — нажмите, чтобы открыть"), color = colors.textTertiary, fontSize = ui.t(14f))
                else Text(a.ru, color = colors.text, fontSize = ui.t(translationSize), lineHeight = ui.t(translationSize * 1.5f))
            }
        }
        Box(Modifier.padding(horizontal = 12.dp).fillMaxWidth().height(1.dp).background(colors.hairline))
    }
}

/** The end of the page: the check of this surah, and the way on to the next one. */
@Composable
private fun PracticeCard(stars: Int, next: Surah?, colors: QuranColors, onPractice: () -> Unit, onNext: () -> Unit, modifier: Modifier) {
    val ui = uiScale()
    val button = RoundedCornerShape(16.dp)
    Column(
        modifier.padding(top = 18.dp).clip(RoundedCornerShape(26.dp)).background(colors.card).padding(ui.s(18f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(tr("Проверить себя"), color = colors.text, fontSize = ui.t(18f), fontWeight = FontWeight.Bold)
        Gap(4f)
        Text(tr("Смысл аятов и пропущенные слова"), color = colors.textTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center)
        if (stars > 0) {
            Gap(10f)
            Stars(stars, colors)
        }
        Gap(14f)
        Box(
            Modifier.fillMaxWidth().clip(button).background(colors.accent).pressClick(shape = button, onClick = onPractice)
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(if (stars > 0) tr("Пройти ещё раз") else tr("Начать проверку"), color = colors.onAccent,
                fontSize = ui.t(15f), fontWeight = FontWeight.SemiBold)
        }
        if (next != null) {
            Gap(6f)
            Row(
                Modifier.fillMaxWidth().clip(button).pressClick(scaleTo = 0.98f, shape = button, onClick = onNext).padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(tr("Дальше: {0}", next.nameRu), color = colors.textSecondary, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
                HGap(6f)
                Glyph(GlyphKind.CHEVRON, colors.textSecondary, Modifier.size(textDp(14f)))
            }
        }
    }
}

@Composable
private fun Stars(n: Int, colors: QuranColors) {
    val gold = if (colors.light) colors.accentText else colors.accent
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(MAX_STARS) { i ->
            Glyph(if (i < n) GlyphKind.STAR else GlyphKind.STAR_OUTLINE, if (i < n) gold else colors.textTertiary, Modifier.size(textDp(16f)))
        }
    }
}

@Composable
private fun ShortSurahSettings(store: QuranStore, colors: QuranColors) {
    val ui = uiScale()
    Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState())) {
        Text(tr("Настройки чтения"), color = colors.text, fontSize = ui.t(18f), fontWeight = FontWeight.Bold)
        Gap(2f)
        Text(tr("Общие с Кораном: выбранное здесь действует и там"), color = colors.textTertiary, fontSize = ui.t(12f))
        Gap(16f)
        SheetLabel(tr("Фон чтения"), colors)
        ReadingThemeRow(store, colors)
        Gap(18f)
        ReadingSizes(store, colors)
        Gap(18f)
        ReadingSwitch(tr("Не гасить экран"), tr("Пока открыта сура"), store.keepAwake, colors) { store.setAwake(!store.keepAwake) }
    }
}

private const val FACE_FULL = 0
private const val FACE_FIRST_LETTERS = 1
private const val FACE_HIDDEN = 2
private const val FACE_IN_MILLIS = 220
private const val FACE_OUT_MILLIS = 140
private const val TAB_MILLIS = 180
private const val PAGE_FADE = 0.45f
private const val PAGE_SHRINK = 0.05f
private const val MAX_STARS = 3
