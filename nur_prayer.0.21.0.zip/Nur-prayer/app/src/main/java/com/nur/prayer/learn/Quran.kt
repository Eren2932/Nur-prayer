package com.nur.prayer.learn

/** A bundled surah. The full mushaf is a separate, licensed dataset; these are the daily ones. */
data class Surah(val number: Int, val nameRu: String, val nameArabic: String, val ayatCount: Int)

data class Ayah(val surah: Int, val number: Int, val arabic: String, val translit: String, val ru: String)

class QuranShort(val ayat: List<Ayah>) {
    private val bySurah = ayat.groupBy { it.surah }
    fun ayat(surah: Int): List<Ayah> = bySurah[surah].orEmpty()

    companion object {
        const val BASMALA = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"
        const val BASMALA_TRANSLIT = "бисми-ллаһи р-раҳмаани р-раҳиим"

        val SURAHS: List<Surah> = listOf(
            Surah(1, "Аль-Фатиха", "الفاتحة", 7),
            Surah(108, "Аль-Каусар", "الكوثر", 3),
            Surah(112, "Аль-Ихлас", "الإخلاص", 4),
            Surah(113, "Аль-Фаляк", "الفلق", 5),
            Surah(114, "Ан-Нас", "الناس", 6)
        )

        /** The course lesson that checks a surah by heart: its stars mark the surah as checked. */
        fun lessonId(surah: Int): String = "quran-surah-$surah"

        fun parse(tsv: String): QuranShort = QuranShort(tsv.lineSequence().drop(1).mapNotNull { line ->
            val c = line.split('\t')
            val surah = c.getOrNull(0)?.toIntOrNull()
            val number = c.getOrNull(1)?.toIntOrNull()
            if (c.size != 5 || surah == null || number == null) null
            else Ayah(surah, number, c[2], c[3], c[4])
        }.toList())
    }
}
