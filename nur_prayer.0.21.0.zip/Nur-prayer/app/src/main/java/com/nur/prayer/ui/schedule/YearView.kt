package com.nur.prayer.ui.schedule

import com.nur.prayer.i18n.tr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.HijriMonthSpan
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.components.rememberEntranceClock
import com.nur.prayer.ui.theme.Glass
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import java.time.LocalDate

/*
 * 0.19.0 — the hijri year at a glance, as in the paper calendars of the mosques: twelve months,
 * each with its Gregorian bounds and the days that fall in it. The current month is lit and shows
 * how far it has gone; a past day fades, the next one says how many days are left.
 */
@Composable
internal fun YearView(
    hijriYear: Int,
    today: LocalDate,
    hijriOffset: Int,
    palette: PhasePalette,
    bottomInset: Dp,
    onPickYear: () -> Unit,
    onYear: (Int) -> Unit,
    onOpen: (SheetTopic) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val months = remember(hijriYear, hijriOffset) { IslamicDays.months(hijriYear, hijriOffset) }
    val current = months.indexOfFirst { it.contains(today) }
    val list = rememberLazyListState()
    val clock = rememberEntranceClock(hijriYear)
    // Open on the current month (item 0 is the year header): the past of the year is above it.
    LaunchedEffect(hijriYear) {
        if (current > 0) list.scrollToItem(current + 1, -24) else list.scrollToItem(0)
    }
    val range = remember(hijriYear, hijriOffset) { PeriodRange.hijriYears(today, hijriOffset) }
    // Two comparisons side by side in an argument list (`a < b, c > d`) parse as type arguments: hoisted.
    val hasPrev = range.first < hijriYear
    val hasNext = range.last > hijriYear
    LazyColumn(
        state = list,
        modifier = modifier.fillMaxSize().testTag("year-view"),
        contentPadding = PaddingValues(start = ui.s(18f), end = ui.s(18f), top = 4.dp, bottom = bottomInset),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "head") {
            YearHeader(hijriYear, months, hasPrev, hasNext, onPickYear, onYear, onOpen)
        }
        items(months, key = { it.month }) { m ->
            MonthCard(m, today, palette, m.month == months.getOrNull(current)?.month, onOpen,
                Modifier.entrance(m.month, clock = clock))
        }
        item(key = "note") {
            Text(
                IslamicDayText.datesNote(hijriOffset), color = TextTertiary, fontSize = ui.t(12f), lineHeight = ui.t(18f),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun YearHeader(
    year: Int, months: List<HijriMonthSpan>, hasPrev: Boolean, hasNext: Boolean,
    onPickYear: () -> Unit, onYear: (Int) -> Unit, onOpen: (SheetTopic) -> Unit
) {
    val ui = uiScale()
    Column(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Arrow(true, tr("Предыдущий год"), hasPrev) { onYear(year - 1) }
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                    .pressClick(role = Role.Button, onClick = onPickYear).padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("{0} г. х.", year), color = TextPrimary, fontSize = ui.t(30f), fontWeight = FontWeight.Medium)
                    Spacer(Modifier.width(6.dp))
                    Glyph(GlyphKind.CHEVRON, TextSecondary, Modifier.size(16.dp).graphicsLayer { rotationZ = 90f })
                }
                val first = months.firstOrNull()?.start
                val last = months.lastOrNull()?.end
                if (first != null && last != null) Text(
                    "${Format.dayMonth(first)} ${first.year} — ${Format.dayMonth(last)} ${last.year}",
                    color = TextSecondary, fontSize = ui.t(12f)
                )
            }
            Arrow(false, tr("Следующий год"), hasNext) { onYear(year + 1) }
        }
        // The legend doubles as the door to the sacred months.
        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
        ) {
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(DayTone.Night.copy(alpha = 0.16f))
                    .pressClick(onClick = { onOpen(SheetTopic.Sacred) })
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(6.dp).clip(CircleShape).border(1.5.dp, DayTone.Night, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(IslamicDayText.sacredTitle(), color = TextPrimary, fontSize = ui.t(12f), fontWeight = FontWeight.Medium)
                Spacer(Modifier.width(6.dp))
                Glyph(GlyphKind.INFO, TextSecondary, Modifier.size(13.dp))
            }
        }
    }
}

@Composable
private fun Arrow(back: Boolean, label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape)
            .pressClick(enabled = enabled, onClick = onClick)
            .graphicsLayer { alpha = if (enabled) 1f else 0.3f }
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) { Glyph(GlyphKind.CHEVRON, TextPrimary, Modifier.size(18.dp).graphicsLayer { rotationZ = if (back) 180f else 0f }) }
}

@Composable
private fun MonthCard(
    m: HijriMonthSpan, today: LocalDate, palette: PhasePalette, isCurrent: Boolean,
    onOpen: (SheetTopic) -> Unit, modifier: Modifier
) {
    val ui = uiScale()
    val shape = RoundedCornerShape(22.dp)
    val sacred = IslamicDays.isSacredMonth(m.month)
    Column(
        modifier.fillMaxWidth().clip(shape).background(Glass)
            .then(if (isCurrent) Modifier.border(1.5.dp, palette.accent.copy(alpha = 0.75f), shape) else Modifier)
            .testTag("hijri-month-${m.month}")
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        HijriCalendar.monthName(m.month).replaceFirstChar { it.uppercase() },
                        color = TextPrimary, fontSize = ui.t(18f), fontWeight = FontWeight.Bold
                    )
                    if (sacred) {
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.size(6.dp).clip(CircleShape).border(1.5.dp, DayTone.Night, CircleShape))
                    }
                }
                Text(
                    "${Format.dayMonth(m.start)} — ${Format.dayMonth(m.end)} · ${tr("{0} дн.", m.end.toEpochDay() - m.start.toEpochDay() + 1)}",
                    color = TextSecondary, fontSize = ui.t(12.5f), modifier = Modifier.padding(top = 2.dp)
                )
            }
            Text(
                IslamicDays.arabicMonth(m.month), color = if (isCurrent) palette.accent else TextSecondary,
                fontSize = ui.t(19f), style = TextStyle(textDirection = TextDirection.Rtl)
            )
        }
        if (isCurrent) {
            val p = m.progress(today)
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(bottom = 12.dp)) {
                Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x26FFFFFF))) {
                    Box(Modifier.fillMaxWidth(p).height(4.dp).clip(RoundedCornerShape(2.dp)).background(palette.accent))
                }
                val total = m.end.toEpochDay() - m.start.toEpochDay() + 1
                Text(
                    tr("День {0} из {1}", today.toEpochDay() - m.start.toEpochDay() + 1, total),
                    color = palette.accent, fontSize = ui.t(12f), fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        m.events.forEachIndexed { i, o ->
            if (i == 0) Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x14FFFFFF)))
            EventRow(o, today, onOpen)
        }
    }
}

/** One day of the year: a coloured date badge, the name, one line on it, and how far away it is. */
@Composable
internal fun EventRow(o: DayOccurrence, today: LocalDate, onOpen: (SheetTopic) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val tone = DayTone.of(o.kind)
    val past = o.end.isBefore(today)
    val now = o.contains(today)
    Row(
        modifier.fillMaxWidth()
            .pressClick(scaleTo = 0.98f, onClick = { onOpen(SheetTopic.Day(o)) })
            .graphicsLayer { alpha = if (past) 0.55f else 1f }
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("event-${o.day.name}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            Modifier.size(52.dp).clip(RoundedCornerShape(14.dp))
                .background(tone.copy(alpha = if (now) 0.42f else 0.2f)),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Text(o.start.dayOfMonth.toString(), color = TextPrimary, fontSize = ui.t(19f), fontWeight = FontWeight.Bold)
            Text(Format.monthShort(o.start), color = tone, fontSize = ui.t(11f), fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(IslamicDayText.title(o.day), color = TextPrimary, fontSize = ui.t(15.5f), fontWeight = FontWeight.SemiBold)
            Text(IslamicDayText.short(o.day), color = TextSecondary, fontSize = ui.t(12.5f), lineHeight = ui.t(17f), maxLines = 2)
            if (!past) Text(
                DayWhen.countdown(o, today), color = tone, fontSize = ui.t(12f), fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
        Spacer(Modifier.width(8.dp))
        Glyph(GlyphKind.CHEVRON, TextTertiary, Modifier.size(14.dp))
    }
}
