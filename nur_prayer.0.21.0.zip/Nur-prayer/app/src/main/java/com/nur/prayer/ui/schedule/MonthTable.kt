package com.nur.prayer.ui.schedule

import com.nur.prayer.i18n.tr

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.data.DayKind
import com.nur.prayer.data.DayOccurrence
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.IslamicDayText
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZonedDateTime

/*
 * 0.20.0 — «Таблица на месяц», rebuilt for reading, not for scrolling.
 *
 *  - The header with the names of the prayers is pinned: it lives outside the list, so the rows
 *    scroll under it and a time never loses its column.
 *  - One line per day (number · weekday · hijri day) instead of two: ~32dp a row, the month fits in
 *    about two screens instead of four.
 *  - The table opens on today (two rows of context above it); today's next prayer is lit.
 *  - A horizontal swipe on the table turns the month, like the grid of «Месяц».
 *  - The days of the month and the hijri note close the list, inside the same card.
 *
 * The same rows feed the shared picture (calendarShareSpec), so what is on screen is what is sent.
 */

/** A computed month: the days in order and the columns the place actually has. */
internal class MonthTimes(val month: YearMonth, val days: List<PrayerDay>, val columns: List<Prayer>)

/** Short column names for a narrow phone; the full name stays in the accessibility label. */
internal fun columnLabel(prayer: Prayer): String = when (prayer) {
    Prayer.SAHAR -> tr("Сухур")
    Prayer.FAJR -> tr("Фаджр")
    Prayer.SUNRISE -> tr("Восход")
    Prayer.DHUHR -> tr("Зухр")
    Prayer.ASR -> tr("Аср")
    Prayer.MAGHRIB -> tr("Магриб")
    Prayer.ISHA -> tr("Иша")
}

/** Where the list opens: today with two rows of context above it, or the first day of another month. */
internal fun tableStartIndex(month: YearMonth, today: LocalDate): Int =
    if (YearMonth.from(today) == month) (today.dayOfMonth - 3).coerceAtLeast(0) else 0

/** Weights of the columns: the date cell is wider, every time is equal. */
private const val DATE_WEIGHT = 1.5f

@Composable
internal fun MonthTable(
    times: MonthTimes,
    today: LocalDate,
    hijriOffset: Int,
    palette: PhasePalette,
    events: List<DayOccurrence>,
    onOpen: (SheetTopic) -> Unit,
    modifier: Modifier = Modifier,
    /** The next prayer and its moment: its cell is lit in its own row (tomorrow's Fajr after Isha). */
    next: Prayer? = null,
    nextStart: ZonedDateTime? = null,
    onSwipe: ((forward: Boolean) -> Unit)? = null,
    bottomPadding: Dp = 8.dp
) {
    val ui = uiScale()
    val shape = RoundedCornerShape(20.dp)
    val narrow = times.columns.size > 6
    val state = rememberSaveable(times.month, saver = LazyListState.Saver) {
        LazyListState(tableStartIndex(times.month, today))
    }
    val swipe = if (onSwipe == null) Modifier else Modifier.pointerInput(times.month) {
        var distance = 0f
        detectHorizontalDragGestures(
            onDragStart = { distance = 0f }, onDragCancel = { distance = 0f },
            onHorizontalDrag = { change, amount -> change.consume(); distance += amount },
            onDragEnd = {
                val threshold = 56.dp.toPx()
                if (distance < -threshold) onSwipe(true) else if (distance > threshold) onSwipe(false)
            }
        )
    }
    Column(
        modifier.fillMaxWidth().clip(shape).background(Color(0x1FFFFFFF)).border(1.dp, Color(0x24FFFFFF), shape)
            .then(swipe).testTag("month-table")
    ) {
        TableHeader(times.columns, palette, narrow)
        LazyColumn(
            state = state,
            modifier = Modifier.weight(1f).fillMaxWidth().testTag("month-table-rows"),
            contentPadding = PaddingValues(bottom = bottomPadding)
        ) {
            itemsIndexed(times.days, key = { _, d -> d.date.toEpochDay() }) { index, day ->
                if (index > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x10FFFFFF)))
                TableRow(times.columns, day, today, hijriOffset, palette, narrow,
                    lit = if (nextStart != null && nextStart.toLocalDate() == day.date) next else null)
            }
            if (events.isNotEmpty()) item(key = "events") {
                Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x24FFFFFF)))
                    events.forEach { o -> EventLine(o, onOpen) }
                }
            }
            item(key = "note") {
                Text(
                    tableNote(hijriOffset), color = TextTertiary, fontSize = ui.t(11f), lineHeight = ui.t(15f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)
                )
            }
        }
    }
}

/** The pinned band with the names of the prayers. */
@Composable
private fun TableHeader(columns: List<Prayer>, palette: PhasePalette, narrow: Boolean) {
    val ui = uiScale()
    Row(
        Modifier.fillMaxWidth().background(palette.accent.copy(alpha = 0.30f)).heightIn(min = 36.dp)
            .padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Spacer(Modifier.width(3.dp))
        Text(tr("Дата").uppercase(), color = TextPrimary, fontSize = ui.t(10f), fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(DATE_WEIGHT).padding(start = 9.dp), maxLines = 1)
        columns.forEach { p ->
            Text(
                columnLabel(p).uppercase(), color = TextPrimary, fontSize = ui.t(if (narrow) 8.5f else 9.5f),
                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1, softWrap = false,
                overflow = TextOverflow.Clip, modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun TableRow(
    columns: List<Prayer>, day: PrayerDay, today: LocalDate, hijriOffset: Int, palette: PhasePalette,
    narrow: Boolean, lit: Prayer?
) {
    val ui = uiScale()
    val date = day.date
    val event = IslamicDays.primary(date, hijriOffset)
    val tone = event?.let { DayTone.of(it.kind) }
    val isToday = date == today
    val friday = date.dayOfWeek == DayOfWeek.FRIDAY
    val past = date < today
    val fill = when {
        isToday -> palette.accent.copy(alpha = 0.34f)
        tone != null && event?.kind != DayKind.SEASON -> tone.copy(alpha = 0.16f)
        tone != null -> tone.copy(alpha = 0.07f)
        friday -> Color(0x12FFFFFF)
        else -> Color.Transparent
    }
    // Days already behind us step back a little: the eye lands on what is still ahead.
    val timeColor = if (past) TextSecondary else TextPrimary
    val timeSize = ui.t(if (narrow) 12.5f else 13.5f)
    Row(
        Modifier.fillMaxWidth().heightIn(min = ui.s(32f)).background(fill)
            .semantics(mergeDescendants = true) {
                contentDescription = buildString {
                    append(Format.fullDate(date))
                    event?.let { append(", ").append(IslamicDayText.title(it.day)) }
                    columns.forEach { p ->
                        append(", ").append(PrayerLabels.title(p)).append(' ')
                        append(day.times[p]?.let { Format.time(it) } ?: "—")
                    }
                }
            }
            .testTag("table-row-$date"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // The coloured edge of a marked day.
        Box(Modifier.width(3.dp).height(ui.s(22f)).background(tone ?: Color.Transparent))
        Row(Modifier.weight(DATE_WEIGHT).padding(start = 9.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                date.dayOfMonth.toString(), color = if (past) TextSecondary else TextPrimary, fontSize = ui.t(14f),
                fontWeight = if (isToday) FontWeight.Bold else FontWeight.SemiBold,
                style = LocalTextStyle.current.copy(fontFeatureSettings = "tnum"),
                maxLines = 1, softWrap = false, modifier = Modifier.width(ui.s(19f))
            )
            Text(
                Format.weekdayShort(date), color = if (friday) palette.accent else TextSecondary,
                fontSize = ui.t(10.5f), fontWeight = if (friday) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1, softWrap = false, overflow = TextOverflow.Clip,
                modifier = Modifier.weight(1f).padding(start = 3.dp)
            )
            Text(
                HijriCalendar.dayOfMonth(date, hijriOffset).toString(), color = tone ?: TextTertiary,
                fontSize = ui.t(9.5f), maxLines = 1, softWrap = false
            )
        }
        columns.forEach { p ->
            val on = p == lit
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Text(
                    day.times[p]?.let { Format.time(it) } ?: "—",
                    color = when {
                        on -> TextPrimary
                        p == Prayer.SUNRISE || p == Prayer.SAHAR -> TextSecondary
                        else -> timeColor
                    },
                    fontSize = timeSize, fontWeight = if (isToday || on) FontWeight.Bold else FontWeight.Normal,
                    textAlign = TextAlign.Center, maxLines = 1, softWrap = false,
                    // Tabular digits keep the columns of times aligned (a TextStyle feature, not a Text parameter).
                    style = LocalTextStyle.current.copy(fontFeatureSettings = "tnum"),
                    modifier = (if (on) Modifier.clip(RoundedCornerShape(8.dp)).background(palette.accent.copy(alpha = 0.55f))
                        else Modifier).padding(horizontal = 3.dp, vertical = 2.dp)
                )
            }
        }
    }
}

/** "● 10 нояб. — 12 нояб. · Дни ташрика ›" — the legend of the colours, each line opens its sheet. */
@Composable
private fun EventLine(o: DayOccurrence, onOpen: (SheetTopic) -> Unit) {
    val ui = uiScale()
    val tone = DayTone.of(o.kind)
    Row(
        Modifier.fillMaxWidth().heightIn(min = 44.dp)
            .pressClick(scaleTo = 0.98f, role = Role.Button, onClick = { onOpen(SheetTopic.Day(o)) })
            .padding(horizontal = 14.dp)
            .testTag("table-event-${o.day.name}"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(tone))
        Text(legendLine(o), color = TextPrimary, fontSize = ui.t(13f), maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f))
        Glyph(GlyphKind.CHEVRON, TextTertiary, Modifier.size(11.dp))
    }
}

/** One line instead of a paragraph: the source of the hijri numbers and the user's shift, if any. */
internal fun tableNote(hijriOffset: Int): String =
    if (hijriOffset == 0) tr("Даты хиджры — по Умм аль-Кура")
    else tr("Даты хиджры — по Умм аль-Кура, сдвиг {0} дн.", if (hijriOffset > 0) "+$hijriOffset" else "$hijriOffset")

/** The spec of the shared picture, from the same rows as the screen. */
internal fun calendarShareSpec(
    times: MonthTimes, today: LocalDate, hijriOffset: Int, placeLabel: String, palette: PhasePalette
): CalendarShareSpec {
    val rows = times.days.map { d ->
        CalendarShareRow(
            day = d.date.dayOfMonth.toString(),
            weekday = Format.weekdayShort(d.date),
            hijriDay = HijriCalendar.dayOfMonth(d.date, hijriOffset).toString(),
            times = times.columns.map { p -> d.times[p]?.let { Format.time(it) } ?: "—" },
            friday = d.date.dayOfWeek == DayOfWeek.FRIDAY,
            today = d.date == today,
            tone = IslamicDays.primary(d.date, hijriOffset)?.let { DayTone.argb(it.kind) }
        )
    }
    val legend = monthEvents(times.month, hijriOffset).map { o -> DayTone.argb(o.kind) to legendLine(o) }
    return CalendarShareSpec(
        kicker = tr("Время намаза"),
        title = "${Format.monthName(times.month.monthValue)} ${times.month.year}",
        subtitle = HijriCalendar.span(times.month.atDay(1), times.month.atEndOfMonth(), hijriOffset),
        place = placeLabel,
        dateHeader = tr("Дата"),
        columns = times.columns.map { columnLabel(it) },
        rows = rows,
        legend = legend,
        footnote = tableNote(hijriOffset),
        palette = palette
    )
}

/** "10 нояб. — 12 нояб. · Дни ташрика" / "25 июня · Ашура". */
internal fun legendLine(o: DayOccurrence): String {
    val start = "${o.start.dayOfMonth} ${Format.monthShort(o.start)}"
    val span = if (o.days > 1) "$start — ${o.end.dayOfMonth} ${Format.monthShort(o.end)}" else start
    return "$span · ${IslamicDayText.title(o.day)}"
}

/** Everything that touches a Gregorian month, in order. */
internal fun monthEvents(month: YearMonth, hijriOffset: Int): List<DayOccurrence> =
    IslamicDays.between(month.atDay(1), month.atEndOfMonth(), hijriOffset)
