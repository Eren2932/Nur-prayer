package com.nur.prayer.ui.learn

import com.nur.prayer.i18n.tr

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.flow.first
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.learn.Arabic
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.learn.LearnProgress
import com.nur.prayer.learn.Lexicon
import com.nur.prayer.learn.Word
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.ScreenHeader
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.components.rememberEntranceClock
import com.nur.prayer.ui.daily.chipBg
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/**
 * The whole lexicon: search in three scripts, filter by topic, tap a word for its letters.
 * [focus] (0.18.5) is the word of the day: the list opens on its card, unfolded, with its voice.
 */
@Composable
fun DictionaryScreen(content: LearnContent?, progress: LearnProgress, palette: PhasePalette, focus: String? = null, onBack: () -> Unit) {
    val ui = uiScale()
    val voice = rememberVoiceStatus()
    val accent = palette.accent
    var query by rememberSaveable { mutableStateOf("") }
    var topic by rememberSaveable { mutableStateOf<String?>(null) }
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(tr("Словарь"), onBack, Modifier.padding(horizontal = ui.s(16f))) {
            content?.let { Tag("${it.lexicon.words.size}") }
        }
        if (content == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(tr("Загружаем словарь…"), color = TextSecondary) }
            return
        }
        val lexicon = content.lexicon
        val results = remember(query, topic, lexicon) { lexicon.search(query, topic) }
        val list = rememberLazyListState()
        // Every entry from the word-of-day tile, not just the first: the page leaves composition in between.
        LaunchedEffect(focus, lexicon) {
            if (focus == null) return@LaunchedEffect
            val i = lexicon.search("", null).indexOfFirst { it.id == focus }
            if (i < 0) return@LaunchedEffect
            query = ""
            topic = null
            open = focus
            // A filter left from last time is dropped above; the full list has to be laid out first.
            androidx.compose.runtime.snapshotFlow { list.layoutInfo.totalItemsCount }.first { it > i }
            list.scrollToItem((i - 1).coerceAtLeast(0))
        }
        // A new topic replays the cascade; typing in the search box does not (it would flicker).
        val clock = rememberEntranceClock(topic)
        Box(
            Modifier.padding(horizontal = ui.s(16f)).fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(SurfaceRaised).padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            if (query.isEmpty()) Text(tr("Слово по-русски, транслитом или по-арабски"), color = TextTertiary, fontSize = ui.t(15f))
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = TextPrimary, fontSize = ui.t(16f)),
                cursorBrush = SolidColor(accent), modifier = Modifier.fillMaxWidth()
            )
        }
        Gap(10f)
        LazyRow(contentPadding = PaddingValues(horizontal = ui.s(16f)), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            item { Chip(tr("Все"), topic == null, accent) { topic = null } }
            items(Lexicon.TOPICS, key = { it.id }) { t -> Chip(t.title, topic == t.id, accent) { topic = if (topic == t.id) null else t.id } }
        }
        Gap(10f)
        AnimatedVisibility(results.isEmpty(), enter = fadeIn(tween(160)), exit = fadeOut(tween(100))) {
            Text(tr("Ничего не нашлось"), color = TextSecondary, fontSize = ui.t(15f), textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 32.dp))
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            state = list,
            contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(results, key = { _, w -> w.id }) { i, w ->
                WordRow(w, progress, accent, open == w.id, voice, Modifier.animateItem().entrance(i, distance = 24f, clock = clock)) {
                    open = if (open == w.id) null else w.id
                }
            }
        }
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, accent: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    val ui = uiScale()
    Text(
        text, color = if (selected) TextPrimary else TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold,
        modifier = Modifier.pressClick(shape = RoundedCornerShape(50), onClick = onClick)
            .background(chipBg(selected, accent)).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun WordRow(
    w: Word, progress: LearnProgress, accent: androidx.compose.ui.graphics.Color, expanded: Boolean,
    voice: com.nur.prayer.audio.ArabicVoice.Status, modifier: Modifier = Modifier, onClick: () -> Unit
) {
    val ui = uiScale()
    val card = progress.cards[LearnProgress.wordKey(w)]
    GlassCard(modifier.pressClick(scaleTo = 0.98f, haptic = false, shape = RoundedCornerShape(20.dp), onClick = onClick), corner = 20.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(w.ru, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
                Text(w.translit, color = TextTertiary, fontSize = ui.t(13f))
                when {
                    card == null -> {}
                    card.box >= LearnProgress.LEARNED_BOX -> Text(tr("выучено"), color = Mint, fontSize = ui.t(11f))
                    else -> Text(tr("в повторении"), color = accent, fontSize = ui.t(11f))
                }
            }
            ArabicText(w.arabic, if (w.isPhrase) 22f else 28f, align = TextAlign.End)
        }
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(NurMotion.gentle()) + fadeIn(NurMotion.gentle()),
            exit = shrinkVertically(NurMotion.snappy()) + fadeOut(NurMotion.snappy())
        ) {
            Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 14.dp)) {
                if (voiceAllowed(w)) {
                    AutoSay(w.arabic, w.id, voice)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SpeakButton(w.arabic, voice, size = 38.dp, slow = false)
                        SpeakButton(w.arabic, voice, size = 38.dp, slow = true, label = tr("Медленно"))
                        Text(tr("обычно · медленно"), color = TextTertiary, fontSize = ui.t(12f))
                    }
                    Gap(8f)
                }
                Text(tr("По буквам, справа налево"), color = TextTertiary, fontSize = ui.t(12f))
                Gap(6f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End)) {
                    w.letters.reversed().forEach { l ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            ArabicText(l.char, 24f)
                            Text(l.sound, color = TextSecondary, fontSize = ui.t(11f))
                        }
                    }
                }
                Gap(4f)
                Text(tr("Без огласовок: "), color = TextTertiary, fontSize = ui.t(12f))
                ArabicText(Arabic.stripMarks(w.arabic), 24f, align = TextAlign.End, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}
