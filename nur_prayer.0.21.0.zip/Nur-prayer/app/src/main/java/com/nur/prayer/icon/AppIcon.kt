package com.nur.prayer.icon

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import com.nur.prayer.R
import com.nur.prayer.i18n.tr

/**
 * 0.15.0 launcher icons.
 *
 * Every entry is an `<activity-alias>` in the manifest pointing at MainActivity; exactly one of them
 * is enabled and that one is what the launcher shows. [alias] is the component's class name and is
 * frozen forever: Android stores the enabled state per component name, so renaming an alias would
 * leave the old state behind and show two icons (or none) after an update.
 */
enum class AppIcon(val id: String, val alias: String, val launcher: Int) {
    NUR("nur", "Nur", R.mipmap.ic_launcher_nur),
    PEARL("pearl", "Pearl", R.mipmap.ic_launcher_pearl),
    FAJR("fajr", "Fajr", R.mipmap.ic_launcher_fajr),
    EMERALD("emerald", "Emerald", R.mipmap.ic_launcher_emerald),
    GOLD("gold", "Gold", R.mipmap.ic_launcher_gold),
    MIDNIGHT("midnight", "Midnight", R.mipmap.ic_launcher_midnight),
    LAGOON("lagoon", "Lagoon", R.mipmap.ic_launcher_lagoon),
    MAGHRIB("maghrib", "Maghrib", R.mipmap.ic_launcher_maghrib),
    GARNET("garnet", "Garnet", R.mipmap.ic_launcher_garnet),
    AURORA("aurora", "Aurora", R.mipmap.ic_launcher_aurora),
    SAND("sand", "Sand", R.mipmap.ic_launcher_sand),
    GRAPHITE("graphite", "Graphite", R.mipmap.ic_launcher_graphite);

    companion object {
        /** The icon the manifest enables: fresh installs, the store listing, every reset. */
        val DEFAULT = NUR

        fun of(id: String?): AppIcon? = entries.firstOrNull { it.id == id }
    }
}

/** Name shown under the tile. Exhaustive on purpose: a new icon must not ship without a title. */
fun AppIcon.title(): String = when (this) {
    AppIcon.NUR -> tr("Нур")
    // 0.18.6: the light artwork became the default «Нур»; alias Pearl now carries the dark one.
    AppIcon.PEARL -> tr("Оникс")
    AppIcon.FAJR -> tr("Фаджр")
    AppIcon.EMERALD -> tr("Изумруд")
    AppIcon.GOLD -> tr("Золото")
    AppIcon.MIDNIGHT -> tr("Полночь")
    AppIcon.LAGOON -> tr("Лагуна")
    AppIcon.MAGHRIB -> tr("Магриб")
    AppIcon.GARNET -> tr("Гранат")
    AppIcon.AURORA -> tr("Аврора")
    AppIcon.SAND -> tr("Песок")
    AppIcon.GRAPHITE -> tr("Графит")
}

/**
 * Switches the launcher alias.
 *
 * The choice is *recorded* at once and *applied* when the activity stops. Disabling the alias the
 * running task was launched from makes the system finish that task on a number of Android builds
 * (Xiaomi and some Samsung firmware do it even with DONT_KILL_APP): switching on the tap would close
 * the app under the user's finger. Applied in onStop it happens while the user is already on the
 * home screen, which is exactly where they want to see the new icon.
 *
 * The system is the source of truth for what is applied; the pending choice is a plain
 * SharedPreferences value written with commit(), so it survives a process kill in the background
 * and is applied at the next onStop.
 */
object AppIconSwitcher {
    private const val PREFS = "launcher_icon"
    private const val KEY_PENDING = "pending"
    private const val KEY_ARTWORK_SWAP = "artwork_swap_0186"
    private const val ALIAS_PACKAGE = "com.nur.prayer.launcher."

    /** What the picker should show as selected: the pending choice, or what the launcher shows. */
    fun selected(context: Context): AppIcon = pending(context) ?: applied(context)

    fun select(context: Context, icon: AppIcon) {
        val editor = prefs(context).edit()
        if (icon == applied(context)) editor.remove(KEY_PENDING) else editor.putString(KEY_PENDING, icon.id)
        editor.commit()
    }

    /**
     * 0.18.6 swapped the artwork of two aliases instead of the aliases themselves (re-enabling
     * components in the manifest shows two icons on every updated phone until the app is opened).
     * The light artwork moved from Pearl to Nur, so whoever had chosen Pearl — the light icon — is
     * moved to Nur and keeps the icon they picked. Runs once; applied in onStop as any other choice.
     */
    fun migrateArtworkSwap(context: Context) {
        val prefs = prefs(context)
        if (prefs.getBoolean(KEY_ARTWORK_SWAP, false)) return
        val editor = prefs.edit().putBoolean(KEY_ARTWORK_SWAP, true)
        if (pending(context) == AppIcon.PEARL) editor.putString(KEY_PENDING, AppIcon.NUR.id)
        else if (pending(context) == null && applied(context) == AppIcon.PEARL) editor.putString(KEY_PENDING, AppIcon.NUR.id)
        editor.commit()
    }

    /** Called from MainActivity.onStop. Cheap when nothing is pending: one SharedPreferences read. */
    fun applyPending(context: Context) {
        val target = pending(context) ?: return
        val pm = context.packageManager
        // Enable first, then disable the rest: there is never a moment without a launcher entry.
        setEnabled(pm, context, target, true)
        AppIcon.entries.filter { it != target }.forEach { setEnabled(pm, context, it, false) }
        prefs(context).edit().remove(KEY_PENDING).commit()
    }

    /** The alias the launcher currently shows; the default if the state is somehow ambiguous. */
    fun applied(context: Context): AppIcon {
        val pm = context.packageManager
        return AppIcon.entries.firstOrNull { it != AppIcon.DEFAULT && isEnabled(pm, context, it) }
            ?: AppIcon.DEFAULT
    }

    private fun pending(context: Context): AppIcon? = AppIcon.of(prefs(context).getString(KEY_PENDING, null))

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun component(context: Context, icon: AppIcon) =
        // The alias class lives in the source namespace; the package is the installed one
        // (`com.nur.prayer.debug` for debug builds).
        ComponentName(context.packageName, ALIAS_PACKAGE + icon.alias)

    private fun isEnabled(pm: PackageManager, context: Context, icon: AppIcon): Boolean =
        when (pm.getComponentEnabledSetting(component(context, icon))) {
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
            PackageManager.COMPONENT_ENABLED_STATE_DEFAULT -> icon == AppIcon.DEFAULT
            else -> false
        }

    private fun setEnabled(pm: PackageManager, context: Context, icon: AppIcon, enabled: Boolean) {
        if (isEnabled(pm, context, icon) == enabled) return // untouched aliases do not make the launcher reflow
        val state = if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else PackageManager.COMPONENT_ENABLED_STATE_DISABLED
        pm.setComponentEnabledSetting(component(context, icon), state, PackageManager.DONT_KILL_APP)
    }
}
