package com.nur.prayer.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.Window
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat

/**
 * 0.18.4: who decides the colour of the status and navigation bar icons.
 *
 * The whole app sits on a dark sky, so the icons are light. The Quran's paper page is the one
 * light surface: while it is on screen the icons turn dark, or the clock and battery vanish into
 * the cream. The state lives here and not in a composable because MainActivity re-applies the bars
 * in onResume (back from the share chooser, from settings), and must re-apply the right tone.
 */
object SystemBarsTone {
    /** True while a light surface is under the system bars. Observed by NurRoot's nav-bar scrim. */
    var light by mutableStateOf(false)
        private set

    fun set(window: Window?, light: Boolean) {
        this.light = light
        apply(window)
    }

    fun apply(window: Window?) {
        window ?: return
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = light
            isAppearanceLightNavigationBars = light
        }
    }
}

/** The activity behind a Compose context, through any wrappers (themes, locales). */
tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
