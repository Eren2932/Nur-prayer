package com.nur.prayer.ui.schedule

import androidx.compose.ui.graphics.Color
import com.nur.prayer.data.DayKind
import com.nur.prayer.i18n.tr

/**
 * 0.19.0 — one colour per kind of day, shared by the grid, the table, the year view, the sheet,
 * the home chip and the shared picture. Five hues far enough apart on the hue wheel to be told
 * apart on a dusk sky and on AMOLED black, all light enough for white-on-sky contrast rules
 * (they are used for fills at low alpha and for small text/dots at full strength).
 */
object DayTone {
    val Feast = Color(0xFFF4C46E)   // warm gold — the two Eids
    val Night = Color(0xFFC2AEFF)   // lavender — blessed nights
    val Fast = Color(0xFF86E0B0)    // mint — Sunna fasts
    val Memorial = Color(0xFFFFADC2) // rose — dates to remember
    val Season = Color(0xFF7FD6EA)  // sky cyan — Ramadan, the ten days

    fun of(kind: DayKind): Color = when (kind) {
        DayKind.FEAST -> Feast
        DayKind.NIGHT -> Night
        DayKind.FAST -> Fast
        DayKind.MEMORIAL -> Memorial
        DayKind.SEASON -> Season
    }

    fun label(kind: DayKind): String = when (kind) {
        DayKind.FEAST -> tr("Праздник")
        DayKind.NIGHT -> tr("Благословенная ночь")
        DayKind.FAST -> tr("День поста")
        DayKind.MEMORIAL -> tr("Памятная дата")
        DayKind.SEASON -> tr("Особые дни")
    }

    fun argb(kind: DayKind): Int = when (kind) {
        DayKind.FEAST -> 0xFFF4C46E.toInt()
        DayKind.NIGHT -> 0xFFC2AEFF.toInt()
        DayKind.FAST -> 0xFF86E0B0.toInt()
        DayKind.MEMORIAL -> 0xFFFFADC2.toInt()
        DayKind.SEASON -> 0xFF7FD6EA.toInt()
    }
}
