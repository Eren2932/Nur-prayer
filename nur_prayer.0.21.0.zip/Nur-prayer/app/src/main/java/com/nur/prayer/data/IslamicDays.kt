package com.nur.prayer.data

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

/*
 * 0.19.0 — the days of the Muslim year as data.
 *
 * Every date here is derived from the same Umm al-Qura chronology and the same user offset that
 * [HijriCalendar] uses for the header of home, so the calendar, the table, the home chip and the
 * notification can never disagree about which day is the 10th of Muharram. Pure java.time: the
 * whole file is covered by JVM tests without Android.
 *
 * Offset convention (same as HijriCalendar): the hijri date of a Gregorian day d is
 * HijrahDate.from(d + offset), hence the Gregorian day of a hijri date h is LocalDate.from(h) − offset.
 */

/** What kind of day it is; drives the colour and the priority when two meet on one date. */
enum class DayKind(val priority: Int) {
    /** Eid al-Fitr, Eid al-Adha, the days of tashriq: fasting is forbidden. */
    FEAST(5),
    /** A blessed night: it begins at maghrib of the previous Gregorian day. */
    NIGHT(4),
    /** A day on which a voluntary fast is Sunna (Arafah, Ashura). */
    FAST(4),
    /** A date to remember (the new year, the Mawlid). */
    MEMORIAL(3),
    /** A stretch of days (Ramadan, the first ten of Dhu al-Hijjah). */
    SEASON(1)
}

/**
 * The days the calendar knows. [span] 0 means "to the end of the hijri month" (Ramadan is 29 or 30).
 * The list is ordered by the hijri year so that a year view can be built by filtering.
 */
enum class IslamicDay(val month: Int, val day: Int, val kind: DayKind, val span: Int = 1) {
    HIJRI_NEW_YEAR(1, 1, DayKind.MEMORIAL),
    ASHURA(1, 10, DayKind.FAST),
    MAWLID(3, 12, DayKind.MEMORIAL),
    ISRA_MIRAJ(7, 27, DayKind.NIGHT),
    BARAAH(8, 15, DayKind.NIGHT),
    RAMADAN(9, 1, DayKind.SEASON, span = 0),
    QADR(9, 27, DayKind.NIGHT),
    FITR(10, 1, DayKind.FEAST),
    DHUL_HIJJAH_TEN(12, 1, DayKind.SEASON, span = 10),
    ARAFAH(12, 9, DayKind.FAST),
    ADHA(12, 10, DayKind.FEAST),
    TASHRIQ(12, 11, DayKind.FEAST, span = 3);

    companion object {
        fun byName(name: String?): IslamicDay? = entries.firstOrNull { it.name == name }
    }
}

/** One hijri month of the year view: its Gregorian bounds and what happens in it. */
data class HijriMonthSpan(
    val year: Int, val month: Int, val start: LocalDate, val end: LocalDate, val events: List<DayOccurrence>
) {
    fun contains(date: LocalDate): Boolean = !date.isBefore(start) && !date.isAfter(end)
    /** 0..1 — how much of the month has passed by [date] (the progress bar of the current month). */
    fun progress(date: LocalDate): Float {
        if (date.isBefore(start)) return 0f
        if (date.isAfter(end)) return 1f
        val total = (end.toEpochDay() - start.toEpochDay() + 1).toFloat()
        return ((date.toEpochDay() - start.toEpochDay() + 1) / total).coerceIn(0f, 1f)
    }
}

/** A hijri date as three numbers; month 1..12. */
data class HijriDay(val year: Int, val month: Int, val day: Int)

/**
 * One concrete occurrence of an [IslamicDay] in a given hijri year: [start]..[end] inclusive,
 * Gregorian, offset already applied.
 */
data class DayOccurrence(val day: IslamicDay, val hijriYear: Int, val start: LocalDate, val end: LocalDate) {
    val kind: DayKind get() = day.kind
    val days: Int get() = (end.toEpochDay() - start.toEpochDay() + 1).toInt()
    /** A night belongs to the evening before its hijri day: the night of the 27th is 26 → 27. */
    val eve: LocalDate? get() = if (day.kind == DayKind.NIGHT) start.minusDays(1) else null
    fun contains(date: LocalDate): Boolean = !date.isBefore(start) && !date.isAfter(end)
    /** Stable id for saved state and notifications: "QADR-1447". */
    val id: String get() = "${day.name}-$hijriYear"
}

object IslamicDays {
    /** HijrahChronology (Umm al-Qura) is defined for 1300..1600 AH; we keep a margin inside it. */
    const val MIN_YEAR = 1301
    const val MAX_YEAR = 1599

    /** The four sacred months of 9:36. */
    private val SACRED = setOf(1, 7, 11, 12)

    private val ARABIC_MONTHS = arrayOf(
        "مُحَرَّم", "صَفَر", "رَبِيع الأَوَّل", "رَبِيع الآخِر", "جُمَادَى الأُولَى", "جُمَادَى الآخِرَة",
        "رَجَب", "شَعْبَان", "رَمَضَان", "شَوَّال", "ذُو القَعْدَة", "ذُو الحِجَّة"
    )

    fun isSacredMonth(month: Int): Boolean = month in SACRED

    fun arabicMonth(month: Int): String = ARABIC_MONTHS[(month - 1).coerceIn(0, 11)]

    fun hijriOf(date: LocalDate, offset: Int = 0): HijriDay {
        val h = HijrahDate.from(date.plusDays(offset.toLong()))
        return HijriDay(h.get(ChronoField.YEAR), h.get(ChronoField.MONTH_OF_YEAR), h.get(ChronoField.DAY_OF_MONTH))
    }

    /** Gregorian day of a hijri date, or null outside the chronology (or day 30 of a 29-day month). */
    fun gregorian(year: Int, month: Int, day: Int, offset: Int = 0): LocalDate? = runCatching {
        LocalDate.from(HijrahDate.of(year, month, day)).minusDays(offset.toLong())
    }.getOrNull()

    fun monthLength(year: Int, month: Int): Int =
        runCatching { HijrahDate.of(year, month, 1).lengthOfMonth() }.getOrDefault(30)

    /**
     * First and last Gregorian day of a hijri month. A Pair, not `first..last`: LocalDate is
     * Comparable<ChronoLocalDate>, so Kotlin's rangeTo does not apply to it.
     */
    fun monthRange(year: Int, month: Int, offset: Int = 0): Pair<LocalDate, LocalDate>? {
        val first = gregorian(year, month, 1, offset) ?: return null
        return first to first.plusDays(monthLength(year, month) - 1L)
    }

    /** The twelve months of a hijri year with their Gregorian bounds, for the year view. */
    fun months(year: Int, offset: Int = 0): List<HijriMonthSpan> {
        if (year < MIN_YEAR || year > MAX_YEAR) return emptyList()
        val all = this.year(year, offset)
        return (1..12).mapNotNull { m ->
            val (start, end) = monthRange(year, m, offset) ?: return@mapNotNull null
            HijriMonthSpan(year, m, start, end, all.filter { it.day.month == m })
        }
    }

    private fun spanOf(day: IslamicDay, year: Int): Int =
        if (day.span > 0) day.span else monthLength(year, day.month) - day.day + 1

    fun occurrence(day: IslamicDay, year: Int, offset: Int = 0): DayOccurrence? {
        if (year < MIN_YEAR || year > MAX_YEAR) return null
        val start = gregorian(year, day.month, day.day, offset) ?: return null
        return DayOccurrence(day, year, start, start.plusDays(spanOf(day, year) - 1L))
    }

    /** Every day of a hijri year, in calendar order. */
    fun year(year: Int, offset: Int = 0): List<DayOccurrence> =
        IslamicDay.entries.mapNotNull { occurrence(it, year, offset) }.sortedWith(compareBy({ it.start }, { -it.kind.priority }))

    /** What falls on [date], the most important first. Empty on an ordinary day. */
    fun on(date: LocalDate, offset: Int = 0): List<DayOccurrence> {
        val h = runCatching { hijriOf(date, offset) }.getOrNull() ?: return emptyList()
        return IslamicDay.entries.mapNotNull { d ->
            if (d.month != h.month || h.day < d.day) return@mapNotNull null
            val span = spanOf(d, h.year)
            if (h.day >= d.day + span) return@mapNotNull null
            val start = date.minusDays((h.day - d.day).toLong())
            DayOccurrence(d, h.year, start, start.plusDays(span - 1L))
        }.sortedWith(compareBy({ -it.kind.priority }, { it.day.ordinal }))
    }

    /** The day the cell is painted with: the highest priority on that date. */
    fun primary(date: LocalDate, offset: Int = 0): DayOccurrence? = on(date, offset).firstOrNull()

    /** Every occurrence that overlaps [from]..[to] (inclusive). */
    fun between(from: LocalDate, to: LocalDate, offset: Int = 0): List<DayOccurrence> {
        if (to.isBefore(from)) return emptyList()
        val y0 = runCatching { hijriOf(from, offset).year }.getOrNull() ?: return emptyList()
        val y1 = runCatching { hijriOf(to, offset).year }.getOrNull() ?: return emptyList()
        return (y0..y1).flatMap { year(it, offset) }
            .filter { !it.end.isBefore(from) && !it.start.isAfter(to) }
            .sortedWith(compareBy({ it.start }, { -it.kind.priority }))
    }

    /**
     * The next point in time worth waiting for: the first occurrence that has not started yet,
     * seasons included. Looks at most two hijri years ahead.
     */
    fun next(from: LocalDate, offset: Int = 0): DayOccurrence? {
        val y = runCatching { hijriOf(from, offset).year }.getOrNull() ?: return null
        return (y..y + 1).flatMap { year(it, offset) }.firstOrNull { it.start.isAfter(from) }
    }

    /** A blessed night that begins this evening (its hijri day is tomorrow). */
    fun tonight(date: LocalDate, offset: Int = 0): DayOccurrence? =
        on(date.plusDays(1), offset).firstOrNull { it.kind == DayKind.NIGHT && it.start == date.plusDays(1) }

    /** Days from [from] to [to]; negative when [to] is in the past. */
    fun daysBetween(from: LocalDate, to: LocalDate): Long = to.toEpochDay() - from.toEpochDay()

    /** How many days ahead home starts announcing a day. */
    const val SOON_DAYS = 3

    /**
     * What home says about [today], the most pressing first: a feast or a fast today → a blessed
     * night this evening → a day within [SOON_DAYS] → the season we are in (day n of Ramadan) → a
     * season about to begin. Null on an ordinary stretch of the year.
     *
     * A night is never "today" on its own hijri day: by then it has passed (it began the evening
     * before), so on that day home is silent about it.
     */
    fun notice(today: LocalDate, offset: Int = 0): DayNotice? {
        val now = on(today, offset)
        now.firstOrNull { it.kind != DayKind.SEASON && it.kind != DayKind.NIGHT }
            ?.let { return DayNotice(it, NoticeStage.TODAY) }
        tonight(today, offset)?.let { return DayNotice(it, NoticeStage.TONIGHT) }
        val ahead = between(today.plusDays(1), today.plusDays(SOON_DAYS.toLong()), offset)
            .filter { it.start.isAfter(today) }
        ahead.firstOrNull { it.kind != DayKind.SEASON }?.let { return DayNotice(it, NoticeStage.SOON) }
        now.firstOrNull { it.kind == DayKind.SEASON }?.let { return DayNotice(it, NoticeStage.ONGOING) }
        ahead.firstOrNull()?.let { return DayNotice(it, NoticeStage.SOON) }
        return null
    }
}

enum class NoticeStage { TODAY, TONIGHT, SOON, ONGOING }

/** One line on the home screen about the Islamic year (see [IslamicDays.notice]). */
data class DayNotice(val occurrence: DayOccurrence, val stage: NoticeStage)
