package com.nur.prayer

import com.nur.prayer.data.DayKind
import com.nur.prayer.data.IslamicDay
import com.nur.prayer.data.IslamicDays
import com.nur.prayer.data.NoticeStage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/** 0.19.0: the days of the Islamic year against the Umm al-Qura tables (dates checked by hand). */
class IslamicDaysTest {

    private fun d(y: Int, m: Int, day: Int) = LocalDate.of(y, m, day)

    @Test fun keyDatesOf1447And1448MatchUmmAlQura() {
        assertEquals(d(2026, 5, 27), IslamicDays.occurrence(IslamicDay.ADHA, 1447)!!.start)
        assertEquals(d(2026, 5, 26), IslamicDays.occurrence(IslamicDay.ARAFAH, 1447)!!.start)
        assertEquals(d(2026, 6, 16), IslamicDays.occurrence(IslamicDay.HIJRI_NEW_YEAR, 1448)!!.start)
        assertEquals(d(2026, 6, 25), IslamicDays.occurrence(IslamicDay.ASHURA, 1448)!!.start)
        assertEquals(d(2027, 3, 9), IslamicDays.occurrence(IslamicDay.FITR, 1448)!!.start)
    }

    @Test fun ramadanRunsToTheEndOfItsMonth() {
        val r = IslamicDays.occurrence(IslamicDay.RAMADAN, 1448)!!
        assertEquals(d(2027, 2, 8), r.start)
        assertEquals(d(2027, 3, 8), r.end)
        assertEquals(29, r.days)
    }

    @Test fun tashriqIsThreeDaysAfterAdha() {
        val t = IslamicDays.occurrence(IslamicDay.TASHRIQ, 1447)!!
        assertEquals(d(2026, 5, 28), t.start)
        assertEquals(d(2026, 5, 30), t.end)
        assertEquals(IslamicDay.TASHRIQ, IslamicDays.primary(d(2026, 5, 29))!!.day)
    }

    @Test fun theStrongerDayWinsTheCell() {
        val on = IslamicDays.on(d(2026, 5, 26))
        assertEquals(IslamicDay.ARAFAH, on.first().day)
        assertTrue(on.any { it.day == IslamicDay.DHUL_HIJJAH_TEN })
        assertTrue(IslamicDays.on(d(2026, 11, 6)).isEmpty())
    }

    @Test fun aNightBeginsTheEveningBefore() {
        assertEquals(IslamicDay.QADR, IslamicDays.tonight(d(2027, 3, 5))!!.day)
        assertNull(IslamicDays.tonight(d(2027, 3, 6)))
    }

    @Test fun theManualOffsetMovesEveryDay() {
        assertEquals(d(2026, 5, 26), IslamicDays.occurrence(IslamicDay.ADHA, 1447, offset = 1)!!.start)
        assertEquals(d(2026, 5, 28), IslamicDays.occurrence(IslamicDay.ADHA, 1447, offset = -1)!!.start)
        assertEquals(IslamicDay.ADHA, IslamicDays.primary(d(2026, 5, 26), offset = 1)!!.day)
    }

    @Test fun twelveMonthsCoverTheYearWithoutGaps() {
        val months = IslamicDays.months(1448)
        assertEquals(12, months.size)
        months.zipWithNext().forEach { (a, b) -> assertEquals(a.end.plusDays(1), b.start) }
        assertEquals(d(2026, 6, 16), months.first().start)
        assertEquals(d(2027, 6, 5), months.last().end)
    }

    @Test fun homeNoticeSpeaksOfTheMostPressingDay() {
        IslamicDays.notice(d(2026, 5, 27))!!.let {
            assertEquals(IslamicDay.ADHA, it.occurrence.day); assertEquals(NoticeStage.TODAY, it.stage)
        }
        IslamicDays.notice(d(2027, 3, 5))!!.let {
            assertEquals(IslamicDay.QADR, it.occurrence.day); assertEquals(NoticeStage.TONIGHT, it.stage)
        }
        // Day 28 of Ramadan: the Eid two days ahead outranks the month we are in.
        IslamicDays.notice(d(2027, 3, 7))!!.let {
            assertEquals(IslamicDay.FITR, it.occurrence.day); assertEquals(NoticeStage.SOON, it.stage)
        }
        IslamicDays.notice(d(2027, 2, 15))!!.let {
            assertEquals(IslamicDay.RAMADAN, it.occurrence.day); assertEquals(NoticeStage.ONGOING, it.stage)
        }
        IslamicDays.notice(d(2026, 6, 23))!!.let {
            assertEquals(IslamicDay.ASHURA, it.occurrence.day); assertEquals(NoticeStage.SOON, it.stage)
        }
        // On its own hijri day a night is over: home does not call it "today".
        assertTrue(IslamicDays.notice(d(2027, 3, 6))?.stage != NoticeStage.TODAY ||
            IslamicDays.notice(d(2027, 3, 6))!!.occurrence.kind != DayKind.NIGHT)
        assertNull(IslamicDays.notice(d(2026, 11, 6)))
    }

    @Test fun nextLooksAcrossTheYearBoundary() {
        val n = IslamicDays.next(d(2026, 6, 10))
        assertNotNull(n)
        assertEquals(IslamicDay.HIJRI_NEW_YEAR, n!!.day)
    }
}
