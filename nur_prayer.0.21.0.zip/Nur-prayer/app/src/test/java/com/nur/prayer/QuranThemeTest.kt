package com.nur.prayer

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.nur.prayer.quran.QuranStore
import com.nur.prayer.ui.quran.quranColors
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.18.4: «Небо» retired, the paper page added. Stored values and contrast of the new surface. */
class QuranThemeTest {
    @Test
    fun retiredSkyAndUnknownValuesReadAsNight() {
        // 2 was «Небо» until 0.18.3: a reader of the dark sky must not wake up to a bright page.
        assertEquals(QuranStore.THEME_NIGHT, QuranStore.normalizeTheme(2))
        assertEquals(QuranStore.THEME_NIGHT, QuranStore.normalizeTheme(-1))
        assertEquals(QuranStore.THEME_NIGHT, QuranStore.normalizeTheme(42))
        assertEquals(QuranStore.THEME_NIGHT, QuranStore.normalizeTheme(QuranStore.THEME_NIGHT))
        assertEquals(QuranStore.THEME_BLACK, QuranStore.normalizeTheme(QuranStore.THEME_BLACK))
        assertEquals(QuranStore.THEME_LIGHT, QuranStore.normalizeTheme(QuranStore.THEME_LIGHT))
    }

    @Test
    fun onlyThePaperPageIsLight() {
        assertTrue(quranColors(QuranStore.THEME_LIGHT).light)
        assertFalse(quranColors(QuranStore.THEME_NIGHT).light)
        assertFalse(quranColors(QuranStore.THEME_BLACK).light)
        assertFalse(quranColors(2).light)
    }

    private fun contrast(a: Color, b: Color): Double {
        val x = a.luminance() + 0.05
        val y = b.luminance() + 0.05
        return (maxOf(x, y) / minOf(x, y)).toDouble()
    }

    @Test
    fun paperTextMeetsAaOnEverySurface() {
        val c = quranColors(QuranStore.THEME_LIGHT)
        val surfaces = listOf(c.background, c.backgroundBottom, c.card, c.raised, c.inset)
        for (bg in surfaces) {
            assertTrue("text", contrast(c.text, bg) >= 7.0)
            assertTrue("secondary", contrast(c.textSecondary, bg) >= 4.5)
            for ((name, ink) in listOf("tertiary" to c.textTertiary, "accentText" to c.accentText,
                    "positive" to c.positive, "warning" to c.warning)) {
                assertTrue("$name on $bg: ${contrast(ink, bg)}", contrast(ink, bg) >= 4.5)
            }
        }
        assertTrue("ink on gold", contrast(c.onAccent, c.accent) >= 4.5)
    }

    @Test
    fun darkSurfacesKeepTheirTextReadable() {
        for (theme in listOf(QuranStore.THEME_NIGHT, QuranStore.THEME_BLACK)) {
            val c = quranColors(theme)
            assertTrue(contrast(c.text, c.background) >= 7.0)
            assertTrue(contrast(c.accentText, c.card) >= 4.5)
            assertTrue(contrast(c.onAccent, c.accent) >= 4.5)
        }
    }
}
