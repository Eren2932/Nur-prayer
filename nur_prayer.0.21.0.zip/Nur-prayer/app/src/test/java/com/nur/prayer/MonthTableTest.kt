package com.nur.prayer

import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.ui.schedule.tableStartIndex
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

/** 0.20.0: the compact month table — its hijri header and where the list opens. */
class MonthTableTest {

    @Test fun hijriSpanSaysTheYearOnceWithinOneYear() {
        // 1 Nov 2026 = 21 джумада аль-уля 1448, 30 Nov 2026 = 20 джумада ас-сани 1448 (Umm al-Qura).
        assertEquals("джумада аль-уля — джумада ас-сани 1448",
            HijriCalendar.span(LocalDate.of(2026, 11, 1), LocalDate.of(2026, 11, 30)))
    }

    @Test fun hijriSpanKeepsBothYearsAcrossTheNewYear() {
        // 1 Jun 2026 = 15 зуль-хиджа 1447, 30 Jun 2026 = 15 мухаррам 1448.
        assertEquals("зуль-хиджа 1447 — мухаррам 1448",
            HijriCalendar.span(LocalDate.of(2026, 6, 1), LocalDate.of(2026, 6, 30)))
    }

    @Test fun hijriSpanOfOneMonthIsOneName() {
        assertEquals("джумада аль-уля 1448", HijriCalendar.span(LocalDate.of(2026, 11, 6), LocalDate.of(2026, 11, 6)))
    }

    @Test fun hijriSpanHonoursTheOffset() {
        // Shifted by +10 days, 21–22 Nov 2026 read as 1–2 Dec: 21–22 джумада ас-сани.
        assertEquals("джумада ас-сани 1448", HijriCalendar.span(LocalDate.of(2026, 11, 21), LocalDate.of(2026, 11, 22), 10))
    }

    @Test fun tableOpensOnTodayWithTwoRowsAbove() {
        val nov = YearMonth.of(2026, 11)
        assertEquals(3, tableStartIndex(nov, LocalDate.of(2026, 11, 6)))
        assertEquals(0, tableStartIndex(nov, LocalDate.of(2026, 11, 1)))
        assertEquals(0, tableStartIndex(nov, LocalDate.of(2026, 11, 2)))
        assertEquals(27, tableStartIndex(nov, LocalDate.of(2026, 11, 30)))
    }

    @Test fun anotherMonthOpensOnItsFirstDay() {
        assertEquals(0, tableStartIndex(YearMonth.of(2026, 12), LocalDate.of(2026, 11, 6)))
    }
}
