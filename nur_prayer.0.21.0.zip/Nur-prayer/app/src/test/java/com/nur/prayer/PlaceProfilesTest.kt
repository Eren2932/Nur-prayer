package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.RegionalProfiles
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.PlaceProfiles
import com.nur.prayer.notify.AzanSound
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * 0.18.6: Kazan and the rest of Tatarstan default to ДУМ РТ; the rest of Russia keeps ДУМ РФ.
 * The switch must be a change of authority only — the arithmetic stays the one calibrated against
 * the printed ДУМ РТ calendar, so not a single minute moves for Kazan users.
 */
class PlaceProfilesTest {

    @Test
    fun tatarstanDefaultsToItsOwnMuftiate() {
        assertEquals(CalculationMethod.SPIRITUAL_BOARD_TATARSTAN, PlaceProfiles.forPlace("Россия", "Татарстан").method)
        assertEquals(CalculationMethod.SPIRITUAL_BOARD_TATARSTAN, AppSettings().paramsFor("Россия", "Татарстан").method)
        assertEquals(CalculationMethod.SPIRITUAL_BOARD_TATARSTAN, PlaceProfiles.methodsFor("Россия", "Татарстан").first())
    }

    @Test
    fun restOfRussiaIsUnchanged() {
        assertEquals(RegionalProfiles.forCountry("Россия"), PlaceProfiles.forPlace("Россия", "Москва"))
        assertEquals(RegionalProfiles.forCountry("Россия"), PlaceProfiles.forPlace("Россия", null))
        assertEquals(RegionalProfiles.forCountry("Узбекистан"), PlaceProfiles.forPlace("Узбекистан", "Татарстан"))
    }

    @Test
    fun tatarstanArithmeticEqualsTheCalibratedProfile() {
        val rt = CalculationMethod.SPIRITUAL_BOARD_TATARSTAN
        val rf = CalculationMethod.RUSSIA_DUM
        assertEquals(rf.fajrAngle, rt.fajrAngle, 0.0)
        assertEquals(rf.ishaAngle, rt.ishaAngle, 0.0)
        assertEquals(rf.congregationalFajrBeforeSunrise, rt.congregationalFajrBeforeSunrise)
        assertEquals(RegionalProfiles.forCountry("Россия").convention, PlaceProfiles.TATARSTAN.convention)
    }

    @Test
    fun defaultSoundIsTheSystemOne() {
        assertEquals(AzanSound.SYSTEM, AppSettings().azanSound)
    }
}
