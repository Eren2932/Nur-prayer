package com.nur.prayer.core.astro

/**
 * Which convention a place belongs to.
 *
 * ### The bug this file exists to kill
 *
 * Until 0.2.7 the app had exactly one default: ДУМ РФ angles (18°/15°), the Tatarstan editorial
 * offsets, and the Russian congregational rule "Fajr = sunrise − 90 min". That default was applied
 * to all 424 cities, including the 134 outside Russia — so Bukhara was computed by the rules of a
 * Kazan mosque poster. Measured against namozvaqti.uz for 18.08.2026 the damage was:
 *
 *     Фаджр    04:28 вместо 04:36   (−8 мин: чужое правило «восход − 90»)
 *     Восход   05:58 вместо 06:02   (−4 мин: узбекский календарь печатает с запасом)
 *     Зухр     12:45 вместо 12:51   (−6 мин: в Узбекистане Зухр печатают позже зенита)
 *     Магриб   19:32 вместо 19:36   (−4 мин, и это худшая из ошибок: ифтар раньше заката)
 *     Иша      20:53 вместо 20:57
 *
 * None of that is an astronomy error — the engine's sunset for Bukhara is 19:33:20 and the true
 * instants are right to the second. It is a *convention* error, and a convention is a property of
 * the place, not of the app.
 *
 * ### The rule
 *
 * A profile is chosen from the country of the selected city, and the user can override it in
 * settings. An override is remembered as an override: it does not silently become the new default
 * for every other country the user then visits.
 *
 * ### On honesty
 *
 * [Calibration] is printed in "О расчёте" verbatim, because there is a real difference between
 * "this reproduces the printed calendar digit for digit" (Russia: 28 of 28 values, four days;
 * Uzbekistan: 6 of 6 values, one day) and "these are the published angles of the local authority,
 * but no calendar of theirs has been compared yet" — which is the state of Kazakhstan, Kyrgyzstan,
 * Tajikistan, Turkmenistan, Azerbaijan and the Levant. Guessing a number and presenting it as
 * verified is how a prayer app loses the right to be trusted.
 */
enum class Calibration(val label: String) {
    /** Verified against a published calendar of that authority, minute for minute. */
    PRINTED_CALENDAR("сверено с печатным календарём"),

    /** The authority's own published angles, no printed table compared yet. */
    OFFICIAL_ANGLES("официальные углы метода"),

    /** Reasonable regional default; needs a photo of a local calendar to be promoted. */
    ASSUMED("общий метод, календарь ещё не сверялся")
}

/**
 * A calculation profile for one country: what to compute, how to print it, and how sure we are.
 */
@androidx.compose.runtime.Immutable
data class RegionalProfile(
    val method: CalculationMethod,
    val convention: CalendarConvention,
    val calibration: Calibration,
    val note: String
)

object RegionalProfiles {

    /** Russia and the countries that follow the Russian boards' printed tables. */
    val RUSSIA = RegionalProfile(
        method = CalculationMethod.RUSSIA_DUM,
        convention = CalendarConvention.DUM_RT,
        calibration = Calibration.PRINTED_CALENDAR,
        note = "Совет муфтиев России, сверено с календарём ДУМ РТ за 15–18.08.2026 (28 из 28 значений)."
    )

    val UZBEKISTAN = RegionalProfile(
        method = CalculationMethod.UZBEKISTAN_BOARD,
        convention = CalendarConvention.UZBEKISTAN,
        calibration = Calibration.PRINTED_CALENDAR,
        note = "Муфтият Узбекистана, сверено с namozvaqti.uz по Бухаре за 18.08.2026 " +
            "(6 из 6 значений, один день)."
    )

    /**
     * Central Asia and the Caucasus outside Uzbekistan.
     *
     * MWL angles (18°/17°) with no editorial offsets. Chosen because it is what the muftiyats of
     * Kazakhstan and Kyrgyzstan publish angles-wise, and because a wrong *offset* is worse than no
     * offset: a missing safety margin errs by a minute, a foreign margin errs by five in whichever
     * direction the other country happens to favour. Hanafi Asr comes from the user's madhab
     * setting, which is already Hanafi by default.
     */
    val CENTRAL_ASIA = RegionalProfile(
        method = CalculationMethod.MUSLIM_WORLD_LEAGUE,
        convention = CalendarConvention.ASTRONOMICAL,
        calibration = Calibration.ASSUMED,
        note = "Углы 18°/17° без редакционных поправок. Пришлите фото местного календаря — " +
            "профиль будет откалиброван так же, как узбекский."
    )

    private fun official(method: CalculationMethod, note: String) =
        RegionalProfile(method, CalendarConvention.ASTRONOMICAL, Calibration.OFFICIAL_ANGLES, note)

    private val BY_COUNTRY: Map<String, RegionalProfile> = mapOf(
        "Россия" to RUSSIA,
        "Беларусь" to RUSSIA,
        "Узбекистан" to UZBEKISTAN,
        "Казахстан" to CENTRAL_ASIA,
        "Киргизия" to CENTRAL_ASIA,
        "Таджикистан" to CENTRAL_ASIA,
        "Туркменистан" to CENTRAL_ASIA,
        // Azerbaijan is majority Ja'fari; the Управление мусульман Кавказа prints times close to
        // the Tehran institute. Kept on the general profile because no calendar has been compared,
        // with Tehran one tap away in the method list.
        "Азербайджан" to CENTRAL_ASIA,
        "Турция" to official(
            CalculationMethod.TURKEY,
            "Diyanet İşleri Başkanlığı: собственные поправки Diyanet по восходу, Зухру, Асру и Магрибу."
        ),
        "Саудовская Аравия" to official(
            CalculationMethod.UMM_AL_QURA,
            "Умм аль-Кура: Иша — закат + 90 минут, как печатает календарь Мекки."
        ),
        "ОАЭ" to official(CalculationMethod.DUBAI, "Официальный расчёт ОАЭ с поправками Дубая."),
        "Катар" to official(CalculationMethod.QATAR, "Катар: Иша — закат + 90 минут."),
        "Кувейт" to official(CalculationMethod.KUWAIT, "Кувейт: 18°/17,5°."),
        "Египет" to official(
            CalculationMethod.EGYPTIAN,
            "Египетское управление геодезии: 19,5°/17,5°."
        ),
        "Иран" to official(
            CalculationMethod.TEHRAN,
            "Институт геофизики Тегерана: Магриб по углу 4,5°, а не по закату."
        ),
        "Бахрейн" to CENTRAL_ASIA,
        "Оман" to CENTRAL_ASIA,
        "Иордания" to CENTRAL_ASIA,
        "Ирак" to CENTRAL_ASIA,
        "Сирия" to CENTRAL_ASIA,
        "Ливан" to CENTRAL_ASIA,
        "Палестина / Израиль" to CENTRAL_ASIA
    )

    /** Never null: an unknown country gets the neutral international profile, never the Russian one. */
    fun forCountry(country: String): RegionalProfile = BY_COUNTRY[country] ?: CENTRAL_ASIA

    /** Every country the city database knows must resolve to a profile; asserted by a unit test. */
    fun countries(): Set<String> = BY_COUNTRY.keys

    /**
     * The convention that belongs to a manually chosen method.
     *
     * A user who picks "ДУМ РФ" wants the Kazan poster, offsets included; one who picks MWL wants
     * plain astronomy. Deriving this instead of storing it removes the state that used to be able to
     * disagree with itself — the 0.2.6 settings held `method` and `convention` independently, so
     * choosing MWL kept the Tatarstan second-offsets underneath it.
     */
    fun conventionFor(method: CalculationMethod): CalendarConvention = when (method) {
        CalculationMethod.RUSSIA_DUM,
        CalculationMethod.SPIRITUAL_BOARD_TATARSTAN -> CalendarConvention.DUM_RT
        CalculationMethod.UZBEKISTAN_BOARD -> CalendarConvention.UZBEKISTAN
        else -> CalendarConvention.ASTRONOMICAL
    }
}
