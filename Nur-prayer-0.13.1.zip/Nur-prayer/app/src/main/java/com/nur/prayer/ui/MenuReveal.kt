package com.nur.prayer.ui

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import kotlin.math.hypot
import kotlin.math.max

/*
 * 0.13.0: pages opened from the home menu grow out of the button that was tapped and shrink back
 * into it on the way home.
 *
 *  - One 0→1 value from the AnimatedContent transition itself drives the circle; it is read only in
 *    the layer and draw phases, so the page composes once and then only redraws.
 *  - The radius is measured to the farthest corner from the origin, so the circle ends exactly when
 *    the page is fully covered: no tail where it keeps growing off-screen.
 *  - A veil the colour of the sky fills the circle while it grows: Кыбла is a transparent page over
 *    the sky, and without the veil home would show through the circle. The veil melts in the last
 *    third, which is when the stars and the glow come back.
 *  - The same wrapper stays around the page for its whole life (only `active` changes), so going on
 *    to «Город» and back never rebuilds the page and never loses its scroll position.
 */
internal object MenuRevealMotion {
    const val OPEN_MILLIS = 440
    const val CLOSE_MILLIS = 340
    /** Home fades out under the circle once the circle covers most of it. */
    const val HOME_FADE_DELAY = 220
}

/** Circle grown from [origin] (page-local px). */
internal class CircleRevealShape(private val origin: Offset, private val fraction: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val o = if (origin.isSpecified) origin else Offset(size.width / 2f, size.height / 2f)
        val r = RevealGeometry.farthestCorner(o.x, o.y, size.width, size.height) * fraction
        return Outline.Generic(Path().apply { addOval(Rect(o, r)) })
    }
}

internal object RevealGeometry {
    fun farthestCorner(x: Float, y: Float, w: Float, h: Float): Float =
        max(max(hypot(x, y), hypot(w - x, y)), max(hypot(x, h - y), hypot(w - x, h - y)))

    /** 1 while the circle grows, melting to 0 over the last 30 %. */
    fun veilAlpha(progress: Float): Float = 1f - ((progress - 0.7f) / 0.3f).coerceIn(0f, 1f)
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
internal fun AnimatedVisibilityScope.MenuRevealBox(
    active: () -> Boolean,
    originInRoot: () -> Offset,
    veil: () -> Brush,
    content: @Composable () -> Unit
) {
    val progress = transition.animateFloat(
        transitionSpec = {
            if (targetState == EnterExitState.Visible) tween(MenuRevealMotion.OPEN_MILLIS, easing = FastOutSlowInEasing)
            else tween(MenuRevealMotion.CLOSE_MILLIS, easing = FastOutLinearInEasing)
        },
        label = "menuReveal"
    ) { state -> if (state == EnterExitState.Visible) 1f else 0f }
    val topLeft = remember { arrayOf(Offset.Zero) }
    Box(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { topLeft[0] = it.positionInRoot() }
            .graphicsLayer {
                val p = progress.value
                val origin = originInRoot()
                if (active() && origin.isSpecified && p < 1f) {
                    clip = true
                    shape = CircleRevealShape(origin - topLeft[0], p)
                } else {
                    clip = false
                    shape = RectangleShape
                }
            }
            .drawBehind {
                if (active() && originInRoot().isSpecified) {
                    val a = RevealGeometry.veilAlpha(progress.value)
                    if (a > 0f) drawRect(veil(), alpha = a)
                }
            }
    ) { content() }
}
