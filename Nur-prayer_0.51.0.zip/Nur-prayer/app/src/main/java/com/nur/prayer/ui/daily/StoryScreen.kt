package com.nur.prayer.ui.daily

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.daily.StoryPhotoOrder
import com.nur.prayer.daily.StorySlide
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.ExitButtonSpec
import com.nur.prayer.ui.components.ExitDock
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.pageContentInsets
import com.nur.prayer.ui.learn.SpeakButton
import com.nur.prayer.ui.learn.rememberVoiceStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

private class StoryFrame(val resource: Int, val index: Int, val slide: StorySlide, val photo: Bitmap, val art: StoryArtwork, val title: String, val scale: Float)
private val night = Brush.verticalGradient(listOf(Color(0xff151515), Color(0xff1b1918), Color(0xff100d0b), Color(0xff080706)))

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StoryScreen(slides: List<StorySlide>, start: Int, opening: Int, day: Long, onSeen: (Int) -> Unit, onClose: () -> Unit) {
    if (slides.isEmpty()) { LaunchedEffect(Unit) { onClose() }; return }
    var index by rememberSaveable(opening) { mutableIntStateOf(start.coerceIn(slides.indices)) }
    var restart by remember(opening) { mutableIntStateOf(0) }
    var held by remember { mutableStateOf(false) }
    var longHold by remember { mutableStateOf(false) }
    var reading by rememberSaveable(opening) { mutableStateOf(false) }
    var sharing by remember { mutableStateOf(false) }
    var closed by remember(opening) { mutableStateOf(false) }
    val safeIndex = index.coerceIn(slides.indices)
    val slide = slides[safeIndex]
    val context = LocalContext.current
    val density = LocalDensity.current
    val fontScale = density.fontScale
    val title = tr(slide.kind).uppercase(L10n.language.locale)
    val ref = remember(day, safeIndex) { storyPhotos[StoryPhotoOrder.index(day, safeIndex, storyPhotos.size)] }
    val resources = context.resources
    val frame by produceState<StoryFrame?>(null, slide, ref, title, fontScale, safeIndex) {
        value = withContext(Dispatchers.Default) {
            val bitmap = requireNotNull(BitmapFactory.decodeResource(resources, ref))
            StoryFrame(ref, safeIndex, slide, bitmap, StoryArtwork(slide, title, fontScale), title, fontScale)
        }
    }
    val ready = frame?.let { it.resource == ref && it.index == safeIndex && it.slide == slide && it.title == title && it.scale == fontScale } == true
    val progress = remember(opening, safeIndex, restart) { mutableFloatStateOf(0f) }
    val drag = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val latestClose by rememberUpdatedState(onClose)
    fun closeOnce() { if (!closed) { closed = true; latestClose() } }
    fun go(delta: Int) {
        if (closed || sharing) return
        val next = index + delta
        when { next < 0 -> restart++; next > slides.lastIndex -> closeOnce(); else -> index = next }
    }
    BackHandler { closeOnce() }
    val life by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    val focused = LocalWindowInfo.current.isWindowFocused
    val hidden = reading || (held && longHold)
    StoryBars(hidden && !closed)
    LaunchedEffect(held) {
        longHold = false
        if (held) { delay(StoryMath.TAP_MAX_MILLIS); longHold = true }
    }
    LaunchedEffect(ready, safeIndex, opening) { if (ready) onSeen(safeIndex) }
    val paused = held || hidden || sharing || closed || !ready || !focused || life != Lifecycle.State.RESUMED
    LaunchedEffect(progress, paused) {
        if (paused) return@LaunchedEffect
        // Reading time is real elapsed foreground time, not Android's animator duration scale.
        val from = progress.floatValue
        val durationNs = StoryMath.durationMillis(slide) * 1_000_000L
        val started = withFrameNanos { it }
        while (progress.floatValue < 1f) withFrameNanos { now ->
            progress.floatValue = (from + (now - started).toFloat() / durationNs).coerceAtMost(1f)
        }
        go(1)
    }
    val bottom = WindowInsets.navigationBarsIgnoringVisibility.asPaddingValues().calculateBottomPadding()
    val top = WindowInsets.statusBarsIgnoringVisibility.asPaddingValues().calculateTopPadding()
    val voice = rememberVoiceStatus()
    val previous = tr("Предыдущее")
    val next = tr("Следующее")
    val action = tr("Поделиться").uppercase(L10n.language.locale)
    val failed = tr("Не удалось подготовить картинку")
    Box(Modifier.fillMaxSize().background(night)) {
        Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.displayCutout.only(WindowInsetsSides.Horizontal))
            .pointerInput(opening, slides.size, density) {
                val swipe = 56.dp.toPx(); val close = 120.dp.toPx()
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val origin = down.position
                    var moved = false
                    var cancelled = false
                    held = true
                    try {
                        while (true) {
                            val e = awaitPointerEvent()
                            val c = e.changes.firstOrNull { it.id == down.id } ?: break
                            val d = c.position - origin
                            if (e.changes.size != 1 || c.isConsumed) cancelled = true
                            if (d.getDistance() > viewConfiguration.touchSlop) moved = true
                            if (!c.pressed) {
                                if (!cancelled) when (StoryMath.classify(c.uptimeMillis - down.uptimeMillis, d.x, d.y, swipe, close)) {
                                    StoryMath.Gesture.CLOSE -> closeOnce()
                                    StoryMath.Gesture.PREV -> go(-1)
                                    StoryMath.Gesture.NEXT -> go(1)
                                    StoryMath.Gesture.TOGGLE -> if (!moved) reading = !reading
                                    StoryMath.Gesture.NONE -> Unit
                                }
                                break
                            }
                            if (!cancelled && moved && d.y > abs(d.x)) {
                                scope.launch { drag.snapTo(d.y) }; c.consume()
                            }
                        }
                    } finally { held = false }
                    if (!closed) scope.launch { drag.animateTo(0f, NurMotion.gentle()) }
                }
            }) {
            BoxWithConstraints(Modifier.fillMaxSize().graphicsLayer { translationY = drag.value }.padding(top = top + 68.dp, bottom = ExitButtonSpec.contentFloor(bottom)), contentAlignment = Alignment.Center) {
                // Normally a fixed 88%-width card. Small landscape/split windows keep a readable
                // column and scroll only when the screen cannot physically hold it at that size.
                val width = minOf(maxWidth * .88f, 435.dp, maxOf(255.dp, maxHeight * (608f / 932f)))
                val room = maxHeight
                val active = frame
                if (active != null) Crossfade(targetState = active, animationSpec = tween(160), label = "storyArt") { f ->
                    val h = width * (f.art.height / StoryArtwork.WIDTH)
                    val scroll = rememberScrollState()
                    Box(Modifier.width(width).heightIn(max = room).then(if (h > room) Modifier.verticalScroll(scroll) else Modifier)) {
                        Canvas(Modifier.width(width).height(h).testTag("story-art").semantics {
                            contentDescription = f.art.description
                            onClick { reading = !reading; true }
                            customActions = listOf(CustomAccessibilityAction(previous) { go(-1); true }, CustomAccessibilityAction(next) { go(1); true })
                        }) { f.art.draw(drawContext.canvas.nativeCanvas, size.width, f.photo) }
                    }
                }
            }
        }
        if (!hidden) {
            Column(Modifier.fillMaxWidth().pageContentInsets().padding(horizontal = 16.dp).padding(top = 10.dp)) {
                Canvas(Modifier.fillMaxWidth().height(3.dp)) {
                    val gap = 4.dp.toPx(); val w = (size.width - gap * slides.lastIndex) / slides.size
                    val r = CornerRadius(size.height / 2f)
                    for (s in slides.indices) {
                        val at = Offset(s * (w + gap), 0f)
                        drawRoundRect(Color(0xff595959), at, Size(w, size.height), r)
                        val fill = when { s < safeIndex -> 1f; s == safeIndex -> progress.floatValue; else -> 0f }
                        if (fill > 0f) drawRoundRect(Color.White, at, Size(w * fill, size.height), r)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("На сегодня"), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    val word = slide.arabic
                    if (slide.kind == WORD_KIND && slide.voiced && word != null) SpeakButton(word, voice, size = 40.dp)
                    Text("${safeIndex + 1} / ${slides.size}", color = Color(0xffcecbc8), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().pageContentInsets()) {
                ExitDock(onClose = { closeOnce() }, bottom = bottom, description = tr("Закрыть"),
                    onMenu = { reading = true }, menuDescription = tr("Скрыть сведения"))
                Box(Modifier.align(Alignment.BottomCenter).padding(bottom = ExitButtonSpec.bottomGap(bottom))
                    .height(ExitButtonSpec.Hit).width(144.dp).clickable(enabled = ready && !sharing, role = Role.Button) {
                        val selected = frame
                        if (selected != null && !sharing) {
                            sharing = true
                            scope.launch {
                                try { val intent = StoryShare.image(context, selected.slide, selected.title, selected.scale, selected.photo)
                                    if (!closed) context.startActivity(intent)
                                } catch (e: CancellationException) { throw e }
                                catch (_: Exception) { Toast.makeText(context, failed, Toast.LENGTH_SHORT).show() }
                                finally { sharing = false }
                            }
                        }
                    }, contentAlignment = Alignment.Center) {
                    Box(Modifier.fillMaxWidth().height(ExitButtonSpec.Diameter).background(Color.Black.copy(alpha = .12f), CircleShape)
                        .border(1.dp, Color.White.copy(alpha = .5f), CircleShape), contentAlignment = Alignment.Center) {
                        Text(action, fontSize = minOf(13f, with(density) { 16.dp.toSp().value }).sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                    }
                }
            }
        }
    }
}
