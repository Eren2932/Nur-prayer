package com.nur.prayer.ui.daily

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.nur.prayer.ui.theme.findActivity

/** Hiding composables alone leaves the battery and time visible. Restore only what we hid. */
@Composable
internal fun StoryBars(hidden: Boolean) {
    val window = LocalContext.current.findActivity()?.window ?: return
    DisposableEffect(window, hidden) {
        val view = window.decorView
        val controller = WindowCompat.getInsetsController(window, view)
        val status = WindowInsetsCompat.Type.statusBars()
        val nav = WindowInsetsCompat.Type.navigationBars()
        val before = ViewCompat.getRootWindowInsets(view)
        val restore = (if (before?.isVisible(status) != false) status else 0) or
            (if (before?.isVisible(nav) != false) nav else 0)
        val behavior = controller.systemBarsBehavior
        if (hidden) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(status or nav)
        }
        onDispose {
            if (hidden) {
                controller.systemBarsBehavior = behavior
                if (restore != 0) controller.show(restore)
            }
        }
    }
}
