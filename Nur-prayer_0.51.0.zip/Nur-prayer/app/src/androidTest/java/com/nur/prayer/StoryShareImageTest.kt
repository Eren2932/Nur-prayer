package com.nur.prayer

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.nur.prayer.daily.DailyStories
import com.nur.prayer.ui.daily.StoryArtwork
import com.nur.prayer.ui.daily.StoryShare
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import kotlin.math.ceil

@RunWith(AndroidJUnit4::class)
class StoryShareImageTest {
    @Suppress("DEPRECATION")
    @Test fun receiverGetsTheSameCompleteCardAndAnIndependentReadGrant() = runBlocking {
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        val slide = DailyStories.DUAS.maxBy { it.ru.length + it.arabic.orEmpty().length }
        val image = BitmapFactory.decodeResource(ctx.resources, R.drawable.story_clock_horizon)
        val title = "ДУА ДНЯ"
        val model = StoryArtwork(slide, title, 1.75f)
        val w = 1080
        val expected = Bitmap.createBitmap(w, ceil(model.height * w / StoryArtwork.WIDTH).toInt(), Bitmap.Config.ARGB_8888)
        try {
            model.draw(Canvas(expected), w.toFloat(), image)
            suspend fun uri(): Uri {
                val chooser = StoryShare.image(ctx, slide, title, 1.75f, image)
                val send = requireNotNull(chooser.getParcelableExtra<Intent>(Intent.EXTRA_INTENT))
                assertEquals(Intent.ACTION_SEND, send.action)
                assertEquals("image/png", send.type)
                assertTrue(send.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION != 0)
                val stream = requireNotNull(send.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))
                assertEquals("content", stream.scheme)
                assertEquals(stream, send.clipData?.getItemAt(0)?.uri)
                return stream
            }
            val first = uri(); val second = uri()
            assertTrue(first != second)
            val decoded = requireNotNull(ctx.contentResolver.openInputStream(first)?.use { BitmapFactory.decodeStream(it) })
            try {
                assertEquals(expected.width, decoded.width)
                assertEquals(expected.height, decoded.height)
                assertTrue(expected.sameAs(decoded))
            } finally { decoded.recycle() }
        } finally { expected.recycle(); image.recycle() }
    }
}
