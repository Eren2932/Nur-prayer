package com.nur.prayer.ui.home

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow

/**
 * 0.30.0: every number of both home screens, in one place, with where it came from.
 *
 * The two mocks were measured pixel by pixel. Both were drawn on a 393 dp wide frame (the width
 * [com.nur.prayer.ui.theme.uiScale] already treats as 1.0): the card mock is 841 px wide
 * (1 px = 0.467 dp), the big-word mock 1080 px (1 px = 0.364 dp). Check of the frame: the capsule
 * is 64 dp high in the code and 138 px / 177 px in the two pictures. Sizes below are dp / sp at
 * that frame; the screens multiply them with `uiScale()` like the rest of the app.
 *
 * Fonts: glyph heights were turned into sizes with cap height 0.714 em and x-height 0.536 em.
 */
internal object HomeSpec {
    /** The soft shadow under text that lies straight on the wallpaper. */
    val OnSky = Shadow(Color(0x8C000000), blurRadius = 12f)

    // ---------------------------------------------------------------- shared colours (measured)

    /** The gold of the pill, the progress line and the next node (mock 2: 244, 196, 112). */
    val Gold = Color(0xFFF4C470)

    /** The gold card of the next prayer (mock 1: 230, 181, 111). */
    val GoldCard = Color(0xFFE6B56F)

    /** Text and glyphs on gold (mock 2: 34, 24, 10). */
    val OnGold = Color(0xFF22180A)

    // ---------------------------------------------------------------- variant 1: cards

    object Cards {
        /**
         * The glass of a card. Measured on the reference with the sheep wallpaper: inside the card a pixel
         * is 0.20 × the pixel outside it, with an intercept of 0 in all three channels (correlation
         * 0.94–0.998): a flat 80 % layer, no blur. Same coverage here, in white.
         */
        const val GLASS_ALPHA = 0.80f
        val Glass = Color.White.copy(alpha = GLASS_ALPHA)

        /** Ink on the white cards: a deep blue-black, dimmer for a time that has passed. */
        val Ink = Color(0xFF14161F)
        const val INK_PAST = 0.60f
        const val INK_SUB = 0.62f
        const val INK_SUB_PAST = 0.55f

        /** «идёт сейчас» and the glyph of the current window: dark amber, readable on white. */
        val Amber = Color(0xFF8A5200)

        // geometry (dp). One shape for every card: the gold one of the mock (105 px × 768 px).
        const val SIDE = 17f          // 36 px
        const val CARD_HEIGHT = 49f   // 105 px
        const val CARD_RADIUS = 10f   // 22 px
        const val CARD_GAP = 5f       // pitch 116 px − 105 px
        const val ICON_START = 12f    // 25 px
        const val ICON_DIAMETER = 26f // 55 px
        const val ICON_GLYPH = 15f    // 33 px
        const val TEXT_GAP = 11f      // 25 px between the circle and the text
        const val TIME_GAP = 14f      // 30 px between the time and the bell
        const val BELL = 12f          // 25 px
        const val END = 12.5f         // 27 px
        const val BAR_HEIGHT = 3f     // 7 px
        const val BAR_BOTTOM = 2f     // 4 px
        const val BAR_END = 36f       // the bar stops under the end of the time (77 px)

        // type (sp)
        const val TITLE = 15f
        const val SUB = 11.5f
        const val TIME = 18f
        const val TITLE_BASELINE = 23.1f // 49 px under the card's top
        const val SUB_BASELINE = 37.5f   // 80 px
        const val LABEL = 15.5f       // «Зухр через»
        const val COUNT = 64f         // digits 98 px high
        const val COUNT_MIN = 44f
        const val AZAN = 11.5f

        // The hero, placed by baselines from its top edge (dp). Label baseline 534.5 px, digits 681.5 px,
        // «азан в» 732 px in the mock; the top edge is 15 dp above the label's baseline.
        const val LABEL_BASELINE = 15f
        const val COUNT_BASELINE = 83.7f
        const val AZAN_BASELINE = 107.3f
        /** The azan line's box ends about 3 dp under its baseline; the cards start 41 dp under it (820 − 732 px). */
        const val HERO_TO_LIST = 38f
        /**
         * Free height above / below the block, as measured: the hero starts 278 px (130 dp) under the
         * header and the list ends 165 px (77 dp) above the capsule's room. They split what a taller or a
         * shorter phone adds or takes in that ratio.
         *
         * 0.30.2: the block stands a little higher: 116 : 91 instead of 130 : 77 (same sum, 207). On the mock
         * that is 14 dp up; on a taller phone it is more, on a shorter one less, and on a phone with no free
         * height at all it is nothing — the lift is a share of the free room, never a fixed offset that could
         * push the list into the header or the capsule.
         */
        const val WEIGHT_TOP = 116f
        const val WEIGHT_BOTTOM = 91f
    }

    // ---------------------------------------------------------------- variant 2: the big word

    object Big {
        // type (sp)
        const val KICKER = 14f        // «Следующий намаз», cap 27.5 px
        const val WORD = 92f          // «Зухр», cap 183 px
        const val WORD_MIN = 48f
        const val PILL_TIME = 19.5f   // digits 38 px
        const val COUNT = 50f         // digits 98 px
        const val COUNT_MIN = 36f
        const val CAPTION = 12f       // «до начала»
        const val BUBBLE_TIME = 13f   // digits 25.5 px
        const val NAME = 9.3f         // cap 18 px
        const val STAMP = 10.5f       // digits 20.5 px

        // pill
        const val PILL_WIDTH = 87f    // 240 px
        const val PILL_HEIGHT = 28f   // 78 px (a full stadium)

        // timeline
        const val SIDE = 36f          // 100 px: the first node sits here, the last one mirrors it
        const val LINE = 2.2f         // 6 px
        const val TRACK_ALPHA = 0.28f // white over the picture: (123 − 72) / (255 − 72)
        const val NODE = 9f           // 25 px
        const val NODE_RING = 3f      // 8 px (past: gold ring around a dark dot)
        const val NODE_RING_FUTURE = 1.5f // 4 px
        const val NEXT_NODE = 14f     // 39 px
        const val NEXT_RING = 1.5f    // 4 px, white
        const val BUBBLE_HEIGHT = 22f // 60 px (a full stadium)
        const val BUBBLE_PAD = 8.5f   // 23 px each side of the digits
        const val TAIL_HEIGHT = 6f    // 16 px
        const val TAIL_WIDTH = 7f     // 20 px
        const val LABEL_GAP = 6f      // least air between two neighbouring labels
        const val EDGE = 8f           // the bubble and the labels never come closer to the screen edge

        // The hero, placed by baselines from its top edge (dp): kicker baseline 519 px, word 740 px,
        // pill 842 px (top edge), digits 1092 px, caption 1151 px; the top edge is 14 dp above the kicker's baseline.
        const val KICKER_BASELINE = 14f
        const val WORD_BASELINE = 94.4f
        const val PILL_TOP = 131.5f
        const val COUNT_BASELINE = 222.5f
        const val CAPTION_BASELINE = 244.0f

        /** The caption's box ends 3 dp under its baseline; the bubble starts 49 dp under it (1286 − 1151 px). */
        const val HERO_TO_TIMELINE = 46f

        // The timeline, placed from the top of the bubble (dp): the line's centre is 104 px under it,
        // the names' baseline 168 px (cap top 1438 px + cap height), the times' baseline 214 px.
        const val BUBBLE_TOP = 0f
        const val LINE_Y = 37.8f
        const val NAME_BASELINE = 61.6f
        const val STAMP_BASELINE = 78.2f
        const val TIMELINE_HEIGHT = 82f

        /**
         * Free height above / below the block: the hero starts 195 px (71 dp) under the header and the
         * timeline ends 638 px (232 dp) above the capsule's room.
         */
        const val WEIGHT_TOP = 71f
        const val WEIGHT_BOTTOM = 232f

        val NodeInk = HomeSpec.OnGold
        val FutureFill = Color(0xFF1E1E28)
        val FutureRing = Color(0xFFC8C8CA)
    }
}
