package com.nur.prayer

import androidx.compose.runtime.remember
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.DailyStories
import com.nur.prayer.daily.Vird
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.daily.StoryScreen
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.today.TodayActions
import com.nur.prayer.ui.today.TodayScreen
import com.nur.prayer.ui.today.TodayState
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DeedsUiTest {
    @get:Rule val compose = createComposeRule()

    @Test fun practicalEntriesDoNotOpenTheCourse() {
        val taps = mutableListOf<String>()
        val state = TodayState("", 20_000L, AzkarSet.MORNING, true, 2, 17, false, Vird.DEFAULT,
            emptyMap(), 0, null, null)
        compose.setContent { NurTheme {
            TodayScreen(state, remember { Reveal(true) }, TodayActions({}, { i -> taps.add("read:$i") }, {},
                { taps.add("azkar") }, {}, {}, {}))
        } }
        compose.onAllNodesWithText("Обучение").assertCountEquals(0)
        compose.onAllNodesWithText("Слово дня").assertCountEquals(0)
        compose.onNodeWithText("Утренние азкары").performScrollTo().performClick()
        compose.onNodeWithText("Хадис дня").performScrollTo().performClick()
        compose.runOnIdle { assertEquals(listOf("azkar", "read:1"), taps) }
    }

    @Test fun dailyReaderWaitsForAnExplicitTurn() {
        val seen = mutableListOf<Int>()
        compose.setContent { NurTheme {
            StoryScreen(remember { DailyStories.of(20_000L) }, 0, 1, { seen.add(it) }, {})
        } }
        compose.mainClock.advanceTimeBy(30_000L)
        compose.runOnIdle { assertEquals(listOf(0), seen) }
        compose.onNodeWithText("Дальше").performScrollTo().performClick()
        compose.runOnIdle { assertEquals(listOf(0, 1), seen) }
    }
}
