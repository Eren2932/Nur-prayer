package com.nur.prayer.ui.daily

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nur.prayer.daily.DailyStore
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.DhikrTally
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.daily.Vird
import kotlinx.coroutines.Dispatchers
import com.nur.prayer.daily.AzkarBook
import com.nur.prayer.learn.LearnContent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

internal enum class DailyLoad { LOADING, READY, FAILED }

internal sealed interface BookState {
    object Idle : BookState
    object Loading : BookState
    object Failed : BookState
    class Ready(val book: AzkarBook) : BookState
}

/** The initial preference read is off main. SharedPreferences.apply then updates the in-memory
 * snapshot in tap order, before returning, and lets Android schedule the small disk writes. */
class DailyViewModel(application: Application) : AndroidViewModel(application) {
    private val store = DailyStore(application)

    private val _dhikrToday = MutableStateFlow<Map<String, Long>>(emptyMap())
    val dhikrToday: StateFlow<Map<String, Long>> = _dhikrToday.asStateFlow()
    private val _dhikrTotal = MutableStateFlow<Map<String, Long>>(emptyMap())
    val dhikrTotal: StateFlow<Map<String, Long>> = _dhikrTotal.asStateFlow()
    private val _selected = MutableStateFlow(Dhikr.PRESETS.first().id)
    val selected: StateFlow<String> = _selected.asStateFlow()
    private val _azkar = MutableStateFlow<Map<String, Map<String, Long>>>(emptyMap())
    val azkar: StateFlow<Map<String, Map<String, Long>>> = _azkar.asStateFlow()
    /** Slides seen today, one bit per slide (see [StoryMath]). */
    private val _storyMask = MutableStateFlow(0)
    val storyMask: StateFlow<Int> = _storyMask.asStateFlow()
    /** The daily vird, in preset order (see [Vird]). */
    private val _vird = MutableStateFlow(Vird.DEFAULT)
    val vird: StateFlow<List<String>> = _vird.asStateFlow()
    private val _translit = MutableStateFlow(true)
    val translit: StateFlow<Boolean> = _translit.asStateFlow()

    /** Which slide the story viewer opens on. */
    var storyStart: Int = 0
        private set
    /** Bumped on every opening, so the viewer starts fresh instead of restoring the last slide. */
    var storyOpening: Int = 0
        private set

    private var dhikrDay = today()
    private var storyDay = dhikrDay
    private val _loadState = MutableStateFlow(DailyLoad.LOADING)
    internal val loadState = _loadState.asStateFlow()
    private var pendingVird: (() -> Unit)? = null
    private val _book = MutableStateFlow<BookState>(BookState.Idle)
    internal val book = _book.asStateFlow()

    internal fun loadBook() {
        if (_book.value != BookState.Idle && _book.value != BookState.Failed) return
        _book.value = BookState.Loading
        viewModelScope.launch {
            _book.value = withContext(Dispatchers.IO) {
                try {
                    val text = getApplication<Application>().assets.open(LearnContent.QURAN_ASSET)
                        .bufferedReader().use { it.readText() }
                    BookState.Ready(AzkarBook.parse(text))
                } catch (_: java.io.IOException) { BookState.Failed }
                  catch (_: IllegalArgumentException) { BookState.Failed }
            }
        }
    }

    internal fun azkarPlace(session: String) = store.azkarPlace(session)
    internal fun setAzkarPlace(session: String, id: String?) = store.saveAzkarPlace(session, id)

    private data class Saved(val day: Long, val todayCounts: Map<String, Long>, val totals: Map<String, Long>,
        val selected: String?, val sessions: Map<String, Map<String, Long>>, val mask: Int,
        val vird: List<String>, val translit: Boolean)

    init {
        readSaved()
    }

    internal fun retryLoad() { if (_loadState.value == DailyLoad.FAILED) readSaved() }

    private fun readSaved() {
        _loadState.value = DailyLoad.LOADING
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) { runCatching {
                val d = today()
                Saved(d, store.dhikrToday(d), store.dhikrTotal(), store.selectedDhikr(), store.azkar(),
                    store.storySeenMask(d), store.vird(), store.showTranslit())
            } }.getOrElse { _loadState.value = DailyLoad.FAILED; return@launch }
            dhikrDay = saved.day
            storyDay = saved.day
            _dhikrToday.value = saved.todayCounts
            _dhikrTotal.value = saved.totals
            _azkar.value = saved.sessions
            _selected.value = Dhikr.preset(saved.selected).id
            _storyMask.value = saved.mask
            _vird.value = saved.vird
            _translit.value = saved.translit
            rollDay()
            _loadState.value = DailyLoad.READY
            pendingVird?.invoke()
            pendingVird = null
        }
    }

    fun refreshDay() { if (_loadState.value == DailyLoad.READY) rollDay() }

    fun today(): Long = LocalDate.now().toEpochDay()

    private fun rollDay() {
        val t = today()
        if (t != dhikrDay) { dhikrDay = t; _dhikrToday.value = emptyMap() }
        if (t != storyDay) { storyDay = t; _storyMask.value = 0 }
    }

    private fun updateTally(id: String, change: (DhikrTally) -> DhikrTally): Long {
        rollDay()
        val old = DhikrTally(_dhikrToday.value[id] ?: 0L, _dhikrTotal.value[id] ?: 0L)
        val next = change(old)
        if (next != old) {
            _dhikrToday.value = if (next.today == 0L) _dhikrToday.value - id else _dhikrToday.value + (id to next.today)
            _dhikrTotal.value = _dhikrTotal.value + (id to next.total)
            saveDhikr()
        }
        return next.today
    }

    fun dhikrTap(id: String): Long = updateTally(id, DhikrTally::tap)
    fun dhikrUndo(id: String): Long = updateTally(id, DhikrTally::undo)
    fun dhikrReset(id: String) { updateTally(id, DhikrTally::reset) }

    fun select(id: String) {
        _selected.value = id
        store.saveSelectedDhikr(id)
    }

    /** Stars [id] in or out of the vird. False when the vird is full and nothing changed. */
    fun toggleVird(id: String): Boolean {
        val next = Vird.toggle(_vird.value, id)
        if (next == _vird.value) return false
        _vird.value = next
        store.saveVird(next)
        return true
    }

    /**
     * Where «Зикр» on the today screen opens: the first dhikr of the vird still open today; with
     * the vird done (or empty), the dhikr that was open last time.
     */
    fun openVird(id: String? = null) {
        if (_loadState.value != DailyLoad.READY) { pendingVird = { openVird(id) }; return }
        rollDay()
        select(id ?: Vird.next(_vird.value, _dhikrToday.value) ?: _selected.value)
    }

    fun todayCount(id: String): Long {
        rollDay()
        return _dhikrToday.value[id] ?: 0L
    }

    private fun saveDhikr() {
        val day = dhikrDay
        val counts = _dhikrToday.value
        val totals = _dhikrTotal.value
        store.saveDhikr(day, counts, totals)
    }

    /** One more repetition of azkar [id] in [session], capped at [max]. Returns the new count. */
    fun azkarTap(session: String, id: String, max: Int): Long {
        val cur = _azkar.value[session].orEmpty()
        val n = ((cur[id] ?: 0L).coerceIn(0L, max.toLong()) + 1).coerceAtMost(max.toLong())
        val next = LinkedHashMap(_azkar.value)
        next.remove(session)
        next[session] = cur + (id to n)
        _azkar.value = next
        store.saveAzkar(next)
        return n
    }

    fun azkarReset(session: String) {
        val next = LinkedHashMap(_azkar.value)
        next.remove(session)
        _azkar.value = next
        store.saveAzkar(next)
    }

    fun openStory(start: Int) {
        storyStart = start.coerceAtLeast(0)
        storyOpening++
    }

    fun markStorySeen(index: Int) {
        rollDay()
        val mask = StoryMath.withSeen(_storyMask.value, index)
        if (mask == _storyMask.value) return
        _storyMask.value = mask
        val day = storyDay
        store.saveStorySeen(day, mask)
    }

    fun setTranslit(v: Boolean) {
        _translit.value = v
        store.saveShowTranslit(v)
    }
}
