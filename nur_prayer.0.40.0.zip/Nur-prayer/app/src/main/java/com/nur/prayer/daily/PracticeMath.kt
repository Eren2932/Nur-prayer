package com.nur.prayer.daily

/** Keep totals as Long, only the bounded position inside a round is converted to Int. */
internal object PracticeMath {
    fun inRound(count: Long, target: Int): Int {
        require(target > 0)
        return if (count <= 0L) 0 else ((count - 1L) % target).toInt() + 1
    }

    fun placeFor(session: String, stored: String?): String? = stored
        ?.takeIf { it.startsWith("$session|") }?.substringAfter('|')?.takeIf { it.isNotBlank() }

    fun readerIndex(items: List<Zikr>, counts: Map<String, Long>, chosen: String?): Int {
        val manual = items.indexOfFirst { it.id == chosen }
        if (manual >= 0) return manual
        // Records from 0.39.1 have counts but no cursor. Resume a partly read text before a fresh one.
        val partial = items.indexOfFirst { (counts[it.id] ?: 0L) in 1L until it.count.toLong() }
        return if (partial >= 0) partial else items.indexOfFirst { (counts[it.id] ?: 0L) < it.count }
    }

    fun nextUnread(items: List<Zikr>, counts: Map<String, Long>, after: Int): Zikr? {
        for (offset in 1..items.size) {
            val z = items[(after + offset) % items.size]
            if ((counts[z.id] ?: 0L) < z.count) return z
        }
        return null
    }
}

/** One preset, two independent counters. Reset is not undo: it retains the all-time count. */
internal data class DhikrTally(val today: Long, val total: Long) {
    fun tap(): DhikrTally = if (today == Long.MAX_VALUE || total == Long.MAX_VALUE) this
        else DhikrTally(today + 1, total + 1)
    fun undo(): DhikrTally = if (today == 0L) this else DhikrTally(today - 1, (total - 1).coerceAtLeast(0))
    fun reset(): DhikrTally = copy(today = 0L)
}
