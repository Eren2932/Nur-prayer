package com.nur.prayer.ui.daily

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.uiScale

/** Opaque surfaces: contrast does not depend on the user's wallpaper or prayer phase. */
internal object Folio {
    val page = Color(0xFF101816)
    val leaf = Color(0xFF213A32)
    val ink = Color(0xFFF4F0E5)
    val muted = Color(0xFFBCCAC1)
    val accent = Color(0xFFE4C598)
    val rule = Color(0xFF4B6056)
}

@Composable
internal fun FolioPage(scrollKey: Any, content: @Composable ColumnScope.() -> Unit) {
    key(scrollKey) {
        Column(Modifier.fillMaxSize().background(Folio.page)
            .padding(top = LocalIslandInset.current).verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp).padding(top = 14.dp, bottom = LocalDockInset.current + 16.dp), content = content)
    }
}

@Composable
internal fun FolioTitle(title: String, size: Float = 28f) {
    val ui = uiScale()
    Text(title, Modifier.semantics { heading() }, color = Folio.ink, fontSize = ui.t(size),
        lineHeight = ui.t(size * 1.2f), fontWeight = FontWeight.Bold)
}

@Composable
internal fun FolioText(text: String, size: Float = 15f, color: Color = Folio.muted) {
    val ui = uiScale()
    Text(text, color = color, fontSize = ui.t(size), lineHeight = ui.t(size * 1.42f))
}

@Composable
internal fun FolioRule() { Spacer(Modifier.fillMaxWidth().height(1.dp).background(Folio.rule)) }

@Composable
internal fun FolioMeter(fraction: Float) {
    val shape = RoundedCornerShape(50)
    Box(Modifier.fillMaxWidth().height(4.dp).clip(shape).background(Folio.rule)) {
        Spacer(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).height(4.dp).clip(shape).background(Folio.accent))
    }
}

@Composable
internal fun FolioEntry(title: String, detail: String, onClick: () -> Unit, prefix: String? = null, selected: Boolean = false, status: String? = null) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().pressClick(shape = RoundedCornerShape(8.dp), onClick = onClick)
        .semantics { if (status != null) stateDescription = status }.heightIn(min = 56.dp).padding(horizontal = 4.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (prefix != null) FolioText(prefix, 13f, Folio.accent)
        Column(Modifier.weight(1f)) {
            Text(title, color = Folio.ink, fontWeight = FontWeight.SemiBold, fontSize = ui.t(17f), lineHeight = ui.t(22f))
            if (detail.isNotBlank()) FolioText(detail, 13f)
        }
        Glyph(if (selected) GlyphKind.SEAL else GlyphKind.CHEVRON, if (selected) Folio.accent else Folio.muted, Modifier.size(16.dp))
    }
    FolioRule()
}

@Composable
internal fun ConfirmPracticeReset(title: String, explanation: String, cancel: () -> Unit, confirm: () -> Unit) {
    AlertDialog(onDismissRequest = cancel, containerColor = Folio.page,
        title = { FolioTitle(title, 21f) }, text = { FolioText(explanation) },
        confirmButton = { TextButton(onClick = confirm) { Text(tr("Сбросить"), color = Folio.accent) } },
        dismissButton = { TextButton(onClick = cancel) { Text(tr("Отмена"), color = Folio.ink) } })
}

@Composable
internal fun PracticeLoading(failed: Boolean, retry: () -> Unit, failureText: String = tr("Не удалось прочитать сохранённые отметки.")) {
    FolioPage("loading") {
        FolioText(if (failed) failureText else tr("Загружаем…"))
        if (failed) com.nur.prayer.ui.components.NurButton(tr("Повторить"), Folio.accent, retry)
    }
}
