package com.nur.prayer.ui.today

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.DailyStories
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.daily.Vird
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.KhatmPlan
import com.nur.prayer.quran.QuranMark
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.daily.Folio
import com.nur.prayer.ui.daily.FolioEntry
import com.nur.prayer.ui.daily.FolioText
import com.nur.prayer.ui.daily.FolioTitle
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.daily.FolioMeter
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.LocalIslandInset

internal data class TodayState(val hijri: String, val today: Long, val azkarSet: AzkarSet,
    val azkarStarted: Boolean, val azkarDone: Int, val azkarTotal: Int, val azkarFailed: Boolean, val vird: List<String>, val dhikrToday: Map<String, Long>,
    val storyMask: Int, val quranMark: QuranMark?, val quranKhatm: KhatmPlan?)

internal class TodayActions(val close: () -> Unit, val story: (Int) -> Unit, val quran: () -> Unit,
    val azkar: () -> Unit, val dhikr: () -> Unit, val schedule: () -> Unit, val qibla: () -> Unit)

@Composable
internal fun TodayScreen(state: TodayState, reveal: Reveal, on: TodayActions) {
    val pull = rememberDraggableState { delta -> reveal.drag(-delta) }
    Column(Modifier.fillMaxSize().background(Folio.page).onSizeChanged { reveal.extentPx = it.height.toFloat() }
        .padding(top = LocalIslandInset.current)) {
        Box(Modifier.fillMaxWidth().height(32.dp).draggable(state = pull, orientation = Orientation.Vertical,
            onDragStarted = { reveal.grab() }, onDragStopped = { velocity ->
                if (reveal.release(-velocity, RevealMath.SHEET_KEEP_AT)) reveal.settle(true) else on.close()
            }), contentAlignment = Alignment.Center) {
            Box(Modifier.width(36.dp).height(4.dp).clip(RoundedCornerShape(50)).background(Folio.rule))
        }
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)
            .padding(bottom = LocalDockInset.current + 20.dp)) {
            FolioText(state.hijri, 14f, Folio.accent)
            FolioTitle(tr("Дела дня"), 34f)
            Gap(16f)
            Column(Modifier.fillMaxWidth().pressClick(shape = RoundedCornerShape(16.dp), onClick = on.azkar)
                .background(Folio.leaf).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { FolioText(tr("Сейчас"), 13f, Folio.accent) }
                    Glyph(if (state.azkarSet == AzkarSet.MORNING) GlyphKind.SUN else GlyphKind.MOON, Folio.accent, Modifier.size(23.dp))
                }
                Gap(10f)
                FolioTitle(tr(state.azkarSet.title), 25f)
                Gap(12f)
                FolioMeter(state.azkarDone.toFloat() / state.azkarTotal.coerceAtLeast(1))
                Gap(6f)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        FolioText(if (state.azkarFailed) tr("Не удалось загрузить азкары.")
                            else if (state.azkarTotal == 0) tr("Загружаем…")
                            else tr("Прочитано: {0} из {1}", state.azkarDone, state.azkarTotal), 14f, Folio.ink)
                    }
                    if (state.azkarTotal > 0) {
                        FolioText(when {
                            state.azkarDone == state.azkarTotal -> tr("Открыть")
                            state.azkarStarted -> tr("Продолжить")
                            else -> tr("Начать")
                        }, 14f, Folio.accent)
                        Glyph(GlyphKind.CHEVRON, Folio.accent, Modifier.size(16.dp))
                    }
                }
            }
            Gap(6f)
            val mark = state.quranMark
            val plan = state.quranKhatm
            FolioEntry(tr("Коран"), when {
                plan == null && mark != null -> tr("{0} · аят {1}", QuranMath.title(QuranMath.surah(mark.surah), L10n.language.code), mark.ayah)
                plan == null -> tr("Аль-Фатиха и все 114 сур")
                plan.finished -> tr("хатм завершён")
                plan.doneToday(state.today) -> tr("норма дня выполнена")
                else -> tr("сегодня {0} из {1} стр.", plan.readToday(state.today), plan.goalToday(state.today))
            }, on.quran)
            FolioEntry(tr("Зикр"), when {
                state.vird.isEmpty() -> tr("сегодня {0}", state.dhikrToday.values.sum())
                Vird.allDone(state.vird, state.dhikrToday) -> tr("Вирд дня выполнен")
                else -> tr("вирд дня · {0} из {1}", Vird.doneCount(state.vird, state.dhikrToday), state.vird.size)
            }, on.dhikr)
            Gap(24f)
            FolioTitle(tr("Чтение дня"), 21f)
            Gap(6f)
            val readings = remember(state.today) { DailyStories.of(state.today) }
            readings.forEachIndexed { i, reading ->
                FolioEntry(tr(reading.kind), reading.source, { on.story(i) }, prefix = (i + 1).toString().padStart(2, '0'),
                    selected = StoryMath.isSeen(state.storyMask, i),
                    status = if (StoryMath.isSeen(state.storyMask, i)) tr("Прочитано") else null)
            }
            Gap(20f)
            FolioTitle(tr("Ещё"), 19f)
            FolioEntry(tr("Кибла"), tr("направление на Каабу"), on.qibla)
            FolioEntry(tr("Календарь намазов"), tr("месяц, время, хиджра"), on.schedule)
        }
    }
}
