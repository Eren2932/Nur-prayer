package com.nur.prayer.ui.daily

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.PracticeMath
import com.nur.prayer.daily.StorySlide
import com.nur.prayer.daily.TasbihMath
import com.nur.prayer.daily.Vird
import com.nur.prayer.daily.AzkarBook
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.uiScale

/** Retained for the course dictionary chips, which follow the prayer palette. */
@Composable
internal fun chipBg(selected: Boolean, accent: Color): Color {
    val c by animateColorAsState(if (selected) accent.copy(alpha = 0.35f) else SurfaceRaised, tween(180), label = "chip")
    return c
}

@Composable
internal fun AzkarScreen(vm: DailyViewModel, book: AzkarBook, currentSet: AzkarSet,
    sessionOf: (AzkarSet) -> String) {
    var set by rememberSaveable(currentSet) { mutableStateOf(currentSet) }
    val session = sessionOf(set)
    val sessions by vm.azkar.collectAsStateWithLifecycle()
    val translit by vm.translit.collectAsStateWithLifecycle()
    val list = book[set]
    val counts = sessions[session].orEmpty()
    val done = list.count { (counts[it.id] ?: 0L) >= it.count }
    val feedback = LocalHapticFeedback.current
    key(session) {
        var chosen by rememberSaveable { mutableStateOf(vm.azkarPlace(session)) }
        fun show(id: String?) { chosen = id; vm.setAzkarPlace(session, id) }
        var contents by rememberSaveable { mutableStateOf(false) }
        var confirm by remember { mutableStateOf(false) }
        val index = PracticeMath.readerIndex(list, counts, chosen)
        val z = list.getOrNull(index)
        BackHandler(contents) { contents = false }
        FolioPage(if (contents) "contents" else z?.id ?: "end") {
            FolioTitle(tr("Азкары"))
            Gap(10f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AzkarSet.values().forEach { s ->
                    NurButton(tr(s.short), Folio.accent, { set = s }, Modifier.weight(1f), primary = set == s)
                }
            }
            Gap(14f)
            FolioText(tr("Прочитано: {0} из {1}", done, list.size), 14f, Folio.accent)
            Gap(6f)
            FolioMeter(done.toFloat() / list.size.coerceAtLeast(1))
            Gap(8f)
            if (contents) {
                FolioEntry(tr("К чтению"), "", { contents = false })
                list.forEachIndexed { i, entry ->
                    val n = counts[entry.id] ?: 0L
                    FolioEntry(entry.title, tr("{0} из {1}", n, entry.count), { show(entry.id); contents = false },
                        prefix = (i + 1).toString().padStart(2, '0'), selected = n >= entry.count)
                }
                if (counts.values.any { it > 0 }) {
                    Gap(14f)
                    NurButton(tr("Начать подборку заново"), Folio.accent, { confirm = true })
                }
            } else {
                FolioEntry(tr("Оглавление"), "", { contents = true })
                Gap(18f)
                if (z != null) {
                    val n = counts[z.id] ?: 0L
                    FolioText(tr("{0} из {1}", index + 1, list.size), 13f, Folio.accent)
                    FolioTitle(z.title, 23f)
                    Gap(16f)
                    ArabicText(z.arabic, 26f, Modifier.fillMaxWidth(), Folio.ink, TextAlign.Start)
                    Gap(14f)
                    NurButton(if (translit) tr("Скрыть транслит") else tr("Показать транслит"), Folio.accent, { vm.setTranslit(!translit) })
                    if (translit) { Gap(8f); FolioText(z.translit) }
                    Gap(14f)
                    FolioText(z.ru, 17f, Folio.ink)
                    z.virtue?.let { Gap(12f); FolioText(it) }
                    Gap(8f)
                    FolioText(z.source, 13f, Folio.accent)
                    Gap(20f)
                    if (n < z.count) {
                        if (z.count > 1) {
                            FolioText(tr("Повторы: {0} из {1}", n, z.count), 15f, Folio.accent)
                            Gap(8f)
                        }
                        NurButton(if (z.count == 1) tr("Прочитал") else tr("Добавить повтор"), Folio.accent, {
                            val value = vm.azkarTap(session, z.id, z.count)
                            if (value >= z.count) {
                                // Search AFTER the actual item, wrapping once if the reader skipped ahead.
                                show(PracticeMath.nextUnread(list, counts + (z.id to value), index)?.id)
                                feedback.performHapticFeedback(HapticFeedbackType.LongPress)
                            }
                        }, primary = true)
                    } else {
                        NurButton(tr("К оглавлению"), Folio.accent, { contents = true })
                    }
                } else if (list.isNotEmpty()) {
                    FolioTitle(tr("{0} прочитаны. Да примет Аллах.", tr(set.title)), 24f)
                } else FolioText(tr("Загружаем…"))
            }
        }
        if (confirm) ConfirmPracticeReset(tr("Начать подборку заново?"), tr("Сбросятся только отметки этой подборки."),
            { confirm = false }, { confirm = false; vm.azkarReset(session); show(null); contents = false })
    }
}

@Composable
internal fun DhikrScreen(vm: DailyViewModel) {
    val selected by vm.selected.collectAsStateWithLifecycle()
    val today by vm.dhikrToday.collectAsStateWithLifecycle()
    val total by vm.dhikrTotal.collectAsStateWithLifecycle()
    val vird by vm.vird.collectAsStateWithLifecycle()
    val p = Dhikr.preset(selected)
    val count = today[p.id] ?: 0L
    val within = PracticeMath.inRound(count, p.target)
    val closed = within == p.target
    val rounds = count / p.target
    val sequence = p.id == Dhikr.AFTER_PRAYER
    val (phase, phaseCount) = TasbihMath.phase(within)
    val next = if (p.id in vird && Vird.done(p.id, today)) Vird.next(vird, today, after = p.id) else null
    val haptic = LocalHapticFeedback.current
    val ui = uiScale()
    var choose by rememberSaveable { mutableStateOf(false) }
    var confirm by remember(p.id) { mutableStateOf(false) }
    BackHandler(choose) { choose = false }
    FolioPage(if (choose) "presets" else p.id) {
        FolioText(tr("Зикр"), 14f, Folio.accent)
        if (choose) {
            FolioTitle(tr("Выбрать зикр"))
            Gap(12f)
            val ordered = vird.map { Dhikr.preset(it) } + Dhikr.PRESETS.filter { it.id !in vird }
            ordered.forEach { d ->
                FolioEntry(tr(d.title), (if (d.id in vird) tr("В вирде дня") + " · " else "") + tr("сегодня {0}", today[d.id] ?: 0L),
                    { vm.select(d.id); choose = false }, selected = d.id == p.id, status = if (d.id == p.id) tr("Выбрано") else null)
            }
        } else {
            FolioTitle(tr(p.title))
            FolioEntry(tr("Выбрать зикр"), "", { choose = true })
            Gap(18f)
            ArabicText(if (sequence) TasbihMath.arabic(phase) else p.arabic, 32f, Modifier.fillMaxWidth(), Folio.ink)
            Gap(6f)
            FolioText(if (sequence) TasbihMath.reading(phase) else p.translit, 16f)
            if (!sequence) FolioText(p.ru, 14f)
            Gap(16f)
            val spoken = if (sequence) phaseCount else within
            val stepTarget = if (sequence) TasbihMath.size(phase) else p.target
            val counterLabel = tr("{0} из {1}", spoken, stepTarget)
            Column(Modifier.fillMaxWidth().pressClick(haptic = false, shape = RoundedCornerShape(16.dp)) {
                val n = vm.dhikrTap(p.id)
                val position = PracticeMath.inRound(n, p.target)
                val boundary = if (sequence) TasbihMath.phaseEnd(position) else position == p.target
                haptic.performHapticFeedback(if (boundary) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove)
            }.semantics { stateDescription = counterLabel }.background(Folio.leaf).heightIn(min = 152.dp).padding(18.dp),
                verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                FolioText(if (closed) tr("круг {0} завершён", rounds) else if (sequence) tr("{0} из {1}", phase + 1, 3) else tr("Зикр"), 13f, Folio.accent)
                Text("$spoken", color = Folio.ink, fontSize = ui.t(52f), fontWeight = FontWeight.Bold)
                FolioText(if (closed) tr("Нажмите, чтобы начать новый круг") else tr("Добавить повтор") + " · " + tr("из {0}", stepTarget), 14f, Folio.ink)
                Gap(10f)
                FolioMeter(within / p.target.toFloat())
            }
            Gap(8f)
            NurButton(tr("Отменить одно нажатие"), Folio.accent, { vm.dhikrUndo(p.id) }, enabled = count > 0)
            Gap(14f)
            FolioText(tr("Сегодня: {0} · За всё время: {1}", count, total[p.id] ?: 0L))
            if (next != null) FolioEntry(tr("Дальше: {0}", tr(Dhikr.preset(next).title)), tr("В вирде дня"), { vm.select(next) })
            else if (p.id in vird && Vird.allDone(vird, today)) FolioText(tr("Вирд дня выполнен"), 14f, Folio.accent)
            Gap(12f)
            FolioRule()
            val full = p.id !in vird && Vird.isFull(vird)
            Gap(12f)
            NurButton(if (p.id in vird) tr("Убрать из вирда дня") else tr("Добавить в вирд дня"), Folio.accent,
                { vm.toggleVird(p.id) }, enabled = !full)
            if (full) FolioText(tr("В вирде уже {0} зикра — уберите один, чтобы добавить", Vird.MAX), 13f)
            Gap(14f)
            FolioText(p.virtue)
            FolioText(p.source, 13f, Folio.accent)
            if (count > 0) {
                Gap(16f)
                NurButton(tr("Сбросить счёт за сегодня"), Folio.accent, { confirm = true })
            }
        }
    }
    if (confirm) ConfirmPracticeReset(tr("Сбросить счёт за сегодня"), tr("Общий счёт останется прежним."),
        { confirm = false }, { confirm = false; vm.dhikrReset(p.id) })
}

/** A reading stays put until the reader turns the page. No timer or gesture overlay. */
@Composable
internal fun StoryScreen(slides: List<StorySlide>, start: Int, opening: Int, onSeen: (Int) -> Unit, onClose: () -> Unit) {
    if (slides.isEmpty()) return
    var index by rememberSaveable(opening) { mutableIntStateOf(start.coerceIn(0, slides.lastIndex)) }
    val i = index.coerceIn(0, slides.lastIndex)
    val s = slides[i]
    LaunchedEffect(s, opening) { onSeen(i) }
    FolioPage(i) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { FolioText(tr("Чтение дня"), 14f, Folio.accent) }
            com.nur.prayer.ui.components.RoundIconButton(com.nur.prayer.ui.components.GlyphKind.CLOSE, tr("Закрыть"), onClose)
        }
        Gap(10f)
        FolioText(tr("{0} из {1}", i + 1, slides.size), 14f)
        FolioTitle(tr(s.kind), 30f)
        Gap(14f)
        FolioRule()
        Gap(20f)
        s.arabic?.let { ArabicText(it, 30f, Modifier.fillMaxWidth(), Folio.ink, TextAlign.Start); Gap(16f) }
        s.translit?.let { FolioText(it); Gap(12f) }
        FolioText(s.ru, 20f, Folio.ink)
        Gap(10f)
        FolioText(s.source, 14f, Folio.accent)
        s.note?.let { Gap(18f); FolioText(it) }
        Gap(24f)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (i > 0) NurButton(tr("Назад"), Folio.accent, { index = i - 1 }, Modifier.weight(1f))
            NurButton(if (i == slides.lastIndex) tr("Закрыть") else tr("Дальше"), Folio.accent,
                { if (i == slides.lastIndex) onClose() else index = i + 1 }, Modifier.weight(1f), primary = true)
        }
    }
}
