package com.nur.prayer.daily

import com.nur.prayer.learn.QuranShort

/** Both practice windows use the bundled Quran text, never course/profile initialisation.
 * A missing or incomplete surah is a load error, not a silently shortened daily target. */
internal class AzkarBook private constructor(private val sets: Map<AzkarSet, List<Zikr>>) {
    operator fun get(set: AzkarSet): List<Zikr> = sets.getValue(set)

    companion object {
        fun parse(text: String): AzkarBook {
            val quran = QuranShort.parse(text)
            for (number in Azkar.ALL.mapNotNull { it.surah }.distinct()) {
                val expected = QuranShort.SURAHS.first { it.number == number }.ayatCount
                val verses = quran.ayat(number)
                require(verses.map { it.number } == (1..expected).toList())
                require(verses.all { it.arabic.isNotBlank() && it.ru.isNotBlank() && it.translit.isNotBlank() })
            }
            return AzkarBook(AzkarSet.values().associateWith { Azkar.of(it, quran) })
        }
    }
}
