package com.nur.prayer

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.daily.AzkarBook
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.DhikrTally
import com.nur.prayer.daily.PracticeMath
import com.nur.prayer.daily.TasbihMath
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.time.LocalDate
import java.time.ZoneId

class PracticeFlowTest {
    private val raw by lazy { listOf(File("src/main/assets/learn/quran_short.tsv"),
        File("app/src/main/assets/learn/quran_short.tsv")).first { it.isFile }.readText() }
    private val morning by lazy { AzkarBook.parse(raw)[AzkarSet.MORNING] }
    private val date = LocalDate.of(2026, 11, 21)
    private val zone = ZoneId.of("Europe/Moscow")
    private fun session(set: AzkarSet, prayer: Prayer, hour: Int, startDay: LocalDate = date) =
        AzkarSet.sessionFor(set, prayer, startDay.atTime(hour, 0).atZone(zone), date, date.atTime(14, 0).atZone(zone))

    @Test fun completeBookLoadsWithoutACourse() {
        val book = AzkarBook.parse(raw)
        for (s in AzkarSet.values()) {
            val list = book[s]
            assertEquals(17, list.size)
            assertEquals(17, list.distinctBy { it.id }.size)
            assertTrue(list.all { it.arabic.isNotBlank() && it.count > 0 })
        }
        assertNotEquals(book[AzkarSet.MORNING].first { it.id == "asbahna" }.arabic,
            book[AzkarSet.EVENING].first { it.id == "asbahna" }.arabic)
    }
    @Test(expected = IllegalArgumentException::class) fun incompleteSurahIsNotReleasedAsACompleteSet() {
        AzkarBook.parse(raw.lines().filterNot { it.startsWith("112\t4\t") }.joinToString("\n"))
    }
    @Test fun partialFromPreviousVersionBeatsUntouchedText() {
        val counts = mapOf("ikhlas" to 2L)
        assertEquals("ikhlas", morning[PracticeMath.readerIndex(morning, counts, null)].id)
        assertEquals("ikhlas", morning[PracticeMath.readerIndex(morning, counts, "unknown")].id)
    }
    @Test fun manualCursorSurvivesOnlyItsOwnSession() {
        val stored = "E:2026-11-20|nas"
        assertEquals("nas", PracticeMath.placeFor("E:2026-11-20", stored))
        assertNull(PracticeMath.placeFor("M:2026-11-20", stored))
        assertNull(PracticeMath.placeFor("E:2026-11-21", stored))
        assertNull(PracticeMath.placeFor("E:2026-11-20", "damaged"))
        assertEquals("nas", morning[PracticeMath.readerIndex(morning, mapOf("ikhlas" to 1L), "nas")].id)
    }
    @Test fun lastPageWrapsToUnreadAndCompleteBookHasNoPhantomPage() {
        val done = morning.associate { it.id to it.count.toLong() }
        assertEquals(morning.first(), PracticeMath.nextUnread(morning, done - morning.first().id, morning.lastIndex))
        assertNull(PracticeMath.nextUnread(morning, done, morning.lastIndex))
        assertEquals(-1, PracticeMath.readerIndex(morning, done, null))
        assertEquals(2, PracticeMath.readerIndex(morning, done, morning[2].id))
    }
    @Test fun midnightDoesNotStartANewEvening() {
        assertEquals("E:2026-11-20", session(AzkarSet.EVENING, Prayer.ISHA, 19, date.minusDays(1)))
        assertEquals("E:2026-11-20", session(AzkarSet.EVENING, Prayer.ISHA, 1))
        assertEquals("M:2026-11-21", session(AzkarSet.MORNING, Prayer.ISHA, 1))
    }
    @Test fun dawnAndAsrUseTheNewLocalDay() {
        assertEquals("M:2026-11-21", session(AzkarSet.MORNING, Prayer.SAHAR, 5))
        assertEquals("E:2026-11-21", session(AzkarSet.EVENING, Prayer.SAHAR, 5))
        assertEquals("E:2026-11-21", session(AzkarSet.EVENING, Prayer.ASR, 14))
    }
    @Test fun tapAndUndoAcrossAllTasbihBoundaries() {
        fun phase(n: Long) = TasbihMath.phase(PracticeMath.inRound(n, 100))
        listOf(32L to (0 to 32), 33L to (1 to 0), 34L to (1 to 1), 65L to (1 to 32),
            66L to (2 to 0), 67L to (2 to 1), 99L to (2 to 33), 100L to (2 to 34),
            101L to (0 to 1)).forEach { (n, expected) -> assertEquals(expected, phase(n)) }
        assertEquals(1 to 32, phase(66L - 1))
        assertEquals(2 to 34, phase(101L - 1))
    }
    @Test fun undoAndResetHaveDifferentLifetimeEffects() {
        val before = DhikrTally(33, 140)
        assertEquals(before, before.tap().undo())
        assertEquals(DhikrTally(32, 139), before.undo())
        assertEquals(DhikrTally(0, 140), before.reset())
        assertEquals(before.reset(), before.reset().undo())
        assertEquals(DhikrTally(1, 141), before.reset().tap())
    }
    @Test fun counterRejectsOverflowWithoutTurningNegative() {
        val full = DhikrTally(150, Long.MAX_VALUE)
        assertEquals(full, full.tap())
        assertEquals(full, full.undo().tap())
    }
    @Test fun longCountsDoNotWrapAtIntMax() {
        for (target in listOf(10, 33, 100)) {
            assertEquals(0, PracticeMath.inRound(0L, target))
            assertEquals(target, PracticeMath.inRound(target.toLong(), target))
            assertEquals(1, PracticeMath.inRound(target + 1L, target))
            assertEquals(((Long.MAX_VALUE - 1) % target + 1).toInt(), PracticeMath.inRound(Long.MAX_VALUE, target))
        }
    }
}
