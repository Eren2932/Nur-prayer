package com.nur.prayer.ui.welcome

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.R
import com.nur.prayer.i18n.AppLanguage
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.rememberAmbientMotionAllowed

@Composable
internal fun WelcomeGreeting(width: Dp) {
    val title = tr("Ассаламу алейкум")
    val running = rememberAmbientMotionAllowed()
    val phase = if (running) rememberInfiniteTransition(label = "silver").animateFloat(
        initialValue = 0f, targetValue = 1f, animationSpec = infiniteRepeatable(tween(7400, easing = LinearEasing)), label = "silverPass"
    ) else null
    val polish = if (phase == null) Modifier else Modifier.graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithCache {
            // Local band on a transparent layer: SrcAtop can change ink, never sky or the counters of letters.
            val band = size.width * .34f
            val silver = Brush.linearGradient(0f to Color.Transparent, .26f to Color.White.copy(alpha = .12f),
                .52f to Color.White.copy(alpha = .66f), .78f to Color.White.copy(alpha = .12f), 1f to Color.Transparent,
                start = Offset.Zero, end = Offset(band, band * .22f))
            onDrawWithContent {
                drawContent()
                val t = (phase.value / .86f).coerceAtMost(1f)
                translate(left = -band * 1.5f + (size.width + band * 1.6f) * t) {
                    drawRect(silver, size = Size(band * 1.4f, size.height), blendMode = BlendMode.SrcAtop)
                }
            }
        }
    if (L10n.language == AppLanguage.RU) Image(painterResource(R.drawable.welcome_lettering), title,
        Modifier.width(width).aspectRatio(405f / 196f).then(polish))
    else Text(title, modifier = polish, color = Color(0xFFE1E6EF), fontFamily = FontFamily.Cursive,
        fontSize = (width.value * .24f).sp, lineHeight = (width.value * .26f).sp, fontStyle = FontStyle.Italic)
}
