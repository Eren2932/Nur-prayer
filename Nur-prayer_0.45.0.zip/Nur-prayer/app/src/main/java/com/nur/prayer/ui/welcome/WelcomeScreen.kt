package com.nur.prayer.ui.welcome

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.R
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.City
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.location.LocationRequestStep
import com.nur.prayer.ui.components.pageContentInsets
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.theme.paletteFor

@Composable
internal fun WelcomeFlow(busy: Boolean, status: String?, step: LocationRequestStep,
                         search: suspend (String) -> List<City>, onLocate: () -> Unit, onPick: (City) -> Unit) {
    var manual by rememberSaveable { mutableStateOf(false) }
    BackHandler(enabled = manual) { manual = false }
    CompositionLocalProvider(LocalLayoutDirection provides if (L10n.language.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Box(Modifier.fillMaxSize().background(Color(0xFF031128))) {
            Image(painterResource(R.drawable.welcome_night), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            if (manual) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .52f)).pageContentInsets()) {
                    CityPickerScreen(paletteFor(Prayer.ISHA), -1, search, onPick = { city -> if (!busy) onPick(city) },
                        onBack = { manual = false }, onUseLocation = {}, locating = false,
                        locationStatus = status, manualOnly = true)
                    if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center).size(36.dp), color = Color.White)
                }
            } else WelcomePage(busy, status, step, onLocate) { manual = true }
        }
    }
}

@Composable
private fun WelcomePage(busy: Boolean, status: String?, step: LocationRequestStep, onLocate: () -> Unit, onManual: () -> Unit) {
    // Background fills the actual window. Insets are floors, not additions to the design margins.
    val safe = WindowInsets.safeDrawing.asPaddingValues()
    BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal)),
        contentAlignment = Alignment.TopCenter) {
        val h = maxHeight
        val w = minOf(maxWidth, 500.dp)
        val compact = h < 420.dp
        val head = maxOf(safe.calculateTopPadding() + 6.dp, if (compact) 18.dp else h * (331f / 1821f))
        val foot = maxOf(safe.calculateBottomPadding(), h * .018f)
        val side = w / 9f
        // With a short landscape window or enlarged text the same column can scroll, never overlap.
        Column(Modifier.width(w).fillMaxHeight().verticalScroll(rememberScrollState()).heightIn(min = h)) {
            Spacer(Modifier.height(head))
            Column(Modifier.padding(start = side, end = w * .055f)) {
                WelcomeGreeting(if (compact) minOf(w * .469f, 136.dp) else w * .469f)
                Spacer(Modifier.height(if (compact) 6.dp else w * .021f))
                val type = (w.value * .047f).coerceIn(16f, 23f)
                Text(tr("Настроим время намаза\nи кыблу для вашего города"), color = Color(0xFFF4F6FB),
                    fontSize = type.sp, lineHeight = (type * 1.22f).sp, fontWeight = FontWeight.Light, letterSpacing = 0.sp)
            }
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.height(12.dp))
            if (!busy && status != null) Text(status,
                Modifier.align(Alignment.CenterHorizontally).padding(horizontal = 20.dp, vertical = 8.dp)
                    .background(Color(0xE6102038), RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 9.dp)
                    .semantics { liveRegion = LiveRegionMode.Polite },
                color = Color.White, fontSize = 14.sp, lineHeight = 18.sp, textAlign = TextAlign.Center)
            val label = when {
                status == null -> tr("Определить")
                step == LocationRequestStep.REQUEST_PERMISSION -> tr("Разрешить")
                step == LocationRequestStep.OPEN_APP_SETTINGS -> tr("Настройки")
                step == LocationRequestStep.OPEN_LOCATION_SETTINGS -> tr("Включить")
                else -> tr("Повторить")
            }
            val diameter = (w * (99f / 864f)).coerceIn(48.dp, 58.dp)
            val capsuleWidth by animateDpAsState(if (busy) diameter else w * (598f / 864f), tween(260), label = "placeCapsule")
            val ring = Color(0xFFE9EFF9)
            Box(Modifier.align(Alignment.CenterHorizontally).size(capsuleWidth, diameter)
                .clip(CircleShape).border((w / 412f).coerceIn(1.dp, 1.3.dp), if (busy) ring.copy(alpha = .28f) else ring, CircleShape)
                .then(if (busy) Modifier else Modifier.clickable(role = Role.Button, onClick = onLocate))
                .testTag("welcome-detect"), contentAlignment = Alignment.Center) {
                if (busy) {
                    val waiting = tr("Определяем…")
                    CircularProgressIndicator(Modifier.size(diameter - 4.dp).semantics { contentDescription = waiting },
                        color = ring, strokeWidth = 2.dp)
                } else Row(horizontalArrangement = Arrangement.spacedBy(w * .036f), verticalAlignment = Alignment.CenterVertically) {
                    LocateArrow((w * .049f).coerceIn(18.dp, 24.dp))
                    Text(label, color = Color.White, fontSize = (w.value * .045f).coerceIn(16f, 22f).sp,
                        fontWeight = FontWeight.Medium, letterSpacing = 0.sp, maxLines = 1)
                }
            }
            Spacer(Modifier.height((h * .005f).coerceAtMost(6.dp)))
            // Reserve the space even when hidden: the capsule contracts about its original centre.
            Box(Modifier.align(Alignment.CenterHorizontally).height(48.dp), contentAlignment = Alignment.Center) {
                if (!busy) Box(Modifier.fillMaxHeight().clip(CircleShape).clickable(role = Role.Button, onClick = onManual)
                    .padding(horizontal = 18.dp).testTag("welcome-manual"), contentAlignment = Alignment.Center) {
                    Text(tr("Выбрать город"), color = Color(0xFFACB8CB), fontSize = (w.value * .04f).coerceIn(15f, 19f).sp,
                        fontWeight = FontWeight.Medium, letterSpacing = 0.sp)
                }
            }
            Spacer(Modifier.height(foot))
        }
    }
}

@Composable
private fun LocateArrow(edge: Dp) {
    Canvas(Modifier.size(edge)) {
        val s = size.minDimension
        val outline = Path().apply {
            moveTo(.10f * s, .48f * s); lineTo(.93f * s, .07f * s); lineTo(.56f * s, .93f * s)
            lineTo(.47f * s, .56f * s); close()
        }
        drawPath(outline, Color.White, style = Stroke(s * .08f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
