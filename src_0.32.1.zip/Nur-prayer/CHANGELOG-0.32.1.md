# 0.32.1 — исправление сборки 0.32.0

## Что было
CI 0.32.0 упал на компиляции Kotlin (`:app:compileReleaseKotlin`, `:app:compileDebugKotlin`):

```
HomeMath.kt: Function 'public' exposes its 'internal' return type 'BellState'.
```

`HomeMath.bellState` была публичной, а возвращала `internal`-тип `BellState`. Это единственная ошибка в логе.

## Что сделано
- `HomeMath.bellState` → `internal fun`: колокольчик нужен только внутри модуля (карточки и `HomeGlyphsTest`, он в том же модуле).
- Новая статическая проверка `tools/check_visibility.py` (+ `tools/test_check_visibility.py`): публичная
  функция/свойство/класс не должны выставлять `internal`-тип или `private`-тип файла в сигнатуре. Стоит в
  `package_source.py` и в CI рядом с `kt_symbols.py`. На 0.32.0 она нашла бы именно эту ошибку; на остальном дереве чистая.
- `tools/kt_symbols.py`: `IllegalArgumentException` / `IllegalStateException` в списке встроенных имён (с 0.32.0).
- Версия 0.32.1, versionCode 70. Ни иконки, ни шрифты, ни обои не менялись.

## Что НЕ проверено
Gradle, компиляция Kotlin и юнит-тесты по-прежнему не запускались здесь. В логе CI до компиляции тестов дело не дошло,
поэтому `HomeGlyphsTest` компилятор ещё не видел: я перечитал его построчно (сигнатуры JUnit, `when`, деструктуризация).
