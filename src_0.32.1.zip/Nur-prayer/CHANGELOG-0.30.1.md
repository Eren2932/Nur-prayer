# 0.30.1 — исправление сборки 0.30.0

## Что упало
Компиляция `app`: `HomeLayouts.kt:55` — `Unresolved reference 'constrainHeight'`. `Constraints.constrainHeight`
— функция-расширение, и для неё нужен свой `import androidx.compose.ui.unit.constrainHeight`. Импорта не было.
Это единственная ошибка в логе сборки: остальные файлы 0.30.0 компилятор принял.

## Исправлено
- `HomeLayouts.kt`: добавлен импорт `constrainHeight`.
- `HomeMathTest`: аргументы `until(...)` теперь явно `Long` (`121L`), чтобы не зависеть от вывода типа литералов.

## Новая проверка
- `tools/check_extension_imports.py` (входит в `package_source.py`): ищет вызовы известных функций-расширений
  Compose (`constrainWidth/Height`, `padding`, `offset`, `clip`, `clickable`, `semantics`, `layout` и др.) в файлах,
  где нет их импорта. Ни `kt_sanity`, ни `kt_symbols` этого не видели, поэтому 0.30.0 их прошёл. На 0.30.0 новая
  проверка падает ровно на этой строке, на исправленном исходнике — чистая.

## Не проверено
Gradle, Kotlin-компилятор, юнит-тесты, lint и устройство в песочнице недоступны. Шаги CI «модульные тесты, lint и
обе APK» в логе 0.30.0 не выполнялись (сборка остановилась раньше), поэтому `HomeMathTest` ещё ни разу не запускался.
