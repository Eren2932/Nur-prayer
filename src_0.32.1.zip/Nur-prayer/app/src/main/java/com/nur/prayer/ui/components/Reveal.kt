package com.nur.prayer.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue

/**
 * One number, 0 (hidden) … 1 (shown), that a layer's position follows: the prayer sheet, the
 * calendar pulled up from home. A finger and an animation drive the same value, so a gesture that
 * is released mid-way continues from exactly where it stopped, and an animation that is grabbed
 * mid-way stops where it is.
 *
 * Everything that moves is read in draw lambdas (`graphicsLayer { … progress … }`), so a frame
 * of a drag or of a settle animation re-draws a layer and never recomposes or re-measures a screen.
 */
@Stable
class Reveal(initiallyOpen: Boolean = false) {
    private val anim = Animatable(if (initiallyOpen) 1f else 0f)

    /** Finger travel not yet folded into [anim], in the same px units as [extentPx]. */
    private var finger by mutableFloatStateOf(0f)

    /** Px that one whole 0→1 takes; set from the layout that owns the gesture. */
    var extentPx by mutableFloatStateOf(0f)

    val progress: Float
        get() {
            val held = if (extentPx > 0f) finger / extentPx else 0f
            return (anim.value + held).coerceIn(0f, 1f)
        }

    /** [towardOpen] > 0 opens, < 0 closes; clamped so the layer never leaves its range. */
    fun drag(towardOpen: Float) {
        val extent = extentPx
        if (extent <= 0f) return
        val at = anim.value.coerceIn(0f, 1f)
        finger = (finger + towardOpen).coerceIn(-at * extent, (1f - at) * extent)
    }

    /** A finger lands on a moving layer: freeze it where it is. */
    suspend fun grab() {
        anim.stop()
        fold()
    }

    /**
     * The finger lifts. Returns whether the layer should end up open; the caller reacts (navigates,
     * dismisses) and then calls [settle], or lets a state change do it.
     */
    suspend fun release(velocityTowardOpen: Float, openAt: Float): Boolean {
        fold()
        return RevealMath.opens(anim.value, velocityTowardOpen / extentPx.coerceAtLeast(1f), openAt)
    }

    /** Animates from wherever the layer is to open or closed; no-op when it already is. */
    suspend fun settle(open: Boolean) {
        if (finger != 0f) fold()
        val from = anim.value
        val target = if (open) 1f else 0f
        if (from == target) return
        // 0.30.2: one decelerating curve both ways. Closing used to be FastOutLinearIn (a long wait, then a
        // dive): the sheet and its scrim hung on screen and then vanished at once, which read as a dark
        // flash and a jerk at the end. Now the layer leaves at once and settles softly, and the scrim,
        // which follows the same number, lifts with it.
        anim.animateTo(
            target,
            tween(if (open) RevealMath.openMillis(from) else RevealMath.closeMillis(from), easing = RevealMath.Settle)
        )
    }

    private suspend fun fold() {
        val p = progress
        anim.snapTo(p)
        finger = 0f
    }
}

/** The numbers behind every transition of the home screen. Pure, so they are unit-tested. */
object RevealMath {
    /** The curve of the system's sheets: nearly all of the way in the first third, then a long soft landing. */
    val Settle = CubicBezierEasing(0.32f, 0.72f, 0f, 1f)

    /** Fling speed, in whole extents per second, that decides regardless of distance. */
    const val FLING = 0.9f

    /** The sheet stays open when released above this; ≈ 96 dp of drag on a 800 dp screen. */
    const val SHEET_KEEP_AT = 0.88f

    /** The calendar opens when pulled past this; with [PULL_GAIN] ≈ 75 dp of finger travel. */
    const val PULL_OPEN_AT = 0.14f

    /** The calendar follows the finger 1.5× faster than 1:1, so a short pull is enough. */
    const val PULL_GAIN = 1.5f

    const val OPEN_MILLIS = 360
    const val CLOSE_MILLIS = 280
    const val MIN_MILLIS = 160

    /** Home faces (list ⇄ big clock). */
    const val FACE_MILLIS = 380
    const val FACE_LIFT_DP = 14f

    fun opens(progress: Float, velocity: Float, openAt: Float): Boolean = when {
        velocity >= FLING -> true
        velocity <= -FLING -> false
        else -> progress >= openAt
    }

    /** Less distance left, less time: finishing a nearly-open layer never takes the full 360 ms. */
    fun openMillis(from: Float): Int = (OPEN_MILLIS * (1f - from)).toInt().coerceIn(MIN_MILLIS, OPEN_MILLIS)

    fun closeMillis(from: Float): Int = (CLOSE_MILLIS * from).toInt().coerceIn(MIN_MILLIS, CLOSE_MILLIS)

    private fun unit(x: Float) = x.coerceIn(0f, 1f)

    // t = 0 the list, t = 1 the clock. The two faces overlap for the middle of the move, so the
    // card never leaves an empty sky between them.
    fun listAlpha(t: Float): Float = 1f - unit(t / 0.6f)
    fun clockAlpha(t: Float): Float = unit((t - 0.2f) / 0.6f)
    fun listScale(t: Float): Float = 1f - 0.05f * unit(t)
    fun clockScale(t: Float): Float = 0.95f + 0.05f * unit(t)
    fun listLiftDp(t: Float): Float = -FACE_LIFT_DP * unit(t)
    fun clockLiftDp(t: Float): Float = FACE_LIFT_DP * (1f - unit(t))

    // p = 0 home, p = 1 the calendar covers it.
    fun homeAlpha(p: Float): Float = 1f - unit(p / 0.55f)
    fun calendarAlpha(p: Float): Float = unit((p - 0.05f) / 0.45f)
}
