package com.nur.prayer.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.drawscope.withTransform
import com.nur.prayer.core.astro.Prayer

/**
 * 0.32.0: the glyphs of the card list are the designer's own (art/home_icons/), vectorised by
 * tools/home_icons.py into [HomeIconData]: six prayer glyphs and three bell states. They are drawn
 * from that data, so they are sharp at any density and any font scale, and recoloured by the state of
 * the card like the mock screen does (past, current, next) — only their outline and their layers' strength
 * come from the sheet, never a colour.
 */

/** Which bell a card wears. */
internal enum class BellState {
    /** No call for this time (and Sunrise, which has none): the bell under a slash. */
    OFF,

    /** The call is on: the bell under its arch, with the dot. */
    ON,

    /** The call is on and this is the window going on now: the solid bell. */
    RINGING
}

internal fun glyphOf(prayer: Prayer): GlyphArt = when (prayer) {
    Prayer.FAJR -> HomeIconData.FAJR
    Prayer.SUNRISE -> HomeIconData.SUNRISE
    Prayer.DHUHR -> HomeIconData.DHUHR
    Prayer.ASR -> HomeIconData.ASR
    Prayer.MAGHRIB -> HomeIconData.MAGHRIB
    // Isha, and anything the list is ever given beyond the six: the crescent.
    else -> HomeIconData.ISHA
}

internal fun bellArt(state: BellState): GlyphArt = when (state) {
    BellState.OFF -> HomeIconData.BELL_OFF
    BellState.ON -> HomeIconData.BELL_ON
    BellState.RINGING -> HomeIconData.BELL_RING
}

/**
 * The tiny path language of [HomeIconData]: absolute `M x y`, `C x1 y1 x2 y2 x y` and `Z`, numbers
 * separated by spaces. Parsed once to a command stream (pure Kotlin, so it is unit-tested on the JVM):
 * `0 x y` = move, `1 x1 y1 x2 y2 x y` = cubic, `2` = close.
 */
internal object GlyphPath {
    const val MOVE = 0f
    const val CUBIC = 1f
    const val CLOSE = 2f

    fun parse(d: String): FloatArray {
        val out = ArrayList<Float>(d.length / 4)
        val args = FloatArray(6)
        var have = 0
        var cmd = ' '
        var i = 0
        while (i < d.length) {
            val c = d[i]
            when {
                c == ' ' -> i++
                c == 'M' || c == 'C' || c == 'Z' -> {
                    require(have == 0) { "unfinished command before '$c' at $i" }
                    if (c == 'Z') out.add(CLOSE)
                    cmd = c
                    i++
                }
                else -> {
                    var j = i
                    while (j < d.length && (d[j] == '-' || d[j] == '.' || d[j] in '0'..'9')) j++
                    require(j > i) { "unexpected '$c' at $i" }
                    args[have++] = d.substring(i, j).toFloat()
                    i = j
                    val need = when (cmd) {
                        'M' -> 2
                        'C' -> 6
                        else -> throw IllegalArgumentException("number after '$cmd' at $i")
                    }
                    if (have == need) {
                        out.add(if (cmd == 'M') MOVE else CUBIC)
                        for (k in 0 until need) out.add(args[k])
                        have = 0
                    }
                }
            }
        }
        require(have == 0) { "unfinished command at the end" }
        return out.toFloatArray()
    }
}

/** A glyph in its viewport: the command streams are parsed once per glyph. */
private val GlyphArt.commands: List<FloatArray>
    get() = parsed.getOrPut(this) { layers.map { GlyphPath.parse(it.path) } }

private val parsed = HashMap<GlyphArt, List<FloatArray>>()

private fun buildPath(commands: FloatArray): Path {
    val path = Path()
    // Counters of a glyph (the inside of a ring, of an arch) are the loops inside a loop.
    path.fillType = PathFillType.EvenOdd
    var i = 0
    while (i < commands.size) {
        when (commands[i]) {
            GlyphPath.MOVE -> {
                path.moveTo(commands[i + 1], commands[i + 2])
                i += 3
            }
            GlyphPath.CUBIC -> {
                path.cubicTo(
                    commands[i + 1], commands[i + 2], commands[i + 3], commands[i + 4], commands[i + 5], commands[i + 6]
                )
                i += 7
            }
            else -> {
                path.close()
                i += 1
            }
        }
    }
    return path
}

/**
 * Draws [art] centred in its box, as large as the box allows. [color] is the glyph, [accent] the small
 * accent of the glyph (the bell's dot); each layer is drawn at its own strength.
 */
@Composable
internal fun GlyphIcon(art: GlyphArt, color: Color, modifier: Modifier = Modifier, accent: Color = color) {
    val paths = remember(art) { art.commands.map(::buildPath) }
    Canvas(modifier) {
        val s = minOf(size.width / art.width, size.height / art.height)
        val dx = (size.width - art.width * s) / 2f
        val dy = (size.height - art.height * s) / 2f
        withTransform({
            translate(left = dx, top = dy)
            scale(scaleX = s, scaleY = s, pivot = Offset.Zero)
        }) {
            art.layers.forEachIndexed { index, layer ->
                val base = if (layer.accent) accent else color
                drawPath(path = paths[index], color = base.copy(alpha = base.alpha * layer.alpha))
            }
        }
    }
}

/** The glyph of a prayer: the box is the 100×100 viewport, which sits on the card's circle. */
@Composable
internal fun PrayerGlyph(prayer: Prayer, color: Color, modifier: Modifier = Modifier) {
    GlyphIcon(glyphOf(prayer), color, modifier)
}

/** The bell of a card, in its [state]; [dot] is the colour of the dot of the "on" bell. */
@Composable
internal fun BellGlyph(state: BellState, color: Color, dot: Color, modifier: Modifier = Modifier) {
    GlyphIcon(bellArt(state), color, modifier, accent = dot)
}
