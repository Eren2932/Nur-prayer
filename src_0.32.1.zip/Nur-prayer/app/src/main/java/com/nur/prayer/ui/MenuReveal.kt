package com.nur.prayer.ui

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.dp

/*
 * 0.14.1: pages opened from the home menu rise out of the button that was tapped and settle back
 * into it on the way home.
 *
 * 0.30.2: the veil is gone.
 *
 * Up to 0.30.1 an opaque layer (black over a picture, the sky's gradient over the sky) was drawn behind the
 * page, so that home could not be seen through a page that is still fading in. It melted in over the last
 * 40 % of the clock on the way in and — the same function run backwards — it *appeared* over the first 60 %
 * on the way out. Combined with a closing curve that kept the page standing for most of the time, the
 * wallpaper went black for a moment and a black rounded card shrank into the capsule. That was the
 * "background suddenly darkens" on every close, and the first of the two jerks.
 *
 * Now nothing opaque is ever added. Home and the page cross-fade by one number (the page's linear clock
 * m, 0 = home, 1 = page), over the same wallpaper that stays where it is:
 *
 *   home alpha = 1 - m / 0.5            (gone by the middle)
 *   page alpha = (m - 0.15) / 0.45      (in by 0.6)
 *
 * The two never leave a hole (the sum stays ≥ 0.7) and never both stand at full strength. The same
 * function runs in both directions, so the way out is exactly the way in, played backwards.
 *
 * Everything that moves is a layer transform, and every fade is per draw call
 * ([CompositingStrategy.ModulateAlpha]): the default would render the whole page into an offscreen
 * buffer in every frame, which is what a weak GPU cannot do 60 times a second.
 *
 *  - the page grows from the tapped button (transformOrigin) from [MenuRevealMotion.PAGE_SCALE];
 *  - home sinks a hair ([MenuRevealMotion.HOME_SCALE]) and comes back;
 *  - the page is invisible for its first frames, so the unavoidable long first frame (the page is
 *    composed there) happens while nothing is on screen and the motion does not appear to skip;
 *  - the same wrapper stays around the page for its whole life (only `active` changes), so going on
 *    to «Город» and back never rebuilds the page and never loses its scroll position.
 */
internal object MenuRevealMotion {
    const val OPEN_MILLIS = 340
    const val CLOSE_MILLIS = 260

    /** Home sinks a little under the page and comes back up when the page leaves. */
    const val HOME_SCALE = 0.965f

    /** A menu page starts this close to its full size: a nudge out of the button, not a zoom. */
    const val PAGE_SCALE = 0.93f

    /** The curve of the system's sheets: nearly all of the way in the first third, then a long soft landing. */
    val Rise = CubicBezierEasing(0.32f, 0.72f, 0f, 1f)

    /** The layer opened from a section of the panel (Дела) grows from further away: it is a bigger move. */
    const val FROM_SCALE = 0.84f
    const val CORNER_DP = 44f
}

internal object RevealGeometry {
    /** The layer of the panel's sections fades in over the first 45 % of the shape's progress. */
    fun contentAlpha(progress: Float): Float = (progress / 0.45f).coerceIn(0f, 1f)

    /** The page's alpha from its linear clock: nothing for the first 15 %, full from 60 %. */
    const val PAGE_IN_FROM = 0.15f
    const val PAGE_IN_SPAN = 0.45f

    /** Home's alpha: full at the start, gone at the middle. */
    const val HOME_OUT_SPAN = 0.5f

    /** [m]: 0 while home is up, 1 while the page is. */
    fun pageAlpha(m: Float): Float = ((m - PAGE_IN_FROM) / PAGE_IN_SPAN).coerceIn(0f, 1f)

    fun homeAlpha(m: Float): Float = (1f - m / HOME_OUT_SPAN).coerceIn(0f, 1f)

    fun pageScale(p: Float): Float = MenuRevealMotion.PAGE_SCALE + (1f - MenuRevealMotion.PAGE_SCALE) * p.coerceIn(0f, 1f)

    fun homeScale(m: Float): Float = 1f - (1f - MenuRevealMotion.HOME_SCALE) * m.coerceIn(0f, 1f)
}

/** The page side of the reveal (Кыбла, Календарь, Настройки). */
@OptIn(ExperimentalAnimationApi::class)
@Composable
internal fun AnimatedVisibilityScope.MenuRevealBox(
    active: () -> Boolean,
    originInRoot: () -> Offset,
    content: @Composable () -> Unit
) {
    val progress = transition.animateFloat(
        transitionSpec = {
            if (targetState == EnterExitState.Visible) tween(MenuRevealMotion.OPEN_MILLIS, easing = MenuRevealMotion.Rise)
            else tween(MenuRevealMotion.CLOSE_MILLIS, easing = MenuRevealMotion.Rise)
        },
        label = "menuReveal"
    ) { state -> if (state == EnterExitState.Visible) 1f else 0f }
    val clock = transition.animateFloat(
        transitionSpec = {
            if (targetState == EnterExitState.Visible) tween(MenuRevealMotion.OPEN_MILLIS, easing = LinearEasing)
            else tween(MenuRevealMotion.CLOSE_MILLIS, easing = LinearEasing)
        },
        label = "menuRevealClock"
    ) { state -> if (state == EnterExitState.Visible) 1f else 0f }
    val topLeft = remember { arrayOf(Offset.Zero) }
    Box(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { topLeft[0] = it.positionInRoot() }
            .graphicsLayer {
                compositingStrategy = CompositingStrategy.ModulateAlpha
                val p = progress.value
                val m = clock.value
                val origin = originInRoot()
                if (active() && origin.isSpecified && (p < 1f || m < 1f)) {
                    val local = origin - topLeft[0]
                    transformOrigin = TransformOrigin(
                        (local.x / size.width.coerceAtLeast(1f)).coerceIn(0f, 1f),
                        (local.y / size.height.coerceAtLeast(1f)).coerceIn(0f, 1f)
                    )
                    val s = RevealGeometry.pageScale(p)
                    scaleX = s
                    scaleY = s
                    alpha = RevealGeometry.pageAlpha(m)
                    clip = p < 1f
                    shape = if (p < 1f) RoundedCornerShape(((1f - p) * MenuRevealMotion.CORNER_DP).dp) else RectangleShape
                } else {
                    scaleX = 1f
                    scaleY = 1f
                    alpha = 1f
                    clip = false
                    shape = RectangleShape
                }
            }
    ) { content() }
}

/**
 * The home side of the same reveal. It runs only while [active] (home ⇄ a menu page); for every other
 * transition home is left exactly as the route transition makes it.
 */
@OptIn(ExperimentalAnimationApi::class)
@Composable
internal fun AnimatedVisibilityScope.HomeRevealBox(
    active: () -> Boolean,
    content: @Composable BoxScope.() -> Unit
) {
    // Mirror image of the page: home is "visible" while the page is away, so it takes the page's
    // closing time when it comes back and the page's opening time when it leaves.
    val clock = transition.animateFloat(
        transitionSpec = {
            if (targetState == EnterExitState.Visible) tween(MenuRevealMotion.CLOSE_MILLIS, easing = LinearEasing)
            else tween(MenuRevealMotion.OPEN_MILLIS, easing = LinearEasing)
        },
        label = "homeRevealClock"
    ) { state -> if (state == EnterExitState.Visible) 1f else 0f }
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                compositingStrategy = CompositingStrategy.ModulateAlpha
                val h = clock.value
                if (h < 1f && active()) {
                    val m = 1f - h
                    alpha = RevealGeometry.homeAlpha(m)
                    val s = RevealGeometry.homeScale(m)
                    scaleX = s
                    scaleY = s
                } else {
                    alpha = 1f
                    scaleX = 1f
                    scaleY = 1f
                }
            }
    ) { content() }
}
