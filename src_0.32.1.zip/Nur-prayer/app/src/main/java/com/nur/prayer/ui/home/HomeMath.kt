package com.nur.prayer.ui.home

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.core.astro.PrayerWindow
import com.nur.prayer.i18n.tr
import java.time.ZonedDateTime
import java.util.Locale

/** What a card of the home list says about its prayer right now. */
enum class RowState {
    /** The time began before the one going on now (and it is not the next one). */
    PAST,

    /** The window going on now: a progress bar and «идёт сейчас». */
    CURRENT,

    /** The next time: the gold card, the countdown above is about this one. */
    NEXT,

    /** Later today (or, after midnight, tonight): «через 4 ч 27 мин». */
    UPCOMING
}

/**
 * 0.30.0: the arithmetic of both home screens, kept out of Compose so a JVM test can pin it.
 * Nothing here reads a clock: every function takes the moment (or the window) it is about.
 */
object HomeMath {
    /**
     * The state of [prayer] by the window alone, so it never needs a ticking clock: the next one is
     * NEXT (even when it is tomorrow's Fajr), the one going on is CURRENT, a time that began before
     * the current window is PAST, anything else is still ahead.
     */
    fun rowState(prayer: Prayer, window: PrayerWindow, today: PrayerDay, fajrEqualsDawn: Boolean): RowState {
        if (prayer == HomeTimeline.next(window, fajrEqualsDawn)) return RowState.NEXT
        if (prayer == HomeTimeline.current(window, fajrEqualsDawn)) return RowState.CURRENT
        val time = today.times[prayer] ?: return RowState.UPCOMING
        return if (time.isBefore(window.currentStart)) RowState.PAST else RowState.UPCOMING
    }

    /** The moment a card shows and counts to: the next one may be tomorrow's, hence [PrayerWindow.nextStart]. */
    fun startOf(prayer: Prayer, state: RowState, window: PrayerWindow, today: PrayerDay): ZonedDateTime? =
        if (state == RowState.NEXT) window.nextStart else today.times[prayer]

    /** «через 2 ч 01 мин»: the minutes are always two digits next to hours, as in the mock. */
    fun until(totalMinutes: Long): String {
        val m = totalMinutes.coerceAtLeast(0L)
        val hours = m / 60L
        val minutes = m % 60L
        return when {
            hours > 0L -> tr("через {0} ч {1} мин", hours, String.format(Locale.US, "%02d", minutes))
            minutes > 0L -> tr("через {0} мин", minutes)
            else -> tr("меньше минуты")
        }
    }

    // ---------------------------------------------------------------- the day's timeline

    /**
     * Where each time sits on a 0..1 axis: proportional to the clock from the first to the last
     * (as in the mock: Fajr at the left end, Isha at the right one). A day that cannot be laid out
     * in time (a missing time, a time out of order) falls back to even steps, never to a crash.
     */
    fun axis(times: List<ZonedDateTime?>): FloatArray {
        val n = times.size
        if (n == 0) return FloatArray(0)
        if (n == 1) return floatArrayOf(0f)
        val seconds = LongArray(n)
        for (i in 0 until n) {
            val t = times[i] ?: return evenAxis(n)
            seconds[i] = t.toEpochSecond()
        }
        for (i in 1 until n) if (seconds[i] <= seconds[i - 1]) return evenAxis(n)
        val span = (seconds[n - 1] - seconds[0]).toDouble()
        return FloatArray(n) { ((seconds[it] - seconds[0]) / span).toFloat() }
    }

    private fun evenAxis(n: Int) = FloatArray(n) { it.toFloat() / (n - 1) }

    /**
     * Where «now» is on that axis: before the first time the left end, after the last one the right
     * end, in between a straight line from one time to the next. Takes epoch seconds so the caller
     * can hand over a minute, not a ticking clock.
     */
    fun nowFraction(times: List<ZonedDateTime?>, axis: FloatArray, nowEpochSecond: Long): Float {
        val n = times.size
        if (n < 2 || axis.size != n) return 0f
        val seconds = LongArray(n)
        for (i in 0 until n) {
            val t = times[i]
            if (t == null) {
                // No times to measure with: step by step, a time passed counts as reached.
                var reached = 0
                for (j in 0 until n) {
                    val tj = times[j] ?: continue
                    if (tj.toEpochSecond() <= nowEpochSecond) reached = j
                }
                return axis[reached]
            }
            seconds[i] = t.toEpochSecond()
        }
        if (nowEpochSecond <= seconds[0]) return axis[0]
        if (nowEpochSecond >= seconds[n - 1]) return axis[n - 1]
        var i = 0
        while (i < n - 2 && nowEpochSecond >= seconds[i + 1]) i++
        val span = (seconds[i + 1] - seconds[i]).toDouble()
        if (span <= 0.0) return axis[i]
        val part = ((nowEpochSecond - seconds[i]) / span).toFloat()
        return axis[i] + (axis[i + 1] - axis[i]) * part
    }

    /**
     * Left edges for labels that sit under their nodes, moved only as far as needed so none touch
     * (gap [gap] between neighbours) and all stay inside [[min], [max]]. The least-squares answer:
     * a crowd of labels spreads evenly around where its members wanted to be, not all to one side.
     */
    fun spreadLabels(centers: FloatArray, widths: FloatArray, gap: Float, min: Float, max: Float): FloatArray {
        val n = centers.size
        if (n == 0 || widths.size != n) return FloatArray(0)
        // Shift every label by the room taken by those before it: the constraint becomes «left edges never decrease».
        val offset = FloatArray(n)
        for (i in 1 until n) offset[i] = offset[i - 1] + widths[i - 1] + gap
        val wanted = FloatArray(n) { centers[it] - widths[it] / 2f - offset[it] }
        val fitted = monotone(wanted)
        // The whole row must fit: the last label's right edge defines the highest the first one may start.
        val highest = max - widths[n - 1] - offset[n - 1]
        val lowest = min
        val out = FloatArray(n)
        for (i in 0 until n) {
            val v = fitted[i].coerceAtMost(highest).coerceAtLeast(lowest)
            out[i] = v + offset[i]
        }
        return out
    }

    /** Pool-adjacent-violators: the closest non-decreasing sequence to [values] (least squares). */
    internal fun monotone(values: FloatArray): FloatArray {
        val n = values.size
        val sum = DoubleArray(n)
        val count = IntArray(n)
        var blocks = 0
        for (v in values) {
            sum[blocks] = v.toDouble()
            count[blocks] = 1
            blocks++
            while (blocks > 1 && sum[blocks - 2] / count[blocks - 2] > sum[blocks - 1] / count[blocks - 1]) {
                sum[blocks - 2] += sum[blocks - 1]
                count[blocks - 2] += count[blocks - 1]
                blocks--
            }
        }
        val out = FloatArray(n)
        var at = 0
        for (b in 0 until blocks) {
            val mean = (sum[b] / count[b]).toFloat()
            repeat(count[b]) { out[at++] = mean }
        }
        return out
    }

    /**
     * Which bell a card wears (0.32.0): none for this time → [BellState.OFF]; the call is on → [BellState.ON],
     * and on the window going on now → [BellState.RINGING], the solid bell of the mock.
     */
    internal fun bellState(enabled: Boolean, state: RowState): BellState = when {
        !enabled -> BellState.OFF
        state == RowState.CURRENT -> BellState.RINGING
        else -> BellState.ON
    }
}
