package com.nur.prayer.ui.shell

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.toRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.home.HomeSection
import com.nur.prayer.ui.home.HomeTimeline
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/*
 * 0.27.0 «Капсула» (variant D of the redesign).
 *
 *  - Home: the times are printed on the wallpaper; at the bottom one floating capsule says what fits
 *    this moment («Вечерние азкары · сейчас · 0 из 12»). A tap on its text starts that; a tap on the
 *    dots opens the panel.
 *  - The panel is the same glass grown in place (shared bounds): today's six times (a tap opens the
 *    prayer's sheet, the speaker marks the azan) and the six sections, each one tap away. A tap
 *    beside it, or back, folds it back into the capsule.
 *  - In a section the capsule says where you are («Кыбла · тап — другие разделы») and opens the same
 *    panel; the moon leads home; the countdown lives in the island at the top.
 *
 * No swipes and no hidden gestures: everything is visible and tappable, TalkBack reads it as is.
 * Every sizes and colours here are taken from the mock (see ShellColors).
 *
 * 0.27.1, the motion:
 *  - the capsule and the panel stay composed for as long as the capsule is on a route. Opening used to
 *    compose ~60 nodes of the panel on the first frame of the morph (and the capsule's content again on
 *    the last frame of the fold): that was the stutter. Now only a float moves;
 *  - layers fade per draw call ([CompositingStrategy.ModulateAlpha]): no offscreen buffer the size of the
 *    panel in every frame of the fade;
 *  - the glass has no elevation shadow and no path clip (see Frost.kt);
 *  - a capsule that comes or goes slides by a layout offset, not a layer translation, so the glass keeps
 *    knowing where on screen it is and the blurred picture inside it never lags behind;
 *  - [ShellState.capsuleHidden]: a page can send the capsule away (the Quran reader while one reads) and
 *    call it back with one float.
 */

/** What the capsule says on home: the thing that fits this moment, and what a tap on it does. */
@Immutable
class CapsuleNow(
    val title: String,
    val subtitle: String,
    val glyph: ShellGlyph,
    val onClick: () -> Unit
)

private val CAPSULE_HEIGHT = 64.dp
private val CAPSULE_MIN_WIDTH = 288.dp
private val CAPSULE_MAX_WIDTH = 400.dp
private val PANEL_MAX_WIDTH = 460.dp
private val PANEL_SIDE = 14.dp
private val PANEL_CORNER = 28.dp
/** What the home and the pages reserve under their content for the capsule. Unchanged since 0.27.0. */
private val BOTTOM_GAP = 14.dp

/** 0.30.2: where the capsule really stands above the navigation bar: 1 dp lower than the room it has reserved. */
private val CAPSULE_BOTTOM = 13.dp

/** Bottom room the capsule takes above the navigation bar; pages under it pad their lists by it. */
val CapsuleRoom = CAPSULE_HEIGHT + BOTTOM_GAP + 12.dp

/** Room the island takes under the status bar; page headers step down by it. */
val IslandRoom = 50.dp

@Composable
fun ShellLayer(
    shell: ShellState,
    route: String,
    data: PrayerData,
    now: State<ZonedDateTime>,
    home: CapsuleNow,
    onOpenSection: (HomeSection, Offset) -> Unit,
    onHome: (Offset) -> Unit,
    onOpenPrayer: (Prayer) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val capsuleOn = ShellRoutes.capsuleOn(route)
    val islandOn = ShellRoutes.islandOn(route)
    // The page under the capsule keeps being named while the capsule slides away with it.
    val lastSection = remember { arrayOfNulls<HomeSection>(1) }
    val liveSection = ShellRoutes.sectionOf(route)
    if (capsuleOn) lastSection[0] = liveSection
    val section = if (capsuleOn) liveSection else lastSection[0]

    // A hidden capsule is not a capsule the panel can grow out of.
    val capsuleVisible = ShellMath.capsuleVisible(capsuleOn, shell.capsuleHidden)
    LaunchedEffect(capsuleVisible) { if (!capsuleVisible) shell.hide() }
    LaunchedEffect(shell.open) {
        coroutineScope {
            // 0.30.2: the vibrator call goes after the first frame of the morph, not in front of it: on a
            // phone where it takes a few milliseconds that used to be a hitch right at the tap.
            if (shell.open) launch {
                withFrameNanos { }
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            }
            shell.settle()
        }
    }
    BackHandler(enabled = shell.open) { shell.hide() }

    val panelOnScreen by remember(shell) { derivedStateOf { shell.open || shell.progress > 0.001f } }
    val capsuleShown = animateFloatAsState(
        if (capsuleVisible) 1f else 0f,
        tween(if (capsuleVisible) 320 else 200, easing = FastOutSlowInEasing),
        label = "capsuleShown"
    )
    val islandShown = animateFloatAsState(
        if (islandOn) 1f else 0f,
        tween(if (islandOn) 320 else 180, easing = FastOutSlowInEasing),
        label = "islandShown"
    )
    val capsuleComposed by remember { derivedStateOf { capsuleOn || capsuleShown.value > 0f } }
    val islandComposed by remember { derivedStateOf { islandOn || islandShown.value > 0f } }

    Box(modifier.fillMaxSize()) {
        if (panelOnScreen) {
            // A tap anywhere beside the panel folds it; the page under it stays where it was.
            Box(
                Modifier
                    .fillMaxSize()
                    .drawBehind { drawRect(Color.Black, alpha = SCRIM_ALPHA * shell.progress.coerceIn(0f, 1f)) }
                    .pointerInput(shell) { detectTapGestures { shell.hide() } }
            )
        }
        if (islandComposed) {
            TopIsland(
                data, now, onTap = onHome,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 6.dp)
                    .offset { IntOffset(0, (-(1f - islandShown.value) * 20.dp.toPx()).roundToInt()) }
                    .graphicsLayer {
                        val k = islandShown.value
                        alpha = k
                        compositingStrategy = CompositingStrategy.ModulateAlpha
                        val s = 0.92f + 0.08f * k
                        scaleX = s
                        scaleY = s
                    }
            )
        }
        if (capsuleComposed) {
            CapsuleMorph(
                shell = shell,
                visible = capsuleVisible,
                section = section,
                home = home,
                data = data,
                onOpenSection = { s, origin ->
                    shell.hide()
                    // The page the section opens on is already showing: folding the panel is the answer.
                    if (route != ShellRoutes.routeOf(s)) onOpenSection(s, origin)
                },
                onHome = { origin -> shell.hide(); onHome(origin) },
                onOpenPrayer = { p -> shell.hide(); onOpenPrayer(p) },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = CAPSULE_BOTTOM)
                    .offset { IntOffset(0, ((1f - capsuleShown.value) * ShellMath.SLIDE_DP.dp.toPx()).roundToInt()) }
                    .graphicsLayer {
                        alpha = capsuleShown.value
                        compositingStrategy = CompositingStrategy.ModulateAlpha
                    }
            )
        }
    }
}

private const val SCRIM_ALPHA = 0.30f

/** The rounded rectangle of the glass: a pill while closed, the panel's corners once open. */
private class MorphShape(private val shell: ShellState) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val p = shell.progress.coerceIn(0f, 1f)
        val r = with(density) { ShellMath.lerp(CAPSULE_HEIGHT.toPx() / 2f, PANEL_CORNER.toPx(), p) }
            .coerceAtMost(size.minDimension / 2f)
        return Outline.Rounded(RoundRect(size.toRect(), CornerRadius(r)))
    }
}

@Composable
private fun CapsuleMorph(
    shell: ShellState,
    visible: Boolean,
    section: HomeSection?,
    home: CapsuleNow,
    data: PrayerData,
    onOpenSection: (HomeSection, Offset) -> Unit,
    onHome: (Offset) -> Unit,
    onOpenPrayer: (Prayer) -> Unit,
    modifier: Modifier = Modifier
) {
    val frost = rememberFrost()
    val shape = remember(shell) { MorphShape(shell) }
    val open = shell.open

    Layout(
        content = {
            // Both faces stay composed; only the one that is up answers touches and TalkBack.
            Box(if (open || !visible) Modifier.clearAndSetSemantics { } else Modifier) {
                CapsuleContent(
                    section = section, home = home, enabled = visible && !open,
                    onExpand = { shell.show() }, onHome = onHome
                )
            }
            Box(if (open) Modifier else Modifier.clearAndSetSemantics { }) {
                PanelContent(
                    data = data, current = section, enabled = open,
                    onOpenPrayer = onOpenPrayer, onOpenSection = onOpenSection
                )
            }
        },
        modifier = modifier
            .frostGlass(frost, shape)
            .onGloballyPositioned { c -> shell.glassBottomInRoot = c.boundsInRoot().bottom }
    ) { measurables, constraints ->
        val p = ShellMath.clampProgress(shell.progress)
        val maxW = constraints.maxWidth
        val capW = ShellMath.capsuleWidth(
            maxW.toFloat(), CAPSULE_MIN_WIDTH.toPx(), CAPSULE_MAX_WIDTH.toPx(), PANEL_SIDE.toPx()
        ).roundToInt().coerceAtMost(maxW)
        val capH = CAPSULE_HEIGHT.roundToPx()
        val panelW = minOf(maxW - 2 * PANEL_SIDE.roundToPx(), PANEL_MAX_WIDTH.roundToPx()).coerceAtLeast(capW)
        val capsule = measurables[0].measure(Constraints.fixed(capW, capH))
        val panel = measurables[1].measure(
            Constraints(minWidth = panelW, maxWidth = panelW, minHeight = 0, maxHeight = constraints.maxHeight)
        )
        val panelH = if (panel.height > 0) panel.height else capH
        val w = ShellMath.lerp(capW.toFloat(), panelW.toFloat(), ShellMath.widthProgress(p)).roundToInt().coerceIn(0, maxW)
        val h = ShellMath.lerp(capH.toFloat(), panelH.toFloat(), p).roundToInt().coerceIn(0, constraints.maxHeight)
        if (panel.height > 0) shell.panelHeightPx = panel.height.toFloat()
        layout(w, h) {
            capsule.placeWithLayer((w - capW) / 2, h - capH) {
                alpha = ShellMath.capsuleAlpha(p)
                compositingStrategy = CompositingStrategy.ModulateAlpha
            }
            panel.placeWithLayer((w - panelW) / 2, 0) {
                alpha = ShellMath.panelAlpha(p)
                compositingStrategy = CompositingStrategy.ModulateAlpha
                translationY = (1f - p.coerceAtMost(1f)) * 14.dp.toPx()
            }
        }
    }
}

@Composable
private fun CapsuleContent(
    section: HomeSection?,
    home: CapsuleNow,
    enabled: Boolean,
    onExpand: () -> Unit,
    onHome: (Offset) -> Unit
) {
    Crossfade(targetState = section, animationSpec = tween(220), label = "capsuleSection") { here ->
        val ui = uiScale()
        val title = here?.label() ?: home.title
        val subtitle = if (here == null) home.subtitle else tr("тап — другие разделы")
        val glyph = here?.glyph ?: home.glyph
        val endCenter = remember { arrayOf(Offset.Unspecified) }
        Row(
            Modifier.fillMaxSize().padding(start = 11.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(50))
                    .clickable(
                        enabled = enabled,
                        role = Role.Button,
                        onClickLabel = if (here == null) title else tr("Разделы"),
                        onClick = { if (here == null) home.onClick() else onExpand() }
                    )
                    .padding(end = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(42.dp).clip(CircleShape).background(ShellColors.Gold),
                    contentAlignment = Alignment.Center
                ) { ShellIcon(glyph, ShellColors.OnGold, Modifier.size(22.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    // Fits instead of cutting: «Вечерние азкары» is «азка…» on a narrow phone or a large font.
                    AutoSizeText(
                        title, color = TextPrimary, fontSize = ui.t(16f), minFontSize = ui.t(12.5f),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        subtitle, color = ShellColors.Secondary, fontSize = ui.t(12.5f),
                        fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Box(Modifier.width(1.dp).height(30.dp).background(ShellColors.Divider))
            val endLabel = if (here == null) tr("Разделы") else tr("На главную")
            Box(
                Modifier
                    .padding(start = 6.dp)
                    .size(48.dp)
                    .onGloballyPositioned { endCenter[0] = it.boundsInRoot().center }
                    .clip(CircleShape)
                    .clickable(enabled = enabled, role = Role.Button, onClickLabel = endLabel) {
                        if (here == null) onExpand() else onHome(endCenter[0])
                    }
                    .semantics { contentDescription = endLabel },
                contentAlignment = Alignment.Center
            ) {
                if (here == null) ShellIcon(ShellGlyph.DOTS, TextPrimary, Modifier.size(19.dp))
                else ShellIcon(ShellGlyph.MOON, TextPrimary, Modifier.size(25.dp))
            }
        }
    }
}

@Composable
private fun PanelContent(
    data: PrayerData,
    current: HomeSection?,
    enabled: Boolean,
    onOpenPrayer: (Prayer) -> Unit,
    onOpenSection: (HomeSection, Offset) -> Unit
) {
    val ui = uiScale()
    val date = data.today.date
    val nowPrayer = HomeTimeline.current(data.window, data.fajrEqualsDawn)
    val times = PanelTimes.PRAYERS
    Column(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${tr("Сегодня")} · ${Format.weekday(date)}",
                color = TextPrimary, fontSize = ui.t(15f), fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            Text(Format.dayMonth(date), color = ShellColors.Secondary, fontSize = ui.t(13f), fontWeight = FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.width(10.dp))
            SettingsGear(enabled = enabled, onOpen = { origin -> onOpenSection(HomeSection.SETTINGS, origin) })
        }
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            times.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { prayer ->
                        TimeCard(
                            prayer = prayer,
                            time = data.today.times[prayer]?.let(Format::time) ?: "—",
                            now = prayer == nowPrayer,
                            azan = prayer.isPrayer && data.settings.notifications[prayer] == true,
                            enabled = enabled,
                            onClick = { onOpenPrayer(prayer) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
        Box(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 6.dp)
                .height(1.dp).background(ShellColors.Divider)
        )
        HomeSection.GRID.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                row.forEach { s ->
                    SectionCell(s, current = s == current, enabled = enabled, onOpen = onOpenSection, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

/**
 * 0.29.0: settings used to be an avatar in the corner of home. The corner is empty now; the way in is this
 * small gear at the end of the panel's header, reachable from home and from every section alike.
 */
@Composable
private fun SettingsGear(enabled: Boolean, onOpen: (Offset) -> Unit) {
    val center = remember { arrayOf(Offset.Unspecified) }
    val label = tr("Настройки")
    Box(
        Modifier
            .size(34.dp)
            .onGloballyPositioned { center[0] = it.boundsInRoot().center }
            .clip(CircleShape)
            .background(ShellColors.Well)
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) { onOpen(center[0]) }
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) { Glyph(GlyphKind.SETTINGS, TextPrimary, Modifier.size(17.dp)) }
}

/** The six times of the panel: the five prayers and sunrise, as in the mock. */
internal object PanelTimes {
    val PRAYERS: List<Prayer> = listOf(Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)
}

@Composable
private fun TimeCard(
    prayer: Prayer,
    time: String,
    now: Boolean,
    azan: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val ink = if (now) ShellColors.OnGold else TextPrimary
    val label = PrayerLabels.title(prayer)
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (now) ShellColors.GoldCard else ShellColors.Card)
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = tr("Подробнее"), onClick = onClick)
            .semantics { contentDescription = "$label $time" }
            .padding(start = 12.dp, end = 10.dp, top = 9.dp, bottom = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                label, color = if (now) ShellColors.OnGold.copy(alpha = 0.78f) else ShellColors.Secondary,
                fontSize = ui.t(12.5f), fontWeight = FontWeight.Medium, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            if (azan) Glyph(GlyphKind.SOUND, if (now) ShellColors.OnGold else TextPrimary.copy(alpha = 0.85f), Modifier.size(12.dp))
        }
        Spacer(Modifier.height(2.dp))
        Text(
            time, color = ink, fontSize = ui.t(18f), fontWeight = FontWeight.Bold, maxLines = 1,
            style = TextStyle(fontFeatureSettings = "tnum")
        )
    }
}

@Composable
private fun SectionCell(
    section: HomeSection,
    current: Boolean,
    enabled: Boolean,
    onOpen: (HomeSection, Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val center = remember { arrayOf(Offset.Unspecified) }
    val label = section.label()
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) { onOpen(section, center[0]) }
            .semantics { contentDescription = label }
            .padding(vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(46.dp)
                .onGloballyPositioned { center[0] = it.boundsInRoot().center }
                .clip(CircleShape)
                .background(ShellColors.Well)
                .then(if (current) Modifier.border(1.5.dp, ShellColors.Gold, CircleShape) else Modifier),
            contentAlignment = Alignment.Center
        ) { ShellIcon(section.glyph, TextPrimary, Modifier.size(22.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(
            label, color = TextPrimary.copy(alpha = 0.92f), fontSize = ui.t(13f), fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

/** The countdown inside a section: a small frosted island under the status bar. A tap leads home. */
@Composable
private fun TopIsland(data: PrayerData, now: State<ZonedDateTime>, onTap: (Offset) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val frost = rememberFrost()
    val pill = RoundedCornerShape(50)
    val center = remember { arrayOf(Offset.Unspecified) }
    val next = HomeTimeline.next(data.window, data.fajrEqualsDawn)
    Row(
        modifier
            .height(38.dp)
            .frostGlass(frost, pill)
            .onGloballyPositioned { center[0] = it.boundsInRoot().center }
            .clickable(role = Role.Button, onClickLabel = tr("На главную")) { onTap(center[0]) }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(ShellColors.Gold))
        Spacer(Modifier.width(9.dp))
        Text(PrayerLabels.title(next), color = TextPrimary, fontSize = ui.t(14f), fontWeight = FontWeight.Medium, maxLines = 1)
        Spacer(Modifier.width(5.dp))
        IslandCountdown(data, now)
    }
}

/** The only part of the island that changes every second. */
@Composable
private fun IslandCountdown(data: PrayerData, now: State<ZonedDateTime>) {
    val ui = uiScale()
    Text(
        Format.countdown(data.window.remaining(now.value)),
        color = TextPrimary, fontSize = ui.t(14f), fontWeight = FontWeight.Bold, maxLines = 1,
        style = TextStyle(fontFeatureSettings = "tnum")
    )
}
