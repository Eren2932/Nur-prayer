package com.nur.prayer.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.HomeLayout
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.shell.CapsuleRoom
import com.nur.prayer.ui.shell.LocalShell
import com.nur.prayer.ui.shell.PanelTimes
import com.nur.prayer.ui.shell.ShellGlyph
import com.nur.prayer.ui.shell.ShellIcon
import com.nur.prayer.ui.shell.ShellMath
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime

/*
 * 0.30.0 home: two screens, one choice in the settings (HomeLayout, «Карточки» by default).
 *
 *  - HomeCards: the countdown and the six times as cards, the next one in gold, the rest in white
 *    glass (HomeCards.kt);
 *  - HomeBig: the next prayer's name in huge type with its time, the countdown and the day's
 *    timeline (HomeBig.kt).
 *
 * What both share lives here: the header (the city with the hijri date), the chip of a feast or a
 * fast, the room kept for the capsule and the way the screen yields to the capsule's panel. When the
 * capsule opens into the panel, the rest of the screen (the cards, the timeline) steps aside, the
 * panel repeats the times, and the hero (the countdown and what belongs to it) shrinks and rises just
 * enough to stay in sight above the panel. Both read the shell's progress in draw only: the morph
 * never recomposes home. The clock is read only in HomeClock.kt.
 */

/** Scale of the hero while the panel is open (mock: «Отсчёт уменьшился, но остался на виду»). */
private const val CLOCK_OPEN_SCALE = 0.8f

/**
 * 0.30.2: the city and the hijri date stand 3 dp higher (8 → 5). The tap target keeps its 48 dp, only the row
 * starts closer to the status bar.
 */
private val HEADER_TOP = 5.dp

@Composable
fun HomeScreen(
    data: PrayerData,
    now: State<ZonedDateTime>,
    palette: PhasePalette,
    onOpenCity: () -> Unit,
    /** The chip of a feast or a fast: the month calendar, opened plainly. */
    onOpenSchedule: () -> Unit,
    /** A time on the screen: its sheet. */
    onOpenPrayer: (Prayer) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val shell = LocalShell.current
    // Where things are, for the lift of the hero. Plain holders: only the draw pass reads them.
    val geometry = remember { FloatArray(3) { Float.NaN } } // [header bottom, hero top, hero height]
    val next = HomeTimeline.next(data.window, data.fajrEqualsDawn)
    val prayers = PanelTimes.PRAYERS

    // The hero rises and shrinks above the open panel…
    val hero = Modifier
        .onGloballyPositioned {
            val b = it.boundsInRoot()
            geometry[1] = b.top
            geometry[2] = b.height
        }
        .graphicsLayer {
            val p = (shell?.progress ?: 0f).coerceIn(0f, 1f)
            if (p <= 0f) {
                scaleX = 1f; scaleY = 1f; translationY = 0f
            } else {
                val s = ShellMath.lerp(1f, CLOCK_OPEN_SCALE, p)
                transformOrigin = TransformOrigin(0.5f, 0f)
                scaleX = s
                scaleY = s
                val lift = ShellMath.clockLift(
                    clockTop = geometry[1],
                    clockBottomScaled = geometry[1] + geometry[2] * CLOCK_OPEN_SCALE,
                    panelTop = shell?.panelTopInRoot ?: Float.NaN,
                    gap = 22.dp.toPx(),
                    ceiling = geometry[0] + 12.dp.toPx()
                )
                translationY = if (lift.isNaN()) 0f else -lift * p
            }
        }
    // …and the rest (the cards, the timeline) steps aside: the panel repeats it.
    val rest = Modifier.graphicsLayer {
        val p = (shell?.progress ?: 0f).coerceIn(0f, 1f)
        // 0.30.2: per draw call. The default (Auto) renders the whole list into an offscreen buffer in every
        // frame of the fade, which is what a weaker GPU feels as a stutter on the first frames of opening.
        compositingStrategy = CompositingStrategy.ModulateAlpha
        alpha = (1f - p * 2.2f).coerceIn(0f, 1f)
        translationY = p * 18.dp.toPx()
    }

    Column(modifier.fillMaxSize()) {
        HomeHeader(
            data, onOpenCity,
            Modifier.onGloballyPositioned { geometry[0] = it.boundsInRoot().bottom }
        )
        // 0.19.0: a feast, a night or a fast of the Islamic year, in its colour (nothing on a plain day).
        HomeDayChip(
            data.today.date, data.settings.hijriOffset, onOpen = onOpenSchedule,
            modifier = Modifier.padding(start = ui.s(20f), end = ui.s(20f), top = 8.dp)
        )
        when (data.settings.homeLayout) {
            HomeLayout.CARDS -> HomeCards(
                data, now, prayers, next, hero, rest, onOpenPrayer, Modifier.weight(1f)
            )
            HomeLayout.BIG -> HomeBig(
                data, now, prayers, next, hero, rest, onOpenPrayer, Modifier.weight(1f)
            )
        }
        // The capsule floats over this room; nothing of home ever hides under it.
        Spacer(Modifier.fillMaxWidth().navigationBarsPadding().height(CapsuleRoom))
    }
}

/** The city and the hijri date on the right: nothing else at the top (0.29.0: the avatar is gone, settings sit in the panel). */
@Composable
private fun HomeHeader(data: PrayerData, onOpenCity: () -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val sky = TextStyle(shadow = HomeSpec.OnSky)
    Row(
        modifier.fillMaxWidth().padding(start = ui.s(14f), end = ui.s(12f), top = HEADER_TOP),
        verticalAlignment = Alignment.Top
    ) {
        Spacer(Modifier.weight(1f))
        Column(
            Modifier
                .weight(3f)
                .clip(RoundedCornerShape(14.dp))
                .clickable(role = Role.Button, onClickLabel = tr("Выбрать город"), onClick = onOpenCity)
                .heightIn(min = 48.dp)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.End
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (data.settings.useDeviceLocation) {
                    ShellIcon(ShellGlyph.LOCATE, TextPrimary, Modifier.size(14.dp))
                    Spacer(Modifier.width(8.dp))
                }
                AutoSizeText(
                    data.place.label, color = TextPrimary, fontSize = ui.t(18f), minFontSize = ui.t(13f),
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.End
                )
            }
            Spacer(Modifier.height(2.dp))
            // 0.19.0: on a feast or a fast the hijri date takes the colour of the day.
            val dayTone = remember(data.today.date, data.settings.hijriOffset) {
                com.nur.prayer.data.IslamicDays.primary(data.today.date, data.settings.hijriOffset)
                    ?.takeIf { it.kind == com.nur.prayer.data.DayKind.FEAST || it.kind == com.nur.prayer.data.DayKind.FAST }
                    ?.let { com.nur.prayer.ui.schedule.DayTone.of(it.kind) }
            }
            Text(
                HijriCalendar.format(data.today.date, data.settings.hijriOffset),
                color = dayTone ?: TextPrimary.copy(alpha = 0.88f), fontSize = ui.t(13f), fontWeight = FontWeight.Medium,
                style = sky, maxLines = 1
            )
        }
    }
}

