package com.nur.prayer.ui.wallpaper

import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/*
 * Pure arithmetic of the wallpapers, no Android: unit-tested in WallpaperMathTest.
 */

/**
 * Where a picture goes on a screen of any shape.
 *
 * The pictures are portrait (≈ 0.45…0.56), the screens anything from 0.40 (21:9 phones) to 2.2
 * (a tablet in landscape). Three rules:
 *
 *  1. Fill the screen (cover) — on every phone this is what happens, the picture is never letterboxed.
 *  2. Keep the composition: the picture point at ([focusX], [focusY]) of the picture lands at the
 *     same fraction of the screen. This is an alignment bias, not "centre the focus": a mosque
 *     drawn at the bottom stays at the bottom, under the clock, not in the middle of it.
 *  3. Never zoom in so far that less than [minVisible] of the picture's cropped side is left. On a
 *     landscape tablet a cover crop would show a quarter of the picture — a blur of sky. Instead
 *     the picture stops growing and the remaining strips are filled by the blurred continuation of
 *     the picture itself ([WallpaperFill], 0.31.0; before it the edge pixels were extended, which
 *     smeared the boats and arcades of a photograph into streaks).
 */
object WallpaperFit {
    const val MIN_VISIBLE = 0.62f

    /** Picture pixel (x, y) is drawn at screen (dx + x·scale, dy + y·scale). */
    data class Fit(val scale: Float, val dx: Float, val dy: Float)

    fun fit(
        imageWidth: Float, imageHeight: Float,
        screenWidth: Float, screenHeight: Float,
        focusX: Float, focusY: Float,
        minVisible: Float = MIN_VISIBLE
    ): Fit {
        if (imageWidth <= 0f || imageHeight <= 0f || screenWidth <= 0f || screenHeight <= 0f) return Fit(1f, 0f, 0f)
        val sx = screenWidth / imageWidth
        val sy = screenHeight / imageHeight
        val cover = max(sx, sy)
        val contain = min(sx, sy)
        // Visible share of the cropped side at scale s is contain / s; keep it >= minVisible.
        val scale = min(cover, contain / minVisible.coerceIn(0.05f, 1f))
        val fx = focusX.coerceIn(0f, 1f)
        val fy = focusY.coerceIn(0f, 1f)
        return Fit(scale, (screenWidth - imageWidth * scale) * fx, (screenHeight - imageHeight * scale) * fy)
    }

    /**
     * BitmapFactory inSampleSize for a picture drawn at [scale] of its full size: the largest power
     * of two that still leaves at least one decoded pixel per screen pixel (sample·scale ≤ 1).
     */
    fun sampleSize(scale: Float): Int {
        if (!(scale > 0f)) return 1
        var sample = 1
        while (sample < 32 && sample * 2 * scale <= 1f) sample *= 2
        return sample
    }
}

/**
 * 0.31.0: what fills the strips beside a picture on a wide screen (a tablet in landscape, a fold).
 *
 * Until 0.30 the strips repeated the picture's edge pixels (CLAMP). That suited the flat
 * illustrations of 0.22, whose edges are sky and sand; on a photograph the boats, rocks, crowds and
 * arcades at the edge were smeared into long horizontal streaks. Now:
 *
 *  1. the strips show the picture's own continuation: the picture shrunk to [WIDTH] px, blurred
 *     (3 × box of [BLUR_RADIUS] ≈ gaussian), laid exactly over the sharp one and mirrored beyond its
 *     edges, shaded by [SHADE]. Mirrored, not stretched or zoomed: at the seam the fill has the colour
 *     of the edge it continues (a cover-zoomed fill put the black of the Kaaba next to the evening
 *     sky), and beyond it the light changes as in the picture, without CLAMP's streaks;
 *  2. the sharp picture lies on top where [WallpaperFit] puts it, and on a side that has a strip
 *     its edge fades into the fill over [FEATHER] of its drawn size — no seam, no hairline.
 *
 * The colour at every screen pixel is pic·m + fill·SHADE·(1 − m), m = [mask]. The contrast scrim
 * samples exactly this ([WallpaperContrast.scrim] with a fill), so its guarantee still holds on the strips.
 * On every phone the picture covers the screen, m = 1 everywhere and nothing of this is drawn.
 */
object WallpaperFill {
    const val WIDTH = 48
    const val BLUR_RADIUS = 3
    const val SHADE = 0.86f
    const val FEATHER = 0.08f

    /** The fill's own fit: the [fillWidth] px copy laid exactly over the picture fitted as [picture]. */
    fun fit(picture: WallpaperFit.Fit, imageWidth: Float, fillWidth: Float): WallpaperFit.Fit =
        if (fillWidth <= 0f) picture else WallpaperFit.Fit(picture.scale * imageWidth / fillWidth, picture.dx, picture.dy)

    /** Index [i] of a mirrored line of [n] pixels (… 2 1 0 | 0 1 2 … n−1 | n−1 n−2 …), as TileMode.Mirror. */
    fun mirror(i: Int, n: Int): Int {
        if (n <= 1) return 0
        val period = 2 * n
        val t = ((i % period) + period) % period
        return if (t < n) t else period - 1 - t
    }

    /** True when the picture leaves a strip on this screen: only then is the fill drawn. */
    fun needed(fit: WallpaperFit.Fit, imageWidth: Float, imageHeight: Float, screenWidth: Float, screenHeight: Float): Boolean =
        fit.dx > EDGE || fit.dy > EDGE ||
            fit.dx + imageWidth * fit.scale < screenWidth - EDGE || fit.dy + imageHeight * fit.scale < screenHeight - EDGE

    /**
     * Opacity of the sharp picture at screen point ([x], [y]): 0 outside it, 1 inside, a linear
     * ramp of [FEATHER] × its drawn size along every edge that borders a strip. An edge that runs
     * off the screen is not feathered (nothing to blend with there).
     */
    fun mask(
        x: Float, y: Float, fit: WallpaperFit.Fit, imageWidth: Float, imageHeight: Float,
        screenWidth: Float, screenHeight: Float
    ): Float {
        val left = fit.dx
        val top = fit.dy
        val right = fit.dx + imageWidth * fit.scale
        val bottom = fit.dy + imageHeight * fit.scale
        if (x < left || x > right || y < top || y > bottom) return 0f
        val fw = FEATHER * (right - left)
        val fh = FEATHER * (bottom - top)
        var m = 1f
        if (left > EDGE) m = min(m, (x - left) / fw)
        if (right < screenWidth - EDGE) m = min(m, (right - x) / fw)
        if (top > EDGE) m = min(m, (y - top) / fh)
        if (bottom < screenHeight - EDGE) m = min(m, (bottom - y) / fh)
        return m.coerceIn(0f, 1f)
    }

    /** Half a pixel: a picture that misses the edge by less is drawn edge to edge already. */
    private const val EDGE = 0.5f
}

/**
 * How much to darken a picture so the app's white type stays readable on it — computed, not guessed.
 *
 * Same contract as the sky (tools/test_amoled_source.py, 0.6.0): on the bare backdrop
 *  - the header (place, date; top [HEADER_END] of the screen) carries TextSecondary at ≥ 4.5:1,
 *  - the footer (day note, pull hint, buttons; from [FOOTER_START]) carries TextPrimary at ≥ 4.5:1,
 *  - between them only large bold type sits on the bare backdrop: TextPrimary at ≥ 3:1 (WCAG large).
 *
 * The screen is cut into [ROWS] horizontal slabs. For each slab the pixels of the picture that
 * actually land in it (after [WallpaperFit], so per device) are measured, the 90th-percentile
 * luminance is taken (the moon and a few stars may stay bright; a whole bright sky may not), and the
 * smallest black overlay alpha that brings that pixel under the slab's limit is found by bisection.
 * Overlay is composited in sRGB like Compose does: c' = c·(1 − a) + tint·a (see [alphaFor], [tintOf]).
 *
 * The slab values become the stops of one vertical gradient drawn at slab centres. Each stop is
 * dilated to the max of its neighbours: a point between two centres belongs to one of the two
 * slabs, and the interpolated alpha there is ≥ min(both stops) ≥ the requirement of both slabs.
 * So the guarantee holds at every pixel row, not only at the centres.
 */
object WallpaperContrast {
    const val ROWS = 24
    const val HEADER_END = 0.17f
    const val FOOTER_START = 0.74f
    const val PERCENTILE = 0.90f
    const val MAX_ALPHA = 0.86f
    /** Rounding of the GPU blend and of the WebP decoder; the result is never shaved to the limit. */
    const val MARGIN = 0.02f

    /** Relative luminance of TextPrimary (#FFFFFF) and TextSecondary (#D2D0E2). */
    val PRIMARY_LUMINANCE: Double = luminance(1.0, 1.0, 1.0)
    val SECONDARY_LUMINANCE: Double = luminance(0xD2 / 255.0, 0xD0 / 255.0, 0xE2 / 255.0)

    fun linear(c: Double): Double = if (c <= 0.04045) c / 12.92 else ((c + 0.055) / 1.055).pow(2.4)

    fun luminance(r: Double, g: Double, b: Double): Double = 0.2126 * linear(r) + 0.7152 * linear(g) + 0.0722 * linear(b)

    fun contrast(a: Double, b: Double): Double = (max(a, b) + 0.05) / (min(a, b) + 0.05)

    /** Brightest background luminance that keeps [textLuminance] at [ratio]:1. */
    fun limit(textLuminance: Double, ratio: Double): Double = (textLuminance + 0.05) / ratio - 0.05

    /** Requirement of the slab centred at screen fraction [y]: text luminance and ratio. */
    fun requirement(y: Float): Pair<Double, Double> = when {
        y < HEADER_END -> SECONDARY_LUMINANCE to 4.5
        y >= FOOTER_START -> PRIMARY_LUMINANCE to 4.5
        else -> PRIMARY_LUMINANCE to 3.0
    }

    /**
     * Smallest overlay alpha that brings sRGB colour (r, g, b) at or under [maxLuminance] when the
     * overlay colour is ([tr], [tg], [tb]): c' = c·(1 − a) + t·a. The overlay is a deep shade of the
     * picture itself ([tintOf]), so a cream sky goes warm brown instead of dirty grey. Monotone in a
     * because the tint is itself under every limit (checked here: a too-bright tint gives 1).
     */
    fun alphaFor(
        r: Double, g: Double, b: Double, maxLuminance: Double,
        tr: Double = 0.0, tg: Double = 0.0, tb: Double = 0.0
    ): Float {
        if (luminance(r, g, b) <= maxLuminance) return 0f
        if (luminance(tr, tg, tb) > maxLuminance) return 1f
        var lo = 0.0
        var hi = 1.0
        repeat(24) {
            val mid = (lo + hi) / 2
            val k = 1 - mid
            if (luminance(r * k + tr * mid, g * k + tg * mid, b * k + tb * mid) <= maxLuminance) hi = mid else lo = mid
        }
        return hi.toFloat()
    }

    /** Share of the darkest pixels skipped when picking the tint (outlines, noise). */
    const val TINT_PERCENTILE = 0.02f
    /** The tint is that dark tone at this brightness: deep enough to sit under every limit. */
    const val TINT_DEPTH = 0.45f

    /** Overlay colour of a picture as opaque ARGB: its own darkest tone, darker still. */
    fun tintOf(pixels: IntArray, step: Int = 7): Int {
        if (pixels.isEmpty()) return 0xFF000000.toInt()
        val sample = IntArray((pixels.size + step - 1) / step) { pixels[it * step] }
        val lum = DoubleArray(sample.size) { i ->
            val p = sample[i]
            luminance((p shr 16 and 0xFF) / 255.0, (p shr 8 and 0xFF) / 255.0, (p and 0xFF) / 255.0)
        }
        val order = sample.indices.sortedBy { lum[it] }
        val p = sample[order[((order.size - 1) * TINT_PERCENTILE).toInt()]]
        val r = ((p shr 16 and 0xFF) * TINT_DEPTH).toInt()
        val g = ((p shr 8 and 0xFF) * TINT_DEPTH).toInt()
        val b = ((p and 0xFF) * TINT_DEPTH).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    /**
     * Scrim stops for one picture on one screen. [pixels] is ARGB of a (small) copy of the picture,
     * [width]×[height]; [fit] was computed for that copy and the screen [screenWidth]×[screenHeight].
     * Returns [ROWS] alphas, one per slab, already dilated and capped.
     */
    fun scrim(
        pixels: IntArray, width: Int, height: Int,
        fit: WallpaperFit.Fit, screenWidth: Float, screenHeight: Float,
        tint: Int = 0xFF000000.toInt(),
        columns: Int = 32, linesPerRow: Int = 6,
        /** 0.31.0: the blurred fill of [WallpaperFill] (ARGB, [fillWidth]×[fillHeight]); null = CLAMP strips. */
        fill: IntArray? = null, fillWidth: Int = 0, fillHeight: Int = 0
    ): FloatArray {
        val tr = (tint shr 16 and 0xFF) / 255.0
        val tg = (tint shr 8 and 0xFF) / 255.0
        val tb = (tint and 0xFF) / 255.0
        val raw = FloatArray(ROWS)
        if (width <= 0 || height <= 0 || pixels.size < width * height) return raw
        val lum = DoubleArray(columns * linesPerRow)
        val rgb = Array(columns * linesPerRow) { DoubleArray(3) }
        val useFill = fill != null && fillWidth > 0 && fillHeight > 0 && fill.size >= fillWidth * fillHeight &&
            WallpaperFill.needed(fit, width.toFloat(), height.toFloat(), screenWidth, screenHeight)
        val fillFit = if (useFill) WallpaperFill.fit(fit, width.toFloat(), fillWidth.toFloat()) else null
        for (row in 0 until ROWS) {
            var n = 0
            for (line in 0 until linesPerRow) {
                val sy = (row + (line + 0.5f) / linesPerRow) / ROWS * screenHeight
                // CLAMP extension: a screen row outside the picture shows the picture's edge row.
                val iy = ((sy - fit.dy) / fit.scale).toInt().coerceIn(0, height - 1)
                for (col in 0 until columns) {
                    val sx = (col + 0.5f) / columns * screenWidth
                    val ix = ((sx - fit.dx) / fit.scale).toInt().coerceIn(0, width - 1)
                    val p = pixels[iy * width + ix]
                    var r = (p shr 16 and 0xFF) / 255.0
                    var g = (p shr 8 and 0xFF) / 255.0
                    var b = (p and 0xFF) / 255.0
                    if (fillFit != null) {
                        // Exactly what is drawn: pic·m + fill·SHADE·(1 − m).
                        val m = WallpaperFill.mask(sx, sy, fit, width.toFloat(), height.toFloat(), screenWidth, screenHeight).toDouble()
                        if (m < 1.0) {
                            val fx = WallpaperFill.mirror(floor((sx - fillFit.dx) / fillFit.scale).toInt(), fillWidth)
                            val fy = WallpaperFill.mirror(floor((sy - fillFit.dy) / fillFit.scale).toInt(), fillHeight)
                            val q = fill!![fy * fillWidth + fx]
                            val k = WallpaperFill.SHADE * (1.0 - m)
                            r = r * m + (q shr 16 and 0xFF) / 255.0 * k
                            g = g * m + (q shr 8 and 0xFF) / 255.0 * k
                            b = b * m + (q and 0xFF) / 255.0 * k
                        }
                    }
                    rgb[n][0] = r; rgb[n][1] = g; rgb[n][2] = b
                    lum[n] = luminance(r, g, b)
                    n++
                }
            }
            val order = (0 until n).sortedBy { lum[it] }
            val pick = order[((n - 1) * PERCENTILE).toInt()]
            val (text, ratio) = requirement((row + 0.5f) / ROWS)
            val c = rgb[pick]
            raw[row] = alphaFor(c[0], c[1], c[2], limit(text, ratio), tr, tg, tb)
        }
        return dilate(smooth(raw))
    }

    /** How fast the scrim may fall off per slab: no visible step where a bright moon ends. */
    const val SLOPE = 0.07f

    /**
     * Cone smoothing: each slab takes max over j of (raw[j] − SLOPE·|i − j|). Never below raw[i]
     * (j = i), so it only adds darkness and the guarantee survives; it turns a hard 0 → 0.6 jump
     * into a soft ramp the eye reads as light, not as a band.
     */
    fun smooth(raw: FloatArray): FloatArray = FloatArray(raw.size) { i ->
        var m = 0f
        for (j in raw.indices) m = max(m, raw[j] - SLOPE * kotlin.math.abs(i - j))
        m
    }

    /** max(self, neighbours) + margin, capped: see the class comment for why this is exact. */
    fun dilate(raw: FloatArray): FloatArray = FloatArray(raw.size) { i ->
        val m = max(raw[i], max(raw.getOrElse(i - 1) { 0f }, raw.getOrElse(i + 1) { 0f }))
        if (m <= 0f) 0f else min(MAX_ALPHA, m + MARGIN)
    }
}

/** Order of the settings row: what is on now, then what was on recently, then the rest of the catalog. */
object WallpaperOrder {
    const val RECENT_LIMIT = 12
    const val ROW_LIMIT = 8

    fun row(current: String, recent: List<String>, catalog: List<String>, limit: Int = ROW_LIMIT): List<String> =
        (listOf(current) + recent.filter { it in catalog } + catalog).distinct().take(limit)

    /** The new recent list after [id] was set: it goes first, duplicates go, the tail is cut. */
    fun remember(id: String, recent: List<String>): List<String> = (listOf(id) + recent).distinct().take(RECENT_LIMIT)

    fun encode(recent: List<String>): String = recent.joinToString(",")

    fun decode(raw: String?): List<String> = raw.orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }
}
