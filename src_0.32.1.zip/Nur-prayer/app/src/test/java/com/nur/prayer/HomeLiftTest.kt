package com.nur.prayer

import com.nur.prayer.ui.home.HomeSpec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.30.2: the cards home stands a little higher, as a share of the free room (never a fixed offset). */
class HomeLiftTest {
    @Test fun theBlockStandsHigherThanTheMockButKeepsItsRoom() {
        val top = HomeSpec.Cards.WEIGHT_TOP
        val bottom = HomeSpec.Cards.WEIGHT_BOTTOM
        // The mock's measured split was 130 : 77 (sum 207); the sum is kept, the share moved up.
        assertEquals(207f, top + bottom, 1e-3f)
        assertTrue(top < 130f)
        val share = top / (top + bottom)
        assertTrue("share $share", share in 0.50f..0.60f)
        // Lift on the mock's own free height: noticeable, but a nudge.
        val liftDp = 130f - top
        assertTrue(liftDp in 8f..20f)
    }

    @Test fun theBigWordIsUntouched() {
        assertEquals(71f, HomeSpec.Big.WEIGHT_TOP, 0f)
        assertEquals(232f, HomeSpec.Big.WEIGHT_BOTTOM, 0f)
    }
}
