package com.nur.prayer

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.ui.home.BellState
import com.nur.prayer.ui.home.GlyphArt
import com.nur.prayer.ui.home.GlyphPath
import com.nur.prayer.ui.home.HomeIconData
import com.nur.prayer.ui.home.HomeMath
import com.nur.prayer.ui.home.HomeSpec
import com.nur.prayer.ui.home.RowState
import com.nur.prayer.ui.home.bellArt
import com.nur.prayer.ui.home.glyphOf
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import kotlin.math.hypot

/** 0.32.0: the designer's glyphs of the card list (art/home_icons → tools/home_icons.py → HomeIconData). */
class HomeGlyphsTest {

    private val prayers = listOf(
        HomeIconData.FAJR, HomeIconData.SUNRISE, HomeIconData.DHUHR,
        HomeIconData.ASR, HomeIconData.MAGHRIB, HomeIconData.ISHA
    )
    private val bells = listOf(HomeIconData.BELL_ON, HomeIconData.BELL_OFF, HomeIconData.BELL_RING)

    /** The end points of every segment of a command stream (the points the outline passes through). */
    private fun anchors(c: FloatArray): List<Pair<Float, Float>> {
        val out = ArrayList<Pair<Float, Float>>()
        var i = 0
        while (i < c.size) {
            when (c[i]) {
                GlyphPath.MOVE -> { out.add(c[i + 1] to c[i + 2]); i += 3 }
                GlyphPath.CUBIC -> { out.add(c[i + 5] to c[i + 6]); i += 7 }
                else -> i += 1
            }
        }
        return out
    }

    private fun anchorsOf(art: GlyphArt) = art.layers.flatMap { anchors(GlyphPath.parse(it.path)) }

    @Test fun theParserReadsMoveCubicAndClose() {
        assertArrayEquals(
            floatArrayOf(0f, 1f, 2f, 1f, 3f, 4f, 5f, 6f, 7f, 8f, 2f),
            GlyphPath.parse("M1 2C3 4 5 6 7 8Z"),
            0f
        )
        assertArrayEquals(
            floatArrayOf(0f, -0.5f, 10.25f, 1f, 0f, 0f, 0f, 0f, 1.5f, 2f, 2f),
            GlyphPath.parse("M-0.5 10.25C0 0 0 0 1.5 2Z"),
            0f
        )
        assertEquals(0, GlyphPath.parse("").size)
    }

    @Test fun theParserRefusesWhatItDoesNotKnow() {
        for (bad in listOf("M1", "M1 2C3 4 5 6 7", "L1 2", "M1 2 3", "Z1")) {
            try {
                GlyphPath.parse(bad)
                fail("accepted '$bad'")
            } catch (expected: IllegalArgumentException) {
                // the point
            }
        }
    }

    @Test fun everyGlyphIsMadeOfClosedLoopsOfCubics() {
        for (art in prayers + bells) {
            assertTrue(art.layers.isNotEmpty())
            for (layer in art.layers) {
                assertTrue(layer.alpha > 0f && layer.alpha <= 1f)
                val c = GlyphPath.parse(layer.path)
                var i = 0
                var open = false
                var cubics = 0
                while (i < c.size) {
                    when (c[i]) {
                        GlyphPath.MOVE -> { assertTrue("a loop inside a loop", !open); open = true; i += 3 }
                        GlyphPath.CUBIC -> { assertTrue("a cubic outside a loop", open); cubics++; i += 7 }
                        GlyphPath.CLOSE -> { assertTrue("a close without a loop", open); open = false; i += 1 }
                        else -> fail("unknown command ${c[i]}")
                    }
                }
                assertTrue(!open)
                assertTrue(cubics >= 3)
            }
            // The ink is always there at full strength, so a glyph is never only a faint shadow.
            assertTrue(art.layers.any { it.alpha == 1f && !it.accent })
        }
    }

    @Test fun everyPointIsInsideItsViewport() {
        for (art in prayers + bells) for ((x, y) in anchorsOf(art)) {
            assertTrue("x=$x of ${art.width}", x >= -1f && x <= art.width + 1f)
            assertTrue("y=$y", y >= -1f && y <= art.height + 1f)
        }
    }

    @Test fun aPrayerGlyphNeverLeavesTheCircleItSitsOn() {
        // The viewport is the 100×100 box of the 26 dp circle: the circle is the disc of radius 50 at (50, 50).
        for (art in prayers) {
            assertEquals(100f, art.width, 0f)
            assertEquals(100f, art.height, 0f)
            val r = anchorsOf(art).maxOf { (x, y) -> hypot(x - 50f, y - 50f) }
            assertTrue("reaches $r", r <= 48f)
            val xs = anchorsOf(art).map { it.first }
            // And it is a real glyph: neither a speck nor wall to wall.
            assertTrue(xs.max() - xs.min() in 40f..90f)
        }
    }

    @Test fun eachPrayerHasItsOwnGlyphInTheOrderOfTheList() {
        val order = listOf(Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)
        assertEquals(6, order.map { glyphOf(it) }.toSet().size)
        order.forEachIndexed { i, p -> assertSame(prayers[i], glyphOf(p)) }
    }

    @Test fun theBellStatesAreThreeDistinctGlyphsAndOnlyTheOnOneHasADot() {
        assertEquals(3, BellState.entries.map { bellArt(it) }.toSet().size)
        assertSame(HomeIconData.BELL_OFF, bellArt(BellState.OFF))
        assertSame(HomeIconData.BELL_ON, bellArt(BellState.ON))
        assertSame(HomeIconData.BELL_RING, bellArt(BellState.RINGING))
        assertEquals(1, HomeIconData.BELL_ON.layers.count { it.accent })
        assertEquals(0, HomeIconData.BELL_OFF.layers.count { it.accent })
        assertEquals(0, HomeIconData.BELL_RING.layers.count { it.accent })
        // One shared viewport: the bell does not jump when the state changes.
        for (b in bells) {
            assertEquals(bells[0].width, b.width, 0f)
            assertEquals(100f, b.height, 0f)
        }
    }

    @Test fun theBellBoxHasTheShapeOfTheViewport() {
        val aspect = HomeSpec.Cards.BELL / HomeSpec.Cards.BELL_H
        assertEquals(HomeIconData.BELL_ON.width / HomeIconData.BELL_ON.height, aspect, 0.01f)
    }

    @Test fun theBellFollowsTheSwitchAndTheWindowGoingOnNow() {
        for (s in RowState.entries) assertEquals(BellState.OFF, HomeMath.bellState(false, s))
        assertEquals(BellState.RINGING, HomeMath.bellState(true, RowState.CURRENT))
        for (s in RowState.entries.filter { it != RowState.CURRENT }) {
            assertEquals(BellState.ON, HomeMath.bellState(true, s))
        }
    }

    @Test fun theNamesAreBiggerAndTheCardIsTheSame() {
        assertTrue(HomeSpec.Cards.TITLE >= 17f)
        assertTrue(HomeSpec.Cards.SUB >= 12.5f)
        assertEquals(49f, HomeSpec.Cards.CARD_HEIGHT, 0f)
        assertEquals(26f, HomeSpec.Cards.ICON_DIAMETER, 0f)
        // The baselines are fixed, so a bigger name has to fit between the card's top and the line below it.
        val titleCap = HomeSpec.Cards.TITLE * 0.72f
        assertTrue(HomeSpec.Cards.TITLE_BASELINE - titleCap >= 8f)
        assertTrue(HomeSpec.Cards.SUB_BASELINE + HomeSpec.Cards.SUB * 0.28f <= HomeSpec.Cards.CARD_HEIGHT - 6f)
    }
}
