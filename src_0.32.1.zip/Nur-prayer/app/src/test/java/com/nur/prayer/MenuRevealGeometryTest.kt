package com.nur.prayer

import com.nur.prayer.ui.MenuRevealMotion
import com.nur.prayer.ui.RevealGeometry
import com.nur.prayer.ui.components.RevealMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 0.30.2: home and a menu page cross-fade by one number, with nothing opaque added (the black veil of 0.30.1 is
 * what made the wallpaper flash dark on every close).
 */
class MenuRevealGeometryTest {
    @Test fun homeIsAloneAtTheStartAndThePageAtTheEnd() {
        assertEquals(1f, RevealGeometry.homeAlpha(0f), 0f)
        assertEquals(0f, RevealGeometry.pageAlpha(0f), 0f)
        assertEquals(0f, RevealGeometry.homeAlpha(1f), 0f)
        assertEquals(1f, RevealGeometry.pageAlpha(1f), 0f)
    }

    @Test fun neitherLayerLeavesAHoleNorBothStandAtFullStrength() {
        for (i in 0..1000) {
            val m = i / 1000f
            val home = RevealGeometry.homeAlpha(m)
            val page = RevealGeometry.pageAlpha(m)
            assertTrue("hole at $m: ${home + page}", home + page >= 0.69f)
            assertTrue("both up at $m", home < 0.999f || page < 0.001f)
            assertTrue("both up at $m", page < 0.999f || home < 0.001f)
        }
    }

    @Test fun thePageIsHiddenForItsFirstFramesAndFullBeforeTheEnd() {
        // The long first frame (the page is composed there) must fall into the hidden part.
        assertEquals(0f, RevealGeometry.pageAlpha(RevealGeometry.PAGE_IN_FROM), 0f)
        assertEquals(1f, RevealGeometry.pageAlpha(RevealGeometry.PAGE_IN_FROM + RevealGeometry.PAGE_IN_SPAN), 1e-6f)
        assertTrue(RevealGeometry.PAGE_IN_FROM + RevealGeometry.PAGE_IN_SPAN <= 0.65f)
        assertEquals(0f, RevealGeometry.homeAlpha(RevealGeometry.HOME_OUT_SPAN), 0f)
    }

    @Test fun pageAndHomeStayInTheirScaleRange() {
        assertEquals(MenuRevealMotion.PAGE_SCALE, RevealGeometry.pageScale(0f), 1e-6f)
        assertEquals(1f, RevealGeometry.pageScale(1f), 1e-6f)
        assertEquals(1f, RevealGeometry.homeScale(0f), 1e-6f)
        assertEquals(MenuRevealMotion.HOME_SCALE, RevealGeometry.homeScale(1f), 1e-6f)
        assertEquals(1f, RevealGeometry.pageScale(3f), 1e-6f)
        assertTrue(MenuRevealMotion.PAGE_SCALE in 0.9f..0.97f)
    }

    @Test fun timingsAreShortAndTheWayOutIsQuicker() {
        assertTrue(MenuRevealMotion.OPEN_MILLIS in 280..380)
        assertTrue(MenuRevealMotion.CLOSE_MILLIS in 200..300)
        assertTrue(MenuRevealMotion.CLOSE_MILLIS < MenuRevealMotion.OPEN_MILLIS)
    }

    @Test fun theSettleCurveStartsFastAndLandsSoftly() {
        val curve = RevealMath.Settle
        assertEquals(0f, curve.transform(0f), 1e-4f)
        assertEquals(1f, curve.transform(1f), 1e-4f)
        assertTrue("fast start", curve.transform(0.3f) > 0.7f)
        var last = -1f
        for (i in 0..200) {
            val v = curve.transform(i / 200f)
            assertTrue("monotonic", v >= last - 1e-6f)
            last = v
        }
    }
}
