#!/usr/bin/env python3
"""check_visibility must catch the 0.32.0 build failure and stay quiet on the legal layouts."""
import os, subprocess, sys, tempfile, textwrap, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def run_on(files):
    """Run the checker on a throwaway src tree."""
    import importlib, check_visibility, kt_symbols
    with tempfile.TemporaryDirectory() as d:
        root = os.path.join(d, "app", "src")
        os.makedirs(root)
        for name, body in files.items():
            with open(os.path.join(root, name), "w", encoding="utf-8") as f:
                f.write(textwrap.dedent(body))
        old = kt_symbols.ROOT
        kt_symbols.ROOT = root
        try:
            import io, contextlib
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                code = check_visibility.main()
            return code, buf.getvalue()
        finally:
            kt_symbols.ROOT = old


class VisibilityTest(unittest.TestCase):
    def test_public_function_returning_internal_type_fails(self):
        code, out = run_on({"A.kt": """
            package p
            internal enum class BellState { OFF, ON }
            object HomeMath {
                fun bellState(enabled: Boolean): BellState = if (enabled) BellState.ON else BellState.OFF
            }
        """})
        self.assertEqual(code, 1)
        self.assertIn("BellState", out)

    def test_internal_function_and_default_values_and_bodies_pass(self):
        code, out = run_on({"A.kt": """
            package p
            internal enum class BellState { OFF, ON }
            internal object Paper { val Ink = 1 }
            object HomeMath {
                internal fun bellState(enabled: Boolean): BellState = BellState.ON
                fun other(x: Int): Int {
                    val local: BellState = BellState.OFF
                    return x
                }
            }
            fun calendar(
                a: Int,
                ink: Int = Paper.Ink
            ) {
                val ring = Paper.Ink
            }
            internal fun again(s: BellState) {}
        """})
        self.assertEqual(code, 0, out)

    def test_public_property_and_parameter_fail(self):
        code, out = run_on({"A.kt": """
            package p
            internal class Hidden
            class Holder {
                val h: Hidden? = null
            }
            fun take(h: Hidden) {}
        """})
        self.assertEqual(code, 1)
        self.assertIn("замечаний 2", out)

    def test_private_top_level_type_is_per_file(self):
        code, out = run_on({"A.kt": """
            package p
            private class Secret
            fun leak(s: Secret) {}
        """, "B.kt": """
            package p
            fun fine(s: Int) {}
        """})
        self.assertEqual(code, 1)

    def test_the_real_tree_is_clean(self):
        r = subprocess.run([sys.executable, os.path.join(HERE, "check_visibility.py")], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stdout)


if __name__ == "__main__":
    unittest.main()
