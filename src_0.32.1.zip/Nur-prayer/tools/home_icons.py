#!/usr/bin/env python3
"""Home-screen glyphs (0.32.0): the six prayer icons and the three bell states, vectorised from the
designer's raster sheets in art/home_icons/ into cubic Béziers.

    python3 tools/home_icons.py build      # art/home_icons/*.png -> HomeIconData.kt   (dev machine, needs
                                            # numpy, scipy, opencv-python, matplotlib/contourpy)
    python3 tools/home_icons.py preview P  # render the fitted vectors next to the source, to P (png)
    python3 tools/home_icons.py check      # stdlib only: the generated Kotlin is well formed

How a glyph is made. Every glyph is a few flat-colour layers on a cream tile. For each layer we blur the
luminance by ≈1 px (kills the sheet's JPEG noise), take the sub-pixel iso-line half way between the tile
colour and the layer's own ink (so the outline sits exactly on the anti-aliased edge, not on a pixel
boundary), and fit Schneider cubic Béziers with corners kept sharp (`bezfit.py`). Maximum deviation from
the iso-line is `err` px of the source (≈ 0.1 % of the circle diameter); outlines are the designer's, not ours.

Colours are NOT taken from the sheet: the app tints a glyph by the state of its card exactly as the
mock screen does (past — ink, current — amber, next — dark on gold). A layer carries only its strength
(`alpha`, the share of the ink it has in the sheet) and whether it is the small accent (the notification dot).

Coordinates. Prayer glyphs: a 100×100 viewport = a square of PRAYER_SIDE sheet pixels centred on the tile
centre, so one glyph keeps its place, its size and its size relative to the others from the sheet; the app
puts that square on the 26 dp circle. Bell glyphs: an 84.44×100 viewport = the union box of the three bells (13 × 15.4 dp in the app).
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SHEET = ROOT / 'art/home_icons/prayer_sheet.png'
BELLS = ROOT / 'art/home_icons/bell_states.png'
OUT = ROOT / 'app/src/main/java/com/nur/prayer/ui/home/HomeIconData.kt'

TILE = (325, 315)                  # prayer tile, sheet px (w, h)
TILE_CENTER = (162.5, 157.5)
PRAYER_SIDE = 270.0                # sheet px that map to the 26 dp circle
PRAYER_TILES = {'fajr': (179, 147), 'sunrise': (605, 147), 'dhuhr': (1032, 147),
                'asr': (179, 551), 'maghrib': (605, 551), 'isha': (1032, 551)}
PRAYER_BG = 224.0                  # luminance of the circle the glyphs sit on

BELL_TILE = (135, 135)
BELL_TILES = {'on': (158, 71), 'off': (473, 70), 'ring': (787, 70)}
BELL_BG = 231.0
BELL_BOX = (33.0, 23.0, 109.0, 113.0)   # x0, y0, x1, y1 of the three bells together

FULL = (25, 290, 25, 300)
# role: ink = full strength; soft/faint = the paler layers (alpha measured from the sheet); accent = the dot.
PRAYER = {
    'fajr':    [dict(alpha=1.00, guess=95,  roi=(25, 200, 25, 300)),
                dict(alpha=0.23, guess=200, roi=(200, 262, 25, 300), blur=1.0)],
    'sunrise': [dict(alpha=1.00, guess=80,  roi=FULL)],
    'dhuhr':   [dict(alpha=1.00, guess=95,  roi=FULL)],
    'asr':     [dict(alpha=1.00, guess=85,  roi=(25, 198, 25, 300)),
                dict(alpha=0.58, guess=140, roi=(198, 262, 25, 300))],
    'maghrib': [dict(alpha=1.00, guess=110, roi=FULL)],
    'isha':    [dict(alpha=1.00, guess=85,  roi=FULL)],
}
DOT = (88, 112, 22, 48)            # centroid box of the notification dot
SLASH = (60, 80, 60, 90)           # centroid box of the "muted" slash
BELL_ROI = (10, 125, 10, 125)
BELL = {
    'on':   [dict(alpha=1.00, guess=90,  roi=BELL_ROI, skip=[DOT]),
             dict(alpha=1.00, guess=140, roi=BELL_ROI, pick=[DOT], minarea=60, accent=True)],
    'off':  [dict(alpha=0.86, guess=96,  roi=BELL_ROI, skip=[SLASH]),
             dict(alpha=1.00, guess=75,  roi=BELL_ROI, pick=[SLASH])],
    'ring': [dict(alpha=1.00, guess=125, roi=BELL_ROI)],
}
UP = 8


def _outlines(L, lb, spec):
    import cv2
    import contourpy
    import numpy as np
    from scipy import ndimage as ndi
    r0, r1, c0, c1 = spec['roi']
    rough = np.zeros(L.shape, bool)
    rough[r0:r1, c0:c1] = L[r0:r1, c0:c1] < (lb + spec['guess']) / 2
    lab, _ = ndi.label(rough)
    keep = np.zeros(L.shape, bool)
    for i, _sl in enumerate(ndi.find_objects(lab), 1):
        reg = lab == i
        if reg.sum() < spec.get('minarea', 40):
            continue
        ys, xs = np.where(reg)
        cx, cy = xs.mean(), ys.mean()
        inside = lambda b: b[0] <= cx < b[1] and b[2] <= cy < b[3]
        if spec.get('pick') and not any(inside(b) for b in spec['pick']):
            continue
        if spec.get('skip') and any(inside(b) for b in spec['skip']):
            continue
        keep |= reg
    px = L[keep]
    link = float(np.median(px[px <= np.percentile(px, 30)]))
    level = (lb + link) / 2
    sel = ndi.binary_dilation(keep, iterations=3)
    F = np.minimum(np.where(sel, L, lb), lb).astype(np.float32)
    ys, xs = np.where(sel)
    y0, y1, x0, x1 = max(ys.min() - 2, 0), ys.max() + 3, max(xs.min() - 2, 0), xs.max() + 3
    big = cv2.resize(F[y0:y1, x0:x1], None, fx=UP, fy=UP, interpolation=cv2.INTER_CUBIC)
    loops = []
    for ln in contourpy.contour_generator(z=-big).lines(-level):
        ln = np.asarray(ln)
        if len(ln) >= 8:
            loops.append(np.c_[(ln[:, 0] + 0.5) / UP + x0, (ln[:, 1] + 0.5) / UP + y0])
    return loops


def _glyphs(image, tiles, size, bg, table, to_view, blur, err, arm, turn):
    import cv2
    import numpy as np
    sys.path.insert(0, str(Path(__file__).parent))
    from bezfit import fit_closed
    from PIL import Image
    src = np.asarray(Image.open(image).convert('RGB')).astype(float)
    out = {}
    for name, layers in table.items():
        x, y = tiles[name]
        tile = src[y:y + size[1], x:x + size[0]]
        L = (tile @ np.array([.299, .587, .114])).astype(np.float32)
        L[L < 40] = bg                       # the black corners of a rounded tile are not ink
        res = []
        for spec in layers:
            b = spec.get('blur', blur)
            Ls = cv2.GaussianBlur(L, (0, 0), b)
            segs = []
            for lp in _outlines(Ls, bg, spec):
                segs.append(fit_closed(lp, err=err, arm_px=arm, min_turn=turn))
            res.append((spec, [[to_view(c) for c in s] for s in segs]))
        out[name] = res
    return out


def _path(loops):
    parts = []
    f = lambda v: ('%.2f' % v).rstrip('0').rstrip('.')
    for segs in loops:
        p0 = segs[0][0]
        parts.append('M%s %s' % (f(p0[0]), f(p0[1])))
        for c in segs:
            parts.append('C' + ' '.join('%s %s' % (f(p[0]), f(p[1])) for p in c[1:]))
        parts.append('Z')
    return ''.join(parts)


def build():
    import numpy as np
    k = 100.0 / PRAYER_SIDE
    cx, cy = TILE_CENTER
    prayer_view = lambda c: np.c_[50 + (c[:, 0] - cx) * k, 50 + (c[:, 1] - cy) * k]
    bx0, by0, bx1, by1 = BELL_BOX
    kb = 100.0 / (by1 - by0)
    bell_view = lambda c: np.c_[(c[:, 0] - bx0) * kb, (c[:, 1] - by0) * kb]
    prayers = _glyphs(SHEET, PRAYER_TILES, TILE, PRAYER_BG, PRAYER, prayer_view, 1.0, 0.3, 2.0, 55)
    bells = _glyphs(BELLS, BELL_TILES, BELL_TILE, BELL_BG, BELL, bell_view, 0.7, 0.15, 1.2, 55)
    lines = [
        'package com.nur.prayer.ui.home', '',
        '// GENERATED by tools/home_icons.py from art/home_icons/*.png. Do not edit by hand.', '',
        '/** One flat layer of a glyph: its strength against the glyph colour and an even-odd outline. */',
        'internal class GlyphLayer(val alpha: Float, val accent: Boolean, val path: String)', '',
        '/** A glyph in a [width]×[height] viewport. */',
        'internal class GlyphArt(val width: Float, val height: Float, val layers: List<GlyphLayer>)', '',
        'internal object HomeIconData {',
        '    /** Prayer glyphs: 100×100 viewport that sits on the 26 dp circle. */',
    ]

    def emit(name, res, w, h):
        out = ['    val %s = GlyphArt(%sf, %sf, listOf(' % (name, w, h)]
        for spec, loops in res:
            out.append('        GlyphLayer(%sf, %s, "%s"),' % (spec['alpha'], str(bool(spec.get('accent'))).lower(), _path(loops)))
        out.append('    ))')
        return out

    for n in ('fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'):
        lines += emit(n.upper(), prayers[n], '100', '100')
    lines += ['', '    /** Bell states: the union box of the three bells, 100 units tall. */']
    bw = round((bx1 - bx0) * kb, 2)
    for n in ('on', 'off', 'ring'):
        lines += emit('BELL_' + n.upper(), bells[n], ('%g' % bw), '100')
    lines += ['}', '']
    OUT.write_text('\n'.join(lines), encoding='utf-8')
    print('wrote', OUT.relative_to(ROOT), OUT.stat().st_size, 'bytes')


def _read_kotlin():
    """name -> (width, height, [(alpha, accent, [loops of cubic segments])]) from the generated file."""
    s = OUT.read_text(encoding='utf-8')
    arts = {}
    for m in re.finditer(r'val ([A-Z_]+) = GlyphArt\(([\d.]+)f, ([\d.]+)f, listOf\((.*?)\n    \)\)', s, re.S):
        name, w, h, body = m.groups()
        layers = []
        for lm in re.finditer(r'GlyphLayer\(([\d.]+)f, (true|false), "([^"]*)"\)', body):
            loops = []
            for lp in re.findall(r'M[^Z]*Z', lm.group(3)):
                nums = [float(v) for v in re.findall(r'-?[\d.]+', lp)]
                p0 = (nums[0], nums[1])
                segs, cur, rest = [], p0, nums[2:]
                for i in range(0, len(rest), 6):
                    c = rest[i:i + 6]
                    segs.append([cur, (c[0], c[1]), (c[2], c[3]), (c[4], c[5])])
                    cur = (c[4], c[5])
                loops.append(segs)
            layers.append((float(lm.group(1)), lm.group(2) == 'true', loops))
        arts[name] = (float(w), float(h), layers)
    return arts


def raster(art, box_w, box_h, color, accent, bg, ss=4):
    """Draw like HomeGlyphs.kt does: fit into the box, centred, each layer at its strength; even-odd fill."""
    import cv2
    import numpy as np
    w, h, layers = art
    W, H = int(round(box_w * ss)), int(round(box_h * ss))
    img = np.empty((H, W, 3), np.float32)
    img[:] = bg
    k = min(W / w, H / h)
    ox, oy = (W - w * k) / 2, (H - h * k) / 2
    for alpha, is_accent, loops in layers:
        mask = np.zeros((H, W), np.uint8)
        for segs in loops:
            pts = []
            for p0, p1, p2, p3 in segs:
                t = np.linspace(0, 1, 20, endpoint=False)[:, None]
                P = [np.array(q) for q in (p0, p1, p2, p3)]
                pts.append((1 - t) ** 3 * P[0] + 3 * (1 - t) ** 2 * t * P[1] + 3 * (1 - t) * t ** 2 * P[2] + t ** 3 * P[3])
            pts = np.vstack(pts) * k + (ox, oy)
            m = np.zeros((H, W), np.uint8)
            cv2.fillPoly(m, [np.round(pts * 16).astype(np.int32)], 255, lineType=cv2.LINE_AA, shift=4)
            mask ^= m
        a = (mask / 255.0 * alpha)[..., None]
        img = img * (1 - a) + np.array(accent if is_accent else color, np.float32) * a
    return cv2.resize(img, (int(box_w), int(box_h)), interpolation=cv2.INTER_AREA)


def preview(path):
    """The six cards of the home list as the app draws them (3x density), to eyeball the result."""
    import cv2
    import numpy as np
    arts = _read_kotlin()
    ink, amber, gold_card, on_gold = (28, 26, 22), (138, 82, 0), (236, 178, 92), (70, 44, 10)
    card = (243, 236, 227)
    rows = [('FAJR', 'OFF', 'past'), ('SUNRISE', 'OFF', 'past'), ('DHUHR', 'ON', 'past'),
            ('ASR', 'ON', 'upcoming'), ('MAGHRIB', 'RING', 'current'), ('ISHA', 'ON', 'next')]
    S = 3
    canvas = np.full((len(rows) * 52 * S + 8 * S, 360 * S, 3), 70, np.float32)
    for r, (pr, bell, st) in enumerate(rows):
        y0 = (4 + r * 52) * S
        bg = gold_card if st == 'next' else card
        canvas[y0:y0 + 49 * S, 8 * S:352 * S] = bg
        glyph = {'past': ink, 'upcoming': ink, 'current': amber, 'next': on_gold}[st]
        a = {'past': .72, 'upcoming': .88, 'current': 1, 'next': 1}[st]
        circ = np.array(bg, float) * (1 - .08) + np.array(ink, float) * .08
        cx, cy, d = (8 + 12 + 13) * S, y0 + 24.5 * S, 26 * S
        yy, xx = np.ogrid[:canvas.shape[0], :canvas.shape[1]]
        canvas[(xx - cx) ** 2 + (yy - cy) ** 2 <= (d / 2) ** 2] = circ
        col = np.array(bg, float) * (1 - a) + np.array(glyph, float) * a
        g = raster(arts[pr], 26 * S, 26 * S, col, col, circ)
        gy, gx = int(cy - 13 * S), int(cx - 13 * S)
        canvas[gy:gy + 26 * S, gx:gx + 26 * S] = np.where(
            ((np.mgrid[:26 * S, :26 * S][0] - 13 * S) ** 2 + (np.mgrid[:26 * S, :26 * S][1] - 13 * S) ** 2 <= (13 * S) ** 2)[..., None],
            g, canvas[gy:gy + 26 * S, gx:gx + 26 * S])
        ba = {'past': .55, 'upcoming': .75, 'current': .75, 'next': .88}[st]
        bcol = np.array(bg, float) * (1 - ba) + np.array(glyph if st == 'next' else ink, float) * ba
        if bell == 'RING':
            bcol = np.array(amber, float)
        dot = np.array(on_gold if st == 'next' else amber, float)
        art = arts['BELL_' + bell]
        bw, bh = 13 * S, 15.4 * S
        b = raster(art, bw, bh, bcol, dot, bg)
        by, bx = int(cy - bh / 2), int(352 * S - 14 * S - bw)
        canvas[by:by + b.shape[0], bx:bx + b.shape[1]] = b
        cv2.putText(canvas, pr.title(), (int(55 * S), int(y0 + 23 * S)), cv2.FONT_HERSHEY_SIMPLEX, 0.9, tuple(float(v) for v in glyph), 2)
    cv2.imwrite(path, canvas[..., ::-1].astype(np.uint8))
    print('wrote', path)


def check():
    s = OUT.read_text(encoding='utf-8')
    problems = []
    names = re.findall(r'val ([A-Z_]+) = GlyphArt\(([\d.]+)f, ([\d.]+)f', s)
    want = ['FAJR', 'SUNRISE', 'DHUHR', 'ASR', 'MAGHRIB', 'ISHA', 'BELL_ON', 'BELL_OFF', 'BELL_RING']
    if [n for n, _, _ in names] != want:
        problems.append('glyph list %s != %s' % ([n for n, _, _ in names], want))
    for m in re.finditer(r'GlyphLayer\(([\d.]+)f, (true|false), "([^"]*)"\)', s):
        d = m.group(3)
        if not re.fullmatch(r'(?:M-?[\d.]+ -?[\d.]+(?:C(?:-?[\d.]+ -?[\d.]+ ?){3})+Z)+', d):
            problems.append('bad path ' + d[:40])
        for v in re.findall(r'-?[\d.]+', d):
            if not -10 <= float(v) <= 120:
                problems.append('coordinate out of the viewport: ' + v)
    print('PASS %d glyphs' % len(names) if not problems else 'FAIL\n' + '\n'.join(problems[:10]))
    return 1 if problems else 0


if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'check'
    if cmd == 'build':
        build()
    elif cmd == 'preview':
        preview(sys.argv[2] if len(sys.argv) > 2 else 'home_icons_preview.png')
    elif cmd == 'check':
        sys.exit(check())
    else:
        print(__doc__)
        sys.exit(2)
