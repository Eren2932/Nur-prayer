"""Philip J. Schneider's curve fitting ("An Algorithm for Automatically Fitting Digitized Curves",
Graphics Gems, 1990) plus corner splitting, stdlib + numpy only. Used by home_icons.py to turn the
sub-pixel outline of a raster glyph into a handful of cubic Béziers.
"""
import numpy as np


def _bez(ctrl, t):
    t = np.asarray(t)[:, None]
    mt = 1 - t
    return mt ** 3 * ctrl[0] + 3 * mt ** 2 * t * ctrl[1] + 3 * mt * t ** 2 * ctrl[2] + t ** 3 * ctrl[3]


def _bez_d1(ctrl, t):
    t = np.asarray(t)[:, None]
    mt = 1 - t
    return 3 * mt ** 2 * (ctrl[1] - ctrl[0]) + 6 * mt * t * (ctrl[2] - ctrl[1]) + 3 * t ** 2 * (ctrl[3] - ctrl[2])


def _bez_d2(ctrl, t):
    t = np.asarray(t)[:, None]
    mt = 1 - t
    return 6 * mt * (ctrl[2] - 2 * ctrl[1] + ctrl[0]) + 6 * t * (ctrl[3] - 2 * ctrl[2] + ctrl[1])


def _unit(v):
    n = np.linalg.norm(v)
    return v / n if n > 1e-12 else v


def _chord_params(pts):
    d = np.r_[0, np.cumsum(np.linalg.norm(np.diff(pts, axis=0), axis=1))]
    return d / d[-1] if d[-1] > 0 else d


def _generate(pts, u, t1, t2):
    p0, p3 = pts[0], pts[-1]
    A1 = np.array([t1 * 3 * (1 - x) ** 2 * x for x in u])
    A2 = np.array([t2 * 3 * (1 - x) * x ** 2 for x in u])
    C = np.zeros((2, 2)); X = np.zeros(2)
    for i, x in enumerate(u):
        C[0, 0] += A1[i] @ A1[i]; C[0, 1] += A1[i] @ A2[i]; C[1, 1] += A2[i] @ A2[i]
        tmp = pts[i] - (p0 * ((1 - x) ** 3 + 3 * (1 - x) ** 2 * x) + p3 * (3 * (1 - x) * x ** 2 + x ** 3))
        X[0] += A1[i] @ tmp; X[1] += A2[i] @ tmp
    C[1, 0] = C[0, 1]
    det = C[0, 0] * C[1, 1] - C[1, 0] * C[0, 1]
    seg = np.linalg.norm(p3 - p0)
    if abs(det) > 1e-12:
        a1 = (X[0] * C[1, 1] - X[1] * C[0, 1]) / det
        a2 = (C[0, 0] * X[1] - C[1, 0] * X[0]) / det
    else:
        a1 = a2 = 0
    eps = 1e-6 * seg
    if a1 < eps or a2 < eps:
        a1 = a2 = seg / 3
    return np.array([p0, p0 + t1 * a1, p3 + t2 * a2, p3])


def _reparam(ctrl, pts, u):
    out = np.array(u, float)
    q = _bez(ctrl, u); q1 = _bez_d1(ctrl, u); q2 = _bez_d2(ctrl, u)
    for i in range(len(u)):
        d = q[i] - pts[i]
        num = d @ q1[i]
        den = q1[i] @ q1[i] + d @ q2[i]
        if abs(den) > 1e-12:
            out[i] = min(1.0, max(0.0, u[i] - num / den))
    return out


def _max_err(ctrl, pts, u):
    d = np.linalg.norm(_bez(ctrl, u) - pts, axis=1)
    i = int(np.argmax(d))
    return d[i], i


def fit_cubic(pts, t1, t2, err):
    """Fit an open polyline with unit end tangents t1 (outward from start) and t2 (outward from end)."""
    pts = np.asarray(pts, float)
    if len(pts) == 2:
        dist = np.linalg.norm(pts[1] - pts[0]) / 3
        return [np.array([pts[0], pts[0] + t1 * dist, pts[1] + t2 * dist, pts[1]])]
    u = _chord_params(pts)
    ctrl = _generate(pts, u, t1, t2)
    e, split = _max_err(ctrl, pts, u)
    if e < err:
        return [ctrl]
    if e < err * 16:
        for _ in range(24):
            u = _reparam(ctrl, pts, u)
            ctrl = _generate(pts, u, t1, t2)
            e, split = _max_err(ctrl, pts, u)
            if e < err:
                return [ctrl]
    split = min(max(split, 1), len(pts) - 2)
    tc = _unit(pts[split - 1] - pts[split + 1])
    return fit_cubic(pts[:split + 1], t1, tc, err) + fit_cubic(pts[split:], -tc, t2, err)


def resample_closed(loop, step):
    loop = np.asarray(loop, float)
    if np.allclose(loop[0], loop[-1]):
        loop = loop[:-1]
    ring = np.vstack([loop, loop[:1]])
    seg = np.linalg.norm(np.diff(ring, axis=0), axis=1)
    cum = np.r_[0, np.cumsum(seg)]
    n = max(8, int(round(cum[-1] / step)))
    s = np.linspace(0, cum[-1], n, endpoint=False)
    return np.c_[np.interp(s, cum, ring[:, 0]), np.interp(s, cum, ring[:, 1])]


def find_corners(ring, arm, min_turn_deg):
    """Indices of corners of a closed, uniformly resampled outline: the turn between the chord
    arriving from `arm` samples back and the chord leaving `arm` samples ahead, local maxima only."""
    n = len(ring)
    a = ring - np.roll(ring, arm, axis=0)
    b = np.roll(ring, -arm, axis=0) - ring
    cross = a[:, 0] * b[:, 1] - a[:, 1] * b[:, 0]
    dot = (a * b).sum(1)
    turn = np.degrees(np.abs(np.arctan2(cross, dot)))
    out = []
    for i in range(n):
        if turn[i] < min_turn_deg:
            continue
        w = [turn[(i + k) % n] for k in range(-arm, arm + 1)]
        if turn[i] >= max(w) - 1e-9:
            if not out or (i - out[-1]) > arm:
                out.append(i)
    if len(out) > 1 and (out[0] + n - out[-1]) <= arm:
        out.pop()
    return out


def fit_closed(loop, err=0.12, step=0.25, arm_px=1.6, min_turn=48):
    """Closed outline -> list of cubic control arrays, corners kept sharp."""
    ring = resample_closed(loop, step)
    n = len(ring)
    arm = max(2, int(round(arm_px / step)))
    corners = find_corners(ring, arm, min_turn)
    segs = []
    if not corners:
        t = _unit(ring[1] - ring[-1])
        pts = np.vstack([ring, ring[:1]])
        return fit_cubic(pts, t, -t, err)
    k = len(corners)
    for j in range(k):
        i0, i1 = corners[j], corners[(j + 1) % k]
        idx = [(i0 + m) % n for m in range(((i1 - i0) % n) + 1)] if i1 != i0 else list(range(n)) + [i0]
        pts = ring[idx]
        if len(pts) < 3:
            segs.append(np.array([pts[0], pts[0], pts[-1], pts[-1]]))
            continue
        # One-sided tangents estimated over a short run keep the corner sharp without jitter.
        m = min(max(3, arm), len(pts) - 1)
        t1 = _unit(pts[m] - pts[0])
        t2 = _unit(pts[-1 - m] - pts[-1])
        segs += fit_cubic(pts, t1, t2, err)
    return segs
