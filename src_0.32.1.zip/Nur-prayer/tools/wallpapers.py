#!/usr/bin/env python3
"""0.22.0 wallpapers: one pipeline from a picture in `art/wallpapers/` to a ready asset.

    python3 tools/wallpapers.py build     # needs Pillow: trim, encode, lock (run after adding a picture)
    python3 tools/wallpapers.py check     # stdlib only, runs in CI

Adding a wallpaper is two steps:
  1. drop `art/wallpapers/<id>.jpg|png|webp` (id = lowercase latin, digits, `_`) and run `build`;
     it prints the suggested focus point of the picture;
  2. add one line to `WallpaperCatalog.kt` (`image("<id>", <category>, fx, fy) { tr("Название") }`).
Everything else — crop on any screen, contrast scrim, thumbnails, gallery sections, order — is
computed by the app from the picture itself.

What `build` does to each picture:
  * trims the thin dark frame AI upscalers leave on the edges (measured, up to 6 px a side, and only
    when the edge is *darker* than the picture inside it: 0.31.0 — the old rule took the texture of
    water, stone or a crowd at a photo's edge for a frame and cut 13 px of real picture);
  * brings the long side to 2560 px (QHD+ phones): a bigger picture is shrunk, and since 0.31.0 a
    smaller one is enlarged once here with Lanczos-3 instead of by the GPU's bilinear filter on every
    frame (+0.6 dB PSNR measured on the 0.31.0 pack, visibly crisper domes and calligraphy);
  * encodes WebP q90, method 6, sharp YUV: flat illustrations, gradient skies — this keeps the
    sky free of banding at ~1/4 of the JPEG size;
  * records the sha256, the size and a saliency focus in `art/wallpapers/wallpapers.lock.json`,
    plus `suggestedLight`: whether the calendar's dark ink (Paper.Ink) keeps 4.5:1 on the darkest
    10 % of the header band — the measured rule behind `light = true` in the catalog.

`build` is incremental since 0.31.0: pictures already in the lock are left byte-for-byte alone
(re-encoding them with another Pillow would change every asset for nothing). `build --force` or
`build <id> …` rebuilds on purpose.

What `check` proves (no Pillow needed): every catalog id has its asset and every asset its
catalog line; the asset bytes are the locked ones; the WebP header agrees with the lock; the
picture is a portrait one; the catalog focus point is inside the picture.
"""
import hashlib
import json
import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / 'art/wallpapers'
ASSETS = ROOT / 'app/src/main/assets/wallpapers'
LOCK = ART / 'wallpapers.lock.json'
CATALOG = ROOT / 'app/src/main/java/com/nur/prayer/ui/wallpaper/WallpaperCatalog.kt'
ID = re.compile(r'^[a-z][a-z0-9_]{1,31}$')
# 0.31.0: the optional `light = true` argument is part of the line (before, kaaba_day did not match
# and `check` called its asset dead weight).
ENTRY = re.compile(r'image\(\s*"([a-z0-9_]+)"\s*,\s*WallpaperCategory\.(\w+)\s*,\s*([0-9.]+)f\s*,\s*([0-9.]+)f\s*'
                   r'(?:,\s*light\s*=\s*(true|false)\s*)?\)')
MAX_SIDE = 2560
MAX_TRIM = 12
FRAME_MAX = 6
FRAME_STEP = 4.0
# Paper.Ink #1D2A24 at 4.5:1 needs a background of at least this relative luminance.
INK_LUMINANCE = 0.0207
LIGHT_HEADER = 4.5 * (INK_LUMINANCE + 0.05) - 0.05


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def webp_size(data):
    """Width and height from a RIFF/WEBP header (VP8, VP8L or VP8X), stdlib only."""
    if data[:4] != b'RIFF' or data[8:12] != b'WEBP':
        raise ValueError('not a WebP file')
    chunk = data[12:16]
    if chunk == b'VP8 ':
        w, h = struct.unpack('<HH', data[26:30])
        return w & 0x3FFF, h & 0x3FFF
    if chunk == b'VP8L':
        b = data[21:25]
        w = 1 + (((b[1] & 0x3F) << 8) | b[0])
        h = 1 + (((b[3] & 0xF) << 10) | (b[2] << 2) | ((b[1] & 0xC0) >> 6))
        return w, h
    if chunk == b'VP8X':
        w = 1 + int.from_bytes(data[24:27], 'little')
        h = 1 + int.from_bytes(data[27:30], 'little')
        return w, h
    raise ValueError('unknown WebP chunk ' + chunk.decode('latin1'))


def catalog_entries(source=None):
    source = source if source is not None else CATALOG.read_text(encoding='utf-8')
    return [(m[1], m[2], float(m[3]), float(m[4]), m[5] == 'true') for m in ENTRY.finditer(source)]


def problems():
    out = []
    lock = json.loads(LOCK.read_text(encoding='utf-8')) if LOCK.exists() else {}
    entries = catalog_entries()
    ids = [e[0] for e in entries]
    if len(ids) != len(set(ids)):
        out.append('WallpaperCatalog.kt: duplicate wallpaper id')
    assets = {p.stem for p in ASSETS.glob('*.webp')} if ASSETS.exists() else set()
    categories = set(re.findall(r'enum class WallpaperCategory\s*\{([^;}]*)', CATALOG.read_text(encoding='utf-8'))[0].replace(',', ' ').split()) \
        if CATALOG.exists() else set()
    for wid, category, fx, fy, light in entries:
        if categories and category not in categories:
            out.append(f'{wid}: unknown category {category}')
        if not ID.match(wid):
            out.append(f'{wid}: id must be lowercase latin, digits and _')
        if not (0.0 <= fx <= 1.0 and 0.0 <= fy <= 1.0):
            out.append(f'{wid}: focus ({fx}, {fy}) is outside the picture')
        asset = ASSETS / f'{wid}.webp'
        if not asset.exists():
            out.append(f'{wid}: missing app/src/main/assets/wallpapers/{wid}.webp (run tools/wallpapers.py build)')
            continue
        if wid not in lock:
            out.append(f'{wid}: not in wallpapers.lock.json (run tools/wallpapers.py build)')
            continue
        data = asset.read_bytes()
        if hashlib.sha256(data).hexdigest() != lock[wid]['sha256']:
            out.append(f'{wid}: asset bytes differ from the lock (rebuild, do not hand-edit assets)')
        try:
            w, h = webp_size(data)
        except ValueError as e:
            out.append(f'{wid}: {e}')
            continue
        if light and lock[wid].get('suggestedLight') is False:
            out.append(f'{wid}: light = true, but Paper.Ink would not keep 4.5:1 on its header (lock: suggestedLight false)')
        if [w, h] != [lock[wid]['width'], lock[wid]['height']]:
            out.append(f'{wid}: WebP is {w}x{h}, lock says {lock[wid]["width"]}x{lock[wid]["height"]}')
        if not 0.35 <= w / h <= 0.80:
            out.append(f'{wid}: {w}x{h} is not a portrait wallpaper (ratio {w / h:.3f})')
        if max(w, h) > MAX_SIDE:
            out.append(f'{wid}: {w}x{h} is larger than {MAX_SIDE} px')
    for stray in sorted(assets - set(ids)):
        out.append(f'assets/wallpapers/{stray}.webp has no line in WallpaperCatalog.kt (dead APK weight)')
    return out


def check():
    found = problems()
    if found:
        print('\n'.join(found))
        sys.exit(f'wallpapers: {len(found)} problem(s)')
    print(f'PASS: {len(catalog_entries())} wallpapers: catalog, assets and lock agree.')


# ---------------------------------------------------------------------------------------- build

def frame_width(gray, side):
    """Rows/columns of the outer frame: thin, and darker than the picture just inside them.

    A frame is a dark hairline of 1–6 px. An edge that differs from the inside for more than
    FRAME_MAX lines, or is lighter, is the picture itself (a gradient, water, stone) and is kept.
    """
    import numpy as np
    h, w = gray.shape
    if side == 'top':
        lines = [gray[i, w // 4: 3 * w // 4].mean() for i in range(MAX_TRIM + 4)]
    elif side == 'bottom':
        lines = [gray[h - 1 - i, w // 4: 3 * w // 4].mean() for i in range(MAX_TRIM + 4)]
    elif side == 'left':
        lines = [gray[h // 10: h // 3, i].mean() for i in range(MAX_TRIM + 4)]
    else:
        lines = [gray[h // 10: h // 3, w - 1 - i].mean() for i in range(MAX_TRIM + 4)]
    inner = float(np.median(lines[MAX_TRIM:]))
    n = 0
    while n < MAX_TRIM and inner - lines[n] > FRAME_STEP:
        n += 1
    if n == 0 or n > FRAME_MAX:
        return 0
    return n + 1  # one more line of JPEG ringing


def suggested_light(image):
    """True when Paper.Ink keeps 4.5:1 on the darkest 10 % of the header band (top 17 %) of a 9:20 crop."""
    import numpy as np
    a = np.asarray(image.convert('RGB')).astype(float) / 255.0
    lin = np.where(a <= 0.04045, a / 12.92, ((a + 0.055) / 1.055) ** 2.4)
    lum = 0.2126 * lin[..., 0] + 0.7152 * lin[..., 1] + 0.0722 * lin[..., 2]
    h, w = lum.shape
    cw = min(w, int(h * 0.45))
    x0 = (w - cw) // 2
    return bool(np.percentile(lum[: int(h * 0.17), x0: x0 + cw], 10) >= LIGHT_HEADER)


def focus(image):
    """Saliency centroid: where the drawing is (edges), not where the empty sky is."""
    import numpy as np
    from PIL import ImageFilter
    small = image.convert('L').resize((200, max(1, int(200 * image.height / image.width))))
    a = np.asarray(small.filter(ImageFilter.GaussianBlur(1))).astype(float)
    g = np.hypot(np.abs(np.diff(a, axis=1))[:-1], np.abs(np.diff(a, axis=0))[:, :-1])
    g[g < 6] = 0
    if g.sum() == 0:
        return 0.5, 0.5
    ys, xs = np.mgrid[0:g.shape[0], 0:g.shape[1]]
    return (round(float((g * xs).sum() / g.sum() / g.shape[1]), 2),
            round(float((g * ys).sum() / g.sum() / g.shape[0]), 2))


def build(ids=(), force=False):
    import numpy as np
    from PIL import Image
    ASSETS.mkdir(parents=True, exist_ok=True)
    lock = json.loads(LOCK.read_text(encoding='utf-8')) if LOCK.exists() else {}
    sources = sorted(p for p in ART.iterdir() if p.suffix.lower() in ('.jpg', '.jpeg', '.png', '.webp'))
    for src in sources:
        wid = src.stem
        if not ID.match(wid):
            sys.exit(f'{src.name}: rename to a lowercase latin id (a-z, 0-9, _)')
        wanted = force or wid in ids or (not ids and wid not in lock)
        if not wanted:
            continue
        image = Image.open(src).convert('RGB')
        gray = np.asarray(image.convert('L')).astype(float)
        t, b, l, r = (frame_width(gray, s) for s in ('top', 'bottom', 'left', 'right'))
        image = image.crop((l, t, image.width - r, image.height - b))
        k = MAX_SIDE / max(image.size)
        if abs(k - 1) > 1e-6:
            image = image.resize((round(image.width * k), round(image.height * k)), Image.LANCZOS)
        out = ASSETS / f'{wid}.webp'
        image.save(out, 'WEBP', quality=90, method=6, use_sharp_yuv=True)
        fx, fy = focus(image)
        light = suggested_light(image)
        lock[wid] = {'sha256': sha256(out), 'width': image.width, 'height': image.height,
                     'trim': [l, t, r, b], 'source': src.name, 'suggestedFocus': [fx, fy],
                     'scale': round(k, 4), 'suggestedLight': light}
        print(f'{wid}: {image.width}x{image.height}, trimmed l{l} t{t} r{r} b{b}, scale {k:.3f}, '
              f'{out.stat().st_size // 1024} KB, focus {fx:.2f} {fy:.2f}, light {light}')
    LOCK.write_text(json.dumps(lock, indent=1, sort_keys=True) + '\n', encoding='utf-8')
    known = {e[0] for e in catalog_entries()} if CATALOG.exists() else set()
    for wid in sorted(set(lock) - known):
        fx, fy = lock[wid]['suggestedFocus']
        light = ', light = true' if lock[wid].get('suggestedLight') else ''
        print(f'  add to WallpaperCatalog.kt:  image("{wid}", WallpaperCategory.MOSQUES, {fx}f, {fy}f{light}) {{ tr("…") }},')


if __name__ == '__main__':
    command = sys.argv[1] if len(sys.argv) > 1 else 'check'
    if command == 'build':
        rest = sys.argv[2:]
        build(ids=tuple(a for a in rest if a != '--force'), force='--force' in rest)
    else:
        check()
