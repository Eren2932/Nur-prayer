#!/usr/bin/env python3
"""
0.32.1: a public declaration must not expose an `internal` (or file-`private`) type.

kotlinc reports it as "Function 'public' exposes its 'internal' return type 'X'" and stops the whole build
(it did, in 0.32.0: HomeMath.bellState returned the internal BellState). Nothing in tools/ looked at
visibility, so the static checks passed and only CI saw it. This one reads signatures:

  * collects every `internal` class/enum/object/interface (project-wide) and every `private` one (per file);
  * for every public fun/val/var/class whose container chain is public too, takes its signature
    (parameters, receiver, return/property type, constructor and supertypes) and looks for those names.

It is an indentation-based reading, like the rest of the tools here (the project is formatted by 4 spaces),
so it can miss exotic layouts; it does not invent errors on the layouts the project has.
Usage: python3 tools/check_visibility.py
"""
import os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kt_symbols import kt_files, strip_noise  # noqa: E402

TYPE_DECL = re.compile(
    r"^(?P<indent>\s*)(?P<mods>(?:(?:@\w+(?:\([^)]*\))?|public|private|internal|protected|abstract|open|sealed|data|enum|"
    r"value|annotation|inline|fun|const|lateinit|override|suspend|operator|infix|tailrec|external|expect|actual)\s+)*)"
    r"(?P<kw>class|interface|object)\s+(?P<name>\w+)")
MEMBER_DECL = re.compile(
    r"^(?P<indent>\s*)(?P<mods>(?:(?:@\w+(?:\([^)]*\))?|public|private|internal|protected|abstract|open|sealed|data|enum|"
    r"value|annotation|inline|const|lateinit|override|suspend|operator|infix|tailrec|external|expect|actual|final)\s+)*)"
    r"(?P<kw>fun|val|var|class|interface|object)\b(?P<rest>.*)$")


def modifiers(mods):
    return set(re.findall(r"\b(public|private|internal|protected)\b", mods))


def signature(lines, i, rest):
    """The text of a declaration up to its body or initializer, over as many lines as it takes."""
    text = rest
    depth = 0
    out = []
    j = i
    while True:
        k = 0
        while k < len(text):
            ch = text[k]
            if ch in "(<[":
                depth += 1
            elif ch in ")>]":
                depth -= 1 if not (ch == ">" and k > 0 and text[k - 1] == "-") else 0
            elif depth <= 0 and (ch == "{" or (ch == "=" and not text[k:k + 2] == "==" and (k == 0 or text[k - 1] not in "=!<>"))):
                out.append(text[:k])
                return " ".join(out)
            k += 1
        out.append(text)
        if depth <= 0 and j + 1 < len(lines) and re.match(r"^\s*(?:@|[\w<])", lines[j + 1]) and not re.match(r"^\s*[:.,]", lines[j + 1]):
            # a signature ends at the end of its line unless parentheses are open or the next line continues it
            if not re.search(r"[:,]\s*$", text) and depth <= 0:
                return " ".join(out)
        j += 1
        if j >= len(lines):
            return " ".join(out)
        text = lines[j]


def without_defaults(sig):
    """`fun f(a: A = Hidden.x, b: B)` exposes A and B, not whatever the default value uses."""
    out = []
    depth = 0
    skipping = False
    for k, ch in enumerate(sig):
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
            if depth == 0:
                skipping = False
        if skipping and not (depth == 1 and ch == ","):
            continue
        if skipping and depth == 1 and ch == ",":
            skipping = False
        if depth == 1 and ch == "=" and sig[k + 1:k + 2] != "=" and sig[k - 1:k] not in ("=", "!", "<", ">"):
            skipping = True
            continue
        out.append(ch)
    return "".join(out)


def container_public(lines, i, indent):
    """True when every enclosing declaration of line i is a public class/object/interface (or there is none)."""
    want = indent
    j = i - 1
    while j >= 0:
        line = lines[j]
        if not line.strip():
            j -= 1
            continue
        ind = len(line) - len(line.lstrip())
        if ind >= want:
            j -= 1
            continue
        if line.lstrip().startswith(")"):
            # `) {` closes a multi-line header: the header is the nearest line above with this indent
            k = j - 1
            while k >= 0 and (not lines[k].strip() or len(lines[k]) - len(lines[k].lstrip()) > ind):
                k -= 1
            if k < 0:
                return False
            j, line = k, lines[k]
        m = TYPE_DECL.match(line)
        if not m:
            # an enclosing function, lambda or property: whatever is inside it is local
            return False
        if modifiers(m.group("mods")) & {"private", "internal", "protected"}:
            return False
        want = len(line) - len(line.lstrip())
        if want == 0:
            return True
        j -= 1
    return True


def main():
    files = {}
    for p in kt_files():
        with open(p, encoding="utf-8") as f:
            files[p] = strip_noise(f.read())
    internal_types = set()
    private_types = {}
    for p, text in files.items():
        for line in text.split("\n"):
            m = TYPE_DECL.match(line)
            if not m:
                continue
            mods = modifiers(m.group("mods"))
            if "internal" in mods:
                internal_types.add(m.group("name"))
            elif "private" in mods and not m.group("indent"):
                private_types.setdefault(p, set()).add(m.group("name"))

    # A name that is also the name of a public type somewhere else is ambiguous for a regex: skip it.
    public_names = set()
    for p, text in files.items():
        for line in text.split("\n"):
            m = TYPE_DECL.match(line)
            if m and not modifiers(m.group("mods")) & {"private", "internal", "protected"}:
                public_names.add(m.group("name"))
    internal_types -= public_names

    problems = []
    for p, text in files.items():
        lines = text.split("\n")
        hidden = internal_types | private_types.get(p, set())
        for i, line in enumerate(lines):
            m = MEMBER_DECL.match(line)
            if not m:
                continue
            mods = modifiers(m.group("mods"))
            if mods & {"private", "internal", "protected"}:
                continue
            indent = len(m.group("indent"))
            if indent and not container_public(lines, i, indent):
                continue
            kw = m.group("kw")
            sig = signature(lines, i, m.group("rest"))
            if kw in ("class", "interface", "object"):
                declared = re.match(r"\s*(\w+)", sig)
                declared = declared.group(1) if declared else ""
            else:
                declared = ""
                # `fun <T> name(` / `fun Receiver.name(` : the name itself is not an exposed type
                sig = re.sub(r"^\s*(?:<[^>]*>\s*)?", "", sig)
            sig = without_defaults(sig)
            for name in hidden:
                if name == declared:
                    continue
                if re.search(r"(?<![\w.])" + re.escape(name) + r"\b", sig):
                    problems.append(f"{os.path.relpath(p, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))}: "
                                    f"public «{line.strip()[:80]}» выставляет скрытый тип {name}")
    if problems:
        for pr in problems:
            print("  " + pr)
        print(f"check_visibility: замечаний {len(problems)}")
        return 1
    print(f"check_visibility: OK, {len(files)} файлов, скрытых типов {len(internal_types)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
