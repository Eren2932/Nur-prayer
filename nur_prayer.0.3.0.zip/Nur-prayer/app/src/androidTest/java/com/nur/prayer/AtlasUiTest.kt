package com.nur.prayer

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsOff
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.City
import com.nur.prayer.ui.components.SwitchRow
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.paletteFor
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AtlasUiTest {
    @get:Rule val compose = createComposeRule()

    @Test fun citySearchAndSelection() {
        val cities = listOf(City.MOSCOW, City(2, "Ташкент", "Ташкент", "Узбекистан", 41.31, 69.28, "Asia/Tashkent"))
        var picked = -1
        compose.setContent {
            NurTheme {
                CityPickerScreen(paletteFor(Prayer.ISHA), 1,
                    search = { query -> cities.filter { query.isEmpty() || it.name.lowercase().contains(query) } },
                    onPick = { picked = it.id }, onBack = {}, onUseLocation = {}, locating = false)
            }
        }
        compose.waitUntil(5000) { compose.onAllNodesWithText("Ташкент").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Поиск города").performTextInput("таш")
        compose.waitUntil(5000) { compose.onAllNodesWithText("Москва").fetchSemanticsNodes().isEmpty() &&
            compose.onAllNodesWithText("Ташкент").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Ташкент").assertIsDisplayed().performClick()
        compose.runOnIdle { assertEquals(2, picked) }
    }

    @Test fun switchExposesCheckedStateToAccessibility() {
        compose.setContent {
            NurTheme {
                var checked by remember { mutableStateOf(false) }
                SwitchRow("Фаджр", checked, Mint, { checked = it })
            }
        }
        compose.onNodeWithText("Фаджр").assertIsOff().performClick().assertIsOn()
    }
}
