package com.nur.prayer.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.City
import com.nur.prayer.ui.components.DockIcon
import com.nur.prayer.ui.components.DockItem
import com.nur.prayer.ui.components.LocalBackdropPaused
import com.nur.prayer.ui.components.NightSky
import com.nur.prayer.ui.components.NurDock
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.settings.SettingsScreen
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.SystemBar
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime

@Composable
fun NurRoot(
    data: PrayerData?, now: State<ZonedDateTime>, locating: Boolean, locationStatus: String?,
    exactAlarmsAllowed: Boolean, notificationsAllowed: Boolean, citySearch: suspend (String) -> List<City>, onPickCity: (City) -> Unit,
    actionsFactory: (openCityPicker: () -> Unit) -> AppActions
) {
    val nav = rememberSaveable(saver = NurNavigator.Saver) { NurNavigator() }
    val pages = rememberSaveableStateHolder()
    val backdropPaused = remember { mutableStateOf(false) }
    BackHandler(nav.canGoBack) { nav.back() }
    val palette = remember(data?.window?.current) {
        paletteFor(data?.window?.current ?: com.nur.prayer.core.astro.Prayer.ISHA)
    }
    val actions = remember(nav) { actionsFactory { nav.go(ROUTE_CITY) } }
    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    CompositionLocalProvider(LocalDockInset provides (88.dp + bottom), LocalBackdropPaused provides backdropPaused) {
        Box(Modifier.fillMaxSize()) {
            // Other routes keep the SAME sky as a still scene; no animation tax on list scrolling.
            NightSky(palette, motionEnabled = nav.current == TAB_HOME && !backdropPaused.value)
            Box(Modifier.fillMaxSize().statusBarsPadding()) {
                AnimatedContent(
                    targetState = nav.current,
                    transitionSpec = {
                        val detail = targetState == ROUTE_CITY || initialState == ROUTE_CITY
                        val direction = if (targetState == ROUTE_CITY) 1 else -1
                        val enter = fadeIn(tween(if (detail) 150 else 120)) +
                            slideInHorizontally(tween(if (detail) 170 else 120)) { if (detail) it / 16 * direction else 0 }
                        val exit = fadeOut(tween(80))
                        (enter togetherWith exit).using(null) // never animate root layout size
                    }, label = "atlasRoute", modifier = Modifier.fillMaxSize()
                ) { route ->
                    pages.SaveableStateProvider(route) {
                        if (data == null) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Готовим расписание…", color = TextPrimary)
                            }
                        } else when (route) {
                            ROUTE_CITY -> CityPickerScreen(palette, data.settings.cityId, citySearch,
                                onPick = { city -> onPickCity(city); nav.back() }, onBack = { nav.back() },
                                onUseLocation = actions.requestLocation, locating = locating, locationStatus = locationStatus)
                            TAB_SETTINGS -> SettingsScreen(data, palette, actions, exactAlarmsAllowed, locating, locationStatus,
                                notificationsAllowed = notificationsAllowed)
                            TAB_SCHEDULE -> ScheduleScreen(data, now, palette)
                            TAB_QIBLA -> QiblaScreen(data, palette)
                            else -> HomeScreen(data, now, palette, onOpenCity = { nav.go(ROUTE_CITY) })
                        }
                    }
                }
            }
            // Backing for edge-to-edge gesture / button navigation, including the city overlay.
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .windowInsetsBottomHeight(WindowInsets.navigationBars).background(SystemBar))
            if (!nav.isOverlay) {
                Column(Modifier.align(Alignment.BottomCenter).background(SystemBar).navigationBarsPadding()) {
                    val items = remember { listOf(
                        DockItem(TAB_HOME, "Намаз", DockIcon.PRAYER),
                        DockItem(TAB_SCHEDULE, "Календарь", DockIcon.CALENDAR),
                        DockItem(TAB_QIBLA, "Кыбла", DockIcon.QIBLA),
                        DockItem(TAB_SETTINGS, "Настройки", DockIcon.SETTINGS)
                    ) }
                    NurDock(items, nav.selectedTab, { nav.go(it) }, palette.accent)
                }
            }
        }
    }
}
