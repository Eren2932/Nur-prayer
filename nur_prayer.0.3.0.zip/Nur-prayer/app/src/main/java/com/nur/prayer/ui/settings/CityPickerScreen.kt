package com.nur.prayer.ui.settings

import com.nur.prayer.ui.components.nurPanel
import androidx.compose.runtime.setValue
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.data.City
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.PanelLevel
import com.nur.prayer.ui.theme.InkSoft
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.solidTone
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.Instant
import java.util.Locale

@Immutable
private data class CityResult(val city: City, val utc: String)
private data class SearchState(val query: String = "", val rows: List<CityResult> = emptyList(),
    val loading: Boolean = true, val error: Boolean = false)

/** No search, JSON parsing, font fitting or timezone lookup takes place in a lazy row. */
@Composable
fun CityPickerScreen(
    palette: PhasePalette, selectedCityId: Int, search: suspend (String) -> List<City>,
    onPick: (City) -> Unit, onBack: () -> Unit, onUseLocation: () -> Unit,
    locating: Boolean, locationStatus: String? = null, modifier: Modifier = Modifier
) {
    val ui = uiScale()
    var query by rememberSaveable { mutableStateOf("") }
    val normalized = remember(query) { query.trim().lowercase(Locale.ROOT) }
    val searchFn by rememberUpdatedState(search)
    val keyboard = LocalSoftwareKeyboardController.current
    val listState = rememberLazyListState()
    var retry by remember { mutableIntStateOf(0) }
    var result by remember { mutableStateOf(SearchState()) }
    LaunchedEffect(normalized, retry) {
        result = result.copy(query = normalized, loading = true, error = false)
        if (normalized.isNotEmpty()) delay(120) // cancelled immediately by the next character
        try {
            val rows = withContext(Dispatchers.Default) {
                val cities = searchFn(normalized)
                val instant = Instant.now()
                val offsets = cities.map { it.timeZoneId }.distinct().associateWith {
                    runCatching { CityTimeZones.label(it, instant) }.getOrDefault("UTC?")
                }
                cities.map { CityResult(it, offsets.getValue(it.timeZoneId)) }
            }
            result = SearchState(normalized, rows, loading = false)
        } catch (cancel: CancellationException) {
            throw cancel
        } catch (_: Exception) {
            result = SearchState(normalized, loading = false, error = true)
        }
    }
    // Query edits reset the list; ordinary return to this route restores its previous scroll.
    var previousQuery by rememberSaveable { mutableStateOf(normalized) }
    LaunchedEffect(normalized) {
        if (previousQuery != normalized) {
            listState.scrollToItem(0)
            previousQuery = normalized
        }
    }
    val busy = result.loading || result.query != normalized
    Column(modifier.fillMaxSize().navigationBarsPadding().imePadding().padding(horizontal = ui.s(22f))) {
        Row(Modifier.fillMaxWidth().heightIn(min = 56.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { keyboard?.hide(); onBack() }) { Text("‹ Назад", color = palette.accentSoft) }
            Spacer(Modifier.weight(1f))
            Text("Местоположение", color = TextPrimary, fontSize = ui.t(17f), fontWeight = FontWeight.Medium)
        }
        Row(Modifier.fillMaxWidth().nurPanel(RoundedCornerShape(12.dp), PanelLevel.INSET)
            .heightIn(min = 52.dp).padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                if (query.isEmpty()) Text("Город, регион или страна", color = TextTertiary, fontSize = ui.t(15f))
                BasicTextField(query, onValueChange = { query = it }, singleLine = true,
                    textStyle = TextStyle(color = TextPrimary, fontSize = ui.t(15f)), cursorBrush = SolidColor(palette.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { keyboard?.hide() }),
                    modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Поиск города" })
            }
            if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("×", color = TextPrimary) }
        }
        Spacer(Modifier.height(8.dp))
        NurButton(if (locating) "Определяем координаты…" else "Использовать моё местоположение",
            palette.accent, onUseLocation, enabled = !locating)
        if (locationStatus != null) Text(locationStatus, color = TextSecondary, fontSize = ui.t(11f),
            maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        Text(when {
            busy -> "Поиск…"
            result.error -> "Не удалось открыть базу городов"
            normalized.isEmpty() -> "ОФЛАЙН · ${result.rows.size} ГОРОДОВ"
            else -> "НАЙДЕНО · ${result.rows.size}"
        }, color = TextSecondary, fontSize = ui.t(10f), letterSpacing = ui.t(1f),
            modifier = Modifier.padding(vertical = 12.dp))
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)).background(InkSoft)) {
            when {
                result.error && !busy -> Column(Modifier.padding(20.dp)) {
                    Text("Повторите загрузку. Если ошибка сохранится, переустановите приложение из проверенного APK.", color = TextSecondary)
                    TextButton(onClick = { retry++ }) { Text("Повторить", color = palette.accentSoft) }
                }
                !busy && result.rows.isEmpty() -> Text("Совпадений нет. Попробуйте часть названия, регион или страну.",
                    color = TextSecondary, fontSize = ui.t(14f), modifier = Modifier.padding(20.dp))
                else -> LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
                    items(result.rows, key = { it.city.id }, contentType = { "city" }) { row ->
                        CityRow(row, row.city.id == selectedCityId, palette.accent, enabled = !busy) {
                            keyboard?.hide()
                            onPick(it)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CityRow(row: CityResult, selected: Boolean, accent: Color, enabled: Boolean, onPick: (City) -> Unit) {
    val ui = uiScale()
    Column {
        Row(Modifier.fillMaxWidth().background(if (selected) solidTone(accent) else InkSoft)
            .selectable(selected = selected, enabled = enabled, role = Role.RadioButton, onClick = { onPick(row.city) })
            .heightIn(min = 72.dp).padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(row.city.name, color = if (selected) accent else TextPrimary, fontSize = ui.t(16f),
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(row.city.subtitle, color = TextTertiary, fontSize = ui.t(11f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(row.utc, color = TextSecondary, fontSize = ui.t(11f), fontFamily = FontFamily.Monospace)
                if (selected) Text("Выбран", color = accent, fontSize = ui.t(10f))
            }
        }
        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(1.dp).background(SurfaceEdge))
    }
}
