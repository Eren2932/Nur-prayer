package com.nur.prayer

import androidx.compose.runtime.setValue
import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nur.prayer.ui.theme.SystemBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.lifecycle.lifecycleScope
import com.nur.prayer.notify.AzanPlayerService
import com.nur.prayer.notify.PrayerAlarmScheduler
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.AppViewModel
import com.nur.prayer.ui.NurRoot
import com.nur.prayer.ui.theme.NurTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()
    private var permissionEpoch by mutableIntStateOf(0)

    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { permissionEpoch++; viewModel.onPermissionsChanged() }

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { viewModel.useDeviceLocation() } // provider returns an explicit NoPermission outcome on denial

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(SystemBar.toArgb())
        )
        syncSystemBars()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            NurTheme {
                val data by viewModel.data.collectAsStateWithLifecycle()
                val locating by viewModel.locating.collectAsStateWithLifecycle()
                val locationStatus by viewModel.locationStatus.collectAsStateWithLifecycle()
                // Deliberately *not* `by`: the clock travels down the tree as state, so this
                // composable never recomposes on a tick. See the doc on `NurRoot.now`.
                val now = viewModel.now.collectAsStateWithLifecycle()
                // System dialogs return through onResume. Re-check immediately rather than
                // reading the clock here and invalidating the root once every minute.
                val exactAllowed = remember(permissionEpoch) {
                    PrayerAlarmScheduler.canScheduleExact(this@MainActivity)
                }
                val notificationsAllowed = remember(permissionEpoch) {
                    androidx.core.app.NotificationManagerCompat.from(this@MainActivity).areNotificationsEnabled()
                }

                NurRoot(
                    data = data,
                    now = now,
                    locating = locating,
                    locationStatus = locationStatus,
                    exactAlarmsAllowed = exactAllowed,
                    notificationsAllowed = notificationsAllowed,
                    citySearch = { query -> viewModel.cities(query) },
                    onPickCity = { city -> viewModel.selectCity(city) },
                    actionsFactory = { openCityPicker ->
                        AppActions(
                            openCityPicker = openCityPicker,
                            requestLocation = { requestLocation() },
                            openExactAlarmSettings = { openExactAlarmSettings() },
                            openBatterySettings = { openBatterySettings() },
                            openNotificationSettings = { openNotificationSettings() },
                            setMethod = { method ->
                                lifecycleScope.launch { viewModel.repository.setMethod(method) }
                            },
                            setMadhab = { madhab ->
                                lifecycleScope.launch { viewModel.repository.setMadhab(madhab) }
                            },
                            setHighLatitudeRule = { rule ->
                                lifecycleScope.launch { viewModel.repository.setHighLatitudeRule(rule) }
                            },
                            setRounding = { mode ->
                                lifecycleScope.launch { viewModel.repository.setRounding(mode) }
                            },
                            setNotification = { prayer, enabled ->
                                viewModel.setNotification(prayer, enabled)
                            },
                            setOffset = { prayer, minutes -> viewModel.setOffset(prayer, minutes) },
                            setPreAlert = { minutes ->
                                lifecycleScope.launch { viewModel.repository.setPreAlert(minutes) }
                            },
                            setAzanSound = { sound ->
                                lifecycleScope.launch { viewModel.repository.setAzanSound(sound) }
                            },
                            previewAzan = { sound ->
                                AzanPlayerService.play(
                                    this@MainActivity,
                                    "Проверка азана",
                                    sound.title,
                                    sound,
                                    preview = true
                                )
                            },
                            stopAzan = { AzanPlayerService.stopPreview(this@MainActivity) },
                            setHijriOffset = { days ->
                                lifecycleScope.launch { viewModel.repository.setHijriOffset(days) }
                            }
                        )
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        permissionEpoch++
        syncSystemBars()
        // Self-heal the alarm chain and the clock every time the user opens the app.
        viewModel.refresh()
        viewModel.onPermissionsChanged()
    }

    override fun onStart() {
        super.onStart()
        viewModel.setForeground(true)
    }

    override fun onStop() {
        viewModel.setForeground(false)
        super.onStop()
    }

    @Suppress("DEPRECATION")
    private fun syncSystemBars() {
        // Android 8–14 and target-34 compatibility: colour the actual THREE-BUTTON bar,
        // not just a Compose view above it. Gesture area is backed by the same opaque ink.
        window.navigationBarColor = SystemBar.toArgb()
        if (Build.VERSION.SDK_INT >= 28) window.navigationBarDividerColor = SystemBar.toArgb()
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightNavigationBars = false
            isAppearanceLightStatusBars = false
        }
    }

    private fun requestLocation() {
        locationPermission.launch(
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        )
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                )
            }
        }
    }

    private fun openNotificationSettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
    }

    private fun openBatterySettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }.onFailure {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
    }
}
