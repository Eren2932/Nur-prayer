package com.nur.prayer.ui.components

import androidx.compose.runtime.setValue
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableFloatState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import com.nur.prayer.ui.theme.PhasePalette
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Atlas atmosphere, kept from the original design.
 * Static atmosphere and decorative overlay have no frame clock. The motion layer runs only on
 * the idle home route, while resumed, outside battery saver and with OS animation enabled.
 * Pausing preserves the visual phase. Its cadence is at most 20 updates/s, not the display rate.
 */
@Composable
fun NightSky(
    palette: PhasePalette,
    modifier: Modifier = Modifier,
    motionEnabled: Boolean = true
) {
    val allowed = rememberAmbientMotionAllowed() && motionEnabled
    val clock = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(allowed) {
        if (!allowed) return@LaunchedEffect
        // Preserve the visual phase when scrolling pauses the background; no jump back to zero.
        var previous = 0L
        while (true) {
            withFrameNanos { now ->
                if (previous != 0L) clock.floatValue += ((now - previous) / 1_000_000_000f).coerceAtMost(0.15f)
                previous = now
            }
            kotlinx.coroutines.delay(50L)
        }
    }

    // Phase colours cross-fade over a second and a half. While that runs, the static layers do
    // redraw - but that is once per phase of the day, not once per frame.
    val zenith by animateColorAsState(palette.zenith, tween(1600), label = "zenith")
    val mid by animateColorAsState(palette.mid, tween(1600), label = "mid")
    val horizon by animateColorAsState(palette.horizon, tween(1600), label = "horizon")
    val glow by animateColorAsState(palette.glow, tween(1600), label = "glow")
    val ribbonA by animateColorAsState(palette.ribbonA, tween(1600), label = "ribbonA")
    val ribbonB by animateColorAsState(palette.ribbonB, tween(1600), label = "ribbonB")
    val starIntensity by animateFloatAsState(palette.starIntensity, tween(1600), label = "stars")
    val auroraIntensity by animateFloatAsState(palette.auroraIntensity, tween(1600), label = "aurora")

    val stars = remember { buildStars() }
    val grain = remember { buildGrain() }
    val lattice = remember { LatticeCache() }
    val curtainFill = remember { Path() }
    val curtainEdge = remember { Path() }

    Box(modifier = modifier.fillMaxSize()) {
        SkyAtmosphere(zenith = zenith, mid = mid, horizon = horizon, glow = glow)
        SkyMotion(
            clock = clock,
            ribbonA = ribbonA,
            ribbonB = ribbonB,
            starIntensity = starIntensity,
            auroraIntensity = auroraIntensity,
            stars = stars,
            curtainFill = curtainFill,
            curtainEdge = curtainEdge
        )
        SkyOverlay(grain = grain, lattice = lattice)
    }
}

/** Layers 1-2: the four-stop atmosphere and the squashed horizon airglow. Never animates. */
@Composable
private fun SkyAtmosphere(zenith: Color, mid: Color, horizon: Color, glow: Color) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        // A zero-sized canvas would produce zero-radius gradients, which shaders reject.
        if (w < 1f || h < 1f) return@Canvas

        drawRect(
            brush = Brush.verticalGradient(
                0f to zenith,
                0.38f to mid,
                0.74f to lerpColor(mid, horizon, 0.6f),
                1f to horizon
            )
        )

        val glowRadius = w * 1.05f
        withTransform({ scale(1f, 0.42f, pivot = Offset(w * 0.5f, h)) }) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        glow.copy(alpha = 0.34f),
                        glow.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.5f, h),
                    radius = glowRadius
                ),
                radius = glowRadius,
                center = Offset(w * 0.5f, h)
            )
        }
    }
}

/** Layers 3-5: the only part of the sky that moves. */
@Composable
private fun SkyMotion(
    clock: MutableFloatState,
    ribbonA: Color,
    ribbonB: Color,
    starIntensity: Float,
    auroraIntensity: Float,
    stars: Array<Star>,
    curtainFill: Path,
    curtainEdge: Path
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val t = clock.floatValue
        val w = size.width
        val h = size.height
        if (w < 1f || h < 1f) return@Canvas

        if (auroraIntensity > 0.02f) {
            drawCurtain(
                t = t, w = w, h = h, color = ribbonA, intensity = auroraIntensity * 0.9f,
                baseY = h * 0.10f, amplitude = h * 0.055f, thickness = h * 0.14f,
                speed = 0.055f, phase = 0f, harmonics = 1.7f,
                fill = curtainFill, edge = curtainEdge
            )
            drawCurtain(
                t = t, w = w, h = h, color = ribbonB, intensity = auroraIntensity,
                baseY = h * 0.24f, amplitude = h * 0.075f, thickness = h * 0.20f,
                speed = -0.038f, phase = 2.1f, harmonics = 1.25f,
                fill = curtainFill, edge = curtainEdge
            )
            drawCurtain(
                t = t, w = w, h = h, color = ribbonA, intensity = auroraIntensity * 0.55f,
                baseY = h * 0.46f, amplitude = h * 0.05f, thickness = h * 0.16f,
                speed = 0.027f, phase = 4.3f, harmonics = 2.3f,
                fill = curtainFill, edge = curtainEdge
            )
        }

        if (starIntensity > 0.02f) {
            // An indexed walk over an array: no iterator, no lambda per star, no boxing on a path
            // that runs a hundred and twenty-four times per drawn frame.
            for (i in stars.indices) {
                val star = stars[i]
                val drift = (star.x + t * star.parallax * 0.004f) % 1.02f
                val x = drift * w
                val y = star.y * h
                // Fade out towards the horizon haze: no stars sitting inside the glow.
                val horizonFade = (1f - (star.y / 0.80f)).coerceIn(0f, 1f)
                val twinkle = 0.58f + 0.42f * sin(2f * PI.toFloat() * (t * star.speed + star.phase))
                val alpha = star.brightness * twinkle * horizonFade * starIntensity
                if (alpha <= 0.012f) continue
                drawCircle(
                    color = Color.White.copy(alpha = alpha.coerceAtMost(0.95f)),
                    radius = star.radius,
                    center = Offset(x, y)
                )
                if (star.sparkle) {
                    val ray = star.radius * 7f
                    val rayAlpha = alpha * 0.34f
                    drawLine(
                        color = Color.White.copy(alpha = rayAlpha),
                        start = Offset(x - ray, y), end = Offset(x + ray, y),
                        strokeWidth = star.radius * 0.5f, cap = StrokeCap.Round
                    )
                    drawLine(
                        color = Color.White.copy(alpha = rayAlpha),
                        start = Offset(x, y - ray), end = Offset(x, y + ray),
                        strokeWidth = star.radius * 0.5f, cap = StrokeCap.Round
                    )
                }
            }

            // A meteor every ~17 s, visible for 1.1 s.
            if (starIntensity > 0.45f) {
                drawMeteor(t = t, w = w, h = h, alphaScale = starIntensity)
            }
        }
    }
}

/** Layers 6-8: engraved lattice, film grain, scrims and vignette. Never animates. */
@Composable
private fun SkyOverlay(grain: Array<Grain>, lattice: LatticeCache) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        if (w < 1f || h < 1f) return@Canvas

        if (lattice.key != size) {
            lattice.key = size
            lattice.path = buildLattice(size)
        }
        drawPath(
            path = lattice.path,
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.085f)),
                startY = h * 0.52f,
                endY = h
            ),
            style = Stroke(width = 1f * density)
        )

        for (i in grain.indices) {
            val g = grain[i]
            drawRect(
                color = Color.White.copy(alpha = g.alpha),
                topLeft = Offset(g.x * w, g.y * h),
                size = Size(density, density)
            )
        }

        drawRect(
            brush = Brush.verticalGradient(
                0f to Color.Black.copy(alpha = 0.30f),
                0.22f to Color.Transparent,
                0.72f to Color.Transparent,
                1f to Color.Black.copy(alpha = 0.46f)
            )
        )
        val vignetteRadius = size.maxDimension * 0.78f
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.30f)),
                center = Offset(w * 0.5f, h * 0.46f),
                radius = vignetteRadius
            )
        )
    }
}

/* ----------------------------------------------------------------------------------------------
 * Drawing helpers
 * -------------------------------------------------------------------------------------------- */

/**
 * One aurora curtain: a band between two sine curves, filled with a gradient that fades on both
 * edges. Two harmonics keep it from looking like a school-book sine wave.
 */
private fun DrawScope.drawCurtain(
    t: Float,
    w: Float,
    h: Float,
    color: Color,
    intensity: Float,
    baseY: Float,
    amplitude: Float,
    thickness: Float,
    speed: Float,
    phase: Float,
    harmonics: Float,
    fill: Path,
    edge: Path
) {
    val steps = 26
    // Two paths, allocated once by the caller and rewound here. Three curtains x two paths x sixty
    // frames used to be three hundred and sixty Path objects a second thrown at the collector, for
    // shapes with the same twenty-seven points every time.
    val path = fill.also { it.reset() }
    var minY = Float.MAX_VALUE
    var maxY = Float.MIN_VALUE

    fun edge(i: Int, bottom: Boolean): Offset {
        val f = i / steps.toFloat()
        val a = 2f * PI.toFloat() * (f * 1.15f + t * speed + phase)
        val b = 2f * PI.toFloat() * (f * harmonics * 1.9f - t * speed * 1.7f + phase * 0.5f)
        val wobble = sin(a) + 0.45f * sin(b)
        val local = baseY + amplitude * wobble
        val depth = thickness * (0.62f + 0.38f * sin(a * 0.7f + 1.3f))
        val y = if (bottom) local + depth else local
        if (y < minY) minY = y
        if (y > maxY) maxY = y
        return Offset(f * w, y)
    }

    for (i in 0..steps) {
        val p = edge(i, false)
        if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
    }
    for (i in steps downTo 0) {
        val p = edge(i, true)
        path.lineTo(p.x, p.y)
    }
    path.close()

    drawPath(
        path = path,
        brush = Brush.verticalGradient(
            colors = listOf(
                color.copy(alpha = 0f),
                color.copy(alpha = 0.26f * intensity),
                color.copy(alpha = 0.07f * intensity),
                color.copy(alpha = 0f)
            ),
            startY = minY,
            endY = maxY
        )
    )
    // A brighter leading edge: this is what makes it read as a curtain of light.
    val edgePath = edge.also { it.reset() }
    for (i in 0..steps) {
        val p = edge(i, false)
        if (i == 0) edgePath.moveTo(p.x, p.y) else edgePath.lineTo(p.x, p.y)
    }
    drawPath(
        path = edgePath,
        color = color.copy(alpha = 0.14f * intensity),
        style = Stroke(width = 1.6f * density, cap = StrokeCap.Round)
    )
}

/** A meteor every [PERIOD] seconds; fully deterministic, so no particle bookkeeping. */
private fun DrawScope.drawMeteor(t: Float, w: Float, h: Float, alphaScale: Float) {
    val index = (t / METEOR_PERIOD).toInt()
    val local = t - index * METEOR_PERIOD
    if (local > METEOR_LIFE) return

    val rnd = hash(index)
    val startX = (0.15f + 0.7f * rnd) * w
    val startY = (0.05f + 0.28f * hash(index * 31 + 7)) * h
    val angle = (0.62f + 0.22f * hash(index * 17 + 3)) // radians, downward-right
    val travel = w * 0.42f
    val p = local / METEOR_LIFE
    val eased = p * p * (3f - 2f * p)
    val hx = startX + cos(angle) * travel * eased
    val hy = startY + sin(angle) * travel * eased
    val tailLength = travel * 0.22f
    val tx = hx - cos(angle) * tailLength
    val ty = hy - sin(angle) * tailLength
    val fade = (1f - abs(p * 2f - 1f)).coerceIn(0f, 1f) * alphaScale

    drawLine(
        brush = Brush.linearGradient(
            colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.75f * fade)),
            start = Offset(tx, ty),
            end = Offset(hx, hy)
        ),
        start = Offset(tx, ty),
        end = Offset(hx, hy),
        strokeWidth = 2f * density,
        cap = StrokeCap.Round
    )
    drawCircle(
        color = Color.White.copy(alpha = 0.9f * fade),
        radius = 1.6f * density,
        center = Offset(hx, hy)
    )
}

/** Two rotated octagons per cell = the simplest honest girih motif. */
private fun buildLattice(size: Size): Path {
    val path = Path()
    val cell = size.width / 3.2f
    val radius = cell * 0.44f
    var row = 0
    var y = size.height * 0.54f
    while (y < size.height + cell) {
        val shift = if (row % 2 == 0) 0f else cell * 0.5f
        var x = -cell * 0.5f + shift
        while (x < size.width + cell) {
            addPolygon(path, Offset(x, y), radius, 8, 0f)
            addPolygon(path, Offset(x, y), radius, 8, 22.5f)
            addPolygon(path, Offset(x, y), radius * 0.42f, 8, 0f)
            x += cell
        }
        y += cell * 0.82f
        row++
    }
    return path
}

private fun addPolygon(path: Path, center: Offset, radius: Float, sides: Int, rotationDeg: Float) {
    for (i in 0..sides) {
        val a = ((rotationDeg + i * 360f / sides) * PI / 180f).toFloat()
        val x = center.x + radius * cos(a)
        val y = center.y + radius * sin(a)
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
}

/* ----------------------------------------------------------------------------------------------
 * Static data
 * -------------------------------------------------------------------------------------------- */

private class Star(
    val x: Float,
    val y: Float,
    val radius: Float,
    val brightness: Float,
    val phase: Float,
    val speed: Float,
    val parallax: Float,
    val sparkle: Boolean
)

private class Grain(val x: Float, val y: Float, val alpha: Float)

private class LatticeCache {
    var key: Size = Size.Zero
    var path: Path = Path()
}

/** Three depth layers: far dust, mid stars, near bright stars with sparkle rays. */
private fun buildStars(): Array<Star> {
    val random = Random(1445)
    val result = ArrayList<Star>(124)
    // Far layer: dust.
    repeat(70) {
        result += Star(
            x = random.nextFloat(),
            y = random.nextFloat() * 0.82f,
            radius = 0.7f + random.nextFloat() * 0.5f,
            brightness = 0.18f + random.nextFloat() * 0.20f,
            phase = random.nextFloat(),
            speed = 0.06f + random.nextFloat() * 0.10f,
            parallax = 0.35f,
            sparkle = false
        )
    }
    // Mid layer.
    repeat(46) {
        result += Star(
            x = random.nextFloat(),
            y = random.nextFloat() * 0.78f,
            radius = 1.1f + random.nextFloat() * 0.8f,
            brightness = 0.30f + random.nextFloat() * 0.30f,
            phase = random.nextFloat(),
            speed = 0.10f + random.nextFloat() * 0.16f,
            parallax = 0.8f,
            sparkle = false
        )
    }
    // Near layer: the eight stars you actually notice.
    repeat(8) {
        result += Star(
            x = random.nextFloat(),
            y = 0.06f + random.nextFloat() * 0.55f,
            radius = 1.9f + random.nextFloat() * 1.0f,
            brightness = 0.62f + random.nextFloat() * 0.30f,
            phase = random.nextFloat(),
            speed = 0.14f + random.nextFloat() * 0.12f,
            parallax = 1.5f,
            sparkle = true
        )
    }
    return result.toTypedArray()
}

private fun buildGrain(): Array<Grain> = Random(93).let { random ->
    Array(240) {
        Grain(
            x = random.nextFloat(),
            y = random.nextFloat(),
            alpha = 0.014f + random.nextFloat() * 0.030f
        )
    }
}

private const val METEOR_PERIOD = 17f
private const val METEOR_LIFE = 1.1f

private fun hash(seed: Int): Float {
    var x = seed * 374761393 + 668265263
    x = (x xor (x shr 13)) * 1274126177
    return ((x xor (x shr 16)) and 0x7FFFFFFF) / 2147483647f
}

private fun lerpColor(from: Color, to: Color, fraction: Float): Color = Color(
    red = from.red + (to.red - from.red) * fraction,
    green = from.green + (to.green - from.green) * fraction,
    blue = from.blue + (to.blue - from.blue) * fraction,
    alpha = from.alpha + (to.alpha - from.alpha) * fraction
)

