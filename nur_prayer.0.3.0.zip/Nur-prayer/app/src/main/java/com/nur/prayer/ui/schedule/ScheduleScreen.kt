package com.nur.prayer.ui.schedule

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.saveable.rememberSaveable
import com.nur.prayer.ui.theme.InkSoft
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.solidTone
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerDay
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.AtlasPanel
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.UiScale
import com.nur.prayer.ui.theme.uiScale
import java.time.Duration
import java.time.ZonedDateTime

/**
 * Two weeks, as a calendar.
 *
 * The old version was a vertical stack of fourteen identical cards — technically complete, visually
 * useless. This is a real month-style grid: seven columns aligned to the weekdays, three rows,
 * today outlined, the selected day filled. Tapping a cell opens one detail card below with the day's
 * six times, an hour-scale timeline of the day, the length of daylight and how much the day moved
 * against today. Everything the fourteen cards used to repeat is now shown once.
 */
@Composable
fun ScheduleScreen(
    data: PrayerData,
    /** State, not a value: only the needle inside the timeline reads it, and only while drawing. */
    now: State<ZonedDateTime>,
    palette: PhasePalette,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val dockInset = LocalDockInset.current
    val haptic = LocalHapticFeedback.current
    val days = data.days
    val today = days.first()
    val hijriOffset = data.settings.hijriOffset

    val selectedIndex = rememberSaveable(today.date.toEpochDay(), data.place.label) { mutableIntStateOf(0) }
    val selected = days.getOrElse(selectedIndex.intValue) { today }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = ui.s(20f))
    ) {
        Spacer(Modifier.height(ui.s(6f)))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Bottom
        ) {
            Column(modifier = Modifier.weight(1f)) {
                AutoSizeText(
                    text = Format.monthYear(selected.date),
                    color = TextPrimary,
                    fontSize = ui.t(24f),
                    minFontSize = ui.t(17f),
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth()
                )
                AutoSizeText(
                    text = HijriCalendar.monthAndYear(selected.date, hijriOffset),
                    color = palette.accentSoft,
                    fontSize = ui.t(12f),
                    minFontSize = ui.t(9.5f),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.width(ui.s(8f)))
            AutoSizeText(
                text = data.place.label,
                color = TextTertiary,
                fontSize = ui.t(11.5f),
                minFontSize = ui.t(9f),
                maxLines = 2
            )
        }

        Spacer(Modifier.height(ui.s(12f)))

        // ---- The grid ---------------------------------------------------------------------------
        AtlasPanel(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = ui.s(12f),
            corner = ui.s(24f)
        ) {
            Column {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (i in 0 until 7) {
                        val label = weekdayHeaders[i]
                        val weekend = i >= 5
                        Box(
                            modifier = Modifier.weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            AutoSizeText(
                                text = label,
                                color = if (weekend) palette.accentSoft.copy(alpha = 0.75f) else TextTertiary,
                                fontSize = ui.t(10.5f),
                                minFontSize = ui.t(8f),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(Modifier.height(ui.s(6f)))

                // Leading blanks so the first day lands under its own weekday.
                val leading = today.date.dayOfWeek.value - 1
                val cells: List<PrayerDay?> = List(leading) { null } + days
                val rows = (cells.size + 6) / 7

                for (row in 0 until rows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(ui.s(4f))
                    ) {
                        for (column in 0 until 7) {
                            val index = row * 7 + column
                            val day = cells.getOrNull(index)
                            Box(modifier = Modifier.weight(1f)) {
                                if (day == null) {
                                    Spacer(Modifier.height(ui.s(46f)))
                                } else {
                                    val dayIndex = index - leading
                                    DayCell(
                                        day = day,
                                        hijriOffset = hijriOffset,
                                        isToday = dayIndex == 0,
                                        isSelected = dayIndex == selectedIndex.intValue,
                                        accent = palette.accent,
                                        ui = ui,
                                        onClick = {
                                            if (dayIndex != selectedIndex.intValue) {
                                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                selectedIndex.intValue = dayIndex
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(ui.s(4f)))
                }
            }
        }

        Spacer(Modifier.height(ui.s(12f)))

        // ---- The selected day ------------------------------------------------------------------
        AtlasPanel(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = ui.s(16f),
            corner = ui.s(24f)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        AutoSizeText(
                            text = Format.fullDate(selected.date).replaceFirstChar { it.uppercase() },
                            color = TextPrimary,
                            fontSize = ui.t(15.5f),
                            minFontSize = ui.t(12f),
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.fillMaxWidth()
                        )
                        AutoSizeText(
                            text = HijriCalendar.dayAndMonth(selected.date, hijriOffset),
                            color = TextTertiary,
                            fontSize = ui.t(11.5f),
                            minFontSize = ui.t(9f),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    if (selectedIndex.intValue == 0) {
                        DayNote("сегодня", palette.accent, ui)
                    } else {
                        DayNote("+${selectedIndex.intValue} дн", TextSecondary, ui)
                    }
                }

                Spacer(Modifier.height(ui.s(12f)))

                DayTimeline(
                    day = selected,
                    now = if (selectedIndex.intValue == 0) now else null,
                    accent = palette.accent,
                    ui = ui
                )

                Spacer(Modifier.height(ui.s(12f)))

                // Six times as a 3 x 2 block: the whole day fits one glance, no scrolling.
                val order = Prayer.entries.toList()
                for (rowStart in order.indices step 3) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(ui.s(8f))
                    ) {
                        for (offset in 0 until 3) {
                            val prayer = order.getOrNull(rowStart + offset)
                            Box(modifier = Modifier.weight(1f)) {
                                if (prayer != null) {
                                    TimeCell(
                                        prayer = prayer,
                                        time = selected.times[prayer],
                                        highlight = selectedIndex.intValue == 0 &&
                                            prayer == data.window.next,
                                        accent = palette.accent,
                                        ui = ui
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(ui.s(8f)))
                }

                HairLine(ui)

                val dayLength = daylight(selected)
                val todayLength = daylight(today)
                SummaryRow("Световой день", Format.hoursMinutes(dayLength), ui)
                if (selectedIndex.intValue != 0) {
                    SummaryRow(
                        "Разница с сегодняшним днём",
                        Format.signedMinutes((dayLength.toMinutes() - todayLength.toMinutes())),
                        ui
                    )
                    SummaryRow(
                        "Фаджр сдвинулся",
                        Format.signedMinutes(minuteShift(today, selected, Prayer.FAJR)),
                        ui
                    )
                    SummaryRow(
                        "Магриб сдвинулся",
                        Format.signedMinutes(minuteShift(today, selected, Prayer.MAGHRIB)),
                        ui
                    )
                }
                SummaryRow("Ночь (от Иша до Фаджра)", Format.hoursMinutes(nightLength(days, selectedIndex.intValue)), ui)

                val note = selected.note
                if (note != null) {
                    Spacer(Modifier.height(ui.s(8f)))
                    Text(
                        text = note,
                        color = palette.accentSoft,
                        fontSize = ui.t(11.5f),
                        lineHeight = ui.t(16f)
                    )
                }
            }
        }

        Spacer(Modifier.height(dockInset))
    }
}

/* ------------------------------------------------------------------------------------------------
 * Pieces
 * ---------------------------------------------------------------------------------------------- */

@Composable
private fun DayCell(
    day: PrayerDay,
    hijriOffset: Int,
    isToday: Boolean,
    isSelected: Boolean,
    accent: Color,
    ui: UiScale,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(ui.s(14f))
    val background by animateColorAsState(
        targetValue = when {
            isSelected -> solidTone(accent, 0.30f)
            isToday -> SurfaceRaised
            else -> InkSoft
        },
        animationSpec = tween(240),
        label = "cellBg"
    )
    val border by animateColorAsState(
        targetValue = when {
            isSelected -> accent.copy(alpha = 0.55f)
            isToday -> accent.copy(alpha = 0.40f)
            else -> Color.Transparent
        },
        animationSpec = tween(240),
        label = "cellBorder"
    )
    val weekend = day.date.dayOfWeek.value >= 6

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = ui.s(46f))
            .clip(shape)
            .background(background)
            .border(1.dp, border, shape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(vertical = ui.s(6f), horizontal = ui.s(2f)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        AutoSizeText(
            text = day.date.dayOfMonth.toString(),
            color = if (isSelected) TextPrimary else if (weekend) accent.copy(alpha = 0.9f) else TextPrimary,
            fontSize = ui.t(15f),
            minFontSize = ui.t(10f),
            fontWeight = if (isSelected || isToday) FontWeight.SemiBold else FontWeight.Normal
        )
        AutoSizeText(
            text = HijriCalendar.dayOfMonth(day.date, hijriOffset).toString(),
            color = TextTertiary,
            fontSize = ui.t(9.5f),
            minFontSize = ui.t(7.5f)
        )
        if (day.note != null) {
            Spacer(Modifier.height(ui.s(2f)))
            Box(
                modifier = Modifier
                    .size(ui.s(4f))
                    .clip(CircleShape)
                    .background(accent)
            )
        }
    }
}

/**
 * The day on an hour scale: 00:00 on the left, 24:00 on the right, night dark, daylight lit, six
 * markers where the prayers fall, and a live "now" needle on today. This is the compact, horizontal
 * reading of a day that a vertical list can never give.
 */
@Composable
private fun DayTimeline(
    day: PrayerDay,
    now: State<ZonedDateTime>?,
    accent: Color,
    ui: UiScale
) {
    val fajr = fraction(day, Prayer.FAJR)
    val sunrise = fraction(day, Prayer.SUNRISE)
    val maghrib = fraction(day, Prayer.MAGHRIB)
    val markers = Prayer.entries.mapNotNull { prayer ->
        day.times[prayer]?.let { prayer to fraction(day, prayer) }
    }

    Column {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(ui.s(34f))
        ) {
            if (size.width < 8f || size.height < 4f) return@Canvas
            val h = size.height
            val barTop = h * 0.30f
            val barHeight = h * 0.36f
            val corner = barHeight / 2f

            // Night bed.
            drawRoundRect(
                color = Color.White.copy(alpha = 0.06f),
                topLeft = Offset(0f, barTop),
                size = androidx.compose.ui.geometry.Size(size.width, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(corner, corner)
            )
            // Twilight (fajr -> sunrise) and daylight (sunrise -> maghrib).
            fun band(from: Float, to: Float, brush: Brush) {
                if (to <= from) return
                drawRoundRect(
                    brush = brush,
                    topLeft = Offset(size.width * from, barTop),
                    size = androidx.compose.ui.geometry.Size(size.width * (to - from), barHeight),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(corner, corner)
                )
            }
            band(
                fajr, sunrise,
                Brush.horizontalGradient(
                    listOf(accent.copy(alpha = 0.18f), accent.copy(alpha = 0.34f))
                )
            )
            band(
                sunrise, maghrib,
                Brush.horizontalGradient(
                    listOf(
                        accent.copy(alpha = 0.45f),
                        accent.copy(alpha = 0.75f),
                        accent.copy(alpha = 0.45f)
                    )
                )
            )

            // Hour grid every three hours.
            for (i in 1 until 8) {
                val x = size.width * (i / 8f)
                drawLine(
                    color = Color.White.copy(alpha = 0.09f),
                    start = Offset(x, barTop),
                    end = Offset(x, barTop + barHeight),
                    strokeWidth = 1f * density
                )
            }

            // Prayer markers.
            markers.forEach { (_, f) ->
                val x = size.width * f
                drawLine(
                    color = Color.White.copy(alpha = 0.85f),
                    start = Offset(x, barTop - h * 0.16f),
                    end = Offset(x, barTop + barHeight + h * 0.16f),
                    strokeWidth = 1.6f * density,
                    cap = StrokeCap.Round
                )
            }

            // Now.
            // The state is read *here*, inside the draw scope. Compose then re-runs this lambda and
            // nothing else — no recomposition, no relayout.
            val moment = now?.value
            if (moment != null) {
                val secondOfDay = moment.hour * 3600 + moment.minute * 60 + moment.second
                val nowFraction = (secondOfDay / 86400f).coerceIn(0f, 1f)
                val x = size.width * nowFraction
                drawLine(
                    color = accent,
                    start = Offset(x, 0f),
                    end = Offset(x, h),
                    strokeWidth = 2.2f * density,
                    cap = StrokeCap.Round
                )
                drawCircle(color = accent, radius = 3f * density, center = Offset(x, h * 0.06f))
            }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            listOf("00", "06", "12", "18", "24").forEachIndexed { index, label ->
                Text(
                    text = label,
                    color = TextTertiary,
                    fontSize = ui.t(8.5f),
                    textAlign = when (index) {
                        0 -> TextAlign.Start
                        4 -> TextAlign.End
                        else -> TextAlign.Center
                    },
                    modifier = Modifier.weight(if (index == 0 || index == 4) 0.5f else 1f)
                )
            }
        }
    }
}

@Composable
private fun TimeCell(
    prayer: Prayer,
    time: ZonedDateTime?,
    highlight: Boolean,
    accent: Color,
    ui: UiScale
) {
    val shape = RoundedCornerShape(ui.s(14f))
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                if (highlight) solidTone(accent, 0.16f) else SurfaceRaised
            )
            .border(
                1.dp,
                if (highlight) accent.copy(alpha = 0.35f) else Color.Transparent,
                shape
            )
            .padding(vertical = ui.s(8f), horizontal = ui.s(6f)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AutoSizeText(
            text = PrayerLabels.title(prayer),
            color = if (highlight) accent else TextSecondary,
            fontSize = ui.t(11f),
            minFontSize = ui.t(8.5f),
            fontWeight = FontWeight.Medium
        )
        AutoSizeText(
            text = time?.let { Format.time(it) } ?: "—",
            color = TextPrimary,
            fontSize = ui.t(17f),
            minFontSize = ui.t(12f),
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium
        )
    }
}

/**
 * "сегодня" / "+3 дн" over the schedule.
 *
 * Was a tinted pill with a hairline border — the same shape as the day selector right above it,
 * which is a control you tap. A caption that looks tappable and is not is a small lie told on every
 * screen, and two stock pills in one column is what makes a layout look generated. Now it is just a
 * word in the accent colour with a hair of letter spacing: still the first thing the eye finds,
 * because nothing else up there is coloured.
 */
@Composable
private fun DayNote(text: String, color: Color, ui: UiScale) {
    AutoSizeText(
        text = text,
        color = color.copy(alpha = 0.92f),
        fontSize = ui.t(11f),
        minFontSize = ui.t(9f),
        fontWeight = FontWeight.Medium,
        letterSpacing = ui.t(0.4f),
        resizeKey = text.length
    )
}

@Composable
private fun SummaryRow(label: String, value: String, ui: UiScale) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(4f)),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AutoSizeText(
            text = label,
            color = TextTertiary,
            fontSize = ui.t(11.5f),
            minFontSize = ui.t(9f),
            maxLines = 2,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(ui.s(10f)))
        AutoSizeText(
            text = value,
            color = TextPrimary,
            fontSize = ui.t(12.5f),
            minFontSize = ui.t(10f),
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun HairLine(ui: UiScale) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(8f))
            .height(1.dp)
            .background(SurfaceEdge)
    )
}

/* ------------------------------------------------------------------------------------------------
 * Small calculations
 * ---------------------------------------------------------------------------------------------- */

private val weekdayHeaders = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

/** Where a prayer falls inside its own local day, 0..1. */
private fun fraction(day: PrayerDay, prayer: Prayer): Float {
    val time = day.times[prayer] ?: return 0f
    val local = time.toLocalTime()
    val seconds = local.hour * 3600 + local.minute * 60 + local.second
    // A prayer pushed past midnight (short northern nights) belongs to the far right edge.
    val rolled = if (time.toLocalDate().isAfter(day.date)) 86400 else seconds
    return (rolled / 86400f).coerceIn(0f, 1f)
}

private fun daylight(day: PrayerDay): Duration {
    val sunrise = day.times[Prayer.SUNRISE]
    val maghrib = day.times[Prayer.MAGHRIB]
    if (sunrise == null || maghrib == null) return Duration.ZERO
    return Duration.between(sunrise, maghrib)
}

/** How many minutes a prayer moved between two days. */
private fun minuteShift(from: PrayerDay, to: PrayerDay, prayer: Prayer): Long {
    val a = from.times[prayer] ?: return 0
    val b = to.times[prayer] ?: return 0
    val aMinutes = a.toLocalTime().toSecondOfDay() / 60L
    val bMinutes = b.toLocalTime().toSecondOfDay() / 60L
    return bMinutes - aMinutes
}

/** Isha of the selected day to Fajr of the following one — the real night, across midnight. */
private fun nightLength(days: List<PrayerDay>, index: Int): Duration {
    val current = days.getOrNull(index) ?: return Duration.ZERO
    val isha = current.times[Prayer.ISHA] ?: return Duration.ZERO
    val nextFajr = days.getOrNull(index + 1)?.times?.get(Prayer.FAJR)
        ?: return Duration.ZERO
    val length = Duration.between(isha, nextFajr)
    return if (length.isNegative) Duration.ZERO else length
}
