package com.nur.prayer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.InkSoft
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.solidTone

/** Opaque, single-fill surfaces. No scrim, glass, blur, shadow or highlight gradient. */
enum class PanelLevel { RAISED, FLAT, INSET }

fun Modifier.nurPanel(shape: Shape, level: PanelLevel = PanelLevel.RAISED, accent: Color? = null): Modifier {
    val fill = when (level) {
        PanelLevel.RAISED -> InkSoft
        PanelLevel.FLAT -> SurfaceRaised
        PanelLevel.INSET -> SurfaceInset
    }
    return clip(shape).background(fill).border(1.dp, accent?.let { solidTone(it, 0.55f) } ?: SurfaceEdge, shape)
}

@Composable
fun AtlasPanel(
    modifier: Modifier = Modifier,
    corner: Dp = 18.dp,
    contentPadding: Dp = 16.dp,
    level: PanelLevel = PanelLevel.RAISED,
    accent: Color? = null,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier.nurPanel(RoundedCornerShape(corner), level, accent).padding(contentPadding), content = content)
}
