package com.nur.prayer.ui.quran

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.QuranIndex
import com.nur.prayer.quran.QuranMark
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.quran.QuranRepository
import com.nur.prayer.quran.QuranSearchHit
import com.nur.prayer.quran.QuranSearchIndex
import com.nur.prayer.quran.QuranSearchResult
import com.nur.prayer.quran.QuranStore
import com.nur.prayer.quran.SurahMeta
import com.nur.prayer.quran.QuranText
import com.nur.prayer.ui.components.EntranceClock
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.components.rememberEntranceClock
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.HGap
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/*
 * Table of contents, 0.17.0.
 *
 * Surahs, juz and bookmarks are three pages of one pager under a segmented control whose
 * indicator follows the finger, so "Суры ↔ Джузы" is a swipe as well as a tap. Typing in the
 * search replaces the pages with results (names in any script, numbers, "2:255"). Every list keeps
 * its scroll across a visit to the reader; coming back, the surah just read is brought into view.
 */
@Composable
internal fun QuranContents(
    store: QuranStore,
    colors: QuranColors,
    lastSurah: Int,
    query: String,
    onQuery: (String) -> Unit,
    tabs: PagerState,
    surahList: LazyListState,
    juzList: LazyListState,
    bookmarkList: LazyListState,
    onBack: () -> Unit,
    onOpen: (Int, Int) -> Unit
) {
    val ui = uiScale()
    val lang = L10n.language.code
    val clock = rememberEntranceClock()
    val searching = query.isNotBlank()

    // Back from the reader: the surah just read must be on screen, not 40 rows away. The list
    // state outlived the reader, so its first visible row is still the one the reader left.
    LaunchedEffect(Unit) {
        val row = HEAD_ROWS + (if (store.mark != null) 1 else 0) + lastSurah - 1
        val first = surahList.firstVisibleItemIndex
        if (row < first || row > first + VISIBLE_ROWS_GUESS) surahList.scrollToItem((row - 2).coerceAtLeast(0))
    }

    var khatmSheet by rememberSaveable { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize()) {
        QuranTopBar(tr("Коран"), colors, onBack)
        SearchField(query, onQuery, colors)
        Gap(12f)
        AnimatedContent(
            targetState = searching,
            transitionSpec = {
                (fadeIn(tween(200)) + slideInVertically(tween(260)) { h: Int -> h / 24 }) togetherWith
                    (fadeOut(tween(140)) + slideOutVertically(tween(200)) { h: Int -> -h / 32 })
            },
            label = "quranSearch", modifier = Modifier.weight(1f).fillMaxWidth()
        ) { showResults ->
            if (showResults) SearchResults(query, lang, colors, store, onOpen)
            else Column(Modifier.fillMaxSize()) {
                QuranTabs(tabs, listOf(tr("Суры"), tr("Джузы"), tr("Закладки")), colors)
                Gap(10f)
                HorizontalPager(state = tabs, key = { it }, modifier = Modifier.weight(1f).fillMaxWidth()) { page ->
                    when (page) {
                        0 -> SurahTab(store, colors, lang, surahList, clock, onOpen, onKhatm = { khatmSheet = true })
                        1 -> JuzTab(store, colors, lang, juzList, clock, onOpen)
                        else -> BookmarkTab(store, colors, lang, bookmarkList, onOpen)
                    }
                }
            }
        }
    }
    ReaderSheet(visible = khatmSheet, colors = colors, onDismiss = { khatmSheet = false }) {
        // The content outlives the slide-out by a moment; a plan made or cancelled must not flicker back.
        KhatmSheet(store, colors, onClose = { khatmSheet = false })
    }
    }
}

// ── chrome ───────────────────────────────────────────────────────────────────────────────────────

@Composable
internal fun QuranTopBar(title: String, colors: QuranColors, onBack: () -> Unit) {
    val ui = uiScale()
    Row(
        Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = ui.s(16f), vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundIconButton(GlyphKind.BACK, tr("Назад"), onBack, tint = colors.text, background = colors.raised)
        HGap(14f)
        Text(title, color = colors.text, fontSize = ui.t(26f), fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun SearchField(query: String, onQuery: (String) -> Unit, colors: QuranColors) {
    val ui = uiScale()
    Row(
        Modifier.padding(horizontal = ui.s(16f)).fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(colors.raised).padding(start = 16.dp, end = 6.dp).heightIn(min = 52.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f).padding(vertical = 14.dp)) {
            if (query.isEmpty()) Text(tr("Сура, слово или 2:255"), color = colors.textTertiary, fontSize = ui.t(15f), maxLines = 1)
            BasicTextField(
                value = query, onValueChange = onQuery, singleLine = true,
                textStyle = TextStyle(color = colors.text, fontSize = ui.t(16f)),
                cursorBrush = SolidColor(colors.accent), modifier = Modifier.fillMaxWidth()
            )
        }
        if (query.isNotEmpty()) {
            RoundIconButton(GlyphKind.CLOSE, tr("Очистить"), { onQuery("") }, size = 40.dp,
                tint = colors.textSecondary, background = colors.inset)
        }
    }
}

/**
 * Segmented tabs bound to the pager: the plate under the labels sits at
 * (currentPage + currentPageOffsetFraction) × segment width, so it slides with the finger and
 * lands with the page. `offset` is layout-relative, which mirrors it for Arabic.
 */
@Composable
private fun QuranTabs(tabs: PagerState, labels: List<String>, colors: QuranColors) {
    val ui = uiScale()
    val scope = rememberCoroutineScope()
    BoxWithConstraints(
        Modifier.padding(horizontal = ui.s(16f)).fillMaxWidth().height(46.dp)
            .clip(RoundedCornerShape(50)).background(colors.inset).padding(4.dp)
    ) {
        val segment = maxWidth / labels.size
        Box(
            Modifier
                .offset { IntOffset(((tabs.currentPage + tabs.currentPageOffsetFraction) * segment.toPx()).roundToInt(), 0) }
                .width(segment).fillMaxHeight().clip(RoundedCornerShape(50)).background(colors.raised)
        )
        Row(Modifier.fillMaxSize()) {
            labels.forEachIndexed { i, label ->
                val tint by animateColorAsState(
                    if (tabs.targetPage == i) colors.text else colors.textTertiary, tween(200), label = "quranTab"
                )
                Box(
                    Modifier.weight(1f).fillMaxHeight()
                        .pressClick(scaleTo = 0.97f, shape = RoundedCornerShape(50)) { scope.launch { tabs.animateScrollToPage(i) } },
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, color = tint, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
    }
}

// ── surahs ───────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun SurahTab(
    store: QuranStore,
    colors: QuranColors,
    lang: String,
    list: LazyListState,
    clock: EntranceClock,
    onOpen: (Int, Int) -> Unit,
    onKhatm: () -> Unit
) {
    val ui = uiScale()
    val mark = store.mark
    LazyColumn(
        Modifier.fillMaxSize(),
        state = list,
        contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(key = "khatm") {
            KhatmCard(
                store.khatm, colors, Modifier.entrance(0, clock = clock),
                onContinue = { page -> QuranMath.pageStart(page).let { onOpen(it.surah, it.ayah) } },
                onPlan = onKhatm
            )
        }
        if (mark != null) {
            item(key = "continue") {
                ContinueCard(mark, lang, colors, Modifier.entrance(0, clock = clock)) { onOpen(mark.surah, mark.ayah) }
            }
        }
        items(QuranIndex.SURAHS, key = { it.number }) { s ->
            val current = mark?.surah == s.number
            SurahRow(
                s, lang, colors, current,
                progress = if (current && mark != null) mark.ayah.toFloat() / s.ayat else null,
                modifier = Modifier.entrance(s.number, clock = clock)
            ) { onOpen(s.number, 0) }
        }
    }
}

/**
 * «Продолжить чтение» with the numbers that matter: the place, how much of the surah and of the
 * whole Quran lies behind it. The bar is the surah; the percentage is the mushaf (6236 ayat).
 */
@Composable
private fun ContinueCard(mark: QuranMark, lang: String, colors: QuranColors, modifier: Modifier, onClick: () -> Unit) {
    val ui = uiScale()
    val s = QuranMath.surah(mark.surah)
    val inSurah = mark.ayah.toFloat() / s.ayat
    val whole = QuranMath.quranProgress(mark.surah, mark.ayah)
    val percent = if (whole < 0.01f) "<1" else (whole * 100f).toInt().toString()
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(colors.card)
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(24.dp), onClick = onClick)
            .padding(ui.s(16f))
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("Продолжить чтение"), color = colors.accent.liftedForText(), fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
                Gap(2f)
                Text(tr("{0} · аят {1}", QuranMath.title(s, lang), mark.ayah), color = colors.text, fontSize = ui.t(18f),
                    fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (lang != "ar") ArabicText(s.arabic, 24f, color = colors.text, align = TextAlign.End)
        }
        Gap(12f)
        val track = colors.hairline
        val fill = colors.accent
        Box(
            Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(50)).drawBehind {
                drawRect(track)
                val w = size.width * inSurah.coerceIn(0f, 1f)
                drawRect(fill, topLeft = Offset(if (rtl) size.width - w else 0f, 0f), size = Size(w, size.height))
            }
        )
        Gap(8f)
        Text(
            tr("джуз {0}", QuranMath.juzOf(mark.surah, mark.ayah)) + " · " + tr("аят {0} из {1}", mark.ayah, s.ayat) +
                " · " + tr("{0}% Корана", percent),
            color = colors.textTertiary, fontSize = ui.t(12f)
        )
    }
}

@Composable
private fun SurahRow(
    s: SurahMeta,
    lang: String,
    colors: QuranColors,
    current: Boolean,
    progress: Float?,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val ui = uiScale()
    val meaning = QuranMath.meaning(s, lang)
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(colors.card)
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(20.dp), onClick = onClick)
            .padding(horizontal = ui.s(12f), vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NumberBadge(s.number, colors, highlighted = current, progress = progress)
        HGap(12f)
        Column(Modifier.weight(1f)) {
            Text(QuranMath.title(s, lang), color = colors.text, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            val place = if (s.medinan) tr("Мединская") else tr("Мекканская")
            Text(
                (if (meaning.isNotEmpty()) "$meaning · " else "") + place + " · " + tr("аятов: {0}", s.ayat),
                color = colors.textTertiary, fontSize = ui.t(13f), lineHeight = ui.t(18f)
            )
        }
        HGap(8f)
        if (lang != "ar") ArabicText(s.arabic, 22f, color = colors.text, align = TextAlign.End)
    }
}

// ── juz ──────────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun JuzTab(
    store: QuranStore,
    colors: QuranColors,
    lang: String,
    list: LazyListState,
    clock: EntranceClock,
    onOpen: (Int, Int) -> Unit
) {
    val ui = uiScale()
    val mark = store.mark
    val currentJuz = mark?.let { QuranMath.juzOf(it.surah, it.ayah) }
    LazyColumn(
        Modifier.fillMaxSize(),
        state = list,
        contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(QuranIndex.JUZ.size, key = { "juz$it" }) { i ->
            val juz = i + 1
            val current = juz == currentJuz
            JuzRow(
                juz, lang, colors, current,
                progress = if (current && mark != null) QuranMath.juzProgress(mark.surah, mark.ayah) else null,
                modifier = Modifier.entrance(i, clock = clock),
                onOpen = onOpen
            )
        }
    }
}

/** A juz names where it starts and ends — «Аль-Бакара 2:142 — Аль-Бакара 2:252» — and its size. */
@Composable
private fun JuzRow(
    juz: Int,
    lang: String,
    colors: QuranColors,
    current: Boolean,
    progress: Float?,
    modifier: Modifier,
    onOpen: (Int, Int) -> Unit
) {
    val ui = uiScale()
    val start = QuranMath.juzStart(juz)
    val end = QuranMath.juzEnd(juz)
    val from = QuranMath.surah(start.surah)
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(colors.card)
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(20.dp)) { onOpen(start.surah, start.ayah) }
            .padding(horizontal = ui.s(12f), vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NumberBadge(juz, colors, highlighted = current, progress = progress)
        HGap(12f)
        Column(Modifier.weight(1f)) {
            Text(tr("Джуз {0}", juz), color = colors.text, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
            Text(
                "${QuranMath.title(from, lang)} ${start.surah}:${start.ayah} — ${end.surah}:${end.ayah}",
                color = colors.textSecondary, fontSize = ui.t(13f), maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(tr("аятов: {0}", QuranMath.juzAyat(juz)), color = colors.textTertiary, fontSize = ui.t(12f))
        }
        if (lang != "ar") ArabicText(from.arabic, 20f, color = colors.textSecondary, align = TextAlign.End)
    }
}

// ── bookmarks ────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun BookmarkTab(
    store: QuranStore,
    colors: QuranColors,
    lang: String,
    list: LazyListState,
    onOpen: (Int, Int) -> Unit
) {
    val ui = uiScale()
    val marks = store.bookmarks
    if (marks.isEmpty()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = ui.s(32f)).padding(top = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("۞", color = colors.accent, fontSize = ui.t(40f))
            Gap(12f)
            Text(tr("Закладок пока нет"), color = colors.text, fontSize = ui.t(17f), fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center)
            Gap(6f)
            Text(
                tr("Удерживайте аят во время чтения и нажмите «В закладки» — он появится здесь."),
                color = colors.textTertiary, fontSize = ui.t(14f), lineHeight = ui.t(20f), textAlign = TextAlign.Center
            )
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        state = list,
        contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(marks, key = { it }) { key ->
            BookmarkRow(key, store, lang, colors, Modifier.animateItem(), onOpen)
        }
    }
}

@Composable
private fun BookmarkRow(key: Int, store: QuranStore, lang: String, colors: QuranColors, modifier: Modifier, onOpen: (Int, Int) -> Unit) {
    val ui = uiScale()
    val context = LocalContext.current
    val repo = remember { QuranRepository.get(context) }
    val surah = key / 1000
    val ayah = key % 1000
    val s = QuranMath.surah(surah)
    val translation = store.translation(lang)
    val preview by produceState<String?>(null, key, translation) {
        val a = runCatching { repo.surah(surah) }.getOrNull()?.getOrNull(ayah - 1)
        value = a?.let { it.translation(translation) ?: it.arabic }
    }
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(colors.card)
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(20.dp)) { onOpen(surah, ayah) }
            .padding(start = ui.s(12f), end = 6.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NumberBadge(surah, colors)
        HGap(12f)
        Column(Modifier.weight(1f)) {
            Text("${QuranMath.title(s, lang)} · $surah:$ayah", color = colors.text, fontSize = ui.t(16f),
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(preview.orEmpty(), color = colors.textTertiary, fontSize = ui.t(13f), lineHeight = ui.t(18f),
                maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        RoundIconButton(GlyphKind.CLOSE, tr("Убрать из закладок"), { store.toggleBookmark(key) }, size = 40.dp,
            tint = colors.textTertiary, background = colors.card)
    }
}

// ── search ───────────────────────────────────────────────────────────────────────────────────────

@Composable
private fun SearchResults(query: String, lang: String, colors: QuranColors, store: QuranStore, onOpen: (Int, Int) -> Unit) {
    val ui = uiScale()
    val context = LocalContext.current
    val markSurah = store.mark?.surah
    val reference = remember(query) { QuranMath.parseReference(query) }
    val page = remember(query) { QuranMath.parsePage(query) }
    // A page query is the page card; the surah list would only repeat its surah.
    val results = remember(query) { if (page != null) emptyList() else QuranMath.search(query) }
    val translation = store.translation(lang)
    val wants = QuranSearchIndex.wants(query)
    val arabicQuery = QuranText.hasArabic(query)
    // The text search: built on the first 3+ letter query, off the main thread, after a short pause
    // so that typing a word does not search for every prefix of it.
    val found by produceState<QuranSearchResult?>(null, query, translation, wants) {
        value = null
        if (!wants) {
            value = QuranSearchResult.EMPTY
            return@produceState
        }
        delay(SEARCH_DEBOUNCE_MILLIS)
        val entries = QuranSearchIndex.entries(context, translation)
        value = withContext(Dispatchers.Default) { QuranSearchIndex.find(entries, query) }
    }
    val result = found
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (reference != null) {
            item(key = "ref") {
                JumpCard(tr("Открыть аят {0}:{1}", reference.surah, reference.ayah), QuranMath.title(QuranMath.surah(reference.surah), lang),
                    colors, Modifier.animateItem()) { onOpen(reference.surah, reference.ayah) }
            }
        }
        if (page != null) {
            item(key = "page") {
                val m = QuranMath.pageStart(page)
                JumpCard(tr("Открыть страницу {0}", page), QuranMath.title(QuranMath.surah(m.surah), lang) + " " + m.surah + ":" + m.ayah,
                    colors, Modifier.animateItem()) { onOpen(m.surah, m.ayah) }
            }
        }
        items(results, key = { it.number }) { s ->
            SurahRow(s, lang, colors, markSurah == s.number, progress = null, modifier = Modifier.animateItem()) { onOpen(s.number, 0) }
        }
        if (result != null && result.hits.isNotEmpty()) {
            item(key = "hits-title") {
                Text(
                    if (result.total > result.hits.size) tr("Первые {0} из {1} аятов", result.hits.size, result.total)
                    else tr("Найдено аятов: {0}", result.total),
                    color = colors.textSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.animateItem().padding(top = 8.dp, start = 4.dp)
                )
            }
            items(result.hits, key = { "hit-${it.surah}-${it.ayah}" }) { hit ->
                HitRow(hit, lang, colors, translation, Modifier.animateItem()) { onOpen(hit.surah, hit.ayah) }
            }
        }
        val nothing = results.isEmpty() && reference == null && page == null && (result?.hits?.isEmpty() == true || !wants)
        if (nothing) item(key = "empty") {
            val hint = when {
                wants && !arabicQuery && translation == null -> tr("Поиск по смыслу работает по переводу: выберите его в настройках чтения.")
                !wants && query.trim().length < QuranSearchIndex.MIN_QUERY -> tr("Для поиска по тексту нужно хотя бы {0} буквы.", QuranSearchIndex.MIN_QUERY)
                else -> tr("Ничего не нашлось")
            }
            Text(hint, color = colors.textSecondary, fontSize = ui.t(15f), textAlign = TextAlign.Center,
                modifier = Modifier.animateItem().fillMaxWidth().padding(top = 32.dp, start = 12.dp, end = 12.dp))
        }
        if (wants && result == null) item(key = "searching") {
            Text(tr("Ищу…"), color = colors.textTertiary, fontSize = ui.t(14f), textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 24.dp))
        }
    }
}

@Composable
private fun JumpCard(title: String, subtitle: String, colors: QuranColors, modifier: Modifier, onClick: () -> Unit) {
    val ui = uiScale()
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(colors.accent.copy(alpha = 0.16f))
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(20.dp), onClick = onClick)
            .padding(ui.s(16f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = colors.text, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = colors.textTertiary, fontSize = ui.t(13f))
        }
        MushafChevron(colors.text, pointsLeft = true, modifier = Modifier.size(18.dp))
    }
}

/** One ayah of the text search: where it is, and the passage with the match marked. */
@Composable
private fun HitRow(hit: QuranSearchHit, lang: String, colors: QuranColors, translation: com.nur.prayer.quran.QuranTranslation?, modifier: Modifier, onClick: () -> Unit) {
    val ui = uiScale()
    val context = LocalContext.current
    val ayah by produceState<com.nur.prayer.quran.QuranAyah?>(null, hit.surah, hit.ayah) {
        value = runCatching { QuranRepository.get(context).surah(hit.surah) }.getOrNull()?.getOrNull(hit.ayah - 1)
    }
    val s = QuranMath.surah(hit.surah)
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(colors.card)
            .pressClick(scaleTo = 0.98f, shape = RoundedCornerShape(20.dp), onClick = onClick)
            .padding(ui.s(16f))
    ) {
        Text("${QuranMath.title(s, lang)} · ${hit.surah}:${hit.ayah}", color = colors.accent.liftedForText(),
            fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold)
        val a = ayah
        if (a != null) {
            Gap(6f)
            if (hit.arabic) {
                val ranges = QuranSearchIndex.arabicRanges(a.arabic, hit.ranges)
                val (text, moved) = QuranSearchIndex.snippet(a.arabic, ranges, ARABIC_SNIPPET_RADIUS)
                ArabicText(marked(text, moved, colors), 24f, Modifier.fillMaxWidth(), color = colors.text, align = TextAlign.Right)
            } else {
                val raw = a.translation(translation).orEmpty()
                val (text, moved) = QuranSearchIndex.snippet(raw, hit.ranges)
                Text(marked(text, moved, colors), color = colors.textSecondary, fontSize = ui.t(15f), lineHeight = ui.t(22f))
            }
        }
    }
}

/** [text] with the match ranges marked: the accent behind them and a heavier weight. */
private fun marked(text: String, ranges: List<IntRange>, colors: QuranColors): AnnotatedString = buildAnnotatedString {
    append(text)
    val style = SpanStyle(background = colors.accent.copy(alpha = 0.30f), color = colors.text, fontWeight = FontWeight.Bold)
    for (r in ranges) if (r.first >= 0 && r.last < text.length && !r.isEmpty()) addStyle(style, r.first, r.last + 1)
}

private const val SEARCH_DEBOUNCE_MILLIS = 180L
private const val ARABIC_SNIPPET_RADIUS = 70
/** Rows above the surah list in its LazyColumn: the khatm card. */
private const val HEAD_ROWS = 1

/** Rows that surely fit on a phone screen; a surah inside this window counts as visible. */
private const val VISIBLE_ROWS_GUESS = 5
