package com.nur.prayer.quran

import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * 0.18.0. The khatm plan: read the Quran to the end by a chosen day, counted in pages of the
 * 604-page Madani mushaf — not in ayat, whose length differs a hundredfold between al-Baqarah
 * and Juz Amma — so that every day asks for about the same time over the book.
 *
 * Pure and immutable: the store keeps one of these and swaps it for the next one. Days are
 * `LocalDate.toEpochDay()`; [day] is 1 on the day the plan was made.
 */
data class KhatmPlan(
    val startDay: Long,
    val targetDays: Int,
    /** Pages already behind the reader when the plan was made: 0 for a whole Quran. */
    val startPage: Int,
    /** Pages completed so far (0..604); the next one to read is lastPage + 1. */
    val lastPage: Int,
    /** The day [todayPages] was counted on; older counts are not today's. */
    val todayDay: Long,
    val todayPages: Int
) {
    val finished: Boolean get() = lastPage >= KhatmMath.PAGES
    val pagesLeft: Int get() = (KhatmMath.PAGES - lastPage).coerceAtLeast(0)
    /** The page to open next; the last page once the Quran is finished. */
    val nextPage: Int get() = (lastPage + 1).coerceAtMost(KhatmMath.PAGES)

    fun day(today: Long): Int = KhatmMath.dayNumber(today, startDay)

    /** Pages that should be behind the reader at the end of [today]. */
    fun expectedPage(today: Long): Int = KhatmMath.expectedPage(startPage, targetDays, day(today))

    /** Positive: ahead of the plan by that many pages, negative: behind, 0: exactly on it. */
    fun delta(today: Long): Int = lastPage - expectedPage(today)

    /** The plan's time is up and the Quran is not finished. */
    fun overdue(today: Long): Boolean = !finished && day(today) > targetDays

    fun readToday(today: Long): Int = if (todayDay == today) todayPages else 0

    /**
     * Pages [today] has to bring to be on the plan by its end: the day's share plus whatever was
     * missed before. 0 when the reader is already ahead.
     */
    fun goalToday(today: Long): Int = max(0, expectedPage(today) - (lastPage - readToday(today)))

    /** Today's share is done: the reader is at or ahead of the page the plan expects. */
    fun doneToday(today: Long): Boolean = finished || lastPage >= expectedPage(today)

    /** 0..1 progress of today's goal. */
    fun todayFraction(today: Long): Float {
        if (doneToday(today)) return 1f
        val goal = goalToday(today)
        return if (goal <= 0) 1f else (readToday(today).toFloat() / goal).coerceIn(0f, 1f)
    }

    /**
     * Reading reached [completedPage] pages. Only a step forward that is small enough to be
     * reading counts: a jump through the book (a juz from the table of contents, the fast-scroll
     * thumb) is not a hundred pages read, and a step back never takes progress away.
     */
    fun credited(completedPage: Int, today: Long): KhatmPlan {
        val p = completedPage.coerceIn(0, KhatmMath.PAGES)
        val gained = p - lastPage
        if (gained <= 0 || gained > KhatmMath.AUTO_WINDOW) return this
        return copy(lastPage = p, todayDay = today, todayPages = readToday(today) + gained)
    }

    /** The reader says where he is — forward or back; the day's count follows the correction. */
    fun movedTo(page: Int, today: Long): KhatmPlan {
        val p = page.coerceIn(startPage, KhatmMath.PAGES)
        val d = p - lastPage
        return copy(lastPage = p, todayDay = today, todayPages = max(0, readToday(today) + d))
    }

    companion object {
        /** A fresh plan starting [today] from [fromPage] pages done (0: the whole Quran). */
        fun start(today: Long, targetDays: Int, fromPage: Int = 0): KhatmPlan {
            val from = fromPage.coerceIn(0, KhatmMath.PAGES - 1)
            return KhatmPlan(today, targetDays.coerceIn(KhatmMath.MIN_DAYS, KhatmMath.MAX_DAYS), from, from, today, 0)
        }

        /** Stored values back into a plan; null when they do not make one. */
        fun restore(active: Boolean, startDay: Long, targetDays: Int, startPage: Int, lastPage: Int, todayDay: Long, todayPages: Int): KhatmPlan? {
            if (!active || startDay <= 0L || targetDays !in KhatmMath.MIN_DAYS..KhatmMath.MAX_DAYS) return null
            val from = startPage.coerceIn(0, KhatmMath.PAGES - 1)
            return KhatmPlan(startDay, targetDays, from, lastPage.coerceIn(from, KhatmMath.PAGES), todayDay, todayPages.coerceIn(0, KhatmMath.PAGES))
        }
    }
}

object KhatmMath {
    const val PAGES = QuranIndex.PAGE_COUNT
    const val MIN_DAYS = 1
    const val MAX_DAYS = 365
    /** The longest step of reading that is counted by itself; farther away is a jump, see [KhatmPlan.credited]. */
    const val AUTO_WINDOW = 8
    /** Presets of the plan sheet. */
    val PRESETS = intArrayOf(7, 15, 30, 60)

    /** 1 on [startDay] itself; a clock set back does not give day 0. */
    fun dayNumber(today: Long, startDay: Long): Int = (today - startDay + 1).coerceIn(1L, 100_000L).toInt()

    /**
     * Pages that must be behind the reader at the end of day [day] of [targetDays]:
     * `startPage + round(day × (604 − startPage) / targetDays)`, never below 1 or above 604.
     * For a whole Quran: `round(day × 604 / targetDays)`.
     */
    fun expectedPage(startPage: Int, targetDays: Int, day: Int): Int {
        val total = PAGES - startPage
        val step = (day.coerceAtLeast(1) * total.toDouble() / targetDays.coerceAtLeast(1)).roundToInt()
        return (startPage + step).coerceIn(max(1, startPage), PAGES)
    }

    /** The usual day's share, rounded up so that the last day is not longer than the others. */
    fun dailyPages(startPage: Int, targetDays: Int): Int =
        ceil((PAGES - startPage).toDouble() / targetDays.coerceAtLeast(1)).toInt().coerceAtLeast(1)
}
