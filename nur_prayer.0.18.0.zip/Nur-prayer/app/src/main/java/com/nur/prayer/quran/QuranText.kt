package com.nur.prayer.quran

/**
 * 0.18.0. Text shapes of an ayah that are not stored anywhere: the folded forms the search runs on
 * and the first-letter mask of the hifz mode. Pure and unit-tested (QuranTextTest).
 */
object QuranText {
    /** Tanzil "simple" Arabic: harakat, sukun, shadda, superscript alef, Quranic annotation marks, tatweel. */
    fun isMark(c: Char): Boolean =
        c in '\u0610'..'\u061A' || c in '\u064B'..'\u065F' || c == '\u0670' || c in '\u06D6'..'\u06ED' || c == '\u0640'

    fun hasArabic(text: String): Boolean = text.any { it in '\u0621'..'\u064A' || it == '\u0671' }

    /** Letters people type interchangeably: every alef as ا, alef maqsura as ي, ta marbuta as ه. */
    private fun baseLetter(c: Char): Char = when (c) {
        'آ', 'أ', 'إ', 'ٱ' -> 'ا'
        'ى', 'ئ' -> 'ي'
        'ة' -> 'ه'
        'ؤ' -> 'و'
        else -> c
    }

    /** Arabic without vowels and marks, letter variants unified, one space between words. */
    fun foldArabic(text: String): String = foldArabicMapped(text).first

    /**
     * [foldArabic] plus, for every folded character, the index of the original character it came
     * from: a match in the folded text is highlighted on the vowelled one.
     */
    fun foldArabicMapped(text: String): Pair<String, IntArray> {
        val out = StringBuilder(text.length)
        val map = IntArray(text.length)
        var n = 0
        for ((i, raw) in text.withIndex()) {
            if (isMark(raw)) continue
            if (raw.isWhitespace()) {
                if (out.isEmpty() || out[out.length - 1] == ' ') continue
                out.append(' '); map[n++] = i
                continue
            }
            out.append(baseLetter(raw)); map[n++] = i
        }
        if (out.isNotEmpty() && out[out.length - 1] == ' ') { out.setLength(out.length - 1); n-- }
        return out.toString() to map.copyOf(n)
    }

    /**
     * Lower case one character at a time, so the folded translation keeps the length — and the
     * offsets — of the shown one. ё/е and the Uzbek ‘okina/apostrophe variants are made equal;
     * Turkish İ becomes i (String.lowercase would turn it into two characters).
     */
    fun foldLatin(text: String): String {
        val out = CharArray(text.length)
        for ((i, c) in text.withIndex()) {
            out[i] = when (c) {
                'ё', 'Ё' -> 'е'
                'İ' -> 'i'
                'ʻ', 'ʼ', '‘', '’', '`', 'ʹ' -> '\''
                else -> Character.toLowerCase(c)
            }
        }
        return String(out)
    }

    /**
     * Hifz «первые буквы»: every word keeps its first letter with its vowels, the rest becomes •••.
     * The article ال is not a hint, so a word that starts with it keeps the next letter too.
     * Stand-alone pause marks (ۖ ۗ ۚ …) and one-letter words stay as they are.
     */
    fun firstLetters(text: String): String = text.split(' ').joinToString(" ") { maskWord(it) }

    private fun maskWord(word: String): String {
        val letters = word.indices.filter { !isMark(word[it]) }
        if (letters.size <= 1) return word
        val keep = if (letters.size > 2 && baseLetter(word[letters[0]]) == 'ا' && word[letters[1]] == 'ل') 3 else 1
        if (letters.size <= keep) return word
        // Everything up to the next letter: the kept letters with their own harakat and shadda.
        val cut = letters[keep]
        return word.substring(0, cut) + MASK
    }

    const val MASK = "•••"
}

/**
 * 0.18.0 hifz switch in the reader's bar. A hidden ayah opens by a tap on it; see [QuranText.firstLetters].
 */
enum class HifzMode {
    OFF, FIRST_LETTERS, HIDE_ARABIC, HIDE_TRANSLATION;

    companion object {
        fun of(ordinal: Int): HifzMode = entries.getOrElse(ordinal) { OFF }
    }
}
