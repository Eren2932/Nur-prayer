package com.nur.prayer

import com.nur.prayer.quran.KhatmMath
import com.nur.prayer.quran.KhatmPlan
import com.nur.prayer.quran.QuranIndex
import com.nur.prayer.quran.QuranMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

/** The khatm plan: pages of the 604-page mushaf, one formula, no clocks — days are plain numbers. */
class QuranKhatmTest {
    private val d0 = 20_000L

    @Test fun expectedPageIsTheShareOfTheBookByDay() {
        assertEquals(20, KhatmMath.expectedPage(0, 30, 1))      // 604 / 30 = 20.13
        assertEquals(302, KhatmMath.expectedPage(0, 30, 15))
        assertEquals(604, KhatmMath.expectedPage(0, 30, 30))    // the last day is the whole book
        assertEquals(604, KhatmMath.expectedPage(0, 30, 99))    // past the term it stays at the end
        assertEquals(2, KhatmMath.expectedPage(0, 365, 1))
        // From the middle: only the rest is divided.
        assertEquals(150, KhatmMath.expectedPage(100, 10, 1))   // 100 + round(50.4)
        assertEquals(604, KhatmMath.expectedPage(100, 10, 10))
        // A tiny remainder never expects less than where the reader already is.
        assertEquals(600, KhatmMath.expectedPage(600, 30, 1))
    }

    @Test fun expectedPageNeverDecreasesAndStaysInTheBook() {
        for (target in listOf(1, 7, 15, 30, 60, 365)) {
            for (from in listOf(0, 1, 100, 300, 603)) {
                var prev = 0
                for (day in 1..target + 3) {
                    val e = KhatmMath.expectedPage(from, target, day)
                    assertTrue("target $target from $from day $day", e in maxOf(1, from)..KhatmMath.PAGES)
                    assertTrue("monotonic: target $target from $from day $day", e >= prev)
                    prev = e
                }
                assertEquals(KhatmMath.PAGES, KhatmMath.expectedPage(from, target, target))
            }
        }
    }

    @Test fun dailyPagesRoundsUp() {
        assertEquals(21, KhatmMath.dailyPages(0, 30))
        assertEquals(2, KhatmMath.dailyPages(0, 365))
        assertEquals(31, KhatmMath.dailyPages(300, 10))
        assertEquals(604, KhatmMath.dailyPages(0, 1))
    }

    @Test fun dayNumberStartsAtOneAndSurvivesAClockSetBack() {
        assertEquals(1, KhatmMath.dayNumber(d0, d0))
        assertEquals(1, KhatmMath.dayNumber(d0 - 5, d0))
        assertEquals(30, KhatmMath.dayNumber(d0 + 29, d0))
    }

    @Test fun aFreshPlanAsksForTheFirstDaysShare() {
        val p = KhatmPlan.start(d0, 30)
        assertEquals(1, p.day(d0))
        assertEquals(20, p.expectedPage(d0))
        assertEquals(-20, p.delta(d0))
        assertEquals(20, p.goalToday(d0))
        assertFalse(p.doneToday(d0))
        assertFalse(p.finished)
        assertEquals(1, p.nextPage)
        assertEquals(604, p.pagesLeft)
    }

    @Test fun readingInSmallStepsIsCreditedAndCounted() {
        var p = KhatmPlan.start(d0, 30)
        p = p.credited(5, d0)
        assertEquals(5, p.lastPage)
        assertEquals(5, p.readToday(d0))
        assertEquals(0.25f, p.todayFraction(d0), 1e-6f)
        p = p.credited(12, d0).credited(20, d0)
        assertEquals(20, p.lastPage)
        assertEquals(20, p.readToday(d0))
        assertTrue(p.doneToday(d0))
        assertEquals(1f, p.todayFraction(d0), 0f)
    }

    @Test fun aJumpThroughTheBookIsNotReading() {
        val p = KhatmPlan.start(d0, 30)
        assertSame(p, p.credited(KhatmMath.AUTO_WINDOW + 1, d0))
        assertSame(p, p.credited(300, d0))
        assertEquals(KhatmMath.AUTO_WINDOW, p.credited(KhatmMath.AUTO_WINDOW, d0).lastPage)
    }

    @Test fun stepsBackAndRepeatsTakeNothingAway() {
        val p = KhatmPlan.start(d0, 30).credited(6, d0)
        assertSame(p, p.credited(6, d0))
        assertSame(p, p.credited(3, d0))
        assertSame(p, p.credited(0, d0))
        assertEquals(6, p.lastPage)
    }

    @Test fun tomorrowStartsFromZeroAndAsksForTheDebtToo() {
        val p = KhatmPlan.start(d0, 30).credited(8, d0).credited(16, d0)
        assertEquals(16, p.readToday(d0))
        assertEquals(0, p.readToday(d0 + 1))
        assertEquals(2, p.day(d0 + 1))
        assertEquals(40, p.expectedPage(d0 + 1))
        assertEquals(24, p.goalToday(d0 + 1))      // 40 − 16: the day's share and what was missed
        assertEquals(-24, p.delta(d0 + 1))
        assertEquals(0f, p.todayFraction(d0 + 1), 0f)
    }

    @Test fun aReaderAheadOfThePlanHasNothingOwedToday() {
        val p = KhatmPlan.start(d0, 30).movedTo(100, d0)
        assertTrue(p.delta(d0) > 0)
        assertTrue(p.doneToday(d0 + 1))            // expected 40 < 100
        assertEquals(0, p.goalToday(d0 + 1))
        assertEquals(1f, p.todayFraction(d0 + 1), 0f)
    }

    @Test fun theReaderCanCorrectHisPageBothWays() {
        var p = KhatmPlan.start(d0, 30).movedTo(20, d0)
        assertEquals(20, p.lastPage)
        assertEquals(20, p.readToday(d0))
        p = p.movedTo(15, d0)
        assertEquals(15, p.lastPage)
        assertEquals(15, p.readToday(d0))          // the day's count follows the correction
        p = p.movedTo(0, d0)
        assertEquals(0, p.readToday(d0))
        assertEquals(0, KhatmPlan.start(d0, 30).movedTo(-9, d0).lastPage)
    }

    @Test fun aPlanFromTheMiddleNeverGoesBelowItsStart() {
        val p = KhatmPlan.start(d0, 10, 100)
        assertEquals(100, p.lastPage)
        assertEquals(100, p.movedTo(5, d0).lastPage)
        assertEquals(150, p.expectedPage(d0))
        assertEquals(604, p.expectedPage(d0 + 9))
    }

    @Test fun reachingThePageSixHundredFourFinishesIt() {
        val p = KhatmPlan.start(d0, 30).movedTo(601, d0).credited(604, d0)
        assertTrue(p.finished)
        assertEquals(604, p.nextPage)
        assertEquals(0, p.pagesLeft)
        assertTrue(p.doneToday(d0))
        assertFalse(p.overdue(d0 + 100))
        assertSame(p, p.credited(604, d0))
    }

    @Test fun aPlanIsOverdueOnlyAfterItsLastDay() {
        val p = KhatmPlan.start(d0, 7)
        assertFalse(p.overdue(d0 + 6))
        assertTrue(p.overdue(d0 + 7))
    }

    @Test fun storedValuesMakeAPlanOnlyWhenTheyAreOne() {
        assertNull(KhatmPlan.restore(false, d0, 30, 0, 5, d0, 5))
        assertNull(KhatmPlan.restore(true, 0L, 30, 0, 5, d0, 5))
        assertNull(KhatmPlan.restore(true, d0, 0, 0, 5, d0, 5))
        assertNull(KhatmPlan.restore(true, d0, 366, 0, 5, d0, 5))
        val p = KhatmPlan.restore(true, d0, 30, -5, 700, d0, 9999)
        assertNotNull(p)
        assertEquals(0, p!!.startPage)
        assertEquals(604, p.lastPage)
        assertEquals(604, p.todayPages)
        assertEquals(10, KhatmPlan.restore(true, d0, 30, 10, 2, d0, 0)!!.lastPage)
    }

    @Test fun startClampsTheTermAndTheStart() {
        assertEquals(KhatmMath.MAX_DAYS, KhatmPlan.start(d0, 9999).targetDays)
        assertEquals(KhatmMath.MIN_DAYS, KhatmPlan.start(d0, 0).targetDays)
        assertEquals(603, KhatmPlan.start(d0, 30, 604).startPage)
    }

    @Test fun finishingAnAyahCompletesThePagesBeforeTheNextOne() {
        // Verified against the Madani layout: 2:255 is on page 42, and 2:256 is on the same page.
        assertEquals(42, QuranMath.pageOf(2, 255))
        assertEquals(41, QuranMath.pagesCompleted(2, 255))
        assertEquals(0, QuranMath.pagesCompleted(1, 1))        // 1:2 is on page 1 too
        assertEquals(1, QuranMath.pagesCompleted(1, 7))        // al-Fatiha ends page 1
        assertEquals(1, QuranMath.pagesCompleted(2, 1))        // 2:2 is on page 2 as well
        assertEquals(49, QuranMath.pagesCompleted(2, 286))     // al-Baqarah ends on page 49
        assertEquals(292, QuranMath.pagesCompleted(18, 1))      // 18:1 and 18:2 are both on page 293
        assertEquals(KhatmMath.PAGES, QuranMath.pagesCompleted(114, 6))
        assertEquals(KhatmMath.PAGES - 1, QuranMath.pagesCompleted(112, 4))
    }

    @Test fun pagesCompletedNeverGoesBackAndEndsAtTheLastPage() {
        var prev = 0
        for (s in QuranIndex.SURAHS) for (a in 1..s.ayat) {
            val done = QuranMath.pagesCompleted(s.number, a)
            assertTrue("${s.number}:$a", done >= prev)
            assertTrue("${s.number}:$a", done <= KhatmMath.PAGES)
            prev = done
        }
        assertEquals(KhatmMath.PAGES, prev)
    }
}
