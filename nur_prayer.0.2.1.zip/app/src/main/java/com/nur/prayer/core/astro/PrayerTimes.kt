package com.nur.prayer.core.astro

import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import kotlin.math.roundToLong

/**
 * Where a value ultimately came from. Surfaced in the UI so that a printed minute is never magic:
 * the user can see whether today's Isha is real astronomy or a high-latitude substitute.
 */
enum class TimeSource {
    /** True solar depression angle. The normal, correct case. */
    ANGLE,

    /** The method itself defines Isha as a fixed interval after sunset (Umm al-Qura, Qatar). */
    METHOD_INTERVAL,

    /** Angle unreachable: fixed interval around sunrise / sunset, the way DUM RF and DUM RT print it. */
    FIXED_INTERVAL,

    /** Angle unreachable: a fraction of the night. */
    NIGHT_FRACTION,

    /** Pulled back to the middle of the night so the daily order stays sane. */
    MIDNIGHT_BOUND
}

/**
 * Prayer times for one calendar day at one location.
 *
 * Times are computed as instants; a value is null only in the extreme polar case where even
 * sunrise / sunset do not exist. Callers should prefer [com.nur.prayer.core.astro.PrayerEngine]
 * which resolves those cases.
 *
 * ### The order of operations, and why it matters
 *
 * 1. Every marker is computed astronomically first.
 * 2. A high-latitude rule is consulted **only** for a marker that came back undefined, i.e. on a
 *    day when the Sun never sinks to the requested depression angle.
 * 3. The middle of the night is applied last as an absolute sanity bound.
 *
 * Step 2 used to run unconditionally, as a clamp. In Kazan on 15 August the Sun reaches -20.3°,
 * so Fajr at 18° (01:10) and Isha at 15° (21:35) are perfectly well defined — yet the clamp
 * replaced them with sunrise - 1/7 night (03:00) and sunset + 1/7 night (20:37). That single
 * defect also silently disabled the whole "calculation method" screen, because a night fraction
 * does not depend on the method's angles at all.
 */
class PrayerTimes(
    val date: LocalDate,
    val coordinates: Coordinates,
    val params: PrayerParams
) {
    val times: Map<Prayer, Instant?>

    /** True when Fajr and/or Isha had to be derived from something other than the angle. */
    val usedHighLatitudeRule: Boolean

    /** Provenance of the two markers that can need help. */
    val fajrSource: TimeSource
    val ishaSource: TimeSource

    /** Length of the night following [date], null in the polar case. */
    val night: Duration?

    init {
        val solar = SolarTime(date, coordinates)
        val tomorrowSolar = SolarTime(date.plusDays(1), coordinates)
        val base = date.atStartOfDay(ZoneOffset.UTC).toInstant()
        val tomorrowBase = date.plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant()

        fun hoursToInstant(from: Instant, hours: Double): Instant? =
            if (hours.isNaN() || hours.isInfinite()) null
            else from.plusMillis((hours * 3600_000.0).roundToLong())

        val sunriseTime = hoursToInstant(base, solar.sunrise)
        val sunsetTime = hoursToInstant(base, solar.sunset)
        val transitTime = hoursToInstant(base, solar.transit)
        val tomorrowSunrise = hoursToInstant(tomorrowBase, tomorrowSolar.sunrise)

        val method = params.method

        // ---- Step 1: pure astronomy -------------------------------------------------------
        var fajrTime = hoursToInstant(base, solar.hourAngle(-method.fajrAngle, afterTransit = false))
        var fajrFrom = TimeSource.ANGLE

        var asrTime = hoursToInstant(base, solar.afternoon(params.madhab.shadowLength))

        val maghribTime = if (method.maghribAngle > 0.0) {
            hoursToInstant(base, solar.hourAngle(-method.maghribAngle, afterTransit = true)) ?: sunsetTime
        } else {
            sunsetTime
        }

        var ishaTime: Instant?
        var ishaFrom: TimeSource
        if (method.ishaIntervalMinutes > 0) {
            ishaTime = sunsetTime?.plusSeconds(method.ishaIntervalMinutes * 60L)
            ishaFrom = TimeSource.METHOD_INTERVAL
        } else {
            ishaTime = hoursToInstant(base, solar.hourAngle(-method.ishaAngle, afterTransit = true))
            ishaFrom = TimeSource.ANGLE
        }

        // ---- Step 2 and 3: help only where astronomy came back empty ----------------------
        var nightLength: Duration? = null
        if (sunriseTime != null && sunsetTime != null && tomorrowSunrise != null) {
            val nightSpan = Duration.between(sunsetTime, tomorrowSunrise)
            nightLength = nightSpan
            val nightSeconds = nightSpan.seconds
            val rule = params.highLatitudeRule.resolve(coordinates.latitude)

            fun fraction(): Pair<Double, Double> = when (rule) {
                HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> 1.0 / 7.0 to 1.0 / 7.0
                HighLatitudeRule.TWILIGHT_ANGLE ->
                    method.fajrAngle / 60.0 to (if (method.ishaAngle > 0) method.ishaAngle else 17.0) / 60.0
                else -> 0.5 to 0.5
            }

            // The Russian boards treat the short-night season as one regime: the printed calendar
            // carries a single banner, "МЕНЯЕТСЯ ВРЕМЯ СУХУРА И ИША", and moves both markers
            // together rather than letting each one leave on its own day. Without that coupling
            // Isha returns to the angle roughly ten days early and sits 1h20m away from the
            // published value through late July.
            //
            // The season is judged by the Fajr angle — the stricter of the two — over *this* night
            // and the *next* one. That second look is what reproduces the calendar's own
            // asymmetry: on the last day of the season Isha is already astronomical while Fajr is
            // still an interval, because the night that follows is finally long enough. Verified
            // on 7 August 2026 in Kazan, where DUM RT prints Fajr 2:00 (interval) next to
            // Isha 22:11 (angle) on the very same line.
            val fajrAngleTomorrow = hoursToInstant(
                tomorrowBase,
                tomorrowSolar.hourAngle(-method.fajrAngle, afterTransit = false)
            )
            val shortNightSeason = rule == HighLatitudeRule.FIXED_INTERVAL &&
                fajrTime == null && fajrAngleTomorrow == null

            if (fajrTime == null) {
                if (rule == HighLatitudeRule.FIXED_INTERVAL) {
                    fajrTime = sunriseTime.minusSeconds(method.nightFajrMinutes * 60L)
                    fajrFrom = TimeSource.FIXED_INTERVAL
                } else {
                    fajrTime = sunriseTime.minusSeconds((nightSeconds * fraction().first).roundToLong())
                    fajrFrom = TimeSource.NIGHT_FRACTION
                }
            }
            if (ishaTime == null || (shortNightSeason && ishaFrom == TimeSource.ANGLE)) {
                if (rule == HighLatitudeRule.FIXED_INTERVAL) {
                    ishaTime = sunsetTime.plusSeconds(method.nightIshaMinutes * 60L)
                    ishaFrom = TimeSource.FIXED_INTERVAL
                } else {
                    ishaTime = sunsetTime.plusSeconds((nightSeconds * fraction().second).roundToLong())
                    ishaFrom = TimeSource.NIGHT_FRACTION
                }
            }

            // Absolute bound, always on: neither marker may cross the middle of the night.
            // On a normal day this never triggers; it exists so a pathological input cannot
            // produce an Isha that lands after Fajr.
            val fajrFloor = sunriseTime.minusSeconds(nightSeconds / 2)
            val ishaCeiling = sunsetTime.plusSeconds(nightSeconds / 2)
            fajrTime?.let { if (it.isBefore(fajrFloor)) { fajrTime = fajrFloor; fajrFrom = TimeSource.MIDNIGHT_BOUND } }
            ishaTime?.let { if (it.isAfter(ishaCeiling)) { ishaTime = ishaCeiling; ishaFrom = TimeSource.MIDNIGHT_BOUND } }
        }

        // Asr can be undefined at high latitudes in winter: the Sun never climbs high enough.
        var asrDegraded = false
        if (asrTime == null) {
            asrTime = hoursToInstant(base, solar.afternoon(Madhab.STANDARD.shadowLength))
            if (asrTime != null) asrDegraded = true
        }
        if (asrTime == null && transitTime != null && maghribTime != null) {
            // Last resort: two thirds of the way from Dhuhr to Maghrib, the classic approximation.
            val span = Duration.between(transitTime, maghribTime).seconds
            asrTime = transitTime.plusSeconds(span * 2 / 3)
            asrDegraded = true
        }

        fajrSource = fajrFrom
        ishaSource = ishaFrom
        night = nightLength
        usedHighLatitudeRule = asrDegraded ||
            fajrFrom != TimeSource.ANGLE ||
            (ishaFrom != TimeSource.ANGLE && ishaFrom != TimeSource.METHOD_INTERVAL)

        fun adjust(prayer: Prayer, value: Instant?): Instant? =
            value?.plusSeconds(params.adjustmentMinutes(prayer) * 60L)?.let { roundToMinute(it, params.rounding) }

        val raw = linkedMapOf(
            Prayer.FAJR to adjust(Prayer.FAJR, fajrTime),
            Prayer.SUNRISE to adjust(Prayer.SUNRISE, sunriseTime),
            Prayer.DHUHR to adjust(Prayer.DHUHR, transitTime),
            Prayer.ASR to adjust(Prayer.ASR, asrTime),
            Prayer.MAGHRIB to adjust(Prayer.MAGHRIB, maghribTime),
            Prayer.ISHA to adjust(Prayer.ISHA, ishaTime)
        )
        times = enforceOrder(raw)
    }

    /**
     * Guarantees a strictly increasing sequence with at least one minute between markers.
     * Needed on the few days a year when a short night makes two markers collapse into the same
     * minute after rounding: the UI and the alarm chain both rely on a strict order.
     */
    private fun enforceOrder(source: Map<Prayer, Instant?>): Map<Prayer, Instant?> {
        val result = LinkedHashMap<Prayer, Instant?>(source)
        val sunrise = result[Prayer.SUNRISE]
        val fajr = result[Prayer.FAJR]
        if (sunrise != null && fajr != null && !fajr.isBefore(sunrise)) {
            result[Prayer.FAJR] = sunrise.minusSeconds(60)
        }
        val order = listOf(Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)
        var previous: Instant? = null
        for (prayer in order) {
            val value = result[prayer] ?: continue
            val bound = previous
            if (bound != null && !value.isAfter(bound)) {
                result[prayer] = bound.plusSeconds(60)
            }
            previous = result[prayer]
        }
        return result
    }

    val isComplete: Boolean get() = times.values.none { it == null }

    private fun roundToMinute(instant: Instant, mode: RoundingMode): Instant {
        val seconds = instant.epochSecond
        val remainder = ((seconds % 60) + 60) % 60
        val floor = seconds - remainder
        val result = when (mode) {
            RoundingMode.DOWN -> floor
            RoundingMode.UP -> if (remainder == 0L) floor else floor + 60
            RoundingMode.NEAREST -> if (remainder >= 30L) floor + 60 else floor
        }
        return Instant.ofEpochSecond(result)
    }
}
