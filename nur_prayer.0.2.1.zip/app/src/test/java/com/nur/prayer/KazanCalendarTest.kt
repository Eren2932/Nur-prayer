package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.PrayerParams
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.core.astro.TimeSource
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import kotlin.math.abs

/**
 * Locks the engine against the printed calendar of the Spiritual Board of Tatarstan
 * ("Казан өчен намаз вакытлары", август 2026), transcribed from a photograph of the poster.
 *
 * This is the test that would have caught the release bug: Isha was published at 20:37 while the
 * mosque called it at 21:36, because a high-latitude rule was applied as an unconditional clamp
 * instead of a fallback for days when the Sun cannot reach the angle.
 */
class KazanCalendarTest {

    private val kazan = Coordinates(55.7963, 49.1064)
    private val zone: ZoneId = ZoneId.of("Europe/Moscow")
    private val params = PrayerParams(
        method = CalculationMethod.SPIRITUAL_BOARD_TATARSTAN,
        madhab = Madhab.HANAFI,
        highLatitudeRule = HighLatitudeRule.AUTO,
        rounding = RoundingMode.NEAREST
    )

    /** day of August 2026 to Fajr, Sunrise, Zenith, Asr, Maghrib, Isha as printed. */
    private val published = mapOf(
        1 to listOf("1:48", "3:48", "11:50", "17:14", "19:51", "21:21"),
        2 to listOf("1:50", "3:50", "11:50", "17:13", "19:49", "21:19"),
        6 to listOf("1:58", "3:58", "11:50", "17:08", "19:40", "21:10"),
        9 to listOf("0:21", "4:03", "11:49", "17:03", "19:34", "22:02"),
        10 to listOf("0:33", "4:05", "11:49", "17:02", "19:32", "21:57"),
        11 to listOf("0:43", "4:07", "11:49", "17:01", "19:29", "21:53"),
        12 to listOf("0:51", "4:09", "11:49", "16:59", "19:27", "21:49"),
        13 to listOf("0:58", "4:11", "11:48", "16:57", "19:25", "21:44"),
        14 to listOf("1:05", "4:13", "11:48", "16:56", "19:22", "21:40"),
        15 to listOf("1:11", "4:15", "11:48", "16:54", "19:20", "21:36"),
        16 to listOf("1:16", "4:17", "11:48", "16:53", "19:18", "21:32"),
        17 to listOf("1:22", "4:19", "11:48", "16:51", "19:15", "21:28"),
        18 to listOf("1:27", "4:21", "11:47", "16:49", "19:13", "21:24"),
        19 to listOf("1:32", "4:23", "11:47", "16:48", "19:11", "21:20"),
        20 to listOf("1:36", "4:25", "11:47", "16:46", "19:08", "21:17")
    )

    @Test
    fun `matches the printed DUM RT calendar for Kazan within three minutes`() {
        val order = listOf(
            Prayer.FAJR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA
        )
        for ((dayOfMonth, expected) in published) {
            val date = LocalDate.of(2026, 8, dayOfMonth)
            val day = PrayerEngine.day(date, kazan, zone, params)
            order.forEachIndexed { index, prayer ->
                val actual = day.at(prayer).toLocalTime()
                val target = LocalTime.parse(padded(expected[index]))
                val delta = minuteDistance(actual, target)
                assertTrue(
                    "$date ${prayer.name}: календарь ${expected[index]}, движок $actual, расхождение $delta мин",
                    delta <= 3
                )
            }
        }
    }

    @Test
    fun `Isha in Kazan on 15 August is astronomical, not a seventh of the night`() {
        val day = PrayerEngine.day(LocalDate.of(2026, 8, 15), kazan, zone, params)
        val isha = day.at(Prayer.ISHA).toLocalTime()

        // The Sun reaches -20.3 degrees that night, so the 15 degree angle is perfectly defined.
        assertEquals(TimeSource.ANGLE, day.ishaSource)
        assertTrue("Иша должна быть около 21:35, получили $isha", minuteDistance(isha, LocalTime.of(21, 35)) <= 2)

        // The exact wrong answer the released build produced. Never again.
        assertTrue("Иша снова зажата в 1/7 ночи", minuteDistance(isha, LocalTime.of(20, 37)) > 30)
    }

    @Test
    fun `short summer nights fall back to the intervals the board actually prints`() {
        val day = PrayerEngine.day(LocalDate.of(2026, 8, 1), kazan, zone, params)
        assertEquals(TimeSource.FIXED_INTERVAL, day.fajrSource)
        assertEquals(TimeSource.FIXED_INTERVAL, day.ishaSource)

        // Fajr = sunrise - 120 min, Isha = sunset + 90 min, verified digit for digit on the poster.
        val sunrise = day.at(Prayer.SUNRISE)
        val maghrib = day.at(Prayer.MAGHRIB)
        assertEquals(120L, java.time.Duration.between(day.at(Prayer.FAJR), sunrise).toMinutes())
        assertEquals(90L, java.time.Duration.between(maghrib, day.at(Prayer.ISHA)).toMinutes())
    }

    @Test
    fun `calculation method actually changes Fajr and Isha`() {
        // The released build looked like the method picker was a stub. It was not a stub: the
        // clamp downstream discarded the angles. This test fails the moment that regresses.
        val date = LocalDate.of(2026, 8, 15)
        val reference = PrayerEngine.day(date, kazan, zone, params)

        val laterIsha = PrayerEngine.day(
            date, kazan, zone, params.copy(method = CalculationMethod.MUSLIM_WORLD_LEAGUE)
        )
        assertNotEquals(
            "Иша при 17° обязана отличаться от Иши при 15°",
            reference.at(Prayer.ISHA), laterIsha.at(Prayer.ISHA)
        )
        assertTrue(laterIsha.at(Prayer.ISHA).isAfter(reference.at(Prayer.ISHA)))

        val earlierFajr = PrayerEngine.day(
            date, kazan, zone, params.copy(method = CalculationMethod.NORTH_AMERICA)
        )
        assertTrue(
            "Фаджр при 15° обязан быть позже, чем при 18°",
            earlierFajr.at(Prayer.FAJR).isAfter(reference.at(Prayer.FAJR))
        )
    }

    @Test
    fun `rounding mode moves a time by at most one minute`() {
        val date = LocalDate.of(2026, 8, 15)
        val up = PrayerEngine.day(date, kazan, zone, params.copy(rounding = RoundingMode.UP))
        val down = PrayerEngine.day(date, kazan, zone, params.copy(rounding = RoundingMode.DOWN))
        for (prayer in Prayer.entries) {
            val gap = java.time.Duration.between(down.at(prayer), up.at(prayer)).toMinutes()
            assertTrue("${prayer.name}: округление разошлось на $gap мин", gap in 0..1)
        }
    }

    private fun padded(value: String): String =
        if (value.length == 4) "0$value" else value

    /** Distance in whole minutes on a 24 hour circle, so 23:59 and 00:01 are two apart. */
    private fun minuteDistance(a: LocalTime, b: LocalTime): Long {
        val direct = abs(a.toSecondOfDay() - b.toSecondOfDay()) / 60L
        return minOf(direct, 1440L - direct)
    }
}
