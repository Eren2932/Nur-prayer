package com.nur.prayer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.width
import androidx.compose.ui.unit.height
import com.nur.prayer.ui.theme.LocalUiScale
import com.nur.prayer.ui.theme.UiScale
import org.junit.Assert.assertTrue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.click
import androidx.compose.ui.test.getUnclippedBoundsInRoot
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performTouchInput
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.daily.DailyStories
import com.nur.prayer.ui.daily.StoryScreen
import com.nur.prayer.ui.theme.NurTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class StoryViewerUiTest {
    @get:Rule val ui = createComposeRule()

    @Test fun completeLongStoryFitsShortWindowAtNormalAndDoubleFontSize() {
        val font = mutableFloatStateOf(1f)
        val long = DailyStories.DUAS.maxBy { it.ru.length + it.arabic.orEmpty().length }
        ui.mainClock.autoAdvance = false
        ui.setContent {
            NurTheme {
                CompositionLocalProvider(LocalDensity provides Density(LocalDensity.current.density, font.floatValue),
                    LocalUiScale provides UiScale.of(320, 430, font.floatValue)) {
                    Box(Modifier.size(320.dp, 430.dp)) { StoryScreen(listOf(long), 0, 1, 0L, {}, {}) }
                }
            }
        }
        val art = ui.onNodeWithTag("story-art", useUnmergedTree = true)
        ui.waitUntil(5000L) {
            ui.mainClock.advanceTimeByFrame()
            ui.onAllNodesWithTag("story-art", useUnmergedTree = true).fetchSemanticsNodes().size == 1
        }
        val bounds = art.getUnclippedBoundsInRoot()
        val area = ui.onNodeWithTag("story-input", useUnmergedTree = true).getUnclippedBoundsInRoot()
        assertTrue(bounds.width > 0.dp && bounds.height > 0.dp)
        assertTrue(bounds.top >= area.top + 76.dp && bounds.bottom <= area.bottom - 63.dp)
        ui.runOnIdle { font.floatValue = 2f }
        ui.mainClock.advanceTimeBy(64)
        assertEquals(bounds, art.getUnclippedBoundsInRoot())
    }

    @Test fun holdKeepsArtStationaryReleaseRestoresChromeAndTapsPage() {
        ui.mainClock.autoAdvance = false // never idle the story to its automatic end
        val slides = DailyStories.HADITH.take(4)
        ui.setContent { NurTheme { StoryScreen(slides, 0, 1, 0L, {}, {}) } }
        val touch = ui.onNodeWithTag("story-input", useUnmergedTree = true)
        val art = ui.onNodeWithTag("story-art", useUnmergedTree = true)
        val count = ui.onNodeWithTag("story-count", useUnmergedTree = true)
        fun awaitCount(number: Int) {
            ui.waitUntil(5000L) {
                ui.mainClock.advanceTimeByFrame()
                runCatching { count.assertTextEquals("$number / 4") }.isSuccess
            }
        }
        ui.waitUntil(5000L) {
            ui.mainClock.advanceTimeByFrame()
            ui.onAllNodesWithTag("story-art", useUnmergedTree = true).fetchSemanticsNodes().size == 1
        }
        val before = art.getUnclippedBoundsInRoot()
        touch.performTouchInput { down(center) }
        ui.mainClock.advanceTimeBy(450)
        ui.waitUntil(2500L) {
            ui.mainClock.advanceTimeByFrame()
            ui.onAllNodesWithTag("story-count", useUnmergedTree = true).fetchSemanticsNodes().isEmpty()
        }
        assertEquals(before, art.getUnclippedBoundsInRoot())
        touch.performTouchInput { advanceEventTime(450); up() }
        awaitCount(1)
        assertEquals(before, art.getUnclippedBoundsInRoot())
        touch.performTouchInput { click(Offset(width * .8f, center.y)) }
        awaitCount(2)
        touch.performTouchInput { click(Offset(width * .1f, center.y)) }
        awaitCount(1)
    }
}
