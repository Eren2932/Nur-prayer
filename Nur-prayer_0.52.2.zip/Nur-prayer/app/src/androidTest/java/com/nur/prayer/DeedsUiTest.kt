package com.nur.prayer

import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.test.hasText
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.test.getUnclippedBoundsInRoot
import com.nur.prayer.ui.theme.LocalUiScale
import com.nur.prayer.ui.theme.UiScale
import androidx.compose.runtime.remember
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.today.TodayActions
import com.nur.prayer.ui.today.TodayScreen
import com.nur.prayer.ui.today.TodayState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.assert
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DeedsUiTest {
    @get:Rule val compose = createComposeRule()

    @Test fun everyCardHasItsOwnDestination() {
        val opened = mutableListOf<String>()
        compose.setContent {
            NurTheme {
                TodayScreen(TodayState(AzkarSet.EVENING, 12, 16, 1, 3, 0L, false, 20123L, 0, true), remember { Reveal(true) },
                    TodayActions({}, { opened += "names" }, { opened += "vird" }, { opened += it.name },
                        { opened += "salawat" }, { opened += "story" }))
            }
        }
        compose.onAllNodesWithText("Читать").assertCountEquals(1)
        compose.onNodeWithText("Коран").assertDoesNotExist()
        for (title in listOf("99 имён Аллаха", "Вирд дня", "Утренние азкары", "Вечерние азкары", "Зикр", "На сегодня")) {
            compose.onNodeWithText(title).performScrollTo().performClick()
        }
        compose.runOnIdle { assertEquals(listOf("names", "vird", "MORNING", "EVENING", "salawat", "story"), opened) }
    }

    @Test fun coverSpansBothRightHandTilesAndRowsAlign() {
        compose.setContent {
            NurTheme {
                CompositionLocalProvider(LocalUiScale provides UiScale.of(393, 851, 1f),
                    LocalDensity provides Density(LocalDensity.current.density, 1f)) {
                    TodayScreen(TodayState(AzkarSet.MORNING, 17, 17, 0, 3, 0L, false, 20123L, 0, true), remember { Reveal(true) },
                        TodayActions({}, {}, {}, {}, {}, {}))
                }
            }
        }
        fun bounds(label: String) = compose.onNodeWithText(label).getUnclippedBoundsInRoot()
        val names = bounds("99 имён Аллаха"); val star = bounds("Вирд дня")
        val sun = bounds("Утренние азкары"); val moon = bounds("Вечерние азкары")
        val salawat = bounds("Зикр"); val story = bounds("На сегодня")
        assertEquals(story.top.value, names.top.value, 1f)
        assertEquals(story.bottom.value, star.bottom.value, 1f)
        assertEquals(11f, (names.left - story.right).value, 1f)
        assertEquals(11f, (star.top - names.bottom).value, 1f)
        assertEquals(21f, (sun.top - story.bottom).value, 1f)
        assertEquals(sun.top.value, moon.top.value, 1f)
        assertEquals(16f, (salawat.top - sun.bottom).value, 1f)
    }

    @Test fun largeSystemFontDoesNotReflowDashboardAndReadFollowsTheCurrentSet() {
        val scale = mutableFloatStateOf(1f)
        val current = mutableStateOf(AzkarSet.MORNING)
        val opened = mutableListOf<AzkarSet>()
        compose.setContent {
            NurTheme {
                CompositionLocalProvider(LocalUiScale provides UiScale.of(393, 851, scale.floatValue),
                    LocalDensity provides Density(LocalDensity.current.density, scale.floatValue)) {
                    TodayScreen(TodayState(current.value, 18, 18, 0, 3, 0L, false, 20123L, 0, true),
                        remember { Reveal(true) }, TodayActions({}, {}, {}, { opened += it }, {}, {}))
                }
            }
        }
        val tiles = listOf("На сегодня", "99 имён Аллаха", "Вирд дня", "Утренние азкары", "Вечерние азкары", "Зикр")
        fun bounds() = tiles.map { compose.onNodeWithText(it).getUnclippedBoundsInRoot() }
        val base = bounds()
        compose.onNode(hasText("Читать") and hasText("Утренние азкары")).performClick()
        compose.runOnIdle { scale.floatValue = 2f; current.value = AzkarSet.EVENING }
        assertEquals(base, bounds())
        compose.onAllNodesWithText("Читать").assertCountEquals(1)
        compose.onNode(hasText("Читать") and hasText("Вечерние азкары")).performClick()
        compose.runOnIdle { assertEquals(listOf(AzkarSet.MORNING, AzkarSet.EVENING), opened) }
    }

    @Test fun narrowViewportReflowsAndReportsNonSequentialReadMask() {
        compose.setContent {
            NurTheme {
                Box(Modifier.width(250.dp)) {
                    TodayScreen(TodayState(AzkarSet.MORNING, 17, 17, 0, 3, 0L, false, 20123L, 10, true),
                        remember { Reveal(true) }, TodayActions({}, {}, {}, {}, {}, {}))
                }
            }
        }
        val cover = compose.onNodeWithText("На сегодня")
        cover.assertIsEnabled().assert(SemanticsMatcher.expectValue(SemanticsProperties.StateDescription, "Просмотрено: 2 из 4"))
        val a = cover.getUnclippedBoundsInRoot()
        val b = compose.onNodeWithText("99 имён Аллаха").getUnclippedBoundsInRoot()
        assertEquals(a.left.value, b.left.value, 1f)
        org.junit.Assert.assertTrue(b.top >= a.bottom)
        compose.onNodeWithText("Зикр").performScrollTo().assertIsEnabled()
    }
}
