package com.nur.prayer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import com.nur.prayer.ui.components.LaunchGlint
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class LaunchGlintRenderTest {
    @get:Rule val compose = createComposeRule()

    @Test fun realMaskHasOneTravellingReflectionAndClearEnds() {
        val phase = mutableFloatStateOf(0f)
        compose.setContent {
            Box(Modifier.testTag("glint-pixel-probe").background(Color.Black)) {
                LaunchGlint(painterResource(R.drawable.ic_splash_glint)) { phase.floatValue }
            }
        }
        fun brightCentre(p: Float): Float? {
            compose.runOnIdle { phase.floatValue = p }
            val frame = compose.onNodeWithTag("glint-pixel-probe").captureToImage().toPixelMap()
            var weight = 0f
            var moment = 0f
            var pixels = 0
            for (y in 0 until frame.height) for (x in 0 until frame.width) {
                val light = frame[x,y].red
                if (light > 0.10f) { weight += light; moment += x * light; pixels++ }
            }
            if (pixels == 0) return null
            assertTrue(pixels > frame.width * frame.height / 60)
            return moment / weight / frame.width
        }
        assertTrue(brightCentre(0f) == null)
        val left = requireNotNull(brightCentre(.35f))
        val right = requireNotNull(brightCentre(.65f))
        assertTrue(right - left > .30f)
        assertTrue(brightCentre(1f) == null)
    }
}
