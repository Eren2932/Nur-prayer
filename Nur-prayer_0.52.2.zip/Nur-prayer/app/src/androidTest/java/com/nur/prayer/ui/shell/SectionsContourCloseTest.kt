package com.nur.prayer.ui.shell

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.Density
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test

class SectionsContourCloseTest {
    @get:Rule val compose = createComposeRule()

    @Test fun closedTargetAlreadyShowsSilverWhilePanelIsStillAtFullProgress() {
        val shell = ShellState().apply { show() }
        runBlocking { shell.snap() } // Hold progress at 1, even after hide(). No spring drives this fixture.
        compose.setContent {
            CompositionLocalProvider(LocalDensity provides Density(3f)) {
                Box(Modifier.background(Color.Black)) {
                    BarCenter(shell, false, true, remember { mutableStateOf(Color.Transparent) },
                        contourEligible = true, scale = 1f, modifier = Modifier)
                }
            }
        }
        compose.waitForIdle()
        val node = compose.onNodeWithTag("sections-ring", useUnmergedTree = true)
        fun hasColdInk(): Boolean {
            val map = node.captureToImage().toPixelMap()
            // The static border, cross, dots and ground are neutral. Only the moving profile has blue > red.
            var count = 0
            for (y in 0 until map.height) for (x in 0 until map.width) {
                val c = map[x,y]
                if (c.blue-c.red > .035f) count++
            }
            return count > 12
        }
        compose.mainClock.autoAdvance = false
        repeat(3) {
            assertTrue(!hasColdInk())
            compose.runOnIdle { shell.hide() }
            compose.mainClock.advanceTimeByFrame()
            assertTrue(hasColdInk())
            compose.runOnIdle { assertEquals(1f, shell.progress, 0f); shell.show() }
            compose.mainClock.advanceTimeByFrame()
        }
    }
}
