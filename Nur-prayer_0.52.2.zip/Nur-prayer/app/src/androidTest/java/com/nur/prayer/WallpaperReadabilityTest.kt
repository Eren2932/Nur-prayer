package com.nur.prayer

import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.ui.home.HomeWallpaperExposure
import com.nur.prayer.ui.theme.HomeSystemBars
import com.nur.prayer.ui.theme.paletteFor
import com.nur.prayer.ui.wallpaper.WallpaperBackdrop
import com.nur.prayer.ui.wallpaper.WallpaperCatalog
import com.nur.prayer.ui.wallpaper.WallpaperScreen
import com.nur.prayer.ui.wallpaper.WallpaperToneAnalyzer
import com.nur.prayer.ui.wallpaper.WallpaperTonePolicy
import com.nur.prayer.ui.wallpaper.rememberWallpaperTone
import java.io.File
import java.security.MessageDigest
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class WallpaperReadabilityTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    @Test fun realBitmapDecodeUsesTheViewportAndCachesResults() = runBlocking {
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        for ((id, paper) in listOf("kaaba_day" to true, "aqsa_qibli" to false, "night_mosque" to false)) {
            val w = requireNotNull(WallpaperCatalog.find(id))
            val key = WallpaperToneAnalyzer.Key(w.id, IntSize(692, 1538), null)
            val t = requireNotNull(WallpaperToneAnalyzer.load(ctx, w, key))
            assertEquals(id, paper, WallpaperTonePolicy.isPaper(t))
            assertSame(t, WallpaperToneAnalyzer.load(ctx, w, key))
        }
    }

    @Test fun storedPhotoIdRestoresAndUsesTheSameAnalyzerAsTheAsset() = runBlocking {
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        val image = ctx.assets.open("wallpapers/kaaba_day.webp").use { it.readBytes() }
        val hash = MessageDigest.getInstance("SHA-256").digest(image).joinToString("") { "%02x".format(it) }
        val id = "photo_$hash"
        val directory = File(ctx.filesDir, "wallpaper-photos").apply { mkdirs() }
        val photo = File(directory, id)
        val created = photo.createNewFile()
        try {
            if (created) photo.writeBytes(image)
            val restored = WallpaperCatalog.resolve(id, skyBackdrop = true)
            assertEquals(id, restored.id)
            val key = WallpaperToneAnalyzer.Key(id, IntSize(692, 1538), null)
            assertTrue(WallpaperTonePolicy.isPaper(requireNotNull(WallpaperToneAnalyzer.load(ctx, restored, key))))
            assertNull(WallpaperCatalog.find("photo_../other"))
        } finally { if (created) photo.delete() }
    }

    @Test fun changingTheWallpaperNotTheRevealOwnsTheStatusBarTone() {
        val wall = mutableStateOf(requireNotNull(WallpaperCatalog.find("kaaba_day")))
        val reveal = mutableFloatStateOf(0f)
        compose.setContent {
            Box(Modifier.size(160.dp, 320.dp)) {
                val palette = paletteFor(Prayer.ISHA)
                WallpaperBackdrop(wall.value, palette, dim = { 0f }, daySoft = { reveal.floatValue }, backdropContrast = { 0f })
                val tone = rememberWallpaperTone(wall.value, palette)
                HomeWallpaperExposure(tone) { reveal.floatValue }
                HomeSystemBars(WallpaperTonePolicy.isPaper(tone))
            }
        }
        fun darkGlyphs(): Boolean {
            val window = compose.activity.window
            return WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars
        }
        for ((id, dark) in listOf("kaaba_day" to true, "aqsa_qibli" to false, "kaaba_day" to true)) {
            compose.runOnIdle { wall.value = requireNotNull(WallpaperCatalog.find(id)) }
            compose.waitUntil(10_000) { WallpaperToneAnalyzer.peek(WallpaperToneAnalyzer.Key(id, WallpaperScreen.size.value, null)) != null }
            for (progress in listOf(0f, .5f, 1f, 0f)) {
                compose.runOnIdle { reveal.floatValue = progress }
                compose.runOnIdle { assertEquals(id, dark, darkGlyphs()) }
            }
        }
    }
}
