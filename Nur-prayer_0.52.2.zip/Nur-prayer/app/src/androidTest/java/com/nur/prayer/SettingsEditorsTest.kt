package com.nur.prayer

import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsSelected
import androidx.compose.ui.test.click
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTouchInput
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.icon.AppIcon
import com.nur.prayer.notify.AzanSound
import com.nur.prayer.ui.settings.AppIconPicker
import com.nur.prayer.ui.settings.SoundChoices
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import com.nur.prayer.ui.wallpaper.WallpaperCatalog
import com.nur.prayer.ui.wallpaper.WallpaperRow
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

class SettingsEditorsTest {
    @get:Rule val compose = createComposeRule()

    @Test fun pickingNeverAuditionsAndAuditioningNeverPicks() {
        val selection = mutableStateOf(AzanSound.SYSTEM)
        val previews = mutableListOf<AzanSound>()
        compose.setContent { NurTheme {
            SoundChoices(selection.value, null, onSelect = { selection.value = it }, onPreview = { previews.add(it) })
        } }
        // Real touch dispatch, not just invoking an accessibility callback.
        compose.onNodeWithTag("sound-choice-AZAN_SHORT").performTouchInput { click() }
        compose.onNodeWithTag("sound-choice-AZAN_SHORT").assertIsSelected()
        compose.runOnIdle { assertEquals(emptyList<AzanSound>(), previews) }
        compose.onNodeWithTag("sound-preview-SYSTEM").performTouchInput { click() }
        compose.onNodeWithTag("sound-preview-AZAN_FULL").performTouchInput { click() }
        compose.onNodeWithTag("sound-choice-AZAN_SHORT").assertIsSelected()
        compose.onNodeWithTag("sound-preview-SILENT").assertDoesNotExist()
        compose.runOnIdle { assertEquals(listOf(AzanSound.SYSTEM, AzanSound.AZAN_FULL), previews) }
    }

    @Test fun lastIconIsReachableWithinTheStrip() {
        val selection = mutableStateOf(AppIcon.NUR)
        compose.setContent { NurTheme { Column { AppIconPicker(selection.value) { selection.value = it } } } }
        compose.onNodeWithTag("icon-strip").performScrollToNode(hasTestTag("app-icon-pole"))
        compose.onNodeWithTag("app-icon-pole").performClick()
        compose.onNodeWithTag("app-icon-pole").assertIsSelected()
    }

    @Test fun artworkIsSquareAndDoesNotShrinkOrJumpOnSelection() {
        val selection = mutableStateOf(AppIcon.NUR)
        compose.setContent { NurTheme { Column { AppIconPicker(selection.value) { selection.value = it } } } }
        fun bounds() = compose.onNodeWithTag("icon-art-dunes", useUnmergedTree = true).fetchSemanticsNode().boundsInRoot
        compose.waitUntil(5_000L) {
            compose.onAllNodes(hasTestTag("icon-art-dunes"), useUnmergedTree = true).fetchSemanticsNodes().isNotEmpty()
        }
        val before = bounds()
        assertTrue(before.width > 0f)
        assertEquals(before.width, before.height, 1f)
        compose.onNodeWithTag("app-icon-dunes").performClick().assertIsSelected()
        assertEquals(before, bounds())
    }

    @Test fun selectingAWallpaperDoesNotResizeItsTile() {
        val selection = mutableStateOf(WallpaperCatalog.Sky)
        compose.setContent { NurTheme { Column {
            WallpaperRow(selection.value, emptyList(), paletteFor(Prayer.ISHA), onPick = { selection.value = it }, onOpenAll = {})
        } } }
        val first = compose.onNodeWithTag("wall-tile-sky").fetchSemanticsNode().size
        val photo = compose.onNodeWithTag("wall-tile-kaaba_day")
        photo.assertIsDisplayed()
        // Layout size in physical pixels, independent of the tile's position in the strip.
        assertEquals(first, photo.fetchSemanticsNode().size)
        photo.performClick()
        photo.assertIsSelected()
        assertEquals(first, photo.fetchSemanticsNode().size)
    }
}
