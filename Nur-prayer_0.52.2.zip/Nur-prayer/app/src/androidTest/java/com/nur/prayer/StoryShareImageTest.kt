package com.nur.prayer

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.nur.prayer.daily.StorySlide
import com.nur.prayer.daily.DailyStories
import com.nur.prayer.ui.daily.StoryArtwork
import com.nur.prayer.ui.daily.StoryShare
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import kotlin.math.ceil

@RunWith(AndroidJUnit4::class)
class StoryShareImageTest {
    @Test fun squareExportHasPhotoAtBothTopCornersAndViewerStillHasRoundCorners() {
        val photoColor = 0xff2355b0.toInt()
        val paperColor = 0xfff5ebdf.toInt()
        val model = StoryArtwork(DailyStories.HADITH.first(), "ХАДИС ДНЯ")
        val w = 333 // Deliberately not a multiple of 608; exercise the rounded-up last row.
        val h = ceil(model.height * w / StoryArtwork.WIDTH).toInt()
        val photo = Bitmap.createBitmap(64, 36, Bitmap.Config.ARGB_8888).apply { eraseColor(photoColor) }
        val viewer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val export = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        try {
            model.draw(Canvas(viewer), w.toFloat(), photo)
            model.draw(Canvas(export), w.toFloat(), photo, StoryArtwork.CardSurface.PNG)
            for (x in listOf(0, w - 1)) {
                assertEquals(photoColor, export.getPixel(x, 0))
                assertEquals(paperColor, export.getPixel(x, h - 1))
                assertEquals(0, viewer.getPixel(x, 0))
                assertEquals(0, viewer.getPixel(x, h - 1))
            }
            // Same layout, not a crop, stretch, or extra border: the entire centre is unchanged.
            for (y in 0 until h - 1) assertEquals(viewer.getPixel(w / 2, y), export.getPixel(w / 2, y))
        } finally { photo.recycle(); viewer.recycle(); export.recycle() }
    }

    @Test fun naturalHeightTracksOnlyActualLinesAndNotes() {
        val short = StorySlide("Хадис дня", null, null, "Чистота — половина веры.", "Муслим 223")
        val long = short.copy(ru = List(12) { short.ru }.joinToString(" "), note = "Примечание")
        val compact = StoryArtwork(short, short.kind)
        val full = StoryArtwork(long, long.kind)
        assertTrue(compact.height < 932f) // no fixed empty paper on the shortest story
        assertTrue(full.height > compact.height)
        assertTrue(StoryArtwork(long.copy(note = null), long.kind).height < full.height)
    }

    @Suppress("DEPRECATION")
    @Test fun receiverGetsTheSameCompleteCardAndAnIndependentReadGrant() = runBlocking {
        val ctx = InstrumentationRegistry.getInstrumentation().targetContext
        val slide = DailyStories.DUAS.maxBy { it.ru.length + it.arabic.orEmpty().length }
        val image = BitmapFactory.decodeResource(ctx.resources, R.drawable.story_clock_horizon)
        val title = "ДУА ДНЯ"
        val model = StoryArtwork(slide, title)
        val w = 1080
        val expected = Bitmap.createBitmap(w, ceil(model.height * w / StoryArtwork.WIDTH).toInt(), Bitmap.Config.ARGB_8888)
        try {
            model.draw(Canvas(expected), w.toFloat(), image, StoryArtwork.CardSurface.PNG)
            suspend fun uri(fontScale: Float): Uri {
                val config = android.content.res.Configuration(ctx.resources.configuration).apply { this.fontScale = fontScale }
                val configured = ctx.createConfigurationContext(config)
                val chooser = StoryShare.image(configured, slide, title, image)
                val send = requireNotNull(chooser.getParcelableExtra<Intent>(Intent.EXTRA_INTENT))
                assertEquals(Intent.ACTION_SEND, send.action)
                assertEquals("image/png", send.type)
                assertTrue(send.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION != 0)
                val stream = requireNotNull(send.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))
                assertEquals("content", stream.scheme)
                assertEquals(stream, send.clipData?.getItemAt(0)?.uri)
                return stream
            }
            val first = uri(1f); val second = uri(2f)
            assertTrue(first != second)
            val decoded = requireNotNull(ctx.contentResolver.openInputStream(first)?.use { BitmapFactory.decodeStream(it) })
            try {
                assertEquals(expected.width, decoded.width)
                assertEquals(expected.height, decoded.height)
                assertTrue(expected.sameAs(decoded))
                val enlarged = requireNotNull(ctx.contentResolver.openInputStream(second)?.use { BitmapFactory.decodeStream(it) })
                try { assertTrue("PNG changed with system font scale", decoded.sameAs(enlarged)) }
                finally { enlarged.recycle() }
                // Inspect the received file, including the two bottom corners on the ceil row.
                for (x in listOf(0, decoded.width - 1)) {
                    assertEquals(255, android.graphics.Color.alpha(decoded.getPixel(x, 0)))
                    assertEquals(0xfff5ebdf.toInt(), decoded.getPixel(x, decoded.height - 1))
                }
            } finally { decoded.recycle() }
        } finally { expected.recycle(); image.recycle() }
    }
}
