package com.nur.prayer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.ui.today.deedMatte
import kotlin.math.abs
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AzkarSkyTest {
    @get:Rule val compose = createComposeRule()

    @Test fun bothSkiesKeepTheApprovedHorizonAfterResize() {
        val dusk = mutableStateOf(false)
        val wide = mutableStateOf(false)
        compose.setContent {
            Box(Modifier.size(if (wide.value) 225.dp else 164.dp, if (wide.value) 100.dp else 141.dp)
                .testTag("active-sky").deedMatte(RoundedCornerShape(16.dp), skyRes =
                    if (dusk.value) R.drawable.deed_sky_dusk else R.drawable.deed_sky_dawn))
        }
        val probes = listOf(.25f to .34f, .62f to .59f, .94f to .78f)
        for (night in listOf(false, true)) for (stretched in listOf(false, true)) {
            compose.runOnIdle { dusk.value = night; wide.value = stretched }
            val pixels = compose.onNodeWithTag("active-sky").captureToImage().toPixelMap()
            val targets = if (night) listOf(0x725D72, 0x875D68, 0x94605C) else listOf(0xDEE5DF, 0xEDE5D3, 0xF4E0C0)
            for ((index, point) in probes.withIndex()) {
                val rgb = pixels[(pixels.width * point.first).toInt(), (pixels.height * point.second).toInt()].toArgb()
                for (shift in listOf(16, 8, 0)) {
                    val actual = (rgb ushr shift) and 255
                    val target = (targets[index] ushr shift) and 255
                    assertTrue("sky=$night wide=$stretched point=$point channel=$shift: $actual vs $target", abs(actual - target) <= 3)
                }
            }
        }
    }
}
