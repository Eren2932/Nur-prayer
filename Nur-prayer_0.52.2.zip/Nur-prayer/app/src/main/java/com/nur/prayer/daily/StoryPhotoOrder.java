package com.nur.prayer.daily;

import java.util.Random;

/** A date-addressable shuffle bag; neither reopening a story nor skipping dates changes the deal. */
public final class StoryPhotoOrder {
    private StoryPhotoOrder() { }

    public static int index(long day, int slide, int count) {
        if (count < 9 || slide < 0 || slide >= 4) throw new IllegalArgumentException();
        long slot = day * 4 + slide;
        long deck = Math.floorDiv(slot, (long) count);
        // Morph one independent Fisher-Yates permutation into the next. Odd-even sorting takes
        // at most count parallel passes. Each item moves <=1 per pass, hence repeat gap >=8
        // slots (two whole days), including the final step onto the next anchor permutation.
        int passes = count - 8;
        int decksPerAnchor = (count + passes - 1) / passes;
        long anchor = Math.floorDiv(deck, (long) decksPerAnchor);
        int[] order = shuffled(anchor, count);
        int steps = (int) Math.floorMod(deck, (long) decksPerAnchor) * passes;
        if (steps != 0) {
            int[] target = shuffled(anchor + 1, count), rank = new int[count];
            for (int i = 0; i < count; i++) rank[target[i]] = i;
            for (int p = 0; p < steps; p++) {
                for (int i = p % 2; i + 1 < count; i += 2) {
                    if (rank[order[i]] > rank[order[i + 1]]) swap(order, i, i + 1);
                }
            }
        }
        return order[(int) Math.floorMod(slot, (long) count)];
    }

    private static int[] shuffled(long seed, int n) {
        Random random = new Random(0x4e55525abL ^ (seed * 0x9e3779b97f4a7c15L));
        int[] items = new int[n];
        for (int i = 0; i < n; i++) items[i] = i;
        for (int i = n - 1; i > 0; i--) swap(items, i, random.nextInt(i + 1));
        return items;
    }
    private static void swap(int[] a, int i, int j) { int v = a[i]; a[i] = a[j]; a[j] = v; }
}
