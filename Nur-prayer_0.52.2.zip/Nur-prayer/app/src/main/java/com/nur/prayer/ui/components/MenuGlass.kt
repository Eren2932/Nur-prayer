package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.uiScale

/** Opaque controls for city search. The settings index uses transparent rows instead. */
object MenuGlass {
    val Fill = Color(0xFF272728)
    val Subtitle = Color(0xFFB1B4BA)
    val Title = Color.White
    val TextShadow = Shadow(Color.Transparent, Offset.Zero, 0f)
    val MaxWidth: Dp = 560.dp
}

/** A menu card: clip and the flat grey fill. */
fun Modifier.menuGlass(corner: Dp): Modifier {
    val shape = RoundedCornerShape(corner)
    return this.clip(shape).background(MenuGlass.Fill)
}

/** The thin white `›` at the end of a row; it mirrors in right-to-left layouts. */
@Composable
fun MenuChevron(modifier: Modifier = Modifier, color: Color = Color.White) {
    val ui = uiScale()
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Canvas(modifier.size(width = ui.s(7f), height = ui.s(11f))) {
        val w = size.width
        val h = size.height
        val stroke = 1.6.dp.toPx()
        val pad = stroke / 2f + 0.4.dp.toPx()
        fun x(v: Float): Float = if (rtl) w - v else v
        val path = Path().apply {
            moveTo(x(pad), pad)
            lineTo(x(w - pad), h / 2f)
            lineTo(x(pad), h - pad)
        }
        drawPath(path, color, style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
