package com.nur.prayer.ui.daily

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsIgnoringVisibility
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.daily.StorySlide
import com.nur.prayer.daily.StoryViewport
import com.nur.prayer.daily.StoryTouch
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.ExitButtonSpec
import com.nur.prayer.ui.components.ExitDock
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.learn.SpeakButton
import com.nur.prayer.ui.learn.rememberVoiceStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StoryScreen(slides: List<StorySlide>, start: Int, opening: Int, day: Long, onSeen: (Int) -> Unit, onClose: () -> Unit) {
    if (slides.isEmpty()) { LaunchedEffect(Unit) { onClose() }; return }
    var index by rememberSaveable(opening) { mutableIntStateOf(start.coerceIn(slides.indices)) }
    var restart by remember(opening) { mutableIntStateOf(0) }
    var held by remember { mutableStateOf(false) }
    var longHold by remember { mutableStateOf(false) }
    var sharing by remember { mutableStateOf(false) }
    var closed by remember(opening) { mutableStateOf(false) }
    val safeIndex = index.coerceIn(slides.indices)
    val slide = slides[safeIndex]
    val context = LocalContext.current
    val density = LocalDensity.current
    val frame by rememberStoryFrame(slides, safeIndex, day)
    val ready = frame?.let { it.index == safeIndex && it.slide == slide } == true
    val progress = remember(opening, safeIndex, restart) { mutableFloatStateOf(0f) }
    var pull by remember { mutableFloatStateOf(0f) }
    var rebound by remember { mutableStateOf<Job?>(null) }
    val scope = rememberCoroutineScope()
    val latestClose by rememberUpdatedState(onClose)
    fun closeOnce() { if (!closed) { closed = true; latestClose() } }
    fun go(delta: Int) {
        if (closed || sharing) return
        val next = index + delta
        when { next < 0 -> restart++; next > slides.lastIndex -> closeOnce(); else -> index = next }
    }
    BackHandler { closeOnce() }
    val life by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    val focused = LocalWindowInfo.current.isWindowFocused
    val hidden = held && longHold
    StoryBars(hidden && !closed)
    LaunchedEffect(ready, safeIndex, opening) { if (ready) onSeen(safeIndex) }
    val paused = held || sharing || closed || !ready || !focused || life != Lifecycle.State.RESUMED
    LaunchedEffect(progress, paused) {
        if (paused) return@LaunchedEffect
        // Reading time is real elapsed foreground time, not Android's animator duration scale.
        val from = progress.floatValue
        val durationNs = StoryMath.durationMillis(slide) * 1_000_000L
        val started = withFrameNanos { it }
        while (progress.floatValue < 1f) withFrameNanos { now ->
            progress.floatValue = (from + (now - started).toFloat() / durationNs).coerceAtMost(1f)
        }
        if (!held && !sharing && !closed) go(1)
    }
    // The OS bars still disappear during a hold, but neither the header nor the card is
    // measured against their transient size. This also covers a side nav bar in landscape.
    val safe = WindowInsets.systemBarsIgnoringVisibility.union(WindowInsets.displayCutout)
    val stable = safe.asPaddingValues()
    val bottom = stable.calculateBottomPadding()
    val top = stable.calculateTopPadding()
    val voice = rememberVoiceStatus()
    val previous = tr("Предыдущее")
    val next = tr("Следующее")
    val action = tr("Поделиться").uppercase(L10n.language.locale)
    val failed = tr("Не удалось подготовить картинку")
    val shown = frame?.index ?: safeIndex
    val shownSlide = frame?.slide ?: slide
    val pullLayer = Modifier.graphicsLayer {
        val d = pull.coerceAtLeast(0f)
        val k = if (size.height > 0f) (d / size.height).coerceIn(0f, 1f) else 0f
        translationY = d; scaleX = 1f - .08f * k; scaleY = scaleX; alpha = 1f - .4f * k
    }
    // NurRoot already owns the selected, frosted wallpaper. Add neutral black, never a
    // replacement image or a second full-screen live blur. Card and photo move as one.
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .46f))
        .windowInsetsPadding(safe.only(WindowInsetsSides.Horizontal))) {
        Box(Modifier.fillMaxSize().testTag("story-input")
            .pointerInput(opening, slides.size, focused, life, sharing, closed) {
                if (!focused || life != Lifecycle.State.RESUMED || sharing || closed) return@pointerInput
                var startPull = 0f
                storyGestures(onContact = { down ->
                    held = down
                    if (down) { rebound?.cancel(); startPull = pull }
                }, onHidden = { longHold = it }, onPull = { pull = startPull + it }, settle = {
                    if (pull > 0f) rebound = scope.launch {
                        animate(pull, 0f, animationSpec = NurMotion.gentle()) { y, _ -> pull = y }
                    }
                }, onAction = { when (it) {
                    StoryTouch.Action.CLOSE -> closeOnce()
                    StoryTouch.Action.PREV -> go(-1)
                    StoryTouch.Action.NEXT -> go(1)
                    StoryTouch.Action.NONE -> Unit
                } })
            }) {
            // Keep touch coordinates outside this layer. Buttons consume their own down in the
            // Main pass before the parent's recognizer; they never navigate as well as activate.
            Box(Modifier.fillMaxSize().then(pullLayer)) {
                BoxWithConstraints(Modifier.fillMaxSize()
                    .padding(top = top + 76.dp, bottom = ExitButtonSpec.contentFloor(bottom)), contentAlignment = Alignment.Center) {
                    val room = maxHeight
                    val roomWidth = maxWidth
                    val active = frame
                    if (active != null) AnimatedContent(targetState = active,
                        modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center,
                        transitionSpec = {
                            val dir = if (targetState.index >= initialState.index) 1 else -1
                            ((slideInHorizontally(NurMotion.gentle()) { dir * it / 5 } + fadeIn(tween(220)) +
                                scaleIn(NurMotion.gentle(), initialScale = .96f)) togetherWith
                                (slideOutHorizontally(NurMotion.gentle()) { -dir * it / 5 } + fadeOut(tween(160)))).using(null)
                        }, label = "storySlide") { f ->
                        val ratio = f.art.height / StoryArtwork.WIDTH
                        // Uniform contain, never crop. The design has no dependency on Android sp.
                        val width = StoryViewport.width(roomWidth.value, room.value, ratio).dp
                        val height = minOf(room, width * ratio)
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Canvas(Modifier.width(width).height(height).testTag("story-art").semantics {
                                contentDescription = f.art.description
                                onClick(label = next) { go(1); true }
                                customActions = listOf(CustomAccessibilityAction(previous) { go(-1); true },
                                    CustomAccessibilityAction(next) { go(1); true })
                            }) {
                                // Both bounds round to physical pixels independently.
                                f.art.draw(drawContext.canvas.nativeCanvas, minOf(size.width, size.height / ratio), f.photo)
                            }
                        }
                    }
                }
                AnimatedVisibility(visible = !hidden, enter = fadeIn(tween(100)), exit = fadeOut(tween(80)),
                    modifier = Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxSize()) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = top + 10.dp)) {
                            Canvas(Modifier.fillMaxWidth().height(3.dp)) {
                                val gap = 4.dp.toPx(); val w = (size.width - gap * slides.lastIndex) / slides.size
                                val r = CornerRadius(size.height / 2f)
                                for (s in slides.indices) {
                                    val at = Offset(s * (w + gap), 0f)
                                    drawRoundRect(Color(0xff595959), at, Size(w, size.height), r)
                                    val fill = when { s < shown -> 1f; s == shown -> progress.floatValue; else -> 0f }
                                    if (fill > 0f) drawRoundRect(Color.White, at, Size(w * fill, size.height), r)
                                }
                            }
                            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(tr("На сегодня"), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.alignByBaseline())
                                Text("${shown + 1} / ${slides.size}", modifier = Modifier.testTag("story-count").padding(start = 8.dp).alignByBaseline(),
                                    color = Color(0xffcecbc8), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.weight(1f))
                                val word = shownSlide.arabic
                                if (shownSlide.kind == WORD_KIND && shownSlide.voiced && word != null) SpeakButton(word, voice)
                            }
                        }
                        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
                            ExitDock(onClose = { closeOnce() }, bottom = bottom, description = tr("Закрыть"))
                            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = ExitButtonSpec.bottomGap(bottom))
                                .height(ExitButtonSpec.Hit).width(144.dp).clickable(enabled = ready && !sharing, role = Role.Button) {
                                    val selected = frame
                                    if (selected != null && !sharing) {
                                        sharing = true
                                        scope.launch {
                                            try { val intent = StoryShare.image(context, selected.slide, selected.title, selected.photo)
                                                if (!closed) context.startActivity(intent)
                                            } catch (e: CancellationException) { throw e }
                                            catch (_: Exception) { Toast.makeText(context, failed, Toast.LENGTH_SHORT).show() }
                                            finally { sharing = false }
                                        }
                                    }
                                }, contentAlignment = Alignment.Center) {
                                Box(Modifier.fillMaxWidth().height(ExitButtonSpec.Diameter).background(Color.Black.copy(alpha = .12f), CircleShape)
                                    .border(1.dp, Color.White.copy(alpha = .5f), CircleShape), contentAlignment = Alignment.Center) {
                                    Text(action, fontSize = minOf(13f, with(density) { 16.dp.toSp().value }).sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
