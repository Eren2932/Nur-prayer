package com.nur.prayer.ui.shell

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.isSpecified
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.wallpaper.PAGE_DIM
import com.nur.prayer.ui.wallpaper.Wallpaper
import com.nur.prayer.ui.wallpaper.WallpaperImages
import com.nur.prayer.ui.wallpaper.WallpaperScreen
import com.nur.prayer.ui.wallpaper.drawWallpaperIn

/** The island is opaque paper; the sheets have dark glass; story and section cards share one matte. */
enum class GlassStyle { LIGHT, DARK, DEED, SECTION }

/** What the glass shows through: the wallpaper on screen and how much the current page darkens it. */
@Stable
class FrostSource(val wallpaper: () -> Wallpaper, val dim: () -> Float)

val LocalFrost = staticCompositionLocalOf<FrostSource?> { null }

/**
 * The colours of the bar, the panel, the island and the compass button, measured from the owner's mocks (576 px =
 * 393 dp): the paper, the veils of the round buttons, the pill, the greys and the navy of the ink. (The cards of the
 * 0.36.0 panel, the lavender «now» and the speakers went with the times in 0.39.0.) The colours of the section discs
 * live in [ShellTones].
 */
object ShellColors {
    /** The paper of the island (0.36.0) and of the open panel over the Quran's white page (0.39.0): #FAFAFA, flat. */
    val Glass = Color(0xFFFAFAFA)
    /**
     * 0.38.0: the round buttons of the bar on home are really transparent: only a faint shade lies inside the ring
     * (black at 8 %), the picture shows through. Home sits on the wallpaper under the page scrim (62 % black), where
     * the white ring and glyph keep their contrast without any help from the veil. The central ring retains this veil while the menu is open.
     */
    val BarGlass = Color(0x14000000)
    /**
     * 0.37.0's firmer veil (black at 45 %, white ink keeps 3:1 even over a white page: #8C8C8C). Inside a section the
     * page under the bar is not the scrimmed wallpaper (the Quran's paper is white), so the buttons wear this one.
     */
    val BarGlassPage = Color(0x73000000)
    /** The ring of a veil button and its ink (0.37.0). */
    val BarRing = Color(0xE6FFFFFF)
    val BarInk = Color(0xFFFFFFFF)
    /** 0.38.0: «Учёба», the pill on the right of the bar: light grey of the mock (#DDDEDC) and near-black ink on it. */
    val PillFill = Color(0xFFDDDEDC)
    val PillInk = Color(0xFF141514)
    /** The light that runs over the pill now and then; its peak alpha is [PillShimmer.PEAK_ALPHA]. */
    val PillGlint = Color(0xFFFFFFFF)
    /** Text and icons: black for what is read, greys for what is around it. */
    val Ink = Color(0xFF0A0A0C)
    val Secondary = Color(0xFF5E5E62)
    val Icon = Color(0xFF3F3F44)
    /**
     * 0.39.0: the labels under the discs of the panel and the settings icon: a deep navy-black, as the mock's, on the
     * matte white (the lightest it gets is about #DCDCDD over a white wallpaper, 13:1).
     */
    val PanelInk = Color(0xFF0B1328)
    val GearInk = Color(0xFF1B2233)
    /** The small accent dot of the island: the gold of the timeline, which reads on white as well. */
    val Accent = Color(0xFFE0993F)
}

/** The dark glass of the sheets, unchanged since 0.27.1. */
internal object SheetGlass {
    val TintTop = Color(0xFF12141F)
    val TintBottom = Color(0xFF0F111B)
    const val TINT_ALPHA = 0.90f
    const val TINT_PLAIN_ALPHA = 0.96f
    /** Black over the blurred picture before the tint: a light wallpaper must not lift the glass. */
    const val PICTURE_DIM = ShellMath.PICTURE_DIM
    val Edge = Color(0x24FFFFFF)
}

/** Same cached wallpaper and opacity in both materials. Lift only the neutral pigment, not the blur. */
internal object CardPigment {
    val DeedPhoto = Color(0xFFF2ECED)
    val DeedPlain = Color(0xFFDFDADB)
    val SectionPhoto = Color(0xFFFBF6F6)
    val SectionPlain = Color(0xFFE7E3E3)
}

/** All five menu tiles sample one image; only their screen origins differ. */
@Stable
internal class FrostImage(val wallpaper: Wallpaper?, initial: ImageBitmap?) {
    var bitmap by mutableStateOf(initial)
}

@Stable
internal class FrostHandle constructor(internal val source: FrostSource?, private val image: FrostImage) {
    internal val bitmap get() = image.bitmap
    internal val wallpaper get() = image.wallpaper
    internal var originInRoot by mutableStateOf(Offset.Zero)
    internal fun atAnotherOrigin() = FrostHandle(source, image)
}

@Composable
internal fun rememberFrost(): FrostHandle {
    val source = LocalFrost.current
    val context = LocalContext.current
    val wallpaper = source?.wallpaper?.invoke()
    val screen by WallpaperScreen.size
    val image = remember(wallpaper, screen) {
        FrostImage(wallpaper, if (wallpaper?.isImage == true && screen.width > 0 && screen.height > 0)
            WallpaperImages.peekFrost(wallpaper, screen.width, screen.height) else null)
    }
    LaunchedEffect(image) {
        if (image.bitmap == null && wallpaper?.isImage == true && screen.width > 0 && screen.height > 0) {
            image.bitmap = WallpaperImages.frost(context, wallpaper, screen.width, screen.height)
        }
    }
    return remember(source, image) { FrostHandle(source, image) }
}

/**
 * Paints the glass of [shape] behind the content of this element and clips the content to it. Read
 * only while drawing: a panel that changes size every frame redraws, it does not recompose.
 *
 *  - [halo]: the faint plates outside the shape. Off for a sheet that touches the screen edges.
 *  - [track]: the glass follows where it is on screen by itself (onGloballyPositioned). A surface that
 *    is moved by a layer transform (a sheet sliding up) sets it off and sets [FrostHandle.originInRoot] itself.
 *  - [wash]: a colour laid very lightly over the tint (the prayer sheet carries the colour of its sky).
 */
internal fun Modifier.frostGlass(
    frost: FrostHandle,
    shape: Shape,
    halo: Boolean = true,
    track: Boolean = true,
    edge: Boolean = true,
    wash: Color = Color.Unspecified,
    style: GlassStyle = GlassStyle.LIGHT
): Modifier = this
    .then(
        if (halo) Modifier.glassHalo(shape) { if (style == GlassStyle.DARK) 1f else LIGHT_HALO }
        else Modifier
    )
    .then(if (track && style != GlassStyle.LIGHT) Modifier.onGloballyPositioned { frost.originInRoot = it.positionInRoot() } else Modifier)
    .clip(shape)
    .drawBehind {
        if (style == GlassStyle.LIGHT) {
            // Opaque paper: no picture, no dim, no rim; the colour is read here, in the draw phase, so a morph
            // that changes it every frame redraws and never recomposes.
            drawRect(ShellColors.Glass)
        } else if (style == GlassStyle.DEED || style == GlassStyle.SECTION) {
            // One cached blur, sampled at each component's screen origin. No blur on text or icons.
            val bitmap = frost.bitmap
            val wall = frost.wallpaper
            val screen = WallpaperScreen.size.value
            if (bitmap != null && wall != null && wall == frost.source?.wallpaper?.invoke() && screen.width > 0 && screen.height > 0) {
                val origin = frost.originInRoot
                translate(-origin.x, -origin.y) {
                    drawWallpaperIn(bitmap, wall, screen.width.toFloat(), screen.height.toFloat(), FilterQuality.Low)
                }
                // Same blur contribution as before: (1 - .77) * (1 - .18) = .1886.
                // Raise only the neutral pigment; the photo, its crop and the page scrim stay untouched.
                drawRect(if (style == GlassStyle.SECTION) CardPigment.SectionPhoto else CardPigment.DeedPhoto, alpha = .8114f)
            } else {
                // Keep 12% of the live backdrop. Match the photo material’s floor on pure black.
                drawRect(if (style == GlassStyle.SECTION) CardPigment.SectionPlain else CardPigment.DeedPlain, alpha = .88f)
            }
        } else {
            val bitmap = frost.bitmap
            val wallpaper = frost.wallpaper
            val screen = WallpaperScreen.size.value
            val picture = bitmap != null && wallpaper != null && screen.width > 0 && screen.height > 0
            if (picture) {
                val o = frost.originInRoot
                translate(-o.x, -o.y) {
                    drawWallpaperIn(bitmap!!, wallpaper!!, screen.width.toFloat(), screen.height.toFloat(), FilterQuality.Low)
                }
                drawRect(Color.Black.copy(alpha = ShellMath.pictureDim(frost.source?.dim?.invoke() ?: 0f, PAGE_DIM)))
            }
            val a = if (picture) SheetGlass.TINT_ALPHA else SheetGlass.TINT_PLAIN_ALPHA
            drawRect(Brush.verticalGradient(listOf(SheetGlass.TintTop.copy(alpha = a), SheetGlass.TintBottom.copy(alpha = a))))
            if (wash.isSpecified) drawRect(wash.copy(alpha = WASH_ALPHA))
            if (edge) {
                // Twice the hairline, centred on the outline: the half outside the clip is cut, 1 dp stays.
                drawOutline(
                    shape.createOutline(size, layoutDirection, this),
                    SheetGlass.Edge,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }

private const val WASH_ALPHA = 0.20f

/** The light glass needs less of a halo than the dark one: a white body already reads on any picture. */
private const val LIGHT_HALO = 0.55f

/** Three flat, very faint plates around a rounded shape: enough to lift it off the picture, nothing more. */
private fun Modifier.glassHalo(shape: Shape, strength: () -> Float): Modifier = drawBehind {
    val outline = shape.createOutline(size, layoutDirection, this)
    if (outline !is Outline.Rounded) return@drawBehind
    val k = strength()
    if (k <= 0.001f) return@drawBehind
    val box = outline.roundRect
    val r = box.topLeftCornerRadius.x
    HALO.forEach { plate ->
        val grow = plate.grow.dp.toPx()
        drawRoundRect(
            Color.Black.copy(alpha = plate.alpha * k),
            topLeft = Offset(box.left - grow, box.top - grow + plate.drop.dp.toPx()),
            size = Size(box.width + 2f * grow, box.height + 2f * grow),
            cornerRadius = CornerRadius(r + grow)
        )
    }
}

private class Plate(val grow: Float, val drop: Float, val alpha: Float)

private val HALO = listOf(Plate(2f, 3f, 0.10f), Plate(6f, 6f, 0.06f), Plate(11f, 9f, 0.035f))
