package com.nur.prayer.ui.components

import android.animation.ValueAnimator
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.nur.prayer.R
import com.nur.prayer.ui.theme.SystemBarsTone
import com.nur.prayer.ui.theme.findActivity
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** «Сверка». Native splash and first Compose frame share paper, canvas, mark and placement. */
object LaunchScreenSpec {
    val Background = Color(0xFFFAFAFA)
    val Spinner = Color(0xFF748593)
    // Fallback for a launch for which Android creates no splash view / sends no exit callback.
    const val CALLBACK_GRACE_MILLIS = 160L
    const val HANDOFF_CAP_MILLIS = 1000L
    const val GLINT_MILLIS = 240
    const val SKY_OPACITY = 0.38f
    const val MARK_DP = 88
    const val ART_DP = 288
    const val MIN_MILLIS = 300L
    /** Never trap the user: if the data has not come by now, the app opens anyway. */
    const val MAX_MILLIS = 5000L
    const val EXIT_MILLIS = 260
    /** The spinner shows up only when the wait is longer than this. */
    const val SPINNER_AFTER_MILLIS = 600L
}

@Composable
fun LaunchScreen(ready: Boolean, systemGone: Boolean, onShown: () -> Unit, onFinished: () -> Unit) {
    val readyNow by rememberUpdatedState(ready)
    val exit = remember { Animatable(0f) }
    val spinner = remember { Animatable(0f) }
    var late by remember { mutableStateOf(false) }

    val sweep = remember { Animatable(0f) }
    val motion = remember { ValueAnimator.areAnimatorsEnabled() }
    val nativeReleased by rememberUpdatedState(systemGone)
    val firstPaint = remember { CompletableDeferred<Unit>() }
    var sweepVisible by remember { mutableStateOf(false) }

    // Dark system-bar icons on the white screen; the app's own tone comes back when it is gone.
    val window = LocalContext.current.findActivity()?.window
    val view = LocalView.current
    DisposableEffect(window) {
        window?.let {
            WindowCompat.getInsetsController(it, view).apply {
                isAppearanceLightStatusBars = true
                isAppearanceLightNavigationBars = true
            }
        }
        onDispose { SystemBarsTone.apply(window) }
    }
    // The system splash is held until this first frame exists, so it hands over to white, not black.
    SideEffect { onShown() }

    LaunchedEffect(Unit) {
        // Start the data deadline immediately. Loading the home screen does not depend on the light.
        val destination = async {
            withTimeoutOrNull(LaunchScreenSpec.MAX_MILLIS) { snapshotFlow { readyNow }.first { it } }
        }
        if (motion) {
            withTimeoutOrNull(LaunchScreenSpec.HANDOFF_CAP_MILLIS) {
                firstPaint.await()
                withTimeoutOrNull(LaunchScreenSpec.CALLBACK_GRACE_MILLIS) {
                    snapshotFlow { nativeReleased }.first { it }
                }
            }
            withFrameNanos { } // next app frame, not the time setContent was called
        }
        val hint = launch {
            delay(LaunchScreenSpec.SPINNER_AFTER_MILLIS)
            late = true
            if (motion) spinner.animateTo(1f, tween(220)) else spinner.snapTo(1f)
        }
        if (motion) {
            sweepVisible = true
            launch {
                sweep.animateTo(1f, tween(LaunchScreenSpec.GLINT_MILLIS, easing = LinearEasing))
                sweepVisible = false
            }
            // The existing minimum and the light run in parallel, from the same visible handoff.
            delay(LaunchScreenSpec.MIN_MILLIS)
        }
        destination.await()
        hint.cancel()
        if (motion) exit.animateTo(1f, tween(LaunchScreenSpec.EXIT_MILLIS, easing = FastOutSlowInEasing))
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = 1f - exit.value }
            .background(LaunchScreenSpec.Background)
            .drawBehind { if (!firstPaint.isCompleted) firstPaint.complete(Unit) }
            .testTag("nur-launch")
            // Nothing underneath may be tapped while the screen is up.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        Image(
            painter = painterResource(R.drawable.deed_sky_dawn), contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                compositingStrategy = CompositingStrategy.ModulateAlpha
                alpha = LaunchScreenSpec.SKY_OPACITY * (if (motion) sweep.value else if (systemGone) 1f else 0f)
            }
        )
        // Keep the native 288dp coordinate system even in a narrow multi-window / landscape height.
        Box(Modifier.align(Alignment.Center).requiredSize(LaunchScreenSpec.ART_DP.dp), contentAlignment = Alignment.Center) {
            Image(
                painter = painterResource(R.drawable.ic_splash_art), contentDescription = null,
                contentScale = ContentScale.Fit, modifier = Modifier.size(LaunchScreenSpec.ART_DP.dp)
            )
            // Resolve the tiny light bitmap during initial composition, not on its first moving frame.
            val glint = painterResource(R.drawable.ic_splash_glint)
            if (sweepVisible) LaunchGlint(glint) { sweep.value }
        }
        if (late) {
            CircularProgressIndicator(
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = 108.dp)
                    .size(22.dp)
                    .graphicsLayer { alpha = spinner.value * (1f - exit.value) },
                color = LaunchScreenSpec.Spinner,
                strokeWidth = 2.dp
            )
        }
    }
}

/** A full-bounds alpha operation: transparent ends clear the rest of the mask on every frame.
 * Only this mark-sized layer is composited offscreen. No blur, moving fullscreen layer or repeated pass. */
@Composable
internal fun LaunchGlint(mask: Painter, progress: () -> Float) {
    Image(painter = mask, contentDescription = null, contentScale = ContentScale.FillBounds,
        modifier = Modifier.size(LaunchScreenSpec.MARK_DP.dp, (LaunchScreenSpec.MARK_DP * 688f / 654f).dp)
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithCache {
                val w = size.width
                val y = size.height * 0.5f
                val half = w * 0.18f
                val tilt = half * 0.30f
                val stops = arrayOf(0f to Color.Transparent, 0.30f to Color.White.copy(alpha = 0.37f),
                    0.5f to Color.White, 0.70f to Color.White.copy(alpha = 0.37f), 1f to Color.Transparent)
                onDrawWithContent {
                    drawContent()
                    val x = w * (-0.37f + 1.74f * progress())
                    val band = Brush.linearGradient(*stops, start = Offset(x - half, y + tilt),
                        end = Offset(x + half, y - tilt))
                    drawRect(brush = band, blendMode = BlendMode.DstIn)
                }
            })
}
