package com.nur.prayer.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.nur.prayer.i18n.tr
import com.nur.prayer.i18n.trDynamic
import com.nur.prayer.notify.AzanSound
import com.nur.prayer.ui.components.AudioPreviewButton

@Composable
internal fun AzanEditor(selected: AzanSound, onSelect: (AzanSound) -> Unit) {
    val context = LocalContext.current.applicationContext
    val owner = LocalLifecycleOwner.current
    val audition = remember(context) { SoundAudition(context) }
    DisposableEffect(audition, owner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_STOP) audition.stop() }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); audition.stop() }
    }
    SoundChoices(selected, audition.current, onSelect = { audition.stop(); onSelect(it) }, onPreview = audition::toggle)
}

@Composable
internal fun SoundChoices(selected: AzanSound, playing: AzanSound?, onSelect: (AzanSound) -> Unit, onPreview: (AzanSound) -> Unit) {
    Column(Modifier.fillMaxWidth().selectableGroup()) {
        AzanSound.entries.forEach { sound ->
            val title = trDynamic(sound.title)
            val detail = when (sound) {
                AzanSound.AZAN_FULL -> tr("Полная запись · 3:35")
                AzanSound.AZAN_SHORT -> tr("25 сек · затухание")
                AzanSound.SYSTEM -> tr("Звук телефона")
                AzanSound.SILENT -> tr("Только вибрация")
            }
            EditorRule()
            EditorChoice(title, detail, selected == sound, { onSelect(sound) }, Modifier.testTag("sound-choice-${sound.name}")) {
                if (sound != AzanSound.SILENT) {
                    val active = selected == sound
                    val stop = playing == sound
                    val label = (if (stop) tr("Остановить") else tr("Прослушать")) + ": " + title
                    AudioPreviewButton(playing = stop, filled = active, label = label,
                        modifier = Modifier.testTag("sound-preview-${sound.name}"), alignment = Alignment.CenterEnd,
                        onClick = { onPreview(sound) })
                }
            }
        }
    }
}
