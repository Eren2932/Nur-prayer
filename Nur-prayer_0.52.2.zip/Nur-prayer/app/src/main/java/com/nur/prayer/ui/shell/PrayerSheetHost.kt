package com.nur.prayer.ui.shell

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.home.PrayerSheet
import com.nur.prayer.ui.home.PrayerSheetMotion

@Composable
fun PrayerSheetHost(
    prayer: Prayer?, data: PrayerData, actions: AppActions,
    notificationsAllowed: Boolean, exactAlarmsAllowed: Boolean, onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val motion = remember { PrayerSheetMotion(scope, restored = prayer != null) }
    val open = prayer != null
    LaunchedEffect(open) { motion.settle(open) }
    val travelling by remember { derivedStateOf { motion.progress > 0f } }
    if (!open && !travelling) return
    // Stay modal during the exit, too. Back must not change the page underneath the finger.
    BackHandler { }
    val last = remember { arrayOfNulls<Prayer>(1) }
    if (prayer != null) last[0] = prayer
    PrayerSheet(data, last[0] ?: Prayer.FAJR, actions, notificationsAllowed, exactAlarmsAllowed,
        motion = motion, active = open, onDismiss = onDismiss)
}
