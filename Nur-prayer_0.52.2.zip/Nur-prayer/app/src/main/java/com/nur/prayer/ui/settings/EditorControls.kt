package com.nur.prayer.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.components.AudioPreviewInk
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.NurSwitch
import com.nur.prayer.ui.theme.uiScale

internal object EditorStyle {
    const val SIDE = 22f
    val Paper = AudioPreviewInk.Paper
    val Track = AudioPreviewInk.Track
    val Muted = Color(0xFFBBBABD)
    val Selected = Color(0xFF56DB94)
}

@Composable
internal fun EditorRule() {
    Spacer(Modifier.fillMaxWidth().height(0.75.dp).background(Color.White.copy(alpha = 0.19f)))
}

@Composable
internal fun EditorLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier.semantics { heading() }, color = Color.White, fontSize = uiScale().t(15f), lineHeight = uiScale().t(19f), fontWeight = FontWeight.Bold)
}

@Composable
internal fun EditorNote(text: String) {
    val ui = uiScale()
    Text(text, color = EditorStyle.Muted, fontSize = ui.t(13f), lineHeight = ui.t(17f))
}

@Composable
internal fun EditorMark() {
    Box(Modifier.size(uiScale().s(11f)).clip(CircleShape).background(EditorStyle.Selected))
}

/** The audition button is a sibling, never nested inside the radio target. */
@Composable
internal fun EditorChoice(title: String, subtitle: String?, selected: Boolean, onClick: () -> Unit,
    modifier: Modifier = Modifier, trailing: (@Composable () -> Unit)? = null) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Row(modifier.weight(1f).selectable(selected, role = Role.RadioButton, onClick = onClick)
            .heightIn(min = if (subtitle == null) 52.dp else ui.s(70f)).padding(vertical = ui.s(9f)),
            verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.Top) {
                if (selected) {
                    Box(Modifier.height(ui.s(20f)), contentAlignment = Alignment.Center) { EditorMark() }
                    Spacer(Modifier.width(ui.s(12f)))
                }
                Column(verticalArrangement = Arrangement.spacedBy(ui.s(2f))) {
                    Text(title, color = Color.White, fontSize = ui.t(16f), lineHeight = ui.t(20f), fontWeight = FontWeight.Bold)
                    if (subtitle != null) EditorNote(subtitle)
                }
            }
        }
        if (trailing != null) trailing()
    }
}

@Composable
internal fun EditorSegments(options: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit) {
    val ui = uiScale()
    // 37 dp visible track, with a distinct 48 dp minimum input area per option.
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(Modifier.matchParentSize().padding(vertical = 5.dp).clip(CircleShape).background(EditorStyle.Track))
        Row(Modifier.fillMaxWidth().selectableGroup()) {
            options.forEachIndexed { i, label ->
                val active = selectedIndex == i
                Box(Modifier.weight(1f).selectable(active, role = Role.RadioButton) { if (!active) onSelect(i) }
                    .heightIn(min = 48.dp).padding(vertical = 5.dp), contentAlignment = Alignment.Center) {
                    if (active) Box(Modifier.matchParentSize().clip(CircleShape).background(EditorStyle.Paper))
                    Text(label, Modifier.padding(horizontal = ui.s(5f), vertical = ui.s(8f)), textAlign = TextAlign.Center,
                        color = if (active) EditorStyle.Track else Color.White, fontSize = ui.t(13.5f), lineHeight = ui.t(16f), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
internal fun EditorFact(label: String, value: String) {
    val ui = uiScale()
    EditorRule()
    Row(Modifier.fillMaxWidth().heightIn(min = 46.dp).padding(vertical = ui.s(8f)), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(0.44f), color = EditorStyle.Muted, fontSize = ui.t(13f))
        Spacer(Modifier.width(ui.s(12f)))
        Text(value, Modifier.weight(0.56f), color = Color.White, fontSize = ui.t(14f), textAlign = TextAlign.End)
    }
}

@Composable
internal fun EditorToggle(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().toggleable(checked, role = Role.Switch, onValueChange = onChange)
        .heightIn(min = ui.s(54f)).padding(vertical = ui.s(6f)), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontSize = ui.t(16f), color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(ui.s(10f)))
        NurSwitch(checked, EditorStyle.Paper)
    }
}

@Composable
internal fun EditorStepper(label: String, value: String, minusEnabled: Boolean, plusEnabled: Boolean,
    onMinus: () -> Unit, onPlus: () -> Unit) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().heightIn(min = ui.s(60f)), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f).padding(end = ui.s(6f)), fontSize = ui.t(15f),
            lineHeight = ui.t(19f), color = Color.White, fontWeight = FontWeight.SemiBold)
        StepButton("−", tr("Уменьшить: {0}", label), minusEnabled, onMinus)
        Text(value, color = EditorStyle.Paper, fontSize = ui.t(14f), textAlign = TextAlign.Center)
        StepButton("+", tr("Увеличить: {0}", label), plusEnabled, onPlus)
    }
}

@Composable
private fun StepButton(glyph: String, label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(48.dp).clip(CircleShape).clickable(enabled = enabled, role = Role.Button, onClick = onClick)
        .semantics { contentDescription = label }, contentAlignment = Alignment.Center) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(EditorStyle.Track), contentAlignment = Alignment.Center) {
            Text(glyph, color = if (enabled) EditorStyle.Paper else EditorStyle.Muted.copy(alpha = 0.55f),
                fontSize = uiScale().t(18f))
        }
    }
}
