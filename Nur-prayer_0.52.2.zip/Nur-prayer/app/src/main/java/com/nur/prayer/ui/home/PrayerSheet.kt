package com.nur.prayer.ui.home

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.dismiss
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.AzanSound
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.ChoiceRow
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurSwitch
import com.nur.prayer.ui.components.PillButton
import com.nur.prayer.ui.components.SheetGrabber
import com.nur.prayer.ui.components.pageContentInsets
import com.nur.prayer.ui.theme.ArabicFont
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale

private val SheetInk = Color(0xFF11121C)
private val GroupInk = Color(0xFF1C1D29)
private val Muted = Color(0xFFB2B2C0)
private val Cream = Color(0xFFFFF2E5)
private val Apricot = Color(0xFFF2BE74)
private val RuleInk = Color(0xFF333440)

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun PrayerSheet(
    data: PrayerData, initial: Prayer, actions: AppActions, notificationsAllowed: Boolean,
    exactAlarmsAllowed: Boolean, motion: PrayerSheetMotion, active: Boolean, onDismiss: () -> Unit
) {
    val ui = uiScale()
    val prayers = remember(data.fajrEqualsDawn) { HomeTimeline.prayers(data.fajrEqualsDawn) }
    val pager = rememberPagerState(initialPage = HomeTimeline.pageOf(initial, data.fajrEqualsDawn)) { prayers.size }
    val scrolls = prayers.map { key(it) { rememberScrollState() } }
    val gripPx = with(LocalDensity.current) { SheetGrabber.LANE.toPx() }
    val canTake = remember(pager, scrolls, gripPx, motion) {
        { y: Float, windowHeight: Int ->
            val surfaceTop = windowHeight - motion.extent * motion.progress + gripPx
            y < surfaceTop || !scrolls[pager.currentPage.coerceIn(scrolls.indices)].canScrollBackward
        }
    }
    val latestDismiss = rememberUpdatedState(onDismiss)
    val close = remember { { latestDismiss.value() } }
    var previewing by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { if (previewing) actions.stopAzan() } }

    val bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val banner = !notificationsAllowed || !exactAlarmsAllowed
    Box(Modifier.fillMaxSize().drawBehind { drawRect(Ink, alpha = 0.55f * motion.progress) }
        .prayerSheetInput(motion, active, canTake, close)) {
        BoxWithConstraints(Modifier.fillMaxSize().pageContentInsets(), contentAlignment = Alignment.BottomCenter) {
            // One viewport for all prayers. Opening sound choices grows the scroll range, NOT the sheet.
            val body = minOf(ui.s(if (banner) 598f else 516f) + bottom, (maxHeight - SheetGrabber.LANE).coerceAtLeast(0.dp))
            Column(Modifier.fillMaxWidth().onSizeChanged { motion.extent = it.height.toFloat() }
                .graphicsLayer { translationY = (1f - motion.progress) * size.height }) {
                SheetGrabber()
                HorizontalPager(state = pager, key = { prayers[it].name }, modifier = Modifier.fillMaxWidth().height(body)
                    .clip(RoundedCornerShape(topStart = ui.s(28f), topEnd = ui.s(28f))).background(SheetInk)
                    .testTag("prayer-sheet").semantics { dismiss { if (active) close(); active } }) { index ->
                    val prayer = prayers[index]
                    Column(Modifier.fillMaxSize().verticalScroll(scrolls[index])
                        .padding(start = ui.s(17f), end = ui.s(17f), top = ui.s(38f), bottom = ui.s(14f) + bottom),
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(horizontalArrangement = Arrangement.spacedBy(ui.s(20f)), verticalAlignment = Alignment.CenterVertically) {
                            Text(PrayerLabels.title(prayer), color = TextPrimary, fontSize = ui.t(32f), lineHeight = ui.t(39f),
                                fontWeight = FontWeight.Bold, modifier = Modifier.semantics { heading() })
                            Text(PrayerLabels.arabic(prayer), color = TextSecondary, fontSize = ui.t(22f), fontFamily = ArabicFont.family)
                        }
                        PageDots(prayers.size, index)
                        TimeHero(prayer, data)
                        if (banner) {
                            Spacer(Modifier.height(ui.s(20f)))
                            if (!notificationsAllowed) PermissionBanner(tr("Уведомления отключены"),
                                tr("Разрешите, иначе азан не придёт"), tr("Включить"), actions.openNotificationSettings)
                            else PermissionBanner(tr("Точные напоминания выключены"), tr("Без этого азан может не прийти вовремя"),
                                tr("Разрешить"), actions.openExactAlarmSettings)
                        }
                        Spacer(Modifier.height(ui.s(18f)))
                        NotificationGroup(prayer, data, actions, previewing) { previewing = it }
                    }
                }
            }
        }
    }
}

@Composable
private fun PageDots(count: Int, selected: Int) {
    val ui = uiScale()
    Row(Modifier.padding(top = ui.s(13f), bottom = ui.s(18f)).semantics {
        contentDescription = tr("Страница {0} из {1}", selected + 1, count)
    }, horizontalArrangement = Arrangement.spacedBy(ui.s(8f))) {
        repeat(count) { Box(Modifier.size(ui.s(7f)).background(if (it == selected) Color.White else Color(0xFF565662), CircleShape)) }
    }
}

@Composable
private fun TimeHero(prayer: Prayer, data: PrayerData) {
    val ui = uiScale()
    val tomorrow = data.days.getOrNull(1)
    val end = HomeTimeline.endOf(prayer, data.today, tomorrow, data.fajrEqualsDawn)
    Text(data.today.times[prayer]?.let(Format::time) ?: "—", color = TextPrimary, fontSize = ui.t(55f),
        lineHeight = ui.t(61f), fontWeight = FontWeight.Bold, letterSpacing = ui.t(-1f))
    Text(PrayerLabels.hint(prayer), color = Muted, fontSize = ui.t(15f), lineHeight = ui.t(19f),
        fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    Row(Modifier.fillMaxWidth().padding(top = ui.s(26f)), verticalAlignment = Alignment.CenterVertically) {
        Fact(tr("Длится до"), end?.let { (p, at) -> "${PrayerLabels.title(p)} · ${Format.time(at)}" } ?: "—", Modifier.weight(1.13f))
        Spacer(Modifier.width(1.dp).height(ui.s(43f)).background(RuleInk))
        Fact(tr("Завтра"), tomorrow?.times?.get(prayer)?.let(Format::time) ?: "—", Modifier.weight(1f))
    }
}

@Composable
private fun Fact(title: String, value: String, modifier: Modifier) {
    val ui = uiScale()
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title.uppercase(L10n.language.locale), color = Muted, fontSize = ui.t(12f), lineHeight = ui.t(15f), fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(ui.s(5f)))
        Text(value, color = TextPrimary, fontSize = ui.t(16f), lineHeight = ui.t(21f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

@Composable
private fun PermissionBanner(title: String, subtitle: String, action: String, onAction: () -> Unit) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().background(Apricot, RoundedCornerShape(ui.s(18f))).heightIn(min = ui.s(64f))
        .padding(start = ui.s(18f), end = ui.s(10f), top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Labels(title, subtitle, Modifier.weight(1f), Ink, Ink)
        Spacer(Modifier.width(ui.s(8f)))
        Box(Modifier.heightIn(min = 48.dp).clickable(role = Role.Button, onClick = onAction), contentAlignment = Alignment.Center) {
            Text(action, Modifier.background(Ink, CircleShape).padding(horizontal = ui.s(18f), vertical = ui.s(9f)),
                color = TextPrimary, fontSize = ui.t(13f), lineHeight = ui.t(18f), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun Labels(title: String, subtitle: String, modifier: Modifier, primary: Color = TextPrimary, secondary: Color = Muted) {
    val ui = uiScale()
    Column(modifier) {
        Text(title, color = primary, fontSize = ui.t(15f), lineHeight = ui.t(19f), fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(ui.s(3f)))
        Text(subtitle, color = secondary, fontSize = ui.t(12f), lineHeight = ui.t(16f), fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun NotificationGroup(prayer: Prayer, data: PrayerData, actions: AppActions, previewing: Boolean, setPreviewing: (Boolean) -> Unit) {
    val ui = uiScale()
    val settings = data.settings
    val enabled = settings.notifications[prayer] == true
    val offset = settings.offsets[prayer] ?: 0
    var soundsOpen by rememberSaveable(prayer) { mutableStateOf(false) }
    val time = data.today.times[prayer]?.let(Format::time) ?: "—"
    val row = Modifier.fillMaxWidth().heightIn(min = ui.s(65f))
    val label = tr("Поправка времени")
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(ui.s(20f))).background(GroupInk)
        .padding(horizontal = ui.s(17f), vertical = ui.s(6f))) {
        Row(row.toggleable(value = enabled, role = Role.Switch, onValueChange = { actions.setNotification(prayer, it) }),
            verticalAlignment = Alignment.CenterVertically) {
            Labels(tr("Уведомление"), when {
                !enabled -> tr("Выключено")
                settings.preAlertMinutes > 0 -> tr("В {0} и за {1} мин", time, settings.preAlertMinutes)
                else -> tr("В {0}", time)
            }, Modifier.weight(1f))
            NurSwitch(checked = enabled, accent = Cream)
        }
        Rule()
        Row(row.clickable(enabled = enabled, role = Role.Button, onClickLabel = if (soundsOpen) tr("Свернуть") else tr("Выбрать звук")) {
            soundsOpen = !soundsOpen
        }, verticalAlignment = Alignment.CenterVertically) {
            Labels(tr("Звук"), settings.azanSound.title, Modifier.weight(1f), primary = if (enabled) TextPrimary else Muted)
            Glyph(GlyphKind.CHEVRON, Muted, Modifier.size(ui.s(16f)).graphicsLayer { rotationZ = if (soundsOpen && enabled) 90f else 0f })
        }
        if (soundsOpen && enabled) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                AzanSound.entries.forEach { sound ->
                    ChoiceRow(title = sound.title, subtitle = sound.explanation, selected = settings.azanSound == sound,
                        accent = Cream, onClick = { actions.setAzanSound(sound) })
                }
                if (settings.azanSound != AzanSound.SILENT) PillButton(if (previewing) tr("Остановить") else tr("Прослушать"), onClick = {
                    if (previewing) actions.stopAzan() else actions.previewAzan(settings.azanSound)
                    setPreviewing(!previewing)
                })
            }
        }
        Rule()
        Row(row, verticalAlignment = Alignment.CenterVertically) {
            Labels(label, tr("Сдвигает расписание и азан"), Modifier.weight(1f))
            Row(Modifier.background(SheetInk, CircleShape), verticalAlignment = Alignment.CenterVertically) {
                Step("−", tr("Уменьшить: {0}", label), offset > -60) { actions.setOffset(prayer, offset - 1) }
                Text(when { offset > 0 -> tr("+{0} мин", offset); else -> tr("{0} мин", offset) },
                    fontSize = ui.t(13f), color = TextPrimary, textAlign = TextAlign.Center)
                Step("+", tr("Увеличить: {0}", label), offset < 60) { actions.setOffset(prayer, offset + 1) }
            }
        }
    }
}

@Composable
private fun Step(glyph: String, description: String, enabled: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(48.dp).semantics { contentDescription = description }.clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center) {
        Text(glyph, color = if (enabled) TextSecondary else Muted, fontSize = uiScale().t(18f), fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun Rule() = Spacer(Modifier.fillMaxWidth().height(1.dp).background(RuleInk))
