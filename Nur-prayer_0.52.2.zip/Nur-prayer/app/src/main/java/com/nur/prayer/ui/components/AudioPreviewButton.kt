package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.uiScale

internal object AudioPreviewInk {
    val Paper = Color(0xFFF1EEE3)
    val Track = Color(0xFF19191B)
}

/** The azan preview ring: same optical size everywhere, independent 48 dp touch target. */
@Composable
internal fun AudioPreviewButton(playing: Boolean, label: String, onClick: () -> Unit,
    modifier: Modifier = Modifier, filled: Boolean = playing, alignment: Alignment = Alignment.Center) {
    val ui = uiScale()
    val ink = if (filled) AudioPreviewInk.Track else AudioPreviewInk.Paper
    Box(modifier.size(48.dp).clickable(role = Role.Button, onClick = onClick)
        .semantics { contentDescription = label }, contentAlignment = alignment) {
        Box(Modifier.size(ui.s(32f)).clip(CircleShape)
            .background(if (filled) AudioPreviewInk.Paper else Color.Transparent)
            .border(1.dp, AudioPreviewInk.Paper, CircleShape), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(ui.s(13f))) {
                if (playing) drawRect(ink, Offset(size.width * .14f, size.height * .14f), Size(size.width * .72f, size.height * .72f))
                else drawPath(Path().apply {
                    moveTo(size.width * .22f, size.height * .05f)
                    lineTo(size.width * .96f, size.height * .5f)
                    lineTo(size.width * .22f, size.height * .95f); close()
                }, ink)
            }
        }
    }
}
