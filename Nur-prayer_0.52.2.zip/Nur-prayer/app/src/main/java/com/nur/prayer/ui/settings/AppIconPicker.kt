package com.nur.prayer.ui.settings

import android.graphics.Bitmap
import android.graphics.drawable.AdaptiveIconDrawable
import android.content.res.Resources
import android.util.LruCache
import kotlin.math.roundToInt
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.res.ResourcesCompat
import com.nur.prayer.i18n.tr
import com.nur.prayer.icon.AppIcon
import com.nur.prayer.icon.title
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
internal fun AppIconPicker(selected: AppIcon, onSelect: (AppIcon) -> Unit) {
    val ui = uiScale()
    val side = ui.s(EditorStyle.SIDE)
    EditorLabel(tr("Иконка"), Modifier.padding(horizontal = side))
    Spacer(Modifier.height(ui.s(12f)))
    val list = rememberLazyListState(initialFirstVisibleItemIndex = selected.ordinal)
    // Reference tile occupies 185/1080 of the screen; cap it in multi-window and on tablets.
    val size = (ui.widthDp * (185f / 1080f)).dp.coerceIn(56.dp, 82.dp)
    val corner = size * 0.245f
    val stroke = ui.s(2.5f)
    val outset = stroke + ui.s(2.5f)
    val tileShape = RoundedCornerShape(corner)
    val ringShape = RoundedCornerShape(corner + outset)
    val slot = size + outset * 2
    val px = with(LocalDensity.current) { size.roundToPx().coerceAtLeast(1) }
    val context = LocalContext.current
    val cache = remember(context, px) { LruCache<AppIcon, ImageBitmap>(AppIcon.entries.size) }
    LazyRow(Modifier.fillMaxWidth().selectableGroup().testTag("icon-strip"), state = list,
        contentPadding = PaddingValues(horizontal = side), horizontalArrangement = Arrangement.spacedBy(ui.s(9f))) {
        items(AppIcon.entries, key = { it.id }) { icon ->
            val active = selected == icon
            var image by remember(cache, icon) { mutableStateOf<ImageBitmap?>(cache.get(icon)) }
            LaunchedEffect(cache, icon) {
                if (image == null) image = withContext(Dispatchers.Default) {
                    renderIconPlate(context.resources, icon, px).also { cache.put(icon, it) }
                }
            }
            Column(Modifier.width(slot).testTag("app-icon-${icon.id}").selectable(active, role = Role.RadioButton) {
                if (!active) onSelect(icon)
            }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(slot).then(if (active) Modifier.border(stroke, Color.White, ringShape) else Modifier),
                    contentAlignment = Alignment.Center) {
                    image?.let { Image(it, contentDescription = null, modifier = Modifier.size(size).clip(tileShape).testTag("icon-art-${icon.id}")) }
                }
                Spacer(Modifier.height(ui.s(6f)))
                Text(icon.title(), color = if (active) Color.White else EditorStyle.Muted, fontSize = ui.t(12f),
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** The picker owns its corners. Draw only the two artwork layers; the OEM's mask belongs to the launcher.
 * The visible 72dp of a 108dp adaptive icon maps edge to edge, without changing launcher resources. */
private fun renderIconPlate(resources: Resources, icon: AppIcon, px: Int): ImageBitmap {
    val art = requireNotNull(ResourcesCompat.getDrawable(resources, icon.launcher, null)).mutate() as AdaptiveIconDrawable
    val bitmap = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    val bleed = (px * (18f / 72f)).roundToInt()
    for (layer in listOfNotNull(art.background, art.foreground)) {
        layer.setBounds(-bleed, -bleed, px + bleed, px + bleed)
        layer.draw(canvas)
    }
    bitmap.prepareToDraw()
    return bitmap.asImageBitmap()
}
