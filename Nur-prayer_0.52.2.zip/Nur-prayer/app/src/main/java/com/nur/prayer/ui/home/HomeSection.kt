package com.nur.prayer.ui.home

import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.shell.ShellGlyph

/** Destinations reachable from the home bar and sections menu. */
enum class HomeSection(val glyph: ShellGlyph) {
    QURAN(ShellGlyph.BOOK),
    DHIKR(ShellGlyph.TASBIH),
    QIBLA(ShellGlyph.KAABA),
    TODAY(ShellGlyph.CHECKLIST),
    COURSE(ShellGlyph.AIN),
    SCHEDULE(ShellGlyph.CALENDAR),
    SETTINGS(ShellGlyph.GEAR);

    fun label(): String = when (this) {
        QURAN -> tr("Коран")
        DHIKR -> tr("Зикр")
        QIBLA -> tr("Кыбла")
        TODAY -> tr("Дела")
        COURSE -> tr("Учёба")
        SCHEDULE -> tr("Месяц")
        SETTINGS -> tr("Настройки")
    }

    companion object {
        /** Row-major in two columns, the same reading order when stacked. Settings stands below. */
        val GRID: List<HomeSection> = listOf(DHIKR, QIBLA, TODAY, SCHEDULE)
    }
}
