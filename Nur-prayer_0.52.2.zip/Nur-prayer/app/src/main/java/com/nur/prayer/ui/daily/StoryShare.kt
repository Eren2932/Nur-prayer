package com.nur.prayer.ui.daily

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.core.content.FileProvider
import com.nur.prayer.daily.StorySlide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.ceil

internal object StoryShare {
    // Separate directory and unique URI: sharing a second slide must not overwrite the first
    // while a receiver is still opening it. Only our old exports are pruned.
    suspend fun image(context: Context, slide: StorySlide, title: String, photo: Bitmap): Intent = withContext(Dispatchers.IO) {
        val art = StoryArtwork(slide, title)
        val w = 1080
        val card = Bitmap.createBitmap(w, ceil(art.height * w / StoryArtwork.WIDTH).toInt(), Bitmap.Config.ARGB_8888)
        val file = try {
            art.draw(Canvas(card), w.toFloat(), photo, StoryArtwork.CardSurface.PNG)
            val dir = File(context.cacheDir, "share/stories").apply { mkdirs() }
            val cutoff = System.currentTimeMillis() - 24L * 60 * 60 * 1000
            dir.listFiles()?.filter { it.isFile && it.lastModified() < cutoff }?.forEach { it.delete() }
            val out = File.createTempFile("nur-story-", ".png", dir)
            try { out.outputStream().buffered().use { check(card.compress(Bitmap.CompressFormat.PNG, 100, it)) }; out }
            catch (e: Exception) { out.delete(); throw e }
        } finally { card.recycle() }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".share", file)
        Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("Nur", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, null)
    }
}
