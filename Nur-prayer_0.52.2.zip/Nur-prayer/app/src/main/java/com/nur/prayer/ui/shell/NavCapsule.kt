package com.nur.prayer.ui.shell

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.indication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.ripple
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import com.nur.prayer.ui.today.DeedGlyphIcon
import com.nur.prayer.ui.components.CloseMark
import com.nur.prayer.ui.components.ExitButtonSpec
import com.nur.prayer.ui.TAB_HOME
import com.nur.prayer.ui.ROUTE_QURAN
import com.nur.prayer.ui.ringWanted
import com.nur.prayer.ui.components.pageContentInsets
import com.nur.prayer.ui.today.DeedGlyph
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.components.AutoSizeText
import androidx.compose.ui.platform.LocalWindowInfo
import com.nur.prayer.ui.components.rememberMotionBudget
import com.nur.prayer.ui.home.LocalHomeReadability
import com.nur.prayer.ui.home.HomeSection
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import com.nur.prayer.core.astro.PrayerDay
import java.time.Duration
import kotlinx.coroutines.delay
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** The navigation ring stays on the bar's optical axis. Only its glyph and the cards above it change. */
private val BAR_BUTTON = BarLayout.BUTTON.dp
/** The width of the pill of the reference. */
private val PILL_WIDTH = BarLayout.PILL_WIDTH.dp
/** The ring of a veil button: 2 px of the reference at 1.4667 px per dp, a hair of it fading, so 1.2 dp. */
private val BAR_RING = 1.2.dp
/** The moon of the way home was 22 dp in the 46 dp button; it keeps its share. */
private const val MOON_SHARE = 22f / 46f
/** The four dots live on a 24-unit grid where one unit is one dp (see [ShellGlyph.APPS]). */
private val APPS_BOX = 24.dp

/** 0.30.2: where the capsule really stands above the navigation bar: 1 dp lower than the room it has reserved. */
private val CAPSULE_BOTTOM = 13.dp
internal val SectionBarRoom = CAPSULE_BOTTOM + BAR_BUTTON + 8.dp

/**
 * Bottom room the capsule takes above the navigation bar; pages under it pad their lists by it. 0.36.0: the capsule
 * got 14 dp lower, the room did not: the clock, the timeline and every page stay exactly where the user knows them.
 */
val CapsuleRoom = 90.dp

/** Room the island takes under the status bar; page headers step down by it. */
val IslandRoom = 48.dp

@Composable
fun ShellLayer(
    shell: ShellState,
    route: String,
    onOpenSection: (HomeSection, Offset) -> Unit,
    onHome: (Offset) -> Unit,
    modifier: Modifier = Modifier,
    paperHome: Boolean = false,
    homeUncovered: Boolean = true,
    sectionSummary: (HomeSection) -> String = { "" }
) {
    val haptic = LocalHapticFeedback.current
    val quranDock = route == ROUTE_QURAN
    val capsuleOn = ShellRoutes.capsuleOn(route)
    // The page under the capsule keeps being named while the capsule slides away with it.
    val lastSection = remember { arrayOfNulls<HomeSection>(1) }
    val liveSection = ShellRoutes.sectionOf(route)
    if (capsuleOn) lastSection[0] = liveSection
    val section = if (capsuleOn) liveSection else lastSection[0]

    // A hidden capsule is not a capsule the panel can grow out of.
    val capsuleVisible = ShellMath.capsuleVisible(capsuleOn || quranDock, shell.capsuleHidden)
    LaunchedEffect(capsuleVisible) { if (!capsuleVisible) shell.hide() }
    LaunchedEffect(shell.open) {
        coroutineScope {
            // 0.30.2: the vibrator call goes after the first frame of the morph, not in front of it: on a
            // phone where it takes a few milliseconds that used to be a hitch right at the tap.
            if (shell.open) launch {
                withFrameNanos { }
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            }
            shell.settle()
        }
    }
    BackHandler(enabled = shell.open) { shell.hide() }

    val panelOnScreen by remember(shell) { derivedStateOf { shell.open || shell.progress > 0.001f } }
    val capsuleShown = animateFloatAsState(
        if (capsuleVisible) 1f else 0f,
        tween(if (capsuleVisible) 320 else 200, easing = FastOutSlowInEasing),
        label = "capsuleShown"
    )
    // The veil of the middle button: faint on home (the scrimmed wallpaper), firmer in a section (maybe a white page).
    val veil = animateColorAsState(
        if (paperHome) Color.White.copy(alpha = .18f) else if (section == null) ShellColors.BarGlass else ShellColors.BarGlassPage,
        tween(220), label = "barVeil"
    )
    val capsuleComposed by remember { derivedStateOf { capsuleShown.value > 0f } }

    Box(modifier.fillMaxSize()) {
        if (panelOnScreen) {
            // A tap anywhere beside the panel folds it; the page under it stays where it was.
            Box(
                Modifier
                    .fillMaxSize()
                    .testTag("shell-panel-scrim")
                    .drawBehind { drawRect(Color.Black, alpha = SCRIM_ALPHA * shell.progress.coerceIn(0f, 1f)) }
                    .pointerInput(shell) { detectTapGestures { shell.hide() } }
            )
        }
        Box(Modifier.fillMaxSize().pageContentInsets()) controls@{
            if (capsuleComposed && !ShellRoutes.study(route) && !ShellRoutes.azkarReader(route)) {
                val openSection: (HomeSection, Offset) -> Unit = { target, origin ->
                    shell.hide()
                    // The page the section opens on is already showing: folding the panel is the answer.
                    if (route != ShellRoutes.routeOf(target)) onOpenSection(target, origin)
                }
                if (quranDock) {
                    // The launch button is the dock's real three-dot button. No closed capsule here:
                    // transparent bar nodes would still eat taps on the Quran list underneath.
                    if (panelOnScreen) SectionCards(shell, liveSection, sectionSummary, openSection,
                        Modifier.align(Alignment.BottomCenter).navigationBarsPadding()
                            .padding(bottom = ExitButtonSpec.Hit + 8.dp), paper = true)
                    return@controls
                }
                // «Учёба» has nothing to offer on its own pages.
                val pillShown = animateFloatAsState(
                    if (section == HomeSection.COURSE) 0f else 1f,
                    tween(180, easing = FastOutSlowInEasing),
                    label = "pillShown"
                )
                BoxWithConstraints(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(bottom = CAPSULE_BOTTOM - (PanelLayout.HIT.dp - BAR_BUTTON) / 2 + if (capsuleOn && ringWanted(route)) ExitButtonSpec.BarClearance else 0.dp)
                        .offset { IntOffset(0, ((1f - capsuleShown.value) * ShellMath.SLIDE_DP.dp.toPx()).roundToInt()) }
                        .graphicsLayer {
                            alpha = capsuleShown.value
                            compositingStrategy = CompositingStrategy.ModulateAlpha
                        }
                ) {
                    // The middle button is at the centre; the others are placed from it (see BarLayout).
                    val leftStart = BarLayout.leftStart(maxWidth.value).dp
                    val pillStart = BarLayout.pillStart(maxWidth.value).dp
                    val pillRoom = maxOf(BarLayout.pillRoom(maxWidth.value), BarLayout.BUTTON).dp
                    val interactive = capsuleVisible && !panelOnScreen
                    val motion = rememberMotionBudget()
                    // Do not place an invisible side control over the dismiss target.
                    if (!panelOnScreen) BarLeft(
                        section = section, paperHome = paperHome, enabled = interactive,
                        onQuran = { origin -> openSection(HomeSection.QURAN, origin) },
                        onHome = { origin -> shell.hide(); onHome(origin) },
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(bottom = (PanelLayout.HIT.dp - BAR_BUTTON) / 2)
                            .padding(start = leftStart)
                    )
                    if (!panelOnScreen && pillShown.value > 0f) {
                        LearnPill(
                            paperHome = paperHome, enabled = interactive && pillShown.value > 0.99f, ambient = motion.ambient, room = pillRoom,
                            onLearn = { origin -> openSection(HomeSection.COURSE, origin) },
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(bottom = (PanelLayout.HIT.dp - BAR_BUTTON) / 2)
                                .padding(start = pillStart)
                                .graphicsLayer {
                                    alpha = pillShown.value
                                    compositingStrategy = CompositingStrategy.ModulateAlpha
                                }
                        )
                    }
                    if (panelOnScreen) SectionCards(shell, section, sectionSummary, openSection,
                        Modifier.align(Alignment.BottomCenter).padding(bottom = PanelLayout.HIT.dp + PanelLayout.RING_GAP.dp))
                    BarCenter(shell, paperHome, capsuleVisible, veil,
                        contourEligible = route == TAB_HOME && homeUncovered && capsuleVisible && motion.ambient && LocalWindowInfo.current.isWindowFocused,
                        scale = motion.foregroundScale,
                        modifier = Modifier.align(Alignment.BottomCenter))
                }
            }
        }
    }
}

private const val SCRIM_ALPHA = 0.30f

@Composable
internal fun BarCenter(shell: ShellState, paperHome: Boolean, enabled: Boolean, veil: State<Color>, contourEligible: Boolean, scale: Float, modifier: Modifier) {
    val label = if (shell.open) tr("Закрыть меню") else tr("Разделы")
    val ink = if (paperHome) LocalHomeReadability.current.ink else ShellColors.BarInk
    val interaction = remember { MutableInteractionSource() }
    Box(modifier.size(PanelLayout.HIT.dp).testTag("sections-toggle")
        .clickable(interactionSource = interaction, indication = null, enabled = enabled, role = Role.Button) {
            if (shell.open) shell.hide() else shell.show()
        }.semantics { contentDescription = label }, contentAlignment = Alignment.Center) {
        Box(Modifier.size(BAR_BUTTON).testTag("sections-ring").clip(CircleShape)
            .drawBehind { drawRect(veil.value) }
            .indication(interaction, ripple()), contentAlignment = Alignment.Center) {
            Spacer(Modifier.matchParentSize().border(BAR_RING, if (paperHome) ink else ShellColors.BarRing, CircleShape))
            // The dots come back as soon as hide() flips the target. Do not wait for the scrim spring.
            if (contourEligible) SectionsContour(paperHome, scale, BAR_RING, running = !shell.open,
                modifier = Modifier.matchParentSize())
            // На будущее: плашку «Новое» показывать только при появлении нового содержимого в разделах.
            // Это не подсказка первого запуска. Сейчас плашки и логики её показа нет.
            if (shell.open) CloseMark(ink, Modifier.size(BAR_BUTTON))
            else ShellIcon(ShellGlyph.APPS, ink, Modifier.size(APPS_BOX))
        }
    }
}

/**
 * The left button. On home: the Quran, a nearly transparent circle with a white ring and a white book. In a section:
 * the way home, a disc in the hue of the section (a pastel with its dark moon), so the colour of the bar still says where the user is.
 */
@Composable
private fun BarLeft(
    paperHome: Boolean,
    section: HomeSection?,
    enabled: Boolean,
    onQuran: (Offset) -> Unit,
    onHome: (Offset) -> Unit,
    modifier: Modifier = Modifier
) {
    val center = remember { arrayOf(Offset.Unspecified) }
    val barInk = if (paperHome) LocalHomeReadability.current.ink else ShellColors.BarInk
    Box(modifier.size(BAR_BUTTON).onGloballyPositioned { center[0] = it.boundsInRoot().center }) {
        Crossfade(targetState = section, animationSpec = tween(220), label = "barLeft") { here ->
            val label = if (here == null) tr("Коран") else tr("На главную")
            val tone = if (here == null) null else ShellTones.of(here)
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(tone?.container ?: if (paperHome) Color.White.copy(alpha = .18f) else ShellColors.BarGlass)
                    .then(if (tone == null) Modifier.border(BAR_RING, if (paperHome) barInk else ShellColors.BarRing, CircleShape) else Modifier)
                    .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) {
                        if (here == null) onQuran(center[0]) else onHome(center[0])
                    }
                    .semantics { contentDescription = label },
                contentAlignment = Alignment.Center
            ) {
                if (tone == null) DiscGlyph(ShellGlyph.BOOK, barInk, BAR_BUTTON)
                else ShellIcon(ShellGlyph.MOON, tone.ink, Modifier.size(BAR_BUTTON * MOON_SHARE))
            }
        }
    }
}

/**
 * The right button: «Учёба», a light grey pill with dark ink (the reference's), 35.5 dp high and 95 dp wide, as wide as
 * the word needs if the word is longer in another language, never wider than [room], where it would meet the edge of
 * the screen: then the word shrinks. A glint runs over it now and then ([PillShimmer]) while the bar is at rest.
 */
@Composable
private fun LearnPill(paperHome: Boolean, enabled: Boolean, ambient: Boolean, room: Dp, onLearn: (Offset) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val label = tr("Учёба")
    val center = remember { arrayOf(Offset.Unspecified) }
    val glintProgress = rememberGlint(running = ambient && enabled && !paperHome)
    Box(
        modifier
            .height(BAR_BUTTON)
            .widthIn(min = minOf(PILL_WIDTH, room), max = room)
            .onGloballyPositioned { center[0] = it.boundsInRoot().center }
            .clip(CircleShape)
            .background(if (paperHome) LocalHomeReadability.current.ink else ShellColors.PillFill)
            .glint(glintProgress)
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label) { onLearn(center[0]) }
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        AutoSizeText(
            label, color = if (paperHome) Color.White else ShellColors.PillInk, fontSize = ui.t(14.5f), minFontSize = ui.t(9f),
            fontWeight = FontWeight.ExtraBold
        )
    }
}

/** A glyph of the designer's sheet in a [disc] of its own: the size and the place it has there, a shade smaller. */
@Composable
internal fun DiscGlyph(glyph: ShellGlyph, tint: Color, disc: Dp) {
    val art = sectionArt(glyph)
    if (art != null) {
        ShellIcon(glyph, tint, Modifier.offset(disc * art.dx, disc * art.dy).size(disc * art.share * PANEL_GLYPH_FIT))
    } else {
        ShellIcon(glyph, tint, Modifier.size(disc * AIN_SHARE))
    }
}

/** The letter ع is not on the sheet: half of its disc, as the sheet's glyphs are about. */
private const val AIN_SHARE = 0.5f

private const val PANEL_GLYPH_FIT = 0.9f

/** A section must be settled for two seconds. Clock ticks never restart this delay. */
@Composable
internal fun rememberPrayerIslandTarget(route: String, days: List<PrayerDay>, now: State<ZonedDateTime>): PrayerIslandPolicy.Target? {
    val life by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    if (!life.isAtLeast(Lifecycle.State.RESUMED)) return null
    val schedule = remember(days) { PrayerIslandPolicy.schedule(days) }
    var ready by remember(route) { mutableStateOf(false) }
    LaunchedEffect(route) { delay(PrayerIslandPolicy.ENTRY_DELAY_MS); ready = true }
    val next by remember(schedule, now) { derivedStateOf { PrayerIslandPolicy.imminent(schedule, now.value) } }
    return if (ready) next else null
}

@Composable
internal fun PrayerIslandHost(target: PrayerIslandPolicy.Target?, now: State<ZonedDateTime>,
    onTap: (Offset) -> Unit, modifier: Modifier = Modifier) {
    AnimatedVisibility(visible = target != null, modifier = modifier,
        enter = fadeIn(tween(220)) + slideInVertically(tween(220)) { -it / 5 }, exit = ExitTransition.None) {
        if (target != null) TopIsland(target, now, onTap)
    }
}

internal object TimerInk {
    val Surface = Color(0xFF000000)
    val Icon = Color(0xFFFFFFFF)
    val Label = Color(0xFFF5F5F5)
    val Time = Color(0xFFFFFFFF)
}

@Composable
private fun TopIsland(target: PrayerIslandPolicy.Target, now: State<ZonedDateTime>, onTap: (Offset) -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val pill = RoundedCornerShape(50)
    val center = remember { arrayOf(Offset.Unspecified) }
    val touches = remember { MutableInteractionSource() }
    val homeLabel = tr("На главную")
    Box(modifier.height(IslandRoom)
        .onGloballyPositioned { center[0] = it.boundsInRoot().center }
        .clickable(interactionSource = touches, indication = null, role = Role.Button, onClickLabel = homeLabel) { onTap(center[0]) },
        contentAlignment = Alignment.Center) {
        Row(Modifier.height(28.dp).clip(pill).background(TimerInk.Surface).indication(touches, ripple())
            .padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            DeedGlyphIcon(DeedGlyph.MOSQUE, TimerInk.Icon, Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(PrayerLabels.title(target.prayer), color = TimerInk.Label, fontSize = ui.t(11f), lineHeight = ui.t(14f),
                fontWeight = FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.width(5.dp))
            IslandCountdown(target, now)
        }
    }
}

/** The only part of the island that changes every second. */
@Composable
private fun IslandCountdown(target: PrayerIslandPolicy.Target, now: State<ZonedDateTime>) {
    val ui = uiScale()
    Text(
        Format.countdown(Duration.between(now.value, target.start)),
        color = TimerInk.Time, fontSize = ui.t(12f), lineHeight = ui.t(15f), fontWeight = FontWeight.Bold, maxLines = 1,
        style = TextStyle(fontFeatureSettings = "tnum")
    )
}
