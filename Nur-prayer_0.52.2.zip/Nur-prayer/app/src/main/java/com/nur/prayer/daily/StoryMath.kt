package com.nur.prayer.daily

/** Timing and read state. Physical touch arbitration lives in StoryTouch. */
object StoryMath {
    const val SLIDE_COUNT = 4

    /** Time on a slide grows with its text: a long hadith is not cut off mid-sentence. */
    fun durationMillis(slide: StorySlide): Int {
        val chars = slide.ru.length + (slide.translit?.length ?: 0) / 2 + (slide.arabic?.length ?: 0) / 3 + (slide.note?.length ?: 0) / 2
        return (4500 + chars * 42).coerceIn(MIN_MILLIS, MAX_MILLIS)
    }

    const val MIN_MILLIS = 6000
    const val MAX_MILLIS = 18000

    fun isSeen(mask: Int, i: Int): Boolean = i in 0..30 && (mask shr i) and 1 == 1
    fun withSeen(mask: Int, i: Int): Int = if (i in 0..30) mask or (1 shl i) else mask
    fun allSeen(mask: Int, count: Int): Boolean = (0 until count).all { isSeen(mask, it) }

    /** Where "watch" starts: the first slide not seen today, or the beginning when all are. */
    fun firstUnseen(mask: Int, count: Int): Int = (0 until count).firstOrNull { !isSeen(mask, it) } ?: 0
}
