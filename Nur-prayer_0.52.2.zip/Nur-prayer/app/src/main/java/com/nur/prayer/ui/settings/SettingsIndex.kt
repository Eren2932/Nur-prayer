package com.nur.prayer.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.data.AppSettings
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.MenuChevron
import com.nur.prayer.ui.components.MenuGlyph
import com.nur.prayer.ui.components.MenuIcon
import com.nur.prayer.ui.theme.Crimson
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.uiScale

internal const val PRECISION_PAGE = "precision"
internal val precisionEditors = listOf("highlat", "rounding", "offsets")
internal fun settingsParent(page: String?): String? = if (page != null && page in precisionEditors) PRECISION_PAGE else null
internal fun settingsDepth(page: String) = when (page) {
    "index" -> 0
    in precisionEditors -> 2
    else -> 1
}

internal fun AppSettings.usesDefaultPrecision() = highLatitudeRule == HighLatitudeRule.AUTO &&
    rounding == RoundingMode.NEAREST && hijriOffset == 0 && offsets.values.none { it != 0 }

/** Each link is a separate keyed lazy item; no card, page scrim or per-row blur. */
internal fun LazyListScope.settingsIndex(specs: List<SettingsTile>, data: PrayerData, notificationsAllowed: Boolean,
    exactAlarmsAllowed: Boolean, locationStatus: String?, openCity: () -> Unit, onOpen: (String) -> Unit) {
    fun group(key: String, title: String) {
        item(key = "group-$key", contentType = "section") {
            val ui = uiScale()
            Text(title, Modifier.padding(top = ui.s(24f), bottom = ui.s(4f)).semantics { heading() },
                color = EditorStyle.Muted, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
        }
    }
    fun link(id: String, title: String? = null) {
        val tile = specs.first { it.id == id }
        item(key = id, contentType = "link") { IndexLink(tile.icon, title ?: tile.title, tile.value, id) { onOpen(id) } }
    }
    item(key = "heading") { IndexTitle(tr("Настройки"), large = true) }
    group("general", tr("Главное"))
    item(key = "place", contentType = "link") {
        val place = if (data.place.fromDeviceLocation) tr("{0} · авто", data.place.label) else data.place.label
        IndexLink(MenuIcon.LOCATION, tr("Город"), place, "place", onClick = openCity)
    }
    if (locationStatus != null) item(key = "location-status") { EditorNote(locationStatus) }
    link("display"); link("language")
    group("signals", tr("Азан и сигналы"))
    if (!notificationsAllowed || !exactAlarmsAllowed) item(key = "permission", contentType = "link") {
        IndexLink(MenuIcon.BELL,
            if (!notificationsAllowed) tr("Разрешите уведомления") else tr("Разрешите точные напоминания"),
            tr("Без этого азан может не прийти вовремя"), "permission", tint = Crimson) { onOpen("notify") }
    }
    link("notify"); link("azan")
    group("time", tr("Расчёт времени"))
    link("method"); link("madhab", tr("Мазхаб"))
    item(key = PRECISION_PAGE, contentType = "link") {
        IndexLink(MenuIcon.SLIDERS, tr("Точность и коррекция"),
            if (data.settings.usesDefaultPrecision()) tr("Авто") else tr("Настроено"), PRECISION_PAGE) { onOpen(PRECISION_PAGE) }
    }
    link("about")
    item(key = "version") {
        val ui = uiScale()
        Text(settingsVersionLabel(), Modifier.padding(top = ui.s(28f), bottom = ui.s(8f)),
            color = EditorStyle.Muted, fontSize = ui.t(12f))
    }
}

@Composable
internal fun IndexTitle(text: String, large: Boolean) {
    val ui = uiScale()
    Text(text, Modifier.fillMaxWidth().padding(top = LocalIslandInset.current + ui.s(8f), bottom = ui.s(12f))
        .semantics { heading() }, color = Color.White, fontSize = ui.t(if (large) 32f else 26f),
        lineHeight = ui.t(if (large) 39f else 32f), fontWeight = FontWeight.Bold)
}

/** 60 dp at the reference size. Only the minimum is fixed; long/large text can add height. */
@Composable
internal fun IndexLink(icon: MenuIcon, title: String, value: String, id: String,
    tint: Color = Color.White, onClick: () -> Unit) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().testTag("setting-$id").clickable(role = Role.Button, onClick = onClick)
        .heightIn(min = ui.s(60f).coerceAtLeast(48.dp))
        .padding(start = ui.s(3f), end = ui.s(2f), top = ui.s(7f), bottom = ui.s(7f)),
        verticalAlignment = Alignment.CenterVertically) {
        MenuGlyph(icon, tint, Modifier.size(ui.s(28f)))
        Spacer(Modifier.width(ui.s(24f)))
        if (ui.widthDp < 340f || ui.largeFont) {
            Column(Modifier.weight(1f)) {
                IndexName(title, tint)
                IndexValue(value, Modifier, TextAlign.Start)
            }
        } else {
            IndexName(title, tint, Modifier.weight(1f))
            Spacer(Modifier.width(ui.s(8f)))
            IndexValue(value, Modifier.widthIn(max = ui.s(120f)), TextAlign.End)
        }
        Spacer(Modifier.width(ui.s(12f)))
        MenuChevron()
    }
}

@Composable
private fun IndexName(text: String, color: Color, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Text(text, modifier, color = color, fontSize = ui.t(16f), lineHeight = ui.t(20f), fontWeight = FontWeight.Bold)
}

@Composable
private fun IndexValue(text: String, modifier: Modifier, align: TextAlign) {
    val ui = uiScale()
    Text(text, modifier, color = EditorStyle.Muted, fontSize = ui.t(14f), lineHeight = ui.t(18f),
        fontWeight = FontWeight.Medium, textAlign = align, maxLines = 2, overflow = TextOverflow.Ellipsis)
}
