package com.nur.prayer.ui.shell

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.home.HomeSection
import com.nur.prayer.ui.theme.uiScale
import com.nur.prayer.ui.today.DeedTone

/** The ring is a sibling, never a child of the scrolling/animated surface. Gaps are dismiss targets. */
@Composable
internal fun SectionCards(shell: ShellState, current: HomeSection?, summary: (HomeSection) -> String,
    open: (HomeSection, Offset) -> Unit, modifier: Modifier = Modifier, paper: Boolean = false) {
    val gap = PanelLayout.GAP.dp
    BoxWithConstraints(modifier.padding(horizontal = PanelLayout.SIDE.dp).widthIn(max = PanelLayout.MAX_WIDTH.dp)
        .fillMaxWidth()) {
        val columns = PanelLayout.columns(maxWidth.value, LocalDensity.current.fontScale)
        val frost = if (paper) null else rememberFrost()
        val rows = remember(columns) { HomeSection.GRID.chunked(columns) }
        Column(Modifier.fillMaxWidth().graphicsLayer { alpha = shell.progress.coerceIn(0f, 1f) }
            .then(if (shell.open) Modifier else Modifier.clearAndSetSemantics { })
            .pointerInput(shell) { detectTapGestures { shell.hide() } }
            .verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(gap)) {
            for (sections in rows) {
                Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    for (section in sections) SectionTile(section, summary(section), section == current, shell.open,
                        frost, open, Modifier.weight(1f).fillMaxHeight())
                }
            }
            SectionTile(HomeSection.SETTINGS, "", false, shell.open, frost, open, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun SectionTile(section: HomeSection, summary: String, current: Boolean, enabled: Boolean, frost: FrostHandle?,
    open: (HomeSection, Offset) -> Unit, modifier: Modifier) {
    val ui = uiScale()
    val settings = section == HomeSection.SETTINGS
    val label = section.label()
    val shape = RoundedCornerShape(14.dp)
    val center = remember { arrayOf(Offset.Unspecified) }
    val surface = if (frost == null) Modifier.clip(shape).background(ShellColors.Glass)
        else Modifier.frostGlass(remember(frost) { frost.atAnotherOrigin() }, shape, halo = false, style = GlassStyle.SECTION)
    Row(modifier.heightIn(min = (if (settings) PanelLayout.SETTINGS else PanelLayout.ROW).dp)
        .onGloballyPositioned { center[0] = it.boundsInRoot().center }
        .then(surface).clickable(enabled = enabled, role = Role.Button) { open(section, center[0]) }
        .semantics { contentDescription = label; if (current) selected = true }
        .padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = if (settings) Arrangement.Center else Arrangement.Start) {
        if (settings) {
            ShellIcon(ShellGlyph.GEAR, DeedTone.Ink, Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Text(label, color = DeedTone.Ink, fontSize = ui.t(16f), fontWeight = FontWeight.Bold)
        } else {
            Column(Modifier.weight(1f)) {
                Text(label, color = DeedTone.Ink, fontSize = ui.t(16f), lineHeight = ui.t(20f), fontWeight = FontWeight.Bold)
                if (summary.isNotEmpty()) Text(summary, color = DeedTone.Quiet, fontSize = ui.t(13f), lineHeight = ui.t(16f))
            }
            Spacer(Modifier.width(6.dp))
            val well = PanelLayout.DISC.dp
            val tone = ShellTones.of(section)
            Box(Modifier.then(if (current) Modifier.border(1.5.dp, tone.ink, CircleShape) else Modifier)
                .padding(3.dp).size(well).background(tone.well, CircleShape), contentAlignment = Alignment.Center) {
                DiscGlyph(section.glyph, Color.White, well)
            }
        }
    }
}
