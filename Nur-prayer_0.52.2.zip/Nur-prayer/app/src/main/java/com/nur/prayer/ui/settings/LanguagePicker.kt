package com.nur.prayer.ui.settings

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.AppLanguage
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.LocalLanguageSwitcher
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.uiScale

/**
 * 0.13.0 language list.
 *
 * Each row: flag, the language's own name (always in itself — a user lost in a foreign UI must
 * still find his own), and below it the name in the current UI language. The check moves at once,
 * on the tap; the words follow a breath later through [LocalLanguageSwitcher] (fade out, swap,
 * fade in), so the tap never feels ignored and the text never flashes half-translated.
 */
@Composable
internal fun ColumnScope.LanguagePicker() {
    val ui = uiScale()
    val switch = LocalLanguageSwitcher.current
    var chosen by remember { mutableStateOf(L10n.language) }
    val languages = L10n.available
    languages.forEach { language ->
        EditorRule()
        val active = language == chosen
        Row(Modifier.fillMaxWidth().testTag("language-${language.code}")
            .selectable(active, role = Role.RadioButton) {
                if (!active) { chosen = language; switch(language) }
            }.heightIn(min = ui.s(60f)).padding(vertical = ui.s(7f)), verticalAlignment = Alignment.CenterVertically) {
            Flag(language, Modifier.size(ui.s(28f)))
            Spacer(Modifier.width(ui.s(12f)))
            Column(Modifier.weight(1f)) {
                Text(language.nativeName, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold)
                val translated = languageName(language)
                if (translated != language.nativeName) EditorNote(translated)
            }
            if (active) EditorMark()
        }
    }
}

/** Emoji flag in a circle; Tatarstan has no emoji, so its three bands are drawn by hand. */
@Composable
private fun Flag(language: AppLanguage, modifier: Modifier) {
    val ui = uiScale()
    Box(modifier.clip(CircleShape).background(Color(0x1FFFFFFF)), contentAlignment = Alignment.Center) {
        val emoji = language.flag
        if (emoji != null) {
            // Slightly larger than the circle: the circle crops the flag's own rounded rectangle.
            Text(emoji, fontSize = ui.t(26f), modifier = Modifier.graphicsLayer { scaleX = 1.25f; scaleY = 1.25f })
        } else Canvas(Modifier.matchParentSize()) {
            val h = size.height
            drawRect(Color(0xFF00A651), size = size.copy(height = h * 0.46f))
            drawRect(Color.White, topLeft = Offset(0f, h * 0.46f), size = size.copy(height = h * 0.08f))
            drawRect(Color(0xFFED1C24), topLeft = Offset(0f, h * 0.54f), size = size.copy(height = h * 0.46f))
        }
    }
}

/** Filled accent circle with a check that draws itself in; [progress] 0 → empty ring. */
@Composable
internal fun CheckMark(accent: Color, progress: Float, modifier: Modifier) {
    Canvas(modifier) {
        val r = size.minDimension / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        val p = progress.coerceIn(0f, 1.2f)
        drawCircle(Color(0x33FFFFFF), r - 1.dp.toPx(), c, style = Stroke(1.5.dp.toPx()))
        if (p <= 0.01f) return@Canvas
        drawCircle(accent, r * p.coerceAtMost(1.08f), c)
        val t = ((p - 0.35f) / 0.65f).coerceIn(0f, 1f)
        if (t > 0f) {
            val a = Offset(c.x - r * 0.42f, c.y + r * 0.02f)
            val b = Offset(c.x - r * 0.10f, c.y + r * 0.32f)
            val e = Offset(c.x + r * 0.45f, c.y - r * 0.30f)
            val first = 0.4f
            val path = Path().apply {
                moveTo(a.x, a.y)
                if (t <= first) lineTo(a.x + (b.x - a.x) * t / first, a.y + (b.y - a.y) * t / first)
                else {
                    lineTo(b.x, b.y)
                    val k = (t - first) / (1f - first)
                    lineTo(b.x + (e.x - b.x) * k, b.y + (e.y - b.y) * k)
                }
            }
            drawPath(path, Color.White, style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

/** The language's name in the current UI language. */
private fun languageName(language: AppLanguage): String = when (language) {
    AppLanguage.RU -> tr("Русский")
    AppLanguage.EN -> tr("Английский")
    AppLanguage.TR -> tr("Турецкий")
    AppLanguage.UZ -> tr("Узбекский")
    AppLanguage.KK -> tr("Казахский")
    AppLanguage.KY -> tr("Киргизский")
    AppLanguage.TT -> tr("Татарский")
    AppLanguage.TG -> tr("Таджикский")
    AppLanguage.AZ -> tr("Азербайджанский")
    AppLanguage.ID -> tr("Индонезийский")
    AppLanguage.AR -> tr("Арабский")
}
