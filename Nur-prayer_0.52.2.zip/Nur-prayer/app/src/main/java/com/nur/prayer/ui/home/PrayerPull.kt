package com.nur.prayer.ui.home

/** The net finger travel from the unscrolled edge, including touch slop, in display-independent units. */
internal object PrayerPull {
    fun closes(travelDp: Float, speedDpPerSecond: Float): Boolean =
        speedDpPerSecond > -240f && (travelDp >= 46f || (travelDp >= 32f && speedDpPerSecond >= 420f))
}
