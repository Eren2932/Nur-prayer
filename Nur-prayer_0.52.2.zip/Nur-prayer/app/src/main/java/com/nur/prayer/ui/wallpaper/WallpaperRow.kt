package com.nur.prayer.ui.wallpaper

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.MenuChevron
import com.nur.prayer.ui.settings.EditorLabel
import com.nur.prayer.ui.settings.EditorStyle
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.uiScale

@Composable
internal fun WallpaperRow(current: Wallpaper, recent: List<String>, palette: PhasePalette,
    onPick: (Wallpaper) -> Unit, onOpenAll: () -> Unit) {
    val ui = uiScale()
    val side = ui.s(EditorStyle.SIDE)
    val options = remember(current.id, recent) {
        val available = (recent + current.id).filter(GalleryPhoto::accepts) +
            WallpaperCatalog.all.sortedBy { if (it.isImage) 0 else 1 }.map { it.id }
        WallpaperOrder.row(current.id, recent, available).mapNotNull(WallpaperCatalog::find)
    }
    val list = remember(current.id) { LazyListState() }
    Row(Modifier.fillMaxWidth().padding(horizontal = side), verticalAlignment = Alignment.CenterVertically) {
        EditorLabel(tr("Обои"), Modifier.weight(1f))
        Row(Modifier.clickable(role = Role.Button, onClick = onOpenAll).widthIn(min = 48.dp).heightIn(min = 48.dp),
            horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Все"), color = EditorStyle.Muted, fontWeight = FontWeight.SemiBold, fontSize = ui.t(13f))
            Spacer(Modifier.size(ui.s(4f)))
            MenuChevron()
        }
    }
    val shape = RoundedCornerShape(ui.s(16f))
    LazyRow(Modifier.fillMaxWidth().selectableGroup().testTag("wallpaper-strip"), state = list,
        contentPadding = PaddingValues(horizontal = side), horizontalArrangement = Arrangement.spacedBy(ui.s(14f))) {
        items(options, key = { it.id }) { w ->
            val active = w == current
            val name = w.title()
            val center = remember { arrayOf(Offset.Unspecified) }
            Box(Modifier.testTag("wall-tile-${w.id}").size(ui.s(95f), ui.s(180f)).onGloballyPositioned { center[0] = it.boundsInRoot().center }
                .clip(shape).squishClick(role = Role.RadioButton) {
                    if (!active) { WallpaperScreen.requestReveal(w.id, center[0]); onPick(w) }
                }.semantics { contentDescription = name; selected = active }
                .then(if (active) Modifier.border(2.dp, EditorStyle.Paper, shape) else Modifier)) {
                WallpaperThumb(w, palette, Modifier.matchParentSize())
            }
        }
    }
}
