package com.nur.prayer.ui.today

import androidx.annotation.DrawableRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt
import com.nur.prayer.ui.shell.GlassStyle
import com.nur.prayer.ui.shell.frostGlass
import com.nur.prayer.ui.shell.rememberFrost
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.uiScale

internal object DeedTone {
    val Ink = Color(0xFF17191B)
    val Quiet = Color(0xFF29292D)
    val Green = Color(0xFF318657)
    val GreenInk = Color(0xFF103C26)
    val Badge = Color(0xFFA3C9AE)
    val DawnLink = Color(0xFF674F39)
    val DuskLink = Color(0xFFF5EAE3)
    val DuskTitle = Color(0xFFFBF9F5)
    val DuskSub = Color(0xFFFFF7F0)
    val PaperMark = Color(0x450E1014)
    val DawnMark = Color(0x70705B41)
    val DuskMark = Color(0x52FFE0CE)
    val NewLabel = Color(0x500E1014)
    val Utility = Color(0xFF36454E)
    val Track = Color(0x260E1012)
}

@Composable
internal fun Modifier.deedMatte(shape: Shape, raised: Boolean = false, @DrawableRes skyRes: Int? = null): Modifier {
    val surface = if (raised) this.shadow(3.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = .24f),
        spotColor = Color.Black.copy(alpha = .27f)) else this
    if (skyRes == null) return surface.frostGlass(rememberFrost(), shape, halo = false, style = GlassStyle.DEED)
    // Only the active azkar loads a sky. A tiny opaque color field preserves the curved
    // horizon without sampling wallpaper or calculating perceptual gradients at draw time.
    val sky = ImageBitmap.imageResource(skyRes)
    return surface.clip(shape).drawWithCache {
        val target = IntSize(size.width.roundToInt(), size.height.roundToInt())
        onDrawBehind { drawImage(sky, dstSize = target, filterQuality = FilterQuality.Low) }
    }
}

@Composable
internal fun DeedCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().deedMatte(RoundedCornerShape(uiScale().s(24f))), content = content)
}

@Composable
internal fun DeedHeading(title: String) {
    val ui = uiScale()
    Text(title, Modifier.padding(top = LocalIslandInset.current).padding(start = ui.s(26f), end = ui.s(23f), bottom = ui.s(12f), top = ui.s(12f)),
        fontSize = ui.t(28f), lineHeight = ui.t(34f), fontWeight = FontWeight.Bold, color = Color.White)
}
