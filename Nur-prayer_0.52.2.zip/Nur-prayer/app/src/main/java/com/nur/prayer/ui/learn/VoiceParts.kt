package com.nur.prayer.ui.learn

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nur.prayer.audio.ArabicVoice
import com.nur.prayer.audio.VoiceText
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.components.AudioPreviewButton
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.SwitchRow
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.delay

/** The process-wide voice; null in previews and tests, where every speaker simply disappears. */
val LocalArabicVoice = staticCompositionLocalOf<ArabicVoice?> { null }

/**
 * Status of the voice for this screen. Connects the engine on first use, looks again when the
 * user comes back from installing a voice, and silences it when the screen goes away.
 */
@Composable
fun rememberVoiceStatus(): ArabicVoice.Status {
    val voice = LocalArabicVoice.current ?: return ArabicVoice.Status.NO_ENGINE
    val owner = LocalLifecycleOwner.current
    DisposableEffect(voice, owner) {
        voice.attach()
        val observer = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) voice.recheck()
            if (e == Lifecycle.Event.ON_PAUSE) voice.stop()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); voice.detach() }
    }
    val status by voice.status.collectAsStateWithLifecycle()
    return status
}

/**
 * Says [text] once when [key] appears, if autoplay is on. Waits a beat for the slide-in, and
 * fires again if the engine becomes ready while the card is on screen.
 */
@Composable
fun AutoSay(text: String?, key: Any, status: ArabicVoice.Status, enabled: Boolean = true) {
    val voice = LocalArabicVoice.current ?: return
    val auto by voice.autoplay.collectAsStateWithLifecycle()
    LaunchedEffect(key, status == ArabicVoice.Status.READY, enabled) {
        if (!enabled || !auto || text.isNullOrBlank() || !voice.canSay(text, status)) return@LaunchedEffect
        delay(280)
        voice.say(text)
    }
}

/** Same play/stop control as azan audition; never expose an action the engine cannot perform. */
@Composable
fun SpeakButton(
    text: String,
    status: ArabicVoice.Status,
    modifier: Modifier = Modifier,
    slow: Boolean? = null,
    label: String = tr("Послушать")
) {
    val voice = LocalArabicVoice.current ?: return
    if (!voice.canSay(text, status)) return
    val speaking by voice.speaking.collectAsStateWithLifecycle()
    val mine = speaking != null && speaking == VoiceText.key(text)
    AudioPreviewButton(playing = mine, modifier = modifier,
        label = if (mine) tr("Остановить") + ": " + label else label,
        onClick = { if (mine) voice.stop() else voice.say(text, slow ?: voice.slow.value) })
}

/** Shown once per screen when the phone has no Arabic voice: what is missing and one button to fix it. */
@Composable
fun VoiceHint(status: ArabicVoice.Status, accent: Color, modifier: Modifier = Modifier) {
    val voice = LocalArabicVoice.current ?: return
    if (status != ArabicVoice.Status.NO_VOICE && status != ArabicVoice.Status.NO_ENGINE) return
    val context = LocalContext.current
    val ui = uiScale()
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SurfaceRaised)
            .pressClick(scaleTo = 0.98f) { voice.openInstall(context) }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Glyph(GlyphKind.SOUND_OFF, accent, Modifier.size(20.dp))
        Column(Modifier.padding(start = 12.dp).weight(1f)) {
            Text(tr("Озвучка выключена"), color = TextPrimary, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
            Text(
                if (status == ArabicVoice.Status.NO_VOICE) tr("На телефоне нет арабского голоса. Нажмите, чтобы установить.")
                else tr("Нет синтезатора речи. Установите «Синтезатор речи Google»."),
                color = TextSecondary, fontSize = ui.t(12f)
            )
        }
    }
}

/**
 * The two voice preferences, on the course map where they matter: new letters and words read
 * aloud as they appear, and the slow reading for every speaker button. Both persist in
 * [ArabicVoice]; a switch here takes effect on the next word, nothing to restart.
 */
@Composable
fun VoiceSettings(accent: Color, modifier: Modifier = Modifier) {
    val voice = LocalArabicVoice.current ?: return
    val auto by voice.autoplay.collectAsStateWithLifecycle()
    val slow by voice.slow.collectAsStateWithLifecycle()
    Column(modifier.fillMaxWidth()) {
        SwitchRow(
            title = tr("Озвучивать новое сразу"),
            checked = auto,
            accent = accent,
            onCheckedChange = voice::setAutoplay,
            subtitle = tr("Новая буква или слово звучит само при показе")
        )
        SwitchRow(
            title = tr("Медленное произношение"),
            checked = slow,
            accent = accent,
            onCheckedChange = voice::setSlow,
            subtitle = tr("Кнопка «послушать» читает медленнее")
        )
    }
}
