package com.nur.prayer.daily;

import java.util.Random;

/** Seven local photos, each used once per aligned seven-day block. Stateless across restarts. */
public final class CoverOrder {
    public static final int SIZE = 7;
    private CoverOrder() { }

    public static int index(long day) {
        long block = Math.floorDiv(day, (long) SIZE);
        int slot = (int) Math.floorMod(day, (long) SIZE);
        int[] current = shuffle(block);
        // Slot 3 can participate in a repair; only the final three never change.
        if (slot >= 4) return current[slot];
        int[] previous = shuffle(block - 1);
        for (int i = 0; i < 3; i++) {
            int j = i;
            while (recent(previous, i, current[j])) j++;
            swap(current, i, j);
        }
        return current[slot];
    }

    // At step i, 4-i candidates for the prefix remain, versus at most 3-i forbidden.
    // Thus the repair never touches the tail needed to compute the *next* block independently.
    private static boolean recent(int[] previous, int i, int value) {
        for (int k = 4 + i; k < SIZE; k++) if (previous[k] == value) return true;
        return false;
    }

    private static int[] shuffle(long block) {
        Random r = new Random(0x4E5552AF133DL ^ (block * 0x9E3779B97F4A7C15L));
        int[] a = {0, 1, 2, 3, 4, 5, 6};
        for (int i = a.length - 1; i > 0; i--) swap(a, i, r.nextInt(i + 1));
        return a;
    }

    private static void swap(int[] a, int i, int j) { int tmp = a[i]; a[i] = a[j]; a[j] = tmp; }
}
