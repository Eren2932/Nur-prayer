package com.nur.prayer.ui.shell;

/** Pure reference model. Angles increase clockwise from three o'clock, as in Nur-contour-only.mp4. */
final class SectionsContourModel {
    static final int STEP = 40, PERIOD = 6080, PHASES = PERIOD / STEP, ANGLES = 96;
    static final double EXTRA_DP = 2.95 * 35.5 / 103.0; // 2.95 px inward in the original 103 px disc
    private static final double[] KNOTS = {0, .22, .53, .78, 1};
    private static final int[] SILVER = {0xff85909a, 0xffa4b2be, 0xffdbe9f3, 0xfffbfdff, 0xffffffff};
    // The cool white crest is retained on paper. A graphite outer edge belongs to the static border underneath.
    private static final int[] PAPER = {0xff3f4c54, 0xff64737e, 0xffb5c8d4, 0xffedf5fb, 0xffffffff};
    private SectionsContourModel() {}

    // A closed ring has no inactive slot: 151 -> 0 is a normal optical step, not a restart.
    static int phaseAt(long elapsedMs, float scale) {
        if (!(scale > 0f) || !Float.isFinite(scale)) return -1;
        long logical = (long) (elapsedMs / (double) scale);
        return (int) (((logical / STEP) % PHASES + 4) % PHASES); // +160 ms, as in the approved profile
    }

    // Monotonic time, not frame count. Missed samples are skipped; never request more than 25 ticks/s.
    static long sleepMs(long elapsedMs, float scale) {
        if (!(scale > 0f) || !Float.isFinite(scale)) return Long.MAX_VALUE;
        double logical = elapsedMs / (double) scale;
        double untilNext = (STEP - logical % STEP) * scale;
        return Math.max(STEP, (long) Math.ceil(untilNext));
    }
    private static double smooth(double v) {
        double x = Math.min(1, Math.max(0, v)); return x*x*(3-2*x);
    }
    static double extraDp(int value) { return EXTRA_DP * smooth((value/255.0 - .11)/.71); }
    static int color(int value, boolean paper) {
        int[] c = paper ? PAPER : SILVER;
        double v = value/255.0; int i = 0;
        while (i+2 < KNOTS.length && v > KNOTS[i+1]) i++;
        double f = (v-KNOTS[i])/(KNOTS[i+1]-KNOTS[i]);
        int out = 0xff000000;
        for (int shift=0; shift<=16; shift+=8) {
            int a=(c[i] >> shift) & 255, b=(c[i+1] >> shift) & 255;
            out |= (int) Math.round(a+(b-a)*f) << shift;
        }
        return out;
    }
    // This 14,592-byte table is baked, then decoded once per process (java.util.Base64: API 26+).
    // No worker hop, file read or whole-cycle calculation on menu close.
    private static class Holder {
        static final byte[] DATA = java.util.Base64.getDecoder().decode(SectionsContourData.PACKED);
    }
    static byte[] profile() { return Holder.DATA; }
}
