package com.nur.prayer.daily;

/** One finger, one owner until UP. Coordinates are physical window pixels, not RTL-relative. */
public final class StoryTouch {
    public enum Mode { PENDING, HOLD, PAGE, PULL, TEXT, CANCELLED }
    public enum Action { NONE, PREV, NEXT, CLOSE }
    public static final long TAP_MS = 220L;
    private final float x, width, slop, swipe, close;
    private final boolean mayPull;
    private Mode mode = Mode.PENDING;

    public StoryTouch(float x, float width, float slop, float swipe, float close, boolean mayPull) {
        this.x = x; this.width = width; this.slop = slop; this.swipe = swipe; this.close = close; this.mayPull = mayPull;
    }
    public boolean hold() {
        if (mode != Mode.PENDING) return false;
        mode = Mode.HOLD;
        return true;
    }
    public void cancel() { mode = Mode.CANCELLED; }
    public Mode move(float dx, float dy) {
        if (mode == Mode.PENDING && dx*dx + dy*dy > slop*slop) {
            if (Math.abs(dx) > Math.abs(dy)) mode = Mode.PAGE;
            else mode = dy > 0 && mayPull ? Mode.PULL : Mode.TEXT;
        }
        return mode;
    }
    public Action finish(long elapsed, float dx, float dy) {
        Mode owner = move(dx, dy);
        cancel(); // an UP or CANCEL is terminal
        if (owner == Mode.PENDING && elapsed <= TAP_MS)
            return x < width * .30f ? Action.PREV : Action.NEXT;
        if (owner == Mode.PAGE && Math.abs(dx) > swipe && Math.abs(dx) > Math.abs(dy))
            return dx < 0 ? Action.NEXT : Action.PREV;
        if (owner == Mode.PULL && dy > close && dy > Math.abs(dx)) return Action.CLOSE;
        return Action.NONE;
    }
}
