package com.nur.prayer.ui.settings

import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.nur.prayer.notify.AzanSound
import com.nur.prayer.notify.NotificationHelper

/** Foreground audition only. It neither writes preferences nor controls a scheduled prayer. */
internal class SoundAudition(private val context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private val audio = context.getSystemService(AudioManager::class.java)
    private var focus: AudioFocusRequest? = null
    private var player: MediaPlayer? = null
    var current by mutableStateOf<AzanSound?>(null)
        private set

    fun toggle(sound: AzanSound) {
        val same = current == sound
        stop()
        if (same || sound == AzanSound.SILENT || audio == null || audio.ringerMode == AudioManager.RINGER_MODE_SILENT) return
        val system = sound == AzanSound.SYSTEM
        val channel = if (system) context.getSystemService(NotificationManager::class.java)
            ?.getNotificationChannel(NotificationHelper.CHANNEL_AZAN_SYSTEM) else null
        val uri = if (channel != null) channel.sound else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        if (system && (uri == null || audio.ringerMode != AudioManager.RINGER_MODE_NORMAL)) return
        try {
            val media = MediaPlayer()
            player = media
            val attrs = channel?.audioAttributes ?: AudioAttributes.Builder()
                .setUsage(if (system) AudioAttributes.USAGE_NOTIFICATION else AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs).setOnAudioFocusChangeListener({ change ->
                    if (player === media && change < 0) stop()
                }, main).build()
            if (audio.requestAudioFocus(request) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) { stop(); return }
            focus = request
            media.setAudioAttributes(attrs)
            if (system) media.setDataSource(context, requireNotNull(uri))
            else context.resources.openRawResourceFd(AzanSound.RAW_RES_ID).use {
                media.setDataSource(it.fileDescriptor, it.startOffset, it.length)
            }
            media.setOnCompletionListener { if (player === media) stop() }
            media.setOnErrorListener { _, _, _ -> if (player === media) stop(); true }
            media.setOnPreparedListener {
                if (player === media) {
                    try {
                        media.start()
                        if (sound.limitSeconds > 0) main.postDelayed({ fade(media, 1) }, sound.limitSeconds * 1000L)
                    } catch (_: IllegalStateException) { stop() }
                }
            }
            current = sound
            media.prepareAsync()
        } catch (_: Exception) { stop() }
    }

    private fun fade(media: MediaPlayer, step: Int) {
        if (media !== player) return
        if (step >= 8) { stop(); return }
        val gain = 1f - step / 8f
        media.setVolume(gain, gain)
        main.postDelayed({ fade(media, step + 1) }, 150L)
    }

    fun stop() {
        main.removeCallbacksAndMessages(null)
        val old = player
        player = null
        current = null
        old?.release()
        focus?.let { audio?.abandonAudioFocusRequest(it) }
        focus = null
    }
}
