package com.nur.prayer.ui.home

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.pointerInput
import com.nur.prayer.ui.components.RevealMath
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Only the grip + visible surface travels, not the entire window. No coroutine per pointer sample. */
@Stable
internal class PrayerSheetMotion(private val scope: CoroutineScope, restored: Boolean) {
    var progress by mutableFloatStateOf(if (restored) 1f else 0f)
        private set
    var extent = 0f
    private var animation: Job? = null
    private var anchor = 0f

    fun grab() {
        animation?.cancel()
        anchor = progress
    }

    fun track(distance: Float) {
        if (extent > 0f) progress = (anchor - distance / extent).coerceIn(0f, 1f)
    }

    fun settle(open: Boolean) {
        animation?.cancel()
        val target = if (open) 1f else 0f
        if (progress == target) return
        val ms = if (open) RevealMath.openMillis(progress) else RevealMath.closeMillis(progress)
        animation = scope.launch {
            animate(progress, target, animationSpec = tween(ms, easing = RevealMath.Settle)) { value, _ -> progress = value }
        }
    }
}

/** Observe the entire window before children. An upward or horizontal gesture belongs to the
 * child for its entire lifetime. On a downward scroll we take only travel AFTER the top edge. */
internal fun Modifier.prayerSheetInput(
    motion: PrayerSheetMotion, active: Boolean, canTake: (Float, Int) -> Boolean, dismiss: () -> Unit
): Modifier = pointerInput(motion, active, canTake, dismiss) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        if (!active) {
            down.consume()
            do {
                val closing = awaitPointerEvent(PointerEventPass.Initial)
                closing.changes.forEach { it.consume() }
            } while (closing.changes.any { it.pressed })
            return@awaitEachGesture
        }
        val slop = viewConfiguration.touchSlop
        var startY = down.position.y
        val velocity = VelocityTracker()
        velocity.addPosition(down.uptimeMillis, down.position)
        var held = false
        try {
            do {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val p = event.changes.singleOrNull() ?: break
                if (p.id != down.id || p.isConsumed) break
                velocity.addPosition(p.uptimeMillis, p.position)
                val d = p.position - down.position
                if (!held) {
                    if (!p.pressed || d.y < -slop || abs(d.x) > slop && abs(d.x) >= d.y / 1.25f) break
                    if (!canTake(down.position.y, size.height)) {
                        startY = p.position.y
                        continue
                    }
                    if (p.position.y - startY <= slop || d.y <= 1.25f * abs(d.x)) continue
                    motion.grab()
                    held = true
                }
                val travel = (p.position.y - startY).coerceAtLeast(0f)
                motion.track((travel - slop).coerceAtLeast(0f))
                p.consume()
                if (!p.pressed) {
                    held = false
                    val speed = velocity.calculateVelocity().y / density
                    if (PrayerPull.closes(travel / density, speed)) dismiss() else motion.settle(true)
                    break
                }
            } while (true)
        } finally {
            if (held) motion.settle(true) // ACTION_CANCEL, pointer replacement, or a second finger
        }
    }
}
