package com.nur.prayer.daily;

/** Width in dp of one complete story. Font scale and display DPI are intentionally not inputs. */
public final class StoryViewport {
    private StoryViewport() {}
    public static float width(float roomWidth, float roomHeight, float heightOverWidth) {
        if (!(roomWidth > 0 && roomHeight > 0 && heightOverWidth > 0)) return 0;
        return Math.min(435f, Math.min(.88f * roomWidth, roomHeight / heightOverWidth));
    }
}
