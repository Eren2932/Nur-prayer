package com.nur.prayer.ui.shell

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf

/** Transient menu state. One reversible spring drives the cards and the full-window scrim. */
@Stable
class ShellState {
    var open by mutableStateOf(false)
        private set
    private val morph = Animatable(0f)
    val progress: Float get() = morph.value

    /**
     * 0.27.1: a page that wants the whole screen for itself (the Quran reader while one reads) asks the
     * capsule to step aside. The capsule keeps its place in the tree, so showing it again on a tap is
     * one animated float, not a composition.
     */
    var capsuleHidden by mutableStateOf(false)

    fun show() { open = true }
    fun hide() { open = false }

    suspend fun settle() {
        if (open) morph.animateTo(1f, spring(dampingRatio = ShellMath.OPEN_DAMPING, stiffness = ShellMath.OPEN_STIFFNESS))
        else morph.animateTo(0f, spring(dampingRatio = ShellMath.CLOSE_DAMPING, stiffness = ShellMath.CLOSE_STIFFNESS))
    }

    suspend fun snap() { morph.snapTo(if (open) 1f else 0f) }
}

val LocalShell = staticCompositionLocalOf<ShellState?> { null }

/** The arithmetic of the morph, kept pure for ShellMathTest. */
object ShellMath {
    /**
     * 0.30.2: both springs are (almost) critically damped, the way the system's own sheets move: a quick
     * start, a soft landing, no bounce. Opening keeps a hair of life (0.92 → well under 0.1 % overshoot,
     * so the layout never has to grow past the panel); closing is critically damped and a little stiffer,
     * so the fold is brisk and never springs off the capsule. A tap mid-way turns either around with the
     * velocity it had.
     */
    const val OPEN_DAMPING = 0.92f
    const val OPEN_STIFFNESS = 460f
    const val CLOSE_DAMPING = 1f
    const val CLOSE_STIFFNESS = 560f

    /**
     * Black laid over the blurred picture under the glass: [pictureDim] at least, so a light wallpaper
     * cannot lift the glass, and as much as the page darkens the sharp picture when that is more.
     */
    fun pictureDim(pageDim: Float, pagePeak: Float): Float = maxOf(PICTURE_DIM, pageDim.coerceIn(0f, 1f) * pagePeak)

    const val PICTURE_DIM = 0.50f

    /** The capsule is on screen when its route has it and no page asked it to step aside. */
    fun capsuleVisible(routeHasIt: Boolean, hiddenByPage: Boolean): Boolean = routeHasIt && !hiddenByPage

    /**
     * The reader's chrome (its top bar and the capsule) is up when the user asked for it (a tap, the top
     * of the surah) and nothing docks at the bottom: a selected ayah's actions or a sheet own that edge.
     */
    fun readerChrome(chromeShown: Boolean, ayahSelected: Boolean, sheetOpen: Boolean): Boolean =
        chromeShown && !ayahSelected && !sheetOpen

    /** Slide of a capsule that comes or goes: it travels this far down while it fades. */
    const val SLIDE_DP = 48f
}
