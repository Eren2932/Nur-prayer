package com.nur.prayer.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette

/**
 * The backdrop: the sky of the current prayer window (0.6.0).
 *
 * Layers, cheapest first:
 *  1. [Ink] — always. It is also the whole backdrop when the user picks the AMOLED style.
 *  2. A three-stop vertical gradient, zenith → mid → horizon, plus a soft radial bloom at the
 *     horizon on the sunrise/sunset palettes. Drawn in one `drawBehind`, i.e. once per
 *     invalidation, never per frame: the sky only changes at a prayer boundary.
 */
@Composable
fun SkyBackdrop(
    palette: PhasePalette,
    modifier: Modifier = Modifier,
    sky: Boolean = true,
    horizonContrast: () -> Float = { 1f }
) {
    Box(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(Ink)
                if (!sky || size.width < 1f || size.height < 1f) return@drawBehind
                drawRect(
                    Brush.verticalGradient(
                        0f to palette.zenith,
                        0.55f to palette.mid,
                        1f to palette.horizon
                    )
                )
                if (palette.glow.alpha > 0.01f) {
                    val radius = size.width * 0.95f
                    drawRect(
                        Brush.radialGradient(
                            colors = listOf(palette.glow, Color.Transparent),
                            center = Offset(size.width * 0.5f, size.height * 1.02f),
                            radius = radius
                        )
                    )
                }
                // Legibility floor for the dock, the pull hint and the day note, which sit on the
                // brightest band of noon. Both constants are read by the contrast contract in tools/.
                val strength = horizonContrast()
                if (strength > 0f) drawRect(
                    Brush.verticalGradient(
                        HORIZON_SCRIM_START to Color.Transparent,
                        1f to Ink.copy(alpha = HORIZON_SCRIM_ALPHA * strength)
                    )
                )
            }
    )
}

/** Darkening at the very bottom edge; keep in sync with `tools/test_amoled_source.py`. */
const val HORIZON_SCRIM_ALPHA = 0.45f
const val HORIZON_SCRIM_START = 0.5f
