package com.nur.prayer.ui.daily

import com.nur.prayer.R

internal val storyPhotos = intArrayOf(
    R.drawable.story_green_hour,
    R.drawable.story_clock_night,
    R.drawable.story_dome_day,
    R.drawable.story_open_gate,
    R.drawable.story_kaaba_gold,
    R.drawable.story_medina_blue,
    R.drawable.story_sunlit_canopies,
    R.drawable.story_twilight_domes,
    R.drawable.story_rose_sky,
    R.drawable.story_minarets_crimson,
    R.drawable.story_clock_horizon
)
