package com.nur.prayer.ui.shell

/** Measured against 393 dp: 20 dp outer margin, ~60 dp rows, a full-width fifth action.
 * Gutters are widened to 8 dp and no target is allowed to shrink to fit a short window. */
internal object PanelLayout {
    const val SIDE = 20f
    const val MAX_WIDTH = 500f
    const val GAP = 8f
    const val ROW = 64f
    const val SETTINGS = 52f
    const val HIT = 48f
    const val RING_GAP = 8f
    const val DISC = 34f

    fun columns(innerWidth: Float, fontScale: Float): Int {
        val minTile = 132f * fontScale.coerceAtLeast(1f)
        return if (innerWidth >= 2f * minTile + GAP) 2 else 1
    }
}
