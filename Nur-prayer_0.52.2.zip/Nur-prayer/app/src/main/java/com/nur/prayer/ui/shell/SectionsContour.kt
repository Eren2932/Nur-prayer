package com.nur.prayer.ui.shell

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.SweepGradient
import android.os.SystemClock
import com.nur.prayer.ui.shell.SectionsContourModel as Contour
import kotlin.ByteArray
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin

/** Keep the small geometry cache across menu toggles, but schedule zero ticks while the cross is visible. */
@Composable
internal fun SectionsContour(paper: Boolean, scale: Float, stroke: Dp, running: Boolean, modifier: Modifier) {
    val origin = remember { SystemClock.uptimeMillis() }
    val phase = remember(running, scale) {
        // Seed synchronously: the first frame with four dots already has the right highlight.
        mutableIntStateOf(if (running) Contour.phaseAt(SystemClock.uptimeMillis() - origin, scale) else -1)
    }
    val currentPhase = rememberUpdatedState(phase)
    if (running) LaunchedEffect(phase) {
        while (true) {
            val elapsed = SystemClock.uptimeMillis() - origin
            phase.intValue = Contour.phaseAt(elapsed, scale)
            delay(Contour.sleepMs(elapsed, scale))
        }
    }
    // No offscreen bitmap. Only the tiny display list redraws. The stable draw modifier retains
    // paths/shaders through open/close; replacing the phase holder does not invalidate layout.
    val layer = remember(paper, stroke) {
        Modifier.graphicsLayer { }.drawWithCache {
            val frames = ContourFrames(Contour.profile(), size.width/2f, size.height/2f,
                ceil(stroke.toPx()), 1.dp.toPx(), paper)
            onDrawBehind {
                val p = currentPhase.value.intValue
                if (p >= 0) frames.draw(drawContext.canvas.nativeCanvas, p)
            }
        }
    }
    Spacer(modifier.then(layer))
}

internal class ContourFrames(
    private val table: ByteArray, private val cx: Float, private val cy: Float,
    private val baseWidth: Float, density: Float, paper: Boolean
) {
    private class Frame(val ring: Path, val gradient: SweepGradient)
    private val n = Contour.ANGLES
    private val frames = arrayOfNulls<Frame>(Contour.PHASES)
    private val colors = IntArray(256) { Contour.color(it, paper) }
    private val outer = minOf(cx,cy)
    // On near-white paper leave a sub-dp graphite edge INSIDE the original radius. The crest itself stays white.
    private val brightOuter = outer - if (paper) minOf(baseWidth*.55f, .65f*density) else 0f
    private val inner = FloatArray(256) { (outer-baseWidth-density*Contour.extraDp(it).toFloat()).coerceAtLeast(0f) }
    private val xs = FloatArray(n) { cos(2.0*PI*it/n).toFloat() }
    private val ys = FloatArray(n) { sin(2.0*PI*it/n).toFloat() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun draw(canvas: Canvas, phase: Int) {
        val f = frames[phase] ?: build(phase).also { frames[phase] = it }
        paint.shader = f.gradient
        canvas.drawPath(f.ring, paint)
    }
    private fun build(phase: Int): Frame {
        val path = Path().apply {
            fillType = Path.FillType.EVEN_ODD
            addCircle(cx, cy, brightOuter, Path.Direction.CW)
        }
        val stops = IntArray(n+1)
        for (i in 0 until n) {
            val v = table[phase*n+i].toInt() and 255
            stops[i] = colors[v]
            val x = cx+inner[v]*xs[i]; val y = cy+inner[v]*ys[i]
            if (i == 0) path.moveTo(x,y) else path.lineTo(x,y)
        }
        path.close()
        stops[n] = stops[0] // continuous at three o'clock
        return Frame(path, SweepGradient(cx, cy, stops, null))
    }
}
