package com.nur.prayer.ui.shell;

import org.junit.Test;

public class SectionsContourTest {
    @Test public void referenceContract() { SectionsContourContract.main(new String[0]); }
}
