package com.nur.prayer

import com.nur.prayer.daily.StoryPhotoOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StoryPhotoOrderTest {
    @Test fun separateDailySetsEvenAcrossShuffleBoundaries() {
        var previous = emptySet<Int>()
        for (day in -5000L..5000L) {
            val today = (0..3).map { StoryPhotoOrder.index(day, it, 11) }.toSet()
            assertEquals(4, today.size)
            assertTrue(today.intersect(previous).isEmpty())
            previous = today
        }
    }
}
