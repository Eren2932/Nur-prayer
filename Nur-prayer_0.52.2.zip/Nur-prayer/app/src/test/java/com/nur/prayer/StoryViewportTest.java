package com.nur.prayer;

import org.junit.Test;
import static org.junit.Assert.*;
import com.nur.prayer.daily.StoryViewport;

public class StoryViewportTest {
    @Test public void fitsWholeArtworkInPortraitLandscapeAndSplitWindow() {
        for (int w : new int[]{180,240,320,360,393,430,600,851,1024})
            for (int h : new int[]{48,100,180,280,400,550,700,960})
                for (int designH=410; designH<=3200; designH+=15) {
                    float aspect=designH/608f, actual=StoryViewport.width(w,h,aspect);
                    assertTrue(actual > 0 && actual <= .88f*w+.001f && actual <= 435f);
                    assertTrue(actual*aspect <= h+.001f);
                    assertEquals(Math.min(Math.min(.88*w,435),h/(double)aspect),actual,.001);
                }
    }
    @Test public void keepsStandardPhoneWidthIfRoomPermits() {
        assertEquals(.88f*393,StoryViewport.width(393,700,1.53f),.001f);
        assertEquals(200,StoryViewport.width(393,400,2),.001f);
        assertEquals(435,StoryViewport.width(1024,860,1.1f),.001f);
    }
    @Test public void waitsForANonEmptyViewport() {
        assertEquals(0,StoryViewport.width(390,0,1.1f),0);
        assertEquals(0,StoryViewport.width(0,400,1.1f),0);
    }
}
