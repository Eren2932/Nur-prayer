package com.nur.prayer.ui.home

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PrayerPullTest {
    @Test fun speedAloneCanNeverDismiss() {
        for (distance in listOf(0f, 8f, 18f, 31.9f)) assertFalse(PrayerPull.closes(distance, 8000f))
    }
    @Test fun twoReleaseThresholds() {
        assertFalse(PrayerPull.closes(32f, 419f))
        assertTrue(PrayerPull.closes(32f, 420f))
        assertFalse(PrayerPull.closes(45.9f, 0f))
        assertTrue(PrayerPull.closes(46f, 0f))
    }
    @Test fun pullBackCancels() {
        assertFalse(PrayerPull.closes(12f, 0f))
        assertFalse(PrayerPull.closes(52f, -300f))
    }
}
