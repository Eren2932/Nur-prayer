package com.nur.prayer

import com.nur.prayer.audio.VoiceText
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.daily.StorySlide
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The story viewer's touch rules and timing; the voice text helpers. */
class StoryMathTest {
    @Test fun durationGrowsWithTextAndIsBounded() {
        val short = StorySlide("Аят", null, null, "Коротко", "—")
        val long = StorySlide("Хадис", "ب".repeat(300), "т".repeat(300), "р".repeat(400), "—")
        assertEquals(StoryMath.MIN_MILLIS, StoryMath.durationMillis(short))
        assertEquals(StoryMath.MAX_MILLIS, StoryMath.durationMillis(long))
    }

    @Test fun seenMask() {
        var m = 0
        assertEquals(0, StoryMath.firstUnseen(m, 4))
        m = StoryMath.withSeen(m, 0)
        m = StoryMath.withSeen(m, 2)
        assertTrue(StoryMath.isSeen(m, 2))
        assertFalse(StoryMath.isSeen(m, 1))
        assertEquals(1, StoryMath.firstUnseen(m, 4))
        m = StoryMath.withSeen(StoryMath.withSeen(m, 1), 3)
        assertTrue(StoryMath.allSeen(m, 4))
        assertEquals(0, StoryMath.firstUnseen(m, 4))
        // A pre-0.11 record ("seen today", no mask) reads as all seen.
        assertTrue(StoryMath.allSeen(0x7fffffff, 4))
    }

    @Test fun voiceKeysAndClips() {
        assertEquals("كِتَاب جَمِيل", VoiceText.key("  كِتَاب   جَمِيل "))
        val clips = VoiceText.parseClips("# comment\nبَ\tba.ogg\n\nبِ\tbi.ogg\n")
        assertEquals("ba.ogg", clips["بَ"])
        assertEquals(2, clips.size)
        assertTrue(VoiceText.rate(true) < VoiceText.rate(false))
    }
}
