package com.nur.prayer

import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.data.AppSettings
import com.nur.prayer.ui.settings.usesDefaultPrecision
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SettingsIndexPolicyTest {
    @Test fun autoMeansAllThreeEditorsAreAtTheirDefaults() {
        val initial = AppSettings()
        assertTrue(initial.usesDefaultPrecision())
        assertTrue(initial.copy(offsets = mapOf(Prayer.FAJR to 0)).usesDefaultPrecision())
        assertFalse(initial.copy(offsets = mapOf(Prayer.FAJR to -1)).usesDefaultPrecision())
        assertFalse(initial.copy(hijriOffset = 1).usesDefaultPrecision())
        assertFalse(initial.copy(rounding = RoundingMode.DOWN).usesDefaultPrecision())
        assertFalse(initial.copy(highLatitudeRule = HighLatitudeRule.FIXED_INTERVAL).usesDefaultPrecision())
    }
}
