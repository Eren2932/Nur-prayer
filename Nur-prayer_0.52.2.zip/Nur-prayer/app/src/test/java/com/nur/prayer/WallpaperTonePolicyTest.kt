package com.nur.prayer

import com.nur.prayer.ui.wallpaper.WallpaperTone
import com.nur.prayer.ui.wallpaper.WallpaperTonePolicy as P
import org.junit.Assert.*
import org.junit.Test

class WallpaperTonePolicyTest {
    private fun near(expected: Float, got: Float) = assertEquals(expected, got, .0001f)

    @Test fun rgbIsPerceptualNotAnAverageOfTheChannels() {
        near(.299f, P.luma(0xFFFF0000.toInt())); near(.587f, P.luma(0xFF00FF00.toInt()))
        near(.114f, P.luma(0xFF0000FF.toInt())); near(1f, P.luma(-1)); near(0f, P.luma(0))
    }

    @Test fun twoThresholdsMustBeMetIncludingEquality() {
        val edge = WallpaperTone(.12f, .70f, .99f, .72f, .9f)
        assertTrue(P.isPaper(edge)); assertFalse(P.isPaper(edge.copy(overallLuminance = .7199f)))
        assertFalse(P.isPaper(edge.copy(centerLuminance = .6999f)))
    }

    @Test fun zoneMeansCountOnlyTheirRowsButOverallCountsTheGapsToo() {
        val t = P.measure { x,y -> when {
            y < .20f -> .15f
            y in .28f.. .75f -> if (x < .25f) .79f else .39f
            y >= .80f -> .90f
            else -> 0f
        } }
        near(.15f, t.topLuminance); near(.49f, t.centerLuminance); near(.90f, t.bottomLuminance)
        near(.25f, t.brightCenterShare); near((13*.15f + 30*.49f + 13*.90f)/64f, t.overallLuminance)
        near(0f, P.measure { _,_ -> .78f }.brightCenterShare)
    }

    @Test fun nightIsUntintedAndEachZoneRampsIndependently() {
        for (y in listOf(0f, .29f, .30f)) { near(0f, P.strength(y)); near(0f, P.shadow(y)) }
        near(.17f, P.TOP_MAX * P.strength(.51f)); near(.16f, P.CENTER_MAX * P.strength(.51f))
        near(.48f, P.BOTTOM_MAX * P.strength(.99f)); near(.34f, P.TOP_MAX * P.strength(1f))
        near(.15f, P.openBlack(.1f)); near(.24f, P.openBlack(.98f)); near(.22f, P.OPEN_WHITE)
    }

    @Test fun editorProtectsIsolatedHighlightsAndUsesTheBrightestBand() {
        near(P.SETTINGS_DIM_MIN, P.settingsDim(P.Night))
        near(P.SETTINGS_DIM_MAX, P.settingsDim(P.Paper))
        near(P.SETTINGS_DIM_MAX, P.settingsDim(P.Night.copy(bottomLuminance = .9f)))
        val middle = P.settingsDim(P.Night.copy(centerLuminance = .5f))
        assertTrue(middle > P.SETTINGS_DIM_MIN && middle < P.SETTINGS_DIM_MAX)
    }

    @Test fun highlightsCanStrengthenTheShadowWithoutDarkeningTheWholePhoto() {
        assertTrue(P.shadow(.52f, .25f) > P.shadow(.52f)); near(.42f, P.shadow(.52f, .25f))
        for (i in 0..100) assertTrue(P.shadow(i/100f, .35f) in 0f.. .42f)
    }

    @Test fun gradientUsesRealStopPositionsAndHorizonGlow() {
        val solid = P.gradient(-1,-1,-1,0,.45f); near(1f, solid.overallLuminance); assertTrue(P.isPaper(solid))
        val g = P.gradient(0,-1,-1,0,.45f); assertTrue(g.topLuminance < g.centerLuminance); near(1f, g.bottomLuminance)
        val glow = P.gradient(0,0,0,-1,.45f); near(0f, glow.topLuminance); assertTrue(glow.bottomLuminance > .3f)
    }

    @Test fun offscreenBrightBorderCannotSwitchTheForeground() {
        val w = 12; val h = 24
        val pixels = IntArray(w*h) { if (it % w >= 8) -1 else 0xFF000000.toInt() }
        val left = P.picture(pixels,w,h,w,h,8,24,0f,.5f)
        val right = P.picture(pixels,w,h,w,h,8,24,1f,.5f)
        near(0f, left.overallLuminance); assertTrue(right.overallLuminance > .4f)
    }

    @Test fun onWideScreensTheVisibleMirroredFillCounts() {
        val white = IntArray(8*16) { -1 }
        val t = P.picture(white,8,16,8,16,32,16,.5f,.5f, intArrayOf(0xFF000000.toInt()),1,1)
        assertTrue(t.overallLuminance in .2f.. .6f); assertFalse(P.isPaper(t))
    }
}
