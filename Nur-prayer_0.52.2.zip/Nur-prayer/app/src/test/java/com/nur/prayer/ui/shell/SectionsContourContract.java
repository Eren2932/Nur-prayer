package com.nur.prayer.ui.shell;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Can be run on a plain JDK or by the Gradle unit test wrapper. */
public final class SectionsContourContract {
    private static void check(boolean ok, String what) { if (!ok) throw new AssertionError(what); }
    private static String sha(byte[] data) {
        try {
            StringBuilder s=new StringBuilder();
            for(byte b:MessageDigest.getInstance("SHA-256").digest(data)) s.append(String.format("%02x",b&255));
            return s.toString();
        } catch (NoSuchAlgorithmException e) { throw new AssertionError(e); }
    }
    public static void main(String[] ignored) {
        byte[] data=SectionsContourModel.profile();
        check(data==SectionsContourModel.profile() && data.length==152*96,"shared profile");
        check(sha(data).equals("73497c92d39fbe091b1c1d25f434648944c3b85617d27db206be547bb656c274"),"exact approved 0.50.1 field");
        // Every adjacent pair, including 151 -> 0: the crest remains visible and neither freezes nor jumps.
        for (int p=0;p<152;p++) {
            int next=(p+1)%152, peak=0, maxStep=0;
            for (int i=0;i<96;i++) {
                int a=data[96*p+i]&255, b=data[96*next+i]&255;
                peak=Math.max(peak,a); maxStep=Math.max(maxStep,Math.abs(a-b));
            }
            check(peak>=210 && maxStep>0 && maxStep<=14,"seam/contrast phase "+p);
        }
        // Test all ms over 100 cycles, including all former blank intervals and former clip endpoints.
        for (long t=0;t<=608000;t++) {
            int actual=SectionsContourModel.phaseAt(t,1f);
            if (actual!=(t/40+4)%152 || SectionsContourModel.sleepMs(t,1f)!=40) throw new AssertionError("time "+t);
        }
        for (int hz:new int[]{60,90,120,144}) for(int refresh=0;refresh<=hz*20;refresh++) {
            long now=Math.round(refresh*1000.0/hz);
            check(SectionsContourModel.phaseAt(now,1f)==(now/40+4)%152,"refresh-dependent phase");
        }
        for(float scale:new float[]{.5f,1f,2f,10f}) {
            long next=0;
            for(int wake=0;wake<500;wake++) {
                long now=next+(wake%23==0 ? 137 : 0); // missed updates, no catch-up frames
                long delay=SectionsContourModel.sleepMs(now,scale);
                check(delay>=40 && delay<=Math.max(40,Math.ceil(40*scale)),"tick budget");
                check(SectionsContourModel.phaseAt(now,scale)==((long)(now/(double)scale)/40+4)%152,"logical time");
                next=now+delay;
            }
        }
        check(SectionsContourModel.phaseAt(0,1)==4,"visible first frame");
        check(SectionsContourModel.phaseAt(2400,0)==-1 && SectionsContourModel.sleepMs(0,0)==Long.MAX_VALUE,"motion disabled");
        check(SectionsContourModel.color(0,false)==0xff85909a && SectionsContourModel.color(255,false)==-1 && SectionsContourModel.color(255,true)==-1,"unchanged silver/paper");
        check(SectionsContourModel.extraDp(0)==0 && Math.abs(SectionsContourModel.extraDp(255)-1.01675)<.002,"unchanged geometry");
        System.out.println("OK: 100 continuous cycles, every phase/seam and first frame, exact baseline data, refresh, stalls and motion policy");
    }
}
