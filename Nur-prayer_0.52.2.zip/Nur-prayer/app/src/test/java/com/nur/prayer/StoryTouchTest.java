package com.nur.prayer;

import com.nur.prayer.daily.StoryTouch;
import org.junit.Test;
import static com.nur.prayer.daily.StoryTouch.Action.*;
import static com.nur.prayer.daily.StoryTouch.Mode.*;
import static org.junit.Assert.*;

public class StoryTouchTest {
    private StoryTouch at(float x, boolean mayPull) { return new StoryTouch(x, 1000, 8, 56, 120, mayPull); }
    @Test public void shortTapsUsePhysicalThirtyPercentBoundary() {
        assertEquals(PREV, at(299.9f, true).finish(219, 2, -1));
        assertEquals(NEXT, at(300, true).finish(220, 0, 0));
        assertEquals(NEXT, at(900, true).finish(30, -2, 2));
        assertEquals(NONE, at(900, true).finish(221, 0, 0));
    }
    @Test public void holdWithJitterNeitherPagesNorClosesOnRelease() {
        StoryTouch t = at(800, true);
        assertEquals(PENDING, t.move(3, 3)); assertTrue(t.hold());
        assertEquals(HOLD, t.move(-90, 0)); assertEquals(NONE, t.finish(1200, 0, 200));
        assertEquals(NONE, t.finish(30, 0, 0));
    }
    @Test public void horizontalSwipesNeverBecomeHolds() {
        StoryTouch t = at(10, true); assertEquals(PAGE, t.move(-20, 3)); assertFalse(t.hold());
        assertEquals(NEXT, t.finish(450, -57, 10)); assertEquals(PREV, at(20, false).finish(120, 90, -20));
    }
    @Test public void reversingAnAbortedDragDoesNotTriggerATap() {
        StoryTouch t = at(20, true); t.move(-19, 0); assertEquals(NONE, t.finish(90, 0, 0));
        assertEquals(NONE, at(20, true).finish(100, -56, 0));
    }
    @Test public void downClosesOnlyWhenStartingAtTopOrInMargin() {
        assertEquals(CLOSE, at(200, true).finish(150, 3, 121));
        assertEquals(NONE, at(200, true).finish(150, 3, 120));
        StoryTouch t = at(200, false); assertEquals(TEXT, t.move(2, 30)); assertFalse(t.hold());
        assertEquals(NONE, t.finish(450, 0, 450));
    }
    @Test public void diagonalAndUpwardTextDragsDoNotChangePage() {
        StoryTouch t = at(500, true); assertEquals(TEXT, t.move(0, -10));
        assertEquals(NONE, t.finish(120, -200, -20));
        assertEquals(NONE, at(2, true).finish(150, 130, 130));
    }
    @Test public void cancellationBlocksAllActionsAndDelayedHold() {
        StoryTouch t = at(20, true); t.cancel(); assertFalse(t.hold()); assertEquals(NONE, t.finish(140, -200, 0));
        t = at(20, true); t.hold(); t.cancel(); assertEquals(NONE, t.finish(1500, 0, 500));
    }
}
