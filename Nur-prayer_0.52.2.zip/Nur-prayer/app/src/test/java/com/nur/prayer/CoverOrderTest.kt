package com.nur.prayer

import com.nur.prayer.daily.CoverOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CoverOrderTest {
    @Test fun eachDeckIsShuffledAndBoundaryHasNoRecentRepeat() {
        val last = IntArray(CoverOrder.SIZE) { -1000000 }
        val orders = mutableSetOf<List<Int>>()
        for (block in -500..500) {
            val deck = (0 until CoverOrder.SIZE).map { slot ->
                val day = block * CoverOrder.SIZE + slot
                val index = CoverOrder.index(day.toLong())
                assertTrue(index in last.indices)
                assertTrue(day - last[index] >= 4)
                assertEquals(index, CoverOrder.index(day.toLong()))
                last[index] = day
                index
            }
            assertEquals(last.size, deck.toSet().size)
            orders.add(deck)
        }
        assertTrue(orders.size > 100)
    }
}
