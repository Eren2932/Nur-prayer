package com.nur.prayer

import com.nur.prayer.ui.shell.PanelLayout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PanelLayoutTest {
    @Test fun referenceHasTwoIdenticalColumnsWithRoomForAThumb() {
        val inner = 393f - 2f * PanelLayout.SIDE
        assertEquals(2, PanelLayout.columns(inner, 1f))
        assertEquals(172.5f, (inner - PanelLayout.GAP) / 2f, 0f)
        assertTrue(listOf(PanelLayout.ROW, PanelLayout.SETTINGS, PanelLayout.HIT).all { it >= 48f })
    }
    @Test fun smallWindowsAndLargeTextStackRatherThanSqueeze() {
        assertEquals(1, PanelLayout.columns(240f, 1f))
        assertEquals(2, PanelLayout.columns(280f, 1f))
        assertEquals(1, PanelLayout.columns(353f, 1.5f))
        assertEquals(1, PanelLayout.columns(500f, 2f))
    }
}
