package com.nur.prayer.ui.daily

import com.nur.prayer.i18n.tr

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.runtime.rememberUpdatedState
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.RollingNumber
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.components.rememberEntranceClock
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import kotlinx.coroutines.delay
import kotlin.math.abs
import androidx.compose.ui.graphics.graphicsLayer
import com.nur.prayer.ui.learn.HGap

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.DhikrPreset
import com.nur.prayer.daily.StorySlide
import com.nur.prayer.daily.TasbihMath
import com.nur.prayer.daily.Zikr
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurButton
import com.nur.prayer.ui.components.RoundIconButton
import com.nur.prayer.ui.components.ScreenHeader
import com.nur.prayer.ui.learn.ArabicText
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.LessonBar
import com.nur.prayer.ui.learn.Tag
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.launch
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nur.prayer.ui.components.DoneSeal
import com.nur.prayer.ui.learn.textDp

/** Warm dusk for the evening set, pale dawn for the morning one — the same cue as the sky. */
internal fun azkarBrush(set: AzkarSet): Brush = if (set == AzkarSet.EVENING)
    Brush.verticalGradient(listOf(Color(0xFFB89A72), Color(0xFFD0453F)))
else Brush.verticalGradient(listOf(Color(0xFF8FB8D8), Color(0xFFE2B97E)))

/** A progress ring: the track and an arc from twelve o'clock. */
@Composable
internal fun Ring(fraction: Float, color: Color, size: Dp, stroke: Dp, modifier: Modifier = Modifier, track: Color = color.copy(alpha = 0.22f)) {
    val shown by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(220), label = "ring")
    Canvas(modifier.size(size)) {
        val w = stroke.toPx()
        val d = this.size.minDimension - w
        val tl = Offset(w / 2, w / 2)
        drawArc(track, 0f, 360f, false, tl, Size(d, d), style = Stroke(w))
        if (shown > 0f) drawArc(color, -90f, 360f * shown, false, tl, Size(d, d), style = Stroke(w, cap = StrokeCap.Round))
    }
}

// ── azkar ──────────────────────────────────────────────────────────────────────────────────────

@Composable
fun AzkarScreen(
    vm: DailyViewModel,
    items: (AzkarSet) -> List<Zikr>,
    currentSet: AzkarSet,
    sessionOf: (AzkarSet) -> String,
    palette: PhasePalette,
    onBack: () -> Unit
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    var set by rememberSaveable { mutableStateOf(currentSet) }
    val sessions by vm.azkar.collectAsStateWithLifecycle()
    val translit by vm.translit.collectAsStateWithLifecycle()
    val list = remember(set, items) { items(set) }
    val session = sessionOf(set)
    val counts = sessions[session].orEmpty()
    val done = list.count { (counts[it.id] ?: 0L) >= it.count }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    // Switching morning/evening replays the cascade; scrolling does not.
    val clock = rememberEntranceClock(set)

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(tr("Азкары"), onBack, Modifier.padding(horizontal = ui.s(16f)))
        Row(Modifier.padding(horizontal = ui.s(16f)), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AzkarSet.values().forEach { s ->
                Chip(s.title + if (s == currentSet) tr(" · сейчас") else "", s == set, palette.accent) { set = s }
            }
        }
        Gap(10f)
        Column(Modifier.padding(horizontal = ui.s(16f))) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("Прочитано "), color = TextSecondary, fontSize = ui.t(13f))
                    RollingNumber(done, TextSecondary, ui.t(13f), fontWeight = FontWeight.Normal)
                    Text(tr(" из {0}", list.size), color = TextSecondary, fontSize = ui.t(13f))
                }
                Text(if (translit) tr("скрыть транслит") else tr("показать транслит"), color = TextTertiary, fontSize = ui.t(12f),
                    modifier = Modifier.clickable { vm.setTranslit(!translit) }.padding(4.dp))
                Text(tr("заново"), color = TextTertiary, fontSize = ui.t(12f), modifier = Modifier.clickable { vm.azkarReset(session) }.padding(4.dp))
            }
            Gap(6f)
            LessonBar(done.toFloat() / list.size.coerceAtLeast(1), if (done == list.size) Mint else palette.accent)
        }
        Gap(10f)
        LazyColumn(
            Modifier.fillMaxSize(), state = listState,
            contentPadding = PaddingValues(start = ui.s(16f), end = ui.s(16f), bottom = LocalDockInset.current + 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (done == list.size && list.isNotEmpty()) item(key = "done") {
                GlassCard(Modifier.entrance(0, distance = 18f), color = Mint.copy(alpha = 0.18f)) {
                    Text(tr("{0} прочитаны. Да примет Аллах.", set.title), color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(ui.s(16f)))
                }
            }
            itemsIndexed(list, key = { _, z -> z.id }) { i, z ->
                val n = counts[z.id] ?: 0L
                AzkarCard(z, n, translit, palette.accent, Modifier.animateItem().entrance(i, clock = clock)) {
                    val now = vm.azkarTap(session, z.id, z.count)
                    if (now >= z.count) {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        // Hand the reader the next unfinished one. The "all read" banner only appears
                        // when nothing is left, so list indices map to item indices one to one here.
                        val next = list.indexOfFirst { (counts[it.id] ?: 0L) < it.count && it.id != z.id }
                        if (next >= 0) scope.launch { listState.animateScrollToItem(next) }
                    } else haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                }
            }
        }
    }
}

@Composable
private fun AzkarCard(z: Zikr, count: Long, translit: Boolean, accent: Color, modifier: Modifier = Modifier, onTap: () -> Unit) {
    val ui = uiScale()
    val finished = count >= z.count
    var open by remember(z.id, finished) { mutableStateOf(!finished) }
    val scope = rememberCoroutineScope()
    // Each "Прочитал" gives the card a small nod; finishing it lands with a bounce.
    val nod = remember { Animatable(1f) }
    val bg by animateColorAsState(if (finished) Mint.copy(alpha = 0.10f) else SurfaceRaised, tween(320), label = "azkarCard")
    GlassCard(modifier.graphicsLayer { scaleX = nod.value; scaleY = nod.value }, color = bg) {
        Row(Modifier.fillMaxWidth().pressClick(scaleTo = 0.98f, haptic = false) { open = !open }.padding(horizontal = ui.s(16f), vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(z.title, color = if (finished) TextSecondary else TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f))
            AnimatedContent(
                targetState = finished,
                transitionSpec = { (scaleIn(NurMotion.bouncy(), initialScale = 0.6f) + fadeIn(tween(140))) togetherWith fadeOut(tween(90)) },
                label = "azkarTag"
            ) { f ->
                if (f) Tag("${z.count}", color = Mint) { DoneSeal(Mint, textDp(14f)) }
                else Row(
                    Modifier.clip(RoundedCornerShape(50)).background(SurfaceInset).padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RollingNumber(count, TextSecondary, ui.t(12f), fontWeight = FontWeight.SemiBold)
                    Text(" / ${z.count}", color = TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold)
                }
            }
        }
        AnimatedVisibility(
            visible = open,
            enter = expandVertically(NurMotion.gentle()) + fadeIn(NurMotion.gentle()),
            exit = shrinkVertically(NurMotion.snappy()) + fadeOut(NurMotion.snappy())
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = ui.s(16f)).padding(bottom = 14.dp)) {
                ArabicText(z.arabic, if (z.arabic.length > 300) 21f else 24f, align = TextAlign.End, modifier = Modifier.fillMaxWidth())
                if (translit) { Gap(6f); Text(z.translit, color = TextTertiary, fontSize = ui.t(14f), lineHeight = ui.t(20f)) }
                Gap(6f)
                Text(z.ru, color = TextPrimary, fontSize = ui.t(15f), lineHeight = ui.t(21f))
                z.virtue?.let { Gap(6f); Text(it, color = accent, fontSize = ui.t(13f), lineHeight = ui.t(18f)) }
                Gap(4f)
                Text(z.source, color = TextTertiary, fontSize = ui.t(12f))
                if (!finished) {
                    Gap(10f)
                    NurButton(if (z.count == 1) tr("Прочитал") else tr("Прочитал · {0} из {1}", count + 1, z.count), accent, {
                        val last = count + 1 >= z.count
                        scope.launch {
                            nod.snapTo(if (last) 0.96f else 0.985f)
                            nod.animateTo(1f, if (last) NurMotion.bouncy<Float>() else NurMotion.snappy<Float>())
                        }
                        onTap()
                    }, Modifier.fillMaxWidth(), primary = true)
                }
            }
        }
    }
}

// ── dhikr ──────────────────────────────────────────────────────────────────────────────────────

@Composable
fun DhikrScreen(vm: DailyViewModel, palette: PhasePalette, onBack: () -> Unit) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val selectedId by vm.selected.collectAsStateWithLifecycle()
    val today by vm.dhikrToday.collectAsStateWithLifecycle()
    val total by vm.dhikrTotal.collectAsStateWithLifecycle()
    val p = Dhikr.preset(selectedId)
    val count = (today[p.id] ?: 0L).toInt()
    val accent = palette.accent
    val sequence = p.id == Dhikr.AFTER_PRAYER
    val finishedSequence = sequence && count >= TasbihMath.TOTAL
    val rounds = if (sequence) 0 else count / p.target
    val inRound = if (sequence) count else count % p.target
    val fraction = if (sequence) count / TasbihMath.TOTAL.toFloat()
        else if (count > 0 && inRound == 0) 1f else inRound / p.target.toFloat()

    val dhikrScope = rememberCoroutineScope()
    // The circle gives under the finger on every count and lands with a little bounce.
    val pulse = remember { Animatable(1f) }

    fun tap() {
        if (finishedSequence) return
        dhikrScope.launch { pulse.snapTo(0.95f); pulse.animateTo(1f, NurMotion.bouncy()) }
        val n = vm.dhikrTap(p.id).toInt()
        val roundEnd = if (sequence) n == 33 || n == 66 || n == TasbihMath.TOTAL else n % p.target == 0
        haptic.performHapticFeedback(if (roundEnd) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(tr("Зикр"), onBack, Modifier.padding(horizontal = ui.s(16f))) {
            Tag(tr("сегодня {0}", today.values.sum()))
        }
        LazyRow(contentPadding = PaddingValues(horizontal = ui.s(16f)), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(Dhikr.PRESETS, key = { it.id }) { d ->
                val c = today[d.id] ?: 0L
                Chip(if (c > 0) "${d.title} · $c" else d.title, d.id == p.id, accent) { vm.select(d.id) }
            }
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = ui.s(20f)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Gap(14f)
            if (sequence) {
                val (phase, inPhase) = TasbihMath.phase(count)
                ArabicText(TasbihMath.arabic(phase), 34f)
                Text(TasbihMath.reading(phase), color = TextSecondary, fontSize = ui.t(15f))
                Gap(6f)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (0..2).forEach { i ->
                        val done = i < phase || finishedSequence
                        // A finished phase keeps its count next to the seal: «33» tells which one it was.
                        if (done) Tag("${TasbihMath.size(i)}", color = Mint) { DoneSeal(Mint, textDp(14f), animate = false) }
                        else Tag(if (i == phase) "$inPhase/${TasbihMath.size(i)}" else "${TasbihMath.size(i)}", color = if (i == phase) TextPrimary else TextTertiary)
                    }
                }
            } else {
                ArabicText(p.arabic, if (p.arabic.length > 24) 26f else 34f)
                Text(p.translit, color = TextSecondary, fontSize = ui.t(15f), textAlign = TextAlign.Center)
                Text(p.ru, color = TextTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center)
            }
            Gap(18f)
            val interaction = remember { MutableInteractionSource() }
            Box(
                Modifier.size(260.dp).graphicsLayer { scaleX = pulse.value; scaleY = pulse.value }.clip(CircleShape)
                    .clickable(interactionSource = interaction, indication = androidx.compose.material3.ripple(), enabled = !finishedSequence) { tap() },
                contentAlignment = Alignment.Center
            ) {
                Ring(fraction, if (finishedSequence) Mint else accent, 260.dp, 14.dp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    // The count rolls with every tap; the check mark of a finished sequence pops in.
                    AnimatedContent(
                        targetState = finishedSequence,
                        transitionSpec = { (scaleIn(NurMotion.bouncy(), initialScale = 0.5f) + fadeIn(tween(140))) togetherWith fadeOut(tween(90)) },
                        contentAlignment = Alignment.Center,
                        label = "dhikrDone"
                    ) { f ->
                        if (f) DoneSeal(Mint, textDp(64f))
                        else RollingNumber(if (sequence) TasbihMath.phase(count).second else inRound, TextPrimary, ui.t(64f))
                    }
                    Text(
                        when {
                            finishedSequence -> tr("100 из 100")
                            sequence -> tr("из {0} · всего {1}", TasbihMath.size(TasbihMath.phase(count).first), count)
                            else -> tr("из {0}", p.target) + if (rounds > 0) tr(" · кругов {0}", rounds) else ""
                        },
                        color = TextSecondary, fontSize = ui.t(13f)
                    )
                }
            }
            Gap(8f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("Нажимайте на круг"), color = TextTertiary, fontSize = ui.t(12f))
                if (count > 0) {
                    HGap(12f)
                    // A slip of the finger is taken back without resetting the whole day.
                    Text("−1", color = TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.Bold,
                        modifier = Modifier.pressClick(shape = RoundedCornerShape(50)) { vm.dhikrUndo(p.id) }
                            .background(SurfaceRaised).padding(horizontal = 12.dp, vertical = 6.dp))
                }
            }
            Gap(14f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Fact(tr("сегодня"), count.toLong(), Modifier.weight(1f))
                Fact(tr("за всё время"), total[p.id] ?: 0L, Modifier.weight(1f))
            }
            Gap(12f)
            GlassCard(corner = 18.dp) {
                Column(Modifier.fillMaxWidth().padding(ui.s(14f))) {
                    Text(p.virtue, color = TextPrimary, fontSize = ui.t(14f), lineHeight = ui.t(20f))
                    Gap(4f)
                    Text(p.source, color = TextTertiary, fontSize = ui.t(12f))
                }
            }
            Gap(10f)
            NurButton(tr("Сбросить счёт за сегодня"), accent, { vm.dhikrReset(p.id) }, Modifier.fillMaxWidth())
            Gap(10f)
            Box(Modifier.height(LocalDockInset.current))
        }
    }
}

@Composable
private fun Fact(label: String, value: Long, modifier: Modifier) {
    val ui = uiScale()
    GlassCard(modifier, corner = 18.dp) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            RollingNumber(value, TextPrimary, ui.t(22f))
            Text(label, color = TextTertiary, fontSize = ui.t(12f))
        }
    }
}

/** Selection fades between chips instead of jumping. */
@Composable
internal fun chipBg(selected: Boolean, accent: Color): Color {
    val c by animateColorAsState(if (selected) accent.copy(alpha = 0.35f) else SurfaceRaised, tween(180), label = "chip")
    return c
}

@Composable
internal fun Chip(text: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val ui = uiScale()
    Text(
        text, color = if (selected) TextPrimary else TextSecondary, fontSize = ui.t(13f), fontWeight = FontWeight.SemiBold,
        modifier = Modifier.pressClick(shape = RoundedCornerShape(50), onClick = onClick)
            .background(chipBg(selected, accent)).padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

// ── story of the day ───────────────────────────────────────────────────────────────────────────

/**
 * Stories, the familiar way. Segments on top fill with time (longer text, longer slide); a short
 * tap on the right goes on, on the left goes back; a hold pauses and hides the chrome, and letting
 * go resumes from the same point (0.10.0 skipped to the next slide here, see [StoryMath]).
 * Swipe left/right changes the slide, pull down closes, following the finger.
 */
@Composable
fun StoryScreen(
    slides: List<StorySlide>,
    start: Int,
    opening: Int,
    accent: Color,
    onSeen: (Int) -> Unit,
    onClose: () -> Unit
) {
    val ui = uiScale()
    if (slides.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    var index by rememberSaveable(opening) { mutableIntStateOf(start.coerceIn(0, slides.lastIndex)) }
    var restart by remember(opening) { mutableIntStateOf(0) }
    var held by remember { mutableStateOf(false) }
    var chromeHidden by remember { mutableStateOf(false) }
    var forward by remember { mutableStateOf(true) }
    val safeIndex = index.coerceIn(0, slides.lastIndex)
    val slide = slides[safeIndex]
    val duration = remember(slide) { StoryMath.durationMillis(slide) }
    val progress = remember(opening, safeIndex, restart) { Animatable(0f) }
    val dragY = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val swipePx = with(density) { 56.dp.toPx() }
    val closePx = with(density) { 120.dp.toPx() }
    val voiceStatus = com.nur.prayer.ui.learn.rememberVoiceStatus()
    val latestClose by rememberUpdatedState(onClose)
    // Closing starts an exit animation during which this screen is still alive: the timer or a
    // second gesture must not pop the back stack twice.
    var closed by remember(opening) { mutableStateOf(false) }
    fun closeOnce() { if (!closed) { closed = true; latestClose() } }

    fun go(delta: Int) {
        if (closed) return
        // Read the state, not safeIndex: the gesture handler below is keyed on (opening, size)
        // and keeps the closure of its first composition, where safeIndex is frozen.
        val n = index.coerceIn(0, slides.lastIndex) + delta
        when {
            n < 0 -> restart++
            n > slides.lastIndex -> closeOnce()
            else -> { forward = delta > 0; index = n }
        }
    }

    BackHandler { closeOnce() }
    LaunchedEffect(safeIndex, opening) { onSeen(safeIndex) }
    // The hold hides the chrome only after a beat, so a quick tap does not blink it.
    LaunchedEffect(held) {
        if (held) { delay(StoryMath.TAP_MAX_MILLIS); chromeHidden = true } else chromeHidden = false
    }
    LaunchedEffect(progress, held) {
        if (held || closed) return@LaunchedEffect
        val left = (1f - progress.value).coerceIn(0f, 1f)
        if (left > 0f) progress.animateTo(1f, tween((duration * left).toInt().coerceAtLeast(1), easing = LinearEasing))
        go(1)
    }
    val chromeAlpha by animateFloatAsState(if (chromeHidden) 0f else 1f, tween(180), label = "storyChrome")

    Box(
        Modifier.fillMaxSize()
            .graphicsLayer {
                val d = dragY.value.coerceAtLeast(0f)
                val k = if (size.height > 0f) (d / size.height).coerceIn(0f, 1f) else 0f
                translationY = d
                scaleX = 1f - 0.08f * k
                scaleY = 1f - 0.08f * k
                alpha = 1f - 0.4f * k
            }
            .clip(RoundedCornerShape(if (dragY.value > 1f) 28.dp else 0.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF0B1030), accent.copy(alpha = 0.45f), Color(0xFF0B1030))))
    ) {
        // Gesture layer with the slide itself. The chrome above is a sibling, so the close and
        // speaker buttons take their own touches and never reach this layer.
        Box(
            Modifier.fillMaxSize().pointerInput(opening, slides.size) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val t0 = down.uptimeMillis
                    val x0 = down.position.x
                    var dx = 0f
                    var dy = 0f
                    var upTime = t0 + 60_000L
                    held = true
                    var pressing = true
                    while (pressing) {
                        val ev = awaitPointerEvent()
                        val c = ev.changes.firstOrNull { it.id == down.id }
                        when {
                            c == null -> pressing = false
                            !c.pressed -> { upTime = c.uptimeMillis; pressing = false }
                            else -> {
                                val d = c.positionChange()
                                dx += d.x
                                dy += d.y
                                c.consume()
                                if (dy > 0f && dy > abs(dx)) { val y = dy; scope.launch { dragY.snapTo(y) } }
                            }
                        }
                    }
                    held = false
                    val g = StoryMath.classify(upTime - t0, dx, dy, x0, size.width.toFloat(), swipePx, closePx)
                    when (g) {
                        StoryMath.Gesture.CLOSE -> closeOnce()
                        StoryMath.Gesture.NEXT -> go(1)
                        StoryMath.Gesture.PREV -> go(-1)
                        StoryMath.Gesture.NONE -> {}
                    }
                    if (g != StoryMath.Gesture.CLOSE) scope.launch { dragY.animateTo(0f, NurMotion.gentle()) }
                }
            }
        ) {
            AnimatedContent(
                targetState = safeIndex,
                transitionSpec = {
                    val dir = if (forward) 1 else -1
                    (slideInHorizontally(NurMotion.gentle()) { w -> dir * w / 5 } + fadeIn(tween(220)) +
                        scaleIn(NurMotion.gentle(), initialScale = 0.96f)) togetherWith
                        (slideOutHorizontally(NurMotion.gentle()) { w -> -dir * w / 5 } + fadeOut(tween(160)))
                },
                label = "storySlide",
                modifier = Modifier.fillMaxSize()
            ) { i ->
                StorySlideBody(slides[i.coerceIn(0, slides.lastIndex)], accent)
            }
        }
        Column(Modifier.fillMaxWidth().graphicsLayer { alpha = chromeAlpha }.padding(horizontal = ui.s(16f)).padding(top = 10.dp)) {
            Canvas(Modifier.fillMaxWidth().height(3.dp)) {
                val n = slides.size
                val gap = 4.dp.toPx()
                val w = (size.width - gap * (n - 1)) / n
                val r = CornerRadius(size.height / 2f)
                for (s in 0 until n) {
                    val x = s * (w + gap)
                    drawRoundRect(Color(0x47FFFFFF), Offset(x, 0f), Size(w, size.height), r)
                    val f = when { s < safeIndex -> 1f; s == safeIndex -> progress.value; else -> 0f }
                    if (f > 0f) drawRoundRect(Color.White, Offset(x, 0f), Size(w * f, size.height), r)
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("История дня"), color = TextPrimary, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
                    Text(tr("{0} · {1} из {2}", tr(slide.kind), safeIndex + 1, slides.size), color = TextTertiary, fontSize = ui.t(12f))
                }
                val word = slide.arabic
                if (slide.kind == WORD_KIND && slide.voiced && word != null) {
                    com.nur.prayer.ui.learn.SpeakButton(word, voiceStatus, size = 40.dp)
                    HGap(8f)
                }
                RoundIconButton(GlyphKind.CLOSE, tr("Закрыть"), { closeOnce() }, size = 40.dp)
            }
        }
        // 0.13.0: the gesture legend under the story is gone — the gestures are the platform's own
        // and the line competed with the text of the slide.
    }
}

/** The word of the day is the only slide the synthesiser may read: no Quran, hadith or dua by machine voice. */
internal const val WORD_KIND = "Слово дня"

@Composable
private fun StorySlideBody(slide: StorySlide, accent: Color) {
    val ui = uiScale()
    Column(
        Modifier.fillMaxSize().padding(horizontal = ui.s(20f)).padding(top = 80.dp, bottom = 56.dp)
            .verticalScroll(rememberScrollState(), enabled = false),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(tr(slide.kind).uppercase(), color = accent, fontSize = ui.t(13f), fontWeight = FontWeight.Bold, letterSpacing = ui.t(1f))
        Gap(14f)
        slide.arabic?.let { ArabicText(it, if (it.length > 60) 26f else 38f); Gap(10f) }
        slide.translit?.let { Text(it, color = TextSecondary, fontSize = ui.t(15f), textAlign = TextAlign.Center, lineHeight = ui.t(21f)); Gap(10f) }
        Text(slide.ru, color = TextPrimary, fontSize = ui.t(if (slide.arabic == null) 24f else 19f), fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center, lineHeight = ui.t(if (slide.arabic == null) 32f else 26f))
        Gap(12f)
        Text(slide.source, color = TextTertiary, fontSize = ui.t(13f), textAlign = TextAlign.Center)
        slide.note?.let {
            Gap(18f)
            Text(it, color = TextSecondary, fontSize = ui.t(14f), textAlign = TextAlign.Center,
                modifier = Modifier.clip(RoundedCornerShape(16.dp)).background(SurfaceInset).padding(12.dp))
        }
    }
}
