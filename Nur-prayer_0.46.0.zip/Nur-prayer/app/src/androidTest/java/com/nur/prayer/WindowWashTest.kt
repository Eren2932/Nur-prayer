package com.nur.prayer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toPixelMap
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.ui.home.compactHomeScrim
import com.nur.prayer.ui.theme.paletteFor
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.ui.wallpaper.WallpaperCatalog
import com.nur.prayer.ui.wallpaper.deedsWindowWash
import kotlin.math.abs
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class WindowWashTest {
    @get:Rule val compose = createComposeRule()

    @Test fun compactScrimTamesWhiteHighlightsButClearsOutsideHome() {
        val k = mutableFloatStateOf(1f)
        compose.setContent {
            Box(Modifier.size(160.dp, 320.dp).testTag("wash").compactHomeScrim(WallpaperCatalog.Sky,
                paletteFor(Prayer.ISHA)) { k.floatValue }.background(Color.White))
        }
        val node = compose.onNodeWithTag("wash")
        val p = node.captureToImage().toPixelMap()
        val x = p.width / 2
        assertTrue(p[x, p.height / 2].red in 0.26f..0.30f)
        // Sweep the whole lower band, not just the bottom pixel: a white highlight under
        // the upper edge of a dock ring is the worst case, especially with 3-button navigation.
        for (y in (p.height * 0.72f).toInt() until p.height) {
            assertTrue("bright band at y=$y", p[x, y].red <= 0.53f)
        }
        assertTrue(p[x, 2].red > 0.98f)
        assertTrue(p[x, p.height - 2].red in 0.49f..0.54f)
        compose.runOnIdle { k.floatValue = 0f }
        assertTrue(node.captureToImage().toPixelMap()[x, p.height / 2].red > 0.98f)
    }

    @Test fun photoHeaderHasOneExposureAndLeavesNoResidueOnHome() {
        val k = mutableFloatStateOf(1f)
        compose.setContent {
            Box(Modifier.size(160.dp, 320.dp).testTag("wash").deedsWindowWash(true) { k.floatValue }
                .background(Color.White))
        }
        val node = compose.onNodeWithTag("wash")
        val pixels = node.captureToImage().toPixelMap()
        val x = pixels.width / 2
        val upper = pixels[x, 1]; val title = pixels[x, pixels.height / 4]
        assertTrue(upper.red > .84f && upper.red < .94f && abs(upper.red - title.red) < .01f)
        assertTrue(abs(upper.green - title.green) < .01f && abs(upper.blue - title.blue) < .01f)
        compose.runOnIdle { k.floatValue = 0f }
        val home = node.captureToImage().toPixelMap()
        assertTrue(home[x, 1].green > .99f && home[x, home.height - 2].green > .99f)
    }

    @Test fun nonPhotoHeaderDoesNotAddAnyShadow() {
        compose.setContent {
            Box(Modifier.size(160.dp, 320.dp).testTag("wash").deedsWindowWash(false) { 1f }.background(Color.White))
        }
        val pixels = compose.onNodeWithTag("wash").captureToImage().toPixelMap()
        assertTrue(pixels[pixels.width / 2, 2].red > .99f)
        assertTrue(pixels[pixels.width / 2, pixels.height - 2].red < .85f)
    }
}
