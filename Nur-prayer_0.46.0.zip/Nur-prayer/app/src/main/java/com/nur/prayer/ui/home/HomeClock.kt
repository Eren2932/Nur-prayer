package com.nur.prayer.ui.home

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerWindow
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime

/* Only these leaves consume the home clock. The center, its animated slots and the day list
 * receive the window already computed by the ViewModel, never a second ticker of their own. */

/**
 * «2:01:34»: the countdown to [next], in the size a layout asks for. The text changes width only
 * when the last hour starts (1:00:00 → 59:59): resizeKey follows that.
 */
@Composable
internal fun HomeCountdown(
    data: PrayerData,
    now: State<ZonedDateTime>,
    next: Prayer,
    fontSize: Float,
    minFontSize: Float,
    weight: FontWeight,
    spacing: Float,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val text = Format.countdown(data.window.remaining(now.value))
    AutoSizeText(
        text, color = TextPrimary, fontSize = ui.t(fontSize), minFontSize = ui.t(minFontSize),
        fontWeight = weight, textAlign = TextAlign.Center, letterSpacing = ui.t(spacing),
        resizeKey = text.length,
        modifier = modifier.clearAndSetSemantics {
            contentDescription = tr("До {0}: {1}", PrayerLabels.title(next), text)
        }
    )
}

/** How far through the window going on now, in thousandths: a bar a few hundred dp long moves by a pixel, not by a second. */
@Composable
internal fun rememberWindowProgress(now: State<ZonedDateTime>, window: PrayerWindow): State<Float> =
    remember(now, window) {
        derivedStateOf { (window.progress(now.value) * PROGRESS_STEPS).toInt() / PROGRESS_STEPS }
    }

/** The minute of the clock, as epoch minutes: the timeline's bubble and its line move once a minute. */
@Composable
internal fun rememberClockMinute(now: State<ZonedDateTime>): State<Long> =
    remember(now) { derivedStateOf { Math.floorDiv(now.value.toEpochSecond(), 60L) } }

/** «12:12»: the clock's minute as text. Same idea: the clock ticks, the reader recomposes once a minute. */
@Composable
internal fun rememberClockStamp(now: State<ZonedDateTime>): State<String> =
    remember(now) { derivedStateOf { Format.time(now.value) } }

private const val PROGRESS_STEPS = 1000f
