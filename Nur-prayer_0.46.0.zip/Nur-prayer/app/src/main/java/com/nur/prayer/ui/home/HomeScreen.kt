package com.nur.prayer.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.HomeLayout
import com.nur.prayer.i18n.tr
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.shell.CapsuleRoom
import com.nur.prayer.ui.shell.PanelTimes
import com.nur.prayer.ui.shell.ShellGlyph
import com.nur.prayer.ui.shell.ShellIcon
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime

/**
 * 0.30.2: the city and the hijri date stand 3 dp higher (8 → 5). The tap target keeps its 48 dp, only the row
 * starts closer to the status bar.
 */
private val HEADER_TOP = 5.dp

@Composable
fun HomeScreen(
    data: PrayerData,
    now: State<ZonedDateTime>,
    onSetNotification: (Prayer, Boolean) -> Unit,
    onOpenCity: () -> Unit,
    /** The chip of a feast or a fast: the month calendar, opened plainly. */
    onOpenSchedule: () -> Unit,
    /** A time on the screen: its sheet. */
    onOpenPrayer: (Prayer) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val next = HomeTimeline.next(data.window, data.fajrEqualsDawn)
    val prayers = PanelTimes.PRAYERS

    val compact = data.settings.homeLayout == HomeLayout.CARDS
    var dayOpen by rememberSaveable(compact) { mutableStateOf(false) }
    val surface = if (compact) Modifier.openDayOnSwipe { dayOpen = true } else Modifier
    Column(modifier.fillMaxSize().then(surface)) {
        HomeHeader(data, onOpenCity)
        // 0.19.0: a feast, a night or a fast of the Islamic year, in its colour (nothing on a plain day).
        HomeDayChip(
            data.today.date, data.settings.hijriOffset, onOpen = onOpenSchedule,
            modifier = Modifier.padding(start = ui.s(20f), end = ui.s(20f), top = 8.dp)
        )
        when (data.settings.homeLayout) {
            HomeLayout.CARDS -> CompactHome(data, now, next, { dayOpen = true }, Modifier.weight(1f))
            HomeLayout.BIG -> HomeBig(
                data, now, prayers, next, Modifier, Modifier, onOpenPrayer, Modifier.weight(1f)
            )
        }
        // The capsule floats over this room; nothing of home ever hides under it.
        Spacer(Modifier.fillMaxWidth().navigationBarsPadding().height(CapsuleRoom))
    }
    if (compact && dayOpen) DayScheduleSheet(data, now, prayers, onSetNotification,
        onDismiss = { dayOpen = false }, onDetails = { prayer -> dayOpen = false; onOpenPrayer(prayer) })
}

/** The city and the hijri date on the right: nothing else at the top (0.29.0: the avatar is gone, settings sit in the panel). */
@Composable
private fun HomeHeader(data: PrayerData, onOpenCity: () -> Unit, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val sky = TextStyle(shadow = HomeSpec.OnSky)
    Row(
        modifier.fillMaxWidth().padding(start = ui.s(14f), end = ui.s(12f), top = HEADER_TOP),
        verticalAlignment = Alignment.Top
    ) {
        Spacer(Modifier.weight(1f))
        Column(
            Modifier
                .weight(3f)
                .clip(RoundedCornerShape(14.dp))
                .clickable(role = Role.Button, onClickLabel = tr("Выбрать город"), onClick = onOpenCity)
                .heightIn(min = 48.dp)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.End
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (data.settings.useDeviceLocation) {
                    ShellIcon(ShellGlyph.LOCATE, TextPrimary, Modifier.size(14.dp))
                    Spacer(Modifier.width(8.dp))
                }
                AutoSizeText(
                    data.place.label, color = TextPrimary, fontSize = ui.t(18f), minFontSize = ui.t(13f),
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.End
                )
            }
            Spacer(Modifier.height(2.dp))
            // 0.19.0: on a feast or a fast the hijri date takes the colour of the day.
            val dayTone = remember(data.today.date, data.settings.hijriOffset) {
                com.nur.prayer.data.IslamicDays.primary(data.today.date, data.settings.hijriOffset)
                    ?.takeIf { it.kind == com.nur.prayer.data.DayKind.FEAST || it.kind == com.nur.prayer.data.DayKind.FAST }
                    ?.let { com.nur.prayer.ui.schedule.DayTone.of(it.kind) }
            }
            Text(
                HijriCalendar.format(data.today.date, data.settings.hijriOffset),
                color = dayTone ?: TextPrimary.copy(alpha = 0.88f), fontSize = ui.t(13f), fontWeight = FontWeight.Medium,
                style = sky, maxLines = 1
            )
        }
    }
}

