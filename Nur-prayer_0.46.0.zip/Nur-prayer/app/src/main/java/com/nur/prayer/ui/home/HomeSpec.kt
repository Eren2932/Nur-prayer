package com.nur.prayer.ui.home

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow

/** Shared home tuning. BIG retains its historical baseline measurements on the 393 dp frame.
 * The compact reference is 841 × 1870 px: timer ink at y=734..861, column labels at y=979..994.
 * Its layout uses measured content plus a bias in the space left by the header and dock. */
internal object HomeSpec {
    /** The soft shadow under text that lies straight on the wallpaper. */
    val OnSky = Shadow(Color(0x8C000000), blurRadius = 12f)

    // ---------------------------------------------------------------- shared colours (measured)

    /** The gold of the pill, the progress line and the next node (mock 2: 244, 196, 112). */
    val Gold = Color(0xFFF4C470)

    /** Text and glyphs on gold (mock 2: 34, 24, 10). */
    val OnGold = Color(0xFF22180A)

    object Compact {
        const val SWITCH_MS = 450
        const val SWIPE_DP = 72
        const val BELL_WIDTH = 20f
        const val BELL_HEIGHT = 23.7f
    }

    // ---------------------------------------------------------------- variant 2: the big word

    object Big {
        // type (sp)
        const val KICKER = 14f        // «Следующий намаз», cap 27.5 px
        const val WORD = 92f          // «Зухр», cap 183 px
        const val WORD_MIN = 48f
        const val PILL_TIME = 19.5f   // digits 38 px
        const val COUNT = 50f         // digits 98 px
        const val COUNT_MIN = 36f
        const val CAPTION = 12f       // «до начала»
        const val BUBBLE_TIME = 13f   // digits 25.5 px
        const val NAME = 9.3f         // cap 18 px
        const val STAMP = 10.5f       // digits 20.5 px

        // pill
        const val PILL_WIDTH = 87f    // 240 px
        const val PILL_HEIGHT = 28f   // 78 px (a full stadium)

        // timeline
        const val SIDE = 36f          // 100 px: the first node sits here, the last one mirrors it
        const val LINE = 2.2f         // 6 px
        const val TRACK_ALPHA = 0.28f // white over the picture: (123 − 72) / (255 − 72)
        const val NODE = 9f           // 25 px
        const val NODE_RING = 3f      // 8 px (past: gold ring around a dark dot)
        const val NODE_RING_FUTURE = 1.5f // 4 px
        const val NEXT_NODE = 14f     // 39 px
        const val NEXT_RING = 1.5f    // 4 px, white
        const val BUBBLE_HEIGHT = 22f // 60 px (a full stadium)
        const val BUBBLE_PAD = 8.5f   // 23 px each side of the digits
        const val TAIL_HEIGHT = 6f    // 16 px
        const val TAIL_WIDTH = 7f     // 20 px
        const val LABEL_GAP = 6f      // least air between two neighbouring labels
        const val EDGE = 8f           // the bubble and the labels never come closer to the screen edge

        // The hero, placed by baselines from its top edge (dp): kicker baseline 519 px, word 740 px,
        // pill 842 px (top edge), digits 1092 px, caption 1151 px; the top edge is 14 dp above the kicker's baseline.
        const val KICKER_BASELINE = 14f
        const val WORD_BASELINE = 94.4f
        const val PILL_TOP = 131.5f
        const val COUNT_BASELINE = 222.5f
        const val CAPTION_BASELINE = 244.0f

        /** The caption's box ends 3 dp under its baseline; the bubble starts 49 dp under it (1286 − 1151 px). */
        const val HERO_TO_TIMELINE = 46f

        // The timeline, placed from the top of the bubble (dp): the line's centre is 104 px under it,
        // the names' baseline 168 px (cap top 1438 px + cap height), the times' baseline 214 px.
        const val BUBBLE_TOP = 0f
        const val LINE_Y = 37.8f
        const val NAME_BASELINE = 61.6f
        const val STAMP_BASELINE = 78.2f
        const val TIMELINE_HEIGHT = 82f

        /**
         * Free height above / below the block: the hero starts 195 px (71 dp) under the header and the
         * timeline ends 638 px (232 dp) above the capsule's room.
         */
        const val WEIGHT_TOP = 71f
        const val WEIGHT_BOTTOM = 232f

        val NodeInk = HomeSpec.OnGold
        val FutureFill = Color(0xFF1E1E28)
        val FutureRing = Color(0xFFC8C8CA)
    }
}
