package com.nur.prayer.ui.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.theme.uiScale
import java.time.ZonedDateTime

/** An occurrence, not a ticking clock. Outgoing content retains its own title AND time. */
private data class Stamp(val prayer: Prayer, val start: ZonedDateTime)

@Composable
internal fun CompactHome(data: PrayerData, now: State<ZonedDateTime>, next: Prayer, onDay: () -> Unit, modifier: Modifier) {
    val ui = uiScale()
    val w = data.window
    BoxWithConstraints(modifier.fillMaxWidth().testTag("home-center"), contentAlignment = BiasAlignment(0f, 0.10f)) {
        val short = maxHeight < 300.dp
        // A very short split-screen can scroll the content rather than scale its touch targets.
        val overflow = if (maxHeight < 240.dp) Modifier.verticalScroll(rememberScrollState()) else Modifier
        Column(Modifier.widthIn(max = 460.dp).fillMaxWidth().then(overflow)
            .padding(horizontal = if (ui.systemFontScale > 1.2f) 8.dp else ui.s(18f)),
            horizontalAlignment = Alignment.CenterHorizontally) {
            AutoSizeText(tr("{0} через", PrayerLabels.title(next)), color = Color.White.copy(alpha = 0.72f),
                fontSize = ui.t(18f), fontWeight = FontWeight.Medium)
            CompositionLocalProvider(LocalTextStyle provides LocalTextStyle.current.copy(fontFeatureSettings = "tnum", lineHeight = TextUnit.Unspecified)) {
                HomeCountdown(data, now, next, if (short) 54f else 82f, 34f, FontWeight.Bold, -1.8f, Modifier.fillMaxWidth())
                Spacer(Modifier.height(if (short) 4.dp else ui.s(30f)))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Row(Modifier.fillMaxWidth()) {
                        StampColumn(Stamp(HomeTimeline.current(w, data.fajrEqualsDawn), w.currentStart), false, Modifier.weight(1f))
                        StampColumn(Stamp(next, w.nextStart), true, Modifier.weight(1f))
                    }
                    // Match the measured text row, not the outer screen or a guessed dp height.
                    Box(Modifier.matchParentSize(), contentAlignment = Alignment.Center) {
                        Spacer(Modifier.width(1.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.24f)))
                    }
                }
            }
            Spacer(Modifier.height(if (short) 4.dp else ui.s(18f)))
            ScheduleButton(onDay)
        }
    }
}

@Composable
private fun StampColumn(stamp: Stamp, next: Boolean, modifier: Modifier) {
    val ui = uiScale()
    Column(modifier.padding(horizontal = if (ui.systemFontScale > 1.2f) 4.dp else 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        val caption = if (next) tr("Далее") else tr("Сейчас")
        AutoSizeText(caption.uppercase(L10n.language.locale), color = Color.White.copy(alpha = if (next) 0.85f else 0.62f),
            fontSize = ui.t(11f), letterSpacing = 1.6.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        val ms = HomeSpec.Compact.SWITCH_MS
        AnimatedContent(targetState = stamp, contentKey = { it.prayer }, label = "prayer-window",
            modifier = Modifier.fillMaxWidth().clipToBounds(), contentAlignment = Alignment.Center,
            transitionSpec = {
                val enter = slideInVertically(tween(ms, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(ms, easing = FastOutSlowInEasing))
                val exit = slideOutVertically(tween(ms, easing = FastOutSlowInEasing)) { -it } + fadeOut(tween(ms, easing = FastOutSlowInEasing))
                (enter togetherWith exit).using(null)
            }) { item ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                AutoSizeText(PrayerLabels.title(item.prayer), color = Color.White.copy(alpha = if (next) 1f else 0.88f),
                    fontSize = ui.t(23f), minFontSize = ui.t(13f), maxLines = 1, textAlign = TextAlign.Center,
                    fontWeight = if (next) FontWeight.SemiBold else FontWeight.Medium)
                AutoSizeText(Format.time(item.start), color = Color.White.copy(alpha = if (next) 1f else 0.75f),
                    fontSize = ui.t(23f), fontWeight = if (next) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
    }
}

@Composable
private fun ScheduleButton(onDay: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(Modifier.clip(shape).clickable(role = Role.Button, onClick = onDay).heightIn(min = 48.dp),
        contentAlignment = Alignment.Center) {
        Row(Modifier.heightIn(min = 44.dp).background(Color.Black.copy(alpha = 0.28f), shape)
            .border(1.dp, Color.White.copy(alpha = 0.22f), shape).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(tr("Расписание дня"), color = Color.White.copy(alpha = 0.90f), fontSize = 14.sp,
                fontWeight = FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.width(8.dp))
            Glyph(GlyphKind.CHEVRON, Color.White, Modifier.size(14.dp).rotate(
                if (LocalLayoutDirection.current == LayoutDirection.Rtl) -90f else 90f))
        }
    }
}
