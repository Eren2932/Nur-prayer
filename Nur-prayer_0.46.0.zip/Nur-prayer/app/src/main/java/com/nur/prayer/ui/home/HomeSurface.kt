package com.nur.prayer.ui.home

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.wallpaper.Wallpaper
import kotlin.math.abs

/** Draw AFTER the actual wallpaper but BEFORE any controls. A crop's existing contrast map uses a
 * percentile: an isolated bright lantern can still land exactly under a letter. A neutral darken
 * blend compresses only channels above the knee; a dark sky is not tinted. No bitmap readback.
 * At full strength even a white highlight is capped at 0.28 sRGB in the reading band, enough for
 * the quiet 62%-white caption. A softer knee protects the existing 90%-white dock outlines. */
internal fun Modifier.compactHomeScrim(wallpaper: Wallpaper, palette: PhasePalette, amount: () -> Float): Modifier = drawWithCache {
    val strength = when (wallpaper.kind) {
        Wallpaper.Kind.IMAGE -> if (wallpaper.light) 0.40f else 0.36f
        Wallpaper.Kind.SKY -> 0.28f + 0.12f * (palette.mid.luminance() * 4f).coerceIn(0f, 1f)
        Wallpaper.Kind.AMOLED -> 0.28f
    }
    val center = Color.Black.copy(alpha = strength)
    val guardAlpha = 0.90f
    val knee = (0.28f / (1f - strength) - (1f - guardAlpha)) / guardAlpha
    val highlight = Color(knee, knee, knee, guardAlpha)
    val clear = highlight.copy(alpha = 0f)
    // A bright stripe can fall just above the bottom fade, under a ring on a short display.
    // Limit only bright channels there. At the bottom edge the 50% black wash suffices by itself.
    val dock = Color(0.46f, 0.46f, 0.46f, guardAlpha)
    val guard = Brush.verticalGradient(0.12f to clear, 0.32f to highlight, 0.72f to highlight,
        0.83f to dock, 0.95f to dock, 1f to dock.copy(alpha = 0f))
    val wash = Brush.verticalGradient(0.12f to Color.Transparent, 0.32f to center, 0.72f to center,
        0.83f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.50f))
    onDrawWithContent {
        drawContent()
        val a = amount().coerceIn(0f, 1f)
        if (a > 0f) {
            if (wallpaper.kind != Wallpaper.Kind.AMOLED) drawRect(guard, alpha = a, blendMode = BlendMode.Darken)
            drawRect(wash, alpha = a)
        }
    }
}

/** Observe only unclaimed downs. A city/chip/button owns its own press. A free drag is claimed
 * only after it crosses the threshold; horizontal, downward and multitouch gestures do nothing. */
@Composable
internal fun Modifier.openDayOnSwipe(openDay: () -> Unit): Modifier {
    val open by rememberUpdatedState(openDay)
    val haptic = LocalHapticFeedback.current
    return pointerInput(haptic) {
        val threshold = HomeSpec.Compact.SWIPE_DP.dp.toPx()
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            if (down.isConsumed) return@awaitEachGesture
            while (true) {
                val change = awaitPointerEvent().changes.singleOrNull() ?: break
                if (!change.pressed || change.id != down.id || change.isConsumed) break
                val d = change.position - down.position
                if (d.y > viewConfiguration.touchSlop || abs(d.x) > maxOf(viewConfiguration.touchSlop, -d.y)) break
                if (-d.y >= threshold && -d.y > abs(d.x) * 1.3f) {
                    change.consume()
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    open()
                    break
                }
            }
        }
    }
}
