package com.nur.prayer.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.i18n.tr
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.components.AutoSizeText
import kotlinx.coroutines.launch
import java.time.ZonedDateTime

private val SheetMatte = Color(0xFF171920)
private val NextMatte = Color(0xFFF2F0EC)
private val DarkInk = Color(0xFF191A1D)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun DayScheduleSheet(data: PrayerData, now: State<ZonedDateTime>, prayers: List<Prayer>,
    onSetNotification: (Prayer, Boolean) -> Unit, onDismiss: () -> Unit, onDetails: (Prayer) -> Unit) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet, containerColor = SheetMatte,
        contentColor = Color.White, tonalElevation = 0.dp,
        contentWindowInsets = { WindowInsets.safeDrawing },
        dragHandle = { BottomSheetDefaults.DragHandle(color = Color.White.copy(alpha = 0.45f)) }) {
        LazyColumn(Modifier.fillMaxWidth().testTag("home-day-sheet"), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)) {
            item(key = "heading") {
                Column(Modifier.padding(start = 10.dp, end = 10.dp, bottom = 10.dp)) {
                    Text(tr("Расписание дня"), fontSize = 24.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.semantics { heading() })
                    Text("${Format.fullDate(data.today.date)} · ${data.place.label}", fontSize = 16.sp,
                        color = Color.White.copy(alpha = 0.84f))
                    // After Isha, or for a separate suhoor, the next event may be outside today's six.
                    // Tell the reader which event is next without marking an unrelated row as next.
                    val next = HomeTimeline.next(data.window, data.fajrEqualsDawn)
                    if (next !in prayers || data.today.times[next]?.isEqual(data.window.nextStart) != true) {
                        val start = data.window.nextStart
                        val date = if (start.toLocalDate() == data.today.date) "" else " · ${Format.dayMonth(start.toLocalDate())}"
                        Text(tr("Следующий: {0}, в {1}", PrayerLabels.title(next), Format.time(start)) + date,
                            fontSize = 15.sp, color = Color.White)
                    }
                }
            }
            items(prayers, key = { it.name }) { prayer ->
                DayScheduleRow(data, now, prayer, onSetNotification) {
                    scope.launch {
                        sheet.hide()
                        if (!sheet.isVisible) onDetails(prayer)
                    }
                }
            }
        }
    }
}

@Composable
private fun DayScheduleRow(data: PrayerData, now: State<ZonedDateTime>, prayer: Prayer,
    onSetNotification: (Prayer, Boolean) -> Unit, onDetails: () -> Unit) {
    val state = HomeMath.dayRowState(prayer, data.window, data.today, data.fajrEqualsDawn)
    val checked = data.settings.notifications[prayer] == true
    val title = PrayerLabels.title(prayer)
    val time = data.today.times[prayer]?.let(Format::time) ?: "—"
    val ink = when (state) {
        RowState.NEXT -> DarkInk
        RowState.PAST -> Color.White.copy(alpha = 0.73f)
        else -> Color.White
    }
    val label = when (state) {
        RowState.CURRENT -> tr("Сейчас")
        RowState.NEXT -> tr("Далее")
        else -> null
    }
    val shape = RoundedCornerShape(14.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(if (state == RowState.NEXT) NextMatte else Color.Transparent)
        .padding(end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).clickable(role = Role.Button, onClickLabel = tr("Подробнее"), onClick = onDetails)
            .heightIn(min = 54.dp).padding(start = 12.dp, end = 8.dp, top = 4.dp, bottom = 4.dp)
            .semantics { if (label != null) stateDescription = label }, verticalArrangement = Arrangement.Center) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AutoSizeText(title, ink, 20.sp, Modifier.weight(1f), minFontSize = 14.sp,
                    fontWeight = if (state == RowState.NEXT) FontWeight.SemiBold else FontWeight.Medium)
                Spacer(Modifier.width(8.dp))
                Text(time, color = ink, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
            if (state == RowState.CURRENT) {
                val progress = rememberWindowProgress(now, data.window)
                Spacer(Modifier.padding(top = 4.dp).fillMaxWidth().height(2.dp).drawBehind {
                    drawRect(Color.White.copy(alpha = 0.18f))
                    drawRect(Color.White, size = Size(size.width * progress.value, size.height))
                })
            }
        }
        // Same per-event preference as PrayerSheet, including Sunrise. No shadow copy of the switch.
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(50)).toggleable(value = checked, role = Role.Switch,
            onValueChange = { onSetNotification(prayer, it) }).semantics {
                contentDescription = "${tr("Уведомление")} · $title"
            }, contentAlignment = Alignment.Center) {
            BellGlyph(HomeMath.bellState(checked, state), ink, ink,
                Modifier.size(HomeSpec.Compact.BELL_WIDTH.dp, HomeSpec.Compact.BELL_HEIGHT.dp))
        }
    }
}
