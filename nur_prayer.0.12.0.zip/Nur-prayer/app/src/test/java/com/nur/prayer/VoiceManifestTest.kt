package com.nur.prayer

import com.nur.prayer.audio.VoiceText
import com.nur.prayer.learn.Arabic
import com.nur.prayer.learn.Exercise
import com.nur.prayer.learn.ExerciseFactory
import com.nur.prayer.learn.LearnContent
import com.nur.prayer.learn.LearnProgress
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * docs/audio/recording_list.tsv (written by tools/audio_manifest.py) must hold exactly what the
 * app can ask the voice to say. Missing: a speaker with no recording planned. Extra: a recording
 * no speaker will ever play. Either way the Python mirror of the course has drifted.
 */
class VoiceManifestTest {
    private fun file(vararg names: String): File = names.map(::File).first { it.exists() }

    private val content by lazy {
        LearnContent.parse(
            file("src/main/assets/${LearnContent.WORDS_ASSET}", "app/src/main/assets/${LearnContent.WORDS_ASSET}").readText(),
            file("src/main/assets/${LearnContent.QURAN_ASSET}", "app/src/main/assets/${LearnContent.QURAN_ASSET}").readText()
        )
    }

    private fun listed(): Set<String> =
        file("../docs/audio/recording_list.tsv", "docs/audio/recording_list.tsv").readLines()
            .filter { it.isNotBlank() && !it.startsWith("#") }
            .map { VoiceText.key(it.substringBefore('\t')) }
            .toSet()

    private fun voicedByApp(): Set<String> {
        val c = content
        val out = LinkedHashSet<String>()
        Arabic.LETTERS.forEach { out += VoiceText.letterSound(it); out += VoiceText.letterName(it) }
        c.lexicon.words.filter { it.machineVoiceAllowed }.forEach { out += it.arabic }
        for (lesson in c.course.lessons) {
            for (seed in 1..6) {
                ExerciseFactory(c.lexicon, c.quran, seed).build(lesson.plan, c.course, LearnProgress(), 0).forEach { ex ->
                    when (ex) {
                        is Exercise.Info -> if (ex.voiced) ex.samples.forEach { out += it.first }
                        is Exercise.LetterIntro -> ex.example?.takeIf { it.machineVoiceAllowed }?.let { out += it.arabic }
                        is Exercise.WordIntro -> if (ex.word.machineVoiceAllowed) out += ex.word.arabic
                        else -> {}
                    }
                }
            }
        }
        return out.map(VoiceText::key).toSet()
    }

    @Test fun recordingListMatchesEverySpeaker() {
        val app = voicedByApp()
        val list = listed()
        val missing = app - list
        val extra = list - app
        assertTrue("not in recording_list.tsv (run tools/audio_manifest.py --write): ${missing.take(10)}", missing.isEmpty())
        assertTrue("in recording_list.tsv but never voiced: ${extra.take(10)}", extra.isEmpty())
    }

    @Test fun quranWordsAreNeverMachineVoiced() {
        val quran = content.lexicon.words.filter { it.topic == "fatiha" || it.topic.startsWith("quran") }
        assertTrue("course has Quran words", quran.isNotEmpty())
        assertTrue(quran.none { it.machineVoiceAllowed })
        val list = listed()
        val leaked = quran.map { VoiceText.key(it.arabic) }.filter { it in list }
            // A Quran word spelled like an everyday word (same letters and marks) is that word.
            .filter { k -> content.lexicon.words.none { it.machineVoiceAllowed && VoiceText.key(it.arabic) == k } }
        assertTrue("Quran words in the recording list: $leaked", leaked.isEmpty())
    }
}
