package com.nur.prayer

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.semantics.getOrNull
import androidx.compose.ui.test.click
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipe
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Before
import com.nur.prayer.ui.home.HomeTimeline
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assert
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performClick
import com.nur.prayer.ui.AppActions
import com.nur.prayer.ui.settings.SettingsScreen
import androidx.compose.ui.test.assertCountEquals
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.distanceToKaabaKm
import com.nur.prayer.core.astro.qiblaBearing
import com.nur.prayer.data.AppSettings
import com.nur.prayer.data.City
import com.nur.prayer.data.HijriCalendar
import com.nur.prayer.data.Place
import com.nur.prayer.notify.PrayerLabels
import com.nur.prayer.ui.Format
import com.nur.prayer.ui.PrayerData
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.qibla.Heading
import com.nur.prayer.ui.qibla.HeadingSource
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Run in the existing API 26 / 34 CI matrix. Authored here, not claimed as locally executed. */
@RunWith(AndroidJUnit4::class)
class ObservatoryScreenTest {
    @get:Rule val compose = createComposeRule()
    private val moment = ZonedDateTime.parse("2026-09-07T21:00:00+03:00[Europe/Moscow]")
    private val actions = AppActions({}, {}, {}, {}, {}, {}, {}, {}, {}, { _, _ -> }, { _, _ -> }, {}, {}, {}, {}, {})

    /** The home face (list / clock) is remembered across launches; every test starts from the list. */
    @Before fun startFromTheList() {
        InstrumentationRegistry.getInstrumentation().targetContext
            .getSharedPreferences("nur_ui", Context.MODE_PRIVATE).edit().clear().commit()
    }

    /** Nodes whose merged description starts with [prefix]: rows say «Зухр, 12:12…», the plate «Следующий: …». */
    private fun described(prefix: String) = SemanticsMatcher("description starts with $prefix") { node ->
        node.config.getOrNull(SemanticsProperties.ContentDescription)?.any { it.startsWith(prefix) } == true
    }

    private fun showHome(
        data: PrayerData,
        opened: MutableList<String> = mutableListOf()
    ) = compose.setContent {
        NurTheme {
            HomeScreen(
                data = data, now = mutableStateOf(moment), palette = paletteFor(Prayer.ISHA), actions = actions,
                notificationsAllowed = true, exactAlarmsAllowed = true,
                onOpenCity = { opened += "city" }, onOpenSchedule = { opened += "schedule" },
                onOpenQibla = { opened += "qibla" }, onOpenSettings = { opened += "settings" }
            )
        }
    }
    private fun fixture(): PrayerData {
        val city = City.MOSCOW
        val settings = AppSettings()
        val params = settings.paramsFor(city.country)
        val place = Place(city.name, city.subtitle, city.country, city.coordinates, city.zone, false)
        return PrayerData(place, PrayerEngine.days(moment.toLocalDate(), 3, city.coordinates, city.zone, params),
            PrayerEngine.window(moment, city.coordinates, city.zone, params), qiblaBearing(city.coordinates),
            distanceToKaabaKm(city.coordinates), HijriCalendar.format(moment.toLocalDate()), settings,
            settings.profileFor(city.country), params)
    }

    @Test fun listFaceShowsEveryRowAndTheNextPlate() {
        val data = fixture()
        showHome(data)
        HomeTimeline.prayers(data.fajrEqualsDawn).forEach {
            compose.onNode(described("${PrayerLabels.title(it)}, ")).assertExists()
        }
        compose.onNode(described("Следующий: ${PrayerLabels.title(HomeTimeline.next(data.window, data.fajrEqualsDawn))}")).assertExists()
        compose.onAllNodes(described("До ")).assertCountEquals(0)
    }

    @Test fun tappingTheSkySwitchesBetweenTheListAndTheClock() {
        val data = fixture()
        showHome(data)
        val clock = "До ${PrayerLabels.title(HomeTimeline.next(data.window, data.fajrEqualsDawn))}: " +
            Format.clock(data.window.remaining(moment))
        // The left edge is outside the card, so the tap lands on the sky itself.
        compose.onRoot().performTouchInput { click(Offset(4f, height / 2f)) }
        compose.waitUntil(5000) { compose.onAllNodesWithContentDescription(clock).fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription(clock).assertIsDisplayed()
        compose.onRoot().performTouchInput { click(Offset(4f, height / 2f)) }
        // Both faces are composed while they cross-fade; the clock leaves the tree when it is gone.
        compose.waitUntil(5000) { compose.onAllNodesWithContentDescription(clock).fetchSemanticsNodes().isEmpty() }
        compose.onNode(described("Следующий: ")).assertExists()
    }

    @Test fun pullingUpFromTheSkyOpensTheCalendarAndAShortSlowDragDoesNot() {
        val opened = mutableListOf<String>()
        showHome(fixture(), opened)
        compose.onRoot().performTouchInput {
            swipe(Offset(4f, height * 0.8f), Offset(4f, height * 0.8f - 24f), durationMillis = 900)
        }
        compose.runOnIdle { assertEquals(emptyList<String>(), opened) }
        compose.onRoot().performTouchInput {
            swipe(Offset(4f, height * 0.8f), Offset(4f, height * 0.3f), durationMillis = 250)
        }
        compose.runOnIdle { assertEquals(listOf("schedule"), opened) }
    }

    @Test fun tappingARowOpensItsSheetAndCloseReturnsToTheList() {
        val data = fixture()
        showHome(data)
        val pages = HomeTimeline.prayers(data.fajrEqualsDawn)
        compose.onNode(described("${PrayerLabels.title(Prayer.DHUHR)}, ")).performClick()
        compose.waitUntil(5000) { compose.onAllNodesWithText("Завтра").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithContentDescription("Страница ${HomeTimeline.pageOf(Prayer.DHUHR, data.fajrEqualsDawn) + 1} из ${pages.size}")
            .assertExists()
        compose.onNodeWithContentDescription("Закрыть").performClick()
        compose.waitUntil(5000) { compose.onAllNodesWithText("Завтра").fetchSemanticsNodes().isEmpty() }
        compose.onNode(described("${PrayerLabels.title(Prayer.DHUHR)}, ")).assertExists()
    }

    @Test fun homeButtonsDispatchTheirDestinations() {
        val opened = mutableListOf<String>()
        showHome(fixture(), opened)
        compose.onNodeWithContentDescription("Кыбла").performClick()
        compose.onNodeWithContentDescription("Настройки").performClick()
        compose.onNodeWithText("КАЛЕНДАРЬ").performClick()
        compose.runOnIdle { assertEquals(listOf("qibla", "settings", "schedule"), opened) }
    }

    @Test fun unavailableSensorCannotShowDirectionFound() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading()) } }
        compose.onNodeWithText("Компас недоступен").assertIsDisplayed()
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Нет достоверного направления"))
        compose.onNodeWithContentDescription("Кааба — направление кыблы").assertIsDisplayed()
    }
    @Test fun magneticInterferenceCannotReportLockEvenAtTargetAzimuth() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 110f, source = HeadingSource.FUSED)) } }
        compose.onNodeWithText("Проверьте калибровку и помехи").assertIsDisplayed()
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Нет достоверного направления"))
    }
    @Test fun alignedCalibratedFlatSensorShowsLock() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 45f, source = HeadingSource.FUSED)) } }
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Направление найдено"))
        compose.onNodeWithText("Направление на Каабу").assertIsDisplayed()
    }
    @Test fun tiltedSensorCannotShowLock() {
        val data = fixture()
        compose.setContent { NurTheme { QiblaScreen(data, paletteFor(Prayer.ISHA), headingOverride = Heading(
            azimuth = data.qibla.toFloat(), accuracy = 3, fieldStrength = 45f, tiltDegrees = 60f, source = HeadingSource.FUSED)) } }
        compose.onNodeWithTag("qibla-instrument").assert(SemanticsMatcher.expectValue(
            SemanticsProperties.StateDescription, "Нет достоверного направления"))
        compose.onNodeWithText("Положите телефон горизонтально").assertIsDisplayed()
    }
    @Test fun homeDoesNotDisplayDecorativeCopy() {
        showHome(fixture())
        compose.onNodeWithText("Время для главного").assertDoesNotExist()
        compose.onNodeWithText("СЛЕДУЮЩЕЕ ВРЕМЯ").assertDoesNotExist()
        compose.onNodeWithText("ПУТЬ ВРЕМЕНИ").assertDoesNotExist()
    }

    @Test fun everySettingsEditorOpensAndReturnsToTheIndex() {
        val data = fixture()
        compose.setContent { NurTheme { SettingsScreen(data, paletteFor(Prayer.ISHA), actions, true) } }
        compose.onNodeWithText("Ваш Нур").assertDoesNotExist()
        listOf("method", "madhab", "notify", "azan", "highlat", "rounding", "offsets", "about").forEach { id ->
            compose.onNodeWithTag("settings-index").performScrollToNode(hasTestTag("setting-$id"))
            compose.onNodeWithTag("setting-$id").performClick()
            compose.onNodeWithTag("settings-$id").assertIsDisplayed()
            compose.onNodeWithContentDescription("К настройкам").performClick()
            compose.onNodeWithTag("settings-index").assertIsDisplayed()
        }
    }

}
