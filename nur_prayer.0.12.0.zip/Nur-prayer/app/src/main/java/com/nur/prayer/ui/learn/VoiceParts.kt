package com.nur.prayer.ui.learn

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nur.prayer.audio.ArabicVoice
import com.nur.prayer.audio.VoiceText
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.SwitchRow
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.uiScale
import kotlinx.coroutines.delay

/** The process-wide voice; null in previews and tests, where every speaker simply disappears. */
val LocalArabicVoice = staticCompositionLocalOf<ArabicVoice?> { null }

/**
 * Status of the voice for this screen. Connects the engine on first use, looks again when the
 * user comes back from installing a voice, and silences it when the screen goes away.
 */
@Composable
fun rememberVoiceStatus(): ArabicVoice.Status {
    val voice = LocalArabicVoice.current ?: return ArabicVoice.Status.NO_ENGINE
    val owner = LocalLifecycleOwner.current
    DisposableEffect(voice, owner) {
        voice.attach()
        val observer = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) voice.recheck()
            if (e == Lifecycle.Event.ON_PAUSE) voice.stop()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); voice.detach() }
    }
    val status by voice.status.collectAsStateWithLifecycle()
    return status
}

/**
 * Says [text] once when [key] appears, if autoplay is on. Waits a beat for the slide-in, and
 * fires again if the engine becomes ready while the card is on screen.
 */
@Composable
fun AutoSay(text: String?, key: Any, status: ArabicVoice.Status, enabled: Boolean = true) {
    val voice = LocalArabicVoice.current ?: return
    val auto by voice.autoplay.collectAsStateWithLifecycle()
    LaunchedEffect(key, status == ArabicVoice.Status.READY, enabled) {
        if (!enabled || !auto || text.isNullOrBlank() || !voice.canSay(text, status)) return@LaunchedEffect
        delay(280)
        voice.say(text)
    }
}

/** A round speaker. Breathes while its own text is sounding; hidden when nothing can say it. */
@Composable
fun SpeakButton(
    text: String,
    status: ArabicVoice.Status,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    tint: Color = TextPrimary,
    slow: Boolean? = null,
    label: String = "Послушать"
) {
    val voice = LocalArabicVoice.current ?: return
    if (!voice.canSay(text, status)) return
    val speaking by voice.speaking.collectAsStateWithLifecycle()
    val mine = speaking != null && speaking == VoiceText.key(text)
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        if (mine) {
            val pulse = rememberInfiniteTransition(label = "speak")
            val k by pulse.animateFloat(0f, 1f, infiniteRepeatable(tween(900), RepeatMode.Restart), label = "speakRing")
            Box(
                Modifier.size(size).graphicsLayer { scaleX = 1f + 0.35f * k; scaleY = 1f + 0.35f * k; alpha = 1f - k }
                    .clip(CircleShape).border(2.dp, tint, CircleShape)
            )
        }
        Box(
            Modifier.size(size).clip(CircleShape).background(if (mine) tint.copy(alpha = 0.22f) else SurfaceRaised)
                .border(1.dp, SurfaceEdge, CircleShape)
                .semantics { contentDescription = label }
                .pressClick(haptic = false) { if (mine) voice.stop() else voice.say(text, slow ?: voice.slow.value) },
            contentAlignment = Alignment.Center
        ) {
            Glyph(GlyphKind.SOUND, tint, Modifier.size(size * 0.46f))
        }
    }
}

/** Shown once per screen when the phone has no Arabic voice: what is missing and one button to fix it. */
@Composable
fun VoiceHint(status: ArabicVoice.Status, accent: Color, modifier: Modifier = Modifier) {
    val voice = LocalArabicVoice.current ?: return
    if (status != ArabicVoice.Status.NO_VOICE && status != ArabicVoice.Status.NO_ENGINE) return
    val context = LocalContext.current
    val ui = uiScale()
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SurfaceRaised)
            .pressClick(scaleTo = 0.98f) { voice.openInstall(context) }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Glyph(GlyphKind.SOUND_OFF, accent, Modifier.size(20.dp))
        Column(Modifier.padding(start = 12.dp).weight(1f)) {
            Text("Озвучка выключена", color = TextPrimary, fontSize = ui.t(14f), fontWeight = FontWeight.SemiBold)
            Text(
                if (status == ArabicVoice.Status.NO_VOICE) "На телефоне нет арабского голоса. Нажмите, чтобы установить."
                else "Нет синтезатора речи. Установите «Синтезатор речи Google».",
                color = TextSecondary, fontSize = ui.t(12f)
            )
        }
    }
}

/**
 * The two voice preferences, on the course map where they matter: new letters and words read
 * aloud as they appear, and the slow reading for every speaker button. Both persist in
 * [ArabicVoice]; a switch here takes effect on the next word, nothing to restart.
 */
@Composable
fun VoiceSettings(accent: Color, modifier: Modifier = Modifier) {
    val voice = LocalArabicVoice.current ?: return
    val auto by voice.autoplay.collectAsStateWithLifecycle()
    val slow by voice.slow.collectAsStateWithLifecycle()
    Column(modifier.fillMaxWidth()) {
        SwitchRow(
            title = "Озвучивать новое сразу",
            checked = auto,
            accent = accent,
            onCheckedChange = voice::setAutoplay,
            subtitle = "Новая буква или слово звучит само при показе"
        )
        SwitchRow(
            title = "Медленное произношение",
            checked = slow,
            accent = accent,
            onCheckedChange = voice::setSlow,
            subtitle = "Кнопка «послушать» читает медленнее"
        )
    }
}
