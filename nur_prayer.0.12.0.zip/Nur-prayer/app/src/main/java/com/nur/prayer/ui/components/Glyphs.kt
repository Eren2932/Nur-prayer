package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * The app's icon set, drawn rather than imported.
 *
 * `material-icons-extended` is ~30 MB of vectors for the nine glyphs we need, and the core set has
 * no compass, no muted speaker and no calendar that matches our stroke weight. These are drawn in
 * a 1×1 unit box with one stroke width, so they sit on the same optical grid at every size.
 * Decorative by default: the clickable around a glyph carries the accessible label.
 */
enum class GlyphKind { COMPASS, MORE, CALENDAR, BACK, CLOSE, LOCATION, SOUND, SOUND_OFF, CHEVRON, MOON }

@Composable
fun Glyph(kind: GlyphKind, tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) { drawGlyph(kind, tint) }
}

private fun DrawScope.drawGlyph(kind: GlyphKind, color: Color) {
    val s = size.minDimension
    if (s <= 0f) return
    val ox = (size.width - s) / 2f
    val oy = (size.height - s) / 2f
    val w = s * 0.09f
    val stroke = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(ox + x * s, oy + y * s)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, width: Float = w) =
        drawLine(color, p(x1, y1), p(x2, y2), strokeWidth = width, cap = StrokeCap.Round)

    when (kind) {
        GlyphKind.COMPASS -> {
            drawCircle(color, radius = s * 0.42f, center = p(0.5f, 0.5f), style = stroke)
            val needle = Path().apply {
                moveTo(ox + 0.68f * s, oy + 0.32f * s)
                lineTo(ox + 0.45f * s, oy + 0.45f * s)
                lineTo(ox + 0.32f * s, oy + 0.68f * s)
                lineTo(ox + 0.55f * s, oy + 0.55f * s)
                close()
            }
            drawPath(needle, color)
        }
        GlyphKind.MORE -> {
            listOf(0.22f, 0.5f, 0.78f).forEach { x -> drawCircle(color, s * 0.075f, p(x, 0.5f)) }
        }
        GlyphKind.CALENDAR -> {
            drawRoundRect(
                color, topLeft = p(0.12f, 0.2f), size = Size(s * 0.76f, s * 0.68f),
                cornerRadius = CornerRadius(s * 0.14f, s * 0.14f), style = stroke
            )
            line(0.32f, 0.1f, 0.32f, 0.27f)
            line(0.68f, 0.1f, 0.68f, 0.27f)
            line(0.12f, 0.42f, 0.88f, 0.42f, w * 0.8f)
            drawCircle(color, s * 0.055f, p(0.34f, 0.62f))
            drawCircle(color, s * 0.055f, p(0.5f, 0.62f))
            drawCircle(color, s * 0.055f, p(0.66f, 0.62f))
        }
        GlyphKind.BACK -> {
            line(0.62f, 0.18f, 0.3f, 0.5f)
            line(0.3f, 0.5f, 0.62f, 0.82f)
        }
        GlyphKind.CHEVRON -> {
            line(0.4f, 0.22f, 0.68f, 0.5f)
            line(0.68f, 0.5f, 0.4f, 0.78f)
        }
        GlyphKind.CLOSE -> {
            line(0.26f, 0.26f, 0.74f, 0.74f)
            line(0.74f, 0.26f, 0.26f, 0.74f)
        }
        GlyphKind.LOCATION -> {
            // The "navigation arrow", as on a map: a filled dart pointing north-east.
            val dart = Path().apply {
                moveTo(ox + 0.86f * s, oy + 0.14f * s)
                lineTo(ox + 0.14f * s, oy + 0.46f * s)
                lineTo(ox + 0.5f * s, oy + 0.52f * s)
                lineTo(ox + 0.56f * s, oy + 0.88f * s)
                close()
            }
            drawPath(dart, color)
        }
        GlyphKind.SOUND, GlyphKind.SOUND_OFF -> {
            val body = Path().apply {
                moveTo(ox + 0.12f * s, oy + 0.38f * s)
                lineTo(ox + 0.3f * s, oy + 0.38f * s)
                lineTo(ox + 0.52f * s, oy + 0.18f * s)
                lineTo(ox + 0.52f * s, oy + 0.82f * s)
                lineTo(ox + 0.3f * s, oy + 0.62f * s)
                lineTo(ox + 0.12f * s, oy + 0.62f * s)
                close()
            }
            drawPath(body, color)
            if (kind == GlyphKind.SOUND) {
                drawArc(
                    color, startAngle = -50f, sweepAngle = 100f, useCenter = false,
                    topLeft = p(0.46f, 0.3f), size = Size(s * 0.24f, s * 0.4f), style = stroke
                )
                drawArc(
                    color, startAngle = -55f, sweepAngle = 110f, useCenter = false,
                    topLeft = p(0.5f, 0.16f), size = Size(s * 0.38f, s * 0.68f), style = stroke
                )
            } else {
                line(0.64f, 0.36f, 0.9f, 0.64f)
                line(0.9f, 0.36f, 0.64f, 0.64f)
            }
        }
        GlyphKind.MOON -> {
            val r = s * 0.38f
            val crescent = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(p(0.5f, 0.5f), r))
            }
            val bite = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(p(0.66f, 0.38f), r * 0.86f))
            }
            val shape = Path().apply { op(crescent, bite, androidx.compose.ui.graphics.PathOperation.Difference) }
            drawPath(shape, color)
        }
    }
}
