# Сборка и проверка Nur 0.3.3

## Среда

JDK 17, Gradle 8.9, Android SDK Platform 34 / Build Tools 34.0.0, Python 3.10+.
Kotlin 2.0.20 / AGP 8.5.2 / Compose BOM 2024.09.00 сохранены. Новых библиотечных зависимостей нет.
Для загрузки зависимостей нужен доступ к Google Maven, Maven Central и репозиторию Gradle.
В ZIP, как и раньше, нет полного Gradle wrapper. Используйте установленный `gradle`, не `./gradlew`.
При необходимости: `gradle wrapper --gradle-version 8.9` в настроенной среде.

## Предварительная проверка

````bash
python3 tools/check_compose_actions.py
python3 tools/test_compose_actions.py
python3 tools/kt_sanity.py
python3 tools/kt_symbols.py
python3 tools/source_audit.py
python3 tools/test_source_archive.py
python3 tools/test_kt_symbols.py
python3 tools/test_build_regressions.py
python3 tools/verify_cities.py
python3 tools/verify_uz_table.py
````

Эти команды не компилируют Kotlin. Проверка Compose actions консервативно запрещает цепочки
после известных Unit-returning действий в androidTest и не заменяет проверку типов компилятором.

## Компиляция, сборка и тесты

````bash
gradle --no-daemon :app:compileDebugKotlin :app:compileReleaseKotlin :app:compileDebugUnitTestKotlin :app:compileDebugAndroidTestKotlin --stacktrace
gradle --no-daemon :app:testDebugUnitTest :app:lintDebug :app:assembleDebug :app:assembleRelease :app:assembleDebugAndroidTest --stacktrace
# С подключённым Android-устройством или эмулятором:
gradle :app:connectedDebugAndroidTest
````

126 JVM-тестов включают четыре новых теста политики компаса. 10 UI-тестов включают пять
сохранённых сценариев и пять новых: кнопки, сегментированный выбор, нулевой размер фона,
компактная шкала со сменой часов. Сборка androidTest APK — это не исполнение UI-тестов.

Новый workflow выполняет те же APK на эмуляторах API 26 и 34 через `am instrument`.
Положительный результат `OK (N tests)` обязателен: одного кода возврата adb недостаточно.
Отчёты: `nur-reports`, `nur-ui-results-api-26`, `nur-ui-results-api-34`.
APK: `nur-debug-apk`, `nur-release-apk-test-key`, `nur-ui-test-apk`.
Для ZIP-репозитория необходимо обновить внешний workflow — см. README.

Lint сохранён в исходном режиме `abortOnError=false`: отчёт требуется прочитать отдельно;
зелёная сборка не доказывает отсутствие lint-замечаний. Ошибки Kotlin, JUnit и UI-тестов
не подавляются. Release по-прежнему минифицируется R8 и подписывается тестовым ключом.

## Установка и подпись

Debug имеет applicationId `com.nur.prayer.debug`, release — `com.nur.prayer`.
Устанавливайте тот же вариант с тем же сертификатом, чтобы сохранить данные.
Новый runner может создать другой debug keystore, поэтому тестовые release APK не гарантируют
обновление поверх старого APK. Для постоянной подписи нужен собственный keystore через Secrets;
ключи и пароли в проект не добавлялись.

## Реальные границы проверки этой выдачи

В the Computer выполнены только статические/Python-проверки и проверка целостности архива.
Gradle/Android SDK не настроены, APK и Android-скриншоты не получены, R8/lint/эмуляторы не запускались.
Не принимайте архив за проверенный бинарный релиз до успешного Actions run и проверки телефона.
Сценарии ручного приёмочного тестирования: `docs/DEVICE-CHECK-0.3.3.md`.
