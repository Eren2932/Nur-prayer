package com.nur.prayer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.unit.dp
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.ui.components.CountdownRing
import com.nur.prayer.ui.components.NightSky
import com.nur.prayer.ui.theme.NurTheme
import com.nur.prayer.ui.theme.paletteFor
import java.time.ZonedDateTime
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MeridianUiTest {
    @get:Rule val compose = createComposeRule()

    @Test fun zeroSizeBackdropDoesNotCreateAnInvalidShader() {
        compose.setContent {
            NurTheme {
                NightSky(paletteFor(Prayer.ISHA), Modifier.size(0.dp))
                Text("Экран доступен")
            }
        }
        compose.onNodeWithText("Экран доступен").assertIsDisplayed()
    }

    @Test fun compactDialSettlesAndSurvivesClockChange() {
        val initial = ZonedDateTime.parse("2026-09-07T12:00:00+03:00")
        val clock = mutableStateOf(initial)
        val start = initial.toInstant().toEpochMilli()
        val palette = paletteFor(Prayer.DHUHR)
        compose.setContent {
            NurTheme {
                Box(Modifier.size(240.dp)) {
                    NightSky(palette)
                    CountdownRing(start, start + 60_000L, clock, palette.accent, palette.accentSoft,
                        Modifier.size(240.dp)) {
                        Text("Следующее время")
                    }
                }
            }
        }
        compose.onNodeWithText("Следующее время").assertIsDisplayed()
        compose.runOnIdle { clock.value = initial.plusMinutes(2) }
        compose.waitForIdle()
        compose.onNodeWithText("Следующее время").assertIsDisplayed()
    }
}
