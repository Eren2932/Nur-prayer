package com.nur.prayer.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.CountdownMath
import com.nur.prayer.ui.theme.SurfaceEdge
import java.time.ZonedDateTime
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Meridian interval dial. Its quiet rim and 48 segments show elapsed interval, not seconds.
 * The centre readout and progress use the same lifecycle-aware clock. No local tick loop.
 */
@Composable
fun CountdownRing(
    startMillis: Long,
    endMillis: Long,
    now: State<ZonedDateTime>,
    accent: Color,
    accentSoft: Color,
    modifier: Modifier = Modifier,
    stroke: Dp = 3.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            if (size.minDimension < 24f) return@Canvas
            val phase = CountdownMath.progress(startMillis, endMillis, now.value.toInstant().toEpochMilli())
            val radius = size.minDimension * 0.455f
            val c = center
            val origin = Offset(c.x - radius, c.y - radius)
            val bounds = Size(radius * 2f, radius * 2f)
            val line = stroke.toPx().coerceIn(1f, radius * 0.08f)
            drawArc(SurfaceEdge, 125f, 290f, false, origin, bounds, style = Stroke(line, cap = StrokeCap.Round))
            if (phase > 0f) drawArc(accent, 125f, 290f * phase, false, origin, bounds,
                style = Stroke(line, cap = StrokeCap.Round))
            for (i in 0..48) {
                val angle = (125.0 + i * 290.0 / 48.0) * PI / 180.0
                val outer = radius - 8.dp.toPx()
                val inner = outer - (if (i % 4 == 0) 6.dp else 3.dp).toPx()
                drawLine(if (i / 48f <= phase) accentSoft.copy(alpha = 0.55f) else SurfaceEdge,
                    Offset(c.x + outer * cos(angle).toFloat(), c.y + outer * sin(angle).toFloat()),
                    Offset(c.x + inner * cos(angle).toFloat(), c.y + inner * sin(angle).toFloat()),
                    strokeWidth = 1.dp.toPx())
            }
            val a = (125.0 + 290.0 * phase) * PI / 180.0
            val marker = Offset(c.x + radius * cos(a).toFloat(), c.y + radius * sin(a).toFloat())
            drawCircle(accent, 5.dp.toPx(), marker)
            drawCircle(accentSoft, 2.dp.toPx(), marker)
        }
        content()
    }
}
