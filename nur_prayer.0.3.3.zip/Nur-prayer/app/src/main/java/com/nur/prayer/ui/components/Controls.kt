package com.nur.prayer.ui.components

import androidx.compose.runtime.setValue
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.nur.prayer.ui.theme.SurfaceRaised
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.InkSoft
import com.nur.prayer.ui.theme.solidTone
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ripple
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/**
 * The control set.
 *
 * Everything the app used before was assembled ad hoc inside the screens: a pill here, a coloured
 * circle there, twelve radio rows always open. That is why Settings was four screens tall and why
 * nothing looked related to anything else. These are the shared primitives instead, and the rules
 * they follow are deliberate:
 *
 *  - **one accent per screen phase.** Colour marks the *chosen* thing and nothing else, so a glance
 *    finds the current state without reading;
 *  - **hairlines, not glow.** Structure comes from 1 dp edges and spacing, the way instrument panels
 *    and Swiss timetables do it, instead of from bloom;
 *  - **hit targets never shrink below 48 dp**, whatever the system font scale does to the label;
 *  - **motion is short and physical:** 120–220 ms, spring where something slides, and no overshoot on
 *    anything the user has to read;
 *  - **every control ticks haptically** on a real state change, and stays silent on a no-op tap.
 */

/* ------------------------------------------------------------------------------------------------
 * Headers and rules
 * ---------------------------------------------------------------------------------------------- */

/** Small-caps label with a hairline that runs to the end of the row. */
@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = text.uppercase(),
            color = TextTertiary,
            fontSize = ui.t(10.5f),
            letterSpacing = ui.t(1.6f),
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.width(ui.s(10f)))
        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(SurfaceEdge)
        )
    }
}

/** One-pixel divider used inside panels. */
@Composable
fun HairRule(modifier: Modifier = Modifier, inset: Boolean = false) {
    val ui = uiScale()
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = if (inset) ui.s(12f) else 0.dp, vertical = ui.s(8f))
            .height(1.dp)
            .background(SurfaceEdge)
    )
}

/* ------------------------------------------------------------------------------------------------
 * Accordion
 * ---------------------------------------------------------------------------------------------- */

/**
 * A collapsible group whose header carries the current value.
 *
 * This is the fix for Settings being endless: twelve calculation methods and five high-latitude rules
 * were rendered as sixty always-visible rows, so the screen was about four and a half viewports tall
 * and the important part — *which* one is active — was the hardest thing to find. Collapsed, each
 * group is one row that states its own answer. Expanded, exactly one group at a time is open, which
 * also keeps the composition small.
 */
@Composable
fun ExpandableSection(
    title: String,
    value: String,
    expanded: Boolean,
    accent: Color,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(ui.s(20f))
    val rotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = tween(140),
        label = "chevron"
    )
    val edge by animateColorAsState(
        targetValue = if (expanded) solidTone(accent, 0.55f) else SurfaceEdge,
        animationSpec = tween(180),
        label = "sectionEdge"
    )

    Column(modifier = modifier.fillMaxWidth().nurPanel(shape, PanelLevel.RAISED)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple()
                ) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onToggle()
                }
                .padding(horizontal = ui.s(16f), vertical = ui.s(14f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = ui.t(14.5f),
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(ui.s(2f)))
                AutoSizeText(
                    text = value,
                    color = if (expanded) accent else TextSecondary,
                    fontSize = ui.t(11.5f),
                    minFontSize = ui.t(9f),
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.width(ui.s(10f)))
            Canvas(
                modifier = Modifier
                    .size(ui.s(16f))
                    .graphicsLayer { rotationZ = rotation }
            ) {
                val s = size.minDimension
                val path = Path().apply {
                    moveTo(s * 0.18f, s * 0.36f)
                    lineTo(s * 0.5f, s * 0.68f)
                    lineTo(s * 0.82f, s * 0.36f)
                }
                drawPath(
                    path = path,
                    color = TextSecondary,
                    style = Stroke(
                        width = s * 0.13f,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
        }
        // Opening a group re-measures a `LazyColumn` item on every animation frame, so the height
        // animation is the expensive half and the fade is the cheap one. Keeping the height change
        // short (140/110 ms) and letting the fade lead makes the group feel like it snaps open
        // while still reading as motion; the old 180/160 ms spent that time visibly measuring.
        AnimatedVisibility(
            visible = expanded,
            enter = fadeIn(tween(110)) + expandVertically(tween(140, easing = LinearOutSlowInEasing)),
            exit = fadeOut(tween(70)) + shrinkVertically(tween(110, easing = FastOutLinearInEasing))
        ) {
            Column(
                modifier = Modifier.padding(
                    start = ui.s(14f),
                    end = ui.s(14f),
                    bottom = ui.s(14f)
                )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(edge)
                )
                Spacer(Modifier.height(ui.s(12f)))
                content()
            }
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * Segmented control
 * ---------------------------------------------------------------------------------------------- */

/**
 * Two to four mutually exclusive options on one line, with a thumb that slides.
 *
 * Replaces the stack of full-width radio rows for every short choice. A segmented track states the
 * whole choice space in one row, which is both smaller and easier to read than n rows of which n − 1
 * are noise.
 */
@Composable
fun SegmentedControl(
    options: List<String>,
    selectedIndex: Int,
    accent: Color,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val trackShape = RoundedCornerShape(ui.s(15f))
    if (options.isEmpty()) return
    val safeIndex = selectedIndex.coerceIn(0, options.lastIndex)

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
            .selectableGroup()
            .nurPanel(trackShape, PanelLevel.INSET)
    ) {
        val slot = maxWidth / options.size.coerceAtLeast(1)
        val thumbOffset by animateDpAsState(
            targetValue = slot * safeIndex,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "segment"
        )
        Box(
            modifier = Modifier
                .offset(x = thumbOffset)
                .width(slot)
                .fillMaxHeight()
                .padding(ui.s(3f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(ui.s(12f)))
                    .background(solidTone(accent, 0.25f))
            )
        }
        Row(modifier = Modifier.fillMaxSize()) {
            options.forEachIndexed { index, label ->
                val active = index == safeIndex
                Box(
                    modifier = Modifier
                        .width(slot)
                        .fillMaxHeight()
                        .selectable(
                            selected = active,
                            role = Role.RadioButton,
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple()
                        ) {
                            if (!active) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onSelect(index)
                            }
                        }
                        .padding(horizontal = ui.s(6f)),
                    contentAlignment = Alignment.Center
                ) {
                    AutoSizeText(
                        text = label,
                        color = if (active) TextPrimary else TextSecondary,
                        fontSize = ui.t(12.5f),
                        minFontSize = ui.t(9.5f),
                        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * Buttons
 * ---------------------------------------------------------------------------------------------- */

/**
 * The two button steps of the app, and there are only two on purpose.
 *
 * [primary] is a solid accent plate with ink-dark type — the one element on a screen that is allowed
 * to shout. Everything else is `primary = false`: a hairline outline that reads as available but not
 * urgent. Both dip to 98.5 % on press, which is the cheapest honest way to say "received".
 */
@Composable
fun NurButton(
    text: String,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    enabled: Boolean = true
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.985f else 1f,
        animationSpec = tween(90),
        label = "buttonPress"
    )
    val shape = RoundedCornerShape(ui.s(12f))
    val alpha = if (enabled) 1f else 0.45f

    Box(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(shape)
            .background(
                if (primary && enabled) accent
                else SurfaceRaised
            )
            .then(
                if (primary && enabled) Modifier
                else Modifier.nurPanel(shape, PanelLevel.FLAT, if (enabled) accent else null)
            )
            .clickable(
                interactionSource = interaction,
                indication = ripple(),
                enabled = enabled,
                role = Role.Button
            ) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(horizontal = ui.s(14f), vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        AutoSizeText(
            text = text,
            color = if (primary && enabled) Ink else TextPrimary.copy(alpha = alpha),
            fontSize = ui.t(14f),
            minFontSize = ui.t(11f),
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/* ------------------------------------------------------------------------------------------------
 * Choice row
 * ---------------------------------------------------------------------------------------------- */

/**
 * One option in a long list (calculation method, latitude rule).
 *
 * Selection is carried by a 3 dp accent rail on the left edge plus the title colour, not by a tinted
 * background over the whole row: with twelve rows, twelve tinted rectangles turned the list into a
 * heat map. The rail is unmistakable and costs one draw call.
 */
@Composable
fun ChoiceRow(
    title: String,
    subtitle: String,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(ui.s(14f))
    val railColor by animateColorAsState(
        targetValue = if (selected) accent else Color.Transparent,
        animationSpec = tween(160),
        label = "rail"
    )
    val background by animateColorAsState(
        targetValue = if (selected) solidTone(accent, 0.16f) else InkSoft,
        animationSpec = tween(160),
        label = "choiceBg"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(background)
            .heightIn(min = 56.dp)
            .selectable(
                selected = selected,
                role = Role.RadioButton,
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple()
            ) {
                if (!selected) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                }
            }
            .padding(vertical = ui.s(10f), horizontal = ui.s(8f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(3.dp)
                .height(ui.s(26f))
                .clip(RoundedCornerShape(2.dp))
                .background(railColor)
        )
        Spacer(Modifier.width(ui.s(10f)))
        Column(modifier = Modifier.weight(1f)) {
            AutoSizeText(
                text = title,
                color = if (selected) TextPrimary else TextSecondary,
                fontSize = ui.t(13.5f),
                minFontSize = ui.t(11f),
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
            AutoSizeText(
                text = subtitle,
                color = TextTertiary,
                fontSize = ui.t(10.5f),
                minFontSize = ui.t(8.5f),
                maxLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/* ------------------------------------------------------------------------------------------------
 * Stepper
 * ---------------------------------------------------------------------------------------------- */

/**
 * Label on the left, one welded −/value/+ group on the right.
 *
 * Before, two round accent buttons floated free with the number between them, so eight steppers in a
 * row produced sixteen coloured circles and no visible structure. Welding them into a single inset
 * track turns each row into one object, and the value sits in monospace so the column of numbers
 * lines up.
 */
@Composable
fun StepperField(
    label: String,
    value: String,
    accent: Color,
    onMinus: () -> Unit,
    onPlus: () -> Unit,
    modifier: Modifier = Modifier,
    hint: String? = null
) {
    val ui = uiScale()
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(5f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            AutoSizeText(
                text = label,
                color = TextPrimary,
                fontSize = ui.t(13.5f),
                minFontSize = ui.t(10.5f),
                maxLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
            if (hint != null) {
                AutoSizeText(
                    text = hint,
                    color = TextTertiary,
                    fontSize = ui.t(10f),
                    minFontSize = ui.t(8.5f),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Spacer(Modifier.width(ui.s(10f)))
        Row(
            modifier = Modifier
                .height(48.dp)
                .nurPanel(RoundedCornerShape(ui.s(12f)), PanelLevel.INSET),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StepperKey("−", "Уменьшить: $label", accent, onMinus)
            Box(
                modifier = Modifier.width(ui.s(58f)),
                contentAlignment = Alignment.Center
            ) {
                AutoSizeText(
                    text = value,
                    color = TextPrimary,
                    fontSize = ui.t(13.5f),
                    minFontSize = ui.t(10f),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium,
                    resizeKey = value.length
                )
            }
            StepperKey("+", "Увеличить: $label", accent, onPlus)
        }
    }
}

@Composable
private fun StepperKey(glyph: String, description: String, accent: Color, onClick: () -> Unit) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val tint by animateColorAsState(
        targetValue = if (pressed) accent else TextSecondary,
        animationSpec = tween(80),
        label = "stepKey"
    )
    Box(
        modifier = Modifier
            .size(48.dp)
            .semantics { contentDescription = description }
            .clickable(interactionSource = interaction, indication = ripple(), role = Role.Button) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = glyph,
            color = tint,
            fontSize = ui.t(17f),
            fontWeight = FontWeight.Medium
        )
    }
}

/* ------------------------------------------------------------------------------------------------
 * Switch row
 * ---------------------------------------------------------------------------------------------- */

/**
 * Title, optional explanation, and our own switch.
 *
 * Material's `Switch` is 52 × 32 dp of someone else's design language, and its thumb ignores our
 * accent rules. This one is 44 × 26, matches the corner radius of every other control, and animates
 * on a spring so the thumb has weight.
 */
@Composable
fun SwitchRow(
    title: String,
    checked: Boolean,
    accent: Color,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null
) {
    val ui = uiScale()
    val haptic = LocalHapticFeedback.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(ui.s(14f)))
            .heightIn(min = 56.dp)
            .toggleable(
                value = checked,
                role = Role.Switch,
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple()
            ) { value ->
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onCheckedChange(value)
            }
            .padding(vertical = ui.s(7f), horizontal = ui.s(4f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            AutoSizeText(
                text = title,
                color = TextPrimary,
                fontSize = ui.t(13.5f),
                minFontSize = ui.t(11f),
                fontWeight = FontWeight.Medium,
                modifier = Modifier.fillMaxWidth()
            )
            if (subtitle != null) {
                AutoSizeText(
                    text = subtitle,
                    color = TextTertiary,
                    fontSize = ui.t(10.5f),
                    minFontSize = ui.t(8.5f),
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Spacer(Modifier.width(ui.s(10f)))
        NurSwitch(checked = checked, accent = accent)
    }
}

/** The switch itself, drawn by us. */
@Composable
fun NurSwitch(checked: Boolean, accent: Color, modifier: Modifier = Modifier) {
    val ui = uiScale()
    val trackWidth = ui.s(44f)
    val trackHeight = ui.s(26f)
    val knob = ui.s(20f)
    val offset by animateDpAsState(
        targetValue = if (checked) trackWidth - knob - ui.s(3f) else ui.s(3f),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "switchKnob"
    )
    val track by animateColorAsState(
        targetValue = if (checked) accent else SurfaceEdge,
        animationSpec = tween(160),
        label = "switchTrack"
    )
    Box(
        modifier = modifier
            .width(trackWidth)
            .height(trackHeight)
            .clip(RoundedCornerShape(trackHeight / 2))
            .background(track),
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .offset(x = offset)
                .size(knob)
                .clip(CircleShape)
                .background(if (checked) Ink else TextSecondary)
        )
    }
}

/* ------------------------------------------------------------------------------------------------
 * Read-only pieces
 * ---------------------------------------------------------------------------------------------- */

/*
 * `StatusChip` used to live here: a tinted capsule with a dot, for read-only state. It was dead code
 * by 0.2.6 — the compass screen, its only ever caller, now draws a single quiet status line instead
 * (see QiblaScreen.StatusStrip), and nothing else should grow a pill for something you cannot press.
 * Deleted rather than kept "just in case": an unused public composable is an invitation.
 */

/** Label / value line for read-only technical facts. */
@Composable
fun FactRow(label: String, value: String, modifier: Modifier = Modifier) {
    val ui = uiScale()
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = ui.s(4f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AutoSizeText(
            text = label,
            color = TextTertiary,
            fontSize = ui.t(11.5f),
            minFontSize = ui.t(9f),
            maxLines = 2,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(ui.s(10f)))
        AutoSizeText(
            text = value,
            color = TextSecondary,
            fontSize = ui.t(11.5f),
            minFontSize = ui.t(9f),
            fontFamily = FontFamily.Monospace,
            resizeKey = value.length
        )
    }
}

/** Small caption used under a control group, a chart or a dial. */
@Composable
fun Caption(text: String, modifier: Modifier = Modifier, color: Color = TextTertiary) {
    val ui = uiScale()
    Text(
        text = text,
        color = color,
        fontSize = ui.t(11f),
        lineHeight = ui.t(15.5f),
        modifier = modifier.fillMaxWidth()
    )
}
