package com.nur.prayer.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.nur.prayer.ui.theme.Ink
import com.nur.prayer.ui.theme.PhasePalette

/** Meridian: matte architectural arches, cached at the actual viewport size.
 * No particles, random grain, blur, bitmap assets, coroutine or frame clock.
 * The old public signature remains compatible with navigation's motion policy.
 */
@Suppress("UNUSED_PARAMETER")
@Composable
fun NightSky(palette: PhasePalette, modifier: Modifier = Modifier, motionEnabled: Boolean = true) {
    Box(modifier.fillMaxSize().drawWithCache {
        val w = size.width
        val h = size.height
        if (w < 1f || h < 1f) {
            onDrawBehind { }
        } else {
            val base = Brush.verticalGradient(listOf(Ink, Color(0xFF102225), Ink))
            val light = Brush.radialGradient(
                listOf(palette.accent.copy(alpha = 0.10f), Color.Transparent),
                center = Offset(w * 0.85f, h * 0.12f), radius = size.maxDimension * 0.65f
            )
            val arches = Path().apply {
                // A restrained mihrab-inspired silhouette, not an animated sky.
                repeat(4) { i ->
                    val inset = w * (0.06f + i * 0.085f)
                    val top = h * (0.13f + i * 0.045f)
                    moveTo(inset, h)
                    lineTo(inset, top + w * 0.58f)
                    cubicTo(inset, top + w * 0.26f, w * 0.35f, top + w * 0.10f, w * 0.5f, top)
                    cubicTo(w * 0.65f, top + w * 0.10f, w - inset, top + w * 0.26f, w - inset, top + w * 0.58f)
                    lineTo(w - inset, h)
                }
            }
            val edge = Stroke(0.75f * density)
            onDrawBehind {
                drawRect(base)
                drawRect(light)
                drawPath(arches, palette.accentSoft.copy(alpha = 0.045f), style = edge)
                drawRect(Color.Black.copy(alpha = 0.12f), Offset(0f, h * 0.72f), Size(w, h * 0.28f))
            }
        }
    })
}
