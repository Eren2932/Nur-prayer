package com.nur.prayer

import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.ui.ROUTE_SURAH
import com.nur.prayer.ui.home.HomeSection
import com.nur.prayer.ui.shell.PanelTimes
import com.nur.prayer.ui.shell.ShellMath
import com.nur.prayer.ui.shell.ShellRoutes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** 0.27.0 «Капсула»: the arithmetic of the morph and which page shows the capsule and the island. */
class ShellMathTest {
    @Test fun capsuleContentLeavesBeforeThePanelArrives() {
        assertEquals(1f, ShellMath.capsuleAlpha(0f), 0f)
        assertEquals(0f, ShellMath.capsuleAlpha(0.3f), 1e-6f)
        assertEquals(0f, ShellMath.panelAlpha(0.28f), 1e-6f)
        assertEquals(1f, ShellMath.panelAlpha(0.8f), 1e-6f)
        // Never both at full strength: no frame shows two layers of text on top of each other.
        var p = 0f
        while (p <= 1.03f) {
            assertTrue(ShellMath.capsuleAlpha(p) + ShellMath.panelAlpha(p) <= 1.0001f)
            p += 0.01f
        }
    }

    @Test fun springOvershootIsBounded() {
        assertEquals(1.03f, ShellMath.clampProgress(1.4f), 0f)
        assertEquals(0f, ShellMath.clampProgress(-0.2f), 0f)
    }

    /** 0.37.0: the glass of the bar is a veil at first and the panel's paper by [ShellMath.FILL_DONE_AT] of the way. */
    @Test fun theVeilBecomesPaperBeforeThePanelsContentHasAnyWeight() {
        assertEquals(0f, ShellMath.fillProgress(0f), 0f)
        assertEquals(0.5f, ShellMath.fillProgress(ShellMath.FILL_DONE_AT / 2f), 1e-6f)
        assertEquals(1f, ShellMath.fillProgress(ShellMath.FILL_DONE_AT), 1e-6f)
        assertEquals(1f, ShellMath.fillProgress(1.03f), 0f)
        // Where the panel's text starts to arrive the glass is already four fifths paper.
        assertEquals(0f, ShellMath.panelAlpha(0.28f), 1e-6f)
        assertTrue(ShellMath.fillProgress(0.28f) >= 0.79f)
    }

    @Test fun everyGridSectionOpensAPageAndThatPageNamesItsSection() {
        HomeSection.GRID.forEach { section ->
            val route = ShellRoutes.routeOf(section)!!
            assertEquals(section, ShellRoutes.sectionOf(route))
            // The calendar is the one section that gives the bottom edge to its cards (0.29.0).
            assertEquals(section != HomeSection.SCHEDULE, ShellRoutes.capsuleOn(route))
        }
        assertNull(ShellRoutes.routeOf(HomeSection.SETTINGS))
        assertEquals(
            listOf(HomeSection.DHIKR, HomeSection.QIBLA, HomeSection.TODAY, HomeSection.SCHEDULE),
            HomeSection.GRID
        )
    }

    /** 0.37.0: the Quran left the panel for the bar's left button; its page still names its section. */
    @Test fun theQuranIsNotInThePanelButItsPageStillNamesItsSection() {
        assertFalse(HomeSection.QURAN in HomeSection.GRID)
        val route = ShellRoutes.routeOf(HomeSection.QURAN)!!
        assertEquals(HomeSection.QURAN, ShellRoutes.sectionOf(route))
    }

    /** 0.38.0: «Учёба» left the panel for the bar's pill; its page still names its section and keeps the capsule. */
    @Test fun theCourseIsNotInThePanelButItsPagesStillNameItsSection() {
        assertFalse(HomeSection.COURSE in HomeSection.GRID)
        val route = ShellRoutes.routeOf(HomeSection.COURSE)!!
        assertEquals(HomeSection.COURSE, ShellRoutes.sectionOf(route))
        assertTrue(ShellRoutes.capsuleOn(route))
    }

    @Test fun capsuleAndIslandPlacement() {
        assertTrue(ShellRoutes.capsuleOn("home"))
        assertFalse(ShellRoutes.islandOn("home"))
        assertTrue(ShellRoutes.islandOn("qibla"))
        // Paper pages keep the capsule but not the island over their own header.
        assertTrue(ShellRoutes.capsuleOn("quran"))
        assertFalse(ShellRoutes.islandOn("quran"))
        // 0.29.0: the calendar keeps the island (it is the way home) and gives the capsule's place to its cards.
        assertTrue(ShellRoutes.islandOn("schedule"))
        assertFalse(ShellRoutes.capsuleOn("schedule"))
        // Pages with their own way out: neither.
        listOf("settings", "city", "lesson", "story").forEach {
            assertFalse(ShellRoutes.capsuleOn(it))
            assertFalse(ShellRoutes.islandOn(it))
        }
    }

    /** 0.27.1: the glass is as dark over a white picture as over a black one. */
    @Test fun glassPictureDimNeverDropsBelowTheFloor() {
        assertEquals(ShellMath.PICTURE_DIM, ShellMath.pictureDim(0f, 0.62f), 0f)
        // A page that darkens more than the floor wins; one that darkens less does not lift the glass.
        assertEquals(0.62f, ShellMath.pictureDim(1f, 0.62f), 1e-6f)
        assertEquals(ShellMath.PICTURE_DIM, ShellMath.pictureDim(0.4f, 0.62f), 0f)
        assertEquals(ShellMath.PICTURE_DIM, ShellMath.pictureDim(-3f, 0.62f), 0f)
        assertEquals(0.62f, ShellMath.pictureDim(7f, 0.62f), 1e-6f)
    }

    @Test fun aPageCanSendTheCapsuleAway() {
        assertTrue(ShellMath.capsuleVisible(true, false))
        assertFalse(ShellMath.capsuleVisible(true, true))
        assertFalse(ShellMath.capsuleVisible(false, false))
    }

    /** The reader's chrome: tap/top/page turn bring it, reading on, a selection or a sheet take it away. */
    @Test fun readerChromeFollowsTheTapAndYieldsTheBottomEdge() {
        assertTrue(ShellMath.readerChrome(chromeShown = true, ayahSelected = false, sheetOpen = false))
        assertFalse(ShellMath.readerChrome(chromeShown = false, ayahSelected = false, sheetOpen = false))
        assertFalse(ShellMath.readerChrome(chromeShown = true, ayahSelected = true, sheetOpen = false))
        assertFalse(ShellMath.readerChrome(chromeShown = true, ayahSelected = false, sheetOpen = true))
    }

    @Test fun closeSpringNeverBounces() {
        assertEquals(1f, ShellMath.CLOSE_DAMPING, 0f)
        assertTrue(ShellMath.OPEN_DAMPING in 0.7f..1f)
    }

    /** 0.30.2: the opening spring overshoots by far less than the layout's headroom (clampProgress), so the glass never grows past the panel. */
    @Test fun openSpringOvershootsLessThanTheHeadroom() {
        val z = ShellMath.OPEN_DAMPING.toDouble()
        val overshoot = kotlin.math.exp(-Math.PI * z / kotlin.math.sqrt(1.0 - z * z))
        assertTrue("overshoot $overshoot", overshoot < 0.005)
        assertTrue(1f + overshoot.toFloat() < ShellMath.clampProgress(1.4f))
        assertTrue(ShellMath.CLOSE_STIFFNESS >= ShellMath.OPEN_STIFFNESS)
    }

    /** 0.39.0 «Капля»: the glass spreads sideways first; the height starts late and never overtakes the width. */
    @Test fun theDropSpreadsSidewaysBeforeItRises() {
        assertEquals(0f, ShellMath.reachProgress(0f), 0f)
        assertEquals(1f, ShellMath.reachProgress(ShellMath.REACH_DONE_AT), 1e-6f)
        assertEquals(1f, ShellMath.reachProgress(1.03f), 0f)
        assertEquals(0f, ShellMath.reachProgress(-0.1f), 0f)
        assertEquals(0f, ShellMath.riseProgress(0f), 0f)
        assertEquals(0f, ShellMath.riseProgress(ShellMath.RISE_START_AT), 1e-6f)
        assertEquals(1f, ShellMath.riseProgress(1f), 1e-6f)
        assertEquals(1f, ShellMath.riseProgress(1.03f), 0f)
        var reachBefore = 0f
        var riseBefore = 0f
        for (i in 0..100) {
            val p = i / 100f
            val reach = ShellMath.reachProgress(p)
            val rise = ShellMath.riseProgress(p)
            assertTrue("reach is quick at the start", reach >= p - 1e-6f)
            assertTrue("height never overtakes width", rise <= reach + 1e-6f)
            assertTrue("reach only grows", reach >= reachBefore)
            assertTrue("rise only grows", rise >= riseBefore)
            reachBefore = reach
            riseBefore = rise
        }
        // A flat wide pill: at 30 % of the way the width is most of the way there, the height has hardly begun.
        assertTrue(ShellMath.reachProgress(0.3f) > 0.8f)
        assertTrue(ShellMath.riseProgress(0.3f) < 0.05f)
    }

    /** 0.39.0: the cells appear from the middle out, each rank a little after the one before, all whole by the end. */
    @Test fun theCellsAppearFromTheMiddleOutwards() {
        for (rank in 0..2) {
            assertEquals(0f, ShellMath.cellProgress(0f, rank), 0f)
            assertEquals(1f, ShellMath.cellProgress(0.8f, rank), 1e-6f)
            assertEquals(1f, ShellMath.cellProgress(1f, rank), 0f)
        }
        assertEquals(0f, ShellMath.cellProgress(ShellMath.CELL_START, 0), 1e-6f)
        for (i in 1..99) {
            val p = i / 100f
            assertTrue(ShellMath.cellProgress(p, 0) >= ShellMath.cellProgress(p, 1) - 1e-6f)
            assertTrue(ShellMath.cellProgress(p, 1) >= ShellMath.cellProgress(p, 2) - 1e-6f)
        }
        assertTrue(ShellMath.cellProgress(0.5f, 0) > ShellMath.cellProgress(0.5f, 1))
        assertTrue(ShellMath.cellProgress(0.5f, 1) > ShellMath.cellProgress(0.5f, 2))
        // The panel's own alpha has arrived by the time the last cell is whole.
        val lastDone = ShellMath.CELL_START + 2 * ShellMath.CELL_STAGGER + ShellMath.CELL_SPAN
        assertTrue(lastDone < 1f)
        assertTrue(ShellMath.panelAlpha(lastDone) > 0.9f)
    }

    @Test fun theMiddleCellsComeFirst() {
        assertEquals(listOf(1, 0, 0, 1), (0..3).map { ShellMath.cellRank(it, 4) })
        assertEquals(listOf(2, 1, 0, 1, 2), (0..4).map { ShellMath.cellRank(it, 5) })
        assertEquals(0, ShellMath.cellRank(0, 1))
    }

    @Test fun onlyTheQuranAndTheSurahsAreWhitePaperUnderThePanel() {
        assertTrue(ShellRoutes.paperPage(ShellRoutes.routeOf(HomeSection.QURAN)!!))
        assertTrue(ShellRoutes.paperPage(ROUTE_SURAH))
        assertFalse(ShellRoutes.paperPage(ShellRoutes.routeOf(HomeSection.DHIKR)!!))
        assertFalse(ShellRoutes.paperPage("home"))
    }

    /** 0.33.0: every card wears a speaker; this decides which one. Sunrise has no call, whatever the settings hold. */
    @Test fun aCardHasACallOnlyForAPrayerWhoseAzanIsOn() {
        val on = Prayer.entries.associateWith { true }
        val off = Prayer.entries.associateWith { false }
        assertEquals(6, PanelTimes.PRAYERS.size)
        assertEquals(Prayer.SUNRISE, PanelTimes.PRAYERS[1])
        assertFalse(PanelTimes.callOn(Prayer.SUNRISE, on))
        assertFalse(PanelTimes.callOn(Prayer.SUNRISE, off))
        assertFalse(PanelTimes.callOn(Prayer.SUNRISE, emptyMap()))
        listOf(Prayer.FAJR, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA).forEach {
            assertTrue(PanelTimes.callOn(it, on))
            assertFalse(PanelTimes.callOn(it, off))
            // No entry at all is no call, not a crash.
            assertFalse(PanelTimes.callOn(it, emptyMap()))
        }
        assertTrue(PanelTimes.callOn(Prayer.ISHA, mapOf(Prayer.ISHA to true)))
    }
}
