package com.nur.prayer.ui.today

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.nur.prayer.daily.AzkarSet
import com.nur.prayer.daily.DayItem
import com.nur.prayer.daily.DayPlan
import com.nur.prayer.daily.DayTask
import com.nur.prayer.daily.Dhikr
import com.nur.prayer.daily.DhikrPreset
import com.nur.prayer.daily.StoryMath
import com.nur.prayer.daily.Vird
import com.nur.prayer.i18n.L10n
import com.nur.prayer.i18n.tr
import com.nur.prayer.quran.KhatmPlan
import com.nur.prayer.quran.QuranMark
import com.nur.prayer.quran.QuranMath
import com.nur.prayer.ui.components.DoneSeal
import com.nur.prayer.ui.components.GlassCard
import com.nur.prayer.ui.components.Glyph
import com.nur.prayer.ui.components.GlyphKind
import com.nur.prayer.ui.components.NurMotion
import com.nur.prayer.ui.components.Reveal
import com.nur.prayer.ui.components.RevealMath
import com.nur.prayer.ui.components.RollingNumber
import com.nur.prayer.ui.components.RollingText
import com.nur.prayer.ui.components.entrance
import com.nur.prayer.ui.components.pressClick
import com.nur.prayer.ui.daily.Ring
import com.nur.prayer.ui.learn.Gap
import com.nur.prayer.ui.learn.HGap
import com.nur.prayer.ui.learn.textDp
import com.nur.prayer.ui.shell.ShellGlyph
import com.nur.prayer.ui.shell.ShellIcon
import com.nur.prayer.ui.theme.Glass
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.LocalIslandInset
import com.nur.prayer.ui.theme.Mint
import com.nur.prayer.ui.theme.PhasePalette
import com.nur.prayer.ui.theme.SurfaceEdge
import com.nur.prayer.ui.theme.SurfaceInset
import com.nur.prayer.ui.theme.TextPrimary
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.TextTertiary
import com.nur.prayer.ui.theme.uiScale

/** What the «Дела» layer shows; computed by the root from the view models. */
data class TodayState(
    val hijri: String,
    val today: Long,
    val azkarSet: AzkarSet,
    val azkarDone: Int,
    val azkarTotal: Int,
    /** 0.18.5: the vird of the day in its order, and today's count of every dhikr. */
    val vird: List<String>,
    val dhikrToday: Map<String, Long>,
    /** Story slides seen today, one bit each (StoryMath). */
    val storyMask: Int,
    /** Where the Quran reader stopped; null before the first reading. */
    val quranMark: QuranMark? = null,
    /** The khatm plan, null when there is none: the Quran row then shows today's share of it. */
    val quranKhatm: KhatmPlan? = null
)

/** Everything the «Дела» layer can open. Learning, the dictionary and the short surahs live in «Учёба» since 0.40.0. */
class TodayActions(
    val close: () -> Unit,
    val story: (Int) -> Unit,
    /** The reader, on the bookmark (al-Fatiha the first time); its back arrow leads to the contents. */
    val quran: () -> Unit,
    val azkar: () -> Unit,
    /** The one counter: on the given dhikr, or (null) on the first of the vird still open. */
    val dhikr: (String?) -> Unit
)

private val STORY_LABELS = listOf("Аят", "Хадис", "Дуа", "Слово")

/**
 * «Дела», 0.40.0: the page answers two questions in this order — how is my day, and what is next.
 *
 * At the top one card: the ring of the day («2 из 4») and the next task; a tap on it opens that task. Under it the four
 * tasks as ONE list, every row built the same way (a ring with the task's own icon, a name, one line of state, a
 * chevron), so the eye reads down a column instead of across a mosaic of tiles of different shapes. Two rows carry a
 * little more because their task is made of parts: the vird is a ring per dhikr, the story of the day four labelled
 * segments (the same bar the story viewer draws on top). One rule for colour: mint means done, white means in
 * progress; the sky's accent only tints the summary card.
 *
 * What used to be here and is not any more: learning, the word of the day, the dictionary, the short surahs (all in
 * «Учёба»), the qibla and the calendar (in the capsule's panel, where they always were). The page is about the day's
 * tasks only; the logic of «done» and «next» is [DayPlan], tested.
 *
 * It shares one [Reveal] with home: a drag down on its header drives the same number back.
 */
@Composable
fun TodayScreen(state: TodayState, palette: PhasePalette, reveal: Reveal, on: TodayActions) {
    val ui = uiScale()
    val accent = palette.accent
    val pullDown = rememberDraggableState { delta -> reveal.drag(-delta) }
    val items = DayPlan.build(
        state.azkarDone, state.azkarTotal, state.quranKhatm, state.today,
        state.vird, state.dhikrToday, state.storyMask, STORY_LABELS.size
    )
    val open: (DayTask) -> Unit = { task ->
        when (task) {
            DayTask.AZKAR -> on.azkar()
            DayTask.READING -> on.quran()
            DayTask.VIRD -> on.dhikr(null)
            DayTask.STORY -> on.story(StoryMath.firstUnseen(state.storyMask, STORY_LABELS.size))
        }
    }
    Column(Modifier.fillMaxSize().onSizeChanged { reveal.extentPx = it.height.toFloat() }) {
        Column(
            Modifier.fillMaxWidth().padding(top = LocalIslandInset.current).draggable(
                state = pullDown,
                orientation = Orientation.Vertical,
                onDragStarted = { reveal.grab() },
                onDragStopped = { v -> if (reveal.release(-v, RevealMath.SHEET_KEEP_AT)) reveal.settle(true) else on.close() }
            ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.padding(top = 8.dp).width(40.dp).height(5.dp).clip(RoundedCornerShape(50)).background(SurfaceEdge))
            Row(Modifier.fillMaxWidth().padding(horizontal = ui.s(16f), vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("Дела"), color = TextPrimary, fontSize = ui.t(28f), fontWeight = FontWeight.Bold)
                    Text(state.hijri, color = TextSecondary, fontSize = ui.t(13f))
                }
            }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = ui.s(16f)).padding(bottom = LocalDockInset.current + 16.dp)
        ) {
            Gap(4f)
            DaySummary(items, state, accent, Modifier.entrance(0), open)
            Gap(14f)
            GlassCard(Modifier.entrance(1), color = SurfaceInset) {
                TaskRow(
                    item = items[0],
                    title = tr(state.azkarSet.title),
                    status = if (items[0].complete) tr("прочитаны") else tr("прочитано {0} из {1}", state.azkarDone, state.azkarTotal),
                    onClick = on.azkar,
                    icon = { Glyph(if (state.azkarSet == AzkarSet.EVENING) GlyphKind.MOON else GlyphKind.SUN, TextPrimary, Modifier.size(textDp(22f))) }
                )
                RowRule()
                TaskRow(
                    item = items[1],
                    title = tr("Коран"),
                    status = quranStatus(state),
                    onClick = on.quran,
                    icon = { ShellIcon(ShellGlyph.BOOK, TextPrimary, Modifier.size(textDp(22f))) }
                )
                RowRule()
                TaskRow(
                    item = items[2],
                    title = tr("Зикр"),
                    status = dhikrStatus(state, items[2]),
                    onClick = { on.dhikr(null) },
                    icon = { ShellIcon(ShellGlyph.TASBIH, TextPrimary, Modifier.size(textDp(22f))) },
                    extra = { VirdBand(state.vird, state.dhikrToday, on.dhikr) }
                )
                RowRule()
                TaskRow(
                    item = items[3],
                    title = tr("История дня"),
                    status = storyStatus(state.storyMask, items[3]),
                    onClick = { open(DayTask.STORY) },
                    icon = { Glyph(GlyphKind.SPARKLE, TextPrimary, Modifier.size(textDp(22f))) },
                    extra = { StorySegments(state.storyMask, on.story) }
                )
            }
        }
    }
}

/** The name of a task as the page and the summary call it. */
private fun taskTitle(task: DayTask, state: TodayState): String = when (task) {
    DayTask.AZKAR -> tr(state.azkarSet.title)
    DayTask.READING -> tr("Коран")
    DayTask.VIRD -> tr("Зикр")
    DayTask.STORY -> tr("История дня")
}

private fun quranStatus(state: TodayState): String {
    val mark = state.quranMark
    val khatm = state.quranKhatm
    return when {
        // With a khatm the row is its day: pages read of today's share, a ring that closes at the norm.
        khatm != null && khatm.finished -> tr("хатм завершён")
        khatm != null && khatm.doneToday(state.today) -> tr("норма дня выполнена")
        khatm != null -> tr("сегодня {0} из {1} стр.", khatm.readToday(state.today), khatm.goalToday(state.today))
        mark == null -> tr("Аль-Фатиха и все 114 сур")
        else -> tr("{0} · аят {1}", QuranMath.title(QuranMath.surah(mark.surah), L10n.language.code), mark.ayah)
    }
}

private fun dhikrStatus(state: TodayState, item: DayItem): String {
    val said = state.dhikrToday.values.sum()
    return when {
        state.vird.isEmpty() && said > 0 -> tr("сегодня {0}", said)
        state.vird.isEmpty() -> tr("тасбих, салават, истигфар…")
        item.complete -> tr("вирд дня выполнен")
        else -> tr("вирд дня · {0} из {1}", Vird.doneCount(state.vird, state.dhikrToday), state.vird.size)
    }
}

private fun storyStatus(mask: Int, item: DayItem): String {
    val count = STORY_LABELS.size
    val seen = (0 until count).count { StoryMath.isSeen(mask, it) }
    return when {
        item.complete -> tr("просмотрена")
        seen == 0 -> tr("аят, хадис, дуа и слово дня")
        else -> tr("просмотрено {0} из {1}", seen, count)
    }
}

// ── the summary ────────────────────────────────────────────────────────────────────────────────

/**
 * The day in one card: the ring (a smooth average of the tasks, the number inside counts the finished ones) and what
 * to do next. A finished day says so and stops being a button.
 */
@Composable
private fun DaySummary(items: List<DayItem>, state: TodayState, accent: Color, modifier: Modifier, onOpen: (DayTask) -> Unit) {
    val ui = uiScale()
    val done = DayPlan.doneCount(items)
    val total = DayPlan.total(items)
    val all = DayPlan.allDone(items)
    val next = DayPlan.next(items)
    val tone = if (all) Mint else TextPrimary
    val tint by animateColorAsState(if (all) Mint.copy(alpha = 0.16f) else accent.copy(alpha = 0.22f), tween(320), label = "summaryTint")
    GlassCard(modifier, color = Glass) {
        Row(
            Modifier.fillMaxWidth()
                .pressClick(enabled = next != null, scaleTo = 0.98f, shape = RoundedCornerShape(24.dp)) { if (next != null) onOpen(next) }
                .background(tint).padding(ui.s(16f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                Ring(DayPlan.fraction(items), tone, 64.dp, 6.dp)
                AnimatedContent(
                    targetState = all,
                    transitionSpec = { (scaleIn(NurMotion.bouncy(), initialScale = 0.5f) + fadeIn(tween(140))) togetherWith fadeOut(tween(90)) },
                    contentAlignment = Alignment.Center,
                    label = "summaryRing"
                ) { full ->
                    if (full) DoneSeal(Mint, textDp(28f))
                    else Row(verticalAlignment = Alignment.Bottom) {
                        RollingNumber(done, TextPrimary, ui.t(21f))
                        Text("/$total", color = TextTertiary, fontSize = ui.t(12f), modifier = Modifier.padding(bottom = 2.dp))
                    }
                }
            }
            HGap(16f)
            Column(Modifier.weight(1f)) {
                Text(
                    if (all) tr("Дела дня выполнены") else tr("Выполнено {0} из {1}", done, total),
                    color = TextPrimary, fontSize = ui.t(18f), fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                val sub = when {
                    all -> tr("Да примет Аллах.")
                    next != null -> tr("Дальше: {0}", taskTitle(next, state))
                    else -> ""
                }
                if (sub.isNotEmpty()) {
                    Gap(2f)
                    RollingText(sub, TextSecondary, ui.t(14f))
                }
            }
            if (next != null) {
                HGap(8f)
                Glyph(GlyphKind.CHEVRON, TextSecondary, Modifier.size(textDp(14f)))
            }
        }
    }
}

// ── the list ───────────────────────────────────────────────────────────────────────────────────

/** The hairline between the rows of the list, inset like the text it separates. */
@Composable
private fun RowRule() {
    val ui = uiScale()
    Box(Modifier.fillMaxWidth().padding(start = ui.s(78f), end = ui.s(16f)).height(1.dp).background(SurfaceEdge))
}

/**
 * One task of the list. Every row has the same skeleton, so the list reads as one thing; [extra] is what a task made
 * of parts shows under its line (the rings of the vird, the segments of the story).
 */
@Composable
private fun TaskRow(
    item: DayItem,
    title: String,
    status: String,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
    extra: @Composable () -> Unit = {}
) {
    val ui = uiScale()
    Column(Modifier.fillMaxWidth().animateContentSize(NurMotion.gentle())) {
        Row(
            Modifier.fillMaxWidth().pressClick(scaleTo = 1f, onClick = onClick)
                .padding(horizontal = ui.s(16f), vertical = ui.s(14f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TaskBadge(item, icon)
            HGap(14f)
            Column(Modifier.weight(1f)) {
                Text(title, color = TextPrimary, fontSize = ui.t(16f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                // Counts change while you watch (back from a counter): roll, do not blink.
                RollingText(status, if (item.complete) Mint else TextTertiary, ui.t(13f))
            }
            HGap(8f)
            Glyph(GlyphKind.CHEVRON, TextTertiary, Modifier.size(textDp(14f)))
        }
        extra()
    }
}

/**
 * The round mark at the start of a row: the task's progress as a ring around its icon, the seal once it is done.
 * A task without a goal (the Quran with no plan) has a quiet track and nothing to fill.
 */
@Composable
private fun TaskBadge(item: DayItem, icon: @Composable () -> Unit) {
    val tone = if (item.complete) Mint else TextPrimary
    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
        Ring(
            if (item.counted) item.fraction else 0f, tone, 48.dp, 4.dp,
            track = if (item.counted) tone.copy(alpha = 0.22f) else SurfaceEdge
        )
        AnimatedContent(
            targetState = item.complete,
            transitionSpec = { (scaleIn(NurMotion.bouncy(), initialScale = 0.5f) + fadeIn(tween(140))) togetherWith fadeOut(tween(90)) },
            contentAlignment = Alignment.Center,
            label = "taskBadge"
        ) { full ->
            if (full) DoneSeal(Mint, textDp(22f)) else icon()
        }
    }
}

/**
 * The vird of the day under its row: a ring per starred dhikr, filled by today's count towards one round. A tap on a
 * ring opens the counter on that dhikr; an empty vird says how to fill it.
 */
@Composable
private fun VirdBand(vird: List<String>, today: Map<String, Long>, onOpen: (String?) -> Unit) {
    val ui = uiScale()
    if (vird.isEmpty()) {
        Text(
            tr("Отметьте зикры звёздочкой в счётчике — они встанут сюда кольцами"), color = TextTertiary, fontSize = ui.t(12f),
            modifier = Modifier.padding(start = ui.s(78f), end = ui.s(16f), bottom = ui.s(14f))
        )
        return
    }
    Row(Modifier.fillMaxWidth().padding(horizontal = ui.s(8f)).padding(bottom = ui.s(8f))) {
        vird.forEach { id -> VirdRing(Dhikr.preset(id), today[id] ?: 0L, Modifier.weight(1f)) { onOpen(id) } }
    }
}

@Composable
private fun VirdRing(d: DhikrPreset, count: Long, modifier: Modifier, onClick: () -> Unit) {
    val ui = uiScale()
    val done = count >= d.target
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.pressClick(scaleTo = 0.92f, shape = shape, onClick = onClick).padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
            Ring(count / d.target.toFloat(), if (done) Mint else TextPrimary, 56.dp, 5.dp)
            AnimatedContent(
                targetState = done,
                transitionSpec = { (scaleIn(NurMotion.bouncy(), initialScale = 0.5f) + fadeIn(tween(140))) togetherWith fadeOut(tween(90)) },
                contentAlignment = Alignment.Center,
                label = "virdRing"
            ) { full ->
                if (full) DoneSeal(Mint, textDp(22f)) else RollingNumber(count, TextPrimary, ui.t(15f))
            }
        }
        Gap(6f)
        Text(
            d.title, color = if (done) Mint else TextSecondary, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
        )
    }
}

/**
 * The story of the day under its row: one labelled segment per slide, the same bar the viewer draws on top. A seen
 * slide is mint; a tap on a segment opens the viewer on that slide.
 */
@Composable
private fun StorySegments(mask: Int, onOpen: (Int) -> Unit) {
    val ui = uiScale()
    Row(Modifier.fillMaxWidth().padding(horizontal = ui.s(8f)).padding(bottom = ui.s(8f))) {
        STORY_LABELS.forEachIndexed { i, label ->
            val seen = StoryMath.isSeen(mask, i)
            val fill by animateColorAsState(if (seen) Mint else SurfaceEdge, tween(300), label = "storySegment")
            val ink by animateColorAsState(if (seen) Mint else TextSecondary, tween(300), label = "storyLabel")
            Column(
                Modifier.weight(1f).pressClick(scaleTo = 0.94f, shape = RoundedCornerShape(14.dp)) { onOpen(i) }
                    .padding(horizontal = 6.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(50)).background(fill))
                Gap(8f)
                Text(tr(label), color = ink, fontSize = ui.t(12f), fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
        }
    }
}
