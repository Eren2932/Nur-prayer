package com.nur.prayer.ui.qibla

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Pure compass mathematics: no Android types, so it is unit-tested on the JVM instead of being
 * verified by waving a phone around. Everything here is exercised by `HeadingMathTest`.
 */

/**
 * Low-pass filter on the unit vector, not on the angle: immune to the 359°/0° discontinuity.
 * The gain adapts — a big movement is followed almost immediately, a resting phone is averaged
 * hard, which is what kills the jitter you see in cheap compass apps.
 */
internal class HeadingFilter {
    private var sinAcc = Float.NaN
    private var cosAcc = Float.NaN

    /**
     * Forgets the accumulated direction, so the next reading is adopted instantly.
     *
     * This is the fix for the symptom "после кнопки «определить по местоположению» стрелка на пару
     * градусов уезжает вправо-влево". Two things move the true azimuth in one step — a new
     * declination when the coordinates change, and the axis remap when the hold switches between
     * flat and upright. The filter knew nothing about either: it kept averaging towards the *old*
     * direction and crawled to the new one over a second or two, which reads exactly like a compass
     * that cannot make up its mind. After a step change the old average is not data, it is a lie, so
     * it is dropped.
     */
    fun reset() {
        sinAcc = Float.NaN
        cosAcc = Float.NaN
    }

    fun push(degrees: Float): Float {
        val radians = Math.toRadians(degrees.toDouble()).toFloat()
        val s = sin(radians)
        val c = cos(radians)
        if (sinAcc.isNaN()) {
            sinAcc = s
            cosAcc = c
            return normalize(degrees)
        }
        val current = normalize(Math.toDegrees(atan2(sinAcc, cosAcc).toDouble()).toFloat())
        val jump = abs(angleDelta(current, degrees))
        val gain = (0.10f + 0.60f * (jump / 25f).coerceAtMost(1f)).coerceIn(0.10f, 0.70f)
        sinAcc += (s - sinAcc) * gain
        cosAcc += (c - cosAcc) * gain
        return normalize(Math.toDegrees(atan2(sinAcc, cosAcc).toDouble()).toFloat())
    }
}

internal fun normalize(angle: Float): Float = ((angle % 360f) + 360f) % 360f

/** Shortest-path angular interpolation: no 359 -> 0 jump. */
internal fun lerpAngle(from: Float, to: Float, factor: Float): Float {
    val delta = ((to - from + 540f) % 360f) - 180f
    if (abs(delta) < 0.05f) return normalize(to)
    return normalize(from + delta * factor)
}

/** Signed difference in degrees, -180..180. Positive means [to] is clockwise from [from]. */
internal fun angleDelta(from: Float, to: Float): Float = ((to - from + 540f) % 360f) - 180f

/**
 * Median of the last three raw azimuths, on the circle.
 *
 * A magnetometer sample stream is not just noisy, it spikes: a single frame can land ten degrees
 * away when the phone passes a laptop hinge or a car speaker. A low-pass filter *averages* a spike
 * in and then has to walk back out of it — that is the visible twitch. A median simply refuses to
 * pass a lone outlier through, and three samples is the shortest window that has a middle.
 *
 * The median is taken relative to the newest sample so that 359° and 1° stay neighbours instead of
 * being 358 degrees apart.
 */
internal class AzimuthMedian3 {
    private var a = Float.NaN
    private var b = Float.NaN

    fun reset() {
        a = Float.NaN
        b = Float.NaN
    }

    fun push(degrees: Float): Float {
        val current = normalize(degrees)
        if (a.isNaN() || b.isNaN()) {
            b = a
            a = current
            return current
        }
        // Work in signed deltas from the newest sample: -180..180, no wrap inside the window.
        val d0 = 0f
        val d1 = angleDelta(current, a)
        val d2 = angleDelta(current, b)
        val middle = median(d0, d1, d2)
        b = a
        a = current
        return normalize(current + middle)
    }

    private fun median(x: Float, y: Float, z: Float): Float =
        maxOf(minOf(x, y), minOf(maxOf(x, y), z))
}

/**
 * Whether the phone counts as "held upright" now, with hysteresis.
 *
 * One threshold was the bug. `tilt > 55°` decided which axis remap produced the azimuth, and at a
 * hold near 55° the value crosses back and forth several times a second — each crossing is a real,
 * large jump in the computed azimuth, and the arrow visibly shudders while the hand is perfectly
 * still. Two thresholds mean the state must travel 10° to flip back, which no hand tremor does.
 *
 * Entering upright at 60° and leaving at 50° also matches how people actually hold a phone: flat on
 * the palm is 0-20°, reading posture is 45-65°, camera posture is 75-90°.
 */
internal fun uprightAfter(previous: Boolean, tiltDegrees: Float): Boolean =
    if (previous) tiltDegrees > 50f else tiltDegrees > 60f

/** Light low-pass for the tilt read-out, so the bubble level does not flicker on the last digit. */
internal fun smoothTilt(previous: Float, sample: Float): Float =
    if (previous.isNaN()) sample else previous * 0.80f + sample * 0.20f
