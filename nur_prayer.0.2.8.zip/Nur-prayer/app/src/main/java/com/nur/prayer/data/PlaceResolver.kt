package com.nur.prayer.data

import android.content.Context
import com.nur.prayer.Graph
import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.location.ZoneCandidate
import com.nur.prayer.location.ZoneResolver
import com.nur.prayer.location.ZoneSource
import java.time.Instant
import java.time.ZoneId

/**
 * Where the user is, according to the current settings.
 *
 * [zoneExplanation] is not decoration: when the zone is anything other than the phone's own, or when
 * it had to be derived from longitude, the user has a right to read why in "О расчётах" — an hour of
 * silent error is the most expensive bug this app can have.
 */
@androidx.compose.runtime.Immutable
data class Place(
    val label: String,
    val subtitle: String,
    /**
     * Country of the place, and therefore of its calculation profile.
     *
     * Carried on the place rather than looked up again by every caller, because there are two
     * callers — the screens and the alarm scheduler — and they must never disagree about which
     * calendar a notification belongs to.
     */
    val country: String,
    val coordinates: Coordinates,
    val zone: ZoneId,
    val fromDeviceLocation: Boolean,
    val accuracyMeters: Double? = null,
    val zoneSource: ZoneSource = ZoneSource.DEVICE,
    val zoneExplanation: String = ""
)

object PlaceResolver {

    fun resolve(context: Context, settings: AppSettings): Place {
        val repo = Graph.cities(context)
        val city = repo.byId(settings.cityId) ?: City.MOSCOW
        val lat = settings.manualLatitude
        val lon = settings.manualLongitude
        if (!settings.useDeviceLocation || lat == null || lon == null) {
            return Place(
                label = city.name,
                subtitle = city.subtitle,
                country = city.country,
                coordinates = city.coordinates,
                zone = city.zone,
                fromDeviceLocation = false,
                zoneSource = ZoneSource.NEIGHBOURHOOD,
                zoneExplanation = "Город выбран вручную: считаем по его координатам и его поясу " +
                    "(${city.timeZoneId})."
            )
        }

        // The fix itself is the truth. The nearest city only lends its *name*: snapping coordinates
        // to a city centre used to cost up to a minute of error on the edge of a large city, and
        // there is no reason to pay it when the real latitude is in hand.
        val fix = Coordinates(lat, lon)
        val neighbours = repo.nearby(fix, ZoneResolver.NEIGHBOURHOOD_RADIUS_KM)
        val nearest = neighbours.firstOrNull()?.city ?: repo.nearest(fix)
        val decision = ZoneResolver.resolve(
            deviceZone = ZoneId.systemDefault(),
            longitude = lon,
            nearby = neighbours.map { ZoneCandidate(it.city.zone, it.distanceKm) },
            instant = Instant.now()
        )
        val accuracy = settings.locationAccuracyMeters
        val radius = when {
            accuracy == null -> ""
            accuracy < 1000.0 -> " · ±${accuracy.toInt()} м"
            else -> " · ±${"%.1f".format(java.util.Locale.US, accuracy / 1000.0)} км"
        }
        return Place(
            label = nearest.name,
            subtitle = "по геолокации$radius · ${format(lat)}, ${format(lon)}",
            // The nearest city lends its country the same way it lends its name. A fix 30 km from
            // Bukhara is in Uzbekistan and must be computed by the Uzbek calendar even though no
            // coordinate of the database is being used for the arithmetic.
            country = nearest.country,
            coordinates = fix,
            zone = decision.zone,
            fromDeviceLocation = true,
            accuracyMeters = accuracy,
            zoneSource = decision.source,
            zoneExplanation = decision.explanation
        )
    }

    private fun format(value: Double): String = String.format(java.util.Locale.US, "%.3f", value)
}
