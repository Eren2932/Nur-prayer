package com.nur.prayer.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.nur.prayer.ui.components.DockIcon
import com.nur.prayer.ui.components.DockItem
import com.nur.prayer.ui.components.NightSky
import com.nur.prayer.ui.components.NurDock
import com.nur.prayer.ui.home.HomeScreen
import com.nur.prayer.ui.qibla.QiblaScreen
import com.nur.prayer.ui.schedule.ScheduleScreen
import com.nur.prayer.ui.settings.CityPickerScreen
import com.nur.prayer.ui.settings.SettingsScreen
import com.nur.prayer.ui.theme.LocalDockInset
import com.nur.prayer.ui.theme.TextSecondary
import com.nur.prayer.ui.theme.paletteFor
import com.nur.prayer.ui.theme.uiScale

internal const val TAB_HOME = "home"
internal const val TAB_SCHEDULE = "schedule"
internal const val TAB_QIBLA = "qibla"
internal const val TAB_SETTINGS = "settings"
internal const val ROUTE_CITY = "city"

private val TABS = listOf(TAB_HOME, TAB_SCHEDULE, TAB_QIBLA, TAB_SETTINGS)

/**
 * The whole navigation state of the app, in one honest little class.
 *
 * The app used to keep two independent `mutableStateOf` values — the selected tab and an optional
 * overlay route — and nothing was listening to the system back gesture. Compose does not invent a
 * back stack for you: with no [BackHandler] registered, the gesture goes straight to the activity,
 * which finishes. That is why swiping back out of the city list killed the app instead of
 * returning to where you were.
 *
 * Rules implemented here, in the order Android expects them:
 *  - back inside an overlay (city picker) returns to the screen that opened it;
 *  - back on a tab returns to the previously visited tab;
 *  - back on the very first screen of the session is *not* intercepted, so the system does its
 *    normal thing and the app closes. Never swallow that one: an app you cannot leave is worse
 *    than an app that leaves too eagerly.
 *
 * The stack is de-duplicated, so bouncing between two tabs cannot grow it without bound, and it
 * is capped as a second line of defence.
 */
@Stable
internal class NurNavigator(initial: String = TAB_HOME) {

    var current by mutableStateOf(initial)
        private set

    private val stack = mutableStateListOf<String>()

    val canGoBack: Boolean get() = stack.isNotEmpty()

    /** Which dock slot to light up: an overlay keeps the tab underneath highlighted. */
    val selectedTab: String
        get() = if (current in TABS) current else stack.lastOrNull { it in TABS } ?: TAB_HOME

    /** True while a full-screen route is covering the tabs, so the dock hides itself. */
    val isOverlay: Boolean get() = current !in TABS

    fun go(destination: String) {
        if (destination == current) return
        stack.remove(destination)
        stack.add(current)
        while (stack.size > MAX_DEPTH) stack.removeAt(0)
        current = destination
    }

    /** Returns false when there is nothing left to pop, i.e. the system should handle the gesture. */
    fun back(): Boolean {
        val previous = stack.removeLastOrNull() ?: return false
        current = previous
        return true
    }

    private companion object {
        const val MAX_DEPTH = 12
    }
}

@Composable
fun NurRoot(
    data: PrayerData?,
    /**
     * The clock, as state rather than as a value.
     *
     * This signature is the whole performance fix in one line. A `ZonedDateTime` parameter changes
     * every second, so Compose had to invalidate `NurRoot` — and with it the sky, the dock, the
     * `AnimatedContent` and the entire active screen — sixty times a minute. Handed in as a
     * [androidx.compose.runtime.State], nothing recomposes until somebody actually *reads* it, and the
     * only readers left are the countdown digits and one canvas.
     */
    now: androidx.compose.runtime.State<java.time.ZonedDateTime>,
    locating: Boolean,
    /** Result of the last location attempt, shown verbatim; null means "nothing to say yet". */
    locationStatus: String?,
    exactAlarmsAllowed: Boolean,
    citySearch: (String) -> List<com.nur.prayer.data.City>,
    onPickCity: (com.nur.prayer.data.City) -> Unit,
    actionsFactory: (openCityPicker: () -> Unit) -> AppActions
) {
    val nav = remember { NurNavigator() }

    // Enabled only when we actually have somewhere to go back to. When it is disabled the gesture
    // falls through to the activity and the app closes, which is exactly right on the root screen.
    BackHandler(enabled = nav.canGoBack) { nav.back() }

    val ui = uiScale()
    val palette = paletteFor(data?.window?.current ?: com.nur.prayer.core.astro.Prayer.ISHA)
    // Built once: a fresh `AppActions` on every recomposition would defeat the point of marking it
    // immutable, because identity is what Compose compares.
    val actions = remember(actionsFactory) { actionsFactory { nav.go(ROUTE_CITY) } }

    // Every screen pads its own bottom by exactly what the dock occupies, so nothing ever hides
    // behind it — including on devices with a tall gesture bar.
    val systemBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val dockInset = ui.s(66f) + ui.s(26f) + systemBottom

    CompositionLocalProvider(LocalDockInset provides dockInset) {
        Box(modifier = Modifier.fillMaxSize()) {
            NightSky(palette = palette)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
            ) {
                AnimatedContent(
                    targetState = nav.current,
                    /**
                     * Tab switching is a *response*, not a performance.
                     *
                     * The old spec ran 320 ms with a vertical slide. Two costs, and the visible one
                     * is the smaller: for those 320 ms both screens are composed and laid out at
                     * once — the outgoing home screen with its ring and the incoming settings list —
                     * while the slide forces a fresh layer offset every frame. On a mid-range phone
                     * that is the exact moment the tap feels like it "thought about it".
                     *
                     * Now: 70 ms out, then 110 ms in after a 20 ms beat, no slide, `clip = false` so
                     * nothing is re-measured for the animation. The delay is not a pause — it is what
                     * makes the two screens stop being fully opaque at the same time, which is the
                     * only frame range where both trees are composed *and* both are drawn. Total
                     * 130 ms: below the ~150 ms at which a transition starts to read as waiting, and
                     * long enough that the switch is not a jump cut.
                     */
                    transitionSpec = {
                        (fadeIn(tween(110, delayMillis = 20, easing = LinearOutSlowInEasing)) togetherWith
                            fadeOut(tween(70, easing = FastOutLinearInEasing)))
                            .using(SizeTransform(clip = false))
                    },
                    label = "screens",
                    modifier = Modifier.fillMaxSize()
                ) { target ->
                    if (data == null) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Считаем солнце…", color = TextSecondary, fontSize = ui.t(14f))
                        }
                    } else {
                        when (target) {
                            ROUTE_CITY -> CityPickerScreen(
                                palette = palette,
                                selectedCityId = data.settings.cityId,
                                search = citySearch,
                                onPick = { city ->
                                    onPickCity(city)
                                    // Picking a city is a completed task: leave the overlay the
                                    // same way the back gesture would, so the two agree.
                                    nav.back()
                                },
                                onBack = { nav.back() },
                                onUseLocation = { actions.requestLocation() },
                                locating = locating,
                                locationStatus = locationStatus
                            )
                            TAB_SCHEDULE -> ScheduleScreen(data = data, now = now, palette = palette)
                            TAB_QIBLA -> QiblaScreen(data = data, palette = palette)
                            TAB_SETTINGS -> SettingsScreen(
                                data = data,
                                palette = palette,
                                actions = actions,
                                exactAlarmsAllowed = exactAlarmsAllowed,
                                locating = locating,
                                locationStatus = locationStatus
                            )
                            else -> HomeScreen(
                                data = data,
                                now = now,
                                palette = palette,
                                onOpenCity = { nav.go(ROUTE_CITY) }
                            )
                        }
                    }
                }
            }

            if (!nav.isOverlay) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(horizontal = ui.s(18f), vertical = ui.s(12f))
                ) {
                    // Hoisted out of composition: this list is a constant, and allocating a new
                    // one on every pass made the dock unskippable.
                    val dockItems = remember {
                        listOf(
                            DockItem(TAB_HOME, "Намаз", DockIcon.PRAYER),
                            DockItem(TAB_SCHEDULE, "Календарь", DockIcon.CALENDAR),
                            DockItem(TAB_QIBLA, "Кыбла", DockIcon.QIBLA),
                            DockItem(TAB_SETTINGS, "Ещё", DockIcon.SETTINGS)
                        )
                    }
                    NurDock(
                        items = dockItems,
                        selected = nav.selectedTab,
                        onSelect = { nav.go(it) },
                        accent = palette.accent
                    )
                }
            }
        }
    }
}
