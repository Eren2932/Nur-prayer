package com.nur.prayer.data

import android.content.Context
import com.nur.prayer.core.astro.Coordinates
import org.json.JSONArray
import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Offline city database, loaded once from assets. No network, no API keys, works in the metro.
 */
class CityRepository(private val context: Context) {

    private val all: List<City> by lazy { load() }

    /**
     * Search keys, normalised once.
     *
     * The old implementation ran [Normalizer] over every city name and region on every keystroke,
     * allocated a pair per city, then sorted the whole list. That is one normalisation per city plus a
     * full sort per typed character, on the composition thread — the reason the city list shivered
     * while typing. Now folding happens once, at load, and a keystroke is a plain scan over
     * pre-folded strings with a bounded insertion instead of a sort.
     */
    private class Key(val city: City, val name: String, val region: String, val country: String)

    private val keys: List<Key> by lazy {
        all.map { Key(it, fold(it.name), fold(it.region), fold(it.country)) }
    }

    private fun load(): List<City> {
        val json = context.assets.open("cities_ru.json").bufferedReader().use { it.readText() }
        val array = JSONArray(json)
        val result = ArrayList<City>(array.length())
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            result.add(
                City(
                    id = o.getInt("id"),
                    name = o.getString("name"),
                    region = o.getString("region"),
                    // Tolerant on purpose: a settings backup restored from 0.2.5 can still be read,
                    // and the default is the country every row without the field belonged to.
                    country = if (o.has("country")) o.getString("country") else City.HOME_COUNTRY,
                    latitude = o.getDouble("lat"),
                    longitude = o.getDouble("lon"),
                    timeZoneId = o.getString("tz")
                )
            )
        }
        return result
    }

    fun cities(): List<City> = all

    fun byId(id: Int): City? = all.firstOrNull { it.id == id }

    /**
     * [limit] caps the *matches* of a real query, never the idle list.
     *
     * The old default was `take(60)` on a blank query, and that was a data bug wearing the costume
     * of a performance optimisation: the picker said "В базе 60 городов" while the asset held far
     * more, so every city after the sixtieth existed but could not be reached by scrolling — the
     * user had to already know the name to type it. The list is a `LazyColumn`; handing it the
     * whole database costs nothing, because only the visible rows are ever composed.
     */
    fun search(query: String, limit: Int = 200): List<City> {
        val q = fold(query)
        if (q.isBlank()) return all
        // Bucket by score instead of sorting: five buckets, one pass, no comparator, no boxing.
        val buckets = Array(8) { ArrayList<City>(8) }
        var found = 0
        for (key in keys) {
            val score = score(key, q)
            if (score == 0) continue
            buckets[score].add(key.city)
            found++
        }
        if (found == 0) return emptyList()
        val result = ArrayList<City>(minOf(found, limit))
        for (bucket in 7 downTo 1) {
            for (city in buckets[bucket]) {
                if (result.size == limit) return result
                result.add(city)
            }
        }
        return result
    }

    /**
     * An exact name beats a prefix beats a substring; region beats country.
     *
     * Country came last for a reason: "узбекистан" should list all thirty-four Uzbek cities, but a
     * query that also matches a *name* must not be buried under a whole country. Before 0.2.6 the
     * country was not searchable at all — it was hidden inside the region field for foreign rows —
     * so typing a country name returned one city or nothing.
     */
    private fun score(key: Key, q: String): Int = when {
        key.name == q -> 7
        key.name.startsWith(q) -> 6
        key.name.contains(q) -> 5
        key.region.startsWith(q) -> 4
        key.region.contains(q) -> 3
        key.country.startsWith(q) -> 2
        key.country.contains(q) -> 1
        else -> 0
    }

    /** Case/diacritic insensitive, treats "ё" as "е" so that "елец"/"ёлец" both match. */
    private fun fold(value: String): String =
        Normalizer.normalize(value.trim().lowercase(), Normalizer.Form.NFC)
            .replace('ё', 'е')
            .replace('-', ' ')

    /**
     * Known cities around a fix, nearest first, with real distances.
     *
     * Feeds [com.nur.prayer.location.ZoneResolver]: one city is not enough to decide a time zone,
     * because the nearest city to a fix can sit thirteen kilometres away on the *other* side of a
     * zone boundary (Октябрьский и Уруссу). Agreement among the neighbours is the signal; a
     * disagreement means "we are on a boundary, ask the phone".
     */
    fun nearby(coordinates: Coordinates, radiusKm: Double): List<NearbyCity> {
        val result = ArrayList<NearbyCity>(8)
        for (city in all) {
            val km = distanceKm(coordinates, city)
            if (km <= radiusKm) result.add(NearbyCity(city, km))
        }
        result.sortBy { it.distanceKm }
        return result
    }

    private fun distanceKm(from: Coordinates, city: City): Double {
        val f1 = Math.toRadians(from.latitude)
        val f2 = Math.toRadians(city.latitude)
        val df = Math.toRadians(city.latitude - from.latitude)
        val dl = Math.toRadians(city.longitude - from.longitude)
        val h = sin(df / 2) * sin(df / 2) + cos(f1) * cos(f2) * sin(dl / 2) * sin(dl / 2)
        return 2 * 6371.0088 * asin(sqrt(h))
    }

    /** Nearest known city to a GPS fix. Used for the *name* of a place, never for its coordinates. */
    fun nearest(coordinates: Coordinates): City = all.minByOrNull { city ->
        val dLat = abs(city.latitude - coordinates.latitude)
        val dLon = abs(city.longitude - coordinates.longitude) *
            cos(Math.toRadians((city.latitude + coordinates.latitude) / 2))
        dLat * dLat + dLon * dLon
    } ?: City.MOSCOW
}

/** A city and how far it is from the fix, in kilometres. */
data class NearbyCity(val city: City, val distanceKm: Double)
