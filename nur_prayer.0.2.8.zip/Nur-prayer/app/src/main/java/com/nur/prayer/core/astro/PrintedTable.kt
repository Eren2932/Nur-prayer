package com.nur.prayer.core.astro

import java.time.LocalDate
import kotlin.math.floor
import kotlin.math.roundToInt

/**
 * A printed calendar of a religious authority, stored as data and read back verbatim.
 *
 * ### Why a table exists at all in an app that computes astronomy properly
 *
 * Up to 0.2.7 every country was computed: angles, then editorial second-offsets per column
 * ([CalendarConvention]). That is the right model for Russia, where the boards publish rounded
 * astronomy, and it reproduces the Kazan poster on all 28 published values.
 *
 * Uzbekistan does not work that way, and this was measured, not assumed. All 96 month pages of
 * namozvaqti.uz for 2026 were downloaded — eight cities, 17 520 printed values — and compared day
 * by day against Tashkent:
 *
 *     Bomdod, Quyosh        one shared offset per day, spread inside the day exactly 0
 *     Peshin                round(4 * dLongitude) minutes, the same integer all year
 *     Asr, Shom, Xufton     one shared offset per day, spread inside the day exactly 0
 *
 * On every one of the 2 920 city-days. Astronomy cannot produce that: sunrise and Isha at two
 * different latitudes drift apart by different amounts through the season. What produces it is a
 * single printed table — Tashkent — plus a printed offset sheet. That is why 0.2.5, 0.2.6 and
 * 0.2.7 all failed here in the same way: they honestly computed each city, matched Bukhara by luck
 * (it was the city the convention had been calibrated on) and missed Termez by 8 minutes and
 * Tashkent itself by up to 17.
 *
 * So for Uzbekistan the app stops guessing and carries the muftiyat's own numbers.
 *
 * ### What is stored
 *
 * The Tashkent year (365 rows x 6 columns) plus, for a ladder of anchor latitudes, the morning and
 * evening offsets with the longitude term removed. Noon is not stored at all: it is
 * `4 * dLongitude`, which reproduces every published Peshin exactly. 12 KB for the whole country.
 *
 * ### The honest limits, written here rather than in a commit message
 *
 *  - **Latitude, not city.** Offsets are interpolated linearly between anchors. Leave-one-out over
 *    the eight measured cities gives at most 1 minute for any city inside the ladder, and 100 % of
 *    values within a minute. Beyond the ladder extrapolation costs up to 10 minutes, so the ladder
 *    ends at the extreme latitudes of the Uzbek city list (Termez 37.22, Muynak 43.77) and latitude
 *    is clamped instead of extrapolated — every one of the 34 Uzbek cities is inside.
 *  - **One year.** The table is 2026 and it is addressed by day of the year. For other years the
 *    equinox slides by under a quarter of a day, which is worth well under a minute on these
 *    columns, and the app says so in "О расчёте" instead of hiding it.
 *  - **Hanafi.** The printed Asr column is Hanafi. A user who switches to the Shafi'i madhab leaves
 *    the table and gets computed astronomy, because the muftiyat does not publish that column.
 */
class PrintedYearTable internal constructor(
    val year: Int,
    val baseLatitude: Double,
    val baseLongitude: Double,
    private val anchorLatitudes: DoubleArray,
    /** 365 * 6 minutes after local midnight, in [PRINTED_ORDER]. */
    private val base: IntArray,
    private val morning: Array<IntArray>,
    private val evening: Array<IntArray>
) {
    /** Southern end of the latitude ladder; below it the value is clamped, never extrapolated. */
    val southernEdge: Double get() = anchorLatitudes.first()

    /** Northern end of the latitude ladder. */
    val northernEdge: Double get() = anchorLatitudes.last()

    /** True when [latitude] lies inside the ladder, i.e. no clamping was needed. */
    fun covers(latitude: Double): Boolean = latitude in southernEdge..northernEdge

    /**
     * Printed minutes after local midnight for one place and date, in [PRINTED_ORDER].
     *
     * Never null and never throws: latitude is clamped to the ladder, and the date is reduced to a
     * day of the year (29 February shares 28 February's row).
     */
    fun minutes(date: LocalDate, coordinates: Coordinates): IntArray {
        val index = dayIndex(date)
        val latitude = coordinates.latitude.coerceIn(southernEdge, northernEdge)
        val noon = roundHalfUp(4.0 * (baseLongitude - coordinates.longitude))
        val morningOffset = roundHalfUp(interpolate(morning, index, latitude))
        val eveningOffset = roundHalfUp(interpolate(evening, index, latitude))
        val row = index * COLUMNS
        return intArrayOf(
            base[row] + noon + morningOffset,
            base[row + 1] + noon + morningOffset,
            base[row + 2] + noon,
            base[row + 3] + noon + eveningOffset,
            base[row + 4] + noon + eveningOffset,
            base[row + 5] + noon + eveningOffset
        )
    }

    private fun interpolate(offsets: Array<IntArray>, dayIndex: Int, latitude: Double): Double {
        if (latitude <= anchorLatitudes.first()) return offsets.first()[dayIndex].toDouble()
        val last = anchorLatitudes.size - 1
        if (latitude >= anchorLatitudes[last]) return offsets[last][dayIndex].toDouble()
        for (i in 0 until last) {
            val low = anchorLatitudes[i]
            val high = anchorLatitudes[i + 1]
            if (latitude in low..high) {
                if (high - low < 1e-9) return offsets[i][dayIndex].toDouble()
                val t = (latitude - low) / (high - low)
                val a = offsets[i][dayIndex].toDouble()
                val b = offsets[i + 1][dayIndex].toDouble()
                return a + (b - a) * t
            }
        }
        return offsets[last][dayIndex].toDouble()
    }

    companion object {
        /** The six printed columns, in the order they appear in the table and in the asset. */
        val PRINTED_ORDER: List<Prayer> = listOf(
            Prayer.SAHAR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA
        )

        internal const val COLUMNS = 6
        internal const val DAYS = 365

        private val MONTH_START = intArrayOf(
            0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334
        )

        /**
         * Day of the year, 0-364, with 29 February folded onto 28 February.
         *
         * Folding rather than shifting is deliberate: shifting would move every date after February
         * by one row in a leap year, which is a whole day of error, while folding costs one day of
         * error on one day of a leap year.
         */
        internal fun dayIndex(date: LocalDate): Int {
            val month = date.monthValue
            val day = if (month == 2 && date.dayOfMonth == 29) 28 else date.dayOfMonth
            return (MONTH_START[month - 1] + day - 1).coerceIn(0, DAYS - 1)
        }

        /** Half-up, matching `math.floor(x + 0.5)` in `tools/build_uz_table.py`. */
        internal fun roundHalfUp(value: Double): Int = floor(value + 0.5).toInt()

        /**
         * Parses the asset produced by `tools/build_uz_table.py`.
         *
         * Returns null on anything unexpected instead of throwing: a malformed asset must degrade
         * to computed astronomy, never crash a prayer app on launch.
         */
        fun parse(text: String): PrintedYearTable? {
            var year = 0
            var baseLatitude = 0.0
            var baseLongitude = 0.0
            var latitudes = DoubleArray(0)
            val base = IntArray(DAYS * COLUMNS)
            var morning: Array<IntArray>? = null
            var evening: Array<IntArray>? = null
            var version = 0

            var section = ""
            var row = 0
            var anchor = 0

            for (rawLine in text.lineSequence()) {
                val line = rawLine.trim()
                if (line.isEmpty() || line.startsWith("#")) continue
                val parts = line.split(' ')
                when {
                    parts[0] == "NURUZ" -> version = parts.getOrNull(1)?.toIntOrNull() ?: 0
                    parts[0] == "YEAR" -> year = parts.getOrNull(1)?.toIntOrNull() ?: return null
                    parts[0] == "BASE" -> {
                        baseLatitude = parts.getOrNull(1)?.toDoubleOrNull() ?: return null
                        baseLongitude = parts.getOrNull(2)?.toDoubleOrNull() ?: return null
                    }
                    parts[0] == "LATS" -> {
                        latitudes = DoubleArray(parts.size - 1) {
                            parts[it + 1].toDoubleOrNull() ?: return null
                        }
                        if (latitudes.size < 2) return null
                        morning = Array(latitudes.size) { IntArray(DAYS) }
                        evening = Array(latitudes.size) { IntArray(DAYS) }
                    }
                    parts[0] == "TABLE" -> {
                        if ((parts.getOrNull(1)?.toIntOrNull() ?: 0) != DAYS) return null
                        section = "TABLE"
                        row = 0
                    }
                    parts[0] == "MORNING" -> { section = "MORNING"; anchor = 0 }
                    parts[0] == "EVENING" -> { section = "EVENING"; anchor = 0 }
                    parts[0] == "END" -> section = ""
                    section == "TABLE" -> {
                        if (parts.size != COLUMNS || row >= DAYS) return null
                        for (c in 0 until COLUMNS) {
                            base[row * COLUMNS + c] = parts[c].toIntOrNull() ?: return null
                        }
                        row++
                    }
                    section == "MORNING" || section == "EVENING" -> {
                        val target = if (section == "MORNING") morning else evening
                        if (target == null || anchor >= target.size) return null
                        decodeRunLength(line, target[anchor]) ?: return null
                        anchor++
                    }
                }
            }

            val m = morning ?: return null
            val e = evening ?: return null
            if (version != 1 || year == 0 || row != DAYS) return null
            // The ladder must be sorted: the interpolation walks it in order.
            for (i in 1 until latitudes.size) if (latitudes[i] <= latitudes[i - 1]) return null
            return PrintedYearTable(year, baseLatitude, baseLongitude, latitudes, base, m, e)
        }

        /** `v*n,v,...` into [out]; null when the run lengths do not add up to exactly [DAYS]. */
        private fun decodeRunLength(line: String, out: IntArray): Unit? {
            var filled = 0
            for (chunk in line.split(',')) {
                if (chunk.isEmpty()) return null
                val star = chunk.indexOf('*')
                val value: Int
                val count: Int
                if (star < 0) {
                    value = chunk.toIntOrNull() ?: return null
                    count = 1
                } else {
                    value = chunk.substring(0, star).toIntOrNull() ?: return null
                    count = chunk.substring(star + 1).toIntOrNull() ?: return null
                }
                if (count <= 0 || filled + count > out.size) return null
                for (i in 0 until count) out[filled + i] = value
                filled += count
            }
            return if (filled == out.size) Unit else null
        }
    }
}

/**
 * Reads a named asset, returning null when it is absent or unreadable.
 *
 * Top level rather than nested so that it is a plain functional interface everywhere: the app hands
 * over an AssetManager lambda, the tests hand over a classpath lambda.
 */
fun interface PrintedTableSource {
    fun read(name: String): String?
}

/**
 * Registry for printed tables.
 *
 * The engine is pure Kotlin on purpose — every calendar claim in this project is asserted by a JVM
 * unit test, and a test that needs an Android `Context` is a test nobody runs. So the table is
 * *installed* from outside: [com.nur.prayer.NurApplication] hands over the app's asset reader, and
 * the unit tests hand over a classpath reader. With nothing installed the engine simply computes
 * astronomy, exactly as 0.2.7 did.
 */
object PrintedCalendars {

    const val UZBEKISTAN_ASSET: String = "uz_muftiyat_2026.txt"

    /**
     * Bounding box of Uzbekistan, generous by design: the table is a country-wide document, and a
     * device fix a few kilometres over the border still belongs to the same printed calendar. The
     * box only guards against a Kazan or Moscow coordinate reaching the Uzbek table because the
     * user manually picked the Uzbek method.
     */
    private const val MIN_LAT = 36.9
    private const val MAX_LAT = 45.8
    private const val MIN_LON = 55.5
    private const val MAX_LON = 73.4

    private val lock = Any()
    private var source: PrintedTableSource? = null
    private var uzbekistan: PrintedYearTable? = null
    private var uzbekistanLoaded = false

    fun install(source: PrintedTableSource) {
        synchronized(lock) {
            this.source = source
            uzbekistan = null
            uzbekistanLoaded = false
        }
    }

    /** Drops the installed source. Used by tests so one test cannot leak into the next. */
    fun clear() {
        synchronized(lock) {
            source = null
            uzbekistan = null
            uzbekistanLoaded = false
        }
    }

    /** The Uzbek table, or null when no source is installed or the asset is unreadable. */
    fun uzbekistan(): PrintedYearTable? = synchronized(lock) {
        if (!uzbekistanLoaded) {
            uzbekistanLoaded = true
            uzbekistan = source?.read(UZBEKISTAN_ASSET)?.let { PrintedYearTable.parse(it) }
        }
        uzbekistan
    }

    /** True when a coordinate is inside the country the Uzbek table describes. */
    fun insideUzbekistan(coordinates: Coordinates): Boolean =
        coordinates.latitude in MIN_LAT..MAX_LAT && coordinates.longitude in MIN_LON..MAX_LON
}
