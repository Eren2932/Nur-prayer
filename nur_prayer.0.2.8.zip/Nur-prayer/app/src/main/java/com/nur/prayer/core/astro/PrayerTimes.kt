package com.nur.prayer.core.astro

import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import kotlin.math.roundToLong

/**
 * A root within this distance of solar midnight is a tangency, not an event.
 *
 * Ten minutes: wide enough that no genuine dawn or Isha in the city list ever falls inside it (the
 * closest real one is +31 min — Kazan, 9 August 2026), narrow enough that it cannot swallow a true
 * season boundary. Inside this window the twilight arc only grazes the angle, so publishing it
 * would mean printing a "dawn" that is really solar midnight.
 */
private const val TANGENCY_MARGIN_SECONDS = 600L

/**
 * Shortest night that can still carry a printed suhoor window.
 *
 * Two hours thirty-four: a seventh of it is twenty-two minutes, and after the calendar offset (+103 s on the suhoor column) still over twenty, the floor below which a
 * "suhoor ends" line stops being usable — Salekhard on 5 June 2026 got a three-minute window, and
 * Anadyr in mid-June a nineteen-minute one. Arithmetically both are correct, in a mosque neither is.
 * A night below this is treated the way the boards treat it: as no real night at all, and the day is
 * resolved by Aqrab al-Ayyam in [PrayerEngine].
 */
private const val MIN_USABLE_NIGHT_SECONDS = 154L * 60L

/**
 * Where a value ultimately came from. Surfaced in the UI so that a printed minute is never magic.
 */
enum class TimeSource {
    /** True solar depression angle. The normal, correct case. */
    ANGLE,

    /**
     * Read verbatim from a published table of the local religious authority, not computed.
     *
     * Uzbekistan only, so far. See [PrintedYearTable] for why a table beats astronomy there: the
     * muftiyat derives every city from one Tashkent table plus printed offsets, so no per-city
     * angle model can reproduce it — three releases in a row proved that.
     */
    PRINTED_TABLE,

    /** The method itself defines Isha as a fixed interval after sunset (Umm al-Qura, Qatar). */
    METHOD_INTERVAL,

    /** Angle unreachable: fixed interval around sunrise / sunset, the way DUM RF and DUM RT print it. */
    FIXED_INTERVAL,

    /** Angle unreachable: a fraction of the night. */
    NIGHT_FRACTION,

    /** Pulled back to the middle of the night so the daily order stays sane. */
    MIDNIGHT_BOUND,

    /** Congregational time derived from the published sunrise minus a fixed gap. */
    CONGREGATION,

    /** Congregational gap would fall before dawn, so dawn itself was used. */
    DAWN_BOUND
}

/**
 * Prayer times for one calendar day at one location.
 *
 * ### Pipeline, in order, and why the order is load-bearing
 *
 * 1. **Astronomy.** Every solar marker is computed as an exact instant. Nothing is rounded,
 *    nothing is clamped.
 * 2. **High-latitude fallback.** Consulted *only* for a marker that came back undefined, i.e. on
 *    a night when the Sun never sinks to the requested depression angle. It is a fallback, never a
 *    cap. Applying it as a cap was the bug that put Isha in Kazan at 20:37 instead of 21:36 and
 *    silently made every calculation method produce identical output.
 * 3. **Publication.** Method correction, user correction and the [CalendarConvention] offset are
 *    added, then the value is rounded with that column's own rounding mode.
 * 4. **Derived markers.** Congregational [Prayer.FAJR] is computed from the *published* sunrise,
 *    not from the raw instant. This matters: the mosque column of the printed calendar is exactly
 *    the printed sunrise minus 90 minutes, so deriving it from the unrounded value would drift a
 *    minute away on half the days of the year.
 * 5. **Order.** A strictly increasing sequence is enforced last.
 */
class PrayerTimes(
    val date: LocalDate,
    val coordinates: Coordinates,
    val params: PrayerParams,
    /**
     * Time zone the day belongs to. Only its UTC offset is used, to pin the solar frame to the
     * local day — see [SolarTime]. Defaults to UTC so existing call sites keep working; every
     * caller that knows the city's zone should pass it.
     */
    val zone: ZoneId = ZoneOffset.UTC
) {
    val times: Map<Prayer, Instant?>

    /** True when Sahar and/or Isha had to be derived from something other than the angle. */
    val usedHighLatitudeRule: Boolean

    /** Provenance of the markers that can need help. */
    val saharSource: TimeSource
    val ishaSource: TimeSource
    val fajrSource: TimeSource

    /** Length of the night following [date], null in the polar case. */
    val night: Duration?

    /** Length of the night that ends at this morning's sunrise, the one Sahar belongs to. */
    val morningNight: Duration?

    /**
     * True when a night exists but is too short to publish honestly (white-night season above
     * roughly 66°). Callers must treat such a day like a polar one and fall back to Aqrab al-Ayyam.
     */
    val nightUnusable: Boolean

    init {
        val base = date.atStartOfDay(ZoneOffset.UTC).toInstant()
        val tomorrowBase = date.plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant()
        // Hours from this frame's origin to local noon. Pins every solar root to the day the user
        // is looking at instead of to the UTC day; without it, cities whose solar noon sits near
        // the UTC day boundary (Anadyr) silently shift a whole day back and forth.
        val anchorHours =
            Duration.between(base, date.atTime(12, 0).atZone(zone).toInstant()).seconds / 3600.0
        val solar = SolarTime.of(date, coordinates, anchorHours)
        val tomorrowSolar = SolarTime.of(date.plusDays(1), coordinates, anchorHours)
        // Yesterday's Sun matters as much as tomorrow's: Sahar belongs to the night that *ends* at
        // this morning's sunrise, and that night began with yesterday's sunset. The two nights are
        // interchangeable in the middle of the country and are not interchangeable at all where
        // sunset itself falls after midnight — Novy Urengoy in July sets at 00:01 — which is how
        // "sunrise - 120 min" ended up in front of its own sunset.
        val yesterdaySolar = SolarTime.of(date.minusDays(1), coordinates, anchorHours)

        fun hoursToInstant(from: Instant, hours: Double): Instant? =
            if (hours.isNaN() || hours.isInfinite()) null
            else from.plusMillis((hours * 3600_000.0).roundToLong())

        val sunriseTime = hoursToInstant(base, solar.sunrise)
        val sunsetTime = hoursToInstant(base, solar.sunset)
        val transitTime = hoursToInstant(base, solar.transit)
        val tomorrowSunrise = hoursToInstant(tomorrowBase, tomorrowSolar.sunrise)
        val yesterdayBase = date.minusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant()
        val yesterdaySunset = hoursToInstant(yesterdayBase, yesterdaySolar.sunset)

        val method = params.method

        // ---- Step 1: pure astronomy -------------------------------------------------------
        var saharTime = hoursToInstant(base, solar.hourAngle(-method.fajrAngle, afterTransit = false))
        var saharFrom = TimeSource.ANGLE

        var asrTime = hoursToInstant(base, solar.afternoon(params.madhab.shadowLength))

        val maghribTime = if (method.maghribAngle > 0.0) {
            hoursToInstant(base, solar.hourAngle(-method.maghribAngle, afterTransit = true)) ?: sunsetTime
        } else {
            sunsetTime
        }

        var ishaTime: Instant?
        var ishaFrom: TimeSource
        // Interval-defined markers are recomputed from the published anchor in step 4; the raw
        // value here only exists so the fallback logic and the ordering pass have something real
        // to compare against.
        var saharBeforeSunrise: Int? = null
        var ishaAfterSunset: Int? = null
        if (method.ishaIntervalMinutes > 0) {
            ishaTime = sunsetTime?.plusSeconds(method.ishaIntervalMinutes * 60L)
            ishaAfterSunset = method.ishaIntervalMinutes
            ishaFrom = TimeSource.METHOD_INTERVAL
        } else {
            ishaTime = hoursToInstant(base, solar.hourAngle(-method.ishaAngle, afterTransit = true))
            ishaFrom = TimeSource.ANGLE
        }

        // ---- Step 2: help only where astronomy came back empty -----------------------------
        //
        // "Came back empty" is not the same as "returned a number". The root finder decides
        // reachability from the declination at transit, so on a tangency night it returns a root
        // sitting on the *descending* branch — an evening crossing dressed up as a dawn. Kazan,
        // 8 August 2026: the Sun bottoms out at -17.976°, never reaching the 18° dawn angle, and
        // the raw root comes back as 23:46:30 the previous evening. That is what printed a 23:49
        // suhoor beside a 02:31 Fajr, and clamping it to the middle of the night only hid it.
        //
        // A morning root is a dawn only if it happens after solar midnight; an evening root is
        // Isha only if it happens before it. The margin also discards a root that merely grazes
        // the angle around solar midnight: there twilight never truly ends, and the interval the
        // board prints is the honest answer.
        val nadirBefore = hoursToInstant(base, solar.transit - 12.0)
        val nadirAfter = hoursToInstant(base, solar.transit + 12.0)
        if (saharTime != null && nadirBefore != null &&
            saharTime!!.isBefore(nadirBefore.plusSeconds(TANGENCY_MARGIN_SECONDS))
        ) {
            saharTime = null
        }
        if (ishaFrom == TimeSource.ANGLE && ishaTime != null && nadirAfter != null &&
            ishaTime!!.isAfter(nadirAfter.minusSeconds(TANGENCY_MARGIN_SECONDS))
        ) {
            ishaTime = null
        }

        var nightLength: Duration? = null
        var morningNightLength: Duration? = null
        if (sunriseTime != null && sunsetTime != null && tomorrowSunrise != null) {
            val nightSpan = Duration.between(sunsetTime, tomorrowSunrise)
            nightLength = nightSpan
            val nightSeconds = nightSpan.seconds
            // The night Sahar lives in, as opposed to the night Isha lives in.
            val morningNightSeconds = yesterdaySunset
                ?.let { Duration.between(it, sunriseTime).seconds }
                ?: nightSeconds
            morningNightLength = Duration.ofSeconds(morningNightSeconds)
            val rule = params.highLatitudeRule.resolve(coordinates.latitude)

            fun fraction(): Pair<Double, Double> = when (rule) {
                HighLatitudeRule.SEVENTH_OF_THE_NIGHT -> 1.0 / 7.0 to 1.0 / 7.0
                HighLatitudeRule.TWILIGHT_ANGLE ->
                    method.fajrAngle / 60.0 to (if (method.ishaAngle > 0) method.ishaAngle else 17.0) / 60.0
                else -> 0.5 to 0.5
            }

            // The Russian boards treat the short-night season as one regime: the printed calendar
            // carries a single banner, "МЕНЯЕТСЯ ВРЕМЯ СУХУРА И ИША", and moves both markers
            // together rather than letting each one leave on its own day. The season is judged by
            // the Sahar angle — the stricter of the two — over *this* night and the *next* one.
            // That second look reproduces the calendar's own asymmetry: on the last day of the
            // season Isha is already astronomical while Sahar is still an interval, because the
            // night that follows is finally long enough. Verified on 7 August 2026 in Kazan.
            val tomorrowNadir = hoursToInstant(tomorrowBase, tomorrowSolar.transit - 12.0)
            val saharAngleTomorrow = hoursToInstant(
                tomorrowBase,
                tomorrowSolar.hourAngle(-method.fajrAngle, afterTransit = false)
            )
            val tomorrowUsable = saharAngleTomorrow != null && tomorrowNadir != null &&
                !saharAngleTomorrow.isBefore(tomorrowNadir.plusSeconds(TANGENCY_MARGIN_SECONDS))
            val shortNightSeason = rule == HighLatitudeRule.FIXED_INTERVAL &&
                saharTime == null && !tomorrowUsable

            // A printed interval silently assumes a night long enough to hold it. The poster wants
            // suhoor 120 minutes before sunrise and Isha 90 after sunset — 210 minutes of night,
            // plus a little air between them. In the white-night season that night no longer exists:
            // Murmansk on 19 May 2026 has 106 minutes of it, and "sunrise − 120" then lands *before
            // the previous sunset* — suhoor ending before the fast begins.
            //
            // So the intervals are kept exactly as printed whenever they fit, and only when they do
            // not are both scaled by the same factor into the night that actually exists, keeping a
            // quarter of an hour between Isha and suhoor. Nights shorter than
            // [MIN_USABLE_NIGHT_SECONDS] never reach this code: they are declared unpublishable and
            // resolved by Aqrab al-Ayyam instead.
            val breathingRoomSeconds = 15L * 60L
            val wantedSahar = method.nightFajrMinutes * 60L
            val wantedIsha = method.nightIshaMinutes * 60L
            val wantedTotal = (wantedSahar + wantedIsha).toDouble()
            // Each marker is judged against its own night, and the tighter of the two decides the
            // scale so that Isha and Sahar keep the proportion the poster prints between them.
            val tightestNight = minOf(nightSeconds, morningNightSeconds)
            val intervalsFit = wantedSahar + wantedIsha + breathingRoomSeconds <= tightestNight
            val squeeze =
                if (intervalsFit) 1.0
                else (tightestNight - breathingRoomSeconds).toDouble() / wantedTotal

            if (saharTime == null) {
                if (rule == HighLatitudeRule.FIXED_INTERVAL) {
                    if (intervalsFit) {
                        saharTime = sunriseTime.minusSeconds(wantedSahar)
                        saharBeforeSunrise = method.nightFajrMinutes
                        saharFrom = TimeSource.FIXED_INTERVAL
                    } else {
                        saharTime = sunriseTime.minusSeconds((wantedSahar * squeeze).roundToLong())
                        saharFrom = TimeSource.NIGHT_FRACTION
                    }
                } else {
                    saharTime = sunriseTime.minusSeconds((nightSeconds * fraction().first).roundToLong())
                    saharFrom = TimeSource.NIGHT_FRACTION
                }
            }
            if (ishaTime == null || (shortNightSeason && ishaFrom == TimeSource.ANGLE)) {
                if (rule == HighLatitudeRule.FIXED_INTERVAL) {
                    if (intervalsFit) {
                        ishaTime = sunsetTime.plusSeconds(wantedIsha)
                        ishaAfterSunset = method.nightIshaMinutes
                        ishaFrom = TimeSource.FIXED_INTERVAL
                    } else {
                        ishaTime = sunsetTime.plusSeconds((wantedIsha * squeeze).roundToLong())
                        ishaFrom = TimeSource.NIGHT_FRACTION
                    }
                } else {
                    ishaTime = sunsetTime.plusSeconds((nightSeconds * fraction().second).roundToLong())
                    ishaFrom = TimeSource.NIGHT_FRACTION
                }
            }

            // Last-resort guard. With the tangency test and the local-noon anchor above, this no
            // longer fires anywhere in the city list across a full year (verified for six methods,
            // 381 060 city-days). It stays so that a future method with an exotic angle cannot
            // publish a marker outside its own night — but it never overrides an interval the
            // board itself prints, which is what turned a 02:01 suhoor into 23:49.
            val saharFloor = sunriseTime.minusSeconds(nightSeconds / 2)
            val ishaCeiling = sunsetTime.plusSeconds(nightSeconds / 2)
            saharTime?.let {
                if (it.isBefore(saharFloor) && saharBeforeSunrise == null) {
                    saharTime = saharFloor; saharFrom = TimeSource.MIDNIGHT_BOUND
                }
            }
            ishaTime?.let {
                if (it.isAfter(ishaCeiling) && ishaAfterSunset == null) {
                    ishaTime = ishaCeiling; ishaFrom = TimeSource.MIDNIGHT_BOUND
                }
            }
        }

        // Asr can be undefined at high latitudes in winter: the Sun never climbs high enough.
        var asrDegraded = false
        if (asrTime == null) {
            asrTime = hoursToInstant(base, solar.afternoon(Madhab.STANDARD.shadowLength))
            if (asrTime != null) asrDegraded = true
        }
        if (asrTime == null && transitTime != null && maghribTime != null) {
            val span = Duration.between(transitTime, maghribTime).seconds
            asrTime = transitTime.plusSeconds(span * 2 / 3)
            asrDegraded = true
        }

        // ---- Step 3: publication ----------------------------------------------------------
        fun publish(prayer: Prayer, value: Instant?): Instant? {
            if (value == null) return null
            val policy = params.policy(prayer)
            val shifted = value.plusSeconds(
                params.adjustmentMinutes(prayer) * 60L + policy.offsetSeconds
            )
            return roundToMinute(shifted, policy.rounding)
        }

        val publishedSunrise = publish(Prayer.SUNRISE, sunriseTime)
        val publishedMaghrib = publish(Prayer.MAGHRIB, maghribTime)

        // An interval marker keeps its exact relationship to the *printed* anchor. The poster says
        // Sahar is sunrise minus 120 minutes and Isha is sunset plus 90; if we derived them from the
        // raw instant, each anchor's own rounding would leak in a second time and the printed gap
        // would come out as 119 or 121 on about half the days of the season.
        val saharGap = saharBeforeSunrise
        val publishedSahar = if (saharGap != null && publishedSunrise != null) {
            publishedSunrise.minusSeconds(saharGap * 60L)
                .plusSeconds(params.adjustmentMinutes(Prayer.SAHAR) * 60L)
        } else {
            publish(Prayer.SAHAR, saharTime)
        }
        val ishaGap = ishaAfterSunset
        val publishedIsha = if (ishaGap != null && publishedMaghrib != null) {
            publishedMaghrib.plusSeconds(ishaGap * 60L)
                .plusSeconds(params.adjustmentMinutes(Prayer.ISHA) * 60L)
        } else {
            publish(Prayer.ISHA, ishaTime)
        }

        // ---- Step 4: congregational Fajr, derived from the published sunrise ---------------
        val gap = params.fajrBeforeSunriseMinutes
        var fajrFrom: TimeSource
        val publishedFajr: Instant? = when {
            publishedSunrise == null || gap == 0 -> {
                fajrFrom = if (gap == 0) TimeSource.ANGLE else saharFrom
                publishedSahar
            }
            else -> {
                val candidate = publishedSunrise.minusSeconds(gap * 60L)
                // Fajr may never precede dawn: at low latitudes the 90 minute gap would do exactly
                // that, and praying before dawn is invalid regardless of what any table says.
                if (publishedSahar != null && candidate.isBefore(publishedSahar)) {
                    fajrFrom = TimeSource.DAWN_BOUND
                    publishedSahar
                } else {
                    fajrFrom = TimeSource.CONGREGATION
                    candidate.plusSeconds(params.adjustmentMinutes(Prayer.FAJR) * 60L)
                }
            }
        }

        saharSource = saharFrom
        ishaSource = ishaFrom
        fajrSource = fajrFrom
        night = nightLength
        morningNight = morningNightLength
        // A day is unpublishable when *either* of its two nights is too short: Sahar reads the one
        // that ends at sunrise, Isha the one that starts at sunset, and both are on screen at once.
        val shortest = listOfNotNull(nightLength, morningNightLength).minByOrNull { it.seconds }
        nightUnusable = shortest != null && shortest.seconds < MIN_USABLE_NIGHT_SECONDS
        usedHighLatitudeRule = asrDegraded ||
            saharFrom != TimeSource.ANGLE ||
            (ishaFrom != TimeSource.ANGLE && ishaFrom != TimeSource.METHOD_INTERVAL)

        val raw = linkedMapOf(
            Prayer.SAHAR to publishedSahar,
            Prayer.FAJR to publishedFajr,
            Prayer.SUNRISE to publishedSunrise,
            Prayer.DHUHR to publish(Prayer.DHUHR, transitTime),
            Prayer.ASR to publish(Prayer.ASR, asrTime),
            Prayer.MAGHRIB to publishedMaghrib,
            Prayer.ISHA to publishedIsha
        )
        times = enforceOrder(raw)
    }

    /** Kept for source compatibility with callers written before Sahar existed. */
    @Deprecated("Use saharSource for dawn or fajrSource for the congregational time")
    val legacyFajrSource: TimeSource get() = saharSource

    /**
     * Guarantees a strictly increasing sequence with at least one minute between markers.
     * The UI and the alarm chain both rely on a strict order.
     */
    private fun enforceOrder(source: Map<Prayer, Instant?>): Map<Prayer, Instant?> {
        val result = LinkedHashMap<Prayer, Instant?>(source)
        val order = listOf(
            Prayer.SAHAR, Prayer.FAJR, Prayer.SUNRISE,
            Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA
        )
        // Sunrise is the hard anchor of the morning: pull Fajr and Sahar back under it if a
        // pathological correction pushed them past it.
        val sunrise = result[Prayer.SUNRISE]
        if (sunrise != null) {
            result[Prayer.FAJR]?.let { if (!it.isBefore(sunrise)) result[Prayer.FAJR] = sunrise.minusSeconds(60) }
            val fajr = result[Prayer.FAJR] ?: sunrise
            result[Prayer.SAHAR]?.let { if (it.isAfter(fajr)) result[Prayer.SAHAR] = fajr }
        }
        var previous: Instant? = null
        for (prayer in order) {
            val value = result[prayer] ?: continue
            val bound = previous
            // Sahar and Fajr are allowed to share a minute: in traditions without a separate
            // congregational time they are genuinely the same instant.
            val mustBeStrictlyAfter = !(prayer == Prayer.FAJR && bound == result[Prayer.SAHAR])
            if (bound != null && mustBeStrictlyAfter && !value.isAfter(bound)) {
                result[prayer] = bound.plusSeconds(60)
            } else if (bound != null && value.isBefore(bound)) {
                result[prayer] = bound
            }
            previous = result[prayer]
        }
        return result
    }

    val isComplete: Boolean get() = times.values.none { it == null }

    /** Complete *and* publishable: every marker exists and the night was long enough to hold them. */
    val isPublishable: Boolean get() = isComplete && !nightUnusable

    private fun roundToMinute(instant: Instant, mode: RoundingMode): Instant {
        val seconds = instant.epochSecond
        val remainder = ((seconds % 60) + 60) % 60
        val floor = seconds - remainder
        val result = when (mode) {
            RoundingMode.DOWN -> floor
            RoundingMode.UP -> if (remainder == 0L) floor else floor + 60
            RoundingMode.NEAREST -> if (remainder >= 30L) floor + 60 else floor
        }
        return Instant.ofEpochSecond(result)
    }
}
