package com.nur.prayer

import android.app.Application
import com.nur.prayer.core.astro.PrintedCalendars
import com.nur.prayer.data.CityRepository
import com.nur.prayer.data.SettingsRepository
import com.nur.prayer.notify.NotificationHelper

class NurApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        instance = this

        /*
         * The printed tables are installed here, once, and read lazily on first use.
         *
         * The engine is pure Kotlin so that every calendar claim can be locked by a JVM unit test,
         * which means it cannot reach into `assets` itself. This is the one line that connects the
         * two, and `runCatching` is deliberate: a missing or damaged asset must fall back to
         * computed astronomy, never take down the launch of a prayer app.
         */
        val assetManager = assets
        PrintedCalendars.install { name ->
            runCatching {
                assetManager.open(name).bufferedReader().use { reader -> reader.readText() }
            }.getOrNull()
        }

        NotificationHelper.createChannels(this)
    }

    companion object {
        lateinit var instance: NurApplication
            private set
    }
}

/** Tiny hand-rolled service locator: no DI framework, no build-time codegen, instant builds. */
object Graph {
    private var cityRepo: CityRepository? = null
    private var settingsRepo: SettingsRepository? = null

    fun cities(context: android.content.Context): CityRepository =
        cityRepo ?: CityRepository(context.applicationContext).also { cityRepo = it }

    fun settings(context: android.content.Context): SettingsRepository =
        settingsRepo ?: SettingsRepository(context.applicationContext).also { settingsRepo = it }
}
