package com.nur.prayer.data

import com.nur.prayer.core.astro.Coordinates
import java.time.ZoneId

/**
 * One row of the offline database.
 *
 * [country] arrived in 0.2.6 and is not cosmetic. Until then the foreign entries carried the country
 * *in the region field* ("Ташкент" had region "Узбекистан"), which had two consequences: the picker
 * could not group anything, and a search for "узбекистан" matched exactly one row while thirty-three
 * Uzbek cities sat in the list. Region now always means region, country always means country.
 */
@androidx.compose.runtime.Immutable
data class City(
    val id: Int,
    val name: String,
    val region: String,
    val country: String,
    val latitude: Double,
    val longitude: Double,
    val timeZoneId: String
) {
    val coordinates: Coordinates get() = Coordinates(latitude, longitude)
    val zone: ZoneId get() = ZoneId.of(timeZoneId)

    /** Second line of a picker row: the region, plus the country when it is not the default one. */
    val subtitle: String
        get() = if (country == HOME_COUNTRY || region == country) region else "$region · $country"

    companion object {
        const val HOME_COUNTRY = "Россия"
        val MOSCOW = City(1, "Москва", "Москва", HOME_COUNTRY, 55.7558, 37.6173, "Europe/Moscow")
    }
}
