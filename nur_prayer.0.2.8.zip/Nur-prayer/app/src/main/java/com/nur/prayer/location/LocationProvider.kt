package com.nur.prayer.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.nur.prayer.core.astro.Coordinates
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/**
 * What came of pressing "Определить по местоположению".
 *
 * 0.2.5 returned `Coordinates?`, so every failure — no permission, location switched off in the
 * system, nothing but a stale cell fix, a device that simply never answers indoors — arrived as the
 * same `null`, and the screen had nothing to say beyond turning the button back on. A user who is
 * not told what went wrong presses the button again. And again.
 */
sealed interface LocationOutcome {

    /**
     * A usable fix. [accuracyMeters] is the device's own 68 % confidence radius, [provider] is who
     * produced it, [ageMillis] how old it was when accepted — all three are shown to the user,
     * because "определено" without a radius is a promise the phone never made.
     */
    data class Fix(
        val coordinates: Coordinates,
        val accuracyMeters: Float,
        val ageMillis: Long,
        val provider: String,
        val timeMillis: Long
    ) : LocationOutcome

    data object NoPermission : LocationOutcome
    data object LocationDisabled : LocationOutcome
    data object TimedOut : LocationOutcome
    data object Unavailable : LocationOutcome
}

/**
 * Location without Google Play Services: plain [LocationManager], so the APK stays tiny and works on
 * any device, including AOSP builds and Huawei.
 *
 * ### What was wrong before (0.2.5)
 *
 * The old implementation looked reasonable and quietly did the wrong thing four times over:
 *
 *  * it *preferred* `NETWORK_PROVIDER` because it answers faster. A network fix is triangulated from
 *    cell towers and Wi-Fi: one to three kilometres in a city. For prayer times that is minutes of
 *    error, and for the Qibla arrow it is degrees;
 *  * a cached fix was accepted on age alone (under thirty minutes), never on accuracy — a stale
 *    3 km estimate beat a fresh satellite one;
 *  * there was no deadline. Indoors, with a single listener registered and no satellites, the button
 *    could sit on "Определяем координаты…" until the app was restarted;
 *  * it listened to one provider. If that one was the enabled-but-mute one, nothing ever arrived.
 *
 * ### Now
 *
 * Both providers are asked at once and their answers compete on a single score: metres of accuracy
 * plus half a metre per second of age. Whoever wins, wins — GPS usually does, the network fix covers
 * the case where the sky is not visible. The race ends early the moment something lands inside
 * [TARGET_ACCURACY_METERS], and it always ends by [DEADLINE_MILLIS]; the best candidate so far is
 * returned rather than thrown away. The cached last-known fix enters the same competition instead of
 * short-circuiting it, so it can only win when it is genuinely better than what the sensors produced.
 */
class LocationProvider(private val context: Context) {

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    suspend fun current(): LocationOutcome {
        if (!hasPermission()) return LocationOutcome.NoPermission
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return LocationOutcome.Unavailable

        val live = LIVE_PROVIDERS.filter { enabled(manager, it) }
        val cached = LIVE_PROVIDERS.plus(LocationManager.PASSIVE_PROVIDER)
            .asSequence()
            .mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }
            .filter { plausible(it) }
            .minByOrNull { score(it) }

        if (live.isEmpty()) {
            // Location is off system-wide. A cached fix is still worth offering, but only a good one:
            // an hour-old tower estimate is not what the user asked for by pressing the button.
            val salvage = cached?.takeIf { score(it) <= SALVAGE_SCORE }
            return salvage?.let { outcome(it) } ?: LocationOutcome.LocationDisabled
        }

        // A cached fix that is both precise and minutes old is the real answer, and asking the
        // satellites again would only cost the user twelve seconds to learn the same thing.
        if (cached != null && cached.accuracy <= TARGET_ACCURACY_METERS &&
            age(cached) <= FRESH_ENOUGH_MILLIS
        ) {
            return outcome(cached)
        }

        val fresh = race(manager, live)
        val best = listOfNotNull(fresh, cached).minByOrNull { score(it) }
        return when {
            best == null -> LocationOutcome.TimedOut
            score(best) > SALVAGE_SCORE -> LocationOutcome.TimedOut
            else -> outcome(best)
        }
    }

    private fun enabled(manager: LocationManager, provider: String): Boolean =
        runCatching { manager.isProviderEnabled(provider) }.getOrDefault(false)

    /**
     * One race, two runners, one deadline.
     *
     * Both listeners write into the same `best`, and the winner is decided by [score] rather than by
     * arrival order — that single change is what stops a 2 km tower estimate from beating a satellite
     * fix that was three seconds slower.
     */
    @SuppressLint("MissingPermission")
    private suspend fun race(manager: LocationManager, providers: List<String>): Location? =
        suspendCancellableCoroutine { continuation ->
            val handler = Handler(Looper.getMainLooper())
            val settled = AtomicBoolean(false)
            var best: Location? = null
            var timeout: Runnable? = null
            var listener: android.location.LocationListener? = null

            fun settle() {
                if (!settled.compareAndSet(false, true)) return
                listener?.let { active -> runCatching { manager.removeUpdates(active) } }
                timeout?.let { handler.removeCallbacks(it) }
                if (continuation.isActive) continuation.resume(best)
            }

            val racer = object : android.location.LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (!plausible(location)) return
                    val current = best
                    if (current == null || score(location) < score(current)) best = location
                    val leader = best ?: return
                    if (leader.accuracy in 0.1f..TARGET_ACCURACY_METERS) settle()
                }

                @Deprecated("Required by the old interface")
                override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) = Unit

                override fun onProviderEnabled(provider: String) = Unit

                // Deliberately not settling here: the *other* provider may still deliver, and the
                // deadline already guarantees this call returns.
                override fun onProviderDisabled(provider: String) = Unit
            }
            listener = racer
            val task = Runnable { settle() }
            timeout = task
            handler.postDelayed(task, DEADLINE_MILLIS)

            var registered = false
            providers.forEach { provider ->
                runCatching {
                    manager.requestLocationUpdates(provider, 0L, 0f, racer, Looper.getMainLooper())
                }.onSuccess { registered = true }
            }
            if (!registered) settle()
            continuation.invokeOnCancellation { settle() }
        }

    private fun outcome(location: Location): LocationOutcome.Fix = LocationOutcome.Fix(
        coordinates = Coordinates(location.latitude, location.longitude),
        accuracyMeters = if (location.hasAccuracy()) location.accuracy else UNKNOWN_ACCURACY_METERS,
        ageMillis = age(location),
        provider = location.provider ?: "?",
        timeMillis = location.time
    )

    private fun age(location: Location): Long =
        (System.currentTimeMillis() - location.time).coerceAtLeast(0L)

    /** Lower is better: metres of radius, plus half a metre for every second of staleness. */
    private fun score(location: Location): Double {
        val accuracy = if (location.hasAccuracy()) location.accuracy.toDouble() else UNKNOWN_ACCURACY_METERS.toDouble()
        return accuracy + age(location) / 1000.0 * AGE_PENALTY_METERS_PER_SECOND
    }

    /** Guards against the 0,0 fix and against garbage that some ROMs report on a cold start. */
    private fun plausible(location: Location): Boolean =
        location.latitude in -90.0..90.0 && location.longitude in -180.0..180.0 &&
            !(location.latitude == 0.0 && location.longitude == 0.0) &&
            location.time > 0L

    companion object {
        /** Good enough to stop early: forty metres is far below the width of a city block. */
        const val TARGET_ACCURACY_METERS = 40f

        /** Hard ceiling on the wait. Twelve seconds is long enough for a warm GPS lock indoors. */
        const val DEADLINE_MILLIS = 12_000L

        /** A cached fix this fresh, if it is also precise, is taken without waking the sensors. */
        const val FRESH_ENOUGH_MILLIS = 5 * 60 * 1000L

        /**
         * Worst score still worth showing, in metres-equivalent. Three kilometres of radius is a
         * tower estimate; times computed from it are off by up to ten seconds, which is honest, but
         * the user is told the radius so the choice is theirs.
         */
        const val SALVAGE_SCORE = 3_000.0

        /** A fix without a radius is treated as mediocre rather than trusted or discarded. */
        const val UNKNOWN_ACCURACY_METERS = 1_500f

        const val AGE_PENALTY_METERS_PER_SECOND = 0.5

        private val LIVE_PROVIDERS = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
    }
}
