package com.nur.prayer.location

import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset
import kotlin.math.abs
import kotlin.math.roundToInt

/** Where the time zone of a raw fix came from. Surfaced verbatim in "О расчётах". */
enum class ZoneSource { DEVICE, NEIGHBOURHOOD, LONGITUDE }

/** A known city near the fix: only the two facts the resolver is allowed to see. */
data class ZoneCandidate(val zone: ZoneId, val distanceKm: Double)

/** The verdict, with the sentence the settings screen prints under it. */
data class ZoneDecision(val zone: ZoneId, val source: ZoneSource, val explanation: String)

/**
 * The time zone of a GPS fix.
 *
 * This is the one mistake in the whole app that costs a full hour, produces no symptom, and cannot
 * be noticed by looking at the screen: every prayer time is simply shifted, all day, every day.
 *
 * 0.2.5 took the zone of the nearest city in the database, which sounds reasonable and is wrong at
 * exactly the places where it matters. Two facts, both measured against the shipped database:
 *
 *  * cities from *different* zones can be thirteen kilometres apart — Октябрьский (+5) and Уруссу
 *    (+3) on the Tatarstan/Bashkortostan border, Кувасай (+5) and Кызыл-Кия (+6) in the Fergana
 *    valley. "Nearest city" is a coin toss there, and the coin is flipped for the user;
 *  * the largest honest gap between a city's zone and its own solar time is 1.59 hours (Актау,
 *    Рубцовск). Anything beyond two hours means the *clock* is lying, not the map.
 *
 * So the evidence is ranked, strongest first:
 *
 *  1. **The neighbourhood.** If every database city within [NEIGHBOURHOOD_RADIUS_KM] of the fix
 *     agrees on the offset, that is a geographic fact, not a guess. If the phone already sits on
 *     that offset, the phone's zone wins the tie — same offset, but with the real DST rules and a
 *     real identifier instead of a bare +05:00. If the phone disagrees, the neighbourhood wins: a
 *     phone that thinks it is in Moscow while standing in Tashkent is a stale clock, and this is
 *     the case a traveller actually hits.
 *  2. **The phone.** Near a zone boundary the neighbourhood is split (that is what a boundary is),
 *     and there the operator's network knows which side of the line the tower is on, which no
 *     offline database can. So the phone's own zone is taken — but only after it is checked against
 *     the longitude of the fix, because that check is free and catches a grossly wrong clock.
 *  3. **The longitude.** Both disagree with the sky: fall back to a fixed offset from the fix's own
 *     longitude and say so out loud in "О расчётах". Never silently keep a zone known to be wrong.
 *
 * Everything the function needs is a parameter — zone, candidates, instant — so all of it is
 * testable on the JVM without a device, a permission dialog or a trip to Tashkent.
 */
object ZoneResolver {

    /**
     * Radius of the "we know where this is" neighbourhood.
     *
     * Half of the closest cross-zone pair in the database (13 km) would be too tight to ever
     * contain a second city; 120 km is wide enough that a unanimous verdict is meaningful and
     * narrow enough that a boundary inside it shows up as disagreement rather than as a wrong
     * answer.
     */
    const val NEIGHBOURHOOD_RADIUS_KM = 120.0

    /**
     * How far a zone may sit from its own solar time before the clock is presumed wrong, hours.
     *
     * Measured, not chosen: 1.59 h is the worst honest case in the shipped database (tools/
     * verify_cities.py prints it), and CityDatabaseTest fails if a new city ever exceeds this
     * constant — so the margin cannot rot away silently as the database grows.
     */
    const val MAX_SOLAR_GAP_HOURS = 2.0

    fun resolve(
        deviceZone: ZoneId,
        longitude: Double,
        nearby: List<ZoneCandidate>,
        instant: Instant
    ): ZoneDecision {
        val solarHours = longitude / 15.0
        val deviceOffset = offsetHours(deviceZone, instant)
        val deviceGap = abs(deviceOffset - solarHours)

        val neighbourhood = nearby.filter { it.distanceKm <= NEIGHBOURHOOD_RADIUS_KM }
        val offsets = neighbourhood.map { offsetHours(it.zone, instant) }.distinct()
        val unanimous = offsets.size == 1
        if (unanimous) {
            val local = offsets.first()
            if (abs(local - deviceOffset) < 1e-9) {
                return ZoneDecision(
                    zone = deviceZone,
                    source = ZoneSource.DEVICE,
                    explanation = "Часовой пояс телефона ($deviceZone) совпал с поясом " +
                        "окрестностей точки — берём его, в нём верные правила перехода."
                )
            }
            val zone = neighbourhood.minByOrNull { it.distanceKm }!!.zone
            return ZoneDecision(
                zone = zone,
                source = ZoneSource.NEIGHBOURHOOD,
                explanation = "Часы телефона показывают UTC${format(deviceOffset)}, а все города " +
                    "в радиусе ${NEIGHBOURHOOD_RADIUS_KM.toInt()} км живут по UTC${format(local)} — " +
                    "берём пояс места ($zone)."
            )
        }

        if (deviceGap <= MAX_SOLAR_GAP_HOURS) {
            val reason = if (neighbourhood.isEmpty()) {
                "рядом нет городов из базы"
            } else {
                "точка у границы поясов, города рядом расходятся"
            }
            return ZoneDecision(
                zone = deviceZone,
                source = ZoneSource.DEVICE,
                explanation = "Пояс телефона ($deviceZone) согласуется с долготой " +
                    "(${format(solarHours)} солнечного против ${format(deviceOffset)} поясного); $reason."
            )
        }

        val fallback = neighbourhood.ifEmpty { nearby }
            .filter { abs(offsetHours(it.zone, instant) - solarHours) <= MAX_SOLAR_GAP_HOURS }
            .minByOrNull { it.distanceKm }
        if (fallback != null) {
            return ZoneDecision(
                zone = fallback.zone,
                source = ZoneSource.NEIGHBOURHOOD,
                explanation = "Пояс телефона ($deviceZone) расходится с долготой точки на " +
                    "${format(deviceGap)} ч — берём пояс ближайшего города (${fallback.zone})."
            )
        }

        val offset = ZoneOffset.ofTotalSeconds(solarHours.roundToInt() * 3600)
        return ZoneDecision(
            zone = offset,
            source = ZoneSource.LONGITUDE,
            explanation = "Ни пояс телефона ($deviceZone), ни города рядом не сходятся с долготой " +
                "точки — время считается по фиксированному смещению UTC$offset от долготы. " +
                "Переходы на летнее время в этом режиме не учитываются."
        )
    }

    fun offsetHours(zone: ZoneId, instant: Instant): Double =
        zone.rules.getOffset(instant).totalSeconds / 3600.0

    private fun format(hours: Double): String {
        val rounded = (hours * 100.0).roundToInt() / 100.0
        val text = if (rounded == rounded.toInt().toDouble()) {
            rounded.toInt().toString()
        } else {
            rounded.toString()
        }
        return if (rounded >= 0) "+$text" else text
    }
}
