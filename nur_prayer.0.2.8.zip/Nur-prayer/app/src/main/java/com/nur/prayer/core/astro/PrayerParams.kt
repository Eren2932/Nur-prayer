package com.nur.prayer.core.astro

/**
 * The daily time markers the app shows.
 *
 * ### [SAHAR] versus [FAJR] — the distinction that caused the release complaint
 *
 * The printed calendar of the Spiritual Board of Tatarstan carries two separate morning rows and
 * they are not the same event:
 *
 * - "Сәхәр тәмам" — the true astronomical dawn, the moment the fast begins. Kazan, 15.08.2026:
 *   **01:11**. This is the solar depression angle, [SAHAR] here.
 * - "Мәчетләрдә укыла" — the moment the congregation actually prays Fajr in the mosques. Same
 *   day: **02:45**, which is exactly sunrise minus 90 minutes and holds digit for digit on
 *   15, 16, 17 and 18 August. This is [FAJR] here.
 *
 * The app used to publish only the first one and call it Fajr, so it announced the morning prayer
 * an hour and a half before any mosque did. Both are now first-class markers.
 */
enum class Prayer {
    /** End of suhoor / true dawn. Fasting boundary, not a call to prayer. */
    SAHAR,

    /** Congregational Fajr, the time the mosque actually calls. */
    FAJR,
    SUNRISE, DHUHR, ASR, MAGHRIB, ISHA;

    /** True for the five obligatory prayers; Sahar and sunrise are informational markers. */
    val isPrayer: Boolean get() = this != SUNRISE && this != SAHAR
}

/** Asr school: shadow length multiplier. */
enum class Madhab(val shadowLength: Double) {
    /** Shafi'i, Maliki, Hanbali: shadow = 1x object height. */
    STANDARD(1.0),

    /** Hanafi: shadow = 2x object height. */
    HANAFI(2.0)
}

/**
 * How a computed instant is collapsed to the printed minute.
 *
 * This is not cosmetics: the whole disagreement between two prayer apps in the same city is
 * usually a single second landing on either side of a minute boundary. Verified against the
 * printed DUM RT calendar for Kazan (August 2026): [NEAREST] reproduces it, which is why it is
 * the default. [UP] is the cautious choice — a prayer is never announced before its
 * astronomical moment.
 */
enum class RoundingMode(val title: String, val explanation: String) {
    NEAREST("К ближайшей минуте", "Совпадает с печатным календарём ДУМ РТ"),
    UP("Вверх", "Намаз никогда не объявляется раньше астрономического времени"),
    DOWN("Вниз", "Отсечение секунд, как в некоторых сторонних приложениях")
}

/**
 * What to do when the Sun does not reach the Fajr / Isha depression angle at all
 * (short summer nights at high latitudes, which is most of Russia).
 *
 * Important: a rule from this list is a **fallback**, not a cap. It is consulted only on days
 * when the angle is genuinely unreachable. On any normal day the true astronomical angle wins.
 * Treating these rules as an unconditional clamp was the bug that put Isha in Kazan at 20:37
 * instead of 21:36 and made every calculation method look identical.
 */
enum class HighLatitudeRule {
    /** Pick automatically from the latitude. */
    AUTO,

    /**
     * Fixed intervals around the Sun: Fajr at [CalculationMethod.nightFajrMinutes] before
     * sunrise, Isha at [CalculationMethod.nightIshaMinutes] after sunset.
     *
     * This is what the Spiritual Boards of Russia and Tatarstan actually print. Verified digit
     * for digit against the Kazan calendar for 1-7 August 2026, where the Sun stays above -18°:
     * published Fajr equals sunrise - 120 min and published Isha equals sunset + 90 min on all
     * seven days.
     */
    FIXED_INTERVAL,

    /** Night is split in half: Fajr and Isha cannot cross the middle of the night. */
    MIDDLE_OF_THE_NIGHT,

    /** Isha at 1/7 of the night after sunset, Fajr at 1/7 before sunrise. */
    SEVENTH_OF_THE_NIGHT,

    /** Night fraction proportional to the twilight angle of the method. */
    TWILIGHT_ANGLE;

    fun resolve(latitude: Double): HighLatitudeRule = when (this) {
        AUTO -> if (kotlin.math.abs(latitude) >= 48.0) FIXED_INTERVAL else MIDDLE_OF_THE_NIGHT
        else -> this
    }
}

/**
 * Ready-made parameter sets. Angles are solar depression angles below the horizon.
 */
enum class CalculationMethod(
    val title: String,
    val fajrAngle: Double,
    val ishaAngle: Double,
    val ishaIntervalMinutes: Int = 0,
    val maghribAngle: Double = 0.0,
    /** Minutes before sunrise used for Fajr when the angle cannot be reached. */
    val nightFajrMinutes: Int = 120,
    /** Minutes after sunset used for Isha when the angle cannot be reached. */
    val nightIshaMinutes: Int = 90,
    /**
     * Minutes before sunrise at which the congregation prays Fajr, 0 when the tradition has no
     * separate congregational time and Fajr coincides with dawn.
     *
     * 90 for the Russian boards, verified against the "Мәчетләрдә укыла" column.
     */
    val congregationalFajrBeforeSunrise: Int = 0,
    val methodAdjustments: Map<Prayer, Int> = emptyMap()
) {
    /**
     * Fajr 18 / Isha 15. Reverse-engineered from the printed Kazan calendar and cross-checked
     * over the whole of August 2026: sunrise, zenith and Maghrib match exactly, Fajr and Isha
     * within one minute. The previous 16/15 pair was wrong by up to half an hour on Fajr.
     */
    RUSSIA_DUM(
        "ДУМ РФ (Совет муфтиев)", 18.0, 15.0,
        congregationalFajrBeforeSunrise = 90
    ),
    SPIRITUAL_BOARD_TATARSTAN(
        "ДУМ Республики Татарстан", 18.0, 15.0,
        congregationalFajrBeforeSunrise = 90
    ),
    /**
     * Muslim Board of Uzbekistan (О‘zbekiston musulmonlari idorasi), as printed on
     * namozvaqti.uz and in the mosque calendars of Uzbekistan.
     *
     * Fajr 15° / Isha 15°, reverse-engineered from Bukhara, 18.08.2026 (Фаджр 04:36,
     * восход 06:02, зухр 12:51, аср 17:33, магриб 19:36, иша 20:57): the depression angle at
     * the published Fajr is 14.89° and at the published Isha 15.19°, so 15°/15° is the pair, and
     * everything left over is editorial minutes — see [CalendarConvention.UZBEKISTAN].
     *
     * [congregationalFajrBeforeSunrise] is deliberately 0. This is the single most expensive
     * difference between the Russian and the Uzbek tradition: the boards of Russia print a separate
     * congregational Fajr at sunrise − 90 min, while the Uzbek calendar prints one morning time and
     * labels it "Saharlik" — dawn itself is both the end of suhoor and the call. Applying the
     * Russian −90 rule in Bukhara moved Fajr from 04:36 to 04:28 and was the actual complaint.
     */
    UZBEKISTAN_BOARD(
        "Муфтият Узбекистана", 15.0, 15.0
    ),
    MUSLIM_WORLD_LEAGUE(
        "Muslim World League", 18.0, 17.0,
        methodAdjustments = mapOf(Prayer.DHUHR to 1)
    ),
    EGYPTIAN(
        "Egyptian General Authority", 19.5, 17.5,
        methodAdjustments = mapOf(Prayer.DHUHR to 1)
    ),
    KARACHI(
        "University of Islamic Sciences, Karachi", 18.0, 18.0,
        methodAdjustments = mapOf(Prayer.DHUHR to 1)
    ),
    UMM_AL_QURA(
        "Umm al-Qura, Makkah", 18.5, 0.0, ishaIntervalMinutes = 90
    ),
    DUBAI(
        "Dubai", 18.2, 18.2,
        methodAdjustments = mapOf(Prayer.SUNRISE to -3, Prayer.DHUHR to 3, Prayer.ASR to 3, Prayer.MAGHRIB to 3)
    ),
    QATAR(
        "Qatar", 18.0, 0.0, ishaIntervalMinutes = 90
    ),
    KUWAIT(
        "Kuwait", 18.0, 17.5
    ),
    TURKEY(
        "Diyanet, Türkiye", 18.0, 17.0,
        methodAdjustments = mapOf(
            Prayer.SUNRISE to -7, Prayer.DHUHR to 5, Prayer.ASR to 4, Prayer.MAGHRIB to 7
        )
    ),
    TEHRAN(
        "Institute of Geophysics, Tehran", 17.7, 14.0, maghribAngle = 4.5
    ),
    NORTH_AMERICA(
        "ISNA, North America", 15.0, 15.0,
        methodAdjustments = mapOf(Prayer.DHUHR to 1)
    );

    /** Human readable summary of what this method actually does, for the settings screen. */
    val angleSummary: String
        get() = "Фаджр $fajrAngle° · Иша " +
            if (ishaIntervalMinutes > 0) "закат + $ishaIntervalMinutes мин" else "$ishaAngle°"
}

/** Full calculation configuration, method plus user overrides. */
@androidx.compose.runtime.Immutable
data class PrayerParams(
    val method: CalculationMethod = CalculationMethod.RUSSIA_DUM,
    val madhab: Madhab = Madhab.HANAFI,
    val highLatitudeRule: HighLatitudeRule = HighLatitudeRule.AUTO,
    val rounding: RoundingMode = RoundingMode.NEAREST,
    /** Which published convention the printed minute should imitate. */
    val convention: CalendarConvention = CalendarConvention.DUM_RT,
    /**
     * Override for [CalculationMethod.congregationalFajrBeforeSunrise]; null keeps the method
     * default, 0 collapses congregational Fajr onto dawn.
     */
    val congregationalFajrMinutes: Int? = null,
    /** Manual per-prayer correction in minutes, applied on top of everything else. */
    val userAdjustments: Map<Prayer, Int> = emptyMap()
) {
    fun adjustmentMinutes(prayer: Prayer): Int =
        (method.methodAdjustments[prayer] ?: 0) + (userAdjustments[prayer] ?: 0)

    /** Resolved gap between congregational Fajr and sunrise, 0 when the two markers coincide. */
    val fajrBeforeSunriseMinutes: Int
        get() = (congregationalFajrMinutes ?: method.congregationalFajrBeforeSunrise).coerceIn(0, 240)

    fun policy(prayer: Prayer): MarkerPolicy = convention.policy(prayer, rounding)
}
