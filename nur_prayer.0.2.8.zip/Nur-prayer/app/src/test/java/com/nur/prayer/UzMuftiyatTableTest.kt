package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.PrayerParams
import com.nur.prayer.core.astro.PrintedCalendars
import com.nur.prayer.core.astro.PrintedYearTable
import com.nur.prayer.core.astro.RegionalProfiles
import com.nur.prayer.core.astro.RoundingMode
import com.nur.prayer.core.astro.TimeSource
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/**
 * The Uzbek printed table, checked against every value the muftiyat published for 2026.
 *
 * 8 cities x 365 days x 6 columns = 17 520 printed times, in
 * `app/src/test/resources/uz_reference_2026.txt`. The asset under test is the very file that ships
 * in the APK — `src/main/assets` is on the unit-test classpath, see app/build.gradle.kts.
 *
 * Why this test is the one that matters: 0.2.5, 0.2.6 and 0.2.7 each shipped a calculation that was
 * checked against *one* published day in *one* city and was wrong by up to 17 minutes elsewhere in
 * the same country. One day proves nothing. A year in eight cities is the smallest thing that does.
 */
class UzMuftiyatTableTest {

    private data class Printed(val lat: Double, val lon: Double, val days: Map<Pair<Int, Int>, List<Int>>)

    private val zone: ZoneId = ZoneId.of("Asia/Tashkent")

    private val params = PrayerParams(
        method = RegionalProfiles.UZBEKISTAN.method,
        madhab = Madhab.HANAFI,
        highLatitudeRule = HighLatitudeRule.AUTO,
        rounding = RoundingMode.NEAREST,
        convention = RegionalProfiles.UZBEKISTAN.convention
    )

    private fun resource(name: String): String =
        checkNotNull(javaClass.classLoader?.getResourceAsStream(name)) { "нет ресурса $name" }
            .bufferedReader().use { it.readText() }

    private fun reference(): Map<String, Printed> {
        val cities = LinkedHashMap<String, Printed>()
        val rows = LinkedHashMap<String, MutableMap<Pair<Int, Int>, List<Int>>>()
        val meta = LinkedHashMap<String, Pair<Double, Double>>()
        resource("uz_reference_2026.txt").lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) return@forEach
            val p = line.split(' ')
            meta[p[0]] = p[1].toDouble() to p[2].toDouble()
            rows.getOrPut(p[0]) { LinkedHashMap() }[p[3].toInt() to p[4].toInt()] =
                (5..10).map { p[it].toInt() }
        }
        meta.forEach { (city, coords) ->
            cities[city] = Printed(coords.first, coords.second, rows.getValue(city))
        }
        return cities
    }

    @Before
    fun installAsset() {
        PrayerEngine.clearCache()
        PrintedCalendars.install { name -> runCatching { resource(name) }.getOrNull() }
    }

    @After
    fun removeAsset() {
        PrintedCalendars.clear()
        PrayerEngine.clearCache()
    }

    @Test
    fun `the shipped asset parses`() {
        val table = PrintedCalendars.uzbekistan()
        assertNotNull("ассет ${PrintedCalendars.UZBEKISTAN_ASSET} не читается", table)
        assertEquals(2026, table!!.year)
        // The ladder must span the whole country: every Uzbek city has to be interpolated, never
        // extrapolated. Termez is the southernmost city in cities_ru.json, Muynak the northernmost.
        assertTrue(table.covers(37.2242))
        assertTrue(table.covers(43.7686))
    }

    @Test
    fun `every printed value of 2026 is reproduced through the engine`() {
        val misses = mutableListOf<String>()
        var checked = 0
        reference().forEach { (city, printed) ->
            val coordinates = Coordinates(printed.lat, printed.lon)
            printed.days.forEach { (date, values) ->
                val day = PrayerEngine.day(LocalDate.of(2026, date.first, date.second), coordinates, zone, params)
                PrintedYearTable.PRINTED_ORDER.forEachIndexed { index, prayer ->
                    val actual = day.at(prayer).toLocalTime()
                    val expected = LocalTime.of(values[index] / 60, values[index] % 60)
                    checked++
                    if (actual != expected && misses.size < 12) {
                        misses += "$city ${date.first}.${date.second} ${prayer.name}: " +
                            "напечатано $expected, движок $actual"
                    }
                }
            }
        }
        assertEquals(17_520, checked)
        assertTrue("Расхождения с календарём муфтията: $misses", misses.isEmpty())
    }

    @Test
    fun `the day says where it came from`() {
        val day = PrayerEngine.day(LocalDate.of(2026, 8, 18), Coordinates(39.7686, 64.4556), zone, params)
        assertEquals(TimeSource.PRINTED_TABLE, day.saharSource)
        assertEquals(TimeSource.PRINTED_TABLE, day.fajrSource)
        assertEquals(TimeSource.PRINTED_TABLE, day.ishaSource)
        assertTrue(day.note.orEmpty().contains("namozvaqti.uz"))
        // The morning call is the printed morning time; the Russian −90 min rule has no place here.
        assertEquals(day.at(Prayer.SAHAR), day.at(Prayer.FAJR))
    }

    @Test
    fun `a city the table never saw lands within a minute of the neighbours it sits between`() {
        // Andijan (40.7821, 72.3442) is not one of the eight downloaded cities. It sits between
        // Fergana and Tashkent on the ladder, and its Peshin is pure longitude, so that column can
        // be asserted outright: 4 * (69.2401 − 72.3442) = −12 minutes from Tashkent.
        val date = LocalDate.of(2026, 8, 18)
        val andijan = PrayerEngine.day(date, Coordinates(40.7821, 72.3442), zone, params)
        val tashkent = PrayerEngine.day(date, Coordinates(41.2995, 69.2401), zone, params)
        assertEquals(
            tashkent.at(Prayer.DHUHR).minusMinutes(12).toLocalTime(),
            andijan.at(Prayer.DHUHR).toLocalTime()
        )
        val fergana = PrayerEngine.day(date, Coordinates(40.3864, 71.7864), zone, params)
        val gap = java.time.Duration.between(
            fergana.at(Prayer.MAGHRIB), andijan.at(Prayer.MAGHRIB)
        ).toMinutes()
        // Andijan is 0.56° north and 2.2 minutes of longitude east of Fergana: the printed evening
        // difference between two such neighbours is single-digit minutes, never an hour.
        assertTrue("Магриб в Андижане уехал от Ферганы на $gap мин", kotlin.math.abs(gap) <= 5)
    }

    @Test
    fun `the table is left when the user leaves its assumptions`() {
        val date = LocalDate.of(2026, 8, 18)
        val bukhara = Coordinates(39.7686, 64.4556)

        // Shafi'i: the muftiyat prints a Hanafi Asr and nothing else, so the engine computes.
        val shafii = PrayerEngine.day(date, bukhara, zone, params.copy(madhab = Madhab.STANDARD))
        assertTrue(shafii.saharSource != TimeSource.PRINTED_TABLE)

        // Another country's coordinates with the Uzbek method selected by hand: no table.
        val kazan = PrayerEngine.day(date, Coordinates(55.7963, 49.1088), zone, params)
        assertTrue(kazan.saharSource != TimeSource.PRINTED_TABLE)

        // Another method inside Uzbekistan: the user asked for astronomy and gets astronomy.
        val mwl = params.copy(
            method = CalculationMethod.MUSLIM_WORLD_LEAGUE,
            convention = RegionalProfiles.conventionFor(CalculationMethod.MUSLIM_WORLD_LEAGUE)
        )
        assertTrue(PrayerEngine.day(date, bukhara, zone, mwl).saharSource != TimeSource.PRINTED_TABLE)
    }

    @Test
    fun `a damaged asset degrades to astronomy instead of crashing`() {
        assertNull(PrintedYearTable.parse(""))
        assertNull(PrintedYearTable.parse("NURUZ 1\nYEAR 2026\nEND\n"))
        assertNull(PrintedYearTable.parse(resource(PrintedCalendars.UZBEKISTAN_ASSET).replace("TABLE 365", "TABLE 12")))

        PrintedCalendars.install { null }
        val day = PrayerEngine.day(LocalDate.of(2026, 8, 18), Coordinates(39.7686, 64.4556), zone, params)
        assertTrue(day.saharSource != TimeSource.PRINTED_TABLE)
        assertTrue(day.at(Prayer.MAGHRIB).toLocalTime() > LocalTime.of(19, 0))
    }

    @Test
    fun `29 february reuses 28 february instead of shifting the year`() {
        val table = checkNotNull(PrintedCalendars.uzbekistan())
        val bukhara = Coordinates(39.7686, 64.4556)
        val leapDay = table.minutes(LocalDate.of(2028, 2, 29), bukhara)
        val eve = table.minutes(LocalDate.of(2028, 2, 28), bukhara)
        assertTrue(leapDay.contentEquals(eve))
        // …and the day after the leap day is 1 March, not 29 February again.
        val march = table.minutes(LocalDate.of(2028, 3, 1), bukhara)
        assertTrue(march[0] < eve[0])
    }

    @Test
    fun `another year is honestly labelled`() {
        val note = PrayerEngine.day(
            LocalDate.of(2027, 8, 18), Coordinates(39.7686, 64.4556), zone, params
        ).note.orEmpty()
        assertTrue("Год-донор не назван пользователю: $note", note.contains("2026"))
    }
}
