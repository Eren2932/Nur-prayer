package com.nur.prayer

import com.nur.prayer.core.astro.CalculationMethod
import com.nur.prayer.core.astro.Calibration
import com.nur.prayer.core.astro.Coordinates
import com.nur.prayer.core.astro.HighLatitudeRule
import com.nur.prayer.core.astro.Madhab
import com.nur.prayer.core.astro.Prayer
import com.nur.prayer.core.astro.PrayerEngine
import com.nur.prayer.core.astro.PrayerParams
import com.nur.prayer.core.astro.RegionalProfiles
import com.nur.prayer.core.astro.RoundingMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/**
 * Locks the engine against the calendar of the Muslim Board of Uzbekistan for Бухара, as published
 * on namozvaqti.uz for 18.08.2026 and transcribed from a screenshot.
 *
 * The regression this file exists for: 0.2.6 shipped 134 cities outside Russia and computed every
 * one of them with the Russian boards' rules. In Bukhara that produced five wrong rows out of six,
 * and one of them was wrong in the dangerous direction — Maghrib four minutes *before* the printed
 * iftar time.
 *
 *     графа      напечатано   0.2.6    0.2.7
 *     Saharlik   04:36        04:28    04:36
 *     Quyosh     06:02        05:58    06:02
 *     Peshin     12:51        12:45    12:51
 *     Asr        17:33        17:34    17:33
 *     Shom       19:36        19:32    19:36
 *     Xufton     20:57        20:53    20:57
 */
class UzbekistanCalendarTest {

    private val bukhara = Coordinates(39.7686, 64.4556)
    private val zone: ZoneId = ZoneId.of("Asia/Tashkent")

    private val params = PrayerParams(
        method = RegionalProfiles.UZBEKISTAN.method,
        madhab = Madhab.HANAFI,
        highLatitudeRule = HighLatitudeRule.AUTO,
        rounding = RoundingMode.NEAREST,
        convention = RegionalProfiles.UZBEKISTAN.convention
    )

    private val order = listOf(
        Prayer.SAHAR, Prayer.SUNRISE, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA
    )

    /** namozvaqti.uz, Бухара, 18.08.2026. */
    private val published = listOf("4:36", "6:02", "12:51", "17:33", "19:36", "20:57")

    private fun padded(text: String): String = if (text.length == 4) "0$text" else text

    @Test
    fun `reproduces the printed uzbek calendar exactly`() {
        val date = LocalDate.of(2026, 8, 18)
        val day = PrayerEngine.day(date, bukhara, zone, params)
        val misses = mutableListOf<String>()
        order.forEachIndexed { index, prayer ->
            val actual = day.at(prayer).toLocalTime()
            val target = LocalTime.parse(padded(published[index]))
            if (actual != target) {
                misses += "${prayer.name}: календарь ${published[index]}, движок $actual"
            }
        }
        assertTrue("Расхождения с namozvaqti.uz: $misses", misses.isEmpty())
    }

    @Test
    fun `fajr and sahar coincide in the uzbek tradition`() {
        // The Uzbek calendar prints one morning time labelled "Saharlik" and the mosques call at it.
        // The Russian −90 min congregational rule must not exist here at all: applying it is what
        // announced Fajr in Bukhara at 04:28 instead of 04:36.
        val day = PrayerEngine.day(LocalDate.of(2026, 8, 18), bukhara, zone, params)
        assertEquals(day.at(Prayer.SAHAR), day.at(Prayer.FAJR))
        assertEquals(0, params.fajrBeforeSunriseMinutes)
    }

    @Test
    fun `the russian profile visibly disagrees with the uzbek calendar`() {
        // Documents the size of the old error, and fails if someone ever "simplifies" the profiles
        // back into a single global default.
        val russian = params.copy(
            method = RegionalProfiles.RUSSIA.method,
            convention = RegionalProfiles.RUSSIA.convention
        )
        val day = PrayerEngine.day(LocalDate.of(2026, 8, 18), bukhara, zone, russian)
        assertEquals(LocalTime.of(4, 27), day.at(Prayer.FAJR).toLocalTime())
        assertEquals(LocalTime.of(19, 34), day.at(Prayer.MAGHRIB).toLocalTime())
        // …and the marker the user actually complained about: dawn, an hour of the day earlier than
        // the Uzbek calendar's single morning time.
        assertEquals(LocalTime.of(4, 18), day.at(Prayer.SAHAR).toLocalTime())
    }

    @Test
    fun `printed times move monotonically around the calibrated day`() {
        // One published day cannot prove the offsets hold all season, so the least it must do is
        // stay smooth: dawn later each morning, sunset earlier each evening in late August.
        var previousSahar: LocalTime? = null
        var previousMaghrib: LocalTime? = null
        for (dayOfMonth in 16..21) {
            val day = PrayerEngine.day(LocalDate.of(2026, 8, dayOfMonth), bukhara, zone, params)
            val sahar = day.at(Prayer.SAHAR).toLocalTime()
            val maghrib = day.at(Prayer.MAGHRIB).toLocalTime()
            previousSahar?.let { assertTrue("$dayOfMonth.08: сахар не сдвинулся вперёд", sahar > it) }
            previousMaghrib?.let { assertTrue("$dayOfMonth.08: магриб не сдвинулся назад", maghrib < it) }
            previousSahar = sahar
            previousMaghrib = maghrib
        }
    }

    @Test
    fun `profiles declare how they were verified`() {
        assertEquals(Calibration.PRINTED_CALENDAR, RegionalProfiles.UZBEKISTAN.calibration)
        assertEquals(Calibration.PRINTED_CALENDAR, RegionalProfiles.RUSSIA.calibration)
        // Never claim a printed-calendar match for a country whose calendar nobody has seen.
        assertEquals(Calibration.ASSUMED, RegionalProfiles.forCountry("Казахстан").calibration)
        assertEquals(
            CalculationMethod.TURKEY,
            RegionalProfiles.forCountry("Турция").method
        )
    }
}
