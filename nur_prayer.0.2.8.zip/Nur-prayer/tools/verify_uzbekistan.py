#!/usr/bin/env python3
"""
Проверка узбекского профиля против печатного календаря namozvaqti.uz.

Зачем отдельный файл. Казанский календарь сверяется verify_kazan.py и держит 28 значений за четыре
дня. Узбекистан до 0.2.7 считался *казанскими* правилами, и это была не астрономическая ошибка, а
подмена конвенции: движок отдавал верные до секунды мгновения, а печатал их по чужим правилам
округления и с чужим правилом «Фаджр = восход − 90».

Здесь проверяется ровно то, что видит пользователь: шесть граф календаря Бухары за 18.08.2026.
Плюс диагностика — на какой глубине находится солнце в момент каждого напечатанного времени: это
доказательство того, что углы метода 15°/15°, а всё остальное расхождение — редакционные минуты.

Ограничение указано честно: это ОДИН день. Достаточно, чтобы поймать поправку с точностью до
минуты, недостаточно, чтобы доказать её постоянство весь год. Пришлите фото календаря за месяц —
скрипт расширяется добавлением строк в PUBLISHED.

Запуск:  python3 tools/verify_uzbekistan.py
Код возврата 0 — все графы совпали.
"""
import os
import sys
from datetime import date, datetime, time
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from prayer_port import (  # noqa: E402
    Coordinates, Params, PrayerTimes, SolarCoordinates, julian_day,
    altitude_of_celestial_body, SAHAR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA,
)

BUKHARA = Coordinates(39.7756, 64.4286)
ZONE = ZoneInfo("Asia/Tashkent")

# namozvaqti.uz, Бухара, 18 августа 2026. Столбец «Фаджр» там подписан Saharlik, отдельного
# «мечетского» Фаджра узбекский календарь не печатает — это и есть главное отличие от России.
PUBLISHED = {
    date(2026, 8, 18): {
        SAHAR: "04:36",
        SUNRISE: "06:02",
        DHUHR: "12:51",
        ASR: "17:33",
        MAGHRIB: "19:36",
        ISHA: "20:57",
    },
}

LABEL = {
    SAHAR: "Saharlik / Фаджр",
    SUNRISE: "Quyosh / Восход",
    DHUHR: "Peshin / Зухр",
    ASR: "Asr / Аср",
    MAGHRIB: "Shom / Магриб",
    ISHA: "Xufton / Иша",
}


def depression_at(moment: datetime, coordinates: Coordinates) -> float:
    """Глубина солнца под горизонтом в конкретный момент, в градусах."""
    utc = moment.astimezone(ZoneInfo("UTC"))
    jd = julian_day(utc.year, utc.month, utc.day, utc.hour + utc.minute / 60.0 + utc.second / 3600.0)
    solar = SolarCoordinates(jd)
    # Местный часовой угол = звёздное время Гринвича + долгота − прямое восхождение.
    lha = (solar.apparent_sidereal_time + coordinates.longitude - solar.right_ascension) % 360.0
    altitude = altitude_of_celestial_body(coordinates.latitude, solar.declination, lha)
    return -altitude


def main() -> int:
    params = Params(method="UZBEKISTAN_BOARD", convention="UZBEKISTAN")
    misses = []
    checked = 0

    for day, published in sorted(PUBLISHED.items()):
        offset = datetime.combine(day, time(12, 0), ZONE).utcoffset().total_seconds() / 3600.0
        times = PrayerTimes(day, BUKHARA, params, offset)
        print(f"\n  Бухара, {day.strftime('%d.%m.%Y')}   (профиль: Муфтият Узбекистана, 15°/15°)")
        print("  графа                напечатано   движок    Δ    глубина солнца")
        for prayer, printed in published.items():
            value = times.times.get(prayer)
            actual = value.astimezone(ZONE).strftime("%H:%M") if value else "--:--"
            checked += 1
            ok = actual == printed
            if not ok:
                misses.append(f"{day} {prayer}: календарь {printed}, движок {actual}")
            printed_dt = datetime.combine(
                day, time(int(printed[:2]), int(printed[3:])), ZONE
            )
            delta = "  0" if ok else "%+3d" % round(
                ((value.astimezone(ZONE) - printed_dt).total_seconds() / 60.0) if value else 0
            )
            depression = depression_at(printed_dt, BUKHARA)
            print(
                "  %-20s %-12s %-9s %s   %6.2f°"
                % (LABEL[prayer], printed, ("OK " if ok else "!! ") + actual, delta, depression)
            )

    print(f"\n  совпадений {checked - len(misses)} из {checked}")
    if misses:
        print("\n  РАСХОЖДЕНИЯ:")
        for miss in misses:
            print("   ", miss)
        return 1
    print("  Профиль воспроизводит печатный календарь. Дней в сверке: %d — этого хватает на"
          % len(PUBLISHED))
    print("  калибровку поправок, но не на доказательство их постоянства весь год.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
