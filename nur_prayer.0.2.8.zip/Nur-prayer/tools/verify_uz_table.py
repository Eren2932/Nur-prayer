#!/usr/bin/env python3
"""Verify the shipped Uzbek asset against the printed reference, with the Kotlin algorithm.

This is a line-by-line port of `PrintedYearTable.minutes` in Kotlin, including half-up rounding and
latitude clamping, run against `app/src/test/resources/uz_reference_2026.txt` — the values as
namozvaqti.uz printed them.

Two verdicts are produced:

  IN   every anchor city. Must be exact: those rows are what the asset stores.
  OUT  leave-one-out. The anchor is removed from the ladder and its city predicted from the
       remaining ones. This is the honest estimate for the 26 Uzbek cities that were never
       downloaded, and it is the number quoted to the user.

Interior cities must land within one minute. The two edge cities (Termez, Muynak) are *expected* to
be bad under leave-one-out — removing them turns interpolation into extrapolation, which is exactly
why the shipped ladder keeps them and clamps instead. They are reported, not silently skipped.

    python3 tools/verify_uz_table.py
"""
from __future__ import annotations

import math
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSET = os.path.join(ROOT, 'app/src/main/assets/uz_muftiyat_2026.txt')
REFERENCE = os.path.join(ROOT, 'app/src/test/resources/uz_reference_2026.txt')
MONTH_START = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
EDGE_CITIES = {'termiz', 'moynoq'}


def half_up(x: float) -> int:
    return int(math.floor(x + 0.5))


def decode_rle(line: str, days: int):
    out = []
    for chunk in line.split(','):
        if '*' in chunk:
            value, count = chunk.split('*')
            out.extend([int(value)] * int(count))
        else:
            out.append(int(chunk))
    assert len(out) == days, f'RLE length {len(out)} != {days}'
    return out


def load_asset(path):
    year = None
    base_lat = base_lon = None
    lats = []
    table, morning, evening = [], [], []
    section = None
    for raw in open(path, encoding='utf-8'):
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split()
        if parts[0] == 'NURUZ':
            assert parts[1] == '1', 'unknown asset version'
        elif parts[0] == 'YEAR':
            year = int(parts[1])
        elif parts[0] == 'BASE':
            base_lat, base_lon = float(parts[1]), float(parts[2])
        elif parts[0] == 'LATS':
            lats = [float(x) for x in parts[1:]]
        elif parts[0] == 'TABLE':
            section = 'T'
        elif parts[0] == 'MORNING':
            section = 'M'
        elif parts[0] == 'EVENING':
            section = 'E'
        elif parts[0] == 'END':
            section = None
        elif section == 'T':
            table.append([int(x) for x in parts])
        elif section == 'M':
            morning.append(decode_rle(line, 365))
        elif section == 'E':
            evening.append(decode_rle(line, 365))
    assert len(table) == 365, len(table)
    assert len(morning) == len(evening) == len(lats)
    return dict(year=year, base_lat=base_lat, base_lon=base_lon, lats=lats,
                table=table, morning=morning, evening=evening)


def day_index(month: int, day: int) -> int:
    if month == 2 and day == 29:
        day = 28
    return MONTH_START[month - 1] + day - 1


def interpolate(offsets, lats, index, latitude):
    if latitude <= lats[0]:
        return float(offsets[0][index])
    if latitude >= lats[-1]:
        return float(offsets[-1][index])
    for i in range(len(lats) - 1):
        if lats[i] <= latitude <= lats[i + 1]:
            t = (latitude - lats[i]) / (lats[i + 1] - lats[i])
            a, b = offsets[i][index], offsets[i + 1][index]
            return a + (b - a) * t
    return float(offsets[-1][index])


def predict(asset, lats, morning, evening, month, day, lat, lon):
    index = day_index(month, day)
    latitude = min(max(lat, lats[0]), lats[-1])
    noon = half_up(4.0 * (asset['base_lon'] - lon))
    m = half_up(interpolate(morning, lats, index, latitude))
    e = half_up(interpolate(evening, lats, index, latitude))
    row = asset['table'][index]
    return [row[0] + noon + m, row[1] + noon + m, row[2] + noon,
            row[3] + noon + e, row[4] + noon + e, row[5] + noon + e]


def load_reference(path):
    cities = {}
    for raw in open(path, encoding='utf-8'):
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        p = line.split()
        cities.setdefault(p[0], dict(lat=float(p[1]), lon=float(p[2]), days={}))
        cities[p[0]]['days'][(int(p[3]), int(p[4]))] = [int(x) for x in p[5:11]]
    return cities


def report(title, city, errors):
    total = len(errors)
    worst = max(errors)
    exact = 100.0 * errors.count(0) / total
    within = 100.0 * sum(1 for e in errors if e <= 1) / total
    print(f'{title} {city:10s} худшее {worst:2d} мин   точно {exact:5.1f}%   '
          f'в пределах минуты {within:5.1f}%   ({total} значений)')
    return worst


def main() -> int:
    asset = load_asset(ASSET)
    reference = load_reference(REFERENCE)
    lats = asset['lats']
    order = sorted(reference, key=lambda c: reference[c]['lat'])
    assert len(order) == len(lats), 'reference cities and ladder anchors disagree'

    print(f'ассет {os.path.getsize(ASSET)} байт, год {asset["year"]}, '
          f'лестница широт {lats[0]:.2f}…{lats[-1]:.2f}, городов в эталоне {len(order)}')
    failures = []

    print('\nIN — города, которые лежат в ассете (должно быть точно):')
    for city in order:
        info = reference[city]
        errors = []
        for (month, day), printed in info['days'].items():
            got = predict(asset, lats, asset['morning'], asset['evening'],
                          month, day, info['lat'], info['lon'])
            errors += [abs(a - b) for a, b in zip(got, printed)]
        if report('  IN ', city, errors) != 0:
            failures.append(city)

    print('\nOUT — город выброшен из лестницы и предсказан по соседям:')
    for city in order:
        info = reference[city]
        keep = [c for c in order if c != city]
        sub_lats = [reference[c]['lat'] for c in keep]
        sub_m = [asset['morning'][order.index(c)] for c in keep]
        sub_e = [asset['evening'][order.index(c)] for c in keep]
        errors = []
        for (month, day), printed in info['days'].items():
            got = predict(asset, sub_lats, sub_m, sub_e, month, day, info['lat'], info['lon'])
            errors += [abs(a - b) for a, b in zip(got, printed)]
        worst = report('  OUT', city, errors)
        if city in EDGE_CITIES:
            print(f'       ^ край лестницы: без него это экстраполяция. Поэтому он в ассете, '
                  f'а широта зажимается.')
        elif worst > 1:
            failures.append(city)

    if failures:
        print('\nПРОВАЛ: ' + ', '.join(failures))
        return 1
    print('\nвсё сходится: внутри страны не хуже минуты, опорные города точно')
    return 0


if __name__ == '__main__':
    sys.exit(main())
