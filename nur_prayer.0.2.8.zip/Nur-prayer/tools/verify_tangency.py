#!/usr/bin/env python3
"""
Tangency audit for the twilight root finder (0.2.6).

verify_roots.py proves that every root the engine reports exists in a minute-by-minute altitude
scan. This tool attacks the opposite failure, the one that survived into 0.2.5: a night whose
lowest point misses the requested angle by a hair. There the altitude curve is flat, Newton parks
on the minimum, the residual is a thousandth of a degree - and the "event" never happened.
Volgograd, 14 June 2026, Isha 18 degrees: minimum -17.9989, engine printed a time near 23:30.

Method, deliberately independent of the engine:

  * each branch is judged against *its own* night - an evening root belongs to the night that
    follows local noon, a morning root to the night that precedes it;
  * the extremum of that night is found by ternary search over altitude_at() (fresh solar
    coordinates per instant, not the engine's interpolation);
  * a crossing, when one exists, is bracketed and bisected to the second.

Then two questions per request:

  * engine answered - does a crossing exist at all?  (false root)
  * a crossing exists, and it is further from solar midnight than the engine's own tangency
    margin - did the engine answer?                  (missed root)

Crossings inside the tangency margin are *supposed* to be dropped: PrayerTimes.kt discards them by
design, because there twilight never truly ends and the printed interval is the honest answer.

Usage: python3 tools/verify_tangency.py [--verbose] [--legacy] [--cities N]
       --legacy restores the pre-0.2.6 acceptance test (tolerance 0.05 deg, no sign probe) so the
       regression can be demonstrated instead of merely asserted.
"""
import argparse, json, math, os, sys
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import prayer_port as pp
from prayer_port import Coordinates, SolarTime
from verify_roots import altitude_at

ASSET = os.path.join(HERE, "..", "app", "src", "main", "assets", "cities_ru.json")
ANGLES = (12.0, 15.0, 16.0, 17.0, 17.5, 18.0, 18.5, 19.0, 19.5)
# Same margin as TANGENCY_MARGIN_SECONDS in PrayerTimes.kt, in hours.
MARGIN_HOURS = 600.0 / 3600.0


def dates():
    out = [date(2026, 6, 1) + timedelta(days=2 * i) for i in range(21)]
    out += [date(2026, 5, 10), date(2026, 5, 20), date(2026, 7, 20), date(2026, 8, 8),
            date(2026, 1, 5), date(2026, 3, 21), date(2026, 9, 23), date(2026, 12, 15)]
    return out


def extremum(d, coords, centre, half_window=5.0):
    lo, hi = centre - half_window, centre + half_window
    for _ in range(80):
        a = lo + (hi - lo) / 3.0
        b = hi - (hi - lo) / 3.0
        if altitude_at(d, coords, a) < altitude_at(d, coords, b):
            hi = b
        else:
            lo = a
    h = (lo + hi) / 2.0
    return altitude_at(d, coords, h), h


def crossing(d, coords, angle, lo_h, hi_h):
    """Bisect altitude(t) = -angle inside a bracket known to change sign. Returns hours."""
    f = lambda h: altitude_at(d, coords, h) + angle
    a, b = lo_h, hi_h
    fa = f(a)
    for _ in range(60):
        m = (a + b) / 2.0
        fm = f(m)
        if (fa < 0) == (fm < 0):
            a, fa = m, fm
        else:
            b = m
    return (a + b) / 2.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--legacy", action="store_true")
    ap.add_argument("--cities", type=int, default=0, help="limit for a quick run")
    args = ap.parse_args()

    if args.legacy:
        pp.ROOT_TOLERANCE_DEGREES = 0.05
        pp.SIGN_PROBE_DAYS = 0.0

    with open(ASSET, encoding="utf-8") as fh:
        cities = json.load(fh)
    if args.cities:
        cities = cities[: args.cities]

    false_roots, missed = [], []
    checked = 0
    for city in cities:
        coords = Coordinates(city["lat"], city["lon"])
        zone = ZoneInfo(city["tz"])
        for d in dates():
            offset = datetime.combine(d, time(12), zone).utcoffset().total_seconds() / 3600.0
            st = SolarTime(d, coords, pp.anchor_hours(d, offset))
            if math.isnan(st.transit):
                continue
            nights = {
                True: extremum(d, coords, st.transit + 12.0),   # evening branch
                False: extremum(d, coords, st.transit - 12.0),  # morning branch
            }
            for after in (True, False):
                low, low_h = nights[after]
                for angle in ANGLES:
                    root = st.hour_angle(-angle, after)
                    checked += 1
                    if low + angle > 0.001:           # the Sun never reached the angle
                        if not math.isnan(root):
                            false_roots.append((city["name"], str(d), angle, after,
                                                round(root, 4), round(low, 4)))
                        continue
                    if low + angle > -0.05:           # grazing: engine may legitimately decline
                        continue
                    # Real crossing. Where is it, relative to solar midnight?
                    edge = low_h - 8.0 if after else low_h + 8.0
                    if (altitude_at(d, coords, edge) + angle) <= 0:
                        continue                       # no sign change in the bracket, skip
                    t = crossing(d, coords, angle, low_h, edge)
                    if abs(t - low_h) <= MARGIN_HOURS:
                        continue                       # inside the tangency margin, dropped by design
                    if math.isnan(root):
                        missed.append((city["name"], str(d), angle, after,
                                       round(t, 4), round(low, 4)))
                    elif abs(root - t) > 60.0 / 3600.0 and abs(root - (t if after else t)) > 1e-9:
                        # answered, but not at the crossing the scan found (allow a minute)
                        missed.append((city["name"], str(d), angle, after, "смещение",
                                       round(root - t, 4)))
    print(f"Проверено {checked} запросов корня в {len(cities)} городах, "
          f"{len(dates())} дат, {len(ANGLES)} углов")
    print(f"Ложных корней (Солнце не дошло до угла): {len(false_roots)}")
    print(f"Пропущенных/смещённых корней: {len(missed)}")
    if args.verbose:
        for row in false_roots[:20]:
            print("  ЛОЖНЫЙ", row)
        for row in missed[:20]:
            print("  ПРОПУСК", row)
    return 1 if false_roots or missed else 0


if __name__ == "__main__":
    sys.exit(main())
