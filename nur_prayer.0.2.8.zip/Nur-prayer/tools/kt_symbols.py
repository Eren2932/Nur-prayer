#!/usr/bin/env python3
"""
Poor man's resolver for the Kotlin tree (0.2.6).

There is no Android SDK in this sandbox, so `./gradlew assembleRelease` cannot be the thing that
first notices a typo. kt_sanity.py checks shape - braces, obvious leftovers. This one checks
*names*, which is where a hand-edited tree actually breaks:

  * every capitalised identifier used in a file must be declared in that file, imported, declared
    somewhere else in the same package, or be a known Kotlin/Java/Compose builtin;
  * every named argument at a call site of a function declared *inside the project* must match a
    parameter of that function - this is what catches a renamed parameter after a refactor;
  * every import must be used (an unused import is not an error to the compiler, but it is a sign
    that something was deleted halfway).

False positives are possible; the point is that the list is short enough to read.
Usage: python3 tools/kt_symbols.py [--strict-imports]
"""
import argparse, os, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src")

BUILTINS = set("""
Any Array ArrayList Boolean Byte Char CharSequence Comparable Double DoubleArray Enum Exception Float
Function0 Function1 HashMap HashSet Int IntArray Iterable Iterator LinkedHashMap List Long Map Math
MutableList MutableMap Nothing Number Pair Runnable Set Short String StringBuilder Suppress Throwable
Triple Unit Volatile JvmStatic JvmField Deprecated Override SuppressLint RequiresApi TargetApi
Locale System Thread Runtime Objects Collections Comparator Regex Sequence Result
Boolean Byte Companion Iterable Number
""".split())

def kt_files():
    for base, _, files in os.walk(ROOT):
        for f in files:
            if f.endswith(".kt"):
                yield os.path.join(base, f)

def package_of(text):
    m = re.search(r"^package\s+([\w.]+)", text, re.M)
    return m.group(1) if m else ""

def declarations(text):
    out = set()
    # `fun interface` is in the list on purpose: without it a SAM interface parsed as a function
    # named "interface", and every use of the type was reported as an unknown name.
    for m in re.finditer(r"^\s*(?:public |private |internal |abstract |sealed |open |data |enum |value |fun )*"
                         r"(?:class|interface|object|enum class|annotation class)\s+([A-Z]\w*)", text, re.M):
        out.add(m.group(1))
    for m in re.finditer(r"^\s*(?:@\w+\s*)*(?:public |private |internal |suspend |inline |external )*"
                         r"fun\s+(?:<[^>]+>\s*)?([A-Z]\w*)\s*\(", text, re.M):
        out.add(m.group(1))
    for m in re.finditer(r"^\s*(?:public |private |internal |const )*val\s+([A-Z]\w*)", text, re.M):
        out.add(m.group(1))
    # enum entries and typealiases
    for m in re.finditer(r"^\s*typealias\s+([A-Z]\w*)", text, re.M):
        out.add(m.group(1))
    return out

def enum_entries(text):
    out = set()
    for m in re.finditer(r"enum class\s+\w+[^{]*\{([^}]*)\}", text, re.S):
        for token in re.findall(r"\b([A-Z][A-Z0-9_]{1,})\b", m.group(1)):
            out.add(token)
    return out

def strip_noise(text):
    """Remove comments and string bodies: both can contain parentheses and break brace counting."""
    text = re.sub(r"/\*[\s\S]*?\*/", "", text)
    text = re.sub(r"//[^\n]*", "", text)
    text = re.sub(r'"""[\s\S]*?"""', '""', text)
    text = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', text)
    return text


def project_functions(files):
    """name -> set of allowed parameter names, for functions declared in the project."""
    table = {}
    for path in files:
        text = strip_noise(open(path, encoding="utf-8").read())
        for m in re.finditer(r"fun\s+(?:<[^>]+>\s*)?(\w+)\s*\(", text):
            name = m.group(1)
            start = m.end() - 1
            depth = 0
            for i in range(start, len(text)):
                if text[i] == "(":
                    depth += 1
                elif text[i] == ")":
                    depth -= 1
                    if depth == 0:
                        params = text[start + 1:i]
                        break
            else:
                continue
            names = set(re.findall(r"(?:^|,)\s*(?:@\w+\s*)*(?:vararg\s+)?(\w+)\s*:", params))
            table.setdefault(name, set()).update(names)
    return table

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strict-imports", action="store_true")
    args = ap.parse_args()

    files = list(kt_files())
    texts = {p: open(p, encoding="utf-8").read() for p in files}
    by_package = {}
    for p, t in texts.items():
        by_package.setdefault(package_of(t), set()).update(declarations(t) | enum_entries(t))
    functions = project_functions(files)

    problems = []
    for path, text in texts.items():
        pkg = package_of(text)
        body = "\n".join(l for l in text.split("\n") if not l.startswith("import "))
        # strip strings and comments so text inside them is not treated as code
        code = strip_noise(body)

        imported = {}
        for line in text.split("\n"):
            m = re.match(r"import\s+([\w.]+)(?:\s+as\s+(\w+))?", line)
            if m:
                target = m.group(2) or m.group(1).split(".")[-1]
                imported[target] = line

        local = declarations(text) | enum_entries(text)
        # qualified uses (com.nur.prayer.X.Y) are fine on their own
        known = local | set(imported) | by_package.get(pkg, set()) | BUILTINS
        for m in re.finditer(r"(?<![\w.])([A-Z]\w*)", code):
            name = m.group(1)
            if name in known:
                continue
            if re.match(r"^[A-Z0-9_]+$", name):  # SCREAMING_CASE constant from a starred import
                continue
            problems.append(f"{os.path.relpath(path, ROOT)}: неизвестное имя {name}")

        for m in re.finditer(r"(?<![\w.])([a-zA-Z]\w*)\s*\(", code):
            fname = m.group(1)
            if fname not in functions:
                continue
            allowed = functions[fname]
            start = m.end() - 1
            depth = 0
            for i in range(start, len(code)):
                if code[i] == "(":
                    depth += 1
                elif code[i] == ")":
                    depth -= 1
                    if depth == 0:
                        call = code[start + 1:i]
                        break
            else:
                continue
            for arg in re.finditer(r"(?:^|,)\s*(\w+)\s*=(?!=)", call):
                key = arg.group(1)
                if key not in allowed:
                    problems.append(
                        f"{os.path.relpath(path, ROOT)}: {fname}(...) — нет параметра «{key}»")

        if args.strict_imports:
            for target, line in imported.items():
                if target == "*":
                    continue
                if not re.search(r"(?<![\w.])" + re.escape(target) + r"\b", code):
                    problems.append(f"{os.path.relpath(path, ROOT)}: импорт не используется — {target}")

    seen = set()
    unique = [p for p in problems if not (p in seen or seen.add(p))]
    print(f"kt_symbols: {len(files)} файлов, функций в проекте {len(functions)}")
    if unique:
        for p in unique:
            print("  " + p)
        print(f"замечаний: {len(unique)}")
        return 1
    print("замечаний нет")
    return 0

if __name__ == "__main__":
    sys.exit(main())
