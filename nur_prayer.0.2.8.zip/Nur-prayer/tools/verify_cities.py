#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Sanity check for the offline city database.

A wrong coordinate is the quietest possible bug: the app keeps working, the times look plausible,
and they are wrong all year. Nothing here proves a coordinate correct - only a survey does - but
each check kills a whole class of mistakes that a typed table actually makes:

  * duplicate id / name, or two cities on the same spot;
  * a swapped or mistyped digit, which throws a city hundreds of km out of its own region;
  * a time zone that does not match the longitude (the classic copy-paste of "Europe/Moscow");
  * a coordinate outside the plausible envelope of the database.

Run: python3 tools/verify_cities.py
"""
import json, math, os, sys
from collections import defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo

ASSET = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     "..", "app", "src", "main", "assets", "cities_ru.json")
# A city may legitimately sit far from its zone's meridian (Russian zones are wide, and some
# regions were moved between zones by decree), but two and a half hours is beyond any of them.
MAX_SOLAR_GAP_HOURS = 2.5
# Two entries closer than this are almost certainly the same settlement typed twice.
MIN_SEPARATION_KM = 2.0
# A city must not be further than this from the other cities of its own region.
# Красноярский край тянется на 3000 км, поэтому порог ловит опечатку, а не большой регион.
MAX_REGION_SPREAD_KM = 1500.0


def haversine(a, b):
    lat1, lon1, lat2, lon2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = (math.sin((lat2 - lat1) / 2) ** 2 +
         math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2)
    return 2 * 6371.0088 * math.asin(math.sqrt(h))


KAABA = (21.4225, 39.8262)


def qibla_bearing(lat, lon):
    """Great-circle initial bearing to the Kaaba, degrees from true north."""
    f1, f2 = math.radians(lat), math.radians(KAABA[0])
    dl = math.radians(KAABA[1] - lon)
    y = math.sin(dl) * math.cos(f2)
    x = math.cos(f1) * math.sin(f2) - math.sin(f1) * math.cos(f2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360.0) % 360.0


def main() -> int:
    cities = json.load(open(ASSET, encoding="utf-8"))
    problems = []

    seen_id, seen_name = {}, {}
    for c in cities:
        if c["id"] in seen_id:
            problems.append(f"id {c['id']} повторяется: {seen_id[c['id']]} и {c['name']}")
        seen_id[c["id"]] = c["name"]
        if c["name"] in seen_name:
            problems.append(f"название повторяется: {c['name']}")
        seen_name[c["name"]] = True
        for field in ("name", "region", "country", "lat", "lon", "tz"):
            if field not in c or c[field] in ("", None):
                problems.append(f"{c.get('name', c['id'])}: нет поля {field}")

    for c in cities:
        if not (21.0 <= c["lat"] <= 72.0):
            problems.append(f"{c['name']}: широта {c['lat']} вне охвата базы (в базе есть Мекка, 21.4)")
        if not (19.0 <= c["lon"] <= 180.0):
            problems.append(f"{c['name']}: долгота {c['lon']} вне охвата базы")

        # January is deliberate: it is standard time everywhere in the database.
        offset = datetime(2026, 1, 15, 12, tzinfo=ZoneInfo(c["tz"])).utcoffset()
        offset_hours = offset.total_seconds() / 3600.0
        gap = abs(c["lon"] / 15.0 - offset_hours)
        if gap > MAX_SOLAR_GAP_HOURS:
            problems.append(
                f"{c['name']} ({c['region']}): пояс {c['tz']} = UTC{offset_hours:+.0f}, "
                f"а долгота {c['lon']} даёт солнечное {c['lon'] / 15.0:+.1f} ч — разрыв {gap:.1f} ч")

    # A region belongs to exactly one country: the field pair is what the picker groups by, so a
    # region leaking across a border would split a country's list in the UI.
    region_country = {}
    for c in cities:
        known = region_country.setdefault(c["region"], c["country"])
        if known != c["country"]:
            problems.append(f"регион «{c['region']}» встречается и в {known}, и в {c['country']}")

    # The zone of a country must be internally consistent with the country's own cities: a
    # copy-pasted Asia/Tashkent on a Kazakh city is invisible in the UI and costs an hour.
    by_country = defaultdict(list)
    for c in cities:
        by_country[c["country"]].append(c)

    # Qibla is the other thing a wrong coordinate ruins silently, and it fails in a *shaped* way:
    # a city north-east of Mecca must point somewhere between due south and due west, a city
    # north-west of it between due south and due east. A swapped lat/lon or a dropped minus sign
    # lands outside that half-plane immediately. Distance is bounded too - the database has nothing
    # further out than the Russian Far East (about 8000 km) and nothing closer than Jeddah.
    for c in cities:
        bearing = qibla_bearing(c["lat"], c["lon"])
        d_lon = c["lon"] - KAABA[1]
        north = c["lat"] > KAABA[0]
        # Beyond ninety degrees of longitude the shortest path leaves over the pole and the bearing
        # legitimately swings past north - Anadyr points 321 deg, which looks wrong and is right.
        # Inside that fan the half-plane rule holds and catches a swapped or mistyped coordinate.
        if north and abs(d_lon) <= 90.0:
            if d_lon > 0 and not (170.0 <= bearing <= 310.0):
                problems.append(f"{c['name']}: кыбла {bearing:.0f}° — город северо-восточнее Каабы")
            if d_lon < 0 and not (50.0 <= bearing <= 190.0):
                problems.append(f"{c['name']}: кыбла {bearing:.0f}° — город северо-западнее Каабы")
        km = haversine((c["lat"], c["lon"]), KAABA)
        if km > 10500.0:
            problems.append(f"{c['name']}: {km:.0f} км до Каабы — вне охвата базы")

    by_region = defaultdict(list)
    for c in cities:
        by_region[c["region"]].append(c)
    for region, group in by_region.items():
        if len(group) < 2:
            continue
        lat0 = sum(c["lat"] for c in group) / len(group)
        lon0 = sum(c["lon"] for c in group) / len(group)
        for c in group:
            d = haversine((lat0, lon0), (c["lat"], c["lon"]))
            if d > MAX_REGION_SPREAD_KM:
                problems.append(f"{c['name']}: {d:.0f} км от центра региона «{region}»")

    points = sorted(cities, key=lambda c: c["lat"])
    for i, a in enumerate(points):
        for b in points[i + 1:]:
            if b["lat"] - a["lat"] > 0.05:
                break
            d = haversine((a["lat"], a["lon"]), (b["lat"], b["lon"]))
            if d < MIN_SEPARATION_KM:
                problems.append(f"{a['name']} и {b['name']} разделяют {d * 1000:.0f} м")

    print(f"Городов в базе: {len(cities)}, стран: {len(by_country)}")
    print("По странам: " + ", ".join(
        f"{k} — {len(v)}" for k, v in sorted(by_country.items(), key=lambda kv: -len(kv[1]))))
    regions = sorted(by_region, key=lambda r: -len(by_region[r]))[:5]
    print("Крупнейшие регионы: " + ", ".join(f"{r} — {len(by_region[r])}" for r in regions))
    if problems:
        print(f"\nЗАМЕЧАНИЙ: {len(problems)}")
        for p in problems[:40]:
            print("  " + p)
        return 1
    print("\nЗамечаний нет: id и названия уникальны, у каждого города есть страна, регион не "
          "пересекает границу, пояса согласованы с долготой, разбросов по регионам и дублей "
          "координат нет.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
