#!/usr/bin/env python3
"""Build the Uzbek muftiyat printed-table asset from namozvaqti.uz month pages.

WHAT THIS FILE ENCODES (the finding that made 0.2.8 possible)
------------------------------------------------------------
The Muslim Board of Uzbekistan does not compute each city astronomically. It
publishes ONE table -- Tashkent -- and derives every other city as
"Tashkent + three offsets":

    Bomdod, Quyosh          one shared offset for that day  (spread inside the day: 0)
    Peshin                  round(4 * dLongitude), constant all year
    Asr, Shom, Xufton       one shared offset for that day  (spread inside the day: 0)

Verified on 8 cities x 365 days = 17520 printed values: the morning pair is
always equal and the evening triple is always equal, on every single day, for
every city. That is not something astronomy produces; it is a printed offset
table. This is exactly why every app (ours included) missed Uzbek time by
8-17 minutes while accidentally matching Bukhara: apps compute angles per city.

The two remaining offsets are a pure function of (latitude, day of year) once
the longitude term is removed, so they are stored as a latitude ladder of
anchor cities and interpolated linearly. Extrapolation beyond the ladder costs
up to 10 minutes, so the ladder deliberately ends at the extreme latitudes of
the Uzbek city list (Termez 37.22, Muynak 43.77) and latitude is clamped.

DATA REPAIR, STATED OUT LOUD
----------------------------
The January page of Tashkent serves corrupted rows for 2-9 January 2026 (Peshin
747-750 min where the other seven cities unanimously imply 752-755, and the row
for 2 January belongs to a different day entirely). No other city breaks. Those
eight days are reconstructed by median vote of the other seven cities, using
each city's own offset interpolated between 1 and 13 January. That is done here,
in the open, not hidden in the asset.

USAGE
    python3 tools/build_uz_table.py --pages <dir with m_<city>_<mm>.html> \
        --asset app/src/main/assets/uz_muftiyat_2026.txt \
        --reference app/src/test/resources/uz_reference_2026.txt
"""
import argparse, os, re, statistics, sys

YEAR = 2026
BASE = 'toshkent'
# Latitude/longitude of the anchor cities, identical to cities_ru.json to the 4th digit.
ANCHORS = {
    'termiz':    (37.2242, 67.2783),
    'qarshi':    (38.8606, 65.7847),
    'samarqand': (39.6542, 66.9597),
    'buxoro':    (39.7686, 64.4556),
    'fargona':   (40.3864, 71.7864),
    'toshkent':  (41.2995, 69.2401),
    'nukus':     (42.4531, 59.6103),
    'moynoq':    (43.7686, 59.0294),
}
DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
ROW = re.compile(r'<tr>\s*<td style="text-align: start">\s*(\d+)\s*[^<]*</td>\s*((?:<td>[^<]*</td>\s*){6,7})', re.S)
CELL = re.compile(r'<td>([^<]*)</td>')


def parse_pages(pages_dir):
    out = {}
    for city in ANCHORS:
        year = {}
        for month in range(1, 13):
            path = os.path.join(pages_dir, f'm_{city}_{month:02d}.html')
            with open(path, encoding='utf-8', errors='ignore') as fh:
                html = fh.read()
            for day, cells in ROW.findall(html):
                values = [c.strip() for c in CELL.findall(cells)][:6]
                if not all(re.fullmatch(r'\d{2}:\d{2}', v) for v in values):
                    continue
                year[(month, int(day))] = [int(v[:2]) * 60 + int(v[3:]) for v in values]
        missing = [(m, d) for m in range(1, 13) for d in range(1, DAYS_IN_MONTH[m - 1] + 1)
                   if (m, d) not in year]
        if missing:
            sys.exit(f'{city}: missing days {missing[:5]} ...')
        out[city] = year
    return out


def repair_base(data, log):
    """Rebuild the eight corrupted Tashkent days by median vote of the other cities."""
    base = data[BASE]
    good_before, good_after = (1, 1), [(1, d) for d in range(10, 17)]
    broken = [(1, d) for d in range(2, 10)]
    fixed = {}
    for key in broken:
        row = []
        for i in range(6):
            estimates = []
            for city in data:
                if city == BASE:
                    continue
                near = base[good_before][i] and data[city][good_before][i] - base[good_before][i]
                far = statistics.median(data[city][g][i] - base[g][i] for g in good_after)
                t = (key[1] - 1) / 12.0
                estimates.append(data[city][key][i] - (near + (far - near) * t))
            row.append(round(statistics.median(estimates)))
        fixed[key] = row
        log.append(f'  repaired {YEAR}-01-{key[1]:02d}: {base[key]} -> {row}')
    base.update(fixed)


def rle(values):
    parts, run, count = [], values[0], 0
    for v in values:
        if v == run:
            count += 1
        else:
            parts.append(f'{run}*{count}' if count > 1 else f'{run}')
            run, count = v, 1
    parts.append(f'{run}*{count}' if count > 1 else f'{run}')
    return ','.join(parts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pages', required=True)
    ap.add_argument('--asset', required=True)
    ap.add_argument('--reference', required=True)
    args = ap.parse_args()

    log = []
    data = parse_pages(args.pages)
    log.append(f'parsed {len(data)} cities x 365 days = {len(data) * 365 * 6} printed values')
    repair_base(data, log)

    keys = [(m, d) for m in range(1, 13) for d in range(1, DAYS_IN_MONTH[m - 1] + 1)]
    base = data[BASE]
    base_lon = ANCHORS[BASE][1]
    noon = {c: round(4 * (base_lon - ANCHORS[c][1])) for c in ANCHORS}

    # Structural proof, re-run on every build: groups must be internally identical.
    for city in data:
        for k in keys:
            row, b = data[city][k], base[k]
            dm = [row[i] - b[i] - noon[city] for i in (0, 1)]
            de = [row[i] - b[i] - noon[city] for i in (3, 4, 5)]
            if dm[0] != dm[1] or len(set(de)) != 1 or row[2] - b[2] != noon[city]:
                sys.exit(f'STRUCTURE BROKEN at {city} {k}: {row} vs base {b}')
    log.append('structure verified: morning pair identical, evening triple identical, '
               'Peshin == round(4*dLon) on all 2920 city-days')

    order = sorted(ANCHORS, key=lambda c: ANCHORS[c][0])
    lines = [
        '# Nur prayer -- printed table of the Muslim Board of Uzbekistan (namozvaqti.uz).',
        '# Generated by tools/build_uz_table.py. Do not edit by hand.',
        '# Model: city = base table + noonOffset(longitude) + morning/evening offset(latitude, day).',
        'NURUZ 1',
        f'YEAR {YEAR}',
        f'BASE {ANCHORS[BASE][0]:.4f} {ANCHORS[BASE][1]:.4f}',
        'LATS ' + ' '.join(f'{ANCHORS[c][0]:.4f}' for c in order),
        'TABLE 365',
    ]
    for k in keys:
        lines.append(' '.join(str(v) for v in base[k]))
    lines.append('MORNING')
    for c in order:
        lines.append(rle([data[c][k][0] - base[k][0] - noon[c] for k in keys]))
    lines.append('EVENING')
    for c in order:
        lines.append(rle([data[c][k][3] - base[k][3] - noon[c] for k in keys]))
    lines.append('END')
    asset = '\n'.join(lines) + '\n'
    os.makedirs(os.path.dirname(args.asset), exist_ok=True)
    with open(args.asset, 'w', encoding='utf-8') as fh:
        fh.write(asset)
    log.append(f'asset {args.asset}: {len(asset.encode())} bytes')

    ref = ['# Printed values of namozvaqti.uz for 2026, kept for the unit test only.',
           '# city lat lon month day bomdod quyosh peshin asr shom xufton']
    for c in order:
        for k in keys:
            lat, lon = ANCHORS[c]
            ref.append(f'{c} {lat:.4f} {lon:.4f} {k[0]} {k[1]} ' + ' '.join(str(v) for v in data[c][k]))
    os.makedirs(os.path.dirname(args.reference), exist_ok=True)
    with open(args.reference, 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(ref) + '\n')
    log.append(f'reference {args.reference}: {len(ref) - 2} city-days')
    print('\n'.join(log))


if __name__ == '__main__':
    main()
