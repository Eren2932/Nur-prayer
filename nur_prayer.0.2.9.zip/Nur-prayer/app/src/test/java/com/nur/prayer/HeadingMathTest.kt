package com.nur.prayer

import com.nur.prayer.ui.qibla.AzimuthMedian3
import com.nur.prayer.ui.qibla.HeadingFilter
import com.nur.prayer.ui.qibla.calibrationGrade
import com.nur.prayer.ui.qibla.smoothTilt
import com.nur.prayer.ui.qibla.uprightAfter
import com.nur.prayer.ui.qibla.angleDelta
import com.nur.prayer.ui.qibla.lerpAngle
import com.nur.prayer.ui.qibla.normalize
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/**
 * The compass bugs that survive in most apps are all here, as tests:
 * wrap-around at north, the shortest-path rule, and a filter that must not smear 359° into 180°.
 */
class HeadingMathTest {

    @Test
    fun `normalize maps any angle into 0 until 360`() {
        assertEquals(10f, normalize(370f), 0.001f)
        assertEquals(350f, normalize(-10f), 0.001f)
        assertEquals(0f, normalize(720f), 0.001f)
        assertEquals(359f, normalize(-361f), 0.001f)
    }

    @Test
    fun `angleDelta takes the short way round north`() {
        assertEquals(2f, angleDelta(359f, 1f), 0.001f)
        assertEquals(-2f, angleDelta(1f, 359f), 0.001f)
        assertEquals(90f, angleDelta(0f, 90f), 0.001f)
        assertTrue(abs(angleDelta(0f, 180f)) == 180f)
    }

    @Test
    fun `lerpAngle never travels the long way`() {
        val mid = lerpAngle(350f, 10f, 0.5f)
        assertEquals(0f, normalize(mid + 360f) % 360f, 0.5f)
    }

    @Test
    fun `filter converges to a steady bearing`() {
        val filter = HeadingFilter()
        var value = 0f
        repeat(80) { value = filter.push(123.4f) }
        assertEquals(123.4f, value, 0.5f)
    }

    @Test
    fun `filter crosses north without a 180 degree excursion`() {
        val filter = HeadingFilter()
        repeat(60) { filter.push(358f) }
        var worst = 0f
        repeat(40) {
            val out = filter.push(2f)
            // Anything between 358 and 2 is fine; 180 is the bug we are hunting.
            val distanceFromNorth = abs(angleDelta(0f, out))
            if (distanceFromNorth > worst) worst = distanceFromNorth
        }
        assertTrue("filter drifted to $worst degrees from north", worst <= 5f)
    }

    @Test
    fun `filter reacts fast to a large turn and slowly to noise`() {
        val fast = HeadingFilter()
        repeat(40) { fast.push(0f) }
        val afterBigTurn = (1..6).map { fast.push(90f) }.last()
        assertTrue("expected a quick move, got $afterBigTurn", afterBigTurn > 55f)

        val calm = HeadingFilter()
        repeat(40) { calm.push(45f) }
        val afterNoise = calm.push(46f)
        assertTrue("noise leaked through: $afterNoise", abs(angleDelta(45f, afterNoise)) < 0.4f)
    }

    @Test
    fun `the upright switch needs ten degrees to change its mind`() {
        // The 0.2.7 bug, written down as a test: a single 55 degree threshold flips on a hand that
        // holds still at 55, and every flip is a real jump of the computed azimuth.
        var state = false
        state = uprightAfter(state, 56f)
        assertEquals(false, state)          // 56 is not enough to enter
        state = uprightAfter(state, 61f)
        assertEquals(true, state)           // 61 enters
        state = uprightAfter(state, 55f)
        assertEquals(true, state)           // and 55 no longer throws us out
        state = uprightAfter(state, 51f)
        assertEquals(true, state)
        state = uprightAfter(state, 49f)
        assertEquals(false, state)          // only below 50
    }

    @Test
    fun `a hand trembling on the threshold never flips the hold`() {
        var state = false
        var flips = 0
        // A tremor of a couple of degrees around 57, which is a perfectly ordinary hold.
        for (i in 0 until 200) {
            val tilt = 57f + if (i % 2 == 0) 1.5f else -1.5f
            val next = uprightAfter(state, tilt)
            if (next != state) flips++
            state = next
        }
        assertEquals(0, flips)
    }

    @Test
    fun `the median swallows a single spike`() {
        val median = AzimuthMedian3()
        median.push(100f)
        median.push(101f)
        // One frame lands 12 degrees away: a laptop hinge, a car speaker, a magnetic case.
        assertEquals(101f, median.push(113f), 0.6f)
        // A real turn is not a spike: once two samples agree, the median follows.
        median.push(140f)
        assertEquals(140f, median.push(141f), 1.5f)
    }

    @Test
    fun `the median stays sane across north`() {
        val median = AzimuthMedian3()
        median.push(359f)
        median.push(1f)
        val out = median.push(0f)
        // Anything in 358..2 is correct here; a wrap bug would answer near 180.
        assertEquals(0f, angleDelta(out, 0f), 2f)
    }

    @Test
    fun `resetting the filter adopts the next reading immediately`() {
        val filter = HeadingFilter()
        repeat(40) { filter.push(10f) }

        // A *small* step is the dangerous one. The gain adapts, so a 180 degree turn is followed at
        // once, but a three degree change — exactly the size of a declination change between two
        // cities — is treated as noise and crawls in over a dozen frames. That crawl is the "стрелка
        // уезжает на пару градусов" the user reported after pressing "определить по местоположению".
        val crawling = filter.push(13f)
        assertTrue("фильтр не должен принимать малый шаг сразу: $crawling", abs(crawling - 13f) > 1.5f)

        // After a reset the new geometry is adopted on the first sample instead of being averaged
        // with a direction that no longer exists.
        filter.reset()
        assertEquals(13f, filter.push(13f), 0.001f)
    }

    @Test
    fun `calibration grade never inherits the rotation vector's optimism`() {
        // The exact situation on the user's screen: platform says HIGH, field is normal, but the
        // independent witness is 14 degrees away. The answer must not be 3.
        assertEquals(1, calibrationGrade(magAccuracy = 3, field = 48f, disagreement = 14f))
        assertEquals(0, calibrationGrade(magAccuracy = 3, field = 48f, disagreement = 25f))
        assertEquals(2, calibrationGrade(magAccuracy = 3, field = 48f, disagreement = 7f))
        assertEquals(3, calibrationGrade(magAccuracy = 3, field = 48f, disagreement = 2f))
    }

    @Test
    fun `calibration grade demotes a bent field and an unknown magnetometer`() {
        assertEquals(1, calibrationGrade(magAccuracy = 3, field = 95f, disagreement = 1f))
        assertEquals(1, calibrationGrade(magAccuracy = 3, field = 12f, disagreement = 1f))
        // Never reported: honest middle, never "высокая".
        assertEquals(2, calibrationGrade(magAccuracy = -1, field = 48f, disagreement = Float.NaN))
        // A device that admits it is uncalibrated is believed immediately.
        assertEquals(0, calibrationGrade(magAccuracy = 0, field = 48f, disagreement = 1f))
    }

    @Test
    fun `tilt smoothing settles without lagging forever`() {
        var tilt = smoothTilt(Float.NaN, 40f)
        assertEquals(40f, tilt, 0.001f)     // first sample is taken as is
        repeat(30) { tilt = smoothTilt(tilt, 20f) }
        assertEquals(20f, tilt, 0.5f)
    }
}
