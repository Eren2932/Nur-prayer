package com.nur.prayer.ui.qibla

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Pure compass mathematics: no Android types, so it is unit-tested on the JVM instead of being
 * verified by waving a phone around. Everything here is exercised by `HeadingMathTest`.
 */

/**
 * Low-pass filter on the unit vector, not on the angle: immune to the 359°/0° discontinuity.
 * The gain adapts — a big movement is followed almost immediately, a resting phone is averaged
 * hard, which is what kills the jitter you see in cheap compass apps.
 */
internal class HeadingFilter {
    private var sinAcc = Float.NaN
    private var cosAcc = Float.NaN

    /**
     * Forgets the accumulated direction, so the next reading is adopted instantly.
     *
     * This is the fix for the symptom "после кнопки «определить по местоположению» стрелка на пару
     * градусов уезжает вправо-влево". Two things move the true azimuth in one step — a new
     * declination when the coordinates change, and the axis remap when the hold switches between
     * flat and upright. The filter knew nothing about either: it kept averaging towards the *old*
     * direction and crawled to the new one over a second or two, which reads exactly like a compass
     * that cannot make up its mind. After a step change the old average is not data, it is a lie, so
     * it is dropped.
     */
    fun reset() {
        sinAcc = Float.NaN
        cosAcc = Float.NaN
    }

    fun push(degrees: Float): Float {
        val radians = Math.toRadians(degrees.toDouble()).toFloat()
        val s = sin(radians)
        val c = cos(radians)
        if (sinAcc.isNaN()) {
            sinAcc = s
            cosAcc = c
            return normalize(degrees)
        }
        val current = normalize(Math.toDegrees(atan2(sinAcc, cosAcc).toDouble()).toFloat())
        val jump = abs(angleDelta(current, degrees))
        // Gain floor raised from 0.10 to 0.25 and the ramp shortened from 25° to 15°.
        // At the sensor rate we ask for now (FASTEST, 100-200 Hz on modern phones) a 0.10 floor is a
        // ~200 ms time constant: the arrow visibly trails the hand, which reads as "the compass is
        // frozen". 0.25 puts the constant near 60 ms — faster than the eye resolves — while the
        // median in front of the filter keeps single-frame spikes out, so nothing is paid for it.
        val gain = (0.25f + 0.65f * (jump / 15f).coerceAtMost(1f)).coerceIn(0.25f, 0.90f)
        sinAcc += (s - sinAcc) * gain
        cosAcc += (c - cosAcc) * gain
        return normalize(Math.toDegrees(atan2(sinAcc, cosAcc).toDouble()).toFloat())
    }
}

internal fun normalize(angle: Float): Float = ((angle % 360f) + 360f) % 360f

/** Shortest-path angular interpolation: no 359 -> 0 jump. */
internal fun lerpAngle(from: Float, to: Float, factor: Float): Float {
    val delta = ((to - from + 540f) % 360f) - 180f
    if (abs(delta) < 0.05f) return normalize(to)
    return normalize(from + delta * factor)
}

/** Signed difference in degrees, -180..180. Positive means [to] is clockwise from [from]. */
internal fun angleDelta(from: Float, to: Float): Float = ((to - from + 540f) % 360f) - 180f

/**
 * Median of the last three raw azimuths, on the circle.
 *
 * A magnetometer sample stream is not just noisy, it spikes: a single frame can land ten degrees
 * away when the phone passes a laptop hinge or a car speaker. A low-pass filter *averages* a spike
 * in and then has to walk back out of it — that is the visible twitch. A median simply refuses to
 * pass a lone outlier through, and three samples is the shortest window that has a middle.
 *
 * The median is taken relative to the newest sample so that 359° and 1° stay neighbours instead of
 * being 358 degrees apart.
 */
internal class AzimuthMedian3 {
    private var a = Float.NaN
    private var b = Float.NaN

    fun reset() {
        a = Float.NaN
        b = Float.NaN
    }

    fun push(degrees: Float): Float {
        val current = normalize(degrees)
        if (a.isNaN() || b.isNaN()) {
            b = a
            a = current
            return current
        }
        // Work in signed deltas from the newest sample: -180..180, no wrap inside the window.
        val d0 = 0f
        val d1 = angleDelta(current, a)
        val d2 = angleDelta(current, b)
        val middle = median(d0, d1, d2)
        b = a
        a = current
        return normalize(current + middle)
    }

    private fun median(x: Float, y: Float, z: Float): Float =
        maxOf(minOf(x, y), minOf(maxOf(x, y), z))
}

/**
 * Whether the phone counts as "held upright" now, with hysteresis.
 *
 * One threshold was the bug. `tilt > 55°` decided which axis remap produced the azimuth, and at a
 * hold near 55° the value crosses back and forth several times a second — each crossing is a real,
 * large jump in the computed azimuth, and the arrow visibly shudders while the hand is perfectly
 * still. Two thresholds mean the state must travel 10° to flip back, which no hand tremor does.
 *
 * Entering upright at 60° and leaving at 50° also matches how people actually hold a phone: flat on
 * the palm is 0-20°, reading posture is 45-65°, camera posture is 75-90°.
 */
internal fun uprightAfter(previous: Boolean, tiltDegrees: Float): Boolean =
    if (previous) tiltDegrees > 50f else tiltDegrees > 60f

/** Light low-pass for the tilt read-out, so the bubble level does not flicker on the last digit. */
internal fun smoothTilt(previous: Float, sample: Float): Float =
    if (previous.isNaN()) sample else previous * 0.72f + sample * 0.28f

/**
 * Honest calibration grade, 0..3, from everything we can actually observe.
 *
 * This replaces "whatever `onAccuracyChanged` last said", and that swap is the fix for the report
 * «телефон стоит вертикально, а он всё равно пишет "калибровка высокая"». On most phones the
 * accuracy callback that arrives belongs to `TYPE_ROTATION_VECTOR`, and that virtual sensor is
 * fused with the gyroscope: the platform reports it as HIGH almost immediately after boot and then
 * never lowers it, even while the magnetometer underneath is badly off. The screen was therefore
 * printing a constant, not a measurement.
 *
 * Three independent facts are used instead:
 *
 *  - [magAccuracy] — the accuracy of the *physical* magnetometer, and only of it. -1 means the
 *    device never reported one, which is "unknown", not "good".
 *  - [field] — Earth's field is 25-65 µT. Outside that band the reading is being bent by metal or
 *    a magnet, and no amount of calibration makes it true.
 *  - [disagreement] — degrees between the fused heading and the heading computed from raw
 *    accelerometer + magnetometer. When the magnetometer has a hard-iron offset the two solutions
 *    part company; the gyro-fused one keeps looking confident while being wrong. This is the check
 *    that catches a stale calibration that the platform is still calling HIGH.
 */
internal fun calibrationGrade(magAccuracy: Int, field: Float, disagreement: Float): Int {
    var grade = when (magAccuracy) {
        3 -> 3
        2 -> 2
        1 -> 1
        0 -> 0
        else -> 2 // unknown: not a promise, but not an accusation either
    }
    if (field > 1f && (field < 22f || field > 72f)) grade = minOf(grade, 1)
    if (!disagreement.isNaN()) {
        if (disagreement > 20f) grade = minOf(grade, 0)
        else if (disagreement > 10f) grade = minOf(grade, 1)
        else if (disagreement > 6f) grade = minOf(grade, 2)
    }
    return grade
}
