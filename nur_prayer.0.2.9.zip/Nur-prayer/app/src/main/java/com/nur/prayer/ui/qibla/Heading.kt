package com.nur.prayer.ui.qibla

import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.view.Surface
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

/** Which sensor stack produced the current reading. */
enum class HeadingSource {
    /** Accelerometer + gyroscope + magnetometer, fused by the platform. The good one. */
    FUSED,

    /** Accelerometer + magnetometer fused by the platform (no gyroscope on this device). */
    GEOMAGNETIC,

    /** Raw accelerometer + magnetometer, fused by us. Noisier, still correct. */
    RAW,

    /** No usable sensors. */
    NONE
}

/**
 * Device heading, in degrees clockwise from **true** north.
 *
 * Everything that makes a phone compass wrong is handled here explicitly:
 *
 *  - **Magnetic vs true north.** The magnetometer points at magnetic north. Across Russia the
 *    declination runs from about +8° in Kaliningrad to +20° in Yakutia, and it is negative in parts
 *    of the west. We add the WMM correction from [GeomagneticField] for the user's own coordinates.
 *    Without it the Qibla arrow is off by a whole sector.
 *  - **Screen rotation.** Sensor axes are tied to the *natural* orientation of the device, not to
 *    what you see. On a landscape-natural tablet, or with the screen rotated, a naive reading is off
 *    by 90°. We remap the rotation matrix through the current display rotation.
 *  - **Tilt.** `getOrientation` is only meaningful while the device is roughly flat; held upright it
 *    degenerates (gimbal lock at pitch ±90°). When we detect the phone is being held up, we remap
 *    the matrix (AXIS_X, AXIS_Z) so the azimuth becomes "where the back of the phone looks" — the
 *    reading the user actually expects — and we still report [tiltDegrees] so the UI can ask for a
 *    flatter hold.
 *  - **Wrap-around.** Smoothing 359° and 1° arithmetically gives 180°. We low-pass the *unit
 *    vector* (sin, cos) instead of the angle, so there is no discontinuity anywhere on the circle.
 *  - **Interference.** Earth's field is 25–65 µT. A speaker magnet, a car dashboard or a metal table
 *    pushes the magnitude out of that band; we detect it and say so instead of silently lying.
 *  - **Calibration state.** `SENSOR_STATUS_ACCURACY_*` of the magnetometer is surfaced, with the
 *    figure-eight hint.
 */
@androidx.compose.runtime.Immutable
data class Heading(
    /** Degrees clockwise from true north. */
    val azimuth: Float = 0f,
    /** Raw reading before the declination correction, for the diagnostics panel. */
    val magneticAzimuth: Float = 0f,
    /** WMM declination at the user's coordinates, degrees east. */
    val declination: Float = 0f,
    /**
     * Calibration grade 0..3 computed by [calibrationGrade]: the magnetometer's own accuracy,
     * corrected by the field magnitude and by how far the fused solution has drifted from the raw
     * one. Deliberately *not* the number `onAccuracyChanged` hands out for the rotation vector.
     */
    val accuracy: Int = -1,
    /** Raw `SENSOR_STATUS_ACCURACY_*` of the physical magnetometer, -1 when the device never said. */
    val magnetometerAccuracy: Int = -1,
    /**
     * Degrees between the fused heading and the independent accelerometer+magnetometer heading.
     * NaN until both are available. Above ~10° the magnetometer needs the figure-eight.
     */
    val disagreement: Float = Float.NaN,
    /** Angle between the screen plane and the horizontal plane, degrees. 0 = perfectly flat. */
    val tiltDegrees: Float = 0f,
    /** Measured magnetic field magnitude, µT. 0 when unknown. */
    val fieldStrength: Float = 0f,
    /** True while the phone is read as held upright: the azimuth is where its back looks. */
    val heldUpright: Boolean = false,
    val source: HeadingSource = HeadingSource.NONE
) {
    val available: Boolean get() = source != HeadingSource.NONE

    /** True when the field magnitude is outside the plausible band for Earth's field. */
    val interference: Boolean
        get() = fieldStrength > 1f && (fieldStrength < 22f || fieldStrength > 72f)

    /**
     * True while the phone is held flat enough for the reading to be first-class.
     *
     * 45°, not 30°. Below the upright switch-over the flat solution is geometrically fine — the
     * error from tilt alone is under a degree at 45° — so warning at 30° told people something was
     * wrong with a hold that was perfectly good, and the amber ring never went away in normal use.
     * Above 50° the reading changes meaning rather than degrading, and that is [heldUpright].
     */
    val heldFlat: Boolean get() = heldUpright || tiltDegrees <= 45f

    /** True when the two independent solutions have visibly parted company. */
    val needsCalibration: Boolean
        get() = available && (accuracy <= 1 || (!disagreement.isNaN() && disagreement > 10f))

    /** Everything is calibrated, undisturbed and level. */
    val trustworthy: Boolean
        get() = available && !interference && accuracy >= SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM
}

@Composable
fun rememberHeading(latitude: Double, longitude: Double): Heading {
    val context = LocalContext.current
    var heading by remember { mutableStateOf(Heading()) }

    DisposableEffect(latitude, longitude, context) {
        val manager = context.getSystemService(SensorManager::class.java)
        val declination = runCatching {
            GeomagneticField(
                latitude.toFloat(),
                longitude.toFloat(),
                0f,
                System.currentTimeMillis()
            ).declination
        }.getOrDefault(0f)

        if (manager == null) {
            heading = Heading(declination = declination, source = HeadingSource.NONE)
            return@DisposableEffect onDispose { }
        }

        val rotationSensor = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val geomagneticSensor = manager.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR)
        val magnetSensor = manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        val accelSensor = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        val vectorSensor = rotationSensor ?: geomagneticSensor
        val source = when {
            rotationSensor != null -> HeadingSource.FUSED
            geomagneticSensor != null -> HeadingSource.GEOMAGNETIC
            magnetSensor != null && accelSensor != null -> HeadingSource.RAW
            else -> HeadingSource.NONE
        }

        if (source == HeadingSource.NONE) {
            heading = Heading(declination = declination, source = HeadingSource.NONE)
            return@DisposableEffect onDispose { }
        }

        val filter = HeadingFilter()
        val median = AzimuthMedian3()
        /*
         * Hold state and the smoothed tilt live across events on purpose: both are hysteretic, and a
         * hysteretic value that is recomputed from scratch on every sample is just the old bug with
         * extra steps. They are reset together with the filter whenever the geometry changes, which
         * for coordinates means "this whole effect is recreated" — see DisposableEffect keys.
         */
        var upright = false
        var smoothedTilt = Float.NaN
        val rotationMatrix = FloatArray(9)
        val displayMatrix = FloatArray(9)
        val finalMatrix = FloatArray(9)
        val orientation = FloatArray(3)
        val gravity = FloatArray(3)
        val geomagnetic = FloatArray(3)
        var hasGravity = false
        var hasGeomagnetic = false
        var fieldStrength = 0f
        // Only ever written from TYPE_MAGNETIC_FIELD. The rotation vector's own accuracy is kept
        // apart on purpose — see calibrationGrade().
        var magnetAccuracy = -1
        var disagreement = Float.NaN
        var lastEmit = 0L
        var lastAzimuth = Float.NaN
        val crossMatrix = FloatArray(9)
        val crossOrientation = FloatArray(3)

        /**
         * Independent heading from raw accelerometer + magnetometer, used only as a witness against
         * the fused one. It is never displayed, so its noise does not matter; what matters is that
         * it has no gyroscope in it and therefore cannot inherit the fused solution's confidence.
         */
        fun crossCheck(fusedMagnetic: Float) {
            if (!hasGravity || !hasGeomagnetic) return
            if (!SensorManager.getRotationMatrix(crossMatrix, null, gravity, geomagnetic)) return
            SensorManager.getOrientation(crossMatrix, crossOrientation)
            val raw = normalize(Math.toDegrees(crossOrientation[0].toDouble()).toFloat())
            // Compare flat-frame to flat-frame: when the hold is upright the displayed azimuth has
            // been remapped and would differ by construction, not by error.
            val delta = abs(angleDelta(raw, normalize(fusedMagnetic)))
            disagreement = if (disagreement.isNaN()) delta else disagreement * 0.85f + delta * 0.15f
        }

        fun publish(magneticAzimuth: Float, tilt: Float) {
            // Order matters: spike rejection on the raw reading first, smoothing second. Smoothing a
            // spike means the average has to climb out of it, which is the twitch the user sees.
            val deSpiked = median.push(magneticAzimuth)
            val trueAzimuth = normalize(deSpiked + declination)
            val smoothed = filter.push(trueAzimuth)
            val now = System.currentTimeMillis()
            // Compare against what we last *emitted*, not against `heading`: recomposition can lag
            // by a frame, and comparing to a stale snapshot let sub-threshold motion accumulate
            // silently — the arrow would sit still and then hop.
            val changed = lastAzimuth.isNaN() || abs(angleDelta(lastAzimuth, smoothed)) > 0.05f
            // ~120 Hz ceiling instead of 60: the recomposition is one rotation value, and halving
            // the quantisation of when it lands is the difference between "follows the hand" and
            // "follows the hand a frame later".
            if (!changed && now - lastEmit < 200L) return
            if (now - lastEmit < 8L) return
            lastEmit = now
            lastAzimuth = smoothed
            heading = Heading(
                azimuth = smoothed,
                magneticAzimuth = normalize(magneticAzimuth),
                declination = declination,
                accuracy = calibrationGrade(magnetAccuracy, fieldStrength, disagreement),
                magnetometerAccuracy = magnetAccuracy,
                disagreement = disagreement,
                tiltDegrees = tilt,
                heldUpright = upright,
                fieldStrength = fieldStrength,
                source = source
            )
        }

        /** Turns a device->world rotation matrix into (azimuth, tilt), handling screen and hold. */
        fun fromRotationMatrix(matrix: FloatArray) {
            // Screen rotation: sensor axes follow the natural orientation of the device.
            val (axisX, axisY) = displayAxes(context)
            if (!SensorManager.remapCoordinateSystem(matrix, axisX, axisY, displayMatrix)) {
                displayMatrix.indices.forEach { displayMatrix[it] = matrix[it] }
            }

            // Tilt: angle between the screen plane and the horizon. matrix[8] is the vertical
            // component of the device Z axis, so acos() of it is exactly that angle.
            val vertical = displayMatrix[8].coerceIn(-1f, 1f)
            val rawTilt = Math.toDegrees(acos(vertical).toDouble()).toFloat()
            smoothedTilt = smoothTilt(smoothedTilt, rawTilt)
            val tilt = smoothedTilt

            // Hysteresis, and a hard reset of both smoothers when the hold actually changes: the
            // remap below rotates the reference frame, so the previous average belongs to a different
            // geometry and averaging across the switch produces a slow drift to the new value.
            val nowUpright = uprightAfter(upright, tilt)
            if (nowUpright != upright) {
                upright = nowUpright
                filter.reset()
                median.reset()
            }
            val active = if (upright) {
                // Held up like a camera: read where the back of the phone looks.
                if (SensorManager.remapCoordinateSystem(
                        displayMatrix,
                        SensorManager.AXIS_X,
                        SensorManager.AXIS_Z,
                        finalMatrix
                    )
                ) {
                    finalMatrix
                } else {
                    displayMatrix
                }
            } else {
                displayMatrix
            }

            SensorManager.getOrientation(active, orientation)
            val azimuth = Math.toDegrees(orientation[0].toDouble()).toFloat()
            publish(azimuth, tilt)
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                when (event.sensor.type) {
                    Sensor.TYPE_ROTATION_VECTOR,
                    Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR -> {
                        if (source == HeadingSource.FUSED &&
                            event.sensor.type == Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR
                        ) {
                            return
                        }
                        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                        fromRotationMatrix(rotationMatrix)
                        // The witness compares flat-frame magnetic north to flat-frame magnetic
                        // north — same frame, same instant, no declination on either side, so the
                        // only thing the difference can contain is sensor error.
                        SensorManager.getOrientation(rotationMatrix, crossOrientation)
                        crossCheck(
                            normalize(Math.toDegrees(crossOrientation[0].toDouble()).toFloat())
                        )
                    }

                    Sensor.TYPE_MAGNETIC_FIELD -> {
                        geomagnetic[0] = event.values[0]
                        geomagnetic[1] = event.values[1]
                        geomagnetic[2] = event.values[2]
                        hasGeomagnetic = true
                        fieldStrength = sqrt(
                            event.values[0] * event.values[0] +
                                event.values[1] * event.values[1] +
                                event.values[2] * event.values[2]
                        )
                        if (source == HeadingSource.RAW && hasGravity) {
                            if (SensorManager.getRotationMatrix(
                                    rotationMatrix, null, gravity, geomagnetic
                                )
                            ) {
                                fromRotationMatrix(rotationMatrix)
                            }
                        }
                    }

                    Sensor.TYPE_ACCELEROMETER -> {
                        // Light low-pass: gravity only, without the hand shake.
                        gravity[0] = gravity[0] * 0.82f + event.values[0] * 0.18f
                        gravity[1] = gravity[1] * 0.82f + event.values[1] * 0.18f
                        gravity[2] = gravity[2] * 0.82f + event.values[2] * 0.18f
                        hasGravity = true
                        if (source == HeadingSource.RAW && hasGeomagnetic) {
                            if (SensorManager.getRotationMatrix(
                                    rotationMatrix, null, gravity, geomagnetic
                                )
                            ) {
                                fromRotationMatrix(rotationMatrix)
                            }
                        }
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
                // Physical magnetometer only. TYPE_ROTATION_VECTOR reports HIGH on nearly every
                // device from the first second and never takes it back, which is precisely how the
                // screen ended up printing "калибровка высокая" while the needle was wrong.
                if (sensor?.type != Sensor.TYPE_MAGNETIC_FIELD) return
                magnetAccuracy = accuracy
                heading = heading.copy(
                    magnetometerAccuracy = accuracy,
                    accuracy = calibrationGrade(accuracy, heading.fieldStrength, heading.disagreement)
                )
            }
        }

        if (vectorSensor != null) {
            // FASTEST, not GAME. GAME is 20 ms; on this screen the compass is the only thing running
            // and the user is judging it by how tightly the needle sticks to the hand.
            manager.registerListener(listener, vectorSensor, SensorManager.SENSOR_DELAY_FASTEST)
        }
        // The magnetometer is always registered: interference probe, calibration probe, and one half
        // of the independent witness.
        if (magnetSensor != null) {
            manager.registerListener(listener, magnetSensor, SensorManager.SENSOR_DELAY_GAME)
        }
        // The accelerometer is now registered in every mode, not only RAW: without it the witness
        // has no gravity vector and the disagreement check cannot run.
        if (accelSensor != null) {
            manager.registerListener(listener, accelSensor, SensorManager.SENSOR_DELAY_GAME)
        }

        onDispose { manager.unregisterListener(listener) }
    }

    return heading
}

/** Axis pair that maps sensor space to what the user currently sees. */
internal fun displayAxes(context: Context): Pair<Int, Int> {
    val rotation = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            context.display?.rotation ?: Surface.ROTATION_0
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(WindowManager::class.java)?.defaultDisplay?.rotation
                ?: Surface.ROTATION_0
        }
    }.getOrDefault(Surface.ROTATION_0)

    return when (rotation) {
        Surface.ROTATION_90 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
        Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
        Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
        else -> SensorManager.AXIS_X to SensorManager.AXIS_Y
    }
}
